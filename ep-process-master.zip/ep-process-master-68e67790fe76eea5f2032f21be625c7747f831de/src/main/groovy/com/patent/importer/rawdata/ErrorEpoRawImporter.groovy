package com.patent.importer.rawdata

import org.slf4j.Logger;
import com.patent.utils.DataStorageUtil
import org.slf4j.LoggerFactory;

class  ErrorEpoRawImporter {
    
    Logger log = LoggerFactory.getLogger(ErrorEpoRawImporter.class);
    
    /**
     * errorPatentRawEPO schema
     * 
     */
    static void saveRawDataError(def errorPatentRawEPO, String path, String patentType, Date doDate, String exceptionMsg) {
        
        def existErrorData = errorPatentRawEPO.findOne([path: path]);
        def now = new Date()
        
        if (!!existErrorData) {
            
            existErrorData.errorMsg << [
                'exception' : exceptionMsg,
                'errorTime' : now
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentRawEPO.save(existErrorData)
            
        } else {
            
            def errorMap = [
                "path" : path,
                "patentType" : patentType,
                "doDate" : doDate,
                "errorMsg" : [] << [
                    'exception' : exceptionMsg,
                    'errorTime' : now
                ],
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentRawEPO.save(errorMap)
            
        }
        
    }  //  end saveRawDataError
    static void saveRawDataError(def errorPatentRawEPO, String path, String fileName, String exceptionMsg) {
        
        def existErrorData = errorPatentRawEPO.findOne([path: path]);
        def now = new Date()
        
        if (!!existErrorData) {
            existErrorData.errorMsg << [
                'exception' : exceptionMsg,
                'errorTime' : now,
                'fileName'  : fileName
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentRawEPO.save(existErrorData)
            
        } else {
            
            def errorMap = [
                "path" : path,
                "errorMsg" : [] << [
                    'exception' : exceptionMsg,
                    'errorTime' : now,
                    'fileName'  : fileName
                ],
                "updateFlag" : false,
                "provider" : "EPO OPS",
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentRawEPO.save(errorMap)
            
        }
        
    }  //  end saveRawDataError
    
}