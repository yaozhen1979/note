package com.patent.importer.marshalldata

import org.slf4j.Logger;
import com.mongodb.BasicDBObject
import com.patent.utils.DataStorageUtil
import org.slf4j.LoggerFactory;

class  ErrorEpoMarshalImporter {
    
    Logger log = LoggerFactory.getLogger(ErrorEpoMarshalImporter.class);
    
    /**
     * errorPatentMarshallEPO schema
     * 
     */
    static void saveMarshallDataError(def errorPatentMarshallEPO, String path, String patentType, Date doDate, String exceptionMsg) {
        
        def existErrorData = errorPatentMarshallEPO.findOne([path: path]);
        def now = new Date()
        
        if (!!existErrorData) {
            
            existErrorData.errorMsg << [
                'exception' : exceptionMsg,
                'errorTime' : now
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentMarshallEPO.save(existErrorData)
            
        } else {
            
            def errorMap = [
                "path" : path,
                "patentType" : patentType,
                "doDate" : doDate,
                "errorMsg" : [] << [
                    'exception' : exceptionMsg,
                    'errorTime' : now
                ],
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentMarshallEPO.save(errorMap)
            
        }
        
    }  //  end saveRawDataError
    static void saveMarshallDataError(def errorPatentMarshallEPO, String path, String fileName, String exceptionMsg) {
        
        def existErrorData = errorPatentMarshallEPO.findOne([path: path]);
        def now = new Date()
        
        if (!!existErrorData) {
            existErrorData.errorMsg << [
                'exception' : exceptionMsg,
                'errorTime' : now,
                'fileName'  : fileName
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentMarshallEPO.save(existErrorData)
            
        } else {
            
            def errorMap = [
                "path" : path,
                "errorMsg" : [] << [
                    'exception' : exceptionMsg,
                    'errorTime' : now,
                    'fileName'  : fileName
                ],
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            def errorMapToObject = new BasicDBObject(errorMap)
            errorPatentMarshallEPO.save(errorMapToObject)
            
        }
        
    }  //  end saveRawDataError
    
    /**
     * 
     * 
     * @param errorPatentInfoCNIPR
     * @param tempData
     * @param errMsg
     */
    static void saveInfoDataIpcError(def errorPatentInfoEPO, def tempData, def errMsg) {
        
        def existErrorData = errorPatentInfoEPO.findOne([doDate: tempData.doDate, patentNumber: tempData.patentNumber, errType: "ipc"]);
        def now = new Date()
        
        if (!!existErrorData) {
            
            existErrorData.errorMsg << [
                'exception' : errMsg,
                'errorTime' : now
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentInfoEPO.save(existErrorData)
            
        } else {
            def errorMap = [
                "doDate" : tempData.doDate,
                "patentNumber" : tempData.patentNumber,
                "patentType" : tempData.patentType,
                "errorMsg" : [] << [
                    'exception' : errMsg,
                    'errorTime' : now
                ],
                "errType" : "ipc",
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentInfoEPO.save(errorMap)
        }
    }
    
}