package com.patent.importer.infodata

import org.slf4j.LoggerFactory

import ch.qos.logback.classic.Logger
import com.patent.utils.InfoDocUtil
import com.mongodb.BasicDBObject
import com.mongodb.Bytes
import com.patent.common.Constants
import com.patent.service.BaseProcess
import com.patent.utils.MongoUtil

class EpoInfoImporter extends BaseProcess {
    private static Logger log = LoggerFactory.getLogger(EpoInfoImporter.class);
    def infoProcess () {
        def dbClient = MongoUtil.connect2X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def marshallDB = dbClient.getDB(Constants.MONGODB_MARSHALLDB)
        def marshallCol = marshallDB.getCollection("patentMarshallEPO")
        def infoDB = dbClient.getDB(Constants.MONGODB_INFODB)
        def errorInfoCol = infoDB.getCollection("errorPatentInfoEPO")
        def infoCol = infoDB.getCollection("patentInfoEPO")
        
        
        def query = new BasicDBObject("provider", Constants.FILE_PROVIDER)
        def mongoCursor = marshallCol.find(query).setOptions(Bytes.QUERYOPTION_NOTIMEOUT)
        
//        def totalCount = mongoCursor.count()
//        RestTimeProcess rtp = new RestTimeProcess(totalCount, EpoInfoImporter.class.name)
        
        mongoCursor.each { doc -> 
            
            Date openDate = doc.doDate
            def stat = doc.stat
            def rawId = doc._id
            try {
//            println rawId
                def docMap = InfoDocUtil.generateInfoDoc(doc)
//                docMap = MiscUtil.removeMapNullValue(docMap)
                infoCol.save(docMap)
//                rtp.process(openDate)
            }  catch (e) {
                GenerateInfoDoc.writeError(errorInfoCol, stat, e.toString(), openDate, rawId)
                if (mongoCursor.hasNext()) {
                    return true
                }
            }
        }
        
    } //end infoProcess
    
    static main(args) {
        new EpoInfoImporter().infoProcess()
        log.info "info finish!!"
    }

}
