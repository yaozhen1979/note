package com.patent.importer.rawdata

import groovy.io.FileType
import org.jsoup.Jsoup
import org.jsoup.select.Elements
import com.patent.common.Constants
import com.patent.service.BaseProcess
import com.patent.service.RawDataProcess;
import com.patent.utils.DateUtil
import com.patent.utils.MongoUtil
import com.patent.utils.DataStorageUtil
import com.patent.utils.MiscUtil

class EpoRawImporter extends BaseProcess {
    
    def cli(args) {
        def cli = new CliBuilder(usage: 'EpoRawImporter.groovy -[hipsua]')
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            i longOpt: 'mongo-ip', args: 1, argName: 'xxx.xxx.xxx.xxx', 'mongo ip'
            p longOpt: 'mongo-port',   args: 1, 'mongo port'
            s longOpt: 'source-path', args: 1, 'which folder inculde year folder, like X:/sample'
            u longOpt: 'user-name', args: 1, 'user name'
            a longOpt: 'password', args: 1, 'user password'
            d longOpt: 'auth-db', args: 1, 'user authentication database'
        }
        def options = cli.parse(args)
        if (!options) {
            return
        }
        if (options.h) {
            cli.usage()
            return
        }
        return options;
    }
    
    def epoRawProcess(String processFolderPath){

        def dbClient = MongoUtil.connect2X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def db = dbClient.getDB(Constants.MONGODB_RAWDB)
//        def dbClient = MongoUtil.connect2X('ericxiao', 'mon2jiy567', '127.0.0.1', 27017, 'admin')
//        def db = dbClient.getDB('test')
        def errorPatentRawEPO = db.getCollection("errorPatentRawEPO")
        def patentRawEpo = db.getCollection("patentRawEPO")

        new File(processFolderPath).eachFileRecurse(FileType.FILES) { file ->

            def path = file.getParent().replace('\\', '/').replace(processFolderPath, '')

            def epoRawDoc = patentRawEpo.findOne([path: path])

            def docMap = [:]
            // insert {tag: {file:xxx.groovy,version:v.1.0}}
            // insert {monSycFlag : {init: date,last:date}}

            def stat = path.find(~/\/\d?\//).replace('/','')
            if (!!epoRawDoc) {
                docMap = epoRawDoc
            } else {
                docMap << ['stat':stat]
                docMap << ['pto':'EPO']
                docMap << ['type' : Constants.XML_FILE_TYPE]
                docMap << ['provider': Constants.FILE_PROVIDER]
                docMap << ['path' : path]
                docMap << ['_id' : path.toString()]
                docMap << [tag : [file : 'EpoRawImporter.groovy' , version : 'v1.0']]
            }
            docMap << MiscUtil.getMongoSyncFlag(epoRawDoc)
            // generateRaw
            def fileName = file.name
            try {
                def root = RawDataProcess.fetchXmlRoot(fileName, file)
                docMap = RawDataProcess.xmlToRaw(fileName, root, file, docMap)

                if (docMap.biblioFlag) {
                    if (docMap.claimsDocNumber == docMap.descriptionDocNumber) {
                        patentRawEpo.save(docMap)
                    } else if (docMap.biblioDocNumber == docMap.claimsDocNumber  && !docMap.descriptionDocNumber) {
                        patentRawEpo.save(docMap)
                        //                println "docMap = ${docMap}2222"
                    } else if (docMap.biblioDocNumber == docMap.descriptionDocNumber && !docMap.claimsDocNumber) {
                        patentRawEpo.save(docMap)
                    } else {
                        throw new Exception ('Number is different')
                    }
                } else {
                    throw new Exception ('biblio xml error')
                }
            } catch (e) {
                ErrorEpoRawImporter.saveRawDataError(errorPatentRawEPO, path, fileName, e.toString())
            }

            //            println "docMap = ${docMap}"
        }  // new File(processFolderPath)

    }

    def epoRawProcess(String processFolderPath, String userName, String password, String ip, int port, String authDB){
        
                def dbClient = MongoUtil.connect2X(userName, password, ip, port, authDB)
                def db = dbClient.getDB(Constants.MONGODB_RAWDB)
        //        def dbClient = MongoUtil.connect2X('ericxiao', 'mon2jiy567', '127.0.0.1', 27017, 'admin')
        //        def db = dbClient.getDB('test')
                def errorPatentRawEPO = db.getCollection("errorPatentRawEPO")
                def patentRawEpo = db.getCollection("patentRawEPO")
        
                new File(processFolderPath).eachFileRecurse(FileType.FILES) { file ->
        
                    def path = file.getParent().replace('\\', '/').replace(processFolderPath, '')
        
                    def epoRawDoc = patentRawEpo.findOne([path: path])
        
                    def docMap = [:]
                    // insert {tag: {file:xxx.groovy,version:v.1.0}}
                    // insert {monSycFlag : {init: date,last:date}}
        
                    def stat = path.find(~/\/\d?\//).replace('/','')
                    if (!!epoRawDoc) {
                        docMap = epoRawDoc
                    } else {
                        docMap << ['stat':stat]
                        docMap << ['pto':'EPO']
                        docMap << ['type' : Constants.XML_FILE_TYPE]
                        docMap << ['provider': Constants.FILE_PROVIDER]
                        docMap << ['path' : path]
                        docMap << ['_id' : path.toString()]
                        docMap << [tag : [file : 'EpoRawImporter.groovy' , version : 'v1.0']]
                    }
                    docMap << MiscUtil.getMongoSyncFlag(epoRawDoc)
                    // generateRaw
                    def fileName = file.name
                    try {
                        def root = RawDataProcess.fetchXmlRoot(fileName, file)
                        docMap = RawDataProcess.xmlToRaw(fileName, root, file, docMap)
        
                        if (docMap.biblioFlag) {
                            if (docMap.claimsDocNumber == docMap.descriptionDocNumber) {
                                patentRawEpo.save(docMap)
                            } else if (docMap.biblioDocNumber == docMap.claimsDocNumber  && !docMap.descriptionDocNumber) {
                                patentRawEpo.save(docMap)
                                //                println "docMap = ${docMap}2222"
                            } else if (docMap.biblioDocNumber == docMap.descriptionDocNumber && !docMap.claimsDocNumber) {
                                patentRawEpo.save(docMap)
                            } else {
                                throw new Exception ('Number is different')
                            }
                        } else {
                            throw new Exception ('biblio xml error')
                        }
                    } catch (e) {
                        ErrorEpoRawImporter.saveRawDataError(errorPatentRawEPO, path, fileName, e.toString())
                    }
        
                    //            println "docMap = ${docMap}"
                }  // new File(processFolderPath)
        
            }
    
    static main(args) {
        def options = new EpoRawImporter().cli(args)
        def ip = options.i;
        def port = options.p;
        def folderPath = options.s;
        def name = options.u;
        def password = options.a;
        def authDB = options.d;
//        args = ["-i", "127.0.0.1", "-p", "27017", "-s", "t:/lost correct"]
        if (!!name) {
            new EpoRawImporter().epoRawProcess(folderPath, name, password, ip, port.toInteger(), authDB)
            println "${ip} import raw data done"
        } else {
            new EpoRawImporter().epoRawProcess(folderPath)
            println 'local patentRawEPO done'
        }
        
    }

}