package com.patent.utils

import java.nio.file.Files
import patentdata.utils.CDataProcess
import com.mongodb.BasicDBObject
import com.mongodb.DBObject
import com.patent.epo.model.EPOMarshalDocument
import com.patent.utils.DataStorageUtil
import com.patent.utils.XmlUtils

/**
 * 
 * @author ericxiao
 *
 */
public class MarshallDocUtil {
    
    private static CDataProcess biblioCData = new CDataProcess('/ops:world-patent-data/exchange-documents/exchange-document/bibliographic-data/invention-title','/ops:world-patent-data/exchange-documents/exchange-document/abstract')
    private static CDataProcess claimsCData = new CDataProcess('/ops:world-patent-data/ftxt:fulltext-documents/ftxt:fulltext-document/claims')
    private static CDataProcess descriptionCData = new CDataProcess('/ops:world-patent-data/ftxt:fulltext-documents/ftxt:fulltext-document/description')
    
    /**
     * 
     * @param rawDoc
     * @return
     */
    static EPOMarshalDocument createMarshallDocument(DBObject rawDoc) {
        
        EPOMarshalDocument doc = new EPOMarshalDocument()
        
        doc.setDoDate(rawDoc.doDate)
        doc.setPath(rawDoc.path)
        doc.setBiblio(rawDoc.data.biblio)
        doc.setDocNo(rawDoc.biblioDocNumber)
        if (!!rawDoc.data.claims) {
            doc.setClaims(rawDoc.data.claims)
        }  
        if (!!rawDoc.data.description) {
            doc.setDescription(rawDoc.data.description)
        }
        return doc
    }
    
    static BasicDBObject generateMarshallData(EPOMarshalDocument doc, DBObject rawDoc, DBObject biblioObject, DBObject claimsObject, DBObject descriptionObject) {
        
        def marshallData = [:]
        marshallData << ['doDate':doc.doDate]
        def data = DataStorageUtil.tempDataStorage(marshallData)
        data << ['biblio':biblioObject]
        
        if (!!claimsObject) {
            data << ['claims':claimsObject]
        }
        if (!!descriptionObject) {
            data << ['description':descriptionObject]
        }
        marshallData << ['stat':rawDoc.stat.toInteger()]
        marshallData << ['relId':['_id':rawDoc._id]]
        marshallData << ['pto':rawDoc.pto]
        marshallData << ['provider':rawDoc.provider]
        marshallData << ['mongoSyncFlag' : ['init':new Date(), 'last':new Date()]]
        marshallData << ['tag':[file : 'EpoMarshallImporter.groovy' , version : 'v1.0']]
        marshallData << ['data':data]
//        println marshallData.toString()
        return new BasicDBObject(marshallData)
    }
    
    static String cdataProcess (def xmlString, def xmlName) {
        
        if (xmlName == "biblio") {
            def biblioCData = biblioCData.transfer(xmlString)
            return biblioCData
        }
        if (xmlName == "claims") {
            def claimsCData = claimsCData.transfer(xmlString)
            return claimsCData
        }
        if (xmlName == "description") {
            def descriptionCData = descriptionCData.transfer(xmlString)
            return descriptionCData
        }
    }
    //parse cdataed claim to json object
    static DBObject parseClaimsText(String cDataString, def jsonObject) {
        def xmlRoot = getXmlRoot(cDataString, 'claims')
        def claimsString = xmlRoot.'claims'.text()
        jsonObject.'world-patent-data'.'fulltext-documents'.'fulltext-document'.'0'.'claims' = claimsString
        return jsonObject
    }
    //parse cdataed description to json object
    static DBObject parseDescriptionText(String cDataString, def jsonObject) {
        def xmlRoot = getXmlRoot(cDataString, 'description')
        def descriptionString = xmlRoot.'description'.text()
        jsonObject.'world-patent-data'.'fulltext-documents'.'fulltext-document'.'0'.'description' = descriptionString
        return jsonObject
    }
    //parse cdataed invention title to json object
    static DBObject parseInventionTitleText(String cDataString, def jsonObject) {
        def xmlRoot = getXmlRoot(cDataString, 'biblio')
//            def langKeyString = takeString("${langKey}")
        def inventionTitle = xmlRoot.'bibliographic-data'.'invention-title'.text()
        jsonObject.'world-patent-data'.'exchange-documents'.'exchange-document'.'0'.'bibliographic-data'.'invention-title' = inventionTitle
        return jsonObject
    }
    //parse cdataed abstract to json object
    static DBObject parseAbstractText (String cDataString, def jsonObject) {
        def xmlRoot = getXmlRoot(cDataString, 'biblio')
        def abstractMap = [:]
        if (!!xmlRoot.'abstract') {
            def abstractString = xmlRoot.'abstract'.text()
            jsonObject.'world-patent-data'.'exchange-documents'.'exchange-document'.'0'.'abstract' = abstractString
            return jsonObject
        }
        return jsonObject
    }
    
    static getXmlRoot (def xmlString, def xmlName) {
        XmlParser xmlParse = new XmlParser()
        def root = null
        if (xmlName == 'biblio') {
            def tempRoot = xmlParse.parseText(xmlString)
            root = tempRoot.'exchange-documents'.'exchange-document'
            return root
        }
        if (xmlName == 'claims' || xmlName == 'description') {
            def tempRoot = xmlParse.parseText(xmlString)
            root = tempRoot.'ftxt:fulltext-documents'.'ftxt:fulltext-document'
            return root
        }
    }
    
    static void main (args) {
        def filePath = new File('sample_data/1979/1/19790124_1/EP0000337A1/biblio.xml').toPath()
        def xmlName = filePath.fileName.toString().replace('.xml', '')
        def xmlString = new String(Files.readAllBytes(filePath)).trim()
        def jsonString = XmlUtils.xmlToJsonString(xmlString)
        def xmlCDataString = cdataProcess(xmlString, xmlName)
        def jsonObject = XmlUtils.stringToJsonObject(jsonString)
        println parseInventionTitleText(xmlCDataString, jsonObject)
//        println getXmlRoot(cDataXml, xmlName).'description'.toString()
//        println cdataProcess(xmlString, xmlName)
    }
}
