package com.patent.utils

import static java.nio.file.Files.readAllBytes
import static java.nio.file.Paths.get

import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.StringWriter
import java.util.HashMap
import java.util.Map

import javax.xml.XMLConstants
import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.apache.commons.io.input.BOMInputStream
import org.apache.commons.io.ByteOrderMark
import org.apache.commons.io.IOUtils
import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;

import com.patent.jaxb.ops.WorldPatentData
import com.patent.common.Constants
import com.patent.epo.model.EPOMarshalDocument;

import groovy.json.JsonSlurper

/**
 * 
 * @author tonykuo
 *
 */
class XmlUtil {
    
    private static boolean inited
    private static Unmarshaller unmarshaller
    private static Marshaller marshaller
    
    /**
     * verify xml data
     *
     * @throws Exception
     */
    private static void jaxbInit() throws Exception {
        if (inited) {
            return
        }
        
        JAXBContext jc = JAXBContext.newInstance("com.patent.jaxb.ops")
        unmarshaller = jc.createUnmarshaller()

        Map<String, Object> props = new HashMap<>()
        
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false)
        props.put(JAXBContextProperties.MEDIA_TYPE,MediaType.APPLICATION_JSON)

        JAXBContext jc1 = JAXBContext.newInstance("com.patent.jaxb.ops",
                WorldPatentData.class.getClassLoader(), props)
        
        marshaller = jc1.createMarshaller()
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json")
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)

        inited = true
    }
    
    /**
     * 
     * @param filePath
     * @return
     */
    static String xml2jsonStr(String xmlStr) {
        jaxbInit()
        
        InputStream xmlStream = new ByteArrayInputStream(xmlStr.getBytes(Constants.LANG_ENCODING))
        
        Object elem = unmarshaller.unmarshal(xmlStream)
        StringWriter sw = new StringWriter()
        marshaller.marshal(elem, sw)
        
        return sw.toString()
        
    }
    
    /**
     * 
     * @param file
     * @return
     */
    static String xml2jsonStr(File file) {
        
        jaxbInit()
        
        Object elem = unmarshaller.unmarshal(file)
        StringWriter sw = new StringWriter()
        marshaller.marshal(elem, sw)
        
        return sw.toString()
    }
    
    /**
     * 
     * @param xmlStr
     * @return
     */
    static def xml2Object(String xmlStr) {
        InputStream is = new ByteArrayInputStream(xmlStr.getBytes(Constants.LANG_ENCODING));
        BOMInputStream bomIn = new BOMInputStream(is, false, ByteOrderMark.UTF_8);
        if (bomIn.hasBOM()) {
            xmlStr = IOUtils.toString(bomIn, Constants.LANG_ENCODING);
        }
        is.close()
        return new XmlParser().parseText(xmlStr)
    }
    
    
    /**
     * 靘��喳��銵�銝� �瑁�trim().
     */
    private def static trimStr = { String text ->
        
        def trimStr = ""
        
        text.eachLine { line ->
            def lineStr = line.toString()
            trimStr += lineStr.trim()
        }
        
        return trimStr
    }
    
    /**
     * 
     * @param jsonStr
     * @return
     */
    static def toJsonObject(String jsonStr) {
        return new JsonSlurper().parseText(jsonStr)
    }
    
    /**
     * 
     * @param inputStream
     * @return
     * @throws IOException
     */
    static InputStream checkForUtf8BOM(InputStream inputStream) throws IOException {
        PushbackInputStream pushbackInputStream = new PushbackInputStream(new BufferedInputStream(inputStream), 3)
        byte[] bom = new byte[3]
        if (pushbackInputStream.read(bom) != -1) {
            if (!(bom[0] == (byte) 0xEF && bom[1] == (byte) 0xBB && bom[2] == (byte) 0xBF)) {
                pushbackInputStream.unread(bom)
            }
        }
        return pushbackInputStream
    }
    static generateEPOJsonObject (def xml) {
        def jsonString = xml2jsonStr(xml)
        def jsonObject = toJsonObject(jsonString)
        
        
    }
    /**
     * 
     * @param arg
     * @return
     */
    static String toHex(String arg) {
        return String.format("%040x", new BigInteger(1, arg.getBytes("UTF-8")))
    }
    
    static String xmlExists2JsonString (def xmlString, EPOMarshalDocument doc) {
        if (!!xmlString) {
            
        }
    }
    
    /**
     * 
     * @param args
     */
    static main(args) {
        def filePath = 'sample_data/1979/1/19790124_1/EP0000337A1/biblio.xml'
        def xmlFile = new File(filePath)
        def jsonString = xml2jsonStr(xmlFile)
        def jsonObject = toJsonObject(jsonString)
        println jsonString
        println "finished..."
    }

}
