package com.patent.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {

    public static Properties load(String fileName) {

        Properties prop = new Properties();
        InputStream input = null;

        try {
            input = new FileInputStream(new File(fileName));
            // load a properties file
            prop.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return prop;
    }
    
    public static void main(String[] args) {
        Properties properties = PropertiesUtil.load("src/main/resources/config.properties");
        System.out.println(properties.getProperty("user_mail"));
    }
    
}
