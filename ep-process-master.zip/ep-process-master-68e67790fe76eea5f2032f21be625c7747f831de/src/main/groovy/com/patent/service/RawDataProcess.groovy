package com.patent.service

import java.io.File

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

import com.patent.service.BaseProcess
import com.patent.utils.DataStorageUtil
import com.patent.utils.DateUtil;;

/**
 * 設定存入[PatentMarshallCN]的資料內容
 * 
 * @author tonykuo
 *
 */
class RawDataProcess extends BaseProcess {
    
    /**
     * 
     * @return
     */
    static fetchXmlRoot(String fileName , File item) {

        def jsoupParser = Jsoup.parse(item,"UTF-8")
        def errorFlag = jsoupParser.getElementsByTag('error')
        def root

        if (!!errorFlag) {
            throw new Exception('xml with no content!')
        } else {
            if (fileName == 'biblio.xml') {
                root = jsoupParser.select('exchange-documents > exchange-document[system] > bibliographic-data')
                //                println root
                if (!!root) {
                    return root
                } else {
                    throw new Exception('no biblio root')
                }

            } else if (fileName == 'claims.xml' || fileName == 'description.xml' ) {
                //                        println root
                root =  jsoupParser.select('[xmlns = http://www.epo.org/fulltext] > [system = ops.epo.org]')
                if (!!root) {

                    return root
                } else {
                    throw new Exception('no claims root or description root')
                }

            } else {
                throw new Exception('you have wrong file name!')
            }
        }
    }

    static xmlToRaw(String fileName, Elements root, File item, def docMap){

        def data = DataStorageUtil.tempDataStorage(docMap)
        
        if (fileName == 'biblio.xml') {
            data << [biblio : item.getText('UTF-8')]
            def dateStr = root.select('publication-reference > document-id[document-id-type = epodoc] > date').text()
            Date doDate = DateUtil.parseDate(dateStr)
            docMap << [doDate : doDate]
            if (!!docMap.doDate) {
                
            } else {
                throw new Exception('doDate is null')
            }
            docMap << [biblioFlag : true]
            def biblioDocNumber = root.select('publication-reference > document-id[document-id-type = docdb] > doc-number').text()
            // patentNumber
            docMap << [biblioDocNumber:biblioDocNumber]


        } else if (fileName == 'claims.xml') {
            data << [claims : item.getText('UTF-8')]
            //
            def claimsDocNumber = root.select('bibliographic-data > publication-reference[data-format = docdb] > document-id > doc-number').text()
            docMap << [claimsDocNumber : claimsDocNumber]

        } else if (fileName == 'description.xml' ) {
            //
            data << [description : item.getText('UTF-8')]
            def descriptionDocNumber = root.select('bibliographic-data > publication-reference[data-format = docdb] > document-id > doc-number').text()
            docMap << [descriptionDocNumber : descriptionDocNumber]

        } else {
            throw new Exception("wrong ${fileName}")
        }

        docMap << ["data": data]

        return docMap
    }
}
