package com.patent.validtion

import java.io.File;
import java.io.IOException;

import groovy.io.FileType

import javax.xml.XMLConstants
import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBException
import javax.xml.bind.Unmarshaller
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.ParserConfigurationException
import javax.xml.transform.Source
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.SchemaFactoryLoader;
import javax.xml.validation.Validator
import org.w3c.dom.Document
import org.xml.sax.SAXException
import com.patent.common.Constants;
import com.patent.utils.XmlUtil;

class XmlValidtion {
    
    private static boolean inited = false
    private static Unmarshaller unmarshaller
    
    private static void Init() throws JAXBException, SAXException {
        
        if (inited) {
            return
        }
//        SchemaFactory schemaFactory = SchemaFactoryLoader.newFactory(XMLConstants.W3C_XML_SCHEMA_NS_URI)
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
        File schemaLocation = new File("xsd/ops.xsd")
        Schema schema = schemaFactory.newSchema(schemaLocation)
        
        JAXBContext jaxbContext = JAXBContext.newInstance("com.patent.jaxb.ops")
        unmarshaller = jaxbContext.createUnmarshaller()
        unmarshaller.setSchema(schema)
        inited = true
    }
    
//    public static boolean isValidate(String xml) throws SAXException, IOException,
//        ParserConfigurationException {
//    
//        DocumentBuilder documentBuilder = null;
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        dbf.setValidating(false);
//        dbf.setNamespaceAware(true);
//        documentBuilder = dbf.newDocumentBuilder();
//    
//        InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
//        Document doc = documentBuilder.parse(is);
//    
//        SchemaFactory factory = SchemaFactory
//                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
//    
//        // factory.setResourceResolver(new DocdbEntityResolver())
//        
//        String xsdPath = "xsd/ops.xsd"
//        File schemaLocation = new File(xsdPath);
//                
//        Schema schema = factory.newSchema(schemaLocation);
//    
//        Validator validator = schema.newValidator();
//    
//        validator.validate(new DOMSource(doc));
//    
//        return true
//    }
//    public boolean isValidate(File file) throws SAXException, IOException,
//    ParserConfigurationException {
//
//        SchemaFactory factory = SchemaFactory
//                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
//
//        File schemaLocation = new File("xsd/ops.xsd");
//        Schema schema = factory.newSchema(schemaLocation);
//
//        def fileText = file.getText(Constants.LANG_ENCODING)
//        // println fileText
//
//        InputStream is = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
//        def source = new StreamSource(is);
//
//        Validator validator = schema.newValidator();
//        validator.validate(source);
//
//        return true
//    }
    
    public static boolean isValid(File file) throws JAXBException,SAXException {
        
        Init()
        
        unmarshaller.unmarshal(file)
        
        return true
    }
    

    static main(args) {
        
        println "to start"
        def filePath = 'sample_data'
        def parentPath
        def xml
        
        new File(filePath).eachFileRecurse(FileType.FILES) { file ->
            
            parentPath = file.getAbsolutePath().toString()
            
            if (new XmlValidtion().isValid(file)) {
                
                println "${parentPath}\tGood"
            } 
            
        }
        
        println "finished..."
    }

}
