package com.patent.epo.model;

import java.util.Date;

public class EPOMarshalDocument {
    
    private String path;
    private Date doDate;
    private String biblio;
    private String claims;
    private String description;
    private String jsonStr;
    private String docNo;
    private String descriptionJsonString;
    private String claimsJsonString;
    private String biblioJsonString;
    
    public String getDescriptionJsonString() {
        return descriptionJsonString;
    }
    public void setDescriptionJsonString(String descriptionJsonString) {
        this.descriptionJsonString = descriptionJsonString;
    }
    public String getClaimsJsonString() {
        return claimsJsonString;
    }
    public void setClaimsJsonString(String claimsJsonString) {
        this.claimsJsonString = claimsJsonString;
    }
    public String getBiblioJsonString() {
        return biblioJsonString;
    }
    public void setBiblioJsonString(String biblioJsonString) {
        this.biblioJsonString = biblioJsonString;
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }
    public Date getDoDate() {
        return doDate;
    }
    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }
    public String getBiblio() {
        return biblio;
    }
    public void setBiblio(String biblio) {
        this.biblio = biblio;
    }
    public String getClaims() {
        return claims;
    }
    public void setClaims(String claims) {
        this.claims = claims;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getJsonStr() {
        return jsonStr;
    }
    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }
    public String getDocNo() {
        return docNo;
    }
    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }
    
}
