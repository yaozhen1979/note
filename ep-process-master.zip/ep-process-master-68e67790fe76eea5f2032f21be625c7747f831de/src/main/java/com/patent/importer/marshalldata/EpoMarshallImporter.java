package com.patent.importer.marshalldata;

import java.util.Date;
import java.util.HashMap;

import com.gmongo.GMongoClient;
import com.mongodb.BasicDBObject;
import com.mongodb.Bytes;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.patent.common.Constants;
import com.patent.epo.model.EPOMarshalDocument;
import com.patent.service.BaseProcess;
import com.patent.utils.MarshallDocUtil;
import com.patent.utils.MongoUtil;
import com.patent.utils.XmlUtils;
import com.patent.valid.EpoXmlValidate;

public class EpoMarshallImporter extends BaseProcess {
    private GMongoClient dbClient = MongoUtil.connect2X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT,
            "admin");
    private DB rawDB = dbClient.getDB(Constants.MONGODB_RAWDB);
    private DB marshallDB = dbClient.getDB(Constants.MONGODB_MARSHALLDB);
    private DBCollection epoRawCollection = rawDB.getCollection("patentRawEPO");
    private DBCollection epoMarshallCollection = marshallDB.getCollection("patentMarshallEPO");
    private DBCollection errorEpoMarshallCollection = marshallDB.getCollection("errorPatentMarshallEPO");

    // private DB testDB = dbClient.getDB("test");
    // private DBCollection epoRawCollection =
    // testDB.getCollection("patentRawEPO");
    // private DBCollection epoMarshallCollection =
    // testDB.getCollection("patentMarshallEPO");
    // private DBCollection errorEpoMarshallCollection =
    // testDB.getCollection("errorPatentMarshallEPO");
    private BasicDBObject query = new BasicDBObject("provider", Constants.FILE_PROVIDER);

    public void marshallProcess() {
        DBCursor dbCursor = epoRawCollection.find(query).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
        while (dbCursor.hasNext()) {
            try {
                DBObject rawDoc = dbCursor.next();

                // System.out.println( "raw id : " + rawDoc.get("_id"));

                EPOMarshalDocument doc;
                // 將rawdata 轉入EPOMarshalDocument class
                try {
                    doc = MarshallDocUtil.createMarshallDocument(rawDoc);
                    // System.out.println(doc.getPath());
                } catch (Exception e) {
                    System.out.println("generate jaxb properties error : ${e}");
                    writeError(errorEpoMarshallCollection, "generate jaxb properties error", e.toString(),
                            rawDoc.get("doDate"), rawDoc.get("_id"));
                    //
                    continue;
                }

                // valid xml with xsd
                try {
                    EpoXmlValidate.isValidate(doc.getBiblio());
                } catch (Exception e) {
                    System.out.println(e.toString());
                    writeError(errorEpoMarshallCollection, "xml biblio validate error", e.toString(),
                            rawDoc.get("doDate"), rawDoc.get("_id"));

                    break;
                }

                if (doc.getClaims() != null) {
                    try {
                        EpoXmlValidate.isValidate(doc.getClaims());
                    } catch (Exception e) {
                        writeError(errorEpoMarshallCollection, "xml claims validate error", e.toString(),
                                rawDoc.get("doDate"), rawDoc.get("_id"));

                        break;
                    }
                }

                if (doc.getDescription() != null) {
                    try {
                        EpoXmlValidate.isValidate(doc.getDescription());
                    } catch (Exception e) {
                        writeError(errorEpoMarshallCollection, "xml description validate error", e.toString(),
                                rawDoc.get("doDate"), rawDoc.get("_id"));

                        break;
                    }
                }

                // jaxb convert xml to json string
                try {
                    doc.setBiblioJsonString(XmlUtils.xmlToJsonString(doc.getBiblio()));
                    // System.out.println(doc.getBiblioJsonString());
                    if (doc.getClaims() != null) {
                        doc.setClaimsJsonString(XmlUtils.xmlToJsonString(doc.getClaims()));
                    }

                    if (doc.getDescription() != null) {
                        doc.setDescriptionJsonString(XmlUtils.xmlToJsonString(doc.getDescription()));
                    }

                } catch (Exception e) {
                    System.out.println("jaxb xml to json error => raw id: " + rawDoc.get("_id"));
                    writeError(errorEpoMarshallCollection, "jaxb xml to json error", e.toString(), rawDoc.get("doDate"),
                            rawDoc.get("_id"));

                    continue;
                }

                // jsoup convert json string to json object
                DBObject biblioObject = null;
                DBObject claimsObject = null;
                DBObject descriptionObject = null;
                DBObject originBiblioObject;
                DBObject originClaimsObject;
                DBObject originDescriptionObject;
                try {
                    originBiblioObject = XmlUtils.stringToJsonObject(doc.getBiblioJsonString());
                    biblioObject = XmlUtils.gernerateBiblioJsonObject(originBiblioObject, doc);

                    if (doc.getClaimsJsonString() != null) {
                        originClaimsObject = XmlUtils.stringToJsonObject(doc.getClaimsJsonString());
                        claimsObject = XmlUtils.gernerateClaimsJsonObject(originClaimsObject, doc);
                    }

                    if (doc.getDescriptionJsonString() != null) {
                        originDescriptionObject = XmlUtils.stringToJsonObject(doc.getDescriptionJsonString());
                        descriptionObject = XmlUtils.gernerateDescriptionJsonObject(originDescriptionObject, doc);
                    }
                } catch (Exception e) {
                    System.out.println(e.toString());
                    System.out.println("json string to json object error : " + rawDoc.get("_id"));
                    writeError(errorEpoMarshallCollection, "jsoup json string to json object error", e.toString(),
                            rawDoc.get("doDate"), rawDoc.get("_id"));
                    continue;
                }

                // gereate marshall doc to insert mongodb
                BasicDBObject marshallDoc = null;
                try {
                    marshallDoc = MarshallDocUtil.generateMarshallData(doc, rawDoc, biblioObject, claimsObject,
                            descriptionObject);
                } catch (Exception e) {
                    writeError(errorEpoMarshallCollection, "generateMarshallData error", e.toString(),
                            rawDoc.get("doDate"), rawDoc.get("_id"));
                    //
                    continue;
                }

                // marshallCol.insert(marshallDoc,
                // com.mongodb.WriteConcern.ACKNOWLEDGED)
                // System.out.println(marshallDoc.toString());
                epoMarshallCollection.save(marshallDoc);
                // System.out.println(marshallDoc);
                // println marshallDoc
                // rtp.process(rawDoc.doDate)

            } catch (Exception e) {
                System.out.println(e.toString());
                throw e;
            }

        }
    }

    // write error to errorPatentMarshallEPO
    private static void writeError(DBCollection errorCol, String errorPurpose, String errorString, Object doDate,
            Object id) {
        DBObject query = new BasicDBObject("rawid", id);
        DBObject oneResult = errorCol.findOne(query);
        HashMap<String, Object> map = new HashMap<String, Object>();
        BasicDBObject mongoSyncMap = new BasicDBObject();

        if (oneResult != null) {
            map.put("errorPurpose", errorPurpose);
            map.put("errorMsg", errorString);
            map.put("_id", oneResult.get("_id"));

            mongoSyncMap = (BasicDBObject) oneResult.get("mongoSyncFlag");
            mongoSyncMap.put("init", mongoSyncMap.get("init"));
            mongoSyncMap.put("last", new Date());

            map.put("mongoSyncFlag", mongoSyncMap);
        } else {
            map.put("errorPurpose", errorPurpose);
            map.put("errorMsg", errorString);
            map.put("rawDoDate", doDate);
            map.put("rawId", id);
            map.put("provider", "EPO OPS");
            mongoSyncMap.put("init", new Date());
            mongoSyncMap.put("last", new Date());

            map.put("mongoSyncFlag", mongoSyncMap);
        }

        DBObject error = new BasicDBObject(map);
        errorCol.save(error);
    }

    public static void main(String[] args) {
        new EpoMarshallImporter().marshallProcess();
        System.out.println("done");

    }

}
