package com.patent.common;

public class Constants {
    
    public static final String XML_FILE_TYPE = "xml/xml";
    public static final String FILE_PROVIDER = "EPO_OPS";
    public static final String LANG_ENCODING = "UTF-8";
    public static final String MONGODB_MARSHALLDB = "patentMarshallEPO";
    public static final String MONGODB_RAWDB = "patentRawEPO";
    public static final String MONGODB_INFODB = "patentInfoEPO";
    private Constants() {}
    
}
