package org.patentdata.web;

import java.util.Date;
import java.util.Map;

import org.patentdata.service.SipoService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * for SIPO Data process
 * 
 * @author tonykuo
 *
 */
@Controller
public class SipoController {
    
    @RequestMapping("/sipo")
    public String welcome(Map<String, Object> model) {
        
        model.put("time", new Date());
        model.put("message", "sipo check");
        
//        // SipoService sipoService = new SipoService();
//        // Object countData = sipoService.queryMongoDBCount("CN", null, "FM");
//        Object countData = null;
//        if (countData != null) {
//            model.put("showData", true);
//            model.put("count", "");
//        } else {
//            model.put("showData", false);
//        }
        
        return "welcome";
    }
    
    // TODO: query 
    @RequestMapping("/sipo/query/{patentType}")
    public String querySipoData(Map<String, Object> model, @PathVariable String patentType) {
        
        model.put("time", new Date());
        model.put("message", "sipo check");
        
        SipoService sipoService = new SipoService();
        Object countData = sipoService.queryMongoDBCount("CN", null, patentType);
        // Object countData = null;
        if (countData != null) {
            model.put("showData", true);
            model.put("count", countData);
        } else {
            model.put("showData", false);
        }
        
        return "welcome";
    }
    
}
