package org.patentdata.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gmongo.GMongoClient;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class MongoUtil {
    
    private static Logger logger = LoggerFactory.getLogger(MongoUtil.class);
    
    /**
     * 
     * @param userId
     * @param userPwd
     * @param ip
     * @param port
     * @return
     */
    public static GMongoClient connect3X(String userId, String userPwd, String ip, int port) {
        
        /*
         * https://api.mongodb.org/java/2.13/com/mongodb/MongoClientOptions.html
         * https://api.mongodb.org/java/2.13/com/mongodb/MongoClientOptions.Builder.html
         */
        MongoClientOptions options = MongoClientOptions.builder()
            .connectionsPerHost(20)
            .alwaysUseMBeans(true)
            .writeConcern(com.mongodb.WriteConcern.ACKNOWLEDGED)
            // .autoConnectRetry(true)
            .build();
        
        MongoCredential auth = MongoCredential.createCredential(userId, "admin", userPwd.toCharArray());
        List<MongoCredential> authList = new ArrayList<MongoCredential>();
        authList.add(auth);
        GMongoClient client = new GMongoClient(new ServerAddress(ip, port), authList, options);
        return client;
    }
    
    /**
     * 
     * @param userId
     * @param userPwd
     * @param ip
     * @param port
     * @return
     */
    public static GMongoClient connect2X(String userId, String userPwd, String ip, int port) {
        
        MongoCredential auth = MongoCredential.createMongoCRCredential(userId, "admin", userPwd.toCharArray());
        List<MongoCredential> authList = new ArrayList<MongoCredential>();
        authList.add(auth);
        GMongoClient client = new GMongoClient(new ServerAddress(ip, port), authList);
        
        return client;
    }
    
    /**
     * 
     * @return
     * @throws Exception 
     */
    public static GMongoClient connectByConfig(String country) throws Exception {
        
        logger.debug("country = " + country);
        if (country == null || country.trim().equals("")) {
            throw new Exception("country is empty");
        }
        
        Properties properties = PropertiesUtil.getProperties();
        String cc = country.toLowerCase().trim();
        String ip = properties.getProperty("mongodb." + cc + ".ip");
        int port = Integer.valueOf(properties.getProperty("mongodb." + cc + ".port"));
        String userId = properties.getProperty("mongodb." + cc + ".userId");
        String pwd = properties.getProperty("mongodb." + cc + ".pwd");

        return getGmongoClient(ip, port, userId, pwd);
        
    }
    
    /**
     * 
     * @return
     * @throws Exception
     */
    public static GMongoClient connect121DB() throws Exception {
        
        Properties properties = PropertiesUtil.getProperties();
        String ip = properties.getProperty("mongodb.121.ip");
        int port = Integer.valueOf(properties.getProperty("mongodb.121.port"));
        String userId = properties.getProperty("mongodb.121.userId");
        String pwd = properties.getProperty("mongodb.121.pwd");

        return getGmongoClient(ip, port, userId, pwd);
        
    }
    
    /**
     * 
     * @param ip
     * @param port
     * @param userId
     * @param pwd
     * @return
     * @throws Exception
     * @throws UnsupportedEncodingException
     */
    private static GMongoClient getGmongoClient(String ip, int port, String userId, String pwd)
            throws Exception, UnsupportedEncodingException {
            
        if (userId == null || userId.equals("")) {
            throw new Exception("please input mongo userId");
        }
        
        if (pwd == null || pwd.equals("")) {
            throw new Exception("please input mongo passwrd");
        }
        
        MongoClientOptions options = MongoClientOptions.builder()
            .connectionsPerHost(20)
            .alwaysUseMBeans(true)
            .writeConcern(com.mongodb.WriteConcern.ACKNOWLEDGED)
            // .autoConnectRetry(true)
            .build();
        
        MongoCredential auth = MongoCredential
            .createCredential(
                new String(Base64.decodeBase64(userId), "UTF-8"), 
                "admin", 
                new String(Base64.decodeBase64(pwd), "UTF-8").toCharArray());
        List<MongoCredential> authList = new ArrayList<MongoCredential>();
        authList.add(auth);
        
        return new GMongoClient(new ServerAddress(ip, port), authList, options);
    }
    
}