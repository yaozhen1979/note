package org.patentdata.service

import org.patentdata.util.DateUtil
import org.patentdata.util.MongoUtil
import org.patentdata.util.RestTimeProcess

import com.gmongo.GMongoClient
import com.mongodb.DB

public class SipoService {
    
    /**
     * 
     * 分別查詢Mongo DB中
     * 
     * PatentRawCN
     * PatentRawSIPO
     * PatentMarshallSIPO
     * 
     * 回傳格式為 
     * queryData = [
     *     [
     *         doDate:
     *         patentType:
     *         sipoCount:
     *         sipoRawCount
     *         sipoMarshallCount
     *     ]...
     * ]
     * 
     * 
     * @param country
     * @return
     */
    public def queryMongoDBCount(String country, String doDate = null, String type = null) {
        
        GMongoClient dbClient = MongoUtil.connectByConfig(country);
        DB patentRawCnDb = dbClient.getDB("PatentRawCN");
        DB patentRawSipoDb = dbClient.getDB("PatentRawSIPO");
        DB patentMarshallSipoDb = dbClient.getDB("PatentMarshallSIPO");
        
        def queryDataList = []
        
        if (!!doDate) {
            // TODO    
        } else {
           //
           def patentCountCn = patentRawCnDb.getCollection("PatentCountCN");
           def patentRawSipo = patentRawSipoDb.getCollection("PatentRawSIPO");
           def PatentMarshallSipo = patentMarshallSipoDb.getCollection("PatentMarshallSIPO")
           // 
           // def queryType = "FM"
           def queryType = type;
           
           int totalSize = patentCountCn.distinct("doDate", [type: queryType]).size();
           RestTimeProcess rtp = new RestTimeProcess(totalSize, "");
           //
           patentCountCn.distinct("doDate", [type: queryType]).each { it ->
               
               def dataMap = [:]
               //
               def queryPatentCountCn = patentCountCn.findOne([doDate: it, type: queryType])
               // println "PatentCountCN, doDate = ${it}, count = ${queryPatentCountCn.count}"
               dataMap << [doDate: DateUtil.toISODate(it, "yyyy-MM-dd")] 
               dataMap << [patentType: queryType]
               dataMap << [sipoCount: queryPatentCountCn.count]
               //
               def queryPatentRawSipo = patentRawSipo.find([doDate: it, patentType: queryType])
               // println "PatentRawSIPO, doDate = ${it}, count = ${queryPatentRawSipo.size()}"
               dataMap << [sipoRawCount: queryPatentRawSipo.size()]
               //
               def queryPatentMarshallSipo = PatentMarshallSipo.find([doDate: it, patentType: queryType])
               // println "PatentMarshallSIPO, doDate = ${it}, count = ${queryPatentMarshallSipo.size()}"
               dataMap << [sipoMarshallCount: queryPatentMarshallSipo.size()]
               
               queryDataList << dataMap
               
               rtp.process()
               
               // println "===================================================="
           }
           
        }
        
        // int count = queryData.count

        return queryDataList
    }
    
    static void main(args) {
        
        // db.PatentCountCN.distinct("doDate", {type:"FM"})
        
        println new SipoService().queryMongoDBCount("CN", null, "FM")
       
        
    }
    
}
