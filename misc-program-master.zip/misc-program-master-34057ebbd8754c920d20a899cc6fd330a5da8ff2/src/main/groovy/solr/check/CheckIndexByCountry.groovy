package solr.check
import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.121", 27017),
                    Arrays.asList(credential));

def pto = "USPTO"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")


def solrc = solr("*:*");
def countrys = solrc.facet_counts.facet_fields.country;
for (def i = 0; i < countrys.size(); i+=2) {
    println countrys[i] + ' > ' + countrys[i+1];
    def cnt = collection.count(new BasicDBObject(
        ["country" : countrys[i].toUpperCase()]))
    if (cnt != countrys[i+1]) {
        println "${cnt} NOT MATCH! ${cnt - countrys[i+1]}"
    }
}
println 'finished!'

def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
//    def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0&facet=true&facet.field=country").toURL().text
	def xml = ("http://10.60.90.172:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0&facet=true&facet.field=country").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
