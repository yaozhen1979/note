import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.122", 27017),
                    Arrays.asList(credential));

//USPTO 已盤查年份: 1976..2013  20150624
//CNIPR 已盤查年份: 1995..2011  20150616
//TIPO  已盤查年份: 1973..2015
//WIPO  已盤查年份: 
                
//def pto = "CNIPR"
//def pto = "USPTO"
//def pto = "TIPO"
//def pto = "WIPO"
def pto="JPO"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")

(1997..2002).each {
    def year = it
    def fromDate = new GregorianCalendar(year, Calendar.JANUARY, 1).time;
    def toDate = new GregorianCalendar(year + 1, Calendar.JANUARY, 1).time;
    //原本採用 lte, 但看起來無作用, 改用 lt
    long cnt = collection.count(new BasicDBObject(
        ["doDate" : BasicDBObjectBuilder.start('$gte', fromDate).add('$lt', toDate).get()]))
    //println cnt;
    
    def solrc = solr("doYear: ${year} AND pto:${pto}");
    def cnt2 = solrc.response.numFound
    println "${year} ${cnt} ${cnt2}" + (cnt == cnt2 ? "":" - NOT MATCH!!!");
}
    
def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
