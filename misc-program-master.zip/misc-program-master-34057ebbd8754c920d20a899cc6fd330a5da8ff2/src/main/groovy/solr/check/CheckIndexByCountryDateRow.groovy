import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                    Arrays.asList(credential));
                
def cc = "AT"
def pto = "DOCDB"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")

def year = 2005
def month = 11
def day = 15

def fromDate = new GregorianCalendar(year, month - 1, day).time;
def toDate = new GregorianCalendar(year, month - 1, day+1).time;
DBCursor cursor = collection.find(new BasicDBObject(
    ["doDate" : BasicDBObjectBuilder.start('$gte', fromDate).add('$lte', toDate).get(),
        "country": cc]))

while (cursor.hasNext()) {
    DBObject dbobj = cursor.next();
    def id = dbobj.get("_id").toString();

    def solrc = solr("id: \"${id}\" AND country:${cc}");
    if (solrc.response.numFound == 0) {
        println id;
    }
}
println 'finished!'

def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.36:8080/solr/docdb/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
