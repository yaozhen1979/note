import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.122", 27017),
                    Arrays.asList(credential));

//def pto = "USPTO"
def pto = "JPO"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")

def year = 2000
(0..11).each {
    def fromDate = new GregorianCalendar(year, it, 1).time;
    def toDate = new GregorianCalendar(year, it + 1, 1).time;
    long cnt = collection.count(new BasicDBObject(
        ["doDate" : BasicDBObjectBuilder.start('$gte', fromDate).add('$lte', toDate).get()]))
    
    def solrc = solr("doYearmon: ${year}${String.format('%02d', it+1)} AND pto:${pto}");
    def cnt2 = solrc.response.numFound
    println "${year} ${cnt} ${cnt2}" + (cnt == cnt2 ? "":" - NOT MATCH!!!");
}
    
def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
