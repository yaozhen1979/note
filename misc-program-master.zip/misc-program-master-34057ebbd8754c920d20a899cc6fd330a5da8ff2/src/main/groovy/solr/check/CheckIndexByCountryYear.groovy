import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                    Arrays.asList(credential));

def cc = "AT"
def pto = "DOCDB"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")

(1700..2016).each {
    def year = it
    def fromDate = new GregorianCalendar(year, Calendar.JANUARY, 1).time;
    def toDate = new GregorianCalendar(year + 1, Calendar.JANUARY, 1).time;
    //原本採用 lte, 但看起來無作用, 改用 lt
    long cnt = collection.count(new BasicDBObject(
        ["doDate" : BasicDBObjectBuilder.start('$gte', fromDate).add('$lt', toDate).get(),
            "country" : cc]))
    //println cnt;
    
    def solrc = solr("doYear: ${year} AND country:${cc}");
    def cnt2 = solrc.response.numFound
    println "${year} ${cnt} ${cnt2}" + (cnt == cnt2 ? "":" - NOT MATCH!!!");
}
    
def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.36:8080/solr/docdb/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
