import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//
MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.122", 27017),
                    Arrays.asList(credential));

//def pto = "USPTO"
def pto = "JPO"
def collection = mongoClient.getDB("PatentInfo${pto}").getCollection("PatentInfo${pto}")

def year = 2000
def month = 1;
(1..31).each {
    def fromDate = new GregorianCalendar(year, month - 1, it).time;
    def toDate = new GregorianCalendar(year, month - 1, it+1).time;
    long cnt = collection.count(new BasicDBObject(
        ["doDate" : BasicDBObjectBuilder.start('$gte', fromDate).add('$lte', toDate).get()]))
    
    def d = "${year}-${String.format('%02d', month)}-${String.format('%02d', it)}"
    def solrc = solr("doDate: \"${d}T00:00:00Z\" AND pto:${pto}");
    def cnt2 = solrc.response.numFound
    if (cnt > 0) {
        println "${d} ${cnt} ${cnt2}" + (cnt == cnt2 ? "":" - NOT MATCH!!!");
    }
}
    
def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
