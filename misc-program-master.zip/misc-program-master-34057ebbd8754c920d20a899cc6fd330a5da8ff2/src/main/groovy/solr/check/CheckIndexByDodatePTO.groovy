import groovy.json.JsonSlurper
import util.MongoUtil

import com.mongodb.BasicDBObject
import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.mongodb.DBObject

def ln = System.getProperty('line.separator')
def dateStr = "T00:00:00Z"
def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
def dateS = "2015-08-13" + dateStr
def dateE = "2015-08-14" + dateStr

def doDateS = Date.parse(dateFormat, dateS)
def doDateE = Date.parse(dateFormat, dateE)

//
def pto = "USPTO"
def srcCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017, "PatentInfo${pto}").getDb().getCollection("PatentInfo${pto}")

def queryMap = [:]
queryMap << ["doDate" : ['$gte' : doDateS, '$lt' : doDateE]]

def result = srcCol.count(new BasicDBObject(queryMap))

//160
//def solrc = solr("doDate: \"${dateS}\" AND pto:${pto}");

//176
def solrc = solr("do_date: \"${dateS}\"");

def solCnt = solrc.response.numFound

println "mongo counts: $result vs $solCnt : solr counts"

println 'finished!'

def solr(querystr) {
	def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.176:8080/solr/us/select?q=${query}&wt=json&indent=true").toURL().text
//	def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
	def jsonSlurper = new JsonSlurper();
	def object = jsonSlurper.parseText(xml)
	return object;
}
