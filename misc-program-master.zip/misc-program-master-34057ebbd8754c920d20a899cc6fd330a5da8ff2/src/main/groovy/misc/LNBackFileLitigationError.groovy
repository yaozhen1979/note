
import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import java.util.regex.*

import org.apache.http.auth.*
import org.json.*

import com.mongodb.*

/**
 * 擷取 LNBackFile 訴訟資料有問題的資料調整
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
                
def collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile")
DBCollection collection2 = mongoClient.getDB("LNBackFile").getCollection("Litigation")
def error = mongoClient.getDB("LNBackFile").getCollection("ErrorLog")

BulkWriteOperation tarBulk = collection.initializeOrderedBulkOperation()

def cnt = 0;
def licnt = 0;
def flagcnt=0;
Locale.setDefault(Locale.US)
//DBCursor cursor = error.find(new BasicDBObject(["flag": 0, "error" : Pattern.compile(/^date.*/)])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
DBCursor cursor = error.find(new BasicDBObject(["flag": 0, "error" : Pattern.compile(/^date not match/)])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
//DBCursor cursor = error.find(new BasicDBObject(["flag": 0, "comment" : java.util.regex.Pattern.compile(" V ")])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
//DBCursor cursor = error.find(new BasicDBObject(["flag": 0, "error" : "docket-number not match"])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
//DBCursor cursor = error.find(new BasicDBObject(["flag": 0, "comment" : null])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
//DBCursor cursor = collection.find(new BasicDBObject(["_id":"US6222921B1"]))
while (cursor.hasNext()) {
    DBObject dbobj1 = cursor.next();
    DBObject dbobj = collection.findOne(new BasicDBObject(["_id": dbobj1.get("_id")]));
    DBObject data = dbobj.get("data")
    BasicDBList issuance = data.get("post-issuance-data")
    def flag = -1;
    DBObject litigation = null;
    if (issuance == null || issuance.size() == 0) {
        flag = 0;
    } else {
        if (issuance.size() > 1) {
            log('warn: post-issuance-data size:' + issuance.size() + ' id:' + dbobj.get("_id"))
            flag = 9
        } else {
            for (DBObject object : issuance) {
                litigation = object.get("notices-of-litigation");
                if (litigation == null) {
                    flag = 0
                } else {
                    licnt++;
                    //log('have litigation: ' + dbobj.get("_id"))
                    def litigations = litigation.get("notice-of-litigation");
                    for (DBObject object2 : litigations) {
                        if (object2.get("comment") == null || object2.get("comment") == ', D.C. , Doc. No. ') {
                            continue
                        }
                        try {
                            if (object2.get("date") == null) {
                                def comment = object2.get("comment")
                                def c = comment.split(" v. ");
                                if (c.length != 2) {
                                    c = comment.split(" VS ");
                                    if (c.length != 2) {
                                        c = comment.split(" V ");
                                        if (c.length != 2) {
                                            throw new Exception("error parse1");
                                        }
                                    }
                                }
                                String u1 = c[0];
                                tmp = c[1];
                                c = tmp.split(", Doc. No. ");
                                if (c.length != 2) {
                                    c = tmp.split(", Doc No. ");
                                    if (c.length != 2) {
                                        c = tmp.split(", Doc. No ");
                                        if (c.length != 2) {
                                            c = tmp.split(",. Doc. No ");
                                            if (c.length != 2) {
                                                c = tmp.split(" Doc. No ");
                                                if (c.length != 2) {
                                                    c = tmp.split(" Doc. No. ");
                                                    if (c.length != 2) {
                                                        c = tmp.split(", Doc. ");
                                                        if (c.length != 2) {
                                                            throw new Exception("error parse3");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                def docNo = c[1]
                                def idx = c[0].lastIndexOf(",")
                                def u2 = c[0].substring(0, idx)
                                def court = c[0].substring(idx+1)
                                //log("comment:" + comment)
                                //log("u1:" + u1 + " u2:" + u2 + " court:" + court + " docNo:" + docNo)
                                object2.put("Plaintiff", u1)
                                object2.put("Defendant", u2)
                                object2.put("Court", court)
                                def dn = docNo.replaceAll("\n","").trim();
                                if (dn != object2.get("docket-number")) {
//                                    throw new Exception("docket-number not match");
                                }
                            } else {
                                def comment = object2.get("comment")
                                def c = comment.split(" v. ");
                                if (c.length != 2) {
                                    c = comment.split(" VS ");
                                    if (c.length != 2) {
                                        c = comment.split(" V ");
                                        if (c.length != 2) {
                                            throw new Exception("error parse1");
                                        }
                                    }
                                }
                                String u1 = c[0];
                                String tmp = c[1];
                                c = tmp.split(", Filed ");
                                if (c.length != 2) {
                                    c = tmp.split(", Filed: ");
                                    if (c.length != 2) {
                                        c = tmp.split(" Filed ");
                                        if (c.length != 2) {
                                            throw new Exception("error parse2");
                                        }
                                    }
                                }
                                String u2 = c[0];
                                tmp = c[1];
                                c = tmp.split(", Doc. No. ");
                                if (c.length != 2) {
                                    c = tmp.split(", Doc No. ");
                                    if (c.length != 2) {
                                        c = tmp.split(", Doc. No ");
                                        if (c.length != 2) {
                                            c = tmp.split(",. Doc. No ");
                                            if (c.length != 2) {
                                                c = tmp.split(" Doc. No ");
                                                if (c.length != 2) {
                                                    c = tmp.split(" Doc. No. ");
                                                    if (c.length != 2) {
                                                        c = tmp.split(", Doc. ");
                                                        if (c.length != 2) {
                                                            throw new Exception("error parse3");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                def docNo = c[1]
                                def idx = c[0].indexOf(",")
                                idx = c[0].indexOf(",", idx+1)
                                if (idx == -1) {
                                    idx = c[0].indexOf(".", idx+1)
                                }
                                def date = c[0].substring(0, idx).trim()
                                def court = c[0].substring(idx+1)
                                //log("u1:" + u1 + " u2:" + u2 + " date:" + date + " court:" + court + " docNo:" + docNo)
                                object2.put("Plaintiff", u1)
                                object2.put("Defendant", u2)
                                object2.put("Court", court)
                                def dn = docNo.replaceAll("\n","").trim();
                                if (dn != object2.get("docket-number")) {
                                    //log(dn + " vs " + object2.get("docket-number"))
//                                    throw new Exception("docket-number not match");
                                }
                                def date1 = new Date().parse('yyyyMMdd', object2.get("date"));
                                if (date1.format("MMMMM dd, yyyy") != date) {
                                    if (date1.format("MMMMM d, yyyy") != date) {
                                        if (date1.format("MMMMM d,yyyy") != date) {
                                            if (date1.format("MMM. d, yyyy") != date) {
                                                //throw new Exception("date not match " + date1.format("MMMMM d, yyyy") + " vs " + date);
                                            }
                                        }
                                    }
                                }
                            }
                            flag = 1
                        } catch (Exception e) {
                            log("ERROR:" + dbobj.get("_id") + " --> " + e.getMessage() + " --> " + object2.get("comment"));
                            error.update(new BasicDBObject(["_id": dbobj.get("_id")]),
                                new BasicDBObject(["error": e.getMessage(), "comment": object2.get("comment"), "flag":0
                            ]), true, false);
                            flag = 8
                            break;
                        }
                    }
                }
            }
        }
    }
    if (flag == -1) {
        flag = 1
    }
    
    if (flag == 1) {
        collection2.update(new BasicDBObject(["_id": dbobj.get("_id")]),
                new BasicDBObject(["notices-of-litigation" : litigation.get("notice-of-litigation")
            ]), true, false);
        
        error.update(new BasicDBObject(["_id": dbobj.get("_id")]),
            new BasicDBObject('$set', new BasicDBObject(["flag": 1
        ])), true, false);
    
        flagcnt++
    }
    if (flag == 1 || flag == 0) {
        tarBulk.find(new BasicDBObject(["_id": dbobj.get("_id")]))
            .update(new BasicDBObject('$set', new BasicDBObject(["litigation": flag])))
    }
    cnt++;
    if (cnt % 10000 == 0) {
        log(cnt)
        //log('batch update')
        def tarResult = tarBulk.execute()
        tarBulk = collection.initializeOrderedBulkOperation()
        //log('update finish!')
    }
}
log(cnt)
log(flagcnt)
log('batch update')
tarBulk.execute();
log('update finish!')

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}