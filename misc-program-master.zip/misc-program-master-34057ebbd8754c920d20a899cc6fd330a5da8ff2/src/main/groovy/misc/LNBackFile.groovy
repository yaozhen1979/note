import java.io.File

@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')
@Grab(group='org.json', module='json', version='20090211')

import groovy.json.JsonSlurper
import groovyx.net.*
import groovyx.net.http.*
import static groovy.json.JsonOutput.*

import org.json.*

import org.apache.http.auth.*

import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.BasicDBObject
import com.mongodb.DBObject
import com.mongodb.DBCursor
import com.mongodb.util.JSON

/**
 *  最原始處理 LNBackFile 的版本，直接用 JSON lib 轉換 XML to JSON。
 *  已經不採用此版本，透過 JAXB 的方式來處理
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile")

def zipFile = new java.util.zip.ZipFile(new File('F:/LN/US_2015_001.zip'))

zipFile.entries().each {
   //def x = new XmlSlurper().parse(zipFile.getInputStream(it))
   //println x
   println it.name
   def patentNo = it.name.split('\\.')[0]
   def xml = zipFile.getInputStream(it).getText("utf-8")
   JSONObject xmlJSONObj = XML.toJSONObject(xml);
   String jsonstr = xmlJSONObj.toString(2);
   DBObject dbObject = (DBObject) JSON.parse(jsonstr);
   
   DBCursor cursor = collection.find(new BasicDBObject(["patentNo": patentNo]))
   if (!cursor.hasNext()) {
        collection.insert(new BasicDBObject(["file": "US_2015_001.zip", "patentNo": patentNo, "data": dbObject]))
   }

}


println 'finished!'

