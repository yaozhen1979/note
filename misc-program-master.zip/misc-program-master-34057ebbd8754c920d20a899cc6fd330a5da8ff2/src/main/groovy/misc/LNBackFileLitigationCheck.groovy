
import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.apache.http.auth.*
import org.json.*

import com.mongodb.*

/**
 * 檢查訴訟資料的小程式
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
                
DBCollection collection2 = mongoClient.getDB("LNBackFile").getCollection("Litigation")

DBCursor cursor = collection2.find().addOption(Bytes.QUERYOPTION_NOTIMEOUT)
def cnt = 0
while (cursor.hasNext()) {
    DBObject dbobj = cursor.next();
    BasicDBList issuance = dbobj.get("notices-of-litigation")
    for (DBObject object : issuance) {
        def docket = object.get("docket-number");
        if (!(docket =~ /^[0-9]:[0-9]{2}-?[a-zA-Z]{2}\.?-?[0-9]{1,5}$/)) {
            println dbobj.get("_id") + " --> " + docket;
            cnt++
        }
//        def adjust = object.get("adjust");
//        if (adjust != null) {
//            println dbobj.get("_id");
//        }
    }
}
println cnt
println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}