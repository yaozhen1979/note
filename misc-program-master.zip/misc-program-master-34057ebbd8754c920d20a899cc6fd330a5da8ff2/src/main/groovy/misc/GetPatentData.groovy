@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')
import groovy.json.JsonSlurper

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import org.bson.types.*


//
MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.122", 27017),
                    Arrays.asList(credential));

def docNum = 'US006976070'
def doc = solr('patentNumberAll:' + docNum)
def d = doc.response.docs[0]
println d.id + d.pto

def collection = mongoClient.getDB("PatentInfo${d.pto.toUpperCase()}").getCollection("PatentInfo${d.pto.toUpperCase()}")
def level2 = collection.findOne(new BasicDBObject(["_id" : new ObjectId(d.id)]))
println "=============== level2 ================"
println level2
println "======================================="
println level2.relRawdatas
println level2.relRawdatas[0]._id

def mongoClient1 = new MongoClient(new ServerAddress("10.60.90.127", 27017),Arrays.asList(credential));
def collection1 = mongoClient1.getDB("PatentRaw${d.pto.toUpperCase()}").getCollection("PatentRaw${d.pto.toUpperCase()}")
def level1 = collection1.findOne(new BasicDBObject(["_id" : level2.relRawdatas[0]._id]))
println "=============== level1 ================"
println level1.data.xml
println "======================================="




def solr(querystr) {
    def query = java.net.URLEncoder.encode(querystr);
    def xml = ("http://10.60.90.160:5566/solr/patentcloud/select?q=${query}&wt=json&indent=true&rows=10").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
