@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.DBCursor


MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.155", 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("PatentIndiaRawData").getCollection("PatentIndiaRawData")

def str = """3705/KOLNP/2006
4515/CHENP/2006
1320/KOL/2006
7435/DELNP/2006
2289/CHE/2006
7447/DELNP/2006
7424/DELNP/2006
2636/DEL/2006
1326/KOL/2006
7440/DELNP/2006
7454/DELNP/2006
7423/DELNP/2006
1324/KOL/2006
7420/DELNP/2006
4521/CHENP/2006
7451/DELNP/2006
2288/CHE/2006"""

str.eachLine {
	int c = collection.count(new BasicDBObject(["application_no" : it]))
	if (c != 2) {
		println 'over:' + it + " -- " + c
		return
	}
	DBCursor cursor = collection.find(new BasicDBObject(["application_no" : it]))
	if (cursor.hasNext()) {
		def d = cursor.next();
        //collection.remove(d);
    }
    cursor.close();
}