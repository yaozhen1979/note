package uspto.download

import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method

import org.apache.http.auth.AuthScope
import org.apache.http.auth.UsernamePasswordCredentials

class HttpBuilderUtil {

    def ln = System.getProperty('line.separator')

    def httpBuilder
    
//    static {
//        
//        System.setProperty("org.apache.commons.logging.Log",
//            "org.apache.commons.logging.impl.NoOpLog");
//     }
  
    
    HttpBuilderUtil(){

        init()
    }

    def init() {
        //httpBuilder
        httpBuilder = new HTTPBuilder()

        httpBuilder.client.getCredentialsProvider().setCredentials(

                new AuthScope("10.60.94.21", 3128),

                new UsernamePasswordCredentials("docker", "Abc.2015")

                )
        
        httpBuilder.setProxy('10.60.94.21', 3128, 'http')

    }

    def downloadFullPdf(downloadPdfUrl, realPath, log) {

        String dateStr = new Date().format( 'yyyy-MM-dd HH:mm:ss')

        def folder = new File(realPath)

        // If it doesn't exist
        if( !folder.exists() ) {
            // Create all folders up-to and including B
            folder.mkdirs()

        }

        def pdfPath = realPath + "/" + "fullPage.pdf"

        def cnt = 0

        while (true) {

            cnt++

            println "${dateStr} download pdf from URL: ${downloadPdfUrl}"

            log << "${dateStr} download pdf from URL: ${downloadPdfUrl}" << ln

            try {

                httpBuilder.request(downloadPdfUrl, Method.GET, ContentType.BINARY) { req ->

                    response.success = { resp, inputStream   ->

                        new File(pdfPath).withOutputStream { out ->

                            out << inputStream

                        }

                    }

                    response.'404' = { resp -> println "Error Code = ${resp.status}" }

                }

                def pdfFile = new File(pdfPath)

                if (pdfFile.exists() && pdfFile.length() > 0) {

                    println "${dateStr} ${pdfPath} save success"

                    log << "${dateStr} ${pdfPath} save success" << ln

                    break;

                } else {

                    println "${dateStr} pdf download failed .. retry ${cnt}"

                    log << "${dateStr} pdf download failed .. retry ${cnt}" << ln

                    pdfFile.deleteOnExit()

                    Thread.sleep(1000 * 6)

                }

                if (cnt > 9) {

                    println "${dateStr} retry download pdf over ${cnt} times, skip it!, realPath: ${pdfPath}"

                    log << "${dateStr} retry download pdf over ${cnt} times, skip it!, realPath: ${pdfPath}" << ln

                    break

                }

            } catch (e) {

                println "${dateStr} pdf download failed .. ${e}, pdfPath: ${pdfPath}"

                log << "${dateStr} pdf download failed .. ${e}, pdfPath: ${pdfPath}" << ln

            }

        }
    }

    def getHtml(url) {

        def html

        httpBuilder.request(url, Method.GET, ContentType.TEXT) { req ->

            response.success = { resp, resq   ->

                html = resq.text
            }

            response.'404' = { resp -> println "Error Code = ${resp.status}" }

        }
        
        return html

    }
}
