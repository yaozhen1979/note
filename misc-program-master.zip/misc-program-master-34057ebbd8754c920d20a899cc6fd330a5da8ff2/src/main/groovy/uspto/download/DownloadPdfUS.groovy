package uspto.download

import java.text.SimpleDateFormat
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.bson.types.ObjectId
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.MongoUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level

import com.mongodb.BasicDBObject
import com.mongodb.DBCursor
import com.mongodb.DBObject

System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");

Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

System.properties << [ 'http.proxyHost':'10.60.94.21', 'http.proxyPort':'3128' ]

//def imgRelPath = "/mnt/nhdell/patent_us/data"

def imgRelPath = "D:\\images\\mnt\\nhdell\\patent_us\\data"
//

def tempImgRelPath = "tmp/pdf/"

def imgPatentUrl = "http://pdfpiw.uspto.gov";

def imgApplicationUrl = "http://pdfaiw.uspto.gov";

def fullPagePatentUrl = "http://pimg-fpiw.uspto.gov/fdd";

def fullPageApplicationUrl = "http://pimg-faiw.uspto.gov/fdd";

def year = "2015"

def month = "09"

def day = "03"

def dateS = year + "/" + month + "/" + day

def dateE = year + "/" + month + "/" + (Integer.valueOf(day) + 1)

def dateSuffix = "T00:00:00"

def doDateS = Date.parse("yyyy/MM/dd'T'HH:mm:ss", dateS + dateSuffix)

def doDateE = Date.parse("yyyy/MM/dd'T'HH:mm:ss", dateE + dateSuffix)

def ln = System.getProperty('line.separator')

def logPath = "log/uspto/downloadPdf/"

if (!new File(logPath).exists()) {

    new File(logPath).mkdirs()

}

File log = new File("log/uspto/downloadPdf/${year}${month}${day}.txt")

def srcCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, "PatentInfoUSPTO").getDb().getCollection("PatentInfoUSPTO")

def queryMap = [:]

queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

def count = srcCol.count(new BasicDBObject(queryMap))

if (count == 0) {

    println "There is no data between [${dateS}~${dateE}] in PatentInfoUSPTO..."

    return

}

println "find patent number list by date range [${dateS}~${dateE}], count: ${count}"

log << "find patent number list by date range [${dateS}~${dateE}], count: ${count}" << ln

DBCursor srcCur = srcCol.find(new BasicDBObject(queryMap))

def patentNumberListFolder = "tmp/uspto/patentNumberList"

if (!new File(patentNumberListFolder).exists()) {

    new File(patentNumberListFolder).mkdirs()

}

def patentListFilePath = "${patentNumberListFolder}/${year}${month}${day}.txt"

File patentListFile = new File("${patentNumberListFolder}/${year}${month}${day}.txt")

if (!patentListFile.exists()) {

    println "${patentListFilePath} is not exist"

    while (srcCur.hasNext()) {

        DBObject doc = srcCur.next()

        def patentNumber = doc.patentNumber

        println "id:${doc._id};patentNumber:${doc.patentNumber};${year}${month}${day}"

        patentListFile << "${doc._id};${doc.patentNumber};${year}${month}${day}" << ln

    }
}

println "star parse image number by file ${patentListFilePath}"

RestTimeProcess rtp = new RestTimeProcess(count, "USPTO ${year}-${month}-${day} : download full pdf", log)

patentListFile.eachLine {line ->

    rtp.process()

    def id = line.split(";")[0]

    DBObject searchById = new BasicDBObject("_id", new ObjectId(id.trim()))

    def doc = srcCol.findOne(searchById)

    def imageUrl = (doc.stat == 1) ? imgApplicationUrl : imgPatentUrl

    def fullPageUrl = (doc.stat == 1) ? fullPageApplicationUrl : fullPagePatentUrl

    if (doc.withdrawn) {

        println "withdrawn " + doc.patentNumber

    } else {

        def formatPatentNumber = formatPatentNumber(doc.stat, doc.patentNumber)

        def realPath = imgRelPath + "/" + getRelPatentPath(doc)
        
        def downloadPdfUrl = makeFullPageUrl(doc.stat, formatPatentNumber, fullPageUrl)
        
        def fullImageUrl = imageUrl + (doc.stat == 1 ? "/.aiw?Docid=" : "/.piw?Docid=") + formatPatentNumber
        
        HttpBuilderUtil http = new HttpBuilderUtil()
        
        http.downloadFullPdf(downloadPdfUrl, tempImgRelPath, log)
        
        saveImageNum(http, fullImageUrl, imageUrl, doc)

        //        srcCol.save(doc)

    }


}

println "download full pdf, date range [${dateS}~${dateE}], finish!!"

def formatPatentNumber(stat, patentNumber) {

    Matcher zeroMat = Pattern.compile("US0*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(patentNumber);

    if (zeroMat.find()) {

        patentNumber = zeroMat.group(1);

    }

    String formatNumber = null;

    try {

        if (stat == 1) {

            return patentNumber;

        }

        Matcher mat = Pattern.compile("(\\D*)(\\d+)", Pattern.CASE_INSENSITIVE).matcher(patentNumber);

        if (mat.find()) {

            String type = mat.group(1);

            String number = mat.group(2);

            int zeroLength = 8 - type.length() - number.length();

            String zeros = "";

            for (int i = 0; i < zeroLength; i++) {

                zeros = zeros + 0;

            }

            formatNumber = String.format("%s%s%s", type, zeros, number);

        }

        return formatNumber;

    } catch (Exception e) {

        throw new IllegalArgumentException("format patentNumber error: " + patentNumber);

    }
}

def saveImageNum(http, url, imageUrl, tarDoc) {

    def doc = null;

    def retry = 0;

    while (retry < 10)  {

        try {
            
            doc = org.jsoup.Jsoup.parse(http.getHtml(url))

//            doc = org.jsoup.Jsoup.connect(url).timeout(300000).get();

            break;

        } catch (Exception e) {

            retry++;

            println e

            println 'will retry list:' + retry

        }
    }

    def aTag

    if (tarDoc.stat == 1) {

        def form = doc.select('form[action="/.aiw"]')

        aTag = form.select('a[href^=/.aiw]')

    } else {

        def form = doc.select('form[action="/.piw"]')

        aTag = form.select('a[href^=/.piw]')
    }

    aTag.each{

        if (it.text() == "Front Page") {

            def map = getImgNum(http, imageUrl + it.attr("href"))

            tarDoc['filePageFirst'] =  map.num.toInteger()

            tarDoc['filePageNumber'] = map.total.toInteger()

        } else if (it.text() == "Drawings"){

            def map = getImgNum(http, imageUrl + it.attr("href"))

            tarDoc['filePageFig'] =  map.num.toInteger()

        } else if (it.text() == "Specifications"){

            def map = getImgNum(http, imageUrl + it.attr("href"))

            tarDoc['filePageDesc'] =  map.num.toInteger()

        } else if (it.text() == "Claims"){

            def map = getImgNum(http, imageUrl + it.attr("href"))

            tarDoc['filePageClaim'] =  map.num.toInteger()

        }

    }

}

def getImgNum(http, url) {

    def doc = null;

    def retry = 0;

    while (retry < 10)  {

        try {

            doc = org.jsoup.Jsoup.parse(http.getHtml(url))
//            doc = org.jsoup.Jsoup.connect(url).timeout(300000)
//                    .get();
            break;

        } catch (Exception e) {

            retry++;

            println e

            println 'will retry list:' + retry

        }
    }

    def table = doc.select('table')[3]

    def td = table.select('td')[0]

    def text = td.html()

    def map = [:]

    text.replaceAll(/<b>\d+\s*of.*?pages/) {fullMatch ->

        def pageContent = fullMatch

        pageContent.replaceAll(/<b>(\d+)\s*of(.*?)pages/){fullMatch1, result, result1 ->

            map['num'] = result

            def total = result1.trim()

            map['total'] = total

        }

    }

    return map
}

/**
 *  publication
 *  url:    http://pimg-faiw.uspto.gov/fdd/54/2014/05/025/0.pdf
 *  eg: 20140250554     /54/2014/05/025/0.pdf
 *
 *  grant
 *  url:    http://pimg-fpiw.uspto.gov/fdd/21/543/076/0.pdf
 *  eg: 7654321         /21/543/076/0.pdf
 *  eg: D697290         /90/972/D06/0.pdf
 *  eg: RE044728        /28/447/RE0/0.pdf
 *  eg: PP24165         /65/241/PP0/0.pdf
 */
def makeFullPageUrl(stat, patentNumber, fullPageUrl) {

    String ret = null;

    Matcher mat;

    try {

        if (stat == 1) {

            mat = Pattern.compile("(\\d{4})(\\d{3})(\\d{2})(\\d{2})", Pattern.CASE_INSENSITIVE).matcher(patentNumber);

            if (mat.find()) {

                ret = String.format("%s/%s/%s/%s/%s/0.pdf", fullPageUrl, mat.group(4), mat.group(1), mat.group(3), mat.group(2));

            }

        } else {

            mat = Pattern.compile("(\\w{3})(\\d{3})(\\d{2})", Pattern.CASE_INSENSITIVE).matcher(patentNumber);

            if (mat.find()) {

                ret = String.format("%s/%s/%s/%s/0.pdf", fullPageUrl, mat.group(3), mat.group(2), mat.group(1));

            }
        }

        return ret;

    } catch (Exception e) {

        throw new IllegalArgumentException("make fullPage url error, patentNumber: " + patentNumber);

    }
}

def getRelPatentPath(doc) {

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

    return sprintf('%s%d%s/%s/%s',
            ["us", doc.stat, (doc.kindcode) ? doc.kindcode.toString().toLowerCase() : "", sdf.format(doc.doDate), doc.patentNumber.replaceAll("[\\/\\s]", "").toLowerCase()])
}

