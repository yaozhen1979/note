package uspto.check;
import com.gmongo.GMongoClient
import com.mongodb.BasicDBObject
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;

Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

/**
 * 盤查USPTO的Full PDF 在實體檔案目錄中是否存在 by patentNumber list 檔案
 */

def srcIp = "10.60.90.121"
def port = 27017
def ac = "patentdata"
def pwd = "data.cloud.Abc12345"
def srcDb = "PatentInfoUSPTO"

def imgPath = "\\\\10.60.95.12\\patentimg\\patent_us\\data\\us"

File file = new File('tmp/20150915.txt')

File errFile = new File('tmp/20150915-1.txt')

File filePageFirst = new File('tmp/20150915-loss-filePageFirst.txt')

def ln = System.getProperty('line.separator')

MongoCredential srcCredential = MongoCredential.createCredential(ac, "admin", pwd as char[]);

def srcClient = new GMongoClient(new ServerAddress(srcIp, port), [srcCredential])

def srcCol = srcClient.getDB(srcDb).getCollection(srcDb)

def total = 0
def missPdfcnt = 0

println "start to check full pdf from text : " + file.absolutePath


file.eachLine { line, lineNumber ->
	total++
	def id = line.split(';')[0]
	DBObject searchById = new BasicDBObject("_id", new ObjectId(id.trim()))
	def doc = srcCol.findOne(searchById)
	Date doDate = doc.doDate
	def dateStr = doDate.format( 'yyyy\\MM\\dd' )
	def fullPdfPath = imgPath + doc.stat + doc.kindcode.toLowerCase() + "\\" + dateStr + "\\" + doc.patentNumber + "\\fullPage.pdf"

	//	println fullPdfPath
	if (!new File(fullPdfPath).exists()) {
		
		missPdfcnt++
		
		println "$fullPdfPath is not exists"
		
		errFile << "${doc._id};${doc.patentNumber};${dateStr}" << ln
		
	} else {
//        println "doc.filePageFirst: " + doc.filePageFirst
		//檔案有但是mongodb 裡面卻沒有紀錄的
		if (doc.filePageFirst == null) {
			
			println "$doc._id;$doc.patentNumber;$doc.filePageFirst"
            
            def srcId = ['_id':doc._id]
            
            def updateMap = ['$set' : ['filePageFirst' : 1]]
            
            srcCol.update(['_id':doc._id], ['$set' : ['filePageFirst' : 1]], true)
            
            filePageFirst << "${doc._id};${doc.patentNumber};${dateStr}" << ln
            
		}
		
	}
}

println "finish ! ${missPdfcnt}/${total}(miss/total)\t" + (missPdfcnt.is(0) ? "match" : "not match")
