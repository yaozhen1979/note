package uspto.check;
import util.MongoUtil
import util.RestTimeProcess

import com.mongodb.BasicDBObject
import com.mongodb.DBCursor
import com.mongodb.DBObject

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;

Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);


/**
 * 盤查USPTO的Full PDF 在實體檔案目錄中是否存在 by doDate 區間
 */

//def srcIp = "10.60.90.121"
//def port = 27017
//def ac = "patentdata"
//def pwd = "data.cloud.Abc12345"
//def srcDb = "PatentInfoUSPTO"
def dateS = "2015/09/22T00:00:00"
def dateE = "2015/09/23T00:00:00"
def imgPath = "\\\\10.60.95.12\\patentimg\\patent_us\\data\\us"

File file = new File('tmp/20150922.txt')

File logFolder = new File("log/pdfCheck")

if (!logFolder.exists()) {
    
    logFolder.mkdirs()
    
}

File log = new File('log/pdfCheck/20150915.txt')

def ln = System.getProperty('line.separator')

def srcCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017, "PatentInfoUSPTO").getDb().getCollection("PatentInfoUSPTO")
//def srcCol = new MongoUtil(ac, pwd, srcIp, port, srcDb).getDb().getCollection(srcDb)

def doDateS = Date.parse("yyyy/MM/dd'T'HH:mm:ss", dateS)
def doDateE = Date.parse("yyyy/MM/dd'T'HH:mm:ss", dateE)

def queryMap = [:]
queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

DBCursor srcCur = srcCol.find(new BasicDBObject(queryMap))

def missPdfcnt = 0

println "start to check full pdf from ${dateS} to ${dateE}"

def total = srcCol.count(new BasicDBObject(queryMap))
RestTimeProcess rtp = new RestTimeProcess(total, log)

def cnt = 0

while (srcCur.hasNext()) {
	
	DBObject doc = srcCur.next()
	
	Date doDate = doc.doDate
	
	def dateStr = doDate.format( 'yyyy\\MM\\dd' )
	
	def fullPdfPath = imgPath + doc.stat + doc.kindcode.toLowerCase() + "\\" + dateStr + "\\" + doc.patentNumber + "\\fullPage.pdf"
	
	rtp.process()
						
	//	println fullPdfPath
	if (!new File(fullPdfPath).exists()) {
		
		missPdfcnt++
		
		println "${fullPdfPath} does not exist"
		
		file << "${doc._id};${doc.patentNumber};${dateStr}" << ln
	} else {
//		file << "${doc._id};${doc.patentNumber};${dateStr}" << ln
	}
}

println "finish ! ${missPdfcnt}/${total}(miss/total)\t" + (missPdfcnt.is(0) ? "match" : "not match")
