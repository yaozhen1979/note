import groovy.json.JsonOutput
import groovy.time.TimeCategory
import groovy.time.TimeDuration

import org.bson.types.ObjectId
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.MongoUtil
import util.PatentInfoFieldVerifyUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level

import com.mongodb.BasicDBObject
import com.mongodb.DBCursor
import com.mongodb.DBObject

Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

//********** arguments ***********
def pto = "PatentInfoUSPTO"

def dateS = "2007-01-01"

def dateE = "2008-01-01"

def batchSize = 1000

def usptoInfoDbName = "PatentInfoUSPTO"

def lnBackDbName = "LNBackFile"

def errColName = "ErrorLNBackFile"
//********** arguments ***********

def PRETTY_PRINT_INDENT_FACTOR = 4;

def ln = System.getProperty('line.separator')

def dateStr = "T00:00:00"

def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"

File log = new File("tmp/LN_back_parse_${dateS}-${dateE}.txt")

def timeCalculateClosure = { closure ->

    def timeStart = new Date()

    def msg = closure()

    def timeStop = new Date()

    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    def msg1 = msg + " spend time: " +  duration

    println msg1

    log << msg1 << ln
}

timeCalculateClosure {

    try {

        def newUsptoInfoClient = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()

        def lnBackClient = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()

        def oldUsptoInfoCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017, usptoInfoDbName).getDb().getCollection(usptoInfoDbName)
        //
        def lnBackDb = lnBackClient.getDB(lnBackDbName)

        def lnBackCol = lnBackDb.getCollection(lnBackDbName)

        def newUsptoInfoDb = newUsptoInfoClient.getDB(usptoInfoDbName)

        def newUsptoInfoCol = newUsptoInfoDb.getCollection(usptoInfoDbName)

        //
        def errDb = lnBackClient.getDB(errColName)

        def errCol = errDb.getCollection(errColName)

        //
        //        def tarCol = client.getDB(tarDB).getCollection(tarDB)

        //        BulkWriteOperation tarBulk = tarCol.initializeOrderedBulkOperation()

        println "parse LNBackFile, date range [${dateS} ~ ${dateE}]"

        def doDateS = Date.parse(dateFormat, dateS + dateStr)

        def doDateE = Date.parse(dateFormat, dateE + dateStr)

        def queryMap = [:]

        queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

//                queryMap << ['_id' : new ObjectId("54abc33e004e48cc371442f3")]

        def total = oldUsptoInfoCol.count(new BasicDBObject(queryMap))

        RestTimeProcess rtp = new RestTimeProcess(total, "LNBackFile parse ${dateS}", log)

        DBCursor oldUsptoCur = oldUsptoInfoCol.find(new BasicDBObject(queryMap))
        
        def cnt = 0

        def missCnt = 0

        while (oldUsptoCur.hasNext()) {

            cnt++

            rtp.process()

            try {

                DBObject oldUsptoDoc = oldUsptoCur.next()

                def oldUsptoPn = oldUsptoDoc.patentNumber
                
//                println "oldUsptoDoc.patentNumber: " + oldUsptoDoc.patentNumber + ",cnt : ${cnt}"

                def lnPatentNo

                def stat = oldUsptoDoc.stat
                
                def docNo

                if (stat == 1) {

                    oldUsptoPn.replaceAll(/^(\d{11})$/) {fullMatch, docNumber ->

                        docNo = docNumber
                        
                    }

                } else if (stat == 2) {

                    if (oldUsptoPn =~ /US0*([1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*([1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    } else if (oldUsptoPn =~ /US0*(D[1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*(D[1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    } else if (oldUsptoPn =~ /US0*(RE[1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*(RE[1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    } else if (oldUsptoPn =~ /US0*(H[1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*(H[1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    } else if (oldUsptoPn =~ /US0*(PP[1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*(PP[1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    } else if (oldUsptoPn =~ /US0*(T[1-9]\d+)/) {

                        oldUsptoPn.replaceAll(/US0*(T[1-9]\d+)/) {fullMatch, docNumber ->

                            docNo = docNumber

                        }

                    }

                }
                
                if (!!docNo) {
                    
                    lnPatentNo = 'US' + docNo
                    
                }
                

                def lnBackFileFlag = 1

                def queryLnPatentNo = ["patentNumber" : lnPatentNo]
                
//                println "queryLnPatentNo : ${queryLnPatentNo}"

                def lnBackCur = lnBackCol.find(queryLnPatentNo)

                if (lnBackCur.count() == 0) {

                    missCnt++

                    println "LNBackFile not exists, patentNumber: ${lnPatentNo}"

                    errCol.update(['_id': oldUsptoDoc.patentNumber],
                    [$set: [
                            errCode : 1.toInteger(),
                            errMsg : 'LNBackfile data cant not found',
                            doDate : oldUsptoDoc.doDate,
                            stat : oldUsptoDoc.stat,
                            type : oldUsptoDoc.type,
                            kindcode : oldUsptoDoc.kindcode,
                            lastUpdateTime : new Date(),
                            errHandle : false]
                    ], true)

                    lnBackFileFlag = 0

                } else if (lnBackCur.count() > 1){

                    missCnt++

                    println "LNBackFile duplicate, patentNumber: ${lnPatentNo}"

                    errCol.update(['_id': lnId],
                    [$set: [
                            errCode : 2.toInteger(),
                            errMsg : 'LNBackfile data is duplicated',
                            doDate : oldUsptoDoc.doDate,
                            stat : oldUsptoDoc.stat,
                            type : oldUsptoDoc.type,
                            kindcode : oldUsptoDoc.kindcode,
                            lastUpdateTime : new Date(),
                            errHandle : false]
                    ], true)

                    lnBackFileFlag = -1

                }

                //查無相對應的LNBackFile 則直接將src存入
                if (lnBackFileFlag < 1) {

                    oldUsptoInfoCol.update(['_id': oldUsptoDoc._id],[$set: ['lnBackFile': lnBackFileFlag.toInteger()]], true)

                } else {

//                    println "LNBackFile exists, patentNumber: ${lnPatentNo}"
                    
                    def lnBackDoc = lnBackCur.next()
                    /*
                    if(lnBackDoc.uspto > 0) {
                        //已經做過
                        println "already made~skip"
                        continue
                        
                    }
*/
                    def newUsptoInfoDoc = [:]

                    newUsptoInfoDoc << ['_id' : oldUsptoDoc._id]

                    newUsptoInfoDoc << ['lnBackFile' : lnBackFileFlag]

                    newUsptoInfoDoc << ['doDate' : oldUsptoDoc.doDate]

                    newUsptoInfoDoc << ['pto' : 'USPTO']

                    newUsptoInfoDoc << ['mongoSyncFlag' : ['init' : new Date()]]

                    def lnBackData
                    if (!!lnBackDoc.data) {

                        lnBackData = lnBackDoc.data

                    } else {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'LN data error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type, 
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw new Exception("LN data error")

                    }


                    def biblio = lnBackData['bibliographic-data']

                    //publication-reference
                    try {
                        //公佈資訊(包含公開,公告)
                        def pubRef = biblio['publication-reference']

                        def lnStat = pubRef['publ-type'] == 'Grant' ? 2 : 1

                        assert lnStat == stat

                        newUsptoInfoDoc << ['stat' : lnStat.toInteger()]

                        def pubRefDocId = pubRef['document-id'][0]

                        def pubRefCountry = pubRefDocId['country']

                        assert  pubRefCountry == 'US'

                        def pubRefKind = pubRefDocId['kind']
                        
                        //舊的資料有kindcode才比較
                        if (!!oldUsptoDoc.kindcode) {
                            
                            assert  pubRefKind == oldUsptoDoc.kindcode
                            
                        }

                        newUsptoInfoDoc << ['kindcode' : pubRefKind]

                        def pubRefDocNumber = pubRefDocId['doc-number']

                        def pubRefPublishDate = pubRefDocId['date']

                        def pubRefPatentNumber = getPatentNubmer(pubRefCountry, pubRefDocNumber)

                        assert  pubRefPatentNumber == oldUsptoDoc.patentNumber

                        if (!pubRefPatentNumber) {
                            
                            errCol.update(['_id': lnPatentNo],
                                [$set: [
                                        errCode : 3.toInteger(),
                                        errMsg : 'patentNubmer error',
                                        doDate : oldUsptoDoc.doDate,
                                        stat : oldUsptoDoc.stat,
                                        type : oldUsptoDoc.type,
                                        kindcode : oldUsptoDoc.kindcode,
                                        lastUpdateTime : new Date(),
                                        errHandle : false]
                                ], true)

                            throw new Exception("patentNubmer error")

                        }

                        if (lnStat == 1) {

                            newUsptoInfoDoc << ['openNumber' : pubRefPatentNumber]

                            newUsptoInfoDoc << ['openNumberNormal' : pubRefCountry + pubRefDocNumber]

                            newUsptoInfoDoc << ['openDate' : toDate(pubRefPublishDate)]

                        } else {

                            newUsptoInfoDoc << ['decisionNumber' : pubRefPatentNumber]

                            newUsptoInfoDoc << ['decisionNumberNormal' : pubRefCountry + pubRefDocNumber]

                            newUsptoInfoDoc << ['decisionDate' : toDate(pubRefPublishDate)]

                        }

                        newUsptoInfoDoc << ['patentNumber' : pubRefPatentNumber]


                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'publication data error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "publication data error: " + e

                    }

                    //application-reference=> appNumber, appDate, type
                    try {

                        def appRef = biblio['application-reference']

                        //type
                        newUsptoInfoDoc << ['type' : oldUsptoDoc.type]

                        //appNumber
                        def appRefDocId = appRef['document-id'][0]

                        def appRefCountry = appRefDocId['country']

                        def appRefAppDateStr = appRefDocId['date']

                        def appRefAppDate = toDate(appRefAppDateStr)

                        newUsptoInfoDoc << ['appDate' : appRefAppDate]

                        def appRefDocNumber = appRefDocId['doc-number']

                        if (appRefDocNumber.length() != 8) {
                            
                            errCol.update(['_id': lnPatentNo],
                                [$set: [
                                        errCode : 3.toInteger(),
                                        errMsg : 'appNumber error',
                                        doDate : oldUsptoDoc.doDate,
                                        stat : oldUsptoDoc.stat,
                                        type : oldUsptoDoc.type,
                                        kindcode : oldUsptoDoc.kindcode,
                                        lastUpdateTime : new Date(),
                                        errHandle : false]
                                ], true)

                            throw new Exception("appNumber length is 8")

                        }

                        appRefDocNumber = appRefDocNumber[0..1] + "/" + appRefDocNumber[2..-1]

                        if (appRefDocNumber != oldUsptoDoc.appNumber) {
                            
                            errCol.update(['_id': lnPatentNo],
                                [$set: [
                                        errCode : 3.toInteger(),
                                        errMsg : 'appNumber not the same',
                                        doDate : oldUsptoDoc.doDate,
                                        stat : oldUsptoDoc.stat,
                                        type : oldUsptoDoc.type,
                                        kindcode : oldUsptoDoc.kindcode,
                                        lastUpdateTime : new Date(),
                                        errHandle : false]
                                ], true)
                            
                            throw new Exception("appNumber not the same")
                            
                        }

                        newUsptoInfoDoc << ['appNumber' : appRefDocNumber]

                        def appNumberNormal = normalizeAppNumber(appRefCountry, appRefAppDateStr, appRefDocId['doc-number'])

                        newUsptoInfoDoc << ['appNumberNormal' : appNumberNormal]

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'application data error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw new Exception("application data error: " + e)

                    }

                    //add version
                    newUsptoInfoDoc << ['version' : '1'.toInteger()]

                    //title
                    newUsptoInfoDoc << ['title' : oldUsptoDoc.title]

                    //description
                    newUsptoInfoDoc << ['description' : oldUsptoDoc.description]

                    //brief
                    newUsptoInfoDoc << ['brief' : oldUsptoDoc.brief]

                    //claim
                    newUsptoInfoDoc << ['claim' : oldUsptoDoc.claim]

                    //ipc
                    try {

                        if (!!biblio['classifications-ipcr']) {

                            def ipcArry = biblio['classifications-ipcr']['classification-ipcr']

                            def ipcsNormal = []

                            def ipcsOrigin = []

                            for (def i = 0; i < ipcArry.size(); i++ ) {

                                def section = ipcArry[i]['section']

                                def classTag = ipcArry[i]['class']

                                def subclass = ipcArry[i]['subclass']

                                def mainGroup = ipcArry[i]['main-group']

                                def subGroup = ipcArry[i]['subgroup']

                                def ipcOrigin = section + classTag + subclass + " " + mainGroup + "/" + subGroup

                                ipcsOrigin << ipcOrigin

                                def ipcNormal = normalizeClassificationNumber(section + classTag + subclass + "-" + mainGroup + "/" + subGroup, 'IPC');

                                if (!!ipcNormal) {

                                    ipcsNormal << ipcNormal

                                } else {

                                    throw new Exception("ipc miss")

                                }

                            }


                            if (ipcsOrigin.size() > 0) {

                                newUsptoInfoDoc << ['mainIPC' : ipcsOrigin[0]]

                                newUsptoInfoDoc << ['ipcs' : ipcsOrigin]

                            }

                            if (ipcsNormal.size() > 0) {

                                newUsptoInfoDoc << ['mainIPCNormal' : ipcsNormal[0]]

                                newUsptoInfoDoc << ['ipcsNormal' : ipcsNormal]

                            } else {

                                throw new Exception("ipc miss")

                            }

                        }


                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'IPC error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        println "IPC error: " + e

                    }

                    //cpc(含正規化) includes mainCPC, cpcs
                    try {

                        if (!!biblio['classifications-cpc']) {

                            def cpcArry = biblio['classifications-cpc']['classification-cpc']

                            def cpcsOrigin = []

                            def cpcsNormal = []

                            for (def i = 0; i < cpcArry.size(); i++ ) {

                                def section = cpcArry[i]['section']['value']

                                def classTag = cpcArry[i]['class']['value']

                                def subclass = cpcArry[i]['subclass']['value']

                                def mainGroup = cpcArry[i]['main-group']['value']

                                def subGroup = cpcArry[i]['subgroup']['value']

                                def cpcOrigin = section + classTag + subclass + " " + mainGroup + "/" + subGroup

                                cpcsOrigin << cpcOrigin

                                def cpcNormal = normalizeClassificationNumber(section + classTag + subclass + "-" + mainGroup + "/" + subGroup, 'CPC')

                                if (!!cpcNormal) {

                                    cpcsNormal << cpcNormal

                                } else {

                                    throw new Exception("cpc miss")

                                }

                            }

                            if (cpcsOrigin.size() > 0) {

                                newUsptoInfoDoc << ['mainCPC' : cpcsOrigin[0]]

                                newUsptoInfoDoc << ['cpcs' : cpcsOrigin]

                            }

                            if (cpcsNormal.size() > 0) {

                                newUsptoInfoDoc << ['mainCPCNormal' : cpcsNormal[0]]

                                newUsptoInfoDoc << ['cpcsNormal' : cpcsNormal]

                            } else {

                                throw new Exception("cpc miss")

                            }

                        }

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'CPC error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        println "CPC error: " + e

                    }

                    //uspc(含正規化) includes mainUSPC, uspcs
                    try {

                        if (!!biblio['classification-national']) {

                            def uspc = biblio['classification-national']

                            def uspcsNormal = []

                            def uspcMain = uspc['main-classification']['text']

                            if (!!uspcMain) {

                                uspcsNormal << uspcMain

                                newUsptoInfoDoc << ['mainUSPC' : uspcMain]

                                newUsptoInfoDoc << ['mainUSPCNormal' : uspcMain]

                            }

                            def uspcFurthers = uspc['main-classification']['further-classification']

                            if (!!uspcFurthers) {

                                for (def i = 0; i < uspcFurthers.size(); i++ ) {

                                    uspcsNormal << uspcFurthers[i]['text']

                                }

                            }

                            if (uspcsNormal.size() > 0) {

                                newUsptoInfoDoc << ['uspcs' : uspcsNormal]

                                newUsptoInfoDoc << ['uspcsNormal' : uspcsNormal]

                            } else {

                                throw new Exception("uspc miss")

                            }

                        }

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'USPC error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        println "USPC error: " + e

                    }

                    //TODO: LOC 目前LNBackFile 未包含Design, 故先不處理LOC

                    //parties => includes agent, inventor, applicants
                    try {

                        def parties = biblio['parties']

                        if (!!parties) {
                            //assignees
                            if (parties['applicants']) {

                                def applicants = parties['applicants']['applicant']

                                if (!!applicants) {

                                    def applicantName

                                    def applicantArry = []

                                    for (def i = 0; i < applicants.size(); i++ ) {

                                        def applicant = applicants[i]
                                        
                                        if (!!applicant['data-format']) {
                                            
                                            if (applicant['data-format'] == 'docdb') {
                                                
                                                continue
                                            }
                                            
                                        }

                                        def applicantAddressbook = applicant['addressbook'][0]

//                                                                        println JsonOutput.prettyPrint(applicantAddressbook.toString())

                                        if (applicantAddressbook['first-name']) {

                                            applicantName = applicantAddressbook['first-name'][0];

                                        }

                                        if (applicantAddressbook['last-name']) {

                                            applicantName = applicantAddressbook['last-name'][0] + "; " + applicantName;

                                        }

                                        if (applicantAddressbook['orgname']) {

                                            applicantName = applicantAddressbook['orgname'][0];

                                        }

                                        if (applicantAddressbook['address']) {

                                            def applicantAddress = applicantAddressbook['address'][0]

                                            def applicantCountry = applicantAddress['country'];

                                            def applicantFullAddr;

                                            if (applicantAddress['state']) {

                                                applicantFullAddr = applicantAddress['city'] + "," + applicantAddress['state'];

                                            } else {

                                                applicantFullAddr = applicantAddress['city'];

                                            }

                                            applicantArry << removeMapNullValue(["name" : ["origin" : applicantName], "address" : ["origin" : applicantFullAddr], "country" : ["origin" : applicantCountry]])

                                        } else {

                                            applicantArry << ["name" : ["origin" : applicantName]]

                                        }

                                        newUsptoInfoDoc << ['assignees' : unique(applicantArry)]

                                    }

                                }

                            }

                            //inventors
                            if (parties['inventors']) {

                                def inventors = parties['inventors']['inventor']

                                if (!!inventors) {

                                    def inventorArry = []

                                    for (def i = 0; i < inventors.size(); i++ ) {

                                        def inventor = inventors[i]
                                        
                                        if (!!inventor['data-format']) {
                                            
                                            if (inventor['data-format'] == 'docdb') {
                                                
                                                continue
                                            }
                                            
                                        }

                                        def inventorAddressbook = inventor['addressbook'][0]

                                        def invFullName;

                                        if (inventorAddressbook['first-name']) {

                                            invFullName = inventorAddressbook['first-name'][0];

                                        }

                                        if (inventorAddressbook['last-name']) {

                                            invFullName = inventorAddressbook['last-name'][0] + " " + invFullName;

                                        }

                                        if (inventorAddressbook['middle-name']) {

                                            invFullName = invFullName + " " + inventorAddressbook['middle-name'][0];

                                        }

                                        if (inventorAddressbook['suffix']) {

                                            invFullName = invFullName + " " + inventorAddressbook['suffix'][0];

                                        }
                                        
                                        if (inventorAddressbook['name']) {
                                            
                                            invFullName = inventorAddressbook['name'][0]['value']
                                        }

                                        //address
                                        if (inventorAddressbook['address']) {

                                            def inventorAddress = inventorAddressbook['address'][0]

                                            def inventorCountry = inventorAddress['country'];

                                            def inventorFullAddr;

                                            if (inventorAddress['state']) {

                                                inventorFullAddr = inventorAddress['city'] + "," + inventorAddress['state'];

                                            } else {

                                                inventorFullAddr = inventorAddress['city'];

                                            }

                                            if (!!inventorFullAddr) {
                                                
                                                inventorArry << removeMapNullValue(["name" : ["origin" : invFullName], "address" : ["origin" : inventorFullAddr], "country" : ["origin" : inventorCountry]])

                                            } else {
                                            
                                                inventorArry << removeMapNullValue(["name" : ["origin" : invFullName], "country" : ["origin" : inventorCountry]])

                                            }

                                        }

                                        newUsptoInfoDoc << ['inventors' : unique(inventorArry)]

                                    }

                                }

                            }

                            //agents
                            if (parties['agents']) {

                                def agents = parties['agents']['agent']

                                if (!!agents) {

                                    def agentArry = []

                                    def agentName

                                    for (def i = 0; i < agents.size(); i++ ) {

                                        def agent = agents[i]
                                        
                                        if (!!agent['data-format']) {
                                            
                                            if (agent['data-format'] == 'docdb') {
                                                
                                                continue
                                            }
                                            
                                        }

                                        def agentAddressbook = agent['addressbook'][0]

                                        if (agentAddressbook['first-name']) {

                                            agentName = agentAddressbook['first-name'][0]

                                        }

                                        if (agentAddressbook['last-name']) {

                                            agentName = agentName + " " + agentAddressbook['last-name'][0]

                                        }

                                        if (agentAddressbook['name']) {

                                            agentName = agentAddressbook['name'][0]['value']

                                        }

                                        agentArry << ["name" : ["origin" : agentName]]

                                    }

                                    newUsptoInfoDoc << ['agents' : unique(agentArry)]

                                }

                            }

                        }

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'parties error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "parties error: " + e
                    }
                    
                    //related US patent document include Reissue
                    try {

                        if (!!biblio['related-documents']) {

                            def relatePatentArry = []

                            def relatedDoc = biblio['related-documents']

                            //reissue
                            if (!!relatedDoc['reissue']) {

                                def reissues = relatedDoc['reissue']

                                for (def i = 0; i < reissues.size(); i++) {

                                    def reissue = reissues[i]

                                    if (!!reissue['relation'] && !!reissue['relation']['parent-doc']) {

                                        def parentDoc = reissue['relation']['parent-doc']

                                        def appDocs = parentDoc['document-id']

                                        def appDoc = appDocs[0]

                                        def grantDoc

                                        if (!!parentDoc['parent-grant-document'] && parentDoc['parent-grant-document']['document-id']) {

                                            grantDoc = parentDoc['parent-grant-document']['document-id'][0]

                                        }

                                        def relatedPatentMap = getRelatedPatentMap(appDoc, grantDoc)

                                        if (!!relatedPatentMap) {

                                            relatedPatentMap << ['relation' : 'ReissueOf']

                                            relatePatentArry << relatedPatentMap

                                        }

                                    }

                                }

                            }// end of reissue

                            //continuation
                            if (!!relatedDoc['continuation']) {

                                def continuations = relatedDoc['continuation']

                                for (def i = 0; i < continuations.size(); i++) {

                                    def continuation = continuations[i]

                                    if (!!continuation['relation'] && !!continuation['relation']['parent-doc']) {

                                        def parentDoc = continuation['relation']['parent-doc']

                                        def appDocs = parentDoc['document-id']

                                        def appDoc = appDocs[0]

                                        def grantDoc

                                        if (!!parentDoc['parent-grant-document'] && parentDoc['parent-grant-document']['document-id']) {

                                            grantDoc = parentDoc['parent-grant-document']['document-id'][0]

                                        }

                                        def relatedPatentMap = getRelatedPatentMap(appDoc, grantDoc)

                                        if (!!relatedPatentMap) {

                                            relatePatentArry << relatedPatentMap

                                        }

                                    }

                                }

                            }//end of continuation

                            //continuation-in-part
                            if (!!relatedDoc['continuation-in-part']) {

                                def continuationInParts = relatedDoc['continuation-in-part']

                                for (def i = 0; i < continuationInParts.size(); i++) {

                                    def continuationInPart = continuationInParts[i]

                                    if (!!continuationInPart['relation'] && !!continuationInPart['relation']['parent-doc']) {

                                        def parentDoc = continuationInPart['relation']['parent-doc']

                                        def appDocs = parentDoc['document-id']

                                        def appDoc = appDocs[0]

                                        def grantDoc

                                        if (!!parentDoc['parent-grant-document'] && parentDoc['parent-grant-document']['document-id']) {

                                            grantDoc = parentDoc['parent-grant-document']['document-id'][0]

                                        }

                                        def relatedPatentMap = getRelatedPatentMap(appDoc, grantDoc)

                                        if (!!relatedPatentMap) {

                                            relatePatentArry << relatedPatentMap

                                        }

                                    }

                                }

                            }//end of continuation-in-part

                            //division
                            if (!!relatedDoc['division']) {

                                def divisions = relatedDoc['division']

                                for (def i = 0; i < divisions.size(); i++) {

                                    def division = divisions[i]

                                    if (!!division['relation'] && !!division['relation']['parent-doc']) {

                                        def parentDoc = division['relation']['parent-doc']

                                        def appDocs = parentDoc['document-id']

                                        def appDoc = appDocs[0]

                                        def grantDoc

                                        if (!!parentDoc['parent-grant-document'] && parentDoc['parent-grant-document']['document-id']) {

                                            grantDoc = parentDoc['parent-grant-document']['document-id'][0]

                                        }

                                        def relatedPatentMap = getRelatedPatentMap(appDoc, grantDoc)

                                        if (!!relatedPatentMap) {

                                            relatePatentArry << relatedPatentMap

                                        }

                                    }

                                }

                            }//end of division

                            //provisional-application
                            if (!!relatedDoc['provisional-application']) {

                                def provisionalApplications = relatedDoc['provisional-application']

                                for (def i = 0; i < provisionalApplications.size(); i++) {

                                    def provisionalApplication = provisionalApplications[i]

                                    if (!!provisionalApplication['document-id']) {

                                        def appDoc = provisionalApplication['document-id'][0]

                                        def relatedPatentMap = getRelatedPatentMap(appDoc, null)

                                        if (!!relatedPatentMap) {

                                            relatePatentArry << relatedPatentMap

                                        }

                                    }

                                }

                            }// end of provisional-application

                            if (relatePatentArry.size() > 0) {

                                newUsptoInfoDoc << ['relatedPatents' : unique(relatePatentArry)]
                            }

                            //related-publication 部分為公開資訊 不納入DB

                        }

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'related US patent document error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "related US patent document error: " + e

                    }

                    //citedPatents
                    try {

                        if (!!biblio['references-cited']) {

                            if (!!biblio['references-cited']['citation']) {

                                def citationArry = []

                                def otherReferencesArry = []

                                def usCitations = biblio['references-cited']['citation']

                                for (def i = 0; i < usCitations.size(); i++) {

                                    def usCitation = usCitations[i]

                                    if (!!usCitation['patcit']) {

                                        def patcit = usCitation['patcit']

                                        def citationCountry = patcit['document-id'][0]['country']

                                        def citationDocNumber = patcit['document-id'][0]['doc-number']

                                        def citationKindcode = patcit['document-id'][0]['kind']

                                        def citationPatentNumber = citationCountry + citationDocNumber

                                        citationArry << ["patentNumber" : citationPatentNumber, "pto" : citationCountry]

                                    }

                                    if (!!usCitation['nplcit']) {

                                        def otherReference = usCitation['nplcit']['text'][0]

                                        otherReferencesArry << otherReference
                                    }

                                }
                                
                                if (citationArry.size() > 0) {
                                    
                                    newUsptoInfoDoc << ['citedPatents' : unique(citationArry)]

                                }

                                if (otherReferencesArry.size() > 0) {
                                    
                                    newUsptoInfoDoc << ['otherReferences' : otherReferencesArry]
                                    
                                }

                            }

                        }


                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'citedPatents error',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "citedPatents error: " + e

                    }//end of citedPatents

                    //examiners includes primary-examiner, assistant-examiner
                    try {

                        if (!!biblio['examiners']) {

                            if (!!biblio['examiners']['primary-examiner']) {

                                def primaryExaminer = biblio['examiners']['primary-examiner']

                                def primaryExaminerName

                                if (!!primaryExaminer['first-name']) {

                                    primaryExaminerName = primaryExaminer['first-name'][0]

                                }

                                if (!!primaryExaminer['last-name']) {

                                    primaryExaminerName = primaryExaminerName + " " + primaryExaminer['last-name'][0]

                                }

                                if (!!primaryExaminerName) {

                                    newUsptoInfoDoc << ['examinerMasters' : [['name' : ['origin' : primaryExaminerName]]]]

                                }

                            }

                            if (!!biblio['examiners']['assistant-examiner']) {

                                def slaveExaminer = biblio['examiners']['assistant-examiner']

                                def slaveExaminerName

                                if (!!slaveExaminer['first-name']) {

                                    slaveExaminerName = slaveExaminer['first-name'][0]

                                }

                                if (!!slaveExaminer['last-name']) {

                                    slaveExaminerName = slaveExaminerName + " " + slaveExaminer['last-name'][0]

                                }

                                if (!!slaveExaminerName) {

                                    newUsptoInfoDoc << ['examinerSlaves' : [['name' : ['origin' : slaveExaminerName]]]]

                                }

                            }

                        }

                    } catch (Exception e) {
                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'examiners error ',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw  "examiners error: " + e

                    }//end of examiners

                    //prioritypatents 優先權
                    try {

                        if (!!biblio['priority-claims'] && biblio['priority-claims']['priority-claim']) {

                            def priorityClaimArry = []

                            def priorityClaims = biblio['priority-claims']['priority-claim']

                            def priorityClaimsPto

                            def priorityClaimsAppNumber

                            def priorityClaimAppDate

                            for (def i = 0; i < priorityClaims.size(); i++) {

                                def priorityClaim = priorityClaims[i]

                                priorityClaimsPto = priorityClaim['country']

                                priorityClaimsAppNumber = priorityClaim['doc-number']

                                priorityClaimAppDate = priorityClaim['date']

                                def priorityClaimsAppNumberNormal

                                if (!!priorityClaimAppDate && !!priorityClaimsPto) {

                                    def priorityClaimAppYear = priorityClaimAppDate[0..3]

                                    priorityClaimsAppNumberNormal = priorityClaimsPto + priorityClaimAppYear + priorityClaimsAppNumber

                                } else {

                                    priorityClaimsAppNumberNormal = priorityClaimsAppNumber

                                }

                                priorityClaimArry << removeMapNullValue(["pto" : priorityClaimsPto, "appNumber" : priorityClaimsAppNumberNormal, "appDate" : toDate(priorityClaimAppDate)])

                            }

                            newUsptoInfoDoc << ['prioritypatents' : unique(priorityClaimArry)]

                        }

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'prioritypatents error ',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "prioritypatents error: " + e

                    }//end of prioritypatents

                    //pct  pctDate  pctNumber  pctOpenDate pctAppNumber
                    try {

                        if (!!biblio['pct-or-regional-filing-data']) {

                            if (!!biblio['pct-or-regional-filing-data']['document-id']) {

                                def pctDoc = biblio['pct-or-regional-filing-data']['document-id'][0]

                                def pctCountry = pctDoc['country'];

                                def pctAppNumber = pctDoc['doc-number'];

                                def pctAppDate = pctDoc['date'];

                                if (pctAppNumber) {

                                    newUsptoInfoDoc << ['pctAppNumber' : pctAppNumber]

                                }

                                if (pctAppDate) {

                                    newUsptoInfoDoc << ['pctAppDate' : toDate(pctAppDate)]

                                }

                            }


                        }//end of pct-or-regional-filing-data

                    } catch (Exception e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'PCT application error ',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "PCT application error: " + e

                    }

                    //pct-or-regional-publishing-data
                    try {

                        if (!!biblio['pct-or-regional-publishing-data']) {

                            if (!!biblio['pct-or-regional-publishing-data']['document-id']) {

                                def pctOpenDoc = biblio['pct-or-regional-publishing-data']['document-id'][0]

                                def pctCountry = pctOpenDoc['country']

                                def pctOpenNumber = pctOpenDoc['doc-number']

                                def pctOpenDate = pctOpenDoc['date']

                                if(!!pctOpenNumber){

                                    newUsptoInfoDoc << ['pctOpenNumber' : pctOpenNumber]

                                }

                                if (!!pctOpenDate) {

                                    newUsptoInfoDoc << ['pctOpenDate' : toDate(pctOpenDate)]

                                }

                            }

                        }//end of pct-or-regional-publishing-data

                    } catch (e) {

                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 3.toInteger(),
                                errMsg : 'PCT publication error ',
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "PCT publication error : " + e

                    }

                    if (!!oldUsptoDoc.applicants) {

                        newUsptoInfoDoc << ['applicants' : oldUsptoDoc.applicants]

                    }

                    //images fields start
                    if (!!oldUsptoDoc.filePageClaim) {

                        newUsptoInfoDoc << ['filePageClaim' : oldUsptoDoc.filePageClaim]

                    }

                    if (!!oldUsptoDoc.filePageDesc) {

                        newUsptoInfoDoc << ['filePageDesc' : oldUsptoDoc.filePageDesc]

                    }

                    if (!!oldUsptoDoc.filePageFig) {

                        newUsptoInfoDoc << ['filePageFig' : oldUsptoDoc.filePageFig]

                    }

                    if (!!oldUsptoDoc.filePageFirst) {

                        newUsptoInfoDoc << ['filePageFirst' : oldUsptoDoc.filePageFirst]

                    }

                    if (!!oldUsptoDoc.filePageNumber) {

                        newUsptoInfoDoc << ['filePageNumber' : oldUsptoDoc.filePageNumber]

                    }

                    if (!!oldUsptoDoc.clipPageNumber) {

                        newUsptoInfoDoc << ['clipPageNumber' : oldUsptoDoc.clipPageNumber]

                    }

                    if (!!oldUsptoDoc.figurePageNumber) {

                        newUsptoInfoDoc << ['figurePageNumber' : oldUsptoDoc.figurePageNumber]

                    }

                    //boolean 格式不能用"!!"判斷
                    if (oldUsptoDoc.firstImagePageFlag != null) {

                        newUsptoInfoDoc << ['firstImagePageFlag' : oldUsptoDoc.firstImagePageFlag]

                    }
                    //images fields end

                    //boolean 格式不能用"!!"判斷
                    if (oldUsptoDoc.truncate != null) {

                        newUsptoInfoDoc << ['truncate' : oldUsptoDoc.truncate]

                    }

                    //docdb merge field start
                    if (!!oldUsptoDoc.familyId) {

                        newUsptoInfoDoc << ['familyId' : oldUsptoDoc.familyId.toInteger()]

                    }

                    if (!!oldUsptoDoc.docdbDoDate) {

                        newUsptoInfoDoc << ['docdbDoDate' : oldUsptoDoc.docdbDoDate]

                    }

                    if (!!oldUsptoDoc.docdbAssignees) {

                        newUsptoInfoDoc << ['docdbAssignees' : oldUsptoDoc.docdbAssignees]

                    }

                    if (!!oldUsptoDoc.docdbaAssignees) {

                        newUsptoInfoDoc << ['docdbaAssignees' : oldUsptoDoc.docdbaAssignees]

                    }

                    if (!!oldUsptoDoc.docdbInventors) {

                        newUsptoInfoDoc << ['docdbInventors' : oldUsptoDoc.docdbInventors]

                    }

                    if (!!oldUsptoDoc.docdbaInventors) {

                        newUsptoInfoDoc << ['docdbaInventors' : oldUsptoDoc.docdbaInventors]

                    }

                    if (!!oldUsptoDoc.country) {

                        newUsptoInfoDoc << ['country' : oldUsptoDoc.country]

                    }

                    if (!!oldUsptoDoc.history) {

                        newUsptoInfoDoc << ['history' : oldUsptoDoc.history]

                    }
                    //docdb merge field end

                    if (!!oldUsptoDoc.relRawdatas) {

                        newUsptoInfoDoc << ['relRawdatas' : oldUsptoDoc.relRawdatas]

                    }

                    //saveTagAndJsfile
                    newUsptoInfoDoc << ['tagAndJsfile' : [['file' : 'UsptoParseLNBackFile.groovy', 'tag' : 'v1.0.0']]]

                    //最後修改時間
                    newUsptoInfoDoc['mongoSyncFlag'] << ['last' : new Date()]

                    //                println JsonOutput.prettyPrint(biblio.toString())

                    try {

                        //verify
                        PatentInfoFieldVerifyUtil.verify(newUsptoInfoDoc)

                    } catch (e) {
                    
                        missCnt++
                        
                        errCol.update(['_id': lnPatentNo],
                        [$set: [
                                errCode : 4.toInteger(),
                                errMsg : e,
                                doDate : oldUsptoDoc.doDate,
                                stat : oldUsptoDoc.stat,
                                type : oldUsptoDoc.type,
                                kindcode : oldUsptoDoc.kindcode,
                                lastUpdateTime : new Date(),
                                errHandle : false]
                        ], true)

                        throw "PatentInfoFieldVerify error : " + e

                    }

                    newUsptoInfoCol.update(['_id': newUsptoInfoDoc._id],[$set: newUsptoInfoDoc], true)

                    lnBackCol.update([patentNumber: lnPatentNo],[$set: [uspto: 1.toInteger(), doDate : oldUsptoDoc.doDate]], true)

                    oldUsptoInfoCol.update(['_id': oldUsptoDoc._id],[$set: ['lnBackFile': lnBackFileFlag.toInteger()]], true)

                }

            } catch (Exception e) {

                log << e << ln
                
                println e

            }

//                        break

        }

        println "missCnt/total: ${missCnt}/${total}, date range [${dateS} ~ ${dateE}]"

        return "pto ${pto} parsing..."

    } catch (Exception e) {

        println e

        return "process stop..."

    }


}

def normalizeClassificationNumber(classificationNumber, type) {

    def classificationNormal

    if (type == 'IPC' || type == 'CPC' ) {

        def arry = classificationNumber.split("-")

        def arry1 = arry[1].split("/")

        def mainGroup = arry1[0].toString();

        mainGroup = "0" * (4 - mainGroup.length()) + mainGroup

        def subGroup = arry1[1].toString();

        subGroup = subGroup + "0" * (6 - subGroup.length())

        classificationNormal = arry[0].toString() +  mainGroup + subGroup

    }

    return classificationNormal

}

def getPatentNubmer(country, docNumber) {

    def patentNubmer

    if (docNumber =~ /^\d{7}$/) {

        patentNubmer = country + "00" + docNumber

    } else if (docNumber =~ /^\d{8}$/){

        patentNubmer = country + "0" + docNumber

    } else if (docNumber =~ /^\d{11}$/){

        patentNubmer = docNumber

    }

    return patentNubmer

}

//appNumber normalize
def normalizeAppNumber(applCountry, appDate, applDocNumber) {

    def appNumberNormal = applCountry + appDate.substring(0, 4) + applDocNumber

}

def toDate(dateStr) {

    if (!dateStr) {

        return null

    }

    def year = dateStr[0..3].toString()

    def month = dateStr[4..5].toString()

    def day = dateStr[6..7].toString()

    def dateFormat = "yyyy/MM/dd'T'HH:mm:ss"

    TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

    def date = Date.parse(dateFormat, year + "/" + month + "/" + day + "T00:00:00")

    TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))

    return date

}

def getRelatedPatentMap(appDoc, grantDoc) {

    def relatedPatentMap = [:]

    def relatedAppCountry = (!!appDoc['country']) ? appDoc['country'] : ""

    def relatedAppNumber = (!!appDoc['doc-number']) ? appDoc['doc-number'] : ""

    def relatedAppDate = (!!appDoc['date']) ? appDoc['date'] : ""

    def relatedAppYear

    def relatedAppNumberNormal

    if (!!relatedAppDate && !!relatedAppCountry) {

        relatedAppYear = appDoc['date'][0..3]

        relatedAppNumberNormal = relatedAppCountry + relatedAppYear + relatedAppNumber

    } else {

        relatedAppNumberNormal = relatedAppNumber

    }

    def relatedGrantCountry

    def relatedGrantNumber

    def relatedGrantDate

    if (!!grantDoc) {

        relatedGrantCountry = (!!grantDoc['country']) ? grantDoc['country'] : ""

        relatedGrantNumber = (!!grantDoc['doc-number']) ? grantDoc['doc-number'] : ""

        relatedGrantDate = (!!grantDoc['date']) ? grantDoc['date'] : null

        relatedPatentMap << ['pto' : relatedAppCountry,
            'appNumber' : relatedAppNumberNormal,
            'appDate' : toDate(relatedAppDate),
            'patentNumber' : relatedGrantCountry + relatedGrantNumber,
            'issueDate' : relatedGrantDate]

    } else {

        //無公告資訊
        relatedPatentMap << ['pto' : relatedAppCountry,
            'appNumber' : relatedAppNumberNormal,
            'appDate' : toDate(relatedAppDate)]

    }

    return removeMapNullValue(relatedPatentMap)

}

//去除map中value為null
def removeMapNullValue(map) {
    
        def newMap = [:]
    
        for (e in map) {
            
            if (!!e.value) {

                if (e.value instanceof Map) {
                    
                    if(!!removeMapNullValue(e.value)) {
                        
                        newMap[e.key] = removeMapNullValue(e.value)
                        
                    }
                    
                } else {
                
                    newMap[e.key] = e.value
                    
                }
    
            }
    
        }
        
        return (newMap.size() > 0) ? newMap : null
    
    }

//排除List重複的值
def unique(arr){
    
    def dataStringArry = []
    
    def dataArry = []
    
    for(def i =0; i< arr.size();i++){
        //使用BasicDBObject將array轉為json
        if(dataStringArry.indexOf(new BasicDBObject(arr[i]).toString()) > -1){
            
            continue
            
        } else {
            
            dataStringArry << new BasicDBObject(arr[i]).toString()
            
            dataArry << arr[i]
            
        }
    }
    
    return dataArry;
}
