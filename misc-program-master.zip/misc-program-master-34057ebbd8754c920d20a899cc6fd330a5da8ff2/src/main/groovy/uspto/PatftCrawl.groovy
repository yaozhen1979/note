//@Grab('org.jsoup:jsoup:1.8.2')
//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*

def cli(args) {
    def cli = new CliBuilder(usage: 'PatftCrawl.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
        p longOpt: 'page',       args: 1, argName: 'pageNumber', 'Page Number'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "19770101", "-e", "19771231"]
def options = cli(args)
if (!options) {
    return
}


/**
 * USPTO 抓取
 */
def beginDate = options.b;
def endDate = options.e;
def pageNum = 1;
if (options.p) {
    pageNum = options.p as int
}

System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' ]

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentRawUSPTO").getCollection("PatFT")
def errColl = mongoClient.getDB("PatentRawUSPTO").getCollection("PatFTError")
def statColl = mongoClient.getDB("PatentRawUSPTO").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)
   
def nextPage = true;
def pageSize = 50;

def statId = "${beginDate}_${endDate}"
def date = new Date()
while (nextPage) {
    def doc = null;

    def retry = 0;
    while (retry < 50)  {
        try {
            doc = org.jsoup.Jsoup.connect("http://patft.uspto.gov/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&u=/netahtml/PTO/search-adv.htm&f=S&l=50&r=0&d=PTXT").timeout(300000)
                    .data("Query", "ISD/${dateBegin.format('MM/dd/yyyy')}->${dateEnd.format('MM/dd/yyyy')}")
                    .data("p", pageNum.toString())
                    .get();
            break;
        } catch (Exception e) {
            log e
            retry++;
            if(retry % 10==0) {
                Thread.sleep(1000*60*5)
            }
            log 'will retry list:' + retry
        }
    }
    if (doc == null) {
        log 'could not get list!';
        break;
    }

    def cnt = doc.select("strong")[2].text() as int
    def pages = ((cnt + pageSize - 1) / pageSize) as int
    log "date:${statId} cnt:${cnt} pages:${pageNum}/${pages}"
    if (pageNum == 1) {
        statColl.save([_id: statId, status: 0, total: cnt, createDate: date, from: beginDate, to: endDate])
    }
    
    def tbl = doc.select("table")[1];
    tbl.select("tr").each { tr ->
        def tds = tr.select("td")
        if (tds.size() == 4) {  //排除 title
            def url = tds[1].select('a').attr('href')
            //println "*** ${tds[0].text()} ${tds[1].text()} ${tds[3].text()}  ${url}"
            
            def row = [:]
            row._id = tds[1].text().trim().replaceAll(",", "");
            row.statId = statId
            row.statCount = cnt
            row.statSeq = tds[0].text().trim()
            row.title = tds[3].text().trim()
            row.createDate = new Date()
            try {
                def data = org.jsoup.Jsoup.connect("http://patft.uspto.gov${url}").timeout(300000).get().html();
                //def data = new URL("http://patft.uspto.gov${url}").getText()
                row.data = data
                collection.save(row);
            } catch (Exception e) {
                row.data = '';
                row.error = e.toString()
                errColl.save(row)
            }
            
        }
    }
    
    pageNum++
    if (pageNum > pages) {
        statColl.save([_id: statId, status: 1, total: cnt, createDate: date, from: beginDate, to: endDate])
        break
    }
}

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}
