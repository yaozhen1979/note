import java.text.SimpleDateFormat

import util.RestTimeProcess


/**
 * 美國聯邦法院訴訟信息
 *   https://dockets.justia.com/
 */
System.properties << [ 'https.proxyHost':'10.60.94.22', 'https.proxyPort':'3128' ]

def logFolder = "log/justia"

if (!new File(logFolder).exists()) {
    
    new File(logFolder).mkdirs()
    
}

def dateS = '2015-7-26'

def dateE = '2015-8-25'

File log = new File("${logFolder}/log-Justia-${dateS}")

File out = new File("${logFolder}/Justia-(${dateS}~${dateS}).txt")

def pageNum = 1

def count = getTotalCounts(dateS, dateE)

def totalPageNum = Math.ceil(count/10).intValue()

RestTimeProcess rtp = new RestTimeProcess(count, "Justia parse ${dateS} ~ ${dateE}", log)

def dataArry = []

while (true) {
    
    doc = org.jsoup.Jsoup.connect("https://dockets.justia.com/search")
        .timeout(100000)
        .data("noscat", "10")
        .data("cases", "between")
        .data("after", dateS)
        .data("before", dateE)
        .data("page", pageNum > 1 ? pageNum.toString()  : "")
        .get();
    
    def section = doc.select("section.clear")
    
    def queryResults = section.select("div.result")
    
    queryResults.each {
        
        rtp.process()
        
        def detailUrl = it.select("a.case-name").attr("href")
        
        def detailMap = getDetailMap(detailUrl)
        
        def row =  detailMap['Docket Number'] ? detailMap['Docket Number'] : "N/A"
            row += "\t"
            row += detailMap['Court'] ? detailMap['Court'] : "N/A"
            row += "\t"
            row += detailMap['Date Filed'] ? detailMap['Date Filed'] : "N/A"
            row += "\t"
            row += detailMap['Cause'] ? detailMap['Cause'] : "N/A"
            row += "\t"
            row += detailMap['Plaintiff'] ? detailMap['Plaintiff'] : "N/A"
            row += "\t"
            row += detailMap['Defendant'] ? detailMap['Defendant'] : "N/A"
             
        println row
                  
        out << row << "\r\n"
        
    }
    
    //last Page
    def wrapDiv = section.select("div")[0]
    
    def pageNumDiv = wrapDiv.select("div")[1]
    
    def lastPageFlag = false
    
    def pageInfo = pageNumDiv.text().trim()
    
    def total
    
    pageInfo.replaceAll(/Cases\s*(\S+)\s*-\s*(\S+)\s*of\s*(\S+)/) {fullMatch, pageStartNum, pageEndNum, totalNum ->
            
            def num1 = pageEndNum.toString().replaceAll(",", "")
            
            def num2 = totalNum.toString().replaceAll(",", "")
            
            lastPageFlag = Integer.valueOf(num1) == Integer.valueOf(num2)

    }
    //end of last Page
    
    println "page ${pageNum} / ${totalPageNum} total finish"
    
    if (lastPageFlag) {
        
        break
        
    } else {
    
        pageNum++
        
    }
    
}

println 'finished!'

def getTotalCounts(dateS, dateE) {
    
    def doc = org.jsoup.Jsoup.connect("https://dockets.justia.com/search")
    .timeout(100000)
    .data("noscat", "10")
    .data("cases", "between")
    .data("after", dateS)
    .data("before", dateE)
    .get();
    
    def total
    
    def section = doc.select("section.clear")
    
    def wrapDiv = section.select("div")[0]
    
    def pageNumDiv = wrapDiv.select("div")[1]
    
    def lastPageFlag = false
    
    def pageInfo = pageNumDiv.text().trim()
    
    pageInfo.replaceAll(/Cases\s*\S+\s*-\s*\S+\s*of\s*(\S+)/) {fullMatch, totalNum ->
            
            def num2 = totalNum.toString().replaceAll(",", "")
            
            total = Integer.valueOf(num2)
    
    }
    
    return total
}

def getDetailMap(detailUrl) {
    
    def detailDoc = org.jsoup.Jsoup.connect(detailUrl).timeout(100000).get()
    
    def tables = detailDoc.select("div#case-info-table").select("table")
    
    def map = [:]
    
    tables.each { table ->
        
        def trs = table.select("tbody > tr")
        
        trs.each {tr ->
            
            if (tr.select("th").html().contains("Plaintiff")) {
                
                map['Plaintiff'] = tr.select("td").html().trim()
                
            }
            
            if (tr.select("th").html().contains("Case Number")) {
                
                map['Docket Number'] = tr.select("td").html().trim()
                
            }
            
            if (tr.select("th").html().contains("Court")) {
                
                map['Court'] = tr.select("td").html().trim()
                
            }
            
            if (tr.select("th").html().contains("Nature of Suit")) {
                
                map['Cause'] = tr.select("td").html().trim()
                
            }
            
            if (tr.select("th").html().contains("Defendant")) {
                
                map['Defendant'] = tr.select("td").html().trim()
                
            }
            
            if (tr.select("th").html().contains("Filed")) {
                
                def date = tr.select("td").html().trim()
                
                map['Date Filed'] = toDate(date.toUpperCase())
                
            }
            
        }
        
    }
    
    return map
}

def toDate(date) {

    //TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

    SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH)

    def formatDate = sdf.parse(date).format("yyyy-MM-dd")

    // TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))

    return formatDate
}
