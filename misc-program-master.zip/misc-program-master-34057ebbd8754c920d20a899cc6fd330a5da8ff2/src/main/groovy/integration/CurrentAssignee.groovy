package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.apache.http.auth.*
import org.json.*
import org.slf4j.LoggerFactory

import util.MailUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.*


// shut down mongo driver log
Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

def cli(args) {
    def cli = new CliBuilder(usage: 'CurrentAssignee.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20151226", "-e", "20151231"]
def options = cli(args)
if (!options) {
    return
}

/**
 * CurrentAssignee -> 整合層
 * 
 * app_number 為唯一值(因 id 會變動)，目前 CurrentAssignee 會等到 solr 建完才進行更新，
 * 因此一定是等全文有了才會更新 CurrentAssignee
 * 申請號也會是全文的申請號
 */
def beginDate = options.b;
def endDate = options.e;

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.121", 27017), Arrays.asList(credential));
def currAsgCol = mongoClient.getDB("USPTO_CurrentAssignee_Lab").getCollection("USPTO_CurrentAssignee_Lab")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def integratcol = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("CurrentAssigneeError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)
    
DBCursor currAsgCursor = currAsgCol.find(
    [update_log: [$gte: dateBegin, $lt: dateEnd]])
    .sort([update_log: 1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
    
def currAsgTotal = currAsgCursor.count();
RestTimeProcess rts = new RestTimeProcess(currAsgTotal, "CurrAssignee_${beginDate}_${endDate}")
//log("total: ${total}")
def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "CurrAssignee_${beginDate}_${endDate}"
statColl.save([_id: statId, total: currAsgTotal, status: 0, createDate: date, from: beginDate, to: endDate])
while (currAsgCursor.hasNext()) {
    cnt++
    DBObject currAsgDoc = currAsgCursor.next();
    
    def appNumber = currAsgDoc.app_number;
    def newAppNumber = null;
    //去掉 , 取 / 後面的分出 serial 與 id
    def str = appNumber.replaceAll(",", "").split("/");
    /* 全文仍有申請號沒 serial 的情況
    if (str.length != 2) {
        error(errColl, srcObj, appNumber, 1, "appNumber err");
        continue;
    }*/
    if (str.length == 2) {
        if (str[0] == 'D') {
            newAppNumber = '29';
        } else {
            newAppNumber = str[0].padLeft(2, '0')
        }
        newAppNumber += "/" + str[1].padLeft(6, '0')
        if (!(newAppNumber ==~ /^[0-9]{2}\/[0-9]{6}$/)) {
            error(errColl, currAsgDoc, appNumber, 2, "appNumber err");
            continue;
        }
    } else {
        newAppNumber = str[0]
        if (!(newAppNumber ==~ /^[0-9]{6}$/)) {
            error(errColl, currAsgDoc, appNumber, 2, "appNumber err");
            continue;
        }
    }
    
    DBCursor integratDocs = integratcol.find(["appNumber": newAppNumber])
    if (integratDocs.count() == 0) {
        error(errColl, currAsgDoc, appNumber, 3, "appNumber not found!");
        continue;
    }
    def event = [name: "CurrentAssignee",
        id: appNumber,
        updatedDate: date]
    
    while (integratDocs.hasNext()) {
        DBObject integratDoc = integratDocs.next();
        integratDoc.currentAssignee = true
        integratDoc.lastUpdateDate = date
        def rel = integratDoc.relations;
        def currentAssignee = rel.CurrentAssignee;
        def events = integratDoc.events
        if (currentAssignee == null) {
            rel << [CurrentAssignee:[id: appNumber, updatedDate: date, 
                assigneeUpdatedDate: currAsgDoc.Current_Assignee_updatedDate,
                ]]
            event.log = "create"
        } else {
            //比對 ID 是否一致
            if (currentAssignee.id != appNumber) {
                error(errColl, currAsgDoc, number, 4, "id not match");
                continue;
            }
            currentAssignee.assigneeUpdatedDate = currAsgDoc.Current_Assignee_updatedDate
            event.log = "update"
        }
        integratDoc.currentAssigneeUpdateLog = currAsgDoc.update_log
        
        events << event
        
        integratcol.save(integratDoc)
    }
    
    saveCnt++;
    
    rts.process(currAsgDoc.update_log)
    //break;
}
log("cnt: $currAsgTotal saveCnt: $saveCnt")
statColl.save([_id: statId, total: currAsgTotal, status: 1, createDate: date, from: beginDate, to: endDate, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'
MailUtil.sendToPatentCloud("mikelin@patentcloud.com","CurrAssignee_${beginDate}_${endDate} finished!", "currAsgTotal: $currAsgTotal saveCnt: $saveCnt")

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.val = val
    doc.code = code
    doc.msg = msg
    errColl.save(doc)
    
    // send error mail
    MailUtil.sendToPatentCloud("mikelin@patentcloud.com","currAssignee Error", "Err: $code - $msg ==> $val")
}
