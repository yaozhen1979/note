package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')


import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*


/**
 * LN 訴訟資料 -> 整合層
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("LNBackFile").getCollection("Litigation")

def collection2 = mongoClient.getDB("IntegrationUS").getCollection("IntegrationUSBak")
def errColl = mongoClient.getDB("IntegrationUS").getCollection("LitigationError")

DBCursor cursor = collection.find().addOption(Bytes.QUERYOPTION_NOTIMEOUT);

def total = cursor.count();
log("total: ${total}")
def cnt = 0
def saveCnt = 0
def date = new Date()
while (cursor.hasNext()) {
    cnt++;
    DBObject srcObj = cursor.next();
    
//    {_id:/^US[0-9]{1,7}[ABC][12]?$/}   44074    >   US00 + num
//    {_id:/^USD[0-9]{7}S$/}   4240             >   US00xDxxxx
//    {_id:/^USRE[0-9]{6}(E|(F1))$/}  578       > 
//    {_id:/^USPP[0-9]{6}P[0-9]?$/}  215        >   US00xxPPxxx
    
    
    def number = srcObj._id;
    def docNumber = null;
    def matcher = number =~ /^US([0-9]{1,7})[ABC][12]?$/
    if (matcher.matches()) {
        docNumber = 'US00' + matcher.group(1).padLeft(7, '0')
    }
    if (docNumber == null) {
        matcher = number =~ /^USD([0-9]{7})S$/
        if (matcher.matches()) {
            def ns = 'D' + removeZero(matcher.group(1))
            docNumber = 'US00' + ns.padLeft(7, '0')
        }
    }
    if (docNumber == null) {
        matcher = number =~ /^USRE([0-9]{6})(E|(F1))$/
        if (matcher.matches()) {
            def ns = 'RE' + removeZero(matcher.group(1))
            docNumber = 'US00' + ns.padLeft(7, '0')
        }
    }
    if (docNumber == null) {
        matcher = number =~ /^USPP([0-9]{6})P[0-9]?$/
        if (matcher.matches()) {
            def ns = 'PP' + removeZero(matcher.group(1))
            docNumber = 'US00' + ns.padLeft(7, '0')
        }
    }
    if (docNumber == null || docNumber.length() != 11) {
        println "$number --> $docNumber"
    }
    def row = collection2.findOne([_id: docNumber])
    if (row == null) {
        error(errColl, srcObj, docNumber, 1, "patent not found!");
        continue
    }
    
    def rel = row.relations;
    def events = row.events
    def event = [name: "LitigationLN",
        id: srcObj._id,
        updatedDate: date,
        log: "create"]
    rel << [LitigationLN:[id: srcObj._id, updatedDate: date]]
    
    row.lastUpdateDate = date
    row.litigationLN = true
    
    collection2.save(row)
    
    saveCnt++
    if (cnt % 1000 == 0) {
        log(cnt + " / " + total )
    }
}
log("cnt: $total saveCnt: $saveCnt")

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def removeZero(def s) {
    def ns = '';
    for (char c : s) {
        if (c == '0' && ns == '') {
            continue;
        }
        ns += c;
    }
    return ns
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.val = val
    doc.code = code
    doc.msg = msg
    errColl.save(doc)
}
