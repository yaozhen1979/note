package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.bson.types.*
import org.slf4j.LoggerFactory

import util.MailUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.*

// shut down mongo driver log
Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

def cli(args) {
    def cli = new CliBuilder(usage: 'DOCDB.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20151201", "-e", "20151211"]
def options = cli(args)
if (!options) {
    return
}

/**
 * DOCDB US -> 整合層
 */
def beginDate = options.b;
def endDate = options.e;

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def infoDocdbCol = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def integratCol = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)

DBCursor infoDocdbCursor = infoDocdbCol.find(
    [country:'US', docdbDoDate: [$gte: dateBegin, $lt: dateEnd]])
    .sort([docdbDoDate: 1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

//DBCursor infoDocdbCursor = infoDocdbCol.find(['_id': new ObjectId("56705d1f8df6550b973672ba")])
    
def infoDocdbTotal = infoDocdbCursor.count();

RestTimeProcess rts = new RestTimeProcess(infoDocdbTotal, "DOCDB_${beginDate}_${endDate}")

def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "DOCDB_${beginDate}_${endDate}"
statColl.save([_id: statId, total: infoDocdbTotal, status: 0, createDate: date, from: beginDate, to: endDate])

while (infoDocdbCursor.hasNext()) {
    cnt++
    
    DBObject infoDocdbDoc = infoDocdbCursor.next();
    
    def number = infoDocdbDoc.patentNumber;
    def patterns = [/^D[1-9]+[0-9]*$/, /^H[1-9]+[0-9]*$/, /^RE[1-9]+[0-9]*$/, /^PP[1-9]+[0-9]*/, /^[1-9][0-9]*$/, /^T[1-9]+[0-9]*/]
    def flag = false;
    
    for (def p : patterns) {
        if (number ==~ p) {
            flag = true
            break;
        }
    }
    
    if (!flag) {
        error(errColl, infoDocdbDoc, number, 1, "number err1");
        continue;
    }
    
    if (infoDocdbDoc.type == "Plant" && infoDocdbDoc.stat == 2 && !number.startsWith("PP")) {
        number = 'PP' + number;
    }
    
    if (infoDocdbDoc.stat == 2 || number.startsWith("H") || number.startsWith("T")) {   //因 H,T 開頭的被處理為公開，因此額外判斷
        number = "US" + number.padLeft(9, '0')
    }
    
    if (number.length() != 11) {
        def err = true
        if (infoDocdbDoc.stat == 1) {
            if (number.length() == 10) {
                number = number.substring(0, 4) + '0' + number.substring(4)
                err = false
            }
        }
        if (err) {
            error(errColl, infoDocdbDoc, number, 2, "number err2");
            continue;
        }
    }
    
    def appNumber = infoDocdbDoc.appNumber
    def newAppNumber = null
    
    if (appNumber != null) {
        appNumber = appNumber.replaceAll("\\*", "")
        appNumber = appNumber.replaceAll("\\[", "")
        appNumber = appNumber.trim()
        //考慮 DOCDB 特有格式 ==> 60 49390 (空白前不參考)
        if (appNumber.contains(' ')) {
            appNumber = appNumber.split(' ')[1]
        }
        if (appNumber.length() == 8) {
            newAppNumber = appNumber.substring(0, 2) + "/" + appNumber.substring(2)
        } else {
            newAppNumber = appNumber;
        }
    }
    
    // println "patentNumber: $number"
    
    def integratDoc = integratCol.findOne(["_id": number])
    
    def init = integratDoc == null
    
    def event = [name: "DOCDB",
        id: infoDocdbDoc._id,
        updatedDate: date]
    
    if (init) {
        integratDoc = [:]
        integratDoc._id = number
        integratDoc.createdDate = date
        if (infoDocdbDoc.kindcode != null) {
            integratDoc.kindcode = infoDocdbDoc.kindcode
        }
        
        integratDoc.stat = infoDocdbDoc.stat
        integratDoc.docDate = infoDocdbDoc.doDate
        
        if (newAppNumber != null) {
            integratDoc.appNumber = newAppNumber
        }
        
        if (infoDocdbDoc.appDate != null) {
            integratDoc.appDate = infoDocdbDoc.appDate
        }
        
        integratDoc.fullText = false
        integratDoc.docdbDoDate = infoDocdbDoc.docdbDoDate
        event.log = "create"
    } else {
        //比對申請號
        if (integratDoc.appNumber != null && newAppNumber != null) {
            if (integratDoc.appNumber != newAppNumber) {
                if (procAppNumber(integratDoc.appNumber) != procAppNumber(newAppNumber)) {
                    error(errColl, infoDocdbDoc, appNumber, 4, "appNumber not match");
                    continue;
                }
            }
        }
    }
    
    integratDoc.lastUpdateDate = date
    integratDoc.docdb = true
    
    if (init) {
        integratDoc.relations = [:]
        integratDoc.events = []
    }
    
    def rel = integratDoc.relations;
    def events = integratDoc.events
    // relation docdb
    def relDocdb = rel.DOCDB;
    if (relDocdb == null) {
        // 如果整合層沒有 relation docdb 則新增
        rel << [DOCDB:[id: infoDocdbDoc._id, updatedDate: date]]
        event.log = "create"
        integratDoc.docdbDoDate = infoDocdbDoc.docdbDoDate
    } else {
        // docdbDoDate : 如果整合層有relation docdb 則比對 docdbDoDate，若整合層比較大，則跳過，若整合層比較小，則更新docdbDoDate
        if (infoDocdbDoc.docdbDoDate > integratDoc.docdbDoDate) {
            integratDoc.docdbDoDate = infoDocdbDoc.docdbDoDate
        }
        
        relDocdb.updatedDate = date
        
        //比對 ID 是否一致
        boolean isReplaceDocdbId = false
        if (relDocdb.id != infoDocdbDoc._id) {
            // println "docdb.id : $relDocdb.id , infoDocdbDoc._id: $infoDocdbDoc._id"
            
            def preRelDocdb = infoDocdbCol.findOne([_id: relDocdb.id])
            
            if (preRelDocdb == null) {
                // 如果整合層舊的rel docdb id 查尋不到則以新的docdbInfo id 替換
                relDocdb.id = infoDocdbDoc._id
                // docDate : 如果沒有全文資料且 docdbInfo 的 doDate 不等於整合層的 docDate， 以新的 docdbInfo 的 doDate 更換整合層的docDate
                if (!integratDoc.fullText) {
                    integratDoc.docDate = infoDocdbDoc.doDate
                }
                isReplaceDocdbId = true
            } else {
                // 比對 rel DOCDB doDate，以 doDate 大的為rel docdb id
                if (infoDocdbDoc.doDate > preRelDocdb.doDate) {
                    relDocdb.id = infoDocdbDoc._id
                }
            }
        }
        
        event.log = isReplaceDocdbId ? "update and fixed docdb id" : "update"
    }
    events << event
    
    // println "integratDoc : $integratDoc"
    
    integratCol.save(integratDoc)
    saveCnt++;
    
    rts.process(infoDocdbDoc.docdbDoDate)
    
}
log("infoDocdbTotal: $infoDocdbTotal saveCnt: $saveCnt")
statColl.save([_id: statId, total: infoDocdbTotal, status: 1, createDate: date, from: beginDate, to: endDate, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'

MailUtil.sendToPatentCloud("mikelin@patentcloud.com","DOCDB_${beginDate}_${endDate} finished!", "infoDocdbTotal: $infoDocdbTotal saveCnt: $saveCnt")

def procAppNumber(def s) {
    def cnt = 6
    if (s == null) {
        return s;
    }
    if (s.length() >= cnt) {
        return s.substring(s.length()-cnt)
    } else {
        return s.padLeft(cnt, '0')
    }
}

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.doDate = row.doDate
    doc.docdbDoDate = row.docdbDoDate
    doc.val = val
    doc.code = code
    doc.msg = msg
    doc.createdDate = new Date()
    errColl.save(doc)
}
