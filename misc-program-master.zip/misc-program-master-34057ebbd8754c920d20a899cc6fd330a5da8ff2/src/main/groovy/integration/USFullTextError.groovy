package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*

/**
 * USPTO 全文處理錯誤的(申請號只有6碼的) -> 整合層
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("IntegrationUS").getCollection("FullTextError")

def mongoClient3 = new GMongoClient(new ServerAddress("10.60.90.121", 27017), Arrays.asList(credential));
def collectionP = mongoClient3.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("FullTextError")

DBCursor cursor = collection.find([code: 3])

def total = cursor.count();
log("total: ${total}")
def cnt = 0
def saveCnt = 0
def date = new Date()
while (cursor.hasNext()) {
    cnt++;
    DBObject errObj = cursor.next();
    
    DBObject srcObj = collectionP.findOne([_id: errObj._id]);
    
    def number = srcObj.patentNumber;
    if (number.length() != 11 || (srcObj.stat == 2 && !number.startsWith("US00"))) {
        error(errColl, srcObj, number, 1, "number err");
        continue;
    }
    def docNumber = '';
    if (srcObj.stat == 1) {
        docNumber = srcObj.openNumber
    } else if (srcObj.stat == 2) {
        docNumber = srcObj.decisionNumber
    } else {
        error(errColl, srcObj, number, 2, "stat err");
        continue;
    }
    
    def appNumber = srcObj.appNumber
    def newAppNumber = null
    if (appNumber != null) {
        //去掉 , 取 / 後面的分出 serial 與 id
        //目前可能為空，待盤查，一樣先進整合層
        def str = appNumber.replaceAll(",", "").split("/");
        /*if (str.length != 2) {
            error(errColl, srcObj, appNumber, 3, "appNumber err");
            continue;
        }
        if (str[0] == 'D') {
            newAppNumber = '29';
        } else {
            newAppNumber = str[0].padLeft(2, '0')
        }
        newAppNumber += "/" + str[1].padLeft(6, '0')
        if (!(newAppNumber ==~ /^[0-9]{2}\/[0-9]{6}$/)) {
            error(errColl, srcObj, appNumber, 4, "appNumber err");
            continue;
        }*/
        newAppNumber = appNumber;
    }
    
    def row = collection2.findOne(["_id": number])
    def init = row == null
    def event = [name: "USPTO",
        id: srcObj._id,
        updatedDate: date]
    if (init) {
        row = [:]
        row._id = number
        row.createdDate = date
        event.log = "create"
        row.docdb = false
    }
    
    row.lastUpdateDate = date
    row.docNumber = docNumber
    if (srcObj.kindcode != null) {
        row.kindcode = srcObj.kindcode
    }
    row.stat = srcObj.stat
    row.docDate = srcObj.doDate
    if (newAppNumber != null) {
        if (row.appNumber != null && row.appNumber != newAppNumber) {
            error(errColl, srcObj, appNumber, 5, "appNumber not match");
            continue;
        }
        row.appNumber = newAppNumber
    }
    if (srcObj.appDate != null) {
        row.appDate = srcObj.appDate
    }
    row.fullText = true
    
    if (init) {
        row.relations = [:]
        row.events = []
    }
    def rel = row.relations;
    def events = row.events
    def uspto = rel.USPTO;
    if (uspto == null) {
        //無全文資料，補上 Relation
        rel << [USPTO:[id: srcObj._id, updatedDate: date]]
        event.log = "create"
    } else {
        //比對 ID 是否一致
        if (uspto.id != srcObj._id) {
            error(errColl, srcObj, number, 6, "id not match");
            continue;
        }
        event.log = "update"
    }
    events << event
    
    collection2.save(row)
    saveCnt++
    if (cnt % 1000 == 0) {
        log(cnt + " / " + total + " --> " + srcObj.doDate)
    }
}
log("cnt: $total saveCnt: $saveCnt")

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.doDate = row.doDate
    doc.docdbDoDate = row.docdbDoDate
    doc.val = val
    doc.code = code
    doc.msg = msg
    //errColl.save(doc)
}


