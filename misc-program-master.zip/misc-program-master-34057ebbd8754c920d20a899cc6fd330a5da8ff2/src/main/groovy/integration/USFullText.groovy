package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.slf4j.LoggerFactory

import util.MailUtil;
import util.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.*

// shut down mongo driver log
Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

def cli(args) {
    def cli = new CliBuilder(usage: 'USFullText.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20151217", "-e", "20151225"]
def options = cli(args)
if (!options) {
    return
}

/**
 * USPTO 全文 -> 整合層
 */
def beginDate = options.b;
def endDate = options.e;

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.121", 27017), Arrays.asList(credential));
def infoCol = mongoClient.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def integratCol = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("FullTextError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)
    
DBCursor infoCur = infoCol.find(
    [doDate: [$gte: dateBegin, $lt: dateEnd]])
    .sort([doDate: 1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

//DBCursor cursor = collection.find(
//    [patentNumber: "US006961184"])

def infoTotal = infoCur.count();

RestTimeProcess rts = new RestTimeProcess(infoTotal, "USFull_${beginDate}_${endDate}")
//log("infoTotal: ${infoTotal}")
def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "USFull_${beginDate}_${endDate}"
statColl.save([_id: statId, total: infoTotal, status: 0, createDate: date, from: beginDate, to: endDate])
while (infoCur.hasNext()) {
    cnt++;
    DBObject infoDoc = infoCur.next();
    
    def number = infoDoc.patentNumber;
    
//    log("patentNumber : $number")
    if (number.length() != 11 || (infoDoc.stat == 2 && !number.startsWith("US00"))) {
        error(errColl, infoDoc, number, 1, "number err");
        continue;
    }
    def docNumber = '';
    if (infoDoc.stat == 1) {
        docNumber = infoDoc.openNumber
    } else if (infoDoc.stat == 2) {
        docNumber = infoDoc.decisionNumber
    } else {
        error(errColl, infoDoc, number, 2, "stat err");
        continue;
    }
    
    def appNumber = infoDoc.appNumber
    
    def newAppNumber = null
    if (!!appNumber) {
        //去掉 , 取 / 後面的分出 serial 與 id
        //目前可能為空，待盤查，一樣先進整合層
        def str = appNumber.replaceAll(",", "").split("/");
        if (str.length != 2) {
            error(errColl, infoDoc, appNumber, 3, "appNumber err");
            continue;
        }
        
        // rebuild appNumber
        if (str[0] == 'D') {
            newAppNumber = '29';
        } else {
            newAppNumber = str[0].padLeft(2, '0')
        }
        newAppNumber += "/" + str[1].padLeft(6, '0')
        
//        log("newAppNumber: $newAppNumber")
        
        // check appNumber
        if (!(newAppNumber ==~ /^[0-9]{2}\/[0-9]{6}$/)) {
            error(errColl, infoDoc, appNumber, 4, "appNumber err");
            continue;
        }
    }
    
    def integratDoc = integratCol.findOne(["_id": number])
    def init = integratDoc == null
    
    // generate eventDoc
    def eventDoc = [name: "USPTO",
        id: infoDoc._id,
        updatedDate: date]
    
    // generate integratDoc
    if (init) {
        integratDoc = [:]
        integratDoc._id = number
        integratDoc.createdDate = date
        eventDoc.log = "create"
        integratDoc.docdb = false
    }
    
    integratDoc.lastUpdateDate = date
    integratDoc.docNumber = docNumber
    if (!!infoDoc.kindcode) {
        integratDoc.kindcode = infoDoc.kindcode
    }
    integratDoc.stat = infoDoc.stat
    integratDoc.docDate = infoDoc.doDate
    if (!!newAppNumber) {
        if (integratDoc.appNumber != null && integratDoc.appNumber != newAppNumber) {
            error(errColl, infoDoc, appNumber, 5, "appNumber not match");
            continue;
        }
        integratDoc.appNumber = newAppNumber
    }
    if (!!infoDoc.appDate) {
        integratDoc.appDate = infoDoc.appDate
    }
    integratDoc.fullText = true
    
    if (init) {
        integratDoc.relations = [:]
        integratDoc.events = []
    }
    
//    log("integratDoc: $integratDoc")
    def rel = integratDoc.relations;
    def events = integratDoc.events
    def uspto = rel.USPTO;
    if (uspto == null) {
        //無全文資料，補上 Relation
        rel << [USPTO:[id: infoDoc._id, updatedDate: date]]
        eventDoc.log = "create"
    } else {
        //比對 ID 是否一致
        if (uspto.id != infoDoc._id) {
            error(errColl, infoDoc, number, 6, "id not match");
            continue;
        }
        uspto.updatedDate = date
        eventDoc.log = "update"
    }
    events << eventDoc
    
    integratCol.save(integratDoc)
    saveCnt++
    
    rts.process(infoDoc.doDate)
//    break;
}
log("cnt: $infoTotal saveCnt: $saveCnt")
statColl.save([_id: statId, total: infoTotal, status: 1, createDate: date, from: beginDate, to: endDate, finishedDate: new Date(), saveCount: saveCnt])

log('finished!')

MailUtil.sendToPatentCloud("mikelin@patentcloud.com","USFull_${beginDate}_${endDate} integratUS finished!", "infoTotal: $infoTotal saveCnt: $saveCnt")

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.doDate = row.doDate
    doc.val = val
    doc.code = code
    doc.msg = msg
    errColl.save(doc)
    
    // send error mail
    MailUtil.sendToPatentCloud("mikelin@patentcloud.com","integratUS Error", "Err: $code - $msg ==> $val")
}
