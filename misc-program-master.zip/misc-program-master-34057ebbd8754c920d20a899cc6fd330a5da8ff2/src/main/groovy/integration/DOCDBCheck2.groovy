package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*


def cli(args) {
    def cli = new CliBuilder(usage: 'DOCDB.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20100101", "-e", "20110101"]
def options = cli(args)
if (!options) {
    return
}

def beginDate = options.b;
def endDate = options.e;

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)
    
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def chkColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbCheck2")

DBCursor cursor = collection2.find(
    [docDate: [$gte: dateBegin, $lt: dateEnd], docdb: true], ['relations.DOCDB.id' : 1])
    .sort([docDate: 1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
    
def total = cursor.count();
log("$beginDate ~ $endDate total: ${total}")
def cnt = 0
while (cursor.hasNext()) {
    DBObject srcObj = cursor.next();
    cnt++
    if (cnt % 1000 == 0) {
        log("$beginDate~$endDate " + cnt + " / " + total + " --> " + srcObj.docDate)
    }
    
    def e = collection.findOne([_id: srcObj.relations.DOCDB.id])
    if (e != null) {
        continue
    }
    chkColl.save([_id: srcObj._id])
}
println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

