package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.apache.http.auth.*
import org.json.*

import util.MailUtil
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.*
import groovy.sql.Sql

def cli(args) {
    def cli = new CliBuilder(usage: 'CurrentAssignee.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20160107", "-e", "20160108"]
def options = cli(args)
if (!options) {
    return
}

/**
 * assignment -> 整合層
 * 
 * 只寫 event 與 lastUpdateDate
 */
def beginDate = options.b;
def endDate = options.e;

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.155", 27017), Arrays.asList(credential));
def integratcol = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("AssignmentError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)

def sql = Sql.newInstance("jdbc:mysql://10.60.90.75/Assignment", "allenwu", "allenwu", 'com.mysql.jdbc.Driver' )
def sqlstr = "from AssignmentETL where Updated between ? and ?"

def row = sql.firstRow("select count(*) cnt $sqlstr", [dateBegin, dateEnd]);
int totalCnt = row.cnt
    
log("total: ${totalCnt}")
def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "Assignment_${beginDate}_${endDate}"
statColl.save([_id: statId, total: totalCnt, status: 0, createDate: date, from: beginDate, to: endDate])

sql.eachRow("select * $sqlstr", [dateBegin, dateEnd]) { it ->
    DBCursor patents = integratcol.find([appNumber: it.appNumber])
    while (patents.hasNext()) {
        DBObject integratDoc = patents.next();
        integratDoc.lastUpdateDate = date
        
        def event = [name: "Assignment",
            updatedDate: date]
        
        integratDoc.events << event
        
        integratDoc.assignments = true
        
        integratcol.save(integratDoc)
        
        saveCnt++;
    }
}
log("cnt: $totalCnt saveCnt: $saveCnt")
statColl.save([_id: statId, total: totalCnt, status: 1, createDate: date, from: beginDate, to: endDate, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

