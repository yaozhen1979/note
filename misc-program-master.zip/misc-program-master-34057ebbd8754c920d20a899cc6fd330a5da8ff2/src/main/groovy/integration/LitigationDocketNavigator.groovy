package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.bson.types.*
import org.slf4j.LoggerFactory

import util.MailUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.*

// shut down mongo driver log
Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

def cli(args) {
    def cli = new CliBuilder(usage: 'DOCDB.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20160126", "-e", "20160205"]
def options = cli(args)
if (!options) {
    return
}

/**
 * Docket Navigation -> 整合層
 */
def beginDate = options.b;
def endDate = options.e;

MongoCredential credential = MongoCredential.createCredential("datateamread","admin","datateamread".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def dnColl = mongoClient.getDB("DocketNavigator").getCollection("DocketNavigator")

MongoCredential credential2 = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.155", 27017), Arrays.asList(credential2));
def integratColl = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("DocketNavigationError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)

DBCursor dnCursor = dnColl.find(
    [lastUpdated: [$gte: dateBegin, $lt: dateEnd]]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

def totalCnt = dnCursor.count();

def statId = "DocketNavigator_${beginDate}_${endDate}"

def cnt = 0
def saveCnt = 0
def date = new Date()
statColl.save([_id: statId, total: totalCnt, status: 0, createDate: date, from: beginDate, to: endDate])

log("$statId ==> totalCnt: $totalCnt")
while (dnCursor.hasNext()) {
    cnt++
    
    DBObject dnDoc = dnCursor.next();
    
    def patents = dnDoc.patents;
    patents.each { it ->
        def matcher = it =~ /^PP(0*)([1-9][0-9]*)$/
        def number = it
        if (matcher.matches()) {
            number = ('PP' + matcher.group(2)).padLeft(7, '0')
        }
        number = 'US00' + number
        
        def integratDoc = integratColl.findOne(["_id": number])
        if (integratDoc == null) {
            error(errColl, dnDoc, number, '01', 'patent not found.')
            return
        }
        
        def event = [name: "DocketNavigator",
            id: dnDoc._id,
            updatedDate: date]
        
        integratDoc.lastUpdateDate = date
        integratDoc.litigationDN = true
        def rels = integratDoc.relations.LitigationDN
        if (rels == null) {
            rels = []
            integratDoc.relations.LitigationDN = rels
        }
        def events = integratDoc.events
        //check all litigations
        def flag = false
        for (def r : rels) {
            def dn = dnColl.findOne([_id: r.id])
            if (dn != null && dn.id == dnDoc.id) {
                //同一筆資料的更新
                flag = true
                r.id = dnDoc._id
                r.updatedDate = date
                event.log = "update"
                break
            }
        }
        if (!flag) {
            event.log = "create"
            rels << [id: dnDoc._id, updatedDate: date]
        }
        events << event
        
        integratColl.save(integratDoc)
        saveCnt++;
    }
}
log("totalCnt: $totalCnt saveCnt: $saveCnt")
statColl.save([_id: statId, total: totalCnt, status: 1, createDate: date, from: beginDate, to: endDate, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.docdbDoDate = row.docdbDoDate
    doc.val = val
    doc.code = code
    doc.msg = msg
    doc.createdDate = new Date()
    errColl.save(doc)
}
