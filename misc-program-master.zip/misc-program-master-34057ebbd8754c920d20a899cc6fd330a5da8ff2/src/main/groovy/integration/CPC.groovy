package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*

def cli(args) {
    def cli = new CliBuilder(usage: 'CPC.groovy -[hf]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                      'Show usage information'
        f longOpt: 'file-name', args: 1, argName: 'yyyy/MM/dd', 'File Name'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-f", "US_Grant_CPC_MCF_3200000.xml"]
def options = cli(args)
if (!options) {
    return
}

String fileName = options.f

/**
 * CPC -> 整合層
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("USPTO").getCollection("CPC_201510")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("CPCError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

DBCursor cursor = collection.find(
    [fileName: fileName]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

def total = cursor.count();
def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "CPC_${fileName}"
log(statId + " total: ${total}")
//statColl.save([_id: statId, total: total, status: 0, createDate: date, fileName: fileName])
while (cursor.hasNext()) {
    cnt++;
    DBObject srcObj = cursor.next();
    
    def number = srcObj._id;
    
    def row = collection2.findOne(["_id": number])
    
    if (row == null) {
        error(errColl, srcObj, number, 6, "patent not found");
        continue
    }
    def event = [name: "CPC",
        id: srcObj._id,
        updatedDate: date]
    
    row.lastUpdateDate = date
    row.cpc = true
    
    def rel = row.relations;
    def events = row.events
    def cpc = rel.cpc;
    if (cpc == null) {
        rel << [cpc:[id: srcObj._id, updatedDate: date]]
        event.log = "create"
    } else {
        cpc.updatedDate = date
        event.log = "update"
    }
    events << event
    
    //collection2.save(row)
    saveCnt++
    if (cnt % 10000 == 0) {
        log(statId + " " + cnt + " / " + total + " --> " + srcObj.date)
    }
}
log("cnt: $total saveCnt: $saveCnt")
//statColl.save([_id: statId, total: total, status: 1, createDate: date, fileName: fileName, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.fileName = row.fileName
    doc.val = val
    doc.code = code
    doc.msg = msg
    //errColl.save(doc)
}
