package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*

def cli(args) {
    def cli = new CliBuilder(usage: 'USPC.groovy -[hc]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                      'Show usage information'
        c longOpt: 'coll-name', args: 1, argName: 'yyyy/MM/dd', 'Collection Name'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-c", "USPC_Pat_201506"]
//def args = ["-c", "USPC_Appl_201506"]
def options = cli(args)
if (!options) {
    return
}

/**
 * USPC -> 整合層
 */
String coll = options.c
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("USPTO").getCollection(coll)

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("USPCError")
def statColl = mongoClient2.getDB("IntegrationUS").getCollection("Stat")

//DBCursor cursor = collection.find([_id: [$regex: /6961184/]]).limit(10).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
DBCursor cursor = collection.find().addOption(Bytes.QUERYOPTION_NOTIMEOUT);

def total = cursor.count();
def cnt = 0
def saveCnt = 0
def date = new Date()
def statId = "${coll}"
log(statId + " total: ${total}")
//statColl.save([_id: statId, total: total, status: 0, createDate: date])
while (cursor.hasNext()) {
    cnt++;
    DBObject srcObj = cursor.next();
    
    def number = srcObj._id;
    
    boolean appl = coll.contains("_Appl_");
    
    if (!appl) {
        def matcher = number =~ /^(PP|RE|RX|[DHTX])?(?:0*)([1-9][0-9]*)$/
        if (matcher.matches()) {
            if (matcher.group(1) != null) {
                number = 'US00' + (matcher.group(1) + matcher.group(2)).padLeft(7, '0')
            } else {
                number = 'US00' + matcher.group(2).padLeft(7, '0')
            }
        } else {
            error(errColl, srcObj, srcObj._id, 6, "number format error");
            continue
        }
    }
    
    def row = collection2.findOne(["_id": number])
    
    if (row == null) {
        error(errColl, srcObj, number, 6, "patent not found");
        continue
    }
    def event = [name: "USPC",
        id: srcObj._id,
        updatedDate: date]
    
    row.lastUpdateDate = date
    row.uspc = true
    
    def rel = row.relations;
    def events = row.events
    def uspc = rel.uspc;
    if (uspc == null) {
        rel << [uspc:[id: srcObj._id, updatedDate: date]]
        event.log = "create"
    } else {
        uspc.updatedDate = date
        event.log = "update"
    }
    events << event
    
    //collection2.save(row)
    saveCnt++
    if (cnt % 10000 == 0) {
        log(statId + " " + cnt + " / " + total)
    }
}
log("cnt: $total saveCnt: $saveCnt")
//statColl.save([_id: statId, total: total, status: 1, createDate: date, finishedDate: new Date(), saveCount: saveCnt])

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg (${row._id}) ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.val = val
    doc.code = code
    doc.msg = msg
    //errColl.save(doc)
}
