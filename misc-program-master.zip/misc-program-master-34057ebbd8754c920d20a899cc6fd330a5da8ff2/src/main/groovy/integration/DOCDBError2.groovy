package integration

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*
import org.bson.types.*


/*
 * 由於 docdb 後來刪除重複，因此需把整合層的關聯修復 
 * 盤查出 400筆，全為公告，找出後，由 event 找 docdb id 更新回 relation
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbCheck3")

DBCursor cursor = errColl.find().addOption(Bytes.QUERYOPTION_NOTIMEOUT);
    
def total = cursor.count();
log("total: ${total}")
def cnt = 0
def saveCnt = 0
def date = new Date()
while (cursor.hasNext()) {
    cnt++
    
    DBObject srcObj1 = cursor.next();
    
    
    def srcObj = collection2.findOne(["_id": srcObj1._id])
    
    def rel = srcObj.relations;
    def events = srcObj.events
    
    def find = false
    for (def event in events) {
        if (event.name == 'DOCDB') {
            def docdb = collection.findOne(["_id": event.id]);
            if (docdb != null) {
                find = true
                rel.DOCDB.id = docdb._id
                break
            }
        }
    }
    if (!find) {
        log("error:${srcObj1._id}")
        continue
    }
    
    srcObj.lastUpdateDate = date
    
    def event = [name: "DOCDB",
        id: rel.DOCDB.id,
        updatedDate: date, 
        log: "fixed docdb missing problem"]
    events << event
    //log(srcObj)
    collection2.save(srcObj)
    saveCnt++
}
log("cnt: $total saveCnt: $saveCnt")

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

