package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*


def cli(args) {
    def cli = new CliBuilder(usage: 'DOCDB.groovy -[hbe]')
    // Create the list of options.
    cli.with {
        h longOpt: 'help',                                       'Show usage information'
        b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
        e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
    }
    def options = cli.parse(args)
    if (!options) {
        return
    }
    if (options.h) {
        cli.usage()
        return
    }
    return options;
}

def args = ["-b", "20151015", "-e", "20151016"]
def options = cli(args)
if (!options) {
    return
}

/**
 * DOCDB US -> 整合層
 */
def beginDate = options.b;
def endDate = options.e;

def dateBegin = Date.parse("yyyyMMdd", beginDate)
def dateEnd = Date.parse("yyyyMMdd", endDate)
    
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbError")
def chkColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbCheck")

DBCursor cursor = collection.find(
    [docdbDoDate: [$gte: dateBegin, $lt: dateEnd], country: 'US'])
    .sort([docdbDoDate: 1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
    
def total = cursor.count();
log("$beginDate ~ $endDate total: ${total}")
def cnt = 0
while (cursor.hasNext()) {
    DBObject srcObj = cursor.next();
    cnt++
    if (cnt % 1000 == 0) {
        log(cnt + " / " + total + " --> " + srcObj.docdbDoDate)
    }
    
    def e = errColl.findOne([_id: srcObj._id])
    if (e != null) {
        continue
    }
    
    def c = collection2.count(["relations.DOCDB.id": srcObj._id])
    if (c != 1) {
        log('size err:' + srcObj._id + " cnt: " + c)
        chkColl.save([_id: srcObj._id, cnt: c])
    }
    
}
println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

