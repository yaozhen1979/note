package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*


/**
 * DOCDB Patch 程式，補放 docdbDoDate
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUS")

//DBCursor cursor = collection2.find([docdb: true, docdbDoDate: [$exists: false]]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
DBCursor cursor = collection2.find(["_id" : "US003931610"]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

def total = cursor.count();
log("total: ${total}")
def cnt = 0
while (cursor.hasNext()) {
    cnt++
    DBObject srcObj = cursor.next();
    
    def row = collection.findOne([_id: srcObj.relations.DOCDB.id], [docdbDoDate:1])
    collection2.update([_id: srcObj._id], [$set: [docdbDoDate: row.docdbDoDate]])
    
    if (cnt % 1000 == 0) {
        log(cnt + " / " + total)
    }
}
log("cnt: $total")

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

