package integration

//@Grab('org.mongodb:mongo-java-driver:2.13.0')
//@Grab('com.gmongo:gmongo:1.5')

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import com.gmongo.GMongoClient
import com.mongodb.*

/**
 * DOCDB US 錯誤的 -> 整合層
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("PatentInfoDOCDB")

def mongoClient2 = new GMongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));
def collection2 = mongoClient2.getDB("IntegrationUS").getCollection("IntegrationUSBak")
def errColl = mongoClient2.getDB("IntegrationUS").getCollection("DocdbErrorBak2")

DBCursor cursor = errColl.find(
    [code: 5]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
    
def total = cursor.count();
log("total: ${total}")
def cnt = 0
def saveCnt = 0
def date = new Date()
while (cursor.hasNext()) {
    cnt++
    DBObject errObj = cursor.next();
    DBObject srcObj = collection.findOne([_id:errObj._id]);
    
    def number = srcObj.patentNumber;
    def patterns = [/^D[1-9]+[0-9]*$/, /^H[1-9]+[0-9]*$/, /^RE[1-9]+[0-9]*$/, /^PP[1-9]+[0-9]*/, /^[1-9][0-9]*$/]
    def flag = false;
    for (def p : patterns) {
        if (number ==~ p) {
            flag = true
            break;
        }
    }
    if (!flag) {
        error(errColl, srcObj, number, 1, "number err1");
        continue;
    }
    if (srcObj.type == "Plant" && srcObj.stat == 2 && !number.startsWith("PP")) {
        number = 'PP' + number;
    }
    if (srcObj.stat == 2 || number.startsWith("H")) {   //因 H 開頭的被處理為公開，因此額外判斷
        number = "US" + number.padLeft(9, '0')
    }
    
    if (number.length() != 11) {
        def err = true
        if (srcObj.stat == 1) {
            if (number.length() == 10) {
                number = number.substring(0, 4) + '0' + number.substring(4)
                err = false
            }
        }
        if (err) {
            error(errColl, srcObj, number, 2, "number err2");
            continue;
        }
    }
    
    def appNumber = srcObj.appNumber
    def newAppNumber = null
    if (appNumber != null) {
        appNumber = appNumber.replaceAll("\\*", "")
        appNumber = appNumber.replaceAll("\\[", "")
        appNumber = appNumber.trim()
        //考慮 DOCDB 特有格式 ==> 60 49390 (空白前不參考)
        if (appNumber.contains(' ')) {
            appNumber = appNumber.split(' ')[1]
        }
        
        if (appNumber.length() == 8) {
            newAppNumber = appNumber.substring(0, 2) + "/" + appNumber.substring(2)
        } else {
            newAppNumber = appNumber;
        }
    }
    
    def row = collection2.findOne(["_id": number])
    def init = row == null
    def event = [name: "DOCDB",
        id: srcObj._id,
        updatedDate: date]
    if (init) {
        row = [:]
        row._id = number
        row.createdDate = date
        if (srcObj.kindcode != null) {
            row.kindcode = srcObj.kindcode
        }
        
        row.stat = srcObj.stat
        row.docDate = srcObj.doDate
        if (newAppNumber != null) {
            row.appNumber = newAppNumber
        }
        if (srcObj.appDate != null) {
            row.appDate = srcObj.appDate
        }
        row.fullText = false
        row.docdbDoDate = srcObj.docdbDoDate
        event.log = "create"
    } else {
        //比對申請號
        if (row.appNumber != null && newAppNumber != null) {
            if (row.appNumber != newAppNumber) {
                if (procAppNumber(row.appNumber) != procAppNumber(newAppNumber)) {
                    error(errColl, srcObj, appNumber, 4, "appNumber not match");
                    continue;
                }
            }
        }
    }
    
    row.lastUpdateDate = date
    row.docdb = true
    
    if (init) {
        row.relations = [:]
        row.events = []
    }
    def rel = row.relations;
    def events = row.events
    def docdb = rel.DOCDB;
    if (docdb == null) {
        rel << [DOCDB:[id: srcObj._id, updatedDate: date]]
        event.log = "create"
        row.docdbDoDate = srcObj.docdbDoDate
    } else {
        //比對 docdbDoDate，若比較大，則跳過，若比較小，則更新
        if (srcObj.docdbDoDate > row.docdbDoDate) {
            row.docdbDoDate = srcObj.docdbDoDate
        }
        //比對 ID 是否一致
        if (docdb.id != srcObj._id) {
            //比對 DOCDB doDate，以 doDate 大的為主，並將小的那筆資料寫入 error 供驗證筆數
            def preDocdb = collection.findOne([_id: docdb.id])
            def oldDocdb = null
            if (srcObj.doDate > preDocdb.doDate) {
                docdb.id = srcObj._id
                oldDocdb = preDocdb
            } else {
                oldDocdb = srcObj
            }
            error(errColl, oldDocdb, number, 5, "id not match");
        }
        event.log = "update"
    }
    events << event
    
    //collection2.save(row)
    saveCnt++;
    if (cnt % 1000 == 0) {
        log(cnt + " / " + total + " --> " + srcObj.docdbDoDate)
    }
}
log("cnt: $total saveCnt: $saveCnt")

println 'finished!'

def procAppNumber(def s) {
    def cnt = 6
    if (s == null) {
        return s;
    }
    if (s.length() >= cnt) {
        return s.substring(s.length()-cnt)
    } else {
        return s.padLeft(cnt, '0')
    }
}

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}

def error(def errColl, def row, def val, def code, def msg) {
    log("Err: $code - $msg ==> $val")
    def doc = [:]
    doc._id = row._id
    doc.doDate = row.doDate
    doc.docdbDoDate = row.docdbDoDate
    doc.val = val
    doc.code = code
    doc.msg = msg
    //errColl.save(doc)
}
