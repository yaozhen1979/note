package util

import groovy.json.JsonOutput

class PatentInfoFieldVerifyUtil {

    def static manualFields = ['appNumber', 'appDate', 'stat', 'doDate', 'version']

    def static arrayFields = ['assignees', 'applicants', 'inventors', 'agents']

    def static multiLangStringFields = ['brief', 'claim', 'description', 'title']

    def static stringArrayFields = ['cpcs', 'ipcs', 'ipcrs', 'locs', 'uspcs', 'fis', 'fterms', 'dis', 'dterms', 'eclas', 'otherReferences']

    def static intFields = ['version', 'lnBackFile', 'stat', 'filePageClaim', 'filePageDesc', 'filePageFig', 'filePageFirst', 'filePageNumber', 'clipPageNumber']

    def static strFields = [
        'pto',
        'appNumber',
        'appNumberNormal',
        'certificateNumber',
        'decisionNumber',
        'decisionNumberNormal',
        'openNumber',
        'openNumberNormal',
        'patentNumber',
        'pctAppNumber',
        'pctOpenNumber',
        'mainCPC',
        'mainCPCNormal',
        'mainIPC',
        'mainIPCNormal',
        'mainIPCR',
        'mainLOC',
        'mainLOCNormal',
        'mainUSPC',
        'mainUSPCNormal',
        'mainFI',
        'mainFTerm',
        'mainDI',
        'mainDTerm',
        'kindcode',
        'type'
    ]

    def static booleanFields = ['truncate', 'firstImagePageFlag']

    def static dateFields = ['appDate', 'certificateDate', 'decisionDate', 'examDate', 'openDate', 'pctAppDate', 'pctOpenDate', 'doDate']

    def static personArrayFields = ['agents', 'agentOperators', 'assignees', 'inventors', 'examinerMasters', 'examinerSlaves']

    def static relatedPatentArrayFields = ['citedPatents', 'priorityPatents', 'relatedPatents', 'relPatents']

    PatentInfoFieldVerifyUtil() {
    }

    def static void main(args) {
        def doc = [:]

        def claim = [:]

        claim << ['en':'abc']

        claim << ['orgin':'def']

        claim << ['123':'123']

        doc << [claim:claim]

        doc << ['appNumber':'1']
        
        doc << ['appDate':new Date()]
        
        doc << ['doDate':new Date()]
        
        doc << ['version': '1'.toInteger()]
        
        doc << ['stat': '1'.toInteger()]
        
        doc << [agents:[[name:[origin:'Allen, Dyer, Doppelt, Milbrath & Gilchrist, P.A.']]]]

        def builder = new groovy.json.JsonBuilder(doc)

        println builder.toString()

        //        personArrayFieldCheck(doc, '1')

        manualFieldCheck(doc)

        arrayFieldCheck(doc)

        dateFieldCheck(doc)

        integerFieldCheck(doc)

        stringFieldCheck(doc)

        booleanFieldCheck(doc)

        personArrayFieldCheck(doc)

        multiLangStringFieldCheck(doc)

    }

    def static verify(doc) throws Exception{

        manualFieldCheck(doc)

        arrayFieldCheck(doc)

        dateFieldCheck(doc)

        integerFieldCheck(doc)

        stringFieldCheck(doc)

        booleanFieldCheck(doc)

        personArrayFieldCheck(doc)

        multiLangStringFieldCheck(doc)
    }

    //檢查必要欄位
    def static manualFieldCheck(doc) {

        manualFields.each { key ->

            if (!doc.containsKey(key) && !doc[key]) {

                throw new Exception("Error: field [${key}] must be manual, appNumber: ${doc.appNumber}, stat : ${doc.stat}")
            }

        }

    }

    //檢查是否為陣列物件
    def static arrayFieldCheck(doc) {

        arrayFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof List)) {

                    throw new Exception("Type Error: field [${key}] must be instanceof List, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                }
            }

        }

    }

    //檢查是否為日期物件
    def static dateFieldCheck(doc) {

        dateFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof Date)) {

                    throw new Exception("Type Error: field [${key}] must be instanceof Date, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                }

            }

        }

    }

    //檢查是否為Integer物件
    def static integerFieldCheck(doc) {

        intFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof Integer)) {

                    throw new Exception("Type Error: field [${key}] must be instanceof Integer, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                }

            }

        }

    }

    //檢查是否為String物件
    def static stringFieldCheck(doc) {

        strFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof String)) {

                    throw new Exception("Type Error: field [${key}] must be instanceof String, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                }

            }

        }

    }

    //檢查是否為boolean物件
    def static booleanFieldCheck(doc) {

        booleanFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof Boolean)) {

                    throw new Exception("Type Error : field [${key}] must be instanceof Boolean, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                }

            }

        }

    }

    //檢查country code是否正確
    def static countryFieldCheck(fieldName, countryStr) {

        if (!(countryStr instanceof String)) {

            throw new Exception("Type Error : field [${fieldName}] has wrong country code")

        }

        if (countryStr.length() != 2) {

            throw new Exception("Type Error: field [${fieldName}] has wrong country code")

        }
    }

    //檢查是否為String物件
    def static stringArrayFieldCheck(doc) {

        stringArrayFields.each { key ->

            if (doc.containsKey(key)) {

                if (!(doc[key] instanceof List)) {

                    throw new Exception("Type Error: field [${key}] must be instanceof List, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                } else {

                    doc[key].each {data ->

                        if (!(data instanceof String)) {

                            throw new Exception("Type Error : [${data}] of [${key}] must be instanceof String, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                        }

                    }

                }

            }

        }

    }

    def static multiPersonLangStringFieldCheck(fieldName, field) {

        if (!(field instanceof List)) {

            throw new Exception("Type Error : field [${fieldName}] must be instanceof List")

        } else {

            field.each {dataMap ->

                dataMap.each {key, value ->
                    
                    for (map in dataMap[key]) {
                        
                        if (!(map.value instanceof String)) {
                            
                            throw new Exception("Type Error : field [${key}] of [${fieldName}] must be instanceof String")
                        }
                        
                    }

                }

            }

        }

    }

    //檢查人員相關欄位
    def static personArrayFieldCheck(doc) {

        personArrayFields.each { key ->

            if (doc.containsKey(key)) {

                multiPersonLangStringFieldCheck(key, doc[key])

            }
        }

    }

    //多語系相關欄位檢察
    def static multiLangStringFieldCheck(doc) {

        multiLangStringFields.each { key ->

            if (doc.containsKey(key)) {

                doc[key].each {dataMap ->

                    for (map in dataMap) {

                        if (!(map.value instanceof String)) {

                            throw new Exception("Type Error : field [${map.key}] of [${key}] must be instanceof String, appNumber: ${doc.appNumber}, stat : ${doc.stat}")

                        }

                    }
                    
                }

            }

        }

    }
}
