@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.5.0')
@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')

import groovy.json.*

import groovyx.net.*
import groovyx.net.http.*

import static groovy.json.JsonOutput.*

import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import org.apache.http.auth.*

import com.mongodb.*

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("PatentRawIN").getCollection("PatentRawIN")

def url = "http://ipindiaservices.gov.in/publicsearch/webservices/search.php"

def http = new HTTPBuilder(url)
http.client.getCredentialsProvider().setCredentials(
    new AuthScope("10.60.94.21", 3128),
    new UsernamePasswordCredentials("docker", "Abc.2015")
)
http.setProxy('10.60.94.21', 3128, 'http')


def jsonSlurper = new JsonSlurper();

def page = 1;   //total: 532522
for (i=0; i<page; i++) {
    def r = ''
    def retry = 0;
    while (retry < 70)  {
        try {
            r = make_get_request(http, i)
            break;
        } catch (Exception e) {
            println e
            retry++;
            if(retry % 10==0) {
                Thread.sleep(1000*60*5)
            }
            println 'will retry list:' + retry
        }
    }
    def object = jsonSlurper.parseText(r)
    print new Date()
    println ' page:' + i + '/' + page + ' start:' + object.start + ' total:' + object.totalResultsFound
    object.record.each() {
        println it.application_no
        it._detailFlag = false
        if (it.application_no == '2284/CHE/2006') {
            //println it
            collection.insert(new BasicDBObject(it))
        }
    }
}
println 'finished!'


def make_get_request(http, p) {

def result = '';
http.request(POST, ContentType.TEXT) {
    //uri.path = '/'
    requestContentType = URLENC

    body = [
publication_type_published:'on',
publication_type_granted:'on',
fieldDate:'APD',
datefieldfrom:'19120101',
datefieldto:'20150722',
operatordate:' AND ',
"field[]":'AP',
"fieldvalue[]":'2284/CHE/2006',
"operator[]":'AND ', 
page:p+'',
start:'0',
limit:'25'
    ]

    response.success = { resp, json ->
        result = json.text;
    }
}
return result;
}