@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.5.0')
@Grab(group='org.mongodb', module='mongo-java-driver', version='2.13.0')

import groovy.json.*

import groovyx.net.*
import groovyx.net.http.*

import static groovy.json.JsonOutput.*

import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import org.apache.http.auth.*

import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.DBCursor
import com.mongodb.BasicDBObject

MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                    Arrays.asList(credential));

System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' ]

while (true) {
    try {
        def collection = mongoClient.getDB("PatentRawIN").getCollection("PatentRawIN")
        DBCursor cursor = collection.find(new BasicDBObject("_detailFlag", false))
        def c = 0
        while (cursor.hasNext()) {
            def d = cursor.next();
            println "${c++}:${d.UCID}:${d._id}"
            def d0 = getDetail(d.UCID)
            def set = [:]
            set['_detail'] = d0
            set['_detailFlag'] = true
            collection.update(new BasicDBObject(["_id" : d._id]), 
                new BasicDBObject('$set', new BasicDBObject(set)))
            //Thread.sleep(1000)
        }
        break;
    } catch(Exception e) {
        println e
    }
} 
println 'finished!'


def getDetail(ucid) {
    def jsonSlurper = new JsonSlurper();
    def id = 'SU4yOTI4L0NIRS8yMDE1IDIwMTUwNjEx'
    def xml = null;
    def retry = 0;
    while (retry < 70)  {
        try {
            xml = ('http://ipindiaservices.gov.in/publicsearch/webservices/patent_detail.php?UCID=' + ucid).toURL().getText([connectTimeout: 20000, readTimeout: 30000])
            break;
        } catch (Exception e) {
            println e
            retry++;
            if(retry % 10==0) {
                Thread.sleep(1000*60*5)
            }
            println 'will retry list:' + retry
        }
    }
    def object = jsonSlurper.parseText(xml)
}

