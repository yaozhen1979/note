import groovy.time.TimeCategory
import groovy.time.TimeDuration

import java.text.SimpleDateFormat

import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.MongoUtil
import util.RestTimeProcess
import ch.qos.logback.classic.Level

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation
import com.mongodb.DBCursor
import com.mongodb.DBObject

Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
mongoLogger.setLevel(Level.OFF);

//********** arguments ***********
def pto = "INPTO"

def dateS = "2015-09-14"

def dateE = "2015-09-15"

def batchSize = 2000

def srcDB = "PatentRawIN"

def tarDB = "PatentInfoIN"

def errColName = "ErrorPatentInfoIN"
//********** arguments ***********

def PRETTY_PRINT_INDENT_FACTOR = 4;

def ln = System.getProperty('line.separator')

def dateStr = "T00:00:00"

def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"

File log = new File("tmp/india_parse_rawData_${dateS}.txt")

def timeCalculateClosure = { closure ->

    def timeStart = new Date()

    def msg = closure()

    def timeStop = new Date()

    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    def msg1 = msg + " spend time: " +  duration

    println msg1

    log << msg1 << ln
}

timeCalculateClosure {

    try {

        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, srcDB).getClient()
        //
        def rawDb = client.getDB(srcDB)

        def srcCol = rawDb.getCollection(srcDB)

        def tarDb = client.getDB(tarDB)
        //
        def tarCol = tarDb.getCollection(tarDB)
        //
        def errCol = tarDb.getCollection(errColName)

        BulkWriteOperation tarBulk = tarCol.initializeOrderedBulkOperation()

        println "date range [${dateS} ~ ${dateE}]"

        def doDateS = Date.parse(dateFormat, dateS + dateStr)

        def doDateE = Date.parse(dateFormat, dateE + dateStr)

        def queryMap = [:]

//        queryMap << ['Publication_Type' : 'B']

                queryMap << ['_id' : new ObjectId("55cc6dfbe4b0ef40c7d4bb2f")]

        def total = srcCol.count(new BasicDBObject(queryMap))

        RestTimeProcess rtp = new RestTimeProcess(total, "PatentRawIN parse ${dateS}", log)

        DBCursor srcCur = srcCol.find(new BasicDBObject(queryMap))

        def cnt = 0

        def doDate = new SimpleDateFormat("yyy-MM-dd").format(new Date())

        while (srcCur.hasNext()) {

            cnt++

            rtp.process()

            DBObject srcDoc = srcCur.next()
            
            //stat
            def stat

            def kindcode

            if (srcDoc.Publication_Type) {

                stat = srcDoc.Publication_Type == 'A' ? 1 : 2

                kindcode = srcDoc.Publication_Type

            } else {

                throw new Exception("Error: field [stat] is manual, src id: " + srcDoc._id);

            }//end of stat

            //appNumber
            def appNumber
            def appNumberNormal

            println "srcDoc.application_no: " + srcDoc.application_no + ",src id : " + srcDoc._id

            if (!!srcDoc.application_no) {

                try {
                    
                    if (srcDoc.application_no =~ /IN\/PCT.+/) {

                        appNumber = srcDoc.application_no

                        appNumberNormal = normalizeAppNumber(appNumber, srcDoc.appDate)

                    } else {

                        appNumber = srcDoc.application_no.replace(" ", "")

                        appNumberNormal = normalizeAppNumber(appNumber, srcDoc.appDate)
                        
                    }

                } catch (Exception e) {
                
                    println e
                    
                    throw e
                }

                if (!appNumberNormal) {
                    
                    log << "Error: field [appNumberNormal] error, src id: " + srcDoc._id << ln

                    def errDoc = [:]

                    errDoc['appNumber'] = srcDoc.application_no

                    errDoc['stat'] = stat

                    errDoc['errMsg'] = 'AppNumber Normalize error'

                    errDoc['data'] = srcDoc.application_no

                    errDoc['date'] = new Date()

                    errDoc['errHandle'] = false
                    
                    println "errDoc: ${errDoc}"

                    errCol.save(errDoc)

                }

            } else {

                throw new Exception("Error: field [appNumber] is manual, src id: " + srcDoc._id);

            }//end of appNumber

            //gen tarDoc
            def tarQueryMap = [:]

            tarQueryMap['appNumber'] = appNumber

            tarQueryMap['stat'] = stat
            
            def data = tarCol.findOne(new BasicDBObject(tarQueryMap))

            def tarDoc = [:]

            if (data) {

                tarDoc = data

                //
                TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

                if (tarDoc.mongoSyncFlag) {

                    tarDoc << ['mongoSyncFlag' : ['init': tarDoc.mongoSyncFlag.init, 'last': new Date()]]

                } else {

                    tarDoc << ['mongoSyncFlag' : ['init': new Date(), 'last': new Date()]]

                }

                TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))

            } else {

                tarDoc['appNumber'] = appNumber

                tarDoc['stat'] = stat

                tarDoc['kindcode'] = kindcode

                //
                TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

                tarDoc << ['mongoSyncFlag' : ['init': new Date(), 'last': new Date()]]

                TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))
            }

            tarDoc['appNumberNormal'] = appNumberNormal
            
            tarDoc['pto'] = 'IN'

            //doDate
            tarDoc['doDate'] = srcDoc.doDate
            
            //indiaDoDate
            if (!!srcDoc.indiaDoDate) {

                tarDoc['indiaDoDate'] = srcDoc.indiaDoDate

            }

            //appDate
            if (!!srcDoc.appDate) {

                tarDoc['appDate'] = toISODate(srcDoc.appDate)

            }//end of appDate

            if (stat == 1) {
                //pubDate
                if (!!srcDoc.pubDate) {

                    def openYear = srcDoc.pubDate.split(" ")[2]
                    
                    if (openYear == '1900') {
                        
                        tarDoc['openDate'] = null
                        
                    } else {
                        
                        tarDoc['openDate'] = toISODate(srcDoc.pubDate)
                    
                    }
                    

                    if (!!appNumberNormal) {

                        tarDoc['openNumber'] = appNumberNormal

                        tarDoc['openNumberNormal'] = appNumberNormal + "A"

                    }

                } else {
                    
                    tarDoc['openDate'] = null
                
                }
            }

            //publicationTerm
            if (!!srcDoc.publication_no) {

                tarDoc['publicationTerm'] = srcDoc.publication_no

            }//end of publicationTerm


            if (stat == 2) {
                //decisionNumber, patentNumber
                if (!!srcDoc.patent_no) {

                    tarDoc['decisionNumber'] = srcDoc.patent_no

                    tarDoc['patentNumber'] = srcDoc.patent_no

                    tarDoc['decisionNumberNormal'] = "IN" + srcDoc.patent_no + "B"

                    tarDoc['patentNumberNormal'] = "IN" + srcDoc.patent_no + "B"

                }

                try {
                    
                    //decisionDate
                    if (!!srcDoc.grantDate && !srcDoc.grantDate.trim().isEmpty()) {
                        
                        def grantYear = srcDoc.grantDate.split("/")[2]
                        
                        if (grantYear == '1900') {
                            
                            tarDoc['decisionDate'] = null
                            
                        } else {

                            tarDoc['decisionDate'] = toISODate(srcDoc.grantDate.replace("/"," "))
                        
                        }
    
                    } else {
                    
                        tarDoc['decisionDate'] = null
                    
                    }


                } catch (Exception e) {

                    println "decisionDate error: " + e

                    log << "Error: field [decisionDate] error, src id: " + srcDoc._id << ln

                    def errDoc = [:]

                    errDoc['appNumber'] = srcDoc.application_no

                    errDoc['stat'] = stat

                    errDoc['errMsg'] = 'DecisionDate error'

                    errDoc['data'] = srcDoc.grantDate

                    errDoc['date'] = new Date()

                    errDoc['errHandle'] = false

                    println "errDoc: ${errDoc}"

                    errCol.save(errDoc)

                }

            }

            //title
            def title
            if (!!srcDoc.title) {

                def titelText = srcDoc.title.trim()
                //"\" AN IMPROVED PROCESS \"test\" FOR THE PREPARATION OF LERCANIDIPINE  \" "
                titelText.replaceAll(/^\"*([\s\S]*?)\"*$/) {fullMatch, content ->

                    title = ['origin' : content.trim()]

                }

                tarDoc['title'] = title
            }

            //brief
            def brief

            if (!!srcDoc['abstract']) {

                brief = ['origin' : srcDoc['abstract'].trim()]

                tarDoc['brief'] = brief

            }

            //claim
            def claim

            if (!!srcDoc.claim) {

                claim = ['origin' : srcDoc.claim.trim()]

//                tarDoc['claim'] = claim

            }

            //description
            def description

            if (!!srcDoc.description) {

                description = ['origin' : srcDoc.description.trim()]

//                tarDoc['description'] = description

            }

            def detailFlag = srcDoc._detailFlag

            def detail

            if (!!detailFlag) {

                detail = srcDoc._detail

                //type
                if (detail.Publication_Type) {
                    //TODO: 先寫死 Utility
                    tarDoc['type'] = "Utility"

                }

                //inventors
                def inventorArry = []
                if (detail.inventor) {

                    detail.inventor.each {
                        
                        def dataMap = parsePersonTypeMap(it)
                        
                        if (dataMap.size() > 0) {
                            
                            inventorArry << dataMap
                            
                        }
                    }
                    
                    if (inventorArry.size() > 0) {

                        tarDoc['inventors'] = inventorArry

                    }

                }

                //applicants, assignees
                def applicantArry = []
                if (!!detail.applicant) {
                    
                    detail.applicant.each {

                        def dataMap = parsePersonTypeMap(it)
                        
                        if (dataMap.size() > 0) {
                            
                            applicantArry << dataMap
                            
                        }
                        
                    }

                    if (applicantArry.size() > 0) {

                        tarDoc['applicants'] = applicantArry

                        tarDoc['assignees'] = applicantArry
                        
                    }

                }

                //ipc
                def ipcArry = []
                
                def ipcArryNormal = []

                if (!!detail.classification_ipcr) {

                    def ipcs = detail.classification_ipcr[0]

                    //B66F-11/04, B66B-9/16, IPC7-A01G 1/00 1104-N  17/00
                    if (!!ipcs) {

                        ipcs.split(",").each {ipc ->

                            ipc = ipc.trim()

                            if (!!ipc) {
                                
                                def ipc1
                                
                                try {

                                    ipc1 = parseClassificationNumber(ipc, "IPC")

                                } catch(Exception e) {

                                    log << "Error: field [ipc] error, src id: " + srcDoc._id << ln

                                    def errDoc = [:]

                                    errDoc['appNumber'] = tarDoc.appNumber

                                    errDoc['stat'] = tarDoc.stat

                                    errDoc['errMsg'] = 'IPC parse error'

                                    errDoc['data'] = ipc

                                    errDoc['date'] = new Date()

                                    errDoc['errHandle'] = false

                                    errCol.save(errDoc)

                                }
                                
                                if (!!ipc1) {

                                    ipcArry << ipc1

                                } else {

                                    ipcArry << ipc

                                }
                                
                                def ipcNormal
                                
                                try {
                                    
                                    ipcNormal = normalizeClassificationNumber(ipc, "IPC")
                                    
                                } catch (Exception e) {
                                    
                                    log << "Error: field [ipc] error, src id: " + srcDoc._id << ln
                                
                                    def errDoc = [:]
                                
                                    errDoc['appNumber'] = tarDoc.appNumber
                                    
                                    errDoc['stat'] = tarDoc.stat
                                    
                                    errDoc['errMsg'] = 'IPC Normalize error'
                                    
                                    errDoc['data'] = ipc
                                    
                                    errDoc['date'] = new Date()
                                    
                                    errDoc['errHandle'] = false
                                    
                                    errCol.save(errDoc)
                                }
                                
                                if (!!ipcNormal) {

                                    ipcArryNormal << ipcNormal

                                } else {

                                    ipcArryNormal << ipc

                                }

                            }

                        }

                    }
                    
                    if (ipcArry.size() > 0) {

                        tarDoc['mainIPC'] = ipcArry[0]

                        tarDoc['ipcs'] = ipcArry

                    }
                    
                    if (ipcArryNormal.size() > 0) {

                        tarDoc['mainIPCNormal'] = ipcArryNormal[0]
                        
                        tarDoc['ipcsNormal'] = ipcArryNormal
                    }

                }
            }


            //relRawdatas
            def relRawdatas = []

            if (!!tarDoc['relRawdatas']) {

                relRawdatas = tarDoc['relRawdatas']

            }

            def isIdExists = false

            relRawdatas.each {relRawdata ->

                if (relRawdata._id == srcDoc._id) {

                    isIdExists = true

                }

            }

            if (!isIdExists) {

                relRawdatas << ['_id' : srcDoc._id]

            }

            tarDoc['relRawdatas'] = relRawdatas
            
//            println "tarDoc: " + tarDoc

            def updateMap = ['$set' : tarDoc]

            //verify
            verify(tarDoc, srcDoc._id)

            tarBulk.find(new BasicDBObject(tarQueryMap)).upsert().updateOne(new BasicDBObject(updateMap))

            if (cnt.mod(batchSize) == 0) {

                cnt = 0

                println "batch insert ...."

                def tarResult = tarBulk.execute()

                tarBulk = tarCol.initializeOrderedBulkOperation()

            }

                        //break

        }

        if (cnt > 0) {

            println "last batch insert counts ${cnt}...."

            tarBulk.execute()

        }

    } catch (Exception e) {

        println e

        return "process stop..."

    }

    return "pto ${pto} parsing..."


}

def toISODate(date) {

    TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

    SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

    Date isoDate = sdf.parse(date)

    TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))

    return isoDate
}

def verify(doc, id) {

    def manualFields = ['appNumber', 'appDate', 'stat', 'doDate', 'type', 'relRawdatas']

    def arrayFields = ['assignees', 'applicants', 'inventors', 'ipcs', 'relRawdatas']

    def dateFields = ['doDate', 'appDate', 'indiaDoDate']
    
    def booleanFields = []
    
    def strFields = ['type']
    
    def classificationFields = ['mainIPC']
    
    def classificationArryFields = ['ipcs']
    
    manualFields.each { key ->

        if (!doc.containsKey(key) && !doc[key]) {

            throw new Exception("Error: field [${key}] is manual, src id: " + id);

        }

    }

    arrayFields.each { key ->

        if (doc.containsKey(key)) {

            if (!doc[key] instanceof List) {
                // do something
                throw new Exception("Type Error: field [${key}] instanceof List, src id: " + id);
            }

        }

    }
    
    strFields.each { key ->

        if (doc.containsKey(key)) {

            if (!doc[key] instanceof String) {
                // do something
                throw new Exception("Type Error: field [${key}] instanceof String, src id: " + id);
            }

        }

    }
    
    dateFields.each { key ->

        if (doc.containsKey(key)) {

            if (!doc[key] instanceof Date) {
             
                throw new Exception("Type Error: field [${key}] instanceof Date, src id: " + id);
            }

        }

    }

}

def normalizeAppNumber(originalAppNumber, appDate) {

    def appNumberNormal
    
    def appNumberTemp

    try {

        if (originalAppNumber =~ /IN\/PCT.+/) {
            
            appNumberTemp = originalAppNumber.replace(",", "/").replace(" ", "/").replace(".", "/").replace(",", "/")
            
            if (appNumberTemp =~ /IN\/+PCT\/+[1-2][0-9]+\/+[0-9]+\/+\w+/) {
                //例外:IN/PCT/20000/0283/MUM
                appNumberTemp.trim().replaceAll(/IN\/+PCT\/+([1-2][0-9]+)\/+([0-9]+)\/+(\w+)/) {fullMatch, year, serialNo, region ->
                    
                    appNumberNormal = "INPCT" + year + region + "0" * (7 - serialNo.length()) + serialNo
                    
                }
                
            } else if (/IN\/+PCT\/+[1-2][0-9]+\/+\w+/){
            
                appNumberTemp.trim().replaceAll(/IN\/+PCT\/+([1-2][0-9]+)\/+(\w+)/) {fullMatch, year, region ->
                    
                    appNumberNormal = "INPCT" + year + "0" * (7) + region
                    
                }
            
            }

        } else if (originalAppNumber =~ /^[0-9]+$/){

            def year = appDate.split(" ")[2]
        
            appNumberNormal = "IN" + year + "0" * (7 - originalAppNumber.length())   + originalAppNumber
        
        } else {

            if (originalAppNumber =~ /\w+\/+[0-9]+\/+[1-2][0-9]+/) {
                
                originalAppNumber.replaceAll(/(\w+)\/+([0-9]+)\/+([1-2][0-9]+)/) {fullMatch, region, serialNo, year ->

                    appNumberNormal = "IN" + year + region + "0" * (7 - serialNo.length()) + serialNo

                }

            } else {
                //3902/CHE/2012
                appNumberTemp = originalAppNumber.replace("/", "").replace("-", "").replace(".", "").replace(",", "")

                if (appNumberTemp =~ /[0-9]+[A-Za-z]+[0-9]+/) {

                    appNumberTemp.replaceAll(/([0-9]+)([A-Za-z]+)([0-9]+)/) {fullMatch, serialNo, region, year ->

                        appNumberNormal = "IN" + year + region + "0" * (7 - serialNo.length()) + serialNo

                    }

                }

            }

        }

    } catch (Exception e) {

        println "Error: normalizeAppNumber error, appNumber => " + originalAppNumber

        throw e

    }

    return appNumberNormal

}

def parseClassificationNumber(classificationNumber, type) {
    
        def classification
    
        try {
    
            if (type == 'IPC') {
    
                if (classificationNumber =~ /IPC.+/) {
                    //IPC7-A01G 1/00, IPC--HO3K 17/00, IPC-:HO3K 17/00
                    if (classificationNumber =~ /IPC\d*-*:*[A-Za-z]-*\s*[0-9]{2}[A-Za-z]-*\s*[0-9]*\/+[0-9]*/){
                        
                        classificationNumber.replaceAll(/IPC\d*-*:*([A-Za-z]-*\s*[0-9]{2}[A-Za-z])-*\s*([0-9]+)\/+([0-9]+)/) {fullMatch, result1, maingroup, subgroup ->
    
                            classification = result1.replace('-', '').replace(' ', '') + ' ' + maingroup + '/' + subgroup
    
                        }
                    }
    
                } else {
                    //C08G-18/10, C07-D 211/00, B01-J  23/89, H01L-35/, F04B--41/06, A61- K 31/495
                    if (classificationNumber =~ /[A-Za-z][0-9]{2}-*\s*[A-Za-z]-*\s*[0-9]*\/[0-9]*/) {
    
                        classificationNumber.replaceAll(/([A-Za-z][0-9]{2}-*\s*[A-Za-z])-*\s*([0-9]*)\/([0-9]*)/) {fullMatch, result1, maingroup, subgroup ->
    
                            classification = result1.replace('-', '').replace(' ', '') + ' ' + maingroup + '/' + subgroup
    
                        }
    
                    }
    
                }
    
            }
    
        } catch (Exception e) {
    
            println "Error: parse classificationNumber error, classificationNumber => " + classificationNumber
    
            throw e
        }
    
        return classification
    
    }

def normalizeClassificationNumber(classificationNumber, type) {

    def classificationNormal

    try {

        if (type == 'IPC') {

            if (classificationNumber =~ /[A-Za-z][0-9]{2}-*\s*[A-Za-z]-*\s*[0-9]*\/[0-9]*/) {

                classificationNumber.replaceAll(/([A-Za-z][0-9]{2}-*\s*[A-Za-z])-*\s*([0-9]*)\/([0-9]*)/) {fullMatch, result1, maingroup, subgroup ->

                    classificationNormal = result1.replace('-', '').replace(' ', '') + '0' * (4 - maingroup.length()) + maingroup + subgroup  + '0' * (6 - subgroup.length())

                }

            }

        }

    } catch (Exception e) {

        println "Error: normalizeClassificationNumber error, classificationNumber => " + classificationNumber

        throw e
    }

    return classificationNormal

}

/**
 * 去除assignee,applicants空白
 * @param personMap
 * @return
 */
def parsePersonTypeMap(personMap) {
    
    def map = [:]
    
    personMap.each {k,v ->
        
        if (k != 'nationality') {
            
            if (!!personMap[k]) {
                
                if (k == 'address') {
                    
                    map << [address:[origin:personMap[k].trim()]]
                    
                } else if (k == 'country') {
                
                    map << [country:[origin:personMap[k].trim()]]
                
                } else if (k == 'name') {
                
                    map << [name:[origin:personMap[k].trim()]]
                
                }
                
            }
            
        }
        
    }
    
    return map
}

//去除map中value為null
def removeMapNullValue(map) {
    
        def newMap = [:]
    
        for (e in map) {
            println "e.key:" + e.key + ",e.value: " + e.value + ":" + !!e.value
            if (!!e.value) {

                if (e.value instanceof Map) {
                    
                    if(!!removeMapNullValue(e.value)) {
                        
                        newMap[e.key] = removeMapNullValue(e.value)
                        
                    }
                    
                } else {
                
                println "tetst1"
                    if (!!e.value) {
                        
                        newMap[e.key] = e.value
                        
                    }
                    
                }
    
            }
    
        }
        
        return (newMap.size() > 0) ? newMap : null
    
    }

//排除List重複的值
def unique(arr){
    
    def dataStringArry = []
    
    def dataArry = []
    
    for(def i =0; i< arr.size();i++){
        //使用BasicDBObject將array轉為json
        if(dataStringArry.indexOf(new BasicDBObject(arr[i]).toString()) > -1){
            
            continue
            
        } else {
            
            dataStringArry << new BasicDBObject(arr[i]).toString()
            
            dataArry << arr[i]
            
        }
    }
    
    return dataArry;
}