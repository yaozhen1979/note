//@Grab(group='net.sourceforge.jtds', module='jtds', version='1.3.1')

import groovy.sql.*

import java.sql.Clob
import java.sql.SQLException

import util.MongoUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation


def dbName = "ClassificationMap"

def colName = "Ipc"

def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()
//
def srcDb = client.getDB(dbName)

def srcCol = srcDb.getCollection(colName)

BulkWriteOperation srcBulk = srcCol.initializeOrderedBulkOperation()

def db = [url:'jdbc:jtds:sqlserver://10.60.90.47:1433/PatentCloudDev',
    user:'sa',
    password:'itec.sql.123',
    driver:'net.sourceforge.jtds.jdbc.Driver']

def sql = Sql.newInstance(db.url, db.user, db.password, db.driver)

def sqlStr = "select * from " + colName

def batchSize = 2500

def cnt = 0
//
sql.eachRow(sqlStr){row ->
    
    def rowMap = [:]

    rowMap << ['_id': row[0].toString()]

    rowMap << ['ParentId':row[1].toString()]

    rowMap << ['Symbol': row[2].toString()]

    rowMap << ['Title': (row[3] instanceof Clob) ? clobToString(row[3]) : row[3].toString()]

    rowMap << ['Level': row[4].toInteger()]

    println rowMap

    srcBulk.insert(new BasicDBObject(rowMap))

    if (cnt.mod(batchSize) == 0) {

        cnt = 0

        println "batch insert ...."

        def srcResult = srcBulk.execute()

        srcBulk = srcCol.initializeOrderedBulkOperation()

    }

}


if (cnt > 0) {

    println "last batch insert counts ${cnt}...."

    srcBulk.execute()

}

println "finish"

def clobToString(Clob clob) {

    if(clob == null) {

        return null

    }

    try  {

        Reader inStreamDoc = clob.getCharacterStream()

        char[] tempDoc = new char[(int) clob.length()]

        inStreamDoc.read(tempDoc)

        inStreamDoc.close()

        return new String(tempDoc)

    } catch (IOException e) {

        println e

    } catch (SQLException es) {

        println es

    }

    return null

}
