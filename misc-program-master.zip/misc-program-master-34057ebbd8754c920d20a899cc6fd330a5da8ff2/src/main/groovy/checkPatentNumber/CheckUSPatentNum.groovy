package checkPatentNumber

import static groovy.json.JsonOutput.*
import groovyx.net.*
import groovyx.net.http.*

import org.apache.http.auth.*
import org.json.*

import com.mongodb.*

/**
 * 
 */
MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.122", 27017), Arrays.asList(credential));

def mongoClient2 = new MongoClient(new ServerAddress("10.60.90.101", 27017), Arrays.asList(credential));

def collection = mongoClient.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO")
DBCollection collection2 = mongoClient2.getDB("PatentUSRelation").getCollection("PatentUSRelation")
def error = mongoClient2.getDB("PatentUSRelation").getCollection("ErrorLog")

BulkWriteOperation tarBulk = collection2.initializeOrderedBulkOperation()

def parsePatentNumber(num) {
    def patterns = [/^US(00)?([0-9]{7})$/, 
        /^US(00)?(D[0-9]{6})$/, 
        /^US(00)?(PP[0-9]{5})$/, /^US(00)?0(PP[0-9]{4})$/,
        /^US(00)?(T[0-9]{6})$/,
        /^US(00)?(RE[0-9]{5})$/,
        /^US(00)?00000(H[0-9]{1})$/, /^US(00)?0000(H[0-9]{2})$/, /^US(00)?000(H[0-9]{3})$/, /^US(00)?00(H[0-9]{4})$/
        ]
    for (def p : patterns) {
    	def matcher = num =~ p
	    if (matcher.matches()) {
	        return matcher.group(2);
	    }
    }
    
    return null
}

def d0 = '20150901'
def d1 = '20150916'

if (args.length == 2) {
    d0 = args[0]
    d1 = args[1]
}

log("from ${d0} to ${d1}")

def dateBegin = Date.parse("yyyyMMdd", d0)
def dateEnd = Date.parse("yyyyMMdd", d1)


def cnt = 0;
def licnt = 0;
def flag = 0;
DBCursor cursor = collection.find(
    new BasicDBObject(["doDate": new BasicDBObject(['$gte': dateBegin, '$lt': dateEnd])]))
    .sort(new BasicDBObject(['doDate': 1])).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
def total = cursor.count();
log("total: ${total}")
def batchCnt = 0
while (cursor.hasNext()) {
    DBObject dbobj = cursor.next();
    def num;
    def patentNumber
    try {
        patentNumber = dbobj.get("patentNumber")
        def stat = dbobj.get("stat")
        if (stat == 1) {
            if (patentNumber =~ /^[0-9]{11}$/) {
                num = patentNumber
            }
        } else {
            num = parsePatentNumber(patentNumber)
        }
        if (num == null) {
            throw new Exception("parse patentNo:" + patentNumber);
        }
        DBObject doc = collection2.findOne(new BasicDBObject(["_id": num]))
        if (doc != null) {
            if (!doc.get("oid").equals(dbobj.get("_id"))) {
                throw new Exception("duplicate patentNo:" + patentNumber);
            }
        } else {
            tarBulk.insert(new BasicDBObject(["_id": num,
                "oid": dbobj.get("_id")]));
            batchCnt++
        }
    } catch (Exception e) {
        log("ERROR:" + dbobj.get("_id") + " --> " + e.getMessage() + " --> " + patentNumber);
        error.update(new BasicDBObject(["_id": dbobj.get("_id")]),
            new BasicDBObject(["error": e.getMessage()
        ]), true, false);
    }

    cnt++;
    if (cnt % 10000 == 0) {
        log(cnt + " / " + total + " --> " + dbobj.get("doDate"))
        if (batchCnt > 0) {
            def tarResult = tarBulk.execute()
            log('batch updated!')
            tarBulk = collection2.initializeOrderedBulkOperation()
            batchCnt = 0
        }
    }
}
log(cnt)
if (batchCnt > 0) {
    log('batch update')
    tarBulk.execute();
    log('update finish!')
}

println 'finished!'

def log(def s) {
    println new Date().format('yyyy/MM/dd HH:mm:ss') + ' ' + s
}