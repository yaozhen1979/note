package lexisnexis.patent;

import java.io.File;
import java.util.Arrays;
import java.util.zip.ZipFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * 從 LNBackFile Import 之後，檢查 Zip 擋案數量與 Level1 數量
 */
public class CheckCount {
    
    private static Logger logger = LoggerFactory.getLogger(CheckCount.class);
    private static String path = "E:\\LN_US\\US\\Xml\\"; 
    private static int cnt = 0;
    
    public static void main(String[] args) throws Exception {
        processDir("E:\\LN_US\\US\\", "Xml");
    }
    
    public static void processDir(String path, String zipFileName) throws Exception {
        File f = new File(path, zipFileName);
        if (f.isDirectory()) {
            String[] list = f.list();
            int year = 9999;
            try {
                year = Integer.parseInt(f.getName());
            } catch (Exception e) {}
            if (year > 2000) {
                for (String f0 : list) {
                    processDir(path + zipFileName + "/", f0);
                }
            }
        } else {
            cnt++;
            if (cnt % 200 == 0) {
                logger.debug("process cnt:" + cnt);
            }
            process(path, zipFileName);
        }
    }
    
    public static void process(String path, String zipFileName) throws Exception {
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile");

        ZipFile zipFile = new java.util.zip.ZipFile(new File(path + zipFileName));
        int cnt = zipFile.size();
        int count = (int) collection.count(new BasicDBObject("zipFile", zipFileName));
        
        if (cnt != count) {
            logger.error("not match: " + zipFileName + " --> " + cnt + " vs " + count);
        } else {
            //logger.info("match: " + zipFileName + " --> " + cnt);
        }
        
        zipFile.close();
        mongoClient.close();
    }
}
