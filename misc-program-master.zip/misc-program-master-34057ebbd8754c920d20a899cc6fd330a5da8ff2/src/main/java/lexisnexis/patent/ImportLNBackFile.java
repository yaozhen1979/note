package lexisnexis.patent;
import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;


/**
 * 從 LNBackFile Import 到 Level1 的主程式
 */
public class ImportLNBackFile {

    private static Logger logger = LoggerFactory.getLogger(ImportLNBackFile.class);
//    private static String path = "E:\\LN_US\\US\\Xml\\"; 
    
    public static void main(String[] args) throws Exception {
//        String year = args[0];
//        String dirstr = path + year + "/";
        String dirstr = args[0];
        //String dirstr = "E:\\LN_US\\US\\Xml\\1995\\";
        File dir = new File(dirstr);
        String[] list = dir.list();
        for (String f : list) {
            processDir(dirstr, f);
        }
    }
    
    public static void processDir(String path, String zipFileName) throws Exception {
        File f = new File(path, zipFileName);
        if (f.isDirectory()) {
            String[] list = f.list();
            for (String f0 : list) {
                processDir(path + zipFileName + "/", f0);
            }
        } else {
            process(path, zipFileName);
        }
    }
    
    public static void process(String path, String zipFileName) throws Exception {
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile");
        DBCollection errorColl = mongoClient.getDB("LNBackFile").getCollection("ErrorLog");

        //String zipFileName = "US_2015_001.zip";
        ZipFile zipFile = new java.util.zip.ZipFile(new File(path + zipFileName));

        try {
            Enumeration<? extends ZipEntry> en = zipFile.entries();
            logger.debug("start process:" + zipFileName);
            int cnt = 0;
            while (en.hasMoreElements()) {
                if (++cnt % 200 == 0) {
                    logger.debug(zipFileName + " cnt:" + cnt);
                }
                ZipEntry entry = en.nextElement();
                String fileName = entry.getName();
                //logger.debug(fileName);
                String patentNo = fileName.split("\\.")[0];
                
                InputStream input = zipFile.getInputStream(entry);
                
                //錯誤處理
                String xml = IOUtils.toString(input, "utf-8").replace("<citation></citation>", "");
                xml = xml.replaceAll("<references-cited date-changed=\"\\d+\">\\s+</references-cited>", "");
                
                DBObject obj = collection.findOne(new BasicDBObject("_id", patentNo));
                if (obj != null) {
                    if (!obj.get("zipFile").toString().equals(zipFileName)) {
                        logger.error("duplicate:" + zipFileName + ":" + patentNo);
                        Map<Object, Object> map = new HashMap<>();
                        map.put("zipFile", zipFileName);
                        map.put("fileName", fileName);
                        map.put("error", "Duplicate");
                        map.put("xml", xml);
                        map.put("date", new Date());
                        map.put("flag", 0);
                        errorColl.insert(new BasicDBObject(map));
                    }
                    continue;
                }
                
                String jsonstr = null;
                try {
                    jsonstr = ConvertXML.xml2Json(xml);
                } catch (Exception e) {
                    logger.error("xml2Json err:" + fileName + "," + e);
                    Map<Object, Object> map = new HashMap<>();
                    map.put("zipFile", zipFileName);
                    map.put("fileName", fileName);
                    map.put("error", "ToJsonErr");
                    map.put("exception", e.getMessage());
                    map.put("xml", xml);
                    map.put("date", new Date());
                    map.put("flag", 0);
                    errorColl.insert(new BasicDBObject(map));
                    continue;
                }
                
                try {
                    DBObject dbObject = (DBObject) JSON.parse(jsonstr);
                    Map<Object, Object> map = new HashMap<>();
                    map.put("_id", patentNo);
                    map.put("zipFile", zipFileName);
                    map.put("data", dbObject);
                    map.put("date", new Date());
                    collection.insert(new BasicDBObject(map));
                    //logger.debug("insert " + patentNo);
                } catch (Exception e) {
                    logger.error("Insert err:" + fileName + "," + e);
                    Map<Object, Object> map = new HashMap<>();
                    map.put("zipFile", zipFileName);
                    map.put("fileName", fileName);
                    map.put("error", "InsertError");
                    map.put("exception", e.getMessage());
                    map.put("xml", xml);
                    map.put("date", new Date());
                    map.put("flag", 0);
                    errorColl.insert(new BasicDBObject(map));
                    continue;
                }
            }
            logger.debug("end process:" + zipFileName);
        } finally {
            zipFile.close();
        }
        mongoClient.close();
    }
    
}
