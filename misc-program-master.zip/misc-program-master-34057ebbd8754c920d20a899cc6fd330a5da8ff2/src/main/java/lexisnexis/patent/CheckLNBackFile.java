package lexisnexis.patent;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;

/**
 * 一些隨手 check LNBackFile 程式
 */
public class CheckLNBackFile {

    private static Logger logger = LoggerFactory.getLogger(CheckLNBackFile.class);
    private static String path = "E:\\LN_US\\US\\Xml\\"; 
    
    public static void main(String[] args) throws Exception {
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile");
        DBCollection errorColl = mongoClient.getDB("LNBackFile").getCollection("ErrorLog");

        DBCursor c = errorColl.find(new BasicDBObject("error", "InsertError"));

        int cnt = 0;
        while (c.hasNext()) {
            cnt++;
            DBObject obj = c.next();
            String xml = obj.get("xml").toString();
            
            String zipFileName = obj.get("zipFile").toString();
            String fileName = obj.get("fileName").toString();
            String patentNo = fileName.split("\\.")[0];
            
//            String patternStr = "<references-cited date-changed=\"\\d+\">\\s+</references-cited>";
//            Pattern pattern = Pattern.compile(patternStr);
//            Matcher matcher = pattern.matcher(xml);
//            boolean matchFound = matcher.find();
//            System.out.println(matchFound);
            
            xml = xml.replaceAll("<references-cited date-changed=\"\\d+\">\\s+</references-cited>", "");
            //System.out.println(xml);
            String jsonstr = ConvertXML.xml2Json(xml);
            
            DBObject dbObject = (DBObject) JSON.parse(jsonstr);
            Map<Object, Object> map = new HashMap<>();
            map.put("_id", patentNo);
            map.put("zipFile", zipFileName);
            map.put("data", dbObject);
            map.put("date", new Date());
            collection.insert(new BasicDBObject(map));
            
            break;
        }
        
        mongoClient.close();
        System.out.println("finished!");
    }
    
}
