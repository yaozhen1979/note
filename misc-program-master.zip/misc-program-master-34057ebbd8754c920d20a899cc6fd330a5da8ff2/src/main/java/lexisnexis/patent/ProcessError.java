package lexisnexis.patent;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;

/**
 * 一些隨手處理錯誤的程式
 */
public class ProcessError {

    private static Logger logger = LoggerFactory.getLogger(ProcessError.class);
    
    public static void main(String[] args) throws Exception {
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection errorColl = mongoClient.getDB("LNBackFile").getCollection("ErrorLog");

        DBCollection collection = mongoClient.getDB("LNBackFile").getCollection("LNBackFile");
        
        DBCursor c = errorColl.find(new BasicDBObject("error", "InsertError").append("flag", new BasicDBObject("$exists", false)));
        
        int cnt = 0;
        while (c.hasNext()) {
            cnt++;
            
            if (cnt % 200 == 0) {
                logger.debug("cnt:" + cnt);
            }
            
            DBObject row = c.next();
            String xml = row.get("xml").toString();
            String zipFileName = row.get("zipFile").toString();
            String fileName = row.get("fileName").toString();
            String patentNo = fileName.split("\\.")[0];
            
            xml = xml.replaceAll("<references-cited date-changed=\"\\d+\">\\s+</references-cited>", "");
            String jsonstr = ConvertXML.xml2Json(xml);
            System.out.println(xml.length());
            DBObject obj = collection.findOne(new BasicDBObject("_id", patentNo));
            if (obj != null) {
                if (!obj.get("zipFile").toString().equals(zipFileName)) {
                    logger.error("duplicate:" + zipFileName + ":" + patentNo);
                    Map<Object, Object> map = new HashMap<>();
                    map.put("zipFile", zipFileName);
                    map.put("fileName", fileName);
                    map.put("error", "Duplicate");
                    map.put("xml", xml);
                    map.put("date", new Date());
                    //errorColl.insert(new BasicDBObject(map));
                }
                continue;
            }
            
            logger.debug("start to insert ");
            try {
                DBObject dbObject = (DBObject) JSON.parse(jsonstr);
                Map<Object, Object> map = new HashMap<>();
                map.put("_id", patentNo);
                map.put("zipFile", zipFileName);
                map.put("data", dbObject);
                map.put("date", new Date());
                collection.insert(new BasicDBObject(map));
                logger.debug("insert " + patentNo);
            } catch (Exception e) {
                logger.error("Insert err:" + fileName + "," + e, e);
                Map<Object, Object> map = new HashMap<>();
                map.put("zipFile", zipFileName);
                map.put("fileName", fileName);
                map.put("error", "InsertError");
                map.put("exception", e.getMessage());
                map.put("xml", xml);
                map.put("date", new Date());
                //errorColl.insert(new BasicDBObject(map));
                continue;
            }
            
            BasicDBObject flag = new BasicDBObject().append("$set", new BasicDBObject("flag", 1));
            errorColl.update(new BasicDBObject("_id", row.get("_id")), flag);
        }
        
        mongoClient.close();
        logger.debug("finished! " + cnt);
    }
    
}
