package lexisnexis.patent;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import lexisnexis.patent.jaxb.LexisnexisPatentDocumentType;

import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;

public class ConvertXML {

    private static boolean inited;
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    
    public static String xml2Json(String xml) throws Exception {
        return xml2Json(new ByteArrayInputStream(xml.getBytes("utf-8")));
    }
    
    private static void init() throws Exception {
        if (inited) {
            return;
        }
        JAXBContext jc = JAXBContext.newInstance("lexisnexis.patent.jaxb");
        unmarshaller = jc.createUnmarshaller();
        
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        InputStream xsdis = ConvertXML.class.getResourceAsStream("lexisnexis-patent-document_v1-13.xsd");
        Schema schema = sf.newSchema(new StreamSource(xsdis));
        unmarshaller.setSchema(schema);
        
//        marshaller = jc.createMarshaller();
//        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
//        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
//        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        
        InputStream importMoxyBinding = ConvertXML.class.getResourceAsStream("oxm.xml");
        List<InputStream> moxyBindings = new ArrayList<>();
        moxyBindings.add(importMoxyBinding);
        Map<String, Object> props = new HashMap<>();
        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings);
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);
        
        JAXBContext jc1 = JAXBContext.newInstance("lexisnexis.patent.jaxb", LexisnexisPatentDocumentType.class.getClassLoader(), props);
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        
        inited = true;
    }
    
    public static String xml2Json(InputStream xml) throws Exception {
        init();
        
        JAXBElement<LexisnexisPatentDocumentType> elem = (JAXBElement<LexisnexisPatentDocumentType>) unmarshaller.unmarshal(xml);
        
        LexisnexisPatentDocumentType doc = elem.getValue();
        
        StringWriter sw = new StringWriter();
        marshaller.marshal(doc, sw);
        
// Jackson
//        ObjectMapper mapper = new ObjectMapper();
//        AnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
//        mapper.setAnnotationIntrospector(introspector);
//        mapper.setSerializationInclusion(Include.NON_NULL);
//        mapper.writeValue(sw, doc);

        return sw.toString();
    }
    
}
