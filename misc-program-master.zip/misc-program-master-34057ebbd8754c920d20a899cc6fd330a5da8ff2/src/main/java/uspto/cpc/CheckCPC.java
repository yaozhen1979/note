package uspto.cpc;

import java.io.InputStream;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

import uspto.cpc.jaxb.CPCMasterClassificationFileType;
import uspto.cpc.jaxb.CPCMasterClassificationRecordType;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;

public class CheckCPC {

    private static Logger logger = LoggerFactory.getLogger(CheckCPC.class);
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    
    public static void main(String[] args) throws Exception {
        String collName = "CPC_201510";
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB("USPTO").getCollection(collName);
        DBCollection errColl = mongoClient.getDB("USPTO").getCollection(collName + "Err");
        
        DBCursor cursor = errColl.find();

        while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            String json = obj.get("json").toString();
            DBObject obj1 = (DBObject)JSON.parse(json);
            String num = ((DBObject)obj1.get("PatentGrantIdentification")).get("PatentNumber").toString();
            //String bag = ((DBObject)obj1.get("CPCClassificationBag")).toString();
            
            String appnum = ((DBObject)obj1.get("ApplicationIdentification")).get("ApplicationNumber").toString();
            
            String id = "US" + StringUtils.leftPad(num, 9, '0');
            
            DBObject obj2 = collection.findOne(new BasicDBObject("_id", id));
//            String bag2 = ((DBObject)obj2.get("data")).get("CPCClassificationBag").toString();
//            if (!bag.equals(bag2)) {
//                System.out.println("not match:" + id);
//            }
            String appnum2 =((DBObject)((DBObject)obj2.get("data")).get("ApplicationIdentification")).get("ApplicationNumber").toString();
            if (!appnum.equals(appnum2)) {
                System.out.println("not match:" + appnum);
            }
        }
        
        
        mongoClient.close();
    }
    
    private static void init() throws Exception {
        JAXBContext jc = JAXBContext.newInstance("uspto.cpc.jaxb");
        unmarshaller = jc.createUnmarshaller();
        
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        sf.setResourceResolver(new LSResourceResolver() {
            @Override
            public LSInput resolveResource(String type, String namespaceURI,
                    String publicId, String systemId, String baseURI) {
                InputStream resourceAsStream = CheckCPC.class.getResourceAsStream(systemId);
                try {
                    return new Input(publicId, systemId, IOUtils.toString(resourceAsStream));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        Schema schema = sf.newSchema(new Source[] {
                new StreamSource(CheckCPC.class.getResourceAsStream("CPCMasterClassificationFile.xsd")),
        });
        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);
        
        JAXBContext jc1 = JAXBContext.newInstance("uspto.cpc.jaxb", CPCMasterClassificationRecordType.class.getClassLoader(), props);
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    }
    
    private static CPCMasterClassificationFileType xml2Object(InputStream xml) throws Exception {
        JAXBElement<CPCMasterClassificationFileType> elem = (JAXBElement<CPCMasterClassificationFileType>) unmarshaller.unmarshal(xml);
        CPCMasterClassificationFileType doc = elem.getValue();
        return doc;
    }
    
    private static String object2json(CPCMasterClassificationRecordType obj) throws Exception {
        StringWriter sw = new StringWriter();
        marshaller.marshal(obj, sw);
        
        return sw.toString();
    }
}