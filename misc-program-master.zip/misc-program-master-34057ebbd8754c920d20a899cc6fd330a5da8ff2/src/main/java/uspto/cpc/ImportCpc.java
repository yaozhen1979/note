package uspto.cpc;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

import uspto.cpc.jaxb.ApplicationIdentificationType;
import uspto.cpc.jaxb.CPCMasterClassificationFileType;
import uspto.cpc.jaxb.CPCMasterClassificationRecordType;
import uspto.cpc.jaxb.PatentGrantIdentificationType;
import uspto.cpc.jaxb.PatentPublicationIdentificationType;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;

/**
 * 公告專利同一號碼早期資料會有 kindcode=A or B1 兩筆
 * 所以會 duplicate 而寫不進去 DB
 * 經排查後這些重複的，其 CPC 內容都一樣，申請號也一樣
 */
public class ImportCpc {

    private static Logger logger = LoggerFactory.getLogger(ImportCpc.class);
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    
    public static void main(String[] args) throws Exception {
        init();
        
        String dirstr = "E:\\US_Grant_CPC_MCF_XML_2015-10-31\\";
//        String dirstr = "E:\\US_PGPub_CPC_MCF_XML_2015-10-31\\";
        File dir = new File(dirstr);
        String[] list = dir.list();
        for (String f : list) {
            if (f.endsWith("xml")) {
                process(dirstr, f, "CPC_201510");
            }
        }
    }
    
    public static void process(String path, String fileName, String collName) throws Exception {
        MongoCredential credential = MongoCredential.createCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.101", 27017),
                            Arrays.asList(credential));
        DBCollection collection = mongoClient.getDB("USPTO").getCollection(collName);
        DBCollection errColl = mongoClient.getDB("USPTO").getCollection(collName + "Err");

        if (!fileName.startsWith("US_Grant_CPC_MCF_")
                && !fileName.startsWith("US_PGPub_CPC_MCF_")) {
            throw new RuntimeException("error fileName:" + fileName);
        }
        boolean grant = fileName.startsWith("US_Grant_CPC_MCF_");
        
        FileInputStream fis = new FileInputStream(new File(path, fileName));
        CPCMasterClassificationFileType root = xml2Object(fis);
        System.out.println(fileName + " ==> " + root.getCPCMasterClassificationRecord().size());
        
        List<CPCMasterClassificationRecordType> list = root.getCPCMasterClassificationRecord();
        
        for (CPCMasterClassificationRecordType record : list) {
            String rec = object2json(record);
            
            String id = null;
            if (grant) {
                id = "US" + StringUtils.leftPad(record.getPatentGrantIdentification().getPatentNumber(), 9, '0');
            } else {
                id = record.getPatentPublicationIdentification().getPublicationNumber();
            }
            try {
                DBObject dbObject = (DBObject) JSON.parse(rec);
                Map<Object, Object> map = new HashMap<>();
                map.put("_id", id);
                map.put("fileName", fileName);
                map.put("data", dbObject);
                map.put("date", new Date());
                map.put("stat", grant ? 2 : 1);
                collection.insert(new BasicDBObject(map));
                //logger.debug("insert " + patentNo);
            } catch (Exception e) {
                logger.error("Insert err:" + fileName + "," + e);
                Map<Object, Object> map = new HashMap<>();
                map.put("fileName", fileName);
                map.put("error", "InsertError");
                map.put("exception", e.getMessage());
                map.put("json", rec);
                map.put("date", new Date());
                map.put("flag", 0);
                map.put("stat", grant ? 2 : 1);
                errColl.insert(new BasicDBObject(map));
                continue;
            }
        }
        
        mongoClient.close();
    }
    
    private static void init() throws Exception {
        JAXBContext jc = JAXBContext.newInstance("uspto.cpc.jaxb");
        unmarshaller = jc.createUnmarshaller();
        
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        sf.setResourceResolver(new LSResourceResolver() {
            @Override
            public LSInput resolveResource(String type, String namespaceURI,
                    String publicId, String systemId, String baseURI) {
                InputStream resourceAsStream = ImportCpc.class.getResourceAsStream(systemId);
                try {
                    return new Input(publicId, systemId, IOUtils.toString(resourceAsStream));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        Schema schema = sf.newSchema(new Source[] {
                new StreamSource(ImportCpc.class.getResourceAsStream("CPCMasterClassificationFile.xsd")),
        });
        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);
        
        JAXBContext jc1 = JAXBContext.newInstance("uspto.cpc.jaxb", CPCMasterClassificationRecordType.class.getClassLoader(), props);
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    }
    
    private static CPCMasterClassificationFileType xml2Object(InputStream xml) throws Exception {
        JAXBElement<CPCMasterClassificationFileType> elem = (JAXBElement<CPCMasterClassificationFileType>) unmarshaller.unmarshal(xml);
        CPCMasterClassificationFileType doc = elem.getValue();
        return doc;
    }
    
    private static String object2json(CPCMasterClassificationRecordType obj) throws Exception {
        StringWriter sw = new StringWriter();
        marshaller.marshal(obj, sw);
        
        return sw.toString();
    }
}