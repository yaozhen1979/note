package com.patentcloud.servlet;

import itec.patent.common.MongoInitUtils;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet(loadOnStartup = 1, urlPatterns = "/_init_")
public class InitServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(InitServlet.class);
    
    static {
        MongoInitUtils.nothing();
    }
}
