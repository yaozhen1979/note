package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.PatentInfo2.PtoPid;
import itec.util.FileUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

import com.patentcloud.utils.MongoUtils;
import com.patentcloud.utils.PtoPidUtils;
import com.patentcloud.vo.query.PatentFile;
    
@WebServlet(urlPatterns = "/GetImage")
public class GetImage extends HttpServlet {
    
    static Log log = LogFactory.getLog(GetImage.class);
    private static final long serialVersionUID = 1L;        
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        ServletOutputStream os = res.getOutputStream();
        FileInputStream fis = null;
        try {
            String parent = req.getParameter("parent");
            String fileName = req.getParameter("fileName");
            String pidStr = req.getParameter("ptopid");
            PtoPid ptopid = PtoPidUtils.getPtoPid(pidStr);
            
            PatentInfo2 info = PatentInfo2.findOne(ptopid.pto, ptopid.id, "pto", "patentNumber", "kindcode", "stat", "doDate");
            String parentPath = String.format("%s/%s/%s/%s"
                    , ConfigUtils.get("image.path")
                    , "patent_" + MongoUtils.ptoMap.get(info.pto.toString()).toLowerCase()
                    , "data"
                    , MongoUtils.getRelPatentPath(info));
            
           if (!parent.equals("")) {
               parent = File.separator + parent;
           }
           String path = parentPath + parent + File.separator + fileName;
           
           PatentFile pFile = new PatentFile();
           pFile.info = info;
           pFile.file = new File(path);
           pFile.mimeType = FilenameUtils.getExtension(pFile.file.getName()).toLowerCase();
           
           if (!pFile.mimeType.equals("pdf") && !pFile.mimeType.equals("png")) {
        	   File cacheFile = Paths.get(ConfigUtils.get("cache.path")).resolve("cache.png").toFile();
        	   FileUtil.sureDirExists(cacheFile, true);
        	   LinkedList<String> cmd = new LinkedList<String>();
               if(System.getProperty("os.name").toLowerCase().indexOf("win") >= 0) {
                   cmd.add("cmd.exe");
                   cmd.add("/C");
               } else {
                   cmd.add("sudo");
               }
               cmd.add("convert");
               cmd.add("-density");
               cmd.add("400");
               cmd.add(pFile.file.getAbsolutePath());
               cmd.add(cacheFile.getAbsolutePath());
               ProcessBuilder pb=new ProcessBuilder(cmd);
               pb.redirectErrorStream(true);
               Process process=pb.start();
               BufferedReader inStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream())); 
               String line = "";
               while((line = inStreamReader.readLine()) != null){
                   log.error("imagemagic meg : " + line);
               }
               pFile.file = cacheFile;
           }
           
           fis = new FileInputStream(pFile.file);
           IOUtils.copy(fis, os);
           os.flush();
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        } finally {
            os.close();
            if (fis != null) {
                fis.close();
            }
        }
    }
}
