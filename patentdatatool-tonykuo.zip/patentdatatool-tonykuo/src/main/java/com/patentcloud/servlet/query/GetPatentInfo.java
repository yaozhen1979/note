package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.PatentInfo2.PtoPid;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;

import com.mongodb.DBObject;
import com.patentcloud.utils.PtoPidUtils;

@WebServlet(urlPatterns = "/GetPatentInfo")
public class GetPatentInfo extends HttpServlet {
    
    static Log log = LogFactory.getLog(GetPatentInfo.class);
    private static final long serialVersionUID = 1L;
    
    private static class Output extends JSonOutput {
        @SuppressWarnings("unused")
        public DBObject data;
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output output = new Output();
        try {
            String pidStr = req.getParameter("ptopid");
            PtoPid ptopid = PtoPidUtils.getPtoPid(pidStr);
            output.data = PatentInfo2.findOneDBObj(PatentInfo2.getClass(ptopid.pto), ptopid.id);
        } catch (Exception e) {
            res.sendError(468, e.getMessage());
            return;
        }
        res.setHeader("Content-type", "text/html;charset=UTF-8");
        output.status = 200;
        output.write(res);
    }
}
