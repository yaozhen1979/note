package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.commons.cli.ParseException;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.lowagie.text.pdf.PdfReader;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.patentcloud.utils.MongoUtils;
import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.SeekableStream;

@ServerEndpoint("/imageCheck")
public class ImageCheck {
	
	static Log log = LogFactory.getLog(ImageCheck.class);
	
	public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "USPTO";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
	@OnMessage
	public void onMessage(String message, Session session) throws IOException, InterruptedException, ParseException {
		ArgParser argParser = new ArgParser().addOpt(ImageCheck.class).parse(message.split("\\s"));
		print(session, "start, opt: " + argParser.getParsedMap());
		
		Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        Path targetPath = Paths.get(ConfigUtils.get("image.path")).resolve("patent_" + MongoUtils.ptoMap.get(pto.toString()).toLowerCase()).resolve("data");
        String dateRange = argParser.getOptString("t");
        QueryHelp query = MongoUtils.getDateRange(dateRange);
        
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count()).setFormatDefNum();
        while (cursor.hasNext()) {
        	PatentInfo2 info = null;
        	try {
        		DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                Path path = targetPath.resolve(MongoUtils.getRelPatentPath(info));
                Integer pageNum = info.filePageNumber;
                if (pageNum == null || pageNum == 0) {
                	print(session, "log" + MongoUtils.getErrorMessage(info) + " ; filePageNumber error");
                	continue;
                }
                
                File fullPageFile = path.resolve("fullPage.pdf").toFile();
                if (fullPageFile.exists()) {
                	PdfReader pdfReader = new PdfReader(fullPageFile.getAbsolutePath());
                	Integer pdfNum = pdfReader.getNumberOfPages();
                	if (pageNum.equals(pdfNum)) {
                		continue;
                	} else {
                		print(session, "log" + MongoUtils.getErrorMessage(info) + " ; filePageNumber not match");
                		continue;
                	}
                }
                
                File fullImageFile = path.resolve("fullImage").toFile();
                if (fullImageFile.exists()) {
                	File[] fullImageFiles = fullImageFile.listFiles();
                	Integer imageNum = fullImageFiles.length;
                	if (pageNum.equals(imageNum)) {
                		for (File file: fullImageFiles) {
                    		checkImageBroken(file);
                    	}
                		continue;
                	} else {
                		print(session, "log" + MongoUtils.getErrorMessage(info) + " ; filePageNumber not match");
                		continue;
                	}
                }
                print(session, "log" + MongoUtils.getErrorMessage(info) + " ; no image file");
        	} catch (Exception e) {
        		print(session, "log" + MongoUtils.getErrorMessage(info) + " ; image broken: " + e.getMessage());
        	} finally {
        		pe.addNum().debug(session, 10000, sdf.format(info.doDate));
        	}
        }
        print(session, "finish");
	}
	
	public void print(Session session, String msg) throws IOException {
		log.debug(msg);
		session.getBasicRemote().sendText(msg);
	}
	
	@OnOpen
	public void onOpen() {
		log.debug("Client connected");
	}

	@OnClose
	public void onClose() {
		log.debug("Connection closed");
	}
	
	public void checkImageBroken(File file) throws Exception {
		String ext = FilenameUtils.getExtension(file.getName()).toLowerCase();
		if (extMimeTypeMap.containsKey(ext)) {
			SeekableStream ss = new FileSeekableStream(file);  
		    ImageDecoder dec = ImageCodec.createImageDecoder(extMimeTypeMap.get(ext), ss, null);  
		    @SuppressWarnings("unused")
			int num = dec.getNumPages();  
        }
	}
	
	@SuppressWarnings("serial")
	private static HashMap<String, String> extMimeTypeMap = new HashMap<String, String>() {{
        //put("gif", "gif");
        put("jpg", "jpeg");
        put("png", "png");
        put("tif", "tiff");
    }};
    
    public class ProcessEstimater {
    	private int SLOT_SIZE;
    	private int SLOT_GAPTIME;
    	private long[] numList;
    	private long[] timeList;
    	private long max = 0;
    	private long skip = 0;
    	private int slot = -1;
    	private String outputFormat = "%1$s";

    	public ProcessEstimater(long max) {
    		init(30, 1000, max, 0);
    	}

    	private void init(int slotSize, int slotGapTime, long max, long skip) {
    		this.SLOT_SIZE = 30;
    		this.SLOT_GAPTIME = 1000;
    		numList = new long[SLOT_SIZE];
    		timeList = new long[SLOT_SIZE];

    		this.max = max;
    		this.skip = skip;
    	}

    	public synchronized ProcessEstimater setNum(long num) {
    		long now = System.currentTimeMillis();
    		if (slot < 0) {
    			slot = 0;
    			for (int i=0 ; i<SLOT_SIZE ; i++) {
    				numList[i] = num;
    				timeList[i] = now;
    			}
    		} else {
    			if ((now - timeList[(slot + SLOT_SIZE - 1) % SLOT_SIZE]) > SLOT_GAPTIME) {
    				slot = (slot + 1) % SLOT_SIZE;
    			}
    			numList[slot] = num;
    			timeList[slot] = now;
    		}
    		return this;
    	}

    	public long getNum() {
    		if (slot < 0) {
    			return 0;
    		}
    		return numList[slot];
    	}

    	public ProcessEstimater addNum(long add) {
    		return setNum(getNum() + add);
    	}

    	public ProcessEstimater addNum() {
    		return addNum(1);
    	}

    	public ProcessEstimater setRestNum(long rest) {
    		long num = max - skip - rest;
    		return setNum(num);
    	}

    	public long getRestNum() {
    		return max - getNum();
    	}

    	private long getRestTime() {
    		if (slot < 0) {
    			return -1;
    		}
    		int slotcmp = (slot + 1) % SLOT_SIZE;
    		long diffTime = timeList[slot] - timeList[slotcmp];
    		long diffNum = numList[slot] - numList[slotcmp];
    		if (diffNum < 1) {
    			return 0;
    		}
    		return getRestNum() * diffTime / diffNum;
    	}

    	public String getRestString() {
    		long rest = getRestTime();
    		rest = Math.max(rest, 0);

    		int msec = (int) (rest % 1000);
    		rest /= 1000;

    		int sec = (int) (rest % 60);
    		rest /= 60;

    		int min = (int) (rest % 60);
    		rest /= 60;

    		int hr = (int) rest;

    		if (hr > 0) {
    			return String.format("%1$02d:%2$02d:%3$02d", hr, min, sec, msec);
    		} else if (min > 0) {
    			return String.format("%2$02d:%3$02d", hr, min, sec, msec);
    		} else {
    			return String.format("%3$02d.%4$03d", hr, min, sec, msec);
    		}
    	}

    	public ProcessEstimater setFormat(String format) {
    		this.outputFormat = format;
    		return this;
    	}

    	public ProcessEstimater setFormatDefNum() {
    		return setFormat("%2$d / %4$d (%5$.2f%%) , Rest time: %1$s");
    	}

    	public ProcessEstimater setFormatDefRest() {
    		return setFormat("%3$d / %4$d (%6$.2f%%) , Rest time: %1$s");
    	}

    	@Override
    	public String toString() {
    		long num, rest;
    		float curPercent, restPercent;
    		num = getNum();
    		rest = getRestNum();
    		if (max > 0) {
    			curPercent = (float) 100.0 * num / max;
    			restPercent = (float) 100.0 * rest / max;
    		} else {
    			curPercent = restPercent = 0;
    		}
    		return String.format(outputFormat, getRestString(), num, rest, max, curPercent, restPercent);
    	}

    	private Date prevMsg = null;
    	public ProcessEstimater debug(Session session, long minTime, String msg) throws IOException {
    		if (minTime > 0 && prevMsg != null && prevMsg.after(new Date())) {
    			return this;
    		}
    		prevMsg = new Date(new Date().getTime() + minTime);
    		if (msg != null) {
    			print(session, toString() + " " + msg);
    		} else {
    			print(session, toString());
    		}
    		return this;
    	}
    }
}
