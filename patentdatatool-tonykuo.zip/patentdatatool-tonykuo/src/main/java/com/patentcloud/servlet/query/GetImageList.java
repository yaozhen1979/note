package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.PatentInfo2.PtoPid;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;
import org.tsaikd.java.utils.ConfigUtils;

import com.patentcloud.utils.MongoUtils;
import com.patentcloud.utils.PtoPidUtils;
import com.patentcloud.vo.query.ImageFile;

@WebServlet(urlPatterns = "/GetImageList")
public class GetImageList extends HttpServlet {

    static Log log = LogFactory.getLog(GetImageList.class);
    private static final long serialVersionUID = 1L;
    
    private static class Output extends JSonOutput {
        public ArrayList<ImageFile> data = new ArrayList<>();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output output = new Output();
        try {
            String pidStr = req.getParameter("ptopid");
            PtoPid ptopid = PtoPidUtils.getPtoPid(pidStr);
            
            PatentInfo2 info = PatentInfo2.findOne(ptopid.pto, ptopid.id, "pto", "patentNumber", "kindcode", "stat", "doDate");
            String parentPath = String.format("%s/%s/%s/%s"
                    , ConfigUtils.get("image.path")
                    , "patent_" + MongoUtils.ptoMap.get(info.pto.toString()).toLowerCase()
                    , "data"
                    , MongoUtils.getRelPatentPath(info));
            
           File parentFile = new File(parentPath);
           if (!parentFile.exists()) {
               res.sendError(404, "no image found");
               return;
           }
           
           File[] files = parentFile.listFiles();
           for (File file: files) {
               ImageFile imgFile = new ImageFile(file.getName());
               if (file.isDirectory()) {
                   File[] subFiles = file.listFiles();
                   for (File subFile: subFiles) {
                       if (subFile.getName().endsWith("tif") || subFile.getName().endsWith("png") || subFile.getName().endsWith("pdf")) {
                           imgFile.childs.add(new ImageFile(subFile.getName()));
                       }
                   }
                   
                   Collections.sort(imgFile.childs, new Comparator<ImageFile>() {
                       @Override
                       public int compare(ImageFile o1, ImageFile o2) {
                           return getPageNumber(o1.name).compareTo(getPageNumber(o2.name));
                       }
                   });
               } 
               output.data.add(imgFile);
           }
           
           output.write(res);
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
    
    public Integer getPageNumber(String fileName) {
        try {
            String num = fileName.substring(0, fileName.indexOf("."));
            return Integer.parseInt(num);
        } catch (Exception e) {
            return 0;
        }
    }
}
