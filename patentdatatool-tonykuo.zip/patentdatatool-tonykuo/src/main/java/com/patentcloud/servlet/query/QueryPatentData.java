package com.patentcloud.servlet.query;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.Gson;
import com.patentcloud.utils.DbUtils;

@WebServlet(urlPatterns = "/QueryPatentData")
public class QueryPatentData extends HttpServlet {
    
    static Log log = LogFactory.getLog(QueryFilePageNumber.class);
    
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try {
            String sql = req.getParameter("sql");
            String ds = req.getParameter("ds");
            
            DbUtils db = new DbUtils();
            db.fetchData(sql, ds);
            
            Gson gson = new Gson();
            String data = gson.toJson(db.getData());
            StringBuilder columns = new StringBuilder("[");
            for (String col : db.getColumns()) {
                columns.append(String.format("{\"data\":\"%s\", \"title\":\"%s\"},", col, col));
            }
            columns.deleteCharAt(columns.length()-1);
            columns.append("]");
            
            String result = "{"
                    + "\"data\": " + data + ","
                    + "\"columns\": " + columns
                    + "}";
            
            res.getOutputStream().write(result.getBytes());
            res.getOutputStream().flush();
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
}
