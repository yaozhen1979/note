package com.patentcloud.servlet.download;

import itec.util.HttpUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;

@WebServlet(urlPatterns = "/GetUSEmbeddedImageYear")
public class GetUSEmbeddedImageYear extends HttpServlet {
    
    static Log log = LogFactory.getLog(GetUSEmbeddedImageYear.class);
    private static final long serialVersionUID = 1L;
    
    private static String pubUrl = "http://www.google.com/googlebooks/uspto-patents-applications-text-with-embedded-images.html";
    private static String grantUrl = "http://www.google.com/googlebooks/uspto-patents-redbook.html";
    
    private static class Output2 extends JSonOutput {
        public List<String> data = new ArrayList<>();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output2 output = new Output2();
        
        String type = req.getParameter("type");
        String content = "";
        try {
            switch (type) {
            case "Publication":
                content = HttpUtil.getResponseAsString(pubUrl);
                break;
            case "Grant":
                content = HttpUtil.getResponseAsString(grantUrl);
                break;
            default:
                throw new IllegalArgumentException("Invalid Patent Type");
            }
            
            Matcher mat = Pattern.compile("<a href=\"#(.*?)\">", Pattern.CASE_INSENSITIVE).matcher(content);
            while (mat.find()) {
                output.data.add(mat.group(1));
            }
            output.write(res);
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
}
