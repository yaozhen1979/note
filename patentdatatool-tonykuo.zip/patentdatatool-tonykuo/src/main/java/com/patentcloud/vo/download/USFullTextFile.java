package com.patentcloud.vo.download;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class USFullTextFile extends MongoObject {
    
    public String fileName;
    
    public boolean isDownload;
    
    public String fileSize;
    
    public Date fileDate;
    
    public String url;
}
