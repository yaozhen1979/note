package com.patentcloud.utils;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;
import itec.patent.mongodb.patentinfo2.PatentInfoEPO;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;

public class MongoUtils {
    
    static Log log = LogFactory.getLog(MongoUtils.class);
    
    public static HashMap<String, String> ptoMap = new HashMap<String, String>() {	
		private static final long serialVersionUID = -1093800027239291314L;
	{
        put("US", "US");
        put("USPTO", "US");
        put("CN", "CN");
        put("CNIPR", "CN");
        put("JP", "JP");
        put("JPO", "JP");
        put("EP", "EP");
        put("EPO", "EP");
        put("WO", "WO");
        put("WIPO", "WO");
        put("KR", "KR");
        put("KIPO", "KR");
        put("TW", "TW");
        put("TIPO", "TW");
    }};
    
    public static String getRelPatentPath(PatentInfo2 info) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        return String.format("%s%d%s/%s/%s"
            , ptoMap.get(info.pto.toString()).toLowerCase()
            , info.stat
            , info.kindcode == null ? "" : info.kindcode.toLowerCase()
            , sdf.format(info.doDate)
            , info.patentNumber.replaceAll("[\\/\\s]", "").toLowerCase()
        );
    }
    
    public static QueryHelp getDateRange(String dateRange) {
        if (dateRange == null || dateRange.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (dateRange.contains("-")) {
            String[] tParts = dateRange.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (dateRange.contains("+")) {
            int caltype;
            String[] tParts = dateRange.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }
            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype, calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }
        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }
    
    public static void init() {
    	MongoInitUtils.nothing();
    }
    
    public static void init(Pto pto) {
    	MongoInitUtils.nothing();
    	switch (pto) {
        case USPTO:
        	MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        	break;
        case CNIPR:
        	MappedClass.getMappedClass(PatentInfoCNIPR.class).setDB(MappedClass.db.getSisterDB("PatentInfoCNIPR"));
        	break;
        case TIPO:
        	MappedClass.getMappedClass(PatentInfoTIPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoTIPO"));
        	break;
        case EPO:
        	MappedClass.getMappedClass(PatentInfoEPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoEPO"));
        	break;
        case WIPO:
        	MappedClass.getMappedClass(PatentInfoWIPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoWIPO"));
        	break;
        case JPO:
        	MappedClass.getMappedClass(PatentInfoJPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoJPO"));
        	break;
        case KIPO:
        	MappedClass.getMappedClass(PatentInfoKIPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoKIPO"));
        	break;
        default:
        	break;
        }
    }
    
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public static String getErrorMessage(PatentInfo2 info) {
    	return info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
    }
}
