date.format.js		http://blog.stevenlevithan.com/archives/date-time-format
