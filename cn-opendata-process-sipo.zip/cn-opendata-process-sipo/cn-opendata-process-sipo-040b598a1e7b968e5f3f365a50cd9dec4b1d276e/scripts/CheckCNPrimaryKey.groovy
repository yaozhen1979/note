import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.utils.MailUtil
import org.utils.RestTimeProcess

def ln = System.getProperty('line.separator')

def auth = MongoCredential.createMongoCRCredential("patentdata", "admin", "data.cloud.Abc12345" as char[])
def dbClient = new GMongoClient(new ServerAddress("10.60.90.121", 27017), [auth])

def db = dbClient.getDB("PatentInfoCNIPR")

def queryCursor = db.PatentInfoCNIPR.find()
queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);

RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), "CheckCNPrimaryKey")

File fileLog = new File("logs/CheckCNPrimaryKey.log")

queryCursor.limit(0).each { it -> 
    
    // def patentNumber = it.patentNumber
    def stat = it.stat
    def kindcode = it.kindcode
    
    /*
     * TODO: 2015-11-13 : 有問題, CN的patentNumber其實就是appNumber..., 所以應要以openNumber or decisionNumber來判斷...
     *       因為早期的CN的資料, appNumber = patentNumber (多早的資料 ???)
     */
    def queryMap = null
    
    if (stat == 1) {
        queryMap = [openNumber: it.openNumber, stat: stat]
    } else if (stat == 2) {
        queryMap = [decisionNumber: it.decisionNumber, stat: stat]
    } else {
        fileLog << "_id: ${it._id}, ${queryMap} => stat error" << ln
    }
    
    def queryData = db.PatentInfoCNIPR.find(queryMap)
    queryData.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
    
    if (queryData.count() == 1) {
        // do nothing...
    } else if (queryData.count() == 0) {
        fileLog << "_id: ${it._id}, ${queryMap} => no data exists" << ln
    } else {
        fileLog << "_id: ${it._id}, ${queryMap} => data size over 1" << ln
    }
    
    restTimeProcess.process()
    
}

println "finished..."


