// T:\cnlist\opendata_test\FM\2015\20150923


def count = new File("T:\\cnlist\\opendata\\FM\\2015\\20150923").listFiles().size()

println "count = $count"