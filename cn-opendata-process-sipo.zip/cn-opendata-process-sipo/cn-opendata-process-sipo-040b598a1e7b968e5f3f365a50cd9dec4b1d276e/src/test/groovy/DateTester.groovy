import org.joda.time.DateTime
import org.joda.time.LocalDate

// import org.joda.*

// import java.text.SimpleDateFormat
//
//// String input = "20131228";
//String input = "20140104";
//String format = "yyyyMMdd";
//
//SimpleDateFormat df = new SimpleDateFormat(format);
//Date date = df.parse(input);
//
//println "date = ${date}"
//
//Calendar cal = Calendar.getInstance();
//cal.setTime(date);
//int week = cal.get(Calendar.WEEK_OF_YEAR);
//
//println "week = ${week}"

DateTime dt1 = new DateTime();
println dt1.weekOfWeekyear

LocalDate localDate = new LocalDate(2015, 1, 7);
println localDate
println localDate.weekOfWeekyear
