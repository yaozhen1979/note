package org.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class CaptchaUtilTester {

    @Test
    public void testAppNumber8code() {
        assert "87103893.5" == CaptchaUtil.genAppNumberWithCaptcha('87103893', true)
        
    }
    
    @Test
    public void testAppNumber12code() {
        assert "200580034547.2" == CaptchaUtil.genAppNumberWithCaptcha('200580034547', true)
    }
    
    @Test
    public void testAppNumber8codeIncludeCaptcha() {
        assert "87103893.5" == CaptchaUtil.genAppNumberWithCaptcha('87103893.5', true)
    }
    
    @Test
    public void testAppNumber12codeIncludeCaptcha() {
        assert "200580034547.2" == CaptchaUtil.genAppNumberWithCaptcha('200580034547.2', true)
    }
    
}
