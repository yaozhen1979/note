package org.utils;

import static org.junit.Assert.*

import org.junit.Ignore
import org.junit.Test

public class CDataProcessTester {
    
    @Ignore
    @Test
    public void testCDataProcess() throws Exception {
        String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" + 
                "<wips-patent-document>\r\n" + 
                "  <description>"
                + "</SB>" + 
                "<SB>2</SB><SB>2</SB></description>\r\n" + 
                "</wips-patent-document>";
        
        CDataProcess process = new CDataProcess(true, "/wips-patent-document/description", "/wips-patent-document/wips-patent-document/claims");
        
        String newXml = process.transfer(xml);
        System.out.println(newXml);
    }
    
    @Ignore
    @Test
    public void testCDataProcessCNData_1() throws Exception {
        
        String xmlStr = new File("opendata-sample/SD/200410074924.2/200410074924NEW.XML").getText("UTF-8")
        // println "xmlStr = ${xmlStr}"
        
        CDataProcess process = new CDataProcess(true, 
            "/cn-patent-document/cn-bibliographic-data/abstract",
            "/cn-patent-document/application-body/description",
            "/cn-patent-document/application-body/claims");
        
        String newXmlStr = process.transfer(xmlStr);
        
        System.out.println(newXmlStr);
        
    }
    
    @Test
    public void testCDataProcessCNData_2() throws Exception {
        
        String xmlStr = new File("opendata-sample/XX/92229828.9/92229828NEW.XML").getText("UTF-8").replaceAll(/<!--\s+SIPO\s+<DP\s+n="\d+">\s+-->/, "")
        // println "xmlStr = ${xmlStr}"
        
        CDataProcess process = new CDataProcess(true,
            "/cn-patent-document/cn-bibliographic-data/abstract",
            "/cn-patent-document/application-body/description",
            "/cn-patent-document/application-body/claims");
        
        String newXmlStr = process.transfer(xmlStr);
        
        System.out.println(newXmlStr);
        
    }

}
