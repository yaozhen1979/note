import org.jsoup.Connection

Connection.Response resp = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/index.action").timeout(300000)

println "resp = ${resp}"