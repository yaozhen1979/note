package org.valid;

import static java.nio.file.Files.readAllBytes;
import static java.nio.file.Paths.get;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.jaxb.CnPatentDocument;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class XmlValidator2Tester {

    public static void main(String[] args) throws SAXException, IOException,
            ParserConfigurationException, JAXBException {

        DocumentBuilder db = null;

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        db = dbf.newDocumentBuilder();

        db.setEntityResolver(new CnIgnoreDTDEntityResolver(
                "file:/dtd/cn-patent-document-06-10-27.dtd"));

        Document doc = db.parse(new File(
                "opendata-sample/FM/201180019236.4/201180019236NEW.XML"));

        SchemaFactory factory = SchemaFactory
                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        File schemaLocation = new File("xsd/cn-patent-document-06-10-27.xsd");
        Schema schema = factory.newSchema(schemaLocation);
        Validator validator = schema.newValidator();

        validator.validate(new DOMSource(doc));

        System.out.println("valid xml ok...");

        // TODO: parse xml to json
        Unmarshaller unmarshaller = null;
        Marshaller marshaller = null;
        JAXBContext jc = JAXBContext.newInstance("org.jaxb");
        unmarshaller = jc.createUnmarshaller();

        // validation xsd
//        SchemaFactory sf = SchemaFactory
//                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
//        InputStream xsdis = new FileInputStream(new File("xsd/cn-patent-document-06-10-27.xsd"));
//        Schema schema = sf.newSchema(new StreamSource(xsdis));
//        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();
        
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        JAXBContext jc1 = JAXBContext.newInstance("org.jaxb",
                CnPatentDocument.class.getClassLoader(), props);
        
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        
        String xml = new String(readAllBytes(get("opendata-sample/FM/201180019236.4/201180019236NEW.XML")));
        InputStream xmlStream = new ByteArrayInputStream(xml.getBytes("utf-8"));
        Object elem = unmarshaller.unmarshal(xmlStream);

        StringWriter sw = new StringWriter();
        marshaller.marshal(elem, sw);

        System.out.println(sw.toString());
        
    }

}
