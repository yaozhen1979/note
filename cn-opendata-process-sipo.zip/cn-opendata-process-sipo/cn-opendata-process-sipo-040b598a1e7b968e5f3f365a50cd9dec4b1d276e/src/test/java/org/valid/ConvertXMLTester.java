package org.valid;

import static java.nio.file.Files.readAllBytes;
import static java.nio.file.Paths.get;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.jaxb.CnPatentDocument;

public class ConvertXMLTester {

    private static boolean inited;
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;

    public static String xml2Json(String xml) throws Exception {
        return xml2Json(new ByteArrayInputStream(xml.getBytes("utf-8")));
    }
    
    /**
     * verify xml data
     * 
     * @throws Exception
     */
    private static void init() throws Exception {
        
        if (inited) {
            return;
        }
        
        JAXBContext jc = JAXBContext.newInstance("org.jaxb");
        unmarshaller = jc.createUnmarshaller();

        // validation xsd
        SchemaFactory sf = SchemaFactory
                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        InputStream xsdis = new FileInputStream(new File("xsd/cn-patent-document-06-10-27.xsd"));
        Schema schema = sf.newSchema(new StreamSource(xsdis));
        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();
        
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        JAXBContext jc1 = JAXBContext.newInstance("org.jaxb",
                CnPatentDocument.class.getClassLoader(), props);
        
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        inited = true;
        
    }

    public static String xml2Json(InputStream xml) throws Exception {
        
        init();

        // JAXBElement<CnPatentDocument> elem = (JAXBElement<CnPatentDocument>) unmarshaller.unmarshal(xml);
        // CnPatentDocument doc = elem.getValue();
        
        Object elem = unmarshaller.unmarshal(xml);

        StringWriter sw = new StringWriter();
        marshaller.marshal(elem, sw);

        return sw.toString();
    }
    
    public static void main(String[] args) throws Exception {
        
        String xml = new String(readAllBytes(get("opendata-sample/FM/201180019236.4/201180019236NEW.XML")));
        // System.out.println(xml);
        
        System.out.println(ConvertXMLTester.xml2Json(xml));
        
    }

}
