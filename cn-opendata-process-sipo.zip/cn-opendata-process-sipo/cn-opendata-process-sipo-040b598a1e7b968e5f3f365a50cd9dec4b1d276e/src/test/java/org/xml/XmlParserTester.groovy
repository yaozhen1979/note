import groovy.xml.*

def xmlFile = new File("opendata-sample/FM/201180019236.4/201180019236NEW.XML")

// println xmlFile.text

def root = new XmlParser().parse(xmlFile)
// def description = new XmlNodePrinter(preserveWhitespace:false).print(root.'application-body'.'description'[0])

// println root.'application-body'.'description'[0]

def trimDescription = XmlUtil.serialize(root.'application-body'.'description'[0])

def test = ""
trimDescription.eachLine { line -> 
    def lineStr = line.toString()
    test += lineStr.trim()
}

// println test

def matchGroup = test =~ /(?ism)<description>([\s\S]*)<\/description>/

//
println matchGroup[0][1]

