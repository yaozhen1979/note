package org.db.transfer

import org.service.BaseService;
import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess

class InfoDataMoveProcess extends BaseService {
    
    def excute(def queryMap) {
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.80.31", MONGODB_PORT, 'admin')
        def db = dbClient.getDB("PatentInfoCNIPR")
        def srcCol = db.PatentInfoCNIPR
        
        def remoteDbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.90.121", MONGODB_PORT, 'admin')
        def remoteDB = remoteDbClient.getDB("PatentInfoCNIPR")
        def tarCol = remoteDB.PatentInfoCNIPR
        
        def queryCursor = srcCol.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it ->
            tarCol.save(it)
            restTimeProcess.process()
        }
        
        dbClient.close()
        remoteDbClient.close()
        
    }
    
    static main(args) {
        
        def queryMap = [doDate: DateUtil.parseDate("2016-03-23")]
        new InfoDataMoveProcess().excute(queryMap)
        
        println "finished..."
        
    }

}
