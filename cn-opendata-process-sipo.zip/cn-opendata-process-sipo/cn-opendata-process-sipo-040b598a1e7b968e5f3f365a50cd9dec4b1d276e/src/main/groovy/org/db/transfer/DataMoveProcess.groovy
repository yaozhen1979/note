package org.db.transfer

import org.service.BaseService;
import org.utils.DateUtil
import org.utils.FileUtil
import org.utils.RestTimeProcess
import org.utils.MailUtil
import org.utils.MongoUtil

/**
 * 把測試資料轉移至正式環境
 * 
 * @deprecated
 * @author tonykuo
 *
 */
class DataMoveProcess extends BaseService {
    
    def excute(def queryMap) {
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "127.0.0.1", MONGODB_PORT, 'admin')
        def db = dbClient.getDB("PatentInfoCNIPR")
        def srcCol = db.PatentInfoCNIPR
        
        def remoteDbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.90.121", MONGODB_PORT, 'admin')
        def remoteDB = remoteDbClient.getDB("PatentInfoCNIPR")
        def tarCol = remoteDB.PatentInfoCNIPR
        
        def queryCursor = srcCol.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it -> 
            tarCol.save(it)
            restTimeProcess.process()
        }
        
        dbClient.close()
        remoteDbClient.close()
        
    }
    
    static main(args) {
        
        def queryMap = [doDate: DateUtil.parseDate("2015-11-04")]
        new DataMoveProcess().excute(queryMap)
        
        println "finished..."
    }

}
