package org.db.transfer

import org.utils.MongoUtil
import org.utils.RestTimeProcess

/**
 * unset PatentRawCNIPR, unset PatentInfoCNIPR 中的 redmine 欄位...
 * 
 * TODO: refactor to dynamic DB or collection
 * 
 * @author tonykuo
 *
 */
class DataUnsetProcess {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.127", 27017, 'admin')
        def patentRawCNIPR = client.getDB("PatentRawCNIPR")
        def queryMap = [redmine: 99999]
        def queryCursor = patentRawCNIPR.PatentRawCNIPR.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.limit(1).each { it
            
            println "id = ${it._id}"
            
            patentRawCNIPR.PatentRawCNIPR.update([_id: it._id], [$unset: [redmine: 99999]])
            
            restTimeProcess.process()
            
        }
        
        println "finished..."
        
    }

}
