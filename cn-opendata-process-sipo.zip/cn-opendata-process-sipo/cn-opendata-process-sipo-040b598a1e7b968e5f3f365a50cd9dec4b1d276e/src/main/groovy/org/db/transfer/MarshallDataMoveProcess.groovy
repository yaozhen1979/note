package org.db.transfer

import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess

class MarshallDataMoveProcess {
    
    def excute(def queryMap) {
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "127.0.0.1", MONGODB_PORT, 'admin')
        def db = dbClient.getDB("PatentMarshallCN")
        def srcCol = db.PatentMarshallCN
        
        def remoteDbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.90.101", MONGODB_PORT, 'admin')
        def remoteDB = remoteDbClient.getDB("PatentMarshallCN")
        def tarCol = remoteDB.PatentMarshallCN
        
        def queryCursor = srcCol.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it ->
            tarCol.save(it)
            restTimeProcess.process()
        }
        
        dbClient.close()
        remoteDbClient.close()
        
    }
    
    static main(args) {
        
        def queryMap = [doDate: DateUtil.parseDate("2015-11-04")]
        new MarshallDataMoveProcess().excute(queryMap)
        
        queryMap = [doDate: DateUtil.parseDate("2015-11-11")]
        new MarshallDataMoveProcess().excute(queryMap)
        
        println "finished..."
        
    }
    
}
