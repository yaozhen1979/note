package org.unzip
// T:\cnlist\opendata\CN-TXTO-10-A 中国发明专利申请公布全文文本数据\20150916\20150916-001.zip
// T:\cnlist\opendata\FM\2015\

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.concurrent.TimeUnit;

/**
 * 可執行, 但速度太慢...
 * 
 * @author tonykuo
 *
 */
public class UnzipFileUtil {

    /**
     * 
     * @param destinationFolder
     * @param zipFile
     */
    private static void unzipFunction(String zipFile, String destinationFolder) {
        
        File directory = new File(destinationFolder);

        // if the output directory doesn't exist, create it
        if(!directory.exists()) {
            directory.mkdirs();
        }

        // buffer for read and write data to file
        byte[] buffer = new byte[2048];

        try {
            FileInputStream fInput = new FileInputStream(zipFile);
            ZipInputStream zipInput = new ZipInputStream(fInput);

            ZipEntry entry = zipInput.getNextEntry();

            while (entry != null) {
                
                String entryName = entry.getName();
                File file = new File(destinationFolder + File.separator + entryName);

                System.out.println("Unzip file " + entryName + " to " + file.getAbsolutePath());

                // create the directories of the zip directory
                if (entry.isDirectory()) {
                    File newDir = new File(file.getAbsolutePath());
                    if(!newDir.exists()) {
                        boolean success = newDir.mkdirs();
                        if(success == false) {
                            System.out.println("Problem creating Folder");
                        }
                    }
                } else {
                    FileOutputStream fOutput = new FileOutputStream(file);
                    int count = 0;
                    while ((count = zipInput.read(buffer)) > 0) {
                        // write 'count' bytes to the file output stream
                        fOutput.write(buffer, 0, count);
                    }
                    fOutput.close();
                }  // if (entry.isDirectory())
                
                // close ZipEntry and take the next one
                zipInput.closeEntry();
                entry = zipInput.getNextEntry();
                
            }  // end while

            // close the last ZipEntry
            zipInput.closeEntry();
            zipInput.close();
            fInput.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }  // end unzipFunction
    
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        
//        String zipFile = null;
//        String destinationFolder = null;
//
//        // take the arguments from the command line
//        zipFile = "T:/cnlist/opendata/CN-TXTO-10-A 中国发明专利申请公布全文文本数据/20150916/20150916-002.zip";
//        destinationFolder = "T:/cnlist/opendata/FM/2015";
//        unzipFunction(destinationFolder, zipFile);
        
        long startTime = System.nanoTime();
        
        String unzipFolder = "T:/cnlist/opendata";
        // String unzipFolder = "D:/share/opendata";
        
        // T:\cnlist\opendata\CN-TXTO-10-A 中国发明专利申请公布全文文本数据\20150930
        String folderPath = "T:/cnlist/opendata"
        
        def periodList = ["20151125"]
        
        def folderList = [
            "FM" : "CN-TXTO-10-A 中国发明专利申请公布全文文本数据",
            "SD" : "CN-TXTO-10-B 中国发明专利授权公告全文文本数据",
            "XX" : "CN-TXTO-20-U 中国实用新型专利授权公告全文文本数据"
            // "WG" : "CN-BIBO-30-S 中国外观设计专利授权公告著录项目数据" => 因語系問題, 先為手動調整.
        ]
        
        periodList.each { period ->
            
            def year = period.substring(0, 4)
            
            folderList.each { key, value ->
                
                if (key == "WG") {
                    
                } else {
                    
                    new File("${folderPath}/${value}/${period}").listFiles().each { file ->
                        
                        // println "file name = ${folderPath}/${value}/${period} = ${file.name}"
                        if (file.name.endsWith("zip") || file.name.endsWith("ZIP")) {
                            println "${key} => ${file.name} extracting..."
                            println "file path = ${file.getAbsolutePath()}"
                            
                            // zipFile = "T:/cnlist/opendata/CN-TXTO-10-A 中国发明专利申请公布全文文本数据/20150916/20150916-002.zip";
                            // destinationFolder = "T:/cnlist/opendata/FM/2015";
                            def unzipPath = unzipFolder + "/${key}/${year}"
                            
                            unzipFunction(file.getAbsolutePath(), unzipPath);
                        }
                        
                    }
                
                }
                
            }
            
        }
        
        // WG 只是單純的txt而已, 所以不需做unzip
        
        long stopTime = System.nanoTime();
        long duration = stopTime - startTime;
        
        System.out.println("total time = ${TimeUnit.SECONDS.convert(duration, TimeUnit.NANOSECONDS)} seconds");
        
        println "finished..."
        
    }

}
