/**
 * unzip 特定folder至指定資料夾
 */
package org.unzip;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.common.Constants;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.unzip.UnzipUtil;

/**
 * TODO: 2015-11-16 有問題...解壓縮後的數量和解壓縮前的數量不一致...
 * 
 * @author tonykuo
 * @deprecated
 * 
 */
public class FullTextFilesExtractor {

    private static final String FILE_SEPARATOR = System.getProperty("file.separator")
	
	private final int BUFF_SIZE = 4096;
	
	/**
	 * 
	 * @param zipFilePath T:/cn_img/20150819/TIFFWG_20150819_001.zip
	 * @param destinationFolderPath T:/cn_img/20150819
	 * @param type WG
	 */
	public FullTextFilesExtractor(String zipFilePath, String destinationFolderPath, String type, String year) {
		
		try {
            
			ZipFile zipFile = new ZipFile(zipFilePath);
			String destinationPath = destinationFolderPath + FILE_SEPARATOR+ type + FILE_SEPARATOR + year;
			
			if (!zipFile.isValidZipFile()) {  
                throw new ZipException("bad zip file...");  
            } else {
                System.out.println("good zip file");
            }
            
            // If zip file is password protected then set the password
            if (zipFile.isEncrypted()) {
                zipFile.setPassword("password");
            } else {
                System.out.println("no Encrypt...");
            }
			
            List fileHeaderList = zipFile.getFileHeaders();
			println "fileHeaderList.size() = ${fileHeaderList.size()}"
            
            def fileCount = 0;
            
            for (int i = 0; i < fileHeaderList.size(); i++) {
                
                fileCount++;
                
                FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
                //
                if (fileHeader != null) {
                    
                    // 
                    String fileName = fileHeader.getFileName();
                    println "fileName = ${fileName}"
                    
//                    if (fileName.endsWith("TIFF") || fileName.endsWith("TIF") || fileName.endsWith("tiff") || fileName.endsWith("tif") ||  
//                            fileName.endsWith("JPG") || fileName.endsWith("JPGE") || fileName.endsWith("jpeg") || fileName.endsWith("jpg") ||
//                            fileName.endsWith("XML") || fileName.endsWith("xml")) {
                    
                    println "fileHeader.isDirectory() = ${fileHeader.isDirectory()}"
                    
                    String outFilePath = destinationPath + FILE_SEPARATOR + fileName;
                    File outFile = new File(outFilePath);
                    
                    //Checks if the file is a directory
                    if (fileHeader.isDirectory()) {
                        //This functionality is up to your requirements
                        //For now I create the directory
                        outFile.mkdirs();
                        continue;
                    }
                    
                    //Check if the directories(including parent directories)
                    //in the output file path exists
                    File parentDir = outFile.getParentFile();
                    if (!parentDir.exists()) {
                        parentDir.mkdirs(); //If not create those directories
                    }
                    
                    unzeipFileByStream(zipFile, fileHeader, outFile);
                    
                    //To restore File attributes (ex: last modified file time, 
                    //read only flag, etc) of the extracted file, a utility class
                    //can be used as shown below
                    UnzipUtil.applyFileAttributes(fileHeader, outFile);
                    
                    // System.out.println("${type} = Done extracting: " + fileName);
                        
                } else {
                
                    println "FileHeader does not exist";
                    
                }  // end if (fileHeader != null)
                
            }  // end for each
            
            println "fileCount = ${fileCount}"
            
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        println "${zipFilePath} unzip complete..."
	}
	
	/**
	 * 
	 * @param zipFile
	 * @param fileHeader
	 * @param outFile
	 * @throws ZipException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
    private void unzeipFileByStream(ZipFile zipFile, FileHeader fileHeader,
            File outFile) throws ZipException, FileNotFoundException,
            IOException {
        //Get the InputStream from the ZipFile
        ZipInputStream is = zipFile.getInputStream(fileHeader);
        //Initialize the output stream
        OutputStream os = new FileOutputStream(outFile);
        
        int readLen = -1;
        byte[] buff = new byte[BUFF_SIZE];
        
        //Loop until End of File and write the contents to the output stream
        while ((readLen = is.read(buff)) != -1) {
            os.write(buff, 0, readLen);
        }
        
        //Closing inputstream also checks for CRC of the the just extracted file.
        //If CRC check has to be skipped (for ex: to cancel the unzip operation, etc)
        //use method is.close(boolean skipCRCCheck) and set the flag,
        //skipCRCCheck to false
        //NOTE: It is recommended to close outputStream first because Zip4j throws 
        //an exception if CRC check fails
        is.close();
        
        //Close output stream
        os.close();
    }
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	    
	    long startTime = System.nanoTime();
	    
	    String unzipFolder = "T:/cnlist/opendata";
	    // String unzipFolder = "D:/share/opendata";
	    
	    // T:\cnlist\opendata\CN-TXTO-10-A 中国发明专利申请公布全文文本数据\20150930
	    
        String folderPath = "T:/cnlist/opendata"
        
        def periodList = ["20150916"]
        
	    def folderList = [
	        "FM" : "CN-TXTO-10-A 中国发明专利申请公布全文文本数据",
            // "SD" : "CN-TXTO-10-B 中国发明专利授权公告全文文本数据",
            // "XX" : "CN-TXTO-20-U 中国实用新型专利授权公告全文文本数据",
            // "WG" : "CN-BIBO-30-S 中国外观设计专利授权公告著录项目数据" => 因語系問題, 先為手動調整.
	    ]
        
        periodList.each { period -> 
            
            def year = period.substring(0, 4)
            
            folderList.each { key, value ->
                
                if (key == "WG") {
                    
                    // Constants.WG_BIB_FILE_NAME
                    new File("${folderPath}/${value}/${period}").listFiles().each { file -> 
                        
                        if (file.name == Constants.WG_BIB_FILE_NAME) {
                            
                            def destFilePath = unzipFolder + FILE_SEPARATOR + key + FILE_SEPARATOR + year + FILE_SEPARATOR + period + FILE_SEPARATOR + Constants.WG_BIB_FILE_NAME
                            File destFile = new File(destFilePath)
                            org.apache.commons.io.FileUtils.copyFile(file, destFile)
                            println "copy file [${destFilePath}] compelete..."
                        }
                        
                    }
                    
                } else {
                    
                    new File("${folderPath}/${value}/${period}").listFiles().each { file ->
                        
                        // println "file name = ${folderPath}/${value}/${period} = ${file.name}"
                        // if (file.name.endsWith("zip") || file.name.endsWith("ZIP")) {
                        if (file.name == "20150916-001.ZIP") {
                            println "${key} => ${file.name} extracting..."
                            println "file path = ${file.getAbsolutePath()}"
                            new FullTextFilesExtractor(file.getAbsolutePath(), unzipFolder, key, year);
                        }
                        
                    }
                
                }
                
            }
            
        }
        
	    // WG 只是單純的txt而已, 所以不需做unzip
	    
		long stopTime = System.nanoTime();
		
		long duration = stopTime - startTime;
		
		System.out.println("total time = ${TimeUnit.SECONDS.convert(duration, TimeUnit.NANOSECONDS)} seconds");
	}

}
