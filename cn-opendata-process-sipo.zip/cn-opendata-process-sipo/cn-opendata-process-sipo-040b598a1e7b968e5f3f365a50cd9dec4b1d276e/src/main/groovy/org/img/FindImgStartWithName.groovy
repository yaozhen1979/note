package org.img

import org.service.BaseService;
import org.utils.RestTimeProcess
import org.utils.DateUtil

/**
 * 工具程式
 * 
 * @author tonykuo
 *
 */
class FindImgStartWithNameStatic extends BaseService {
    
    def void process(def args, def period) {
        
        String argDoPath = args.argDoPath
        String patentType = args.patentType
        Date doDate = DateUtil.parseDate(period);
        log.info "args = ${args}"
        log.info "doDate = ${doDate}"
        
        // D:\cn_opendata\data\FM\2015\20150923
        // File dir = new File(RAW_DATA_FOLDER_PATH + argDoPath)
        File dir = new File("D:\\cn_opendata\\data\\" + argDoPath)
        println "path = ${RAW_DATA_FOLDER_PATH + argDoPath}"
        
        if (!dir.exists()) {
            throw new Exception("No Raw Data Folder Exist")
        }
        
        File fileLog = new File("logs/FindImgStartWithName.log")
        
        def fileCount = dir.listFiles().size()
        println "fileCount = ${fileCount}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)
        
        dir.listFiles().eachWithIndex { File folder, index ->
            
            def appNumber = folder.name
            println "folder appNumber = ${appNumber}"
            def clipCount = 0
            
            folder.listFiles().each { File it ->
                
                def imageName = it.name
                
                if (!imageName.toUpperCase().contains("XML") && (imageName != "Thumbs.db")) {
                    
                    if (appNumber.contains(imageName.replace(".TIF", ""))) {
                        // do nothing => 201180074796.TIF
                    } else if (imageName.contains("BDA") || imageName.contains("DDA") ||
                            imageName.contains("FDA") || imageName.contains("DEST_PATH") ||
                            imageName.contains("IDA") || imageName.contains("GDA") || 
                            imageName.contains("BPA") || imageName.contains("ISB") || 
                            imageName.contains("BSA") || imageName.contains("FSA") ||
                            imageName.contains("DSA") || imageName.contains("FDF") ||
                            imageName.contains("ISA") || imageName.contains("FPA") ||
                            imageName.contains("DPA") || imageName.contains("FSB") ||
                            imageName.contains("GYZ") || imageName.startsWith("S058")) {
                        // do nothing
                    } else if (imageName.contains("HPA") || imageName.contains("HDA") || 
                            imageName.contains("HSA") || imageName.contains("HSB") || 
                            (imageName ==~ /^\d[\S]*.TIF/) || imageName.startsWith("S0417") || 
                            imageName.startsWith("YZ") || imageName.startsWith("H") || 
                            imageName.startsWith("S2005")) {
                            // appNumber = 201410150626.0, file name = 3.TIF
                    } else {
                        println "file name = ${it.name}"
                        fileLog << "${patentType}, doDate = ${argDoPath}, appNumber = ${appNumber}, file name = ${it.name}" << System.getProperty('line.separator')
                    }
                    
                }
                
            }
            
            restTimeProcess.process()
        }
        
    }
    
    static main(args) {
        
        //
        def year = "2015"
        def period = "20150923"
        
        ["FM", "SD", "XX"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['argDoPath' : "${patentType}/${year}/${period}"]
            argMap << ['patentType' : patentType]
            
            new FindImgStartWithNameStatic().process(argMap, period);
            
        }
        
        println "finished..."
        
    }
    
}
