package org.img

import org.exception.CnException
import org.service.BaseService;
import org.utils.DateUtil
import org.utils.FileUtil
import org.utils.RestTimeProcess
import org.utils.MailUtil
import org.utils.MongoUtil

/**
 * @dreprecated <br/>
 * 本想已圖片檔名來找出存放在clip, figure, first img的規則出來, <br/>
 * 但因檔名種類太多, 因而放棄... <br/>
 * 
 * 現改為使用ImageCopyProcess2.groovy
 * 
 * @author tonykuo
 *
 */
class ImageCopyProcess extends BaseService {
    
    private final static String IMAGE_FORMAT = ".TIF"
    private final static String FIRST_IMAGE_NAME = "firstImage" + IMAGE_FORMAT
    private final static String CLIP_IMAGE_FOLER = "clip"
    private final static String EMBED_IMAGE_FOLDER = "figure"
    
    def void process(def args, def period) {
        
        String argDoPath = args.argDoPath
        String patentType = args.patentType
        Date doDate = DateUtil.parseDate(period);
        log.info "args = ${args}"
        log.info "doDate = ${doDate}"
        
//        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
//        def db = dbClient.getDB("PatentRawCN")
//        def patentImageCN = db.getCollection("PatentImageCN")
        
        File dir = new File(RAW_DATA_FOLDER_PATH + argDoPath)
        println "path = ${RAW_DATA_FOLDER_PATH + argDoPath}"
        
        File fileLog = new File("logs/ImageCopyProcess.log")
        
        if (!dir.exists()) {
            throw new Exception("No Raw Data Folder Exist")
        }
        
        // IMAGE_DATA_FOLDER_PATH
        File destDir = new File(IMAGE_DATA_FOLDER_PATH + "/"+ argDoPath)
        if (!destDir.exists()) {
            FileUtil.mkdir(destDir)
        }
        
        def fileCount = dir.listFiles().size()
        println "fileCount = ${fileCount}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)
        
        dir.listFiles().eachWithIndex { File folder, index -> 
            
            def appNumber = folder.name
            // println "appNumber = ${appNumber}"
            
            def clipCount = 0
            
            folder.listFiles().each { File it ->
                
                if (!it.name.toUpperCase().contains("XML") && (it.name != "Thumbs.db")) {
                    
                    def firstImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/" + FIRST_IMAGE_NAME
                    def clipImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/clip"
                    def embedImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/figure"
                    
                    // check image format
                    if (!it.name.endsWith("TIF")) {
                        throw new CnException("CN OPEN DATA image format error => ${appNumber}, ${it.name}")
                    }
                    
                    def imageName = it.name.replace(IMAGE_FORMAT, "")
                    
                    if (appNumber.contains(imageName.replace(".TIF", ""))) {
                        FileUtil.copyFileUsingStream(it, new File(firstImagePath))
                        // TODO: record appNumber do not have first image
                    } else if (imageName.contains("BDA") || imageName.contains("DDA") ||
                            imageName.contains("FDA") || imageName.contains("DEST_PATH") ||
                            imageName.contains("IDA") || imageName.contains("GDA") || 
                            imageName.contains("BPA") || imageName.contains("ISB") || 
                            imageName.contains("BSA") || imageName.contains("FSA") ||
                            imageName.contains("DSA") || imageName.contains("FDF") ||
                            imageName.contains("ISA") || imageName.contains("FPA") ||
                            imageName.contains("DPA") || imageName.contains("FSB") ||
                            imageName.contains("GYZ") || imageName.startsWith("S058")) {
                            //
                            FileUtil.copyFileUsingStream(it, new File(embedImagePath + "/" + it.name))
                   } else if (imageName.contains("HPA") || imageName.contains("HDA") || 
                            imageName.contains("HSA") || imageName.contains("HSB") || 
                            (imageName ==~ /^\d[\S]*.TIF/) || imageName.startsWith("S0417") || 
                            imageName.startsWith("YZ") || imageName.startsWith("H") || 
                            imageName.startsWith("S2005")) {
                            // HPA / HDA 為 clip image
                            def clipImageName = (++clipCount) + IMAGE_FORMAT;
                            // println "clipImageName = ${clipImageName}"
                            FileUtil.copyFileUsingStream(it, new File(clipImagePath + "/" + clipImageName))
                    } else {
                        println "file name = ${it.name}"
                        fileLog << "${patentType}, doDate = ${argDoPath}, appNumber = ${appNumber}, file name = ${it.name}" << System.getProperty('line.separator')
                    }
                    
                }  // end if (!it.name.toUpperCase().contains("XML"))
                
            }  // end folder.listFiles()
            
            restTimeProcess.process()
            
        }
        
    }
    
    static main(args) {
        
        //
        def year = "2015"
        def period = "20151104"
        
        /*
         * WG: 特有期數 => (YYYY - 1985 + 1) + 當年週數 => EX: (2015 - 1985 + 1) + 第38週 = 3138
         * CNIPR 才會有期數,
         * CN Open Data 則無...
         */
        // def wgPeriod = "3138"
        
        // "FM", "SD", "XX"
        ["FM", "SD", "XX"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['argDoPath' : "${patentType}/${year}/${period}"]
            argMap << ['patentType' : patentType]
            
            new ImageCopyProcess().process(argMap, period);
            
        }
        
        println "finished..."
        
    }

}
