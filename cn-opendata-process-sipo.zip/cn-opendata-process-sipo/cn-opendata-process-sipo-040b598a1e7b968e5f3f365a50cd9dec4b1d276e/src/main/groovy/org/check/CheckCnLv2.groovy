package org.check

import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.RestTimeProcess

/**
 * 檢查CN LV2和CN appNumber的差異 => find Lv2 Gap app number 
 * 以appNumber list來檢核PatentInfoCNIPR
 * 
 */
class CheckCnLv2 {
    
    static void process(def db, String patentType, String doDate) {
        
        def ln = System.getProperty('line.separator')
        
        // T:\cnlist\appNumber\20150527
        def srcFilePath = "T:\\cnlist\\appNumber\\${doDate}\\sipo-${patentType}-${doDate.substring(0,4)}.${doDate.substring(4,6)}.${doDate.substring(6,8)}.txt"
        
        def diffList = [];
        def difflog = "logs/log_lv2_gap/find-LV2-gap-${patentType}-${doDate}-log.txt"
        
        File diffFile = new File(difflog)
        
        println "start ${patentType}-${doDate} parsing..."
        
        def totalLine = 0
        new File(srcFilePath).eachLine { line -> 
            totalLine++;
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(totalLine, this.class.name)
        
        new File(srcFilePath).eachLine { line ->
            
            if (!!line) {
                
                def appNo = line.substring(12)
                // println "appNo = " + line.substring(12);
                
                def queryCursor = db.PatentInfoCNIPR.find([appNumber: line.substring(12), doDate: DateUtil.parseDate(doDate)])
                queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
                
                if (queryCursor.count() == 0) {
                    println "${appNo} data no exists"
                    diffList << appNo
                }
                
            }
            
            restTimeProcess.process()
        }
        
        println "${patentType}-${doDate}, diff count = " + diffList.size()
        
        if (diffList.size() > 0) {
            //
            diffList.each{ it ->
                // println it
                // format = XX\20150701\201520085573.9
                diffFile << "${patentType}\\${doDate}\\${it}" << ln
            }
        }
        
    }
    
    static main(args) {
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
        def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")
        
        def doDateList = [
//            "20150107",
//            "20150114",
//            "20150121",
//            "20150128",
//            "20150204",
//            "20150211",
//            "20150218",
//            "20150225",
//            "20150304",
//            "20150311",
//            "20150318",
//            "20150325",
//            "20150401",
//            "20150408",
//            "20150415",
//            "20150422",
//            "20150429",
//            "20150506",
//            "20150513",
//            "20150520",
//            "20150527",
//            "20150603",
//            "20150610",
//            "20150617",
//            "20150624",
//            "20150701",
            "20150708",
//            "20150715",
//            "20150722",
//            "20150729",
//            "20150805",
//            "20150812",
//            "20150819",
//            "20150826",
//            "20150902",
//            "20150909",
//            "20150916",
//            "20150923",
//            "20150930",
//            "20151007",
//            "20151014",
//            "20151021",
//            "20151028",
            "20151104",
//            "20151111"
//            "20151118",
//            "20151125",
//            "20151202"
        ]
        
        doDateList.each { doDate -> 
            
            println "process doDate = ${doDate}"
            
            ["FM", "SD", "XX", "WG"].each { patentType ->
                
                CheckCnLv2.process(patentInfoCNIPR, patentType, doDate)
                
            }
              
        }
        
        println "finished"
        
    }

}

