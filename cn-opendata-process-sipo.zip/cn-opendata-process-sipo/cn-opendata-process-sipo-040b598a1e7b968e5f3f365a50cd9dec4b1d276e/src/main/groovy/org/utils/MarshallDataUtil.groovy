package org.utils

import org.common.Constants
import org.utils.XmlUtil

class MarshallDataUtil {
    
    /**
     * 
     * @param expansionDataMap
     * @param doDate
     * @param patentType
     * @param existData = null
     * @return
     */
    static generateMarshallData(def expansionDataMap, def rawData, def existData = null) {
        
        def marshallData = [:]
        
        //marshallData << ["_id" : rawData._id]
        marshallData << ["_id" : XmlUtil.getMarshallDB_Id(expansionDataMap)]
        marshallData << ["appNumber" : XmlUtil.getAppNumber(expansionDataMap)]
        marshallData << ["doDate" : rawData.doDate]
        marshallData << ["pto" : Constants.PTO]
        marshallData << ["patentType" : rawData.patentType]
        
        // TODO: fileType 1為create, 2為amend => 目前CN沒有amend的資料
        rawData << ["fileType" : 1]
        
        def patentNumber = XmlUtil.getPatentNumber(expansionDataMap);
        marshallData << ["patentNumber" : patentNumber]
        
        if (!!existData) {
            // 如現在資料已有bibo, claim, description, 則保存.
            def dataMap = existData.data
            dataMap.expansion = expansionDataMap
            marshallData << ["data": dataMap]
        } else {
            def dataMap = [:] << ["expansion" : expansionDataMap]
            marshallData << ["data" : dataMap]
        }
        
        marshallData << MiscUtil.getRelRawdatas(rawData, existData)
        marshallData << MiscUtil.getTagAndFile(existData, "marshallLevel")
        marshallData << MiscUtil.getMongoSyncFlag(existData)

        return marshallData
        
    }  // end generateRawData function
    
}
