package org.utils.infodata

import org.utils.DateUtil
import org.utils.StringUtil
import org.utils.MiscUtil
import org.exception.CnException

class WGInfoDataUtil extends BaseInfoData {
    
    private final static def LOC_VALID_REGEX_PATTERN = /^\d{1,2}[\s\-]*(\d{1,4})(\s)*(\(\d{1,3}\))?/
    private final static def LOC_FIND_REGEX_PATTERN = /^\d{1,2}[\s\-]*(\d{1,4})(\s)*/
    
    /**
     * For WG
     *
     * @param marshallData
     * @param existInfoData
     * @return
     */
    static generateWGInfoData(def marshallData, def existInfoData) {
        
        def infoData = [:]
        def wgData = marshallData.data.expansion
        
        infoData << ["appNumber" : wgData.appNumber.replace("CN", "")]
        infoData << ["appNumberNormal" : wgData.appNumber.replace(".", "")]
        infoData << ["appDate" : DateUtil.parseDate(wgData.applicationDate)]
        
        // NOTE: WG 尚未有二個以上的代理機構資料出現
        if (!!wgData.agency) {
            infoData << ["agents" : [] << ["name" : ["origin" : wgData.agency]]]
        }
        if (!!wgData.agents) {
            infoData << ["agentOperators" : getAgentOperators(wgData)]
        }
        if (!!wgData.assignees) {
            infoData << ["assignees" : getAssignees(wgData)]
        }
        if (!!wgData.inventors) {
            infoData << ["inventors" : getInventors(wgData)]
        }
        
        infoData << ["patentNumber" : wgData.appNumber.replace("CN", "")]
        infoData << ["decisionNumber" : wgData.patentNumber]
        infoData << ["decisionNumberNormal" : wgData.patentNumber]
        infoData << ["decisionDate" : DateUtil.parseDate(wgData.publicationDate)]
        infoData << ["doDate" : DateUtil.parseDate(wgData.publicationDate)]
        infoData << ["title" : ["origin" : wgData.title]]
        infoData << ["brief" : ["origin" : wgData.brief]]
        infoData << ["mainLOC" : getMainLOC(wgData)]
        infoData << ["locs" : getLocs(wgData)]
        if (!!wgData.filePageNumber) {
            infoData << ["filePageNumber" : wgData.filePageNumber]
        }
        
        // NOTE: hard code "S", 但如果要刷早期的外觀設計資料的話, 要如何判斷 ???
        infoData << ["kindcode" : "S"]
        infoData << ["stat" : 2]
        
        infoData << generateBasicData(marshallData, existInfoData)
        
        return infoData
    }
    
    private static getAssignees(def wgData) {
        
        def assignees = []
        def address = wgData.address
        def assigneeList = wgData.assignees
        
        assigneeList.each { assignee -> 
            
            assignees << [
                "name" : ["origin" : assignee],
                "address" : ["origin" : address]
            ]
            
        }
        
        return assignees
    }
    
    /**
     * NOTE: 目前前台所使用的欄位, 但實際為顯示代理機構, 而非代理人.
     * 
     * @param wgData
     * @return
     */
    private static getAgents(def wgData) {
        
        def agents = []
        def agency = wgData.agency
        def agentList = wgData.agents
        
        agentList.each { agent -> 
            agents << [
                "name" : ["origin" : agency]
            ]
        }
        
        return agents
    }
    
    private static getAgentOperators(def wgData) {
        
        def agentOperators = []
        def agency = wgData.agency
        def agentList = wgData.agents
        
        agentList.each { agent ->
            agentOperators << [
                "name" : ["origin" : agent],
                "agency" : ["origin" : agency]
            ]
        }
        
        return agentOperators
    }
    
    private static getInventors(def wgData) {
        
        def inventors = []
        def inventorList = wgData.inventors
        
        inventorList.each { inventor -> 
            inventors << ["name" : ["origin" : inventor]]
        }
        
        return inventors
    }
    
    private static getMainLOC(def wgData) {
        
        def mainLOC = wgData.mainLOC
        
        if (!(mainLOC ==~ LOC_VALID_REGEX_PATTERN)) {
            throw new CnException("loc regex pattern error, wgData = ${wgData}")
        }
        
        mainLOC.find(LOC_FIND_REGEX_PATTERN) { it -> 
            return it[0].trim()
        }
           
    }
    
    private static getLocs(def wgData) {
        
        def locList = wgData.locs
        def locs = []
        
        locList.each { loc -> 
            
            if (!(loc ==~ LOC_VALID_REGEX_PATTERN)) {
                throw new CnException("loc regex pattern error, wgData = ${wgData}")
            }
            
            loc.find(LOC_FIND_REGEX_PATTERN) { it ->
                locs << it[0].trim()
            }
        }
        
        return locs
    }
    
}
