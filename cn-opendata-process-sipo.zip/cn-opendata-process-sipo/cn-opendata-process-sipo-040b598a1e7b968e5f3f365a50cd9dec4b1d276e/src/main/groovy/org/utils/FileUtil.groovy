package org.utils

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class FileUtil {
    
    private static Logger logger = LoggerFactory.getLogger(FileUtil.class);
    
    private static Class<?> searchBase = FileUtil.class;
    
    private static ArrayList<String> searchPath = new ArrayList<String>() {
        {
            add("");
            add("../");
            add("/");
            add("/../");
            add("../../");
            add("/../../");
            add("/../../../");
        }
    };
    
    /**
     *
     * @param fileName
     * @return
     */
    public static File searchPropFromFile(String fileName) {
        
        String base = searchBase.getProtectionDomain().getCodeSource().getLocation().getPath();
        
        File fileBase = new File(base);
        if (!fileBase.isDirectory()) {
            base = fileBase.getParent();
        }
        logger.debug("Search base: " + base + ", for: " + fileName);
        File file = new File(fileName);

        if (file.exists() && file.canRead()) {
            return file;
        }

        for (String inc : searchPath) {
            if (!inc.startsWith("/")) {
                file = new File(inc + fileName);
                if (file.exists() && file.canRead()) {
                    return file;
                }
            }

            file = new File(base + inc + fileName);
            if (file.exists() && file.canRead()) {
                return file;
            }
        }

        return null;
    }
    
    /**
     *
     * @param fileName
     * @return
     */
    public static InputStream searchPropFromResource(String fileName) {
        
        InputStream is = null;

        for (String inc : searchPath) {
            is = searchBase.getResourceAsStream(inc + fileName);
            if (is != null) {
                logger.debug("Load properties from search path resource: " + inc + fileName);
                return is;
            }
        }

        is = Thread.currentThread().getClass().getResourceAsStream(fileName);
        if (is != null) {
            logger.debug("Load properties from current thread resource: " + fileName);
            return is;
        }

        return is;
    }
    
    /**
     * 
     * @param file
     */
    static void mkdir(File dir) {
        
        if (!dir.exists()) {
            File parentFile = dir.getParentFile()
            mkdir(parentFile)
        }
        
        dir.mkdirs()
    }
    
    /**
     * 
     * @param source
     * @param dest
     * @throws IOException
     */
    static void copyFileUsingStream(File source, File dest) throws IOException {
        
        InputStream is = null;
        OutputStream os = null;
        
        if (!dest.getParentFile().exists()) {
            FileUtil.mkdir(dest.getParentFile())
        }
        
        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
        
    }  // end copyFileUsingStream
    
}
