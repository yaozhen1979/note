package org.utils

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class RestTimeProcess {
	
    Logger log = LoggerFactory.getLogger(RestTimeProcess.class);
    
    def ln = System.getProperty('line.separator')
	def totalCnt
	def currCnt
	def lastCnt
	def msg
	Date now
	Date lastTime
    // File log
	def interval = 10000
	
	RestTimeProcess(totalCnt, msg){
		this.totalCnt = totalCnt
		this.currCnt = 0
		this.lastCnt = 0
		this.lastTime = new Date()
		this.msg = msg
	}
    
    RestTimeProcess(totalCnt){
        this.totalCnt = totalCnt
        this.currCnt = 0
        this.lastCnt = 0
        this.lastTime = new Date()
        this.msg = msg
    }
	
	def process() {
		
		currCnt++
		
		now = new Date()
        
        String dateStr = now.format("yyyy-MM-dd HH:mm:ss")
		
		if (currCnt == 1) {
			lastCnt = currCnt
			log.info "${dateStr} : ${msg} : start process total counts : ${totalCnt}"
		}
		
		if ((now.compareTo(lastTime) > 0 && 
                (now.getTime()- lastTime.getTime()) > interval && currCnt > lastCnt) || 
                (currCnt == totalCnt)) {
			
			//進度百分比
			def percent = Math.round(currCnt / totalCnt * 100 * 100) / 100
			//剩餘數量
			def restNum = totalCnt - currCnt
			//單位時間(interval)內進行的數量
			def procNum = currCnt - lastCnt
			//已使用時間
			def usedTime = now.getTime()- lastTime.getTime()
			//剩餘時間
            def restTime = (procNum == 0 ? 0 : (restNum / procNum) * usedTime)
            
			def ms = restTime / 1000
			
			//取秒數
			def secs = ms.toInteger().mod(60)
			
			ms = ms / 60
			
			//取分鐘數
			def mins = ms.toInteger().mod(60)
			
			ms = ms / 60
			
			//取時數
			def hours = ms.toInteger().mod(60)
			
			if (msg?.trim()) {
				log.info "${dateStr} : ${msg} process ${currCnt} / ${totalCnt} (${percent}%), Rest time:" + sprintf('%02d:%02d:%02d', [hours, mins, secs])
			} else {
				log.info "${dateStr} : process ${currCnt} / ${totalCnt} (${percent}%), Rest time:" + sprintf('%02d:%02d:%02d', [hours, mins, secs])
			}
			
			lastTime = now
			lastCnt = currCnt
		}

	}
	
}


