package org.utils

import static java.nio.file.Files.readAllBytes;
import static java.nio.file.Paths.get;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.jaxb.CnPatentDocument;
import org.common.Constants;
import org.apache.commons.io.input.BOMInputStream
import org.apache.commons.io.ByteOrderMark
import org.apache.commons.io.FileUtils
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.StringUtils

import groovy.json.JsonSlurper

import org.utils.CaptchaUtil

/**
 * TODO: 
 * 
 * 1. 有必要用那麼多的static ???
 * 
 * @author tonykuo
 *
 */
class XmlUtil {
    
    private final static String DTD_REMOVE_PATTERN = "<!DOCTYPE[\\S\\s]*?>(\r\n|\n)"
    
    private static boolean inited;
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    
    /**
     * verify xml data
     *
     * @throws Exception
     */
    private static void jaxbInit() throws Exception {
        
        if (inited) {
            return;
        }
        
        JAXBContext jc = JAXBContext.newInstance("org.jaxb");
        unmarshaller = jc.createUnmarshaller();

        Map<String, Object> props = new HashMap<>();
        
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        JAXBContext jc1 = JAXBContext.newInstance("org.jaxb",
                CnPatentDocument.class.getClassLoader(), props);
        
        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        inited = true;
        
    }
    
    static String getXmlText(String filePath) {
        return getXmlText(new File(filePath))
    }
    
    static String getXmlText(File xmlFile) {
        return xmlFile.getText(Constants.LANG_ENCODING)
    }
    
    /**
     * 
     * @param filePath
     * @return
     */
    static String xml2jsonStr(String xmlStr) {
        jaxbInit();
        def fileText = XmlUtil.reomoveDTDDeclaration(xmlStr)
        // println fileText
        InputStream xmlStream = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        
        Object elem = unmarshaller.unmarshal(xmlStream);
        StringWriter sw = new StringWriter();
        marshaller.marshal(elem, sw);
        
        return sw.toString()
    }
    
    /**
     * 
     * @param file
     * @return
     */
    static String xml2jsonStr(File file) {
        
        jaxbInit();
        
        def fileText = XmlUtil.reomoveDTDDeclaration(file.getText(Constants.LANG_ENCODING))
        // println fileText
        InputStream xmlStream = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        
        Object elem = unmarshaller.unmarshal(xmlStream);
        StringWriter sw = new StringWriter();
        marshaller.marshal(elem, sw);
        
        return sw.toString()
    }
    
    /**
     * 
     * @param xmlStr
     * @return
     */
    static def xml2Object(String xmlStr) {
        def fileText = XmlUtil.reomoveDTDDeclaration(xmlStr)
        // NOTE: 判斷是否為BOM File, 且此判斷是否要移到RawData中實做 ???
        InputStream is = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        BOMInputStream bomIn = new BOMInputStream(is, false, ByteOrderMark.UTF_8);
        if (bomIn.hasBOM()) {
            fileText = IOUtils.toString(bomIn, Constants.LANG_ENCODING);
        }
        is.close()
        return new XmlParser().parseText(fileText)
    }
    
    /**
     * 
     * @param xmlStr
     * @return
     */
    static def parseDescription(String xmlStr) {
        
        def root = XmlUtil.xml2Object(xmlStr)
        def description = groovy.xml.XmlUtil.serialize(root.'application-body'.'description'[0])
        def trimStr = trimStr(description)
        def matchGroup = trimStr =~ /(?ism)<description>([\s\S]*)<\/description>/
        
        return matchGroup[0][1]
    }
    
    /**
     * 
     * @param xmlStr
     * @return
     */
    static def parseClaim(String xmlStr, int index) {
        
        def root = XmlUtil.xml2Object(xmlStr)
        def claim = groovy.xml.XmlUtil.serialize(root.'application-body'.'claims'[index])
        def trimStr = trimStr(claim)
        def matchGroup = trimStr =~ /(?ism)<claims>([\s\S]*)<\/claims>/
        
        return matchGroup[0][1]
    }
    
    /**
     * 
     * @param xmlStr
     * @return
     */
    static def parseTitle(String xmlStr) {
        
        def root = XmlUtil.xml2Object(xmlStr)
        def title = groovy.xml.XmlUtil.serialize(root.'cn-bibliographic-data'.'invention-title'[0])
        def trimStr = trimStr(title)
        def matchGroup = trimStr =~ /(?ism)<invention-title>([\s\S]*)<\/invention-title>/
        
        return matchGroup[0][1]
    }
    
    /**
     * 應有額外加入 <p> tag 所以需要再確認前台是否有顯示的問題 ??? => 前台可正常顯示
     * 
     * @param xmlStr
     * @return
     */
    static def parseAbstract(String xmlStr) {
        
        def root = XmlUtil.xml2Object(xmlStr)
        def abstractStr = groovy.xml.XmlUtil.serialize(root.'cn-bibliographic-data'.'abstract'[0])
        def trimStr = trimStr(abstractStr)
        def matchGroup = trimStr =~ /(?ism)<abstract>([\s\S]*)<\/abstract>/
        
        return matchGroup[0][1]
    }
    
    /**
     * TODO: 有必要再加入doDate來讓patentNumber當做惟一值 ??? => 依據sally rule ???
     * 
     * patentNumber = 國別 + 公佈號 + kindcode(沒kindcode, 則以專利類型來判斷(A, B, U, S))
     * 
     * @param jsonObj
     * @return
     */
    static def getPatentNumber(def jsonObj) {
        
        def country = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."country"
        // def doDate = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."date"
        def docNumber = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."doc-number"
        def kindcode = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."kind"
        
        return country + docNumber + kindcode
    }
    
    /**
     * 依所傳入的每行字串, 執行trim().
     */
    private def static trimStr = { String text ->
        
        def trimStr = ""
        
        text.eachLine { line ->
            def lineStr = line.toString()
            trimStr += lineStr.trim()
        }
        
        return trimStr
    }
    
    /**
     * 
     * @param jsonStr
     * @return
     */
    static def toJsonObject(String jsonStr) {
        return new JsonSlurper().parseText(jsonStr)
    }
    
    /**
     * 強制消除<!DOCTYPE cn-patent-document SYSTEM "\dtd\cn-patent-document-06-10-27.dtd" []>這一行
     * 
     * @param xml
     * @return
     */
    static String reomoveDTDDeclaration(String xml) {
        return xml.replaceAll(DTD_REMOVE_PATTERN, "")
    }
    
    /**
     * 特別處理[invention-title], [abstract], [description], [claims]這4個欄位.
     * 
     * 上述4個資料, 並不特別parse其data為json format, 而只取出其中的text而已.
     * 
     * @param xml
     * @return
     */
    //static def generateCnOpenDataJsonObject(String xml, String patentType) {
    static def generateCnOpenDataJsonObject(def rawData) {
        String xml = rawData.data.text;
        String patentType = rawData.patentType;
        // cdata process
        CDataProcess process = new CDataProcess(false,
            "/cn-patent-document/cn-bibliographic-data/abstract",
            "/cn-patent-document/application-body/description",
            "/cn-patent-document/application-body/claims");
        
        // SIPO 資料會有 <!-- SIPO <DP n="1"> -->, 造成CDataProcess無法解析, 故先replace成空字串.
        String newXmlStr = process.transfer(xml.replaceAll(/<!--\s+SIPO\s*<DP\s+n="\d+">\s*-->/, ""));
        // String newXmlStr = xml.replaceAll(/<!--\s+SIPO\s*<DP\s+n="\d+">\s*-->/, "");
        println "newXmlStr = ${newXmlStr}"
        
        def jsonStr = XmlUtil.xml2jsonStr(newXmlStr)
        def jsonObj = XmlUtil.toJsonObject(jsonStr)
        
        String regex = "<invention-title\\s*/>";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(xml);
        if (m.find()) {
            def _id = rawData._id;
            FileUtils.write(new File("." + File.separator + "no_title.txt"), _id + "\r\n" , true);
            return null;
        } else {
            jsonObj."cn-patent-document"."cn-bibliographic-data"."invention-title" = XmlUtil.parseTitle(newXmlStr)
            if (jsonObj."cn-patent-document"."cn-bibliographic-data"."abstract" != null) {
                jsonObj."cn-patent-document"."cn-bibliographic-data"."abstract" = XmlUtil.parseAbstract(newXmlStr)
            } else {
                def patentNumber = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."doc-number"
                def kindcode = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."kind"
                FileUtils.write(new File("." + File.separator + "No_Abstract.txt"), patentNumber + kindcode +"\r\n", true);
            }
            //
            if (patentType != "WG") {
                if(jsonObj."cn-patent-document"."application-body" != null){
                    jsonObj."cn-patent-document"."application-body"."description" = XmlUtil.parseDescription(newXmlStr)
                    
                    // CN OPEN DATA claims marshall data type 為 array, SIPO claims 則為 Object.
                    if (jsonObj."cn-patent-document"."application-body"."claims".size() > 0) {
                        jsonObj."cn-patent-document"."application-body"."claims".eachWithIndex { claim, index ->
                            // println index
                            jsonObj."cn-patent-document"."application-body"."claims" = XmlUtil.parseClaim(newXmlStr, index)
                        }
                    } else {
                        jsonObj."cn-patent-document"."application-body"."claims" = XmlUtil.parseClaim(newXmlStr, -1)
                    }
                } else {
                    def patentNumber = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."doc-number"
                    def kindcode = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."kind"
                    FileUtils.write(new File("." + File.separator + "No_DescOrClaim.txt"), patentNumber + kindcode +"\r\n", true);
                }
            }
        }
        
        return jsonObj
    }
    
    /**
     * 
     * @param inputStream
     * @return
     * @throws IOException
     */
    static InputStream checkForUtf8BOM(InputStream inputStream) throws IOException {
        PushbackInputStream pushbackInputStream = new PushbackInputStream(new BufferedInputStream(inputStream), 3);
        byte[] bom = new byte[3];
        if (pushbackInputStream.read(bom) != -1) {
            if (!(bom[0] == (byte) 0xEF && bom[1] == (byte) 0xBB && bom[2] == (byte) 0xBF)) {
                pushbackInputStream.unread(bom);
            }
        }
        return pushbackInputStream;
    }
    
    /**
     * 
     * @param arg
     * @return
     */
    static String toHex(String arg) {
        return String.format("%040x", new BigInteger(1, arg.getBytes("UTF-8")));
    }
    
    /**
     * @author yyj
     * 
     * TODO: 是否還要在加入appNumber申請號長度為8碼或是12碼的資料 by Tony
     * 
     * @param jsonObj
     * @return
     */
    static def getMarshallDB_Id(def jsonObj) {
        
        def marShallDB_id = null;
        def appNo = jsonObj."cn-patent-document"."cn-bibliographic-data"."application-reference"."document-id"."doc-number";
        def kindcode = jsonObj."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"."kind";
        
        if (appNo.contains(".")) {
            def appNumber = appNo.substring(0, appNo.indexOf("."));
            def captcha = appNo.substring(appNo.indexOf(".") + 1);
            marShallDB_id = StringUtils.leftPad(appNumber, 12, "0") + captcha + kindcode.toUpperCase();
        } else {
            //throw new Exception("jsonObj = ${jsonObj}, appNumber doesnt contain [.]")
            String appNumberCaptcha = CaptchaUtil.genAppNumberWithCaptcha(appNo.replaceAll("\n", ""), true);
            def appNumber = appNumberCaptcha.substring(0, appNumberCaptcha.indexOf("."));
            def captcha = appNumberCaptcha.substring(appNumberCaptcha.indexOf(".") + 1);
            marShallDB_id = StringUtils.leftPad(appNumber, 12, "0") + captcha + kindcode.toUpperCase();
        }
        
        return marShallDB_id;
        
    }   // end getMarshallDBId
    
    /**
     * 
     * @param jsonObj
     * @return
     */
    static def getAppNumber(def jsonObj){
        def appNumber = null;
        appNumber = jsonObj."cn-patent-document"."cn-bibliographic-data"."application-reference"."document-id"."doc-number"
        return appNumber;
    }
    
    /**
     * 
     * @param args
     */
    static main(args) {
        
        // println XmlUtil.trimStr("  test ")
        
        def xmlStr = XmlUtil.getXmlText("opendata-sample/FM/20151104/201180074796NEW.XML")
        // println toHex(xmlStr)
        
        InputStream is = new ByteArrayInputStream(xmlStr.getBytes(Constants.LANG_ENCODING));
        BOMInputStream bomIn = new BOMInputStream(is, false, ByteOrderMark.UTF_8);
        if (bomIn.hasBOM()) {
            xmlStr = IOUtils.toString(bomIn, Constants.LANG_ENCODING);
        }
        is.close()
        
        def jsonObj = XmlUtil.generateCnOpenDataJsonObject(xmlStr)
        println XmlUtil.getPatentNumber(jsonObj)
        
        println "finished..."
    }

}
