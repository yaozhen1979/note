package org.utils

import java.io.File;

import org.common.Constants

import org.utils.PropertiesUtil

/**
 * 設定存入[PatentMarshallCN]的資料內容
 * 
 * @author tonykuo
 *
 */
class RawDataUtil {
    
    static generateRawData(String text, Date doDate, String path, String patentType, def existData) {
        
        def rawData = [:]
        
        rawData << ["_id" : path]
        rawData << ["provider" : Constants.DATA_PROVIDER]
        rawData << ["doDate" : doDate]
        rawData << ["pto" : Constants.PTO]
        rawData << ["truncate" : false]
        rawData << ["patentType" : patentType]
        rawData << ["soureType" : "xml"]
        
        // TODO: fileType 1為create, 2為amend => 目前CN沒有amend的資料
        rawData << ["fileType" : 1]
        
        if (patentType == "WG") {
            rawData << ["xsd" : PropertiesUtil.getWgXsdFile()]
        } else {
            rawData << ["xsd" : PropertiesUtil.getXsdFile()]
        }
        
        if (!!existData) {
            // 如現在資料已有bibo, claim, description, 則保存.
            def dataMap = existData.data
            dataMap.text = text
            rawData << ["data": dataMap]
        } else {
            def dataMap = [:] << ["text" : text]
            rawData << ["data" : dataMap]
        }
        
        /*
         * NOTE: 2015-11-23 會再補上appNumber是為在marshall而用, 並且在找出clip, embed, first image時的資料夾名稱.
         * NOTE: 2016-03-25 因為SIPO所來的資料folder name = CN101998000158990CN00001034820080ATXTZH20140101CN004
         *       和CN OPEN DATA的不同, 所以appNumber改為在marshall level時, 再來處理.      
         */
        // rawData << ["appNumber" : path.split("/")[3].trim()]
        rawData << MiscUtil.getTagAndFile(existData, "rawLevel")
        rawData << MiscUtil.getMongoSyncFlag(existData)
        
        return rawData
        
    }  // end generateRawData function
    
}
