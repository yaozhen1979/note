package org.service

import java.util.Date;
import java.util.Properties;

import org.service.BaseService

import org.common.Constants
import org.utils.RawDataUtil
import org.utils.RestTimeProcess
import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.PropertiesUtil
import org.utils.MailUtil

class WGService extends BaseService {
    
    // <优先权>, <专利代理机构>, <代理人>, <分案原申请号>, <主权项> : 為例外..., 故不可為檢核數量的依據.
    private final static def ITEM_LIST = [
        "<REC>", "<申请号>", "<专利号>", "<申请日>", "<公开（公告）日>", "<公开（公告）号>", "<名称>", "<主分类号>",
        "<分类号>", "<地址>", "<国省代码>", "<发明（设计）人>", "<申请（专利权）人>",
        "<摘要>", "<页数>", "<PCT公开>", "<PCT申请>", "<PCT信息>", "<光盘号>", "<发布路径>"
    ]
    
    private int recCount = 0;
    
    /**
     * <申请号>=CN201530125600.6 => assignees 有三個
     * <申请号>=CN201530141491.7 => inventors 只有一個
     * <申请号>=CN201430218309.9 => LOCS 有二個
     * 
     * @param file
     * 
     */
    def void processRawData(File file, Date doDate, String argDoPath, String patentType, def dbClient) {
        
        def fileText = getFileText(file)
        def recList = fileText.split(/(?ism)^\s*$/)
        log.info "recList size = ${recList.size()}"
        
        // 再一次檢核該期專利數量是否為一致
        if (this.recCount != recList.size()) {
            throw new Exception("the number of WG parse data error...")
        }
        
        // TODO: patentRawCNIPR 往上移 ???
        def patentRawCNIPR = dbClient.getDB("PatentRawCNIPR").getCollection("PatentRawCNIPR")
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(recList.size(), this.class.name)
        
        recList.each { rec -> 
            
            def dataMap = [:]
            def path;
            
            rec.eachLine { line ->
                def dataArray = line.split("=")
                if (dataArray.size() == 2) {
                    dataMap << getBibMap(dataArray)
                    path = argDoPath + "/" + dataMap.appNumber.replaceAll("CN", "")
                }
            }
            
            // 以path來查詢是否已重複insert
            def existData = patentRawCNIPR.findOne([path: path])
            def rawData = RawDataUtil.generateRawData(rec.trim(), doDate, path, patentType, existData)
            // println "rawData = ${rawData}"
            patentRawCNIPR.save(rawData)
            
            restTimeProcess.process()
            
        }  // end recList.eachWithIndex
        
    }
    
    /**
     * 
     * @param text
     * @return
     */
    def processMarshallData(def text) {
        
        def dataMap = [:]
        // println text
        
        text.eachLine { line ->
            
            def dataArray = line.split("=")
            if (dataArray.size() == 2) {
                dataMap << getBibMap(dataArray)
            }
    
        }  // end text.eachLine
        
        // println "dataMap = ${dataMap}"
        
        return dataMap
    }
    
    /**
     *  @deprecated
     *  
     *  把WG書目資料, 拆分為單一一筆資料, 再以申請號為folder name, bibliography.txt為檔名寫入txt file for 單筆記錄用
     *  
     *  @param record
     *  @param argDoPath
     *  @param appNumber
     */
    def void writeWGRec(def record, String argDoPath, String appNumber) {
        def saveFile = new File(RAW_DATA_FOLDER_PATH + argDoPath + "/" + appNumber.replaceAll("CN", "") + "/bibliography.txt")
        saveFile.getParentFile().mkdirs();
        saveFile.createNewFile();
        saveFile << record
    }
    
    /**
     * 
     * @param dataArray
     * @return
     */
    def getBibMap(def dataArray) {
        
        def bibMap = [:]
        
        def key = dataArray[0]
        def value = dataArray[1]
        switch (key) {
            case ~/<申请号>/:
                bibMap << ["appNumber" : value]
                break;
            case ~/<专利号>/:
                break;
            case ~/<申请日>/:
                bibMap << ["applicationDate" : value]
                break;
            case ~/<公开（公告）日>/:
                bibMap << ["publicationDate" : value]
                break;
            case ~/<公开（公告）号>/:
                bibMap << ["patentNumber" : value]
                break;
            case ~/<名称>/:
                bibMap << ["title" : value]
                break;
            case ~/<主分类号>/:
                bibMap << ["mainLOC" : value]
                break;
            case ~/<分类号>/:
                // 依有多筆資料處理
                def locList = value.split(";").inject([]) { result, it -> 
                    result << it
                }
                bibMap << ["locs" : locList]
                break;
            case ~/<地址>/:
                // 指assignee的地址 
                bibMap << ["address" : value]
                break;
            case ~/<国省代码>/:
                // NOTE EX: 韩国;KR, 广东;44, 江苏;32 => countryCode hard code parse 二碼
                def countryDataList = value.split(";").inject([:]) { result, it -> 
                    if (it ==~ /(?is)[\d|\w]{2}/) {
                        // println "countryCode = ${it}"
                        result << ["countryCode" : it]
                    } else {
                        // println "country = ${it}"
                        result << ["countryName" : it]
                    }
                }
                bibMap << ["country" : countryDataList]
                break;
            case ~/<发明（设计）人>/:
                def inventorList = value.split(";").inject([]) { result, it -> 
                    result << it.trim()
                }
                bibMap << ["inventors" : inventorList]
                break;
            case ~/<专利代理机构>/:
                bibMap << ["agency" : value]
                break;
            case ~/<代理人>/:
                def agentList = value.split(";").inject([]) { result, it -> 
                    result << it.trim()
                }
                bibMap << ["agents" : agentList]
                break;
            case ~/<申请（专利权）人>/:
                def assigneeList = value.split(";").inject([]) { result, it -> 
                    result << it.trim()
                }
                bibMap << ["assignees" : assigneeList]
                break;
            case ~/<摘要>/:
                bibMap << ["brief" : value]
                break;
            case ~/<页数>/:
                def filePageNumber = value as int
                bibMap << ["filePageNumber" : filePageNumber]
                break;
            case ~/<优先权>/:
                def priorityClaimList = value.split(";").inject([]) { result, it ->
                    result << it.trim()
                }
                bibMap << [priorityPatents : priorityClaimList]
                break;
            case ~/<分案原申请号>/:
                bibMap << ["divisionalApplication" : ["originAppNumber" : value.trim()]]
                break;
            case ~/PCT/:
                if (!!value) {
                    def errMsg = "tag: ${key} no parse..."
                    MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data WG Exception Error", errMsg)
                    throw new Exception("tag: ${key} no parse...")
                }
                break;
            case ~/<光盘号>/:
                break;
            case ~/<发布路径>/:
                break;
            case ~/<主权项>/:
                // TODO: 2015-08-26 該期資料, 有下列資料樣例 => <主权项>=PCT国内申请，权利要求书已公开。, 暫不處理.
                break;
            default:
                def errMsg = "tag: ${key} no match..."
                MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data WG Exception Error", errMsg)
                throw new Exception(errMsg)
                break;
        }
        
        return bibMap
    }
    
    /**
     * 檢核WG中[REC]的數量和其餘各欄位的總數量是否為一致. 
     * 
     * @param file
     * @return
     */
    private boolean checkCount(File file) throws Exception {
        
        def checkFlag = false
        
        def fileText = getFileText(file)
        // println fileText
        
        // println "checkList size = ${checkList.size()}"
        
        ITEM_LIST.each { checkItem -> 
            
            def matchGroup = fileText =~ "(?ism)${checkItem}"
            def checkCount = matchGroup.size()
            // println "checkCount = ${checkCount}"
            
            if (checkItem == "<REC>") {
                this.recCount = checkCount
            } else {
                checkFlag = (checkCount == this.recCount ? true : false)
                if (checkFlag == false) {
                    def checkMsg = "${checkItem} count = ${checkCount} do not match with rec count = ${this.recCount}"
                    println checkMsg
                    throw new Exception(checkMsg)
                }
            }
            
        }  // end checkList.each
        
        return checkFlag
    }
    
    /**
     * TODO: 20151119: 編碼有問題...
     * 
     * @param file
     * @return
     */
    static String getFileText(File file) {
        /*
         * NOTE => WG的書目資料從CN_OPEN_DATA來的時候, 其檔案編碼為[GB2312], 但在本地開發時IDE的編碼預設是[UTF-8]
         *         所以在處理正式WG書目資料檔和WG測試書目資料檔時, 其編碼應該額外處理...
         */
        return new String(file.getText(Constants.LANG_ENCODING).getBytes(Constants.LANG_ENCODING))
    }
    
    /**
     * For Test
     * 
     * @param args
     */
    static main(args) {
        
        File wgFile = new File("opendata-sample/WG/20151104_BIO.txt")
        // File wgFile = new File("T:/cnlist/opendata/WG/2015/20150923/INDUSTRIAL-DESIGN-BIB.TXT")
        
        WGService wgService = new WGService()
        
        if (wgService.checkCount(wgFile)) {
            log.info "check WG bib data ok..."
        }
        
        // parse WG data => File file, Date doDate, String argDoPath, String patentType, def dbClient
        String argDoPath = "WG/2015/20150923"
        String patentType = "WG"
        Date doDate = DateUtil.parseDate("20150923");
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "127.0.0.1", 27017, 'admin')
        wgService.processRawData(wgFile, doDate, argDoPath, patentType, dbClient)
        
        println "finished..."
    }

}
