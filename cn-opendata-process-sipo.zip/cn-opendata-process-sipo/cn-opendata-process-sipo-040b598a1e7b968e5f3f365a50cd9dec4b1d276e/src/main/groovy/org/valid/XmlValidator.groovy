package org.valid;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.utils.PropertiesUtil
import org.utils.XmlUtil
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import org.common.Constants

public class XmlValidator {
    
    private static DocumentBuilder documentBuilder
    
    private static boolean validInited;
    private static boolean validWGInited;
    
    // for FM, SD, XX
    private static Validator validator
    // for WG
    private static Validator validatorWG
    
    public static void initValidate() {
        
        if (validInited) {
            return
        }
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        dbf.setNamespaceAware(true);
        documentBuilder = dbf.newDocumentBuilder();
        
        SchemaFactory factory = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        
        File schemaLocation = new File(PropertiesUtil.getXsdFile());
        Schema schema = factory.newSchema(schemaLocation);
        validator = schema.newValidator();
        
        validInited = true
    }
    
    public static void initValidateWG () {
        
        if (validWGInited) {
            return
        }
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        dbf.setNamespaceAware(true);
        documentBuilder = dbf.newDocumentBuilder();
        
        SchemaFactory factory = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        
        File schemaLocation = new File(PropertiesUtil.getWgXsdFile());
        Schema schema = factory.newSchema(schemaLocation);
        validatorWG = schema.newValidator();
        
        validWGInited = true
    }
    
    /**
     * 
     * @param validXmlPath
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public boolean validate(String validXmlPath, String patentType) throws SAXException, IOException,
            ParserConfigurationException {
        return validate(new File(validXmlPath), patentType);
    }
    
    /**
     * 
     * @param validXml
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public boolean validate(File file, String patentType) throws SAXException, IOException,
            ParserConfigurationException {
        
        patentType == "WG" ? initValidateWG() : initValidate()
                
        def fileText = XmlUtil.reomoveDTDDeclaration(file.getText(Constants.LANG_ENCODING))
        // println fileText
        
        InputStream is = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        Document doc = documentBuilder.parse(is);
    
        patentType == "WG" ? validatorWG.validate(new DOMSource(doc)) : validator.validate(new DOMSource(doc))
        
        return true
    }
    
    static main(args) {
        
        // println new XmlValidator().validate("opendata-sample/FM/201180019236.4/201180019236NEW.XML", "FM")
        
        // 201530091838 / 201530079283
        println new XmlValidator().validate("opendata-sample/WG/sipo/201530091838.XML", "WG")
        
    }

}
