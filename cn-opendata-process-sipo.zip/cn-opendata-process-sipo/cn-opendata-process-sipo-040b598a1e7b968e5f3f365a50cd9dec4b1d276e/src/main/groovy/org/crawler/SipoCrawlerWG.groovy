/**
 * WG crawler deprated... 直接改用CN OPEN DATA中所提供的書目資料即可....
 */
package org.crawler

import groovy.time.TimeCategory
import org.jsoup.Connection.Response
import org.utils.MailUtil

/**
 *  該隻為目前每週三時, 爬取sipo的申請號程式.
 */
class SipoCrawlerWG {
    
    private static final String SIPO_QUREY_URL = "http://epub.sipo.gov.cn/patentoutline.action"
    
    private static final String SIPO_SERVER = "http://epub.sipo.gov.cn"
    
    private static final String LINE_SEPARATOR = System.getProperty('line.separator')
    
    /**
     *
     * @param querydate 查詢日期(yyyy.MM.dd)
     * @param folderName 資料名稱
     * @param type 專利類型  1.發明公佈 2.發明授權 3. 實用新型 4. 外觀設定
     * @return
     */
    static void crawlerWGUtil(querydate, folderName, type) {
        
        // date formate yyyy.MM.dd
        // def querydate = '2015.01.21';
        // def folderName = "20150121"
        // def type = 1;  // 1.發明公佈 2.發明授權 3. 實用新型 4. 外觀設定
        // System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]
        
        def typeCode;
        def date = Date.parse('yyyy.MM.dd', querydate);
        def nextPage = true;
        def pageNum = 1;
        def pageSize = 10;
        
        // TODO: set cookies
//        Map<String, String> cookieMap = new HashMap<String, String>() {
//            {
//                put("WEB", "20111116");
//                put("_gscu_2029180466", "455636501szgmu68");
//                put("_gscbrs_2029180466", "1");
//                put("_gscu_1718069323", "45563650jw771057");
//                put("_gscbrs_1718069323", "1");
//                put("JSESSIONID", "46BF04EA18EC5DB8ED3B422B0CACBEE7");
//            }
//        };
        
        
        switch(type) {
            case 1 : typeCode = 'FM'
              break
            case 2 : typeCode = 'SD'
              break
            case 3 : typeCode = 'XX'
              break
            case 4 : typeCode = 'WG'
              break
            Default :
              break
        }
        
        // TODO: mkdir save folder
        // hard code =>
        File saveFolder = new File("T:/cnlist/rawdata/${folderName}/${typeCode}")
        org.apache.commons.io.FileUtils.forceMkdir(saveFolder)
        
        println "to start..."
        
        while (nextPage) {
        
            def doc = null;
            def retry = 0;
        
            while (retry < 10)  {
                try {
                    // for 列表模式
                    // showType=0&strWord=公开（公告）日='2015.05.06'&numSortMethod=0&strLicenseCode=&selected=fmsq&numFMGB=&numFMSQ=4609&numSYXX=&numWGSQ=&pageSize=10&pageNow=1
                    doc = org.jsoup.Jsoup.connect(SIPO_QUREY_URL).timeout(300000)
                            // .userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36")
                            // .referrer("http://epub.sipo.gov.cn/gjcx.jsp")
                            // .header("Content-Length", "200")
                            // .header("Cache-Control", "max-age=0")
                            // .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                            // .header("Origin", "http://epub.sipo.gov.cn")
                            // .header("Accept-Encoding", "gzip, deflate")
                            // .header("Accept-Language", "zh-TW,zh;q=0.8,en-US;q=0.6,en;q=0.4,zh-CN;q=0.2")
                            // .cookies(cookieMap)
                            .data("showType", "1")
                            // .data("strWord", "公开（公告）日=BETWEEN['${date.format('yyyy.MM.dd')}','${enddate.format('yyyy.MM.dd')}']")
                            // .data("strWord", "公开（公告）日='${querydate}'")
                            .data("strWord", "公开（公告）号='CN303428782S%' and 公开（公告）日='${querydate}'")
                            .data("pageSize", pageSize.toString())
                            .data("pageNow", pageNum.toString())
                            .data("numFMGB", type == 1 ? "0":"")   // 發明公佈
                            .data("numFMSQ", type == 2 ? "0":"")
                            .data("numSYXX", type == 3 ? "0":"")
                            .data("numWGSQ", type == 4 ? "0":"")
                            .post();
                    break;
                } catch (Exception e) {
                    retry++;
                    println 'will retry list:' + retry
                    println "Exception = ${e}"
                }
            }
        
            if (doc == null) {
                println 'could not get list!';
                break;
            }
            
            def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
            println "cntt = ${cntt}"
            
            def cnt = cntt.substring(5, cntt.length()-1) as int
            println "cnt = ${cnt}"
            
            def pages = ((cnt + pageSize - 1) / pageSize) as int
            println "${querydate} type::${type} cnt:${cnt} pages:${pageNum}/${pages}"
            
            // parse img url
            // println doc.html()
            
            doc.select("div.w790.right > div.cp_box").eachWithIndex { node, index ->
                
                def dataMap = [:]
                
                // println node.html()
                // CN303428782S => 有優先權, LOC 也有二筆資料
                // CN303429555S => 沒有專業代理機構等欄位資料
                def title = node.select("div.cp_linr > h1").text().replaceAll("[\\[外观设计\\] ]", "").trim()
                // println "title = ${title}"
                dataMap << ["title": title]
                
                node.select("div.cp_linr > ul > li").each { liNode ->
                    def text = liNode.text()
                    if (text.startsWith("分类号")) {
                        // TODO
                        def locs = []
                        def locInfoHtml = liNode.html()
                        // println locInfoHtml
                        // 分类号[\S\s]*?<a[\S\s]*?>全部<\/a>
                        // <a href="javascript:;" class="zhankai" style="color:#c5000f"
                        def matchGroup = locInfoHtml =~ /(?ism)(\d{1,4}-\d{1,4}\s*\(?\d*\)*[;\s]?)/
                        matchGroup.each { it -> 
                            def loc = it[0].replaceAll("[;&]", "")
                            locs << [loc]
                        }
                        dataMap << ["locs" : locs]
                        
                        liNode.select("div > ul > li").each { it -> 
                           println it.text()
                        }
                        
                    } else {
                        // println liNode.text()
                        def textArray = liNode.text().split("：")
                        if (textArray.size() == 2) {
                            def key = textArray[0].trim()
                            println "key = ${key}"
                            def value = textArray[1].trim()
                            println "value = ${value}"
                            switch(key) {
                                case "授权公告号":
                                    dataMap << [patentNumber: value]
                                    break
                                case "授权公告日":
                                    dataMap << [publicationDate: value]
                                    break
                                case "申请号":
                                    dataMap << [appNumber: value]
                                    break
                                case "申请日":
                                    dataMap << [applicationDate: value]
                                    break
                                case "专利权人":
                                    // 多個assignee ???
                                    dataMap << [assignee: value]
                                    break
                                case "地址":
                                    dataMap << [address: value]
                                    break
                                case "设计人":
                                    def inventors = []
                                    value.split(";").each { it -> 
                                        inventors << [name: [origin: it.replaceAll(" ", "").trim()]]
                                    }
                                    dataMap << [inventors: inventors]
                                default:
                                    println "no data"
                                    break
                            }
                        }
                        
                    }
                }
                
                def briefHtml = node.select("div.cp_jsh").html().replaceAll("<a[\\S\\s]*?>全部</a>", "")
                def briefText = org.jsoup.Jsoup.parse(briefHtml).text().replaceAll("简要说明： ", "").trim()
                // println "brief = ${briefText}"
                dataMap << [brief: briefText]
                
                // get first image
                def firstImgThumbUrl = node.select("div.cp_img > img").attr('src')
                def firstImgUrl = firstImgThumbUrl.replaceAll("_thumb", "")
                if (!!firstImgThumbUrl) {
                    def firstImgData = [:]
                    firstImgData = [:] << [origin: SIPO_SERVER + "/" + firstImgUrl]
                    firstImgData = [:] << [thumb: SIPO_SERVER + "/" + firstImgThumbUrl]
                    dataMap << firstImgData
                }
                
                println "dataMap = ${dataMap}"
            }
            
            pageNum++
            
            // if (pageNum > pages) {
            if (true) {
                break
            }
        
        }  // end while
        
        // fos.close()
        
        println "${typeCode} crawler finished!"
    }
    
    /**
     * ref apache common fileutil api 2.5
     *
     * @param file
     * @param append
     * @return
     * @throws IOException
     */
    static FileOutputStream openOutputStream(final File file, final boolean append) throws IOException {
        if (file.exists()) {
            if (file.isDirectory()) {
                throw new IOException("File '" + file + "' exists but is a directory");
            }
            if (file.canWrite() == false) {
                throw new IOException("File '" + file + "' cannot be written to");
            }
        } else {
            final File parent = file.getParentFile();
            if (parent != null) {
                if (!parent.mkdirs() && !parent.isDirectory()) {
                    throw new IOException("Directory '" + parent + "' could not be created");
                }
            }
        }
        return new FileOutputStream(file, append);
    }
    
    static def main(args) {
        
        System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]
        
        SipoCrawlerWG.crawlerWGUtil("2015.11.04", "20151104", 4)
        
        println "finished..."
    }
    
}

