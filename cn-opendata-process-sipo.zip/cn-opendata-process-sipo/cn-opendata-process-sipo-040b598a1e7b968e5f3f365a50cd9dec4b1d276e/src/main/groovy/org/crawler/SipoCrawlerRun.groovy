package org.crawler

import org.crawler.SipoCrawlerWG

// date formate yyyy.MM.dd
// def querydate = '2015.01.21';
// def folderName = "20150121"
// def type = 1;  // 1.發明公佈 2.發明授權 3. 實用新型 4. 外觀設定


class SipoCrawlerFirstImgRun {
    
    static void run() {
        
        System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]
        
        //-----------------------------待檢核數量
        
        def typeList = [1, 2, 3, 4]
        
        // TODO: 查詢日期寫入DB ??
        def dateList = [
            '20151028'
        ]
        
        dateList.each { date ->
            
            File fileLog = new File("first_image_log/no_img/${date}.log");
            
            def dateFmt = date.substring(0, 4) + "." + date.substring(4, 6) + "." + date.substring(6, 8)
            // println "dateFmt = ${dateFmt}"
            
            typeList.each { type ->
                //
                SipoCrawlerWG.crawlerFirstImgUtil(dateFmt, date, type, fileLog)
            }
            
        }
        
        println "finished..."
        
    }
    
    public static void main(args) {
        run();
    }
    
}
