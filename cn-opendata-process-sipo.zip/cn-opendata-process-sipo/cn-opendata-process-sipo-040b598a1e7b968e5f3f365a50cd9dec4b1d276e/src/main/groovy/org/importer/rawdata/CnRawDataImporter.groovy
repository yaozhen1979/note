package org.importer.rawdata

import org.common.Constants

import java.io.File
import java.util.Date
import org.utils.RawDataUtil
import org.utils.RestTimeProcess

import org.utils.PropertiesUtil
import org.utils.XmlUtil
import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.MailUtil

import org.error.CnDataErrorProcess

import org.valid.XmlValidator
import org.xml.sax.SAXParseException

import org.service.BaseService
import org.service.WGService

class CnRawDataImporter extends BaseService {
    
    /**
     * 處理FM, SD, XX三種專利類型
     * 
     * @param dir
     * @param doDate
     * @param argDoPath
     * @param patentType
     */
    def void process(File dir, Date doDate, String argDoPath, String patentType, def dbClient) {
        
        def fileCount = dir.listFiles().size()
        // println "fileCount = ${fileCount}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)
        
        def db = dbClient.getDB("PatentRawCNIPR")
        def patentRawCNIPR = db.getCollection("PatentRawCNIPR")
        def errorPatentRawCNIPR = db.getCollection("ErrorPatentRawCNIPR");
        //
        XmlValidator xmlValidator = new XmlValidator()
        
        dir.listFiles().eachWithIndex { File folder, index ->
            
            boolean checkXmlFlag = false
            
            folder.listFiles().each { File it ->
                
                if (it.name.toUpperCase().contains("XML")) {
                    
                    checkXmlFlag = true
                    
                    def path = argDoPath + "/" + it.getParentFile().name
                    // println "path name = ${path}"
                    
                    try {
                        
                        // valid xml by xsd
                        if (xmlValidator.validate(it)) {
                            
                            // 以path來查詢是否已重複insert
                            def existData = patentRawCNIPR.findOne([path: path])
                            def xmlStr = XmlUtil.getXmlText(it.getAbsolutePath())
                            def rawData = RawDataUtil.generateRawData(xmlStr, doDate, path, patentType, existData)
                            // println "rawData = ${rawData}"
                            
                            patentRawCNIPR.save(rawData)
                            
                            restTimeProcess.process()
                        }
                        
                    } catch (SAXParseException e) {
                        log.error "path = ${path}/${it.name}, SAXParseException = ${e}"
                        // insert error data => errorPatentMarshallCN
                        CnDataErrorProcess.saveRawDataError(errorPatentRawCNIPR, path, patentType, doDate, e.toString())
                        // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data SAXParseException Error", "path = ${path}/${it.name}, ${e.toString()}")
                    } catch (Exception e) {
                        // TODO: how to handler exception ???
                        log.error "path = ${path}/${it.name}, Exception = ${e}"
                        CnDataErrorProcess.saveRawDataError(errorPatentRawCNIPR, path, patentType, doDate, e.toString())
                        // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data Exception Error", "path = ${path}/${it.name}, ${e.toString()}")
                    }
                    
                }  // end it.name.toUpperCase().contains("XML")
                
            }  // end file.listFiles
            
            if (checkXmlFlag == false) {
                def path = argDoPath + "/" + folder.name
                CnDataErrorProcess.saveRawDataError(errorPatentRawCNIPR, path, patentType, doDate, "${path}, no xml file exists")
                MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data SAXParseException Error", "${path}, no xml file exists")
            }
            
        }  // end file.listFiles
        
    }
    
    /**
     * 
     * @param args
     * @param period
     * @return
     */
    def processRawData(def args, def period) {
        
        String argDoPath = args.argDoPath
        String patentType = args.patentType
        Date doDate = DateUtil.parseDate(period);
        log.info "args = ${args}"
        log.info "doDate = ${doDate}"
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        
        File dir = new File(RAW_DATA_FOLDER_PATH + argDoPath)
        println "path = ${RAW_DATA_FOLDER_PATH + argDoPath}"
        
        if (!dir.exists()) {
            throw new Exception("No Raw Data Folder Exist")
        }
        
        if (patentType == "WG") {
            
            WGService wgService = new WGService()
            
            dir.listFiles().each { it ->
                if (it.name.toUpperCase() == Constants.WG_BIB_FILE_NAME) {
                    if (wgService.checkCount(it)) {
                        log.info "check WG bib data ok..."
                    }
                    // parse WG data
                    wgService.processRawData(it, doDate, argDoPath, patentType, dbClient)
                }
            }
            
        } else {
            //
            process(dir, doDate, argDoPath, patentType, dbClient)
        }
        
    }  // end processOpenData function
    
    static main(args) {
        
        //
        def year = "2016"
        def period = "20160309"
        
        /*
         * WG: 特有期數 => (YYYY - 1985 + 1) + 當年週數 => EX: (2015 - 1985 + 1) + 第38週 = 3138
         * CNIPR 才會有期數,
         * CN Open Data 則無...
         */
        // def wgPeriod = "3138"
        
        // "FM", "SD", "XX", "WG"
        ["WG"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑 => FM/20160203/201510420831.9
            argMap << ['argDoPath' : "${patentType}/${year}/${period}"]
            argMap << ['patentType' : patentType]
            
            new CnRawDataImporter().processRawData(argMap, period);
            
        }
        
        println "finished..."
    }

}
