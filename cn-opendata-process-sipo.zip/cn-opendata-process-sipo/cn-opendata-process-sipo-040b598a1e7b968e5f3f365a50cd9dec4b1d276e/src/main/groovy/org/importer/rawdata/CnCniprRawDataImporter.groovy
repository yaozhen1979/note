package org.importer.rawdata;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.utils.ProcessEstimater;
import org.utils.DateUtil
import org.utils.MongoUtil

/**
 * CnImportRawData: CN 導入到 Level 1 的程式, groovy version
 *
 * @author tonykuo
 *
 */
public class CnCniprRawDataImporter {

    static Logger log = LoggerFactory.getLogger(CnCniprRawDataImporter.class);

    private File bookpath;

    private ProcessEstimater pe;

    private static String provider;
    
    public CnCniprRawDataImporter() {}
    
    /**
     *
     * @param bookpath
     * @throws UnknownHostException
     */
    public CnCniprRawDataImporter(String bookpath) throws UnknownHostException {
        //
        this.bookpath = new File(bookpath);
        pe = new ProcessEstimater(0).setFormat("%2\$d");
    }
    
    /**
     *
     * @param args
     * @throws Exception
     */
    void worker(def args, def period) throws Exception {
        
        String argPath = args.argPath
        String argDoPath = args.argDoPath
        
        if (argDoPath.contains("/WG/")) {
            provider = "CNIPR1";
        } else {
            provider = "CNIPR2";
        }

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + args);
        }
        
        // TODO: connect to mongodb => 10.60.90.101
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def patentRawCN = client.getDB("PatentRawCN")
        
        new CnCniprRawDataImporter(argPath).importDir(new File(argDoPath), patentRawCN, period);

        log.debug("finish");
    }
    
    /**
     * 處理指定目錄 ???
     *
     * ref: Another builder pattern for
     * Java[http://blog.crisp.se/2013/10/09
     * /perlundholm/another-builder-pattern-for-java]
     *
     * @param dir
     * @return
     * @throws IOException
     */
    public CnCniprRawDataImporter importDir(File dir, def dbClient, def period) throws IOException {

        if (dir.isDirectory()) {
            
            // find 該目錄內是否有書目資料
            File fileBiblio = dir.toPath().resolve("bibliography.html")
                    .toFile();

            if (fileBiblio.isFile()) {

                File fileClaim = dir.toPath().resolve("claim.xml").toFile();
                File fileDesc = dir.toPath().resolve("description.xml")
                        .toFile();
                
                // TODO: 要在調整path. 20150710
                String path = bookpath.toPath().relativize(dir.toPath())
                        .toString().replaceAll("\\\\", "/");

                Date doDate = DateUtil.parseDate(period);
                
                if (doDate == null) {
                    // process special case
                    while (true) {
                        //
                        Matcher mat;
                        mat = Pattern.compile("(?i)^SD/1992/19921230Z/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtil.parseDate("19921230");
                            break;
                        }

                        mat = Pattern.compile("(?i)^WG/(\\d{4})/\\d{4}/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtil.parseDate(mat.group(1) + "0101");
                            break;
                        }

                        break;
                    }
                }
                
                def rawData = [:]
                
                def findData = dbClient.PatentRawCN.findOne([path: path])
                
                if (!!findData) {
                    rawData = setRawData(doDate, path, fileBiblio, fileClaim, fileDesc, findData)
                } else {
                    rawData = setRawData(doDate, path, fileBiblio, fileClaim, fileDesc, null)
                }
                
                // log.debug("doDate = " + doDate);
                println "rawData id = ${rawData._id}"
                //dbClient.PatentRawCN.save(rawData)
                
                pe.addNum().debug(log, 10000, "save: '" + path + "'");

            } else {
                
                // 真正處理的entry point
                for (File file : dir.listFiles()) {
                    if (file.isDirectory()) {
                        importDir(file, dbClient, period);
                    }
                }

            }
        }

        return this;
    }
    
    /**
     * 
     * @param doDate
     * @param fileBiblio
     * @param fileClaim
     * @param fileDesc
     * @return
     */
    private setRawData(Date doDate, String path, File fileBiblio, File fileClaim, File fileDesc, def findData) {
        
        def rawData = [:]
        
        rawData << ["pto" : "CNIPR"]
        rawData << ["path" : path]
        rawData << ["type" : "html/json-html"]
        rawData << ["provider" : provider]
        rawData << ["doDate" : doDate]

        def dataMap = [:]
        
        if (fileBiblio.isFile()) {
            dataMap << ["bibliography" : FileUtils.readFileToString(fileBiblio, "UTF-8")]
        }

        if (fileClaim.isFile()) {
            dataMap << ["claim" : FileUtils.readFileToString(fileClaim, "UTF-8")]
        }

        if (fileDesc.isFile()) {
            dataMap << ["description" : FileUtils.readFileToString(fileDesc, "UTF-8")]
        }
        
        rawData << [data: dataMap]
        
        if (!!findData) {
            rawData << ["_id" : findData._id]
        }

        return rawData
    }
    
    /**
     * entry point
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        
        //
        def year = "2014"
        def period = "20140101"
        def wgPeriod = "3001"
        //
        CnCniprRawDataImporter cnipr = new CnCniprRawDataImporter();
        
        ["FM", "SD", "XX", "WG"].each { type -> 
            
            def argMap = [:]
            
            argMap << ['argPath' : "T:/cnlist/rawdata"]
            
            if (type == "WG") {
                argMap << ['argDoPath' : "T:/cnlist/rawdata/${type}/${year}/${wgPeriod}"]
            } else {
                argMap << ['argDoPath' : "T:/cnlist/rawdata/${type}/${year}/${period}"]
            }
            
            cnipr.worker(argMap, period);
            
        }
    }

}
 