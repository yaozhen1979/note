package org.importer.marshalldata

import com.mongodb.BasicDBObject
import java.util.Date;

import org.service.BaseService;
import org.service.WGService
import org.utils.RestTimeProcess
import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.PropertiesUtil
import org.utils.MarshallDataUtil
import org.utils.XmlUtil
import org.utils.MailUtil
import org.apache.commons.io.FileUtils

/**
 * For SIPO XML DATA
 *
 * @author tonykuo
 *
 */
class SipoMarshallDataImporter extends BaseService {

    /**
     * 
     * @param args
     * @param period
     * @return
     */
    def processMarshallData(def args, def period, def queryMap = null) {
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def rawDataDB = dbClient.getDB(PropertiesUtil.getRawDB())
        
        // NOTE: 暫時使用... 等正式使用11月份的資料時再統一使用dbClient
        // def remoteClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.90.101", MONGODB_PORT, 'admin')
        def marshallDataDB = dbClient.getDB(PropertiesUtil.getMarshallDB())
        
        def rawDataCollection = rawDataDB.getCollection(PropertiesUtil.getRawCol())
        def marshallDataCollection = marshallDataDB.getCollection(PropertiesUtil.getMarshallCol())
        def errMarshallDataCollection = marshallDataDB.getCollection(PropertiesUtil.getMarshallErrCol());
        //
        // 可自定義查詢條件
        if (!queryMap) {
            String patentType = args.patentType
            Date doDate = DateUtil.parseDate(period);
            // log.info "args = ${args}"
            // log.info "doDate = ${doDate}"
            queryMap = [doDate: doDate, patentType: patentType]
        }
        def rawDataCursor = rawDataCollection.find(queryMap).sort(new BasicDBObject("doDate":1)).limit(0)
        rawDataCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        if (rawDataCursor.count() == 0) {
            throw new Exception("no data find...")
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(rawDataCursor.count(), this.class.name)
        
        def _id = null;  // for exception message
        
        try {
            rawDataCursor.each { rawData ->
                
                _id = rawData._id
                //
                def expansionData = XmlUtil.generateCnOpenDataJsonObject(rawData)
                
                if(!!expansionData){
                    def existDate = marshallDataCollection.findOne([doDate: rawData.doDate, patentNumber: XmlUtil.getPatentNumber(expansionData)])
                    
                    def marshallData = MarshallDataUtil.generateMarshallData(expansionData, rawData, existDate)
                    
                    // marshallDataCollection.save(marshallData)
                    marshallDataCollection.save(marshallData, com.mongodb.WriteConcern.ACKNOWLEDGED)
                    
                    restTimeProcess.process()
                }                
            }
        } catch (e) {
            //log.error "Exception = ${e}"
            log.error "rawdata._id = ${_id}, Exception = ${e}"
            // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data Exception Error", "${_id} = ${e.toString()}")
        } finally {
            dbClient.close()
            // remoteClient.close()
        }
        
    }
    
    static main(args) {
        
        /*//
        def period = "19930609"
        
        //["SD", "XX", "WG"].each { patentType ->
		["FM"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['patentType' : patentType]
            
            new SipoMarshallDataImporter().processMarshallData(argMap, period);
            
        }*/
        def startdate = args[0];
        def enddate = args[1];
        def queryMap = [doDate:[$gte:DateUtil.parseDate(startdate),$lte:DateUtil.parseDate(enddate)]]
        new SipoMarshallDataImporter().processMarshallData(null, null,queryMap);
        println "finished..."
        
    }

}
