package org.importer.rawdata

import java.io.File
import java.util.Date
import org.utils.RawDataUtil
import org.utils.RestTimeProcess

import org.utils.PropertiesUtil
import org.utils.XmlUtil
import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.MailUtil

import org.error.CnDataErrorProcess
import org.valid.XmlValidator
import org.xml.sax.SAXParseException
import org.service.BaseService

/**
 * For SIPO XML DATA
 * 
 * @author tonykuo
 *
 */
class SipoRawDataImporter extends BaseService {
    
    /**
     * 處理FM, SD, XX, WG三種專利類型
     * 
     * @param dir
     * @param doDate
     * @param argDoPath
     * @param patentType
     */
    def void process(File dir, Date doDate, String argDoPath, String patentType, def dbClient) {
        
        def fileCount = dir.listFiles().size()
        // println "fileCount = ${fileCount}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)
        
        // TODO: DB 在SIPO資料進來後, 改為使用PatentRawSIPO
        def db = dbClient.getDB(PropertiesUtil.getRawDB())
        def patentRawSIPO = db.getCollection(PropertiesUtil.getRawCol())
        def errorPatentRawSIPO = db.getCollection(PropertiesUtil.getRawErrCol());
        //
        XmlValidator xmlValidator = new XmlValidator()
        
        dir.listFiles().eachWithIndex { File folder, index ->
            
            boolean checkXmlFlag = false
            
            folder.listFiles().each { File it ->
                
                if (it.name.toUpperCase().contains("XML") && it.name.toUpperCase().startsWith("CN")) {
                    
                    checkXmlFlag = true
                    
                    def path = argDoPath + "/" + it.getParentFile().name
                    // println "path name = ${path}"
                    
                    try {
                        
                        // valid xml by xsd
                        if (xmlValidator.validate(it, patentType)) {
                        //if (true) {
                            
                            // 以path來查詢是否已重複insert
                            def existData = patentRawSIPO.findOne([_id: path])
                            def xmlStr = XmlUtil.getXmlText(it.getAbsolutePath())
                            def rawData = RawDataUtil.generateRawData(xmlStr, doDate, path, patentType, existData)
                            // println "rawData = ${rawData}"
                            
                            patentRawSIPO.save(rawData)
                            
                            restTimeProcess.process()
                        }
                        
                    } catch (SAXParseException e) {
                        log.error "path = ${path}/${it.name}, SAXParseException = ${e}"
                        // insert error data => errorPatentRawSIPO
                        CnDataErrorProcess.saveRawDataError(errorPatentRawSIPO, path, patentType, doDate, e.toString())
                        // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data SAXParseException Error", "path = ${path}/${it.name}, ${e.toString()}")
                    } catch (Exception e) {
                        // TODO: how to handler exception ???
                        log.error "path = ${path}/${it.name}, Exception = ${e}"
                        CnDataErrorProcess.saveRawDataError(errorPatentRawSIPO, path, patentType, doDate, e.toString())
                        // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data Exception Error", "path = ${path}/${it.name}, ${e.toString()}")
                    }
                    
                }  // end it.name.toUpperCase().contains("XML")
                
            }  // end file.listFiles
            
            if (checkXmlFlag == false) {
                def path = argDoPath + "/" + folder.name
                CnDataErrorProcess.saveRawDataError(errorPatentRawSIPO, path, patentType, doDate, "${path}, no xml file exists")
                // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data SAXParseException Error", "${path}, no xml file exists")
            }
            
        }  // end file.listFiles
        
    }
    
    /**
     * 
     * @param args
     * @param period
     * @return
     */
    def processRawData(def args, def period) {
        
        String argDoPath = args.argDoPath
        String patentType = args.patentType
        Date doDate = DateUtil.parseDate(period);
        log.info "args = ${args}"
        log.info "doDate = ${doDate}"
        
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        
        // TODO: 資料處理路徑
        File dir = new File(RAW_DATA_FOLDER_PATH + argDoPath)
        println "path = ${RAW_DATA_FOLDER_PATH + argDoPath}"
        
        if (!dir.exists()) {
            throw new Exception("No Raw Data Folder Exist")
        }
        
        process(dir, doDate, argDoPath, patentType, dbClient)
        
    }  // end processOpenData function
    
    /**
     * 
     * 
     * @param args
     */
    static main(args) {
        
        // 讀取外部設定檔, 來設定查詢參數, filePath也可以hard code.
        def filePath = args[0];
        FileReader reader = new FileReader(filePath);
        BufferedReader br = new BufferedReader(reader);
        String temp = null;
        
        while ((temp = br.readLine()) != null) {
            String[] array = temp.split(";")
            def patentType = array[0];
            def year = array[1];
            def period = array[2];
                
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['argDoPath' : "${patentType}/${year}/${period}"]
            argMap << ['patentType' : patentType]
            
            new SipoRawDataImporter().processRawData(argMap, period);
        }
        
        println "finished..."
    }

}

