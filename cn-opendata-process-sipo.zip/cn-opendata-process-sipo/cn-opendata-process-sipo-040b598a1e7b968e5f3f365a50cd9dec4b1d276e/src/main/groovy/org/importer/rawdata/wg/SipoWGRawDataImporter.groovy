package org.importer.rawdata.wg

import org.utils.DateUtil;
import org.utils.FileUtil;
import org.utils.RestTimeProcess

class SipoWGRawDataImporter {
    
    static main(args) {
        // TODO
        println "finished..."
        
    }

}
