package org.importer.infodata

import org.bson.types.ObjectId
import org.exception.CnException
import org.service.BaseService
import org.utils.RestTimeProcess

import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.infodata.InfoDataUtil
import org.utils.infodata.WGInfoDataUtil

class CnInfoDataImporter extends BaseService {
    
    //
    def processInfoData(def args, def period, def queryMap = null) {
        
        // NOTE: 暫時使用... 等正式使用11月份的資料時再統一使用dbClient
        def remoteClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def marshallDB = remoteClient.getDB("PatentMarshallCN")
        def patentMarshallCN = marshallDB.getCollection("PatentMarshallCN")
        //
        def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def infoDB = dbClient.getDB("PatentInfoCNIPR")
        def patentInfoCNIPR = infoDB.getCollection("PatentInfoCNIPR")
        def errorPatentInfoCNIPR = infoDB.getCollection("ErrorPatentInfoCNIPR");
        
        // 可自定義查詢條件
        if (!queryMap) {
            String patentType = args.patentType
            Date doDate = DateUtil.parseDate(period);
            log.info "args = ${args}"
            log.info "doDate = ${doDate}"
            queryMap = [patentType: patentType, doDate: doDate]
        }
        
        def marshallCursor = patentMarshallCN.find(queryMap)
        marshallCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        println "marshallCount = ${marshallCursor.count()}"
        
        if (marshallCursor.count() == 0) {
            throw new Exception("no data find...")
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(marshallCursor.count(), this.class.name)
        
        def _id = null;  // for exception message
        
        try {
            
            marshallCursor.each { it -> 
                
                _id = it._id
                
                def expansionData = it.data.expansion
                def queryMapForExistData = queryMapForExistData(it)
                def existInfolData = patentInfoCNIPR.findOne(queryMapForExistData)
                def infoData = null
                
                if (it.patentType == "WG") {
                    infoData = WGInfoDataUtil.generateWGInfoData(it, existInfolData)
                } else {
                    infoData = InfoDataUtil.generateInfoData(it, existInfolData, errorPatentInfoCNIPR)
                }
                // println "infoData = ${infoData}"
                
                // TODO: json validator
                
                if (!!existInfolData) {
                    patentInfoCNIPR.update([_id: existInfolData._id], infoData, true, false, com.mongodb.WriteConcern.ACKNOWLEDGED)
                } else {
                    patentInfoCNIPR.insert(infoData, com.mongodb.WriteConcern.ACKNOWLEDGED)
                }
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            // TODO: save to error collection
            def errMsg = "marshall._id = ${_id}, Exception = ${e.message}"
            log.error errMsg
            throw new CnException(errMsg)
        } finally {
            dbClient.close()
        }
        
    }
    
    /**
     * 
     * @param lv1Data
     * @return
     */
    def queryMapForExistData(def marshallData) {
        
        def queryMap = [:]
        queryMap << [doDate: marshallData.doDate]
        
        // NOTE: CN, KR 因為歷史原因, 導致在infoDB中patentNumber = appNumber. 
        queryMap << [appNumber: marshallData.appNumber]
        
        def patentType = marshallData.patentType
        switch (patentType) {
            case "FM":
                queryMap << [stat : 1]
                break;
            case "SD":
                queryMap << [stat : 2]
                break;
            case "XX":
                queryMap << [stat : 2]
                break;
            case "WG":
                queryMap << [stat : 2]
                break;
            defualt:
                throw new Exception("marshallData._id = ${marshallData._id}, patentType error")
                break;
        }
        
        return queryMap
    }
    
    static main(args) {
        
        // def year = "2015"
        def period = "20160309"
        
        // "FM", "SD", "XX", "WG"
        ["WG"].each { patentType ->
            
            def argMap = [:]
            
            argMap << ['patentType' : patentType]
            
            new CnInfoDataImporter().processInfoData(argMap, period);
            
        }
        
        // CN303429845S / CN303429939S
//        def queryMap = [patentNumber: "CN303429939S"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for FM test pct data CN104937930A
        // for FM ipcr data have [\n]
//        def queryMap = [openNumber: "CN105027243A"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for SD test CN102611705B
//        def queryMap = [decisionNumber: "CN102611705B"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for XX test data
//        def queryMap = [decisionNumber: "CN204667289U"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for WG test data / CN303380514S / CN303380733S
//        def queryMap = [decisionNumber: "CN303380514S"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        //  for WG agents = null test / CN303380516S / CN303381713S
//        def queryMap = [decisionNumber: "CN303381713S"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // test for priorityPatents CN104929793A
//        def queryMap = [patentNumber: "CN104929793A"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // test for citedPatents && otherReferences \ CN102551747B \ CN103977133B
//        def queryMap = [patentNumber: "CN103977133B"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
//        def queryMap = [_id: new ObjectId("56c092375eee26d85e25fb5d")]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        println "finished..."
        
    }

}
