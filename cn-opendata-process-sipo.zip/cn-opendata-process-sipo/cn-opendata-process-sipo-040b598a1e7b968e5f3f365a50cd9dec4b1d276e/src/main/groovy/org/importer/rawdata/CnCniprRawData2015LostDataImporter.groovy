package org.importer.rawdata

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.utils.ProcessEstimater;
import org.utils.DateUtil
import org.utils.MongoUtil

class CnCniprRawData2015LostDataImporter {

    static Logger log = LoggerFactory.getLogger(CnCniprRawData2015LostDataImporter.class);

    private File bookpath;

    private ProcessEstimater pe;

    private static String provider;

    public CnCniprRawData2015LostDataImporter() {}
    
    private File fileLog = new File("logs/CnCniprRawData2015LostDataImporter_20151204.log")
    
    private def ln = System.getProperty('line.separator')
    
    /**
     *
     * @param bookpath
     * @throws UnknownHostException
     */
    public CnCniprRawData2015LostDataImporter(String bookpath) throws UnknownHostException {
        //
        this.bookpath = new File(bookpath);
        pe = new ProcessEstimater(0).setFormat("%2\$d");
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    void worker(def args, def period) throws Exception {

        String argPath = args.argPath
        String argDoPath = args.argDoPath

        if (argDoPath.contains("/WG/")) {
            provider = "CNIPR1";
        } else {
            provider = "CNIPR2";
        }

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + args);
        }

        // TODO: connect to mongodb => 10.60.90.101
        def client = MongoUtil.connect3X('yyj', 'yyj', "10.60.90.127", 27017, 'admin')
        def patentRawCNIPR = client.getDB("PatentRawCNIPR")

        new CnCniprRawData2015LostDataImporter(argPath).importDir(new File(argDoPath), patentRawCNIPR, period);

        log.debug("finish");
    }

    /**
     * 處理指定目錄 ???
     *
     * ref: Another builder pattern for
     * Java[http://blog.crisp.se/2013/10/09
     * /perlundholm/another-builder-pattern-for-java]
     *
     * @param dir
     * @return
     * @throws IOException
     */
    public CnCniprRawData2015LostDataImporter importDir(File dir, def dbClient, def period) throws IOException {

        if (dir.isDirectory()) {

            // find 該目錄內是否有書目資料
            File fileBiblio = dir.toPath().resolve("bibliography.html")
                    .toFile();

            if (fileBiblio.isFile()) {

                File fileClaim = dir.toPath().resolve("claim.xml").toFile();
                File fileDesc = dir.toPath().resolve("description.xml")
                        .toFile();

                // TODO: 要在調整path. 20150710
                String path = bookpath.toPath().relativize(dir.toPath())
                        .toString().replaceAll("\\\\", "/");

                Date doDate = DateUtil.parseDate(period);

                if (doDate == null) {
                    // process special case
                    while (true) {
                        //
                        Matcher mat;
                        mat = Pattern.compile("(?i)^SD/1992/19921230Z/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtil.parseDate("19921230");
                            break;
                        }

                        mat = Pattern.compile("(?i)^WG/(\\d{4})/\\d{4}/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtil.parseDate(mat.group(1) + "0101");
                            break;
                        }

                        break;
                    }
                }

                def rawData = [:]

                def findData = dbClient.PatentRawCNIPR.findOne([path: path])

                if (!!findData) {
                    rawData = setRawData(doDate, path, fileBiblio, fileClaim, fileDesc, findData)
                } else {
                    rawData = setRawData(doDate, path, fileBiblio, fileClaim, fileDesc, null)
                }

                log.debug("doDate = " + doDate);
                fileLog << "doDate = ${doDate}, path = ${path}" << ln
                // println "rawData = ${rawData}"
                
                dbClient.PatentRawCNIPR.save(rawData)

                pe.addNum().debug(log, 10000, "save: '" + path + "'");

            } else {

                // 真正處理的entry point
                for (File file : dir.listFiles()) {
                    if (file.isDirectory()) {
                        importDir(file, dbClient, period);
                    }
                }

            }
        }

        return this;
    }

    /**
     *
     * @param doDate
     * @param fileBiblio
     * @param fileClaim
     * @param fileDesc
     * @return
     */
    private setRawData(Date doDate, String path, File fileBiblio, File fileClaim, File fileDesc, def findData) {

        def rawData = [:]

        rawData << ["pto" : "CNIPR"]
        rawData << ["path" : path]
        rawData << ["type" : "html/json-html"]
        rawData << ["provider" : provider]
        rawData << ["doDate" : doDate]
        
        // TODO: only for 補資料而用, 補完後一定要記得unset...
        rawData << ["redmine" : 99999]

        def dataMap = [:]

        if (fileBiblio.isFile()) {
            dataMap << ["bibliography" : FileUtils.readFileToString(fileBiblio, "UTF-8")]
        }

        if (fileClaim.isFile()) {
            dataMap << ["claim" : FileUtils.readFileToString(fileClaim, "UTF-8")]
        }

        if (fileDesc.isFile()) {
            dataMap << ["description" : FileUtils.readFileToString(fileDesc, "UTF-8")]
        }

        rawData << [data: dataMap]

        if (!!findData) {
            rawData << ["_id" : findData._id]
        }

        return rawData
    }
    
    /**
     * 
     * @param args
     */
    static main(args) {
        
        //
        CnCniprRawData2015LostDataImporter importer = new CnCniprRawData2015LostDataImporter()
        
        def argMap = [:]
        
        argMap << ['lostDataPath' : ""]
        argMap << ['argPath' : "D:/cnlist/rawdata/2015_lost_data"]
        
        // "FM", "SD", "XX", "WG"
        ["SD"].each { type -> 
            
            new File(argMap.argPath + "/" + type + "/2015").eachFile { file -> 
                
                if (file.isDirectory()) {
                    
                    println file.path
                    argMap << ['argDoPath' : file.path]
                    
                    def doDate = file.path.split("\\\\")[-1]
                    
                    if (type == "WG") {
                        switch (doDate) {
                            case "3101":
                                doDate = "20150107"
                                break
                            case "3102":
                                doDate = "20150114"
                                break
                            case "3103":
                                doDate = "20150121"
                                break
                            case "3104":    
                                doDate = "20150128"
                                break
                            case "3105":
                                doDate = "20150204"
                            case "3106":
                                doDate = "20150211"
                                break
                            case "3107":
                                doDate = "20150218"
                                break
                            case "3108":
                                doDate = "20150225"
                                break
                            case "3109":
                                doDate = "20150304"
                                break
                            case "3110":
                                doDate = "20150311"
                                break
                            case "3111":
                                doDate = "20150318"
                                break
                        }
                    }  // end if (type == "WG")
                    
                    println "doDate = ${doDate}"
                    
                    importer.worker(argMap, doDate);
                    
                }
                
            }
            
        }
        
    }

}
