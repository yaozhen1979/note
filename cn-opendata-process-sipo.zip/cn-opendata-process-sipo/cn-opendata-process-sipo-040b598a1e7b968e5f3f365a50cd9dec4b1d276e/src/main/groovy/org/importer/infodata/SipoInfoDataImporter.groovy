package org.importer.infodata

class SipoInfoDataImporter {

    static main(args) {
        // TODO
    }

}
