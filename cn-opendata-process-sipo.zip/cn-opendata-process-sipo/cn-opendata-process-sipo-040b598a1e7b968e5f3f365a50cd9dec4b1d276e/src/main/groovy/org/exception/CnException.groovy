package org.exception

import java.util.Properties;
import org.utils.PropertiesUtil;
import org.utils.MailUtil

/**
 * TODO: good exception pattern ???
 * 
 * @author tonykuo
 *
 */
class CnException extends Exception {
    
    private Properties propertyUtil = PropertiesUtil.load("src/main/resources/config.properties");
    private String mailTitle = "CN Open Data Exception Error"
    private String userMail = propertyUtil.getProperty("user_mail");
    
    public CnException(){
        super();
    }
    
    public CnException(String message){
        super(message);
        MailUtil.sendToPatentCloud(userMail, mailTitle, message)
    }
    
    public CnException(String message, Throwable cause){
        super(message, cause);
        MailUtil.sendToPatentCloud(userMail, mailTitle, message)
    }
    
    public CnException(Throwable cause){
        super(cause);
        MailUtil.sendToPatentCloud(userMail, mailTitle, cause)
    }
    
}
