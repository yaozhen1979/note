//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>classification-ipcr complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="classification-ipcr"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}ipc-version-indicator"/&gt;
 *           &lt;element ref="{}classification-level" minOccurs="0"/&gt;
 *           &lt;element ref="{}section"/&gt;
 *           &lt;element ref="{}class"/&gt;
 *           &lt;element ref="{}subclass"/&gt;
 *           &lt;element ref="{}main-group" minOccurs="0"/&gt;
 *           &lt;element ref="{}subgroup" minOccurs="0"/&gt;
 *           &lt;element ref="{}symbol-position" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-value" minOccurs="0"/&gt;
 *           &lt;element ref="{}action-date" minOccurs="0"/&gt;
 *           &lt;element ref="{}generating-office" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-status" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-data-source" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{}text"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="sequence" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classification-ipcr", propOrder = {
    "ipcVersionIndicator",
    "classificationLevel",
    "section",
    "clazz",
    "subclass",
    "mainGroup",
    "subgroup",
    "symbolPosition",
    "classificationValue",
    "actionDate",
    "generatingOffice",
    "classificationStatus",
    "classificationDataSource",
    "text"
})
public class ClassificationIpcr {

    @XmlElement(name = "ipc-version-indicator")
    protected IpcVersionIndicator ipcVersionIndicator;
    @XmlElement(name = "classification-level")
    protected ClassificationLevel classificationLevel;
    protected Section section;
    @XmlElement(name = "class")
    protected Class clazz;
    protected Subclass subclass;
    @XmlElement(name = "main-group")
    protected MainGroup mainGroup;
    protected Subgroup subgroup;
    @XmlElement(name = "symbol-position")
    protected SymbolPosition symbolPosition;
    @XmlElement(name = "classification-value")
    protected ClassificationValue classificationValue;
    @XmlElement(name = "action-date")
    protected ActionDate actionDate;
    @XmlElement(name = "generating-office")
    protected GeneratingOffice generatingOffice;
    @XmlElement(name = "classification-status")
    protected ClassificationStatus classificationStatus;
    @XmlElement(name = "classification-data-source")
    protected ClassificationDataSource classificationDataSource;
    protected Text text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "sequence")
    @XmlSchemaType(name = "anySimpleType")
    protected String sequence;

    /**
     * 取得 ipcVersionIndicator 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link IpcVersionIndicator }
     *     
     */
    public IpcVersionIndicator getIpcVersionIndicator() {
        return ipcVersionIndicator;
    }

    /**
     * 設定 ipcVersionIndicator 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link IpcVersionIndicator }
     *     
     */
    public void setIpcVersionIndicator(IpcVersionIndicator value) {
        this.ipcVersionIndicator = value;
    }

    /**
     * 取得 classificationLevel 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationLevel }
     *     
     */
    public ClassificationLevel getClassificationLevel() {
        return classificationLevel;
    }

    /**
     * 設定 classificationLevel 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationLevel }
     *     
     */
    public void setClassificationLevel(ClassificationLevel value) {
        this.classificationLevel = value;
    }

    /**
     * 取得 section 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Section }
     *     
     */
    public Section getSection() {
        return section;
    }

    /**
     * 設定 section 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Section }
     *     
     */
    public void setSection(Section value) {
        this.section = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Class }
     *     
     */
    public Class getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Class }
     *     
     */
    public void setClazz(Class value) {
        this.clazz = value;
    }

    /**
     * 取得 subclass 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Subclass }
     *     
     */
    public Subclass getSubclass() {
        return subclass;
    }

    /**
     * 設定 subclass 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Subclass }
     *     
     */
    public void setSubclass(Subclass value) {
        this.subclass = value;
    }

    /**
     * 取得 mainGroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainGroup }
     *     
     */
    public MainGroup getMainGroup() {
        return mainGroup;
    }

    /**
     * 設定 mainGroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainGroup }
     *     
     */
    public void setMainGroup(MainGroup value) {
        this.mainGroup = value;
    }

    /**
     * 取得 subgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Subgroup }
     *     
     */
    public Subgroup getSubgroup() {
        return subgroup;
    }

    /**
     * 設定 subgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Subgroup }
     *     
     */
    public void setSubgroup(Subgroup value) {
        this.subgroup = value;
    }

    /**
     * 取得 symbolPosition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SymbolPosition }
     *     
     */
    public SymbolPosition getSymbolPosition() {
        return symbolPosition;
    }

    /**
     * 設定 symbolPosition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SymbolPosition }
     *     
     */
    public void setSymbolPosition(SymbolPosition value) {
        this.symbolPosition = value;
    }

    /**
     * 取得 classificationValue 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationValue }
     *     
     */
    public ClassificationValue getClassificationValue() {
        return classificationValue;
    }

    /**
     * 設定 classificationValue 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationValue }
     *     
     */
    public void setClassificationValue(ClassificationValue value) {
        this.classificationValue = value;
    }

    /**
     * 取得 actionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ActionDate }
     *     
     */
    public ActionDate getActionDate() {
        return actionDate;
    }

    /**
     * 設定 actionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionDate }
     *     
     */
    public void setActionDate(ActionDate value) {
        this.actionDate = value;
    }

    /**
     * 取得 generatingOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link GeneratingOffice }
     *     
     */
    public GeneratingOffice getGeneratingOffice() {
        return generatingOffice;
    }

    /**
     * 設定 generatingOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link GeneratingOffice }
     *     
     */
    public void setGeneratingOffice(GeneratingOffice value) {
        this.generatingOffice = value;
    }

    /**
     * 取得 classificationStatus 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationStatus }
     *     
     */
    public ClassificationStatus getClassificationStatus() {
        return classificationStatus;
    }

    /**
     * 設定 classificationStatus 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationStatus }
     *     
     */
    public void setClassificationStatus(ClassificationStatus value) {
        this.classificationStatus = value;
    }

    /**
     * 取得 classificationDataSource 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationDataSource }
     *     
     */
    public ClassificationDataSource getClassificationDataSource() {
        return classificationDataSource;
    }

    /**
     * 設定 classificationDataSource 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationDataSource }
     *     
     */
    public void setClassificationDataSource(ClassificationDataSource value) {
        this.classificationDataSource = value;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

}
