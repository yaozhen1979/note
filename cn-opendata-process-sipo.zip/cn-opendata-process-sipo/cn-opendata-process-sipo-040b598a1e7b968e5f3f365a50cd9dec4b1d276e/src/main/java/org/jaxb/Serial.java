//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>serial complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="serial"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}sertitle"/&gt;
 *         &lt;element ref="{}alttitle" minOccurs="0"/&gt;
 *         &lt;element ref="{}subname" minOccurs="0"/&gt;
 *         &lt;element ref="{}issue" minOccurs="0"/&gt;
 *         &lt;element ref="{}imprint" minOccurs="0"/&gt;
 *         &lt;element ref="{}pubdate" minOccurs="0"/&gt;
 *         &lt;element ref="{}descrip" minOccurs="0"/&gt;
 *         &lt;element ref="{}notes" minOccurs="0"/&gt;
 *         &lt;element ref="{}issn" minOccurs="0"/&gt;
 *         &lt;element ref="{}isbn" minOccurs="0"/&gt;
 *         &lt;element ref="{}pubid" minOccurs="0"/&gt;
 *         &lt;element ref="{}vid" minOccurs="0"/&gt;
 *         &lt;element ref="{}ino" minOccurs="0"/&gt;
 *         &lt;element ref="{}cpyrt" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "serial", propOrder = {
    "sertitle",
    "alttitle",
    "subname",
    "issue",
    "imprint",
    "pubdate",
    "descrip",
    "notes",
    "issn",
    "isbn",
    "pubid",
    "vid",
    "ino",
    "cpyrt"
})
public class Serial {

    @XmlElement(required = true)
    protected Sertitle sertitle;
    protected Alttitle alttitle;
    protected Subname subname;
    protected Issue issue;
    protected Imprint imprint;
    protected Pubdate pubdate;
    protected Descrip descrip;
    protected Notes notes;
    protected Issn issn;
    protected Isbn isbn;
    protected Pubid pubid;
    protected Vid vid;
    protected Ino ino;
    protected Cpyrt cpyrt;

    /**
     * 取得 sertitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Sertitle }
     *     
     */
    public Sertitle getSertitle() {
        return sertitle;
    }

    /**
     * 設定 sertitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Sertitle }
     *     
     */
    public void setSertitle(Sertitle value) {
        this.sertitle = value;
    }

    /**
     * 取得 alttitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Alttitle }
     *     
     */
    public Alttitle getAlttitle() {
        return alttitle;
    }

    /**
     * 設定 alttitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Alttitle }
     *     
     */
    public void setAlttitle(Alttitle value) {
        this.alttitle = value;
    }

    /**
     * 取得 subname 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Subname }
     *     
     */
    public Subname getSubname() {
        return subname;
    }

    /**
     * 設定 subname 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Subname }
     *     
     */
    public void setSubname(Subname value) {
        this.subname = value;
    }

    /**
     * 取得 issue 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Issue }
     *     
     */
    public Issue getIssue() {
        return issue;
    }

    /**
     * 設定 issue 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Issue }
     *     
     */
    public void setIssue(Issue value) {
        this.issue = value;
    }

    /**
     * 取得 imprint 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Imprint }
     *     
     */
    public Imprint getImprint() {
        return imprint;
    }

    /**
     * 設定 imprint 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Imprint }
     *     
     */
    public void setImprint(Imprint value) {
        this.imprint = value;
    }

    /**
     * 取得 pubdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pubdate }
     *     
     */
    public Pubdate getPubdate() {
        return pubdate;
    }

    /**
     * 設定 pubdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pubdate }
     *     
     */
    public void setPubdate(Pubdate value) {
        this.pubdate = value;
    }

    /**
     * 取得 descrip 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Descrip }
     *     
     */
    public Descrip getDescrip() {
        return descrip;
    }

    /**
     * 設定 descrip 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Descrip }
     *     
     */
    public void setDescrip(Descrip value) {
        this.descrip = value;
    }

    /**
     * 取得 notes 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Notes }
     *     
     */
    public Notes getNotes() {
        return notes;
    }

    /**
     * 設定 notes 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Notes }
     *     
     */
    public void setNotes(Notes value) {
        this.notes = value;
    }

    /**
     * 取得 issn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Issn }
     *     
     */
    public Issn getIssn() {
        return issn;
    }

    /**
     * 設定 issn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Issn }
     *     
     */
    public void setIssn(Issn value) {
        this.issn = value;
    }

    /**
     * 取得 isbn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Isbn }
     *     
     */
    public Isbn getIsbn() {
        return isbn;
    }

    /**
     * 設定 isbn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Isbn }
     *     
     */
    public void setIsbn(Isbn value) {
        this.isbn = value;
    }

    /**
     * 取得 pubid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pubid }
     *     
     */
    public Pubid getPubid() {
        return pubid;
    }

    /**
     * 設定 pubid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pubid }
     *     
     */
    public void setPubid(Pubid value) {
        this.pubid = value;
    }

    /**
     * 取得 vid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Vid }
     *     
     */
    public Vid getVid() {
        return vid;
    }

    /**
     * 設定 vid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Vid }
     *     
     */
    public void setVid(Vid value) {
        this.vid = value;
    }

    /**
     * 取得 ino 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Ino }
     *     
     */
    public Ino getIno() {
        return ino;
    }

    /**
     * 設定 ino 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Ino }
     *     
     */
    public void setIno(Ino value) {
        this.ino = value;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Cpyrt }
     *     
     */
    public Cpyrt getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Cpyrt }
     *     
     */
    public void setCpyrt(Cpyrt value) {
        this.cpyrt = value;
    }

}
