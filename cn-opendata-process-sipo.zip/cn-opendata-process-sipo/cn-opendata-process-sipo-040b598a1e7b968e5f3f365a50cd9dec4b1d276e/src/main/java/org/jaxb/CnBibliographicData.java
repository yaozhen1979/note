//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>cn-bibliographic-data complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="cn-bibliographic-data"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}cn-publication-reference"/&gt;
 *         &lt;element ref="{}correction" minOccurs="0"/&gt;
 *         &lt;element ref="{}application-reference"/&gt;
 *         &lt;element ref="{}priority-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-ipc" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-ipcr" minOccurs="0"/&gt;
 *         &lt;element ref="{}invention-title" maxOccurs="unbounded"/&gt;
 *         &lt;element ref="{}assignees" minOccurs="0"/&gt;
 *         &lt;element ref="{}references-cited" minOccurs="0"/&gt;
 *         &lt;element ref="{}abstract" minOccurs="0"/&gt;
 *         &lt;element ref="{}figures" minOccurs="0"/&gt;
 *         &lt;element ref="{}cn-abstract-drawing" minOccurs="0"/&gt;
 *         &lt;element ref="{}cn-related-publication"/&gt;
 *         &lt;element ref="{}cn-related-documents"/&gt;
 *         &lt;element ref="{}cn-parties"/&gt;
 *         &lt;element ref="{}date-pct-article-22-39-fulfilled" minOccurs="0"/&gt;
 *         &lt;element ref="{}pct-or-regional-filing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}pct-or-regional-publishing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}text" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="country" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cn-bibliographic-data", propOrder = {
    "cnPublicationReference",
    "correction",
    "applicationReference",
    "priorityClaims",
    "classificationIpc",
    "classificationsIpcr",
    "inventionTitle",
    "assignees",
    "referencesCited",
    "_abstract",
    "figures",
    "cnAbstractDrawing",
    "cnRelatedPublication",
    "cnRelatedDocuments",
    "cnParties",
    "datePctArticle2239Fulfilled",
    "pctOrRegionalFilingData",
    "pctOrRegionalPublishingData",
    "text"
})
public class CnBibliographicData {

    @XmlElement(name = "cn-publication-reference", required = true)
    protected CnPublicationReference cnPublicationReference;
    protected Correction correction;
    @XmlElement(name = "application-reference", required = true)
    protected ApplicationReference applicationReference;
    @XmlElement(name = "priority-claims")
    protected PriorityClaims priorityClaims;
    @XmlElement(name = "classification-ipc")
    protected ClassificationIpc classificationIpc;
    @XmlElement(name = "classifications-ipcr")
    protected ClassificationsIpcr classificationsIpcr;
    @XmlElement(name = "invention-title", required = true)
    protected List<InventionTitle> inventionTitle;
    protected Assignees assignees;
    @XmlElement(name = "references-cited")
    protected ReferencesCited referencesCited;
    @XmlElement(name = "abstract")
    protected Abstract _abstract;
    protected Figures figures;
    @XmlElement(name = "cn-abstract-drawing")
    protected CnAbstractDrawing cnAbstractDrawing;
    @XmlElement(name = "cn-related-publication", required = true)
    protected CnRelatedPublication cnRelatedPublication;
    @XmlElement(name = "cn-related-documents", required = true)
    protected CnRelatedDocuments cnRelatedDocuments;
    @XmlElement(name = "cn-parties", required = true)
    protected CnParties cnParties;
    @XmlElement(name = "date-pct-article-22-39-fulfilled")
    protected DatePctArticle2239Fulfilled datePctArticle2239Fulfilled;
    @XmlElement(name = "pct-or-regional-filing-data")
    protected PctOrRegionalFilingData pctOrRegionalFilingData;
    @XmlElement(name = "pct-or-regional-publishing-data")
    protected PctOrRegionalPublishingData pctOrRegionalPublishingData;
    protected List<Text> text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    @XmlSchemaType(name = "anySimpleType")
    protected String lang;
    @XmlAttribute(name = "country")
    @XmlSchemaType(name = "anySimpleType")
    protected String country;
    @XmlAttribute(name = "status")
    @XmlSchemaType(name = "anySimpleType")
    protected String status;

    /**
     * 取得 cnPublicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnPublicationReference }
     *     
     */
    public CnPublicationReference getCnPublicationReference() {
        return cnPublicationReference;
    }

    /**
     * 設定 cnPublicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnPublicationReference }
     *     
     */
    public void setCnPublicationReference(CnPublicationReference value) {
        this.cnPublicationReference = value;
    }

    /**
     * 取得 correction 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Correction }
     *     
     */
    public Correction getCorrection() {
        return correction;
    }

    /**
     * 設定 correction 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Correction }
     *     
     */
    public void setCorrection(Correction value) {
        this.correction = value;
    }

    /**
     * 取得 applicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationReference }
     *     
     */
    public ApplicationReference getApplicationReference() {
        return applicationReference;
    }

    /**
     * 設定 applicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationReference }
     *     
     */
    public void setApplicationReference(ApplicationReference value) {
        this.applicationReference = value;
    }

    /**
     * 取得 priorityClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PriorityClaims }
     *     
     */
    public PriorityClaims getPriorityClaims() {
        return priorityClaims;
    }

    /**
     * 設定 priorityClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityClaims }
     *     
     */
    public void setPriorityClaims(PriorityClaims value) {
        this.priorityClaims = value;
    }

    /**
     * 取得 classificationIpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpc }
     *     
     */
    public ClassificationIpc getClassificationIpc() {
        return classificationIpc;
    }

    /**
     * 設定 classificationIpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpc }
     *     
     */
    public void setClassificationIpc(ClassificationIpc value) {
        this.classificationIpc = value;
    }

    /**
     * 取得 classificationsIpcr 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public ClassificationsIpcr getClassificationsIpcr() {
        return classificationsIpcr;
    }

    /**
     * 設定 classificationsIpcr 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public void setClassificationsIpcr(ClassificationsIpcr value) {
        this.classificationsIpcr = value;
    }

    /**
     * Gets the value of the inventionTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inventionTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInventionTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InventionTitle }
     * 
     * 
     */
    public List<InventionTitle> getInventionTitle() {
        if (inventionTitle == null) {
            inventionTitle = new ArrayList<InventionTitle>();
        }
        return this.inventionTitle;
    }

    /**
     * 取得 assignees 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Assignees }
     *     
     */
    public Assignees getAssignees() {
        return assignees;
    }

    /**
     * 設定 assignees 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Assignees }
     *     
     */
    public void setAssignees(Assignees value) {
        this.assignees = value;
    }

    /**
     * 取得 referencesCited 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ReferencesCited }
     *     
     */
    public ReferencesCited getReferencesCited() {
        return referencesCited;
    }

    /**
     * 設定 referencesCited 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ReferencesCited }
     *     
     */
    public void setReferencesCited(ReferencesCited value) {
        this.referencesCited = value;
    }

    /**
     * 取得 abstract 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Abstract }
     *     
     */
    public Abstract getAbstract() {
        return _abstract;
    }

    /**
     * 設定 abstract 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Abstract }
     *     
     */
    public void setAbstract(Abstract value) {
        this._abstract = value;
    }

    /**
     * 取得 figures 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Figures }
     *     
     */
    public Figures getFigures() {
        return figures;
    }

    /**
     * 設定 figures 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Figures }
     *     
     */
    public void setFigures(Figures value) {
        this.figures = value;
    }

    /**
     * 取得 cnAbstractDrawing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnAbstractDrawing }
     *     
     */
    public CnAbstractDrawing getCnAbstractDrawing() {
        return cnAbstractDrawing;
    }

    /**
     * 設定 cnAbstractDrawing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnAbstractDrawing }
     *     
     */
    public void setCnAbstractDrawing(CnAbstractDrawing value) {
        this.cnAbstractDrawing = value;
    }

    /**
     * 取得 cnRelatedPublication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnRelatedPublication }
     *     
     */
    public CnRelatedPublication getCnRelatedPublication() {
        return cnRelatedPublication;
    }

    /**
     * 設定 cnRelatedPublication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnRelatedPublication }
     *     
     */
    public void setCnRelatedPublication(CnRelatedPublication value) {
        this.cnRelatedPublication = value;
    }

    /**
     * 取得 cnRelatedDocuments 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnRelatedDocuments }
     *     
     */
    public CnRelatedDocuments getCnRelatedDocuments() {
        return cnRelatedDocuments;
    }

    /**
     * 設定 cnRelatedDocuments 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnRelatedDocuments }
     *     
     */
    public void setCnRelatedDocuments(CnRelatedDocuments value) {
        this.cnRelatedDocuments = value;
    }

    /**
     * 取得 cnParties 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnParties }
     *     
     */
    public CnParties getCnParties() {
        return cnParties;
    }

    /**
     * 設定 cnParties 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnParties }
     *     
     */
    public void setCnParties(CnParties value) {
        this.cnParties = value;
    }

    /**
     * 取得 datePctArticle2239Fulfilled 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatePctArticle2239Fulfilled }
     *     
     */
    public DatePctArticle2239Fulfilled getDatePctArticle2239Fulfilled() {
        return datePctArticle2239Fulfilled;
    }

    /**
     * 設定 datePctArticle2239Fulfilled 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePctArticle2239Fulfilled }
     *     
     */
    public void setDatePctArticle2239Fulfilled(DatePctArticle2239Fulfilled value) {
        this.datePctArticle2239Fulfilled = value;
    }

    /**
     * 取得 pctOrRegionalFilingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public PctOrRegionalFilingData getPctOrRegionalFilingData() {
        return pctOrRegionalFilingData;
    }

    /**
     * 設定 pctOrRegionalFilingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public void setPctOrRegionalFilingData(PctOrRegionalFilingData value) {
        this.pctOrRegionalFilingData = value;
    }

    /**
     * 取得 pctOrRegionalPublishingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public PctOrRegionalPublishingData getPctOrRegionalPublishingData() {
        return pctOrRegionalPublishingData;
    }

    /**
     * 設定 pctOrRegionalPublishingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public void setPctOrRegionalPublishingData(PctOrRegionalPublishingData value) {
        this.pctOrRegionalPublishingData = value;
    }

    /**
     * Gets the value of the text property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the text property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getText().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Text }
     * 
     * 
     */
    public List<Text> getText() {
        if (text == null) {
            text = new ArrayList<Text>();
        }
        return this.text;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
