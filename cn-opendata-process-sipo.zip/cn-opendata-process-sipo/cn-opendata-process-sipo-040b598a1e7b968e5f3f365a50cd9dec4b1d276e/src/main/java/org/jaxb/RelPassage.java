//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>rel-passage complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="rel-passage"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence maxOccurs="unbounded"&gt;
 *           &lt;element ref="{}passage" maxOccurs="unbounded"/&gt;
 *           &lt;element ref="{}category" minOccurs="0"/&gt;
 *           &lt;element ref="{}rel-claims" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rel-passage", propOrder = {
    "text",
    "passageAndCategoryAndRelClaims"
})
public class RelPassage {

    protected Text text;
    @XmlElements({
        @XmlElement(name = "passage", type = Passage.class),
        @XmlElement(name = "category", type = Category.class),
        @XmlElement(name = "rel-claims", type = RelClaims.class)
    })
    protected List<Object> passageAndCategoryAndRelClaims;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * Gets the value of the passageAndCategoryAndRelClaims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the passageAndCategoryAndRelClaims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPassageAndCategoryAndRelClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Passage }
     * {@link Category }
     * {@link RelClaims }
     * 
     * 
     */
    public List<Object> getPassageAndCategoryAndRelClaims() {
        if (passageAndCategoryAndRelClaims == null) {
            passageAndCategoryAndRelClaims = new ArrayList<Object>();
        }
        return this.passageAndCategoryAndRelClaims;
    }

}
