//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.jaxb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Title_QNAME = new QName("", "title");
    private final static QName _Math_QNAME = new QName("", "math");
    private final static QName _CnPatentDocument_QNAME = new QName("", "cn-patent-document");
    private final static QName _CnBibliographicData_QNAME = new QName("", "cn-bibliographic-data");
    private final static QName _SequenceListDoc_QNAME = new QName("", "sequence-list-doc");
    private final static QName _SequenceList_QNAME = new QName("", "sequence-list");
    private final static QName _CnPublicationReference_QNAME = new QName("", "cn-publication-reference");
    private final static QName _ApplicationReference_QNAME = new QName("", "application-reference");
    private final static QName _Correction_QNAME = new QName("", "correction");
    private final static QName _PriorityClaims_QNAME = new QName("", "priority-claims");
    private final static QName _PriorityClaim_QNAME = new QName("", "priority-claim");
    private final static QName _ClassificationIpc_QNAME = new QName("", "classification-ipc");
    private final static QName _ClassificationsIpcr_QNAME = new QName("", "classifications-ipcr");
    private final static QName _ClassificationIpcr_QNAME = new QName("", "classification-ipcr");
    private final static QName _InventionTitle_QNAME = new QName("", "invention-title");
    private final static QName _ReferencesCited_QNAME = new QName("", "references-cited");
    private final static QName _Citation_QNAME = new QName("", "citation");
    private final static QName _Division_QNAME = new QName("", "division");
    private final static QName _CnRelatedPublication_QNAME = new QName("", "cn-related-publication");
    private final static QName _CnParties_QNAME = new QName("", "cn-parties");
    private final static QName _DatePctArticle2239Fulfilled_QNAME = new QName("", "date-pct-article-22-39-fulfilled");
    private final static QName _PctOrRegionalFilingData_QNAME = new QName("", "pct-or-regional-filing-data");
    private final static QName _Us371C124Date_QNAME = new QName("", "us-371c124-date");
    private final static QName _PctOrRegionalPublishingData_QNAME = new QName("", "pct-or-regional-publishing-data");
    private final static QName _Figures_QNAME = new QName("", "figures");
    private final static QName _FigureToPublish_QNAME = new QName("", "figure-to-publish");
    private final static QName _FigNumber_QNAME = new QName("", "fig-number");
    private final static QName _NumberOfFigures_QNAME = new QName("", "number-of-figures");
    private final static QName _NumberOfDrawingSheets_QNAME = new QName("", "number-of-drawing-sheets");
    private final static QName _TypeOfCorrection_QNAME = new QName("", "type-of-correction");
    private final static QName _DocumentCorrected_QNAME = new QName("", "document-corrected");
    private final static QName _GazetteReference_QNAME = new QName("", "gazette-reference");
    private final static QName _GazetteNum_QNAME = new QName("", "gazette-num");
    private final static QName _Serial_QNAME = new QName("", "serial");
    private final static QName _Sertitle_QNAME = new QName("", "sertitle");
    private final static QName _Alttitle_QNAME = new QName("", "alttitle");
    private final static QName _Subname_QNAME = new QName("", "subname");
    private final static QName _Name_QNAME = new QName("", "name");
    private final static QName _Prefix_QNAME = new QName("", "prefix");
    private final static QName _LastName_QNAME = new QName("", "last-name");
    private final static QName _Orgname_QNAME = new QName("", "orgname");
    private final static QName _FirstName_QNAME = new QName("", "first-name");
    private final static QName _MiddleName_QNAME = new QName("", "middle-name");
    private final static QName _Suffix_QNAME = new QName("", "suffix");
    private final static QName _Iid_QNAME = new QName("", "iid");
    private final static QName _Role_QNAME = new QName("", "role");
    private final static QName _Department_QNAME = new QName("", "department");
    private final static QName _Synonym_QNAME = new QName("", "synonym");
    private final static QName _RegisteredNumber_QNAME = new QName("", "registered-number");
    private final static QName _Addressbook_QNAME = new QName("", "addressbook");
    private final static QName _Address_QNAME = new QName("", "address");
    private final static QName _Address1_QNAME = new QName("", "address-1");
    private final static QName _Address2_QNAME = new QName("", "address-2");
    private final static QName _Address3_QNAME = new QName("", "address-3");
    private final static QName _Mailcode_QNAME = new QName("", "mailcode");
    private final static QName _Pobox_QNAME = new QName("", "pobox");
    private final static QName _Room_QNAME = new QName("", "room");
    private final static QName _AddressFloor_QNAME = new QName("", "address-floor");
    private final static QName _Building_QNAME = new QName("", "building");
    private final static QName _Street_QNAME = new QName("", "street");
    private final static QName _City_QNAME = new QName("", "city");
    private final static QName _County_QNAME = new QName("", "county");
    private final static QName _State_QNAME = new QName("", "state");
    private final static QName _Postcode_QNAME = new QName("", "postcode");
    private final static QName _Country_QNAME = new QName("", "country");
    private final static QName _Text_QNAME = new QName("", "text");
    private final static QName _Phone_QNAME = new QName("", "phone");
    private final static QName _Fax_QNAME = new QName("", "fax");
    private final static QName _Email_QNAME = new QName("", "email");
    private final static QName _Url_QNAME = new QName("", "url");
    private final static QName _Ead_QNAME = new QName("", "ead");
    private final static QName _Dtext_QNAME = new QName("", "dtext");
    private final static QName _Issue_QNAME = new QName("", "issue");
    private final static QName _Imprint_QNAME = new QName("", "imprint");
    private final static QName _Pubdate_QNAME = new QName("", "pubdate");
    private final static QName _Sdate_QNAME = new QName("", "sdate");
    private final static QName _Edate_QNAME = new QName("", "edate");
    private final static QName _Time_QNAME = new QName("", "time");
    private final static QName _Descrip_QNAME = new QName("", "descrip");
    private final static QName _Notes_QNAME = new QName("", "notes");
    private final static QName _Issn_QNAME = new QName("", "issn");
    private final static QName _Isbn_QNAME = new QName("", "isbn");
    private final static QName _Pubid_QNAME = new QName("", "pubid");
    private final static QName _Vid_QNAME = new QName("", "vid");
    private final static QName _Ino_QNAME = new QName("", "ino");
    private final static QName _Cpyrt_QNAME = new QName("", "cpyrt");
    private final static QName _DocumentId_QNAME = new QName("", "document-id");
    private final static QName _DocNumber_QNAME = new QName("", "doc-number");
    private final static QName _Kind_QNAME = new QName("", "kind");
    private final static QName _Date_QNAME = new QName("", "date");
    private final static QName _OfficeOfFiling_QNAME = new QName("", "office-of-filing");
    private final static QName _Region_QNAME = new QName("", "region");
    private final static QName _PriorityDocRequested_QNAME = new QName("", "priority-doc-requested");
    private final static QName _PriorityDocAttached_QNAME = new QName("", "priority-doc-attached");
    private final static QName _Class_QNAME = new QName("", "class");
    private final static QName _ClassificationDataSource_QNAME = new QName("", "classification-data-source");
    private final static QName _ClassificationStatus_QNAME = new QName("", "classification-status");
    private final static QName _GeneratingOffice_QNAME = new QName("", "generating-office");
    private final static QName _ActionDate_QNAME = new QName("", "action-date");
    private final static QName _ClassificationValue_QNAME = new QName("", "classification-value");
    private final static QName _SymbolPosition_QNAME = new QName("", "symbol-position");
    private final static QName _Subgroup_QNAME = new QName("", "subgroup");
    private final static QName _MainGroup_QNAME = new QName("", "main-group");
    private final static QName _Subclass_QNAME = new QName("", "subclass");
    private final static QName _Section_QNAME = new QName("", "section");
    private final static QName _ClassificationLevel_QNAME = new QName("", "classification-level");
    private final static QName _IpcVersionIndicator_QNAME = new QName("", "ipc-version-indicator");
    private final static QName _B_QNAME = new QName("", "b");
    private final static QName _I_QNAME = new QName("", "i");
    private final static QName _U_QNAME = new QName("", "u");
    private final static QName _Smallcaps_QNAME = new QName("", "smallcaps");
    private final static QName _Sup_QNAME = new QName("", "sup");
    private final static QName _Sub_QNAME = new QName("", "sub");
    private final static QName _Patcit_QNAME = new QName("", "patcit");
    private final static QName _RelPassage_QNAME = new QName("", "rel-passage");
    private final static QName _Passage_QNAME = new QName("", "passage");
    private final static QName _Category_QNAME = new QName("", "category");
    private final static QName _RelClaims_QNAME = new QName("", "rel-claims");
    private final static QName _Nplcit_QNAME = new QName("", "nplcit");
    private final static QName _Article_QNAME = new QName("", "article");
    private final static QName _Author_QNAME = new QName("", "author");
    private final static QName _Atl_QNAME = new QName("", "atl");
    private final static QName _Book_QNAME = new QName("", "book");
    private final static QName _BookTitle_QNAME = new QName("", "book-title");
    private final static QName _Conference_QNAME = new QName("", "conference");
    private final static QName _Conftitle_QNAME = new QName("", "conftitle");
    private final static QName _Confno_QNAME = new QName("", "confno");
    private final static QName _Confplace_QNAME = new QName("", "confplace");
    private final static QName _Confsponsor_QNAME = new QName("", "confsponsor");
    private final static QName _Subtitle_QNAME = new QName("", "subtitle");
    private final static QName _Edition_QNAME = new QName("", "edition");
    private final static QName _Series_QNAME = new QName("", "series");
    private final static QName _Mst_QNAME = new QName("", "mst");
    private final static QName _Msn_QNAME = new QName("", "msn");
    private final static QName _Absno_QNAME = new QName("", "absno");
    private final static QName _Location_QNAME = new QName("", "location");
    private final static QName _Serpart_QNAME = new QName("", "serpart");
    private final static QName _Sersect_QNAME = new QName("", "sersect");
    private final static QName _Chapter_QNAME = new QName("", "chapter");
    private final static QName _Pp_QNAME = new QName("", "pp");
    private final static QName _Ppf_QNAME = new QName("", "ppf");
    private final static QName _Ppl_QNAME = new QName("", "ppl");
    private final static QName _Column_QNAME = new QName("", "column");
    private final static QName _Colf_QNAME = new QName("", "colf");
    private final static QName _Coll_QNAME = new QName("", "coll");
    private final static QName _Para_QNAME = new QName("", "para");
    private final static QName _Paraf_QNAME = new QName("", "paraf");
    private final static QName _Paral_QNAME = new QName("", "paral");
    private final static QName _Line_QNAME = new QName("", "line");
    private final static QName _Linef_QNAME = new QName("", "linef");
    private final static QName _Linel_QNAME = new QName("", "linel");
    private final static QName _Bookno_QNAME = new QName("", "bookno");
    private final static QName _Keyword_QNAME = new QName("", "keyword");
    private final static QName _Refno_QNAME = new QName("", "refno");
    private final static QName _Artid_QNAME = new QName("", "artid");
    private final static QName _Online_QNAME = new QName("", "online");
    private final static QName _OnlineTitle_QNAME = new QName("", "online-title");
    private final static QName _Hosttitle_QNAME = new QName("", "hosttitle");
    private final static QName _History_QNAME = new QName("", "history");
    private final static QName _Received_QNAME = new QName("", "received");
    private final static QName _Accepted_QNAME = new QName("", "accepted");
    private final static QName _Revised_QNAME = new QName("", "revised");
    private final static QName _Misc_QNAME = new QName("", "misc");
    private final static QName _Hostno_QNAME = new QName("", "hostno");
    private final static QName _Avail_QNAME = new QName("", "avail");
    private final static QName _Datecit_QNAME = new QName("", "datecit");
    private final static QName _Srchterm_QNAME = new QName("", "srchterm");
    private final static QName _Srchdate_QNAME = new QName("", "srchdate");
    private final static QName _Othercit_QNAME = new QName("", "othercit");
    private final static QName _DateSearchCompleted_QNAME = new QName("", "date-search-completed");
    private final static QName _DateSearchReportMailed_QNAME = new QName("", "date-search-report-mailed");
    private final static QName _PlaceOfSearch_QNAME = new QName("", "place-of-search");
    private final static QName _SearchReportPublication_QNAME = new QName("", "search-report-publication");
    private final static QName _Searcher_QNAME = new QName("", "searcher");
    private final static QName _IpcVersion_QNAME = new QName("", "ipc-version");
    private final static QName _MainClassification_QNAME = new QName("", "main-classification");
    private final static QName _FurtherClassification_QNAME = new QName("", "further-classification");
    private final static QName _AdditionalInfo_QNAME = new QName("", "additional-info");
    private final static QName _LinkedIndexingCodeGroup_QNAME = new QName("", "linked-indexing-code-group");
    private final static QName _MainLinkedIndexingCode_QNAME = new QName("", "main-linked-indexing-code");
    private final static QName _SubLinkedIndexingCode_QNAME = new QName("", "sub-linked-indexing-code");
    private final static QName _UnlinkedIndexingCode_QNAME = new QName("", "unlinked-indexing-code");
    private final static QName _CorrespondingDocs_QNAME = new QName("", "corresponding-docs");
    private final static QName _ClassificationNational_QNAME = new QName("", "classification-national");
    private final static QName _Substitution_QNAME = new QName("", "substitution");
    private final static QName _CnDomesticPriorityClaim_QNAME = new QName("", "cn-domestic-priority-claim");
    private final static QName _CnDomesticPriorityClaims_QNAME = new QName("", "cn-domestic-priority-claims");
    private final static QName _Relation_QNAME = new QName("", "relation");
    private final static QName _ParentDoc_QNAME = new QName("", "parent-doc");
    private final static QName _ParentPctDocument_QNAME = new QName("", "parent-pct-document");
    private final static QName _ParentStatus_QNAME = new QName("", "parent-status");
    private final static QName _ParentGrantDocument_QNAME = new QName("", "parent-grant-document");
    private final static QName _ChildDoc_QNAME = new QName("", "child-doc");
    private final static QName _CnApplicants_QNAME = new QName("", "cn-applicants");
    private final static QName _CnApplicant_QNAME = new QName("", "cn-applicant");
    private final static QName _Nationality_QNAME = new QName("", "nationality");
    private final static QName _Residence_QNAME = new QName("", "residence");
    private final static QName _CnInventors_QNAME = new QName("", "cn-inventors");
    private final static QName _CnInventor_QNAME = new QName("", "cn-inventor");
    private final static QName _CorrespondenceAddress_QNAME = new QName("", "correspondence-address");
    private final static QName _CustomerNumber_QNAME = new QName("", "customer-number");
    private final static QName _CnAgents_QNAME = new QName("", "cn-agents");
    private final static QName _CnAgent_QNAME = new QName("", "cn-agent");
    private final static QName _CnAgency_QNAME = new QName("", "cn-agency");
    private final static QName _ApplicationBody_QNAME = new QName("", "application-body");
    private final static QName _Figure_QNAME = new QName("", "figure");
    private final static QName _AbstSolution_QNAME = new QName("", "abst-solution");
    private final static QName _AbstProblem_QNAME = new QName("", "abst-problem");
    private final static QName _Claim_QNAME = new QName("", "claim");
    private final static QName _ClaimRef_QNAME = new QName("", "claim-ref");
    private final static QName _SequenceListText_QNAME = new QName("", "sequence-list-text");
    private final static QName _IndustrialApplicability_QNAME = new QName("", "industrial-applicability");
    private final static QName _ModeForInvention_QNAME = new QName("", "mode-for-invention");
    private final static QName _BestMode_QNAME = new QName("", "best-mode");
    private final static QName _Disclosure_QNAME = new QName("", "disclosure");
    private final static QName _AdvantageousEffects_QNAME = new QName("", "advantageous-effects");
    private final static QName _TechSolution_QNAME = new QName("", "tech-solution");
    private final static QName _TechProblem_QNAME = new QName("", "tech-problem");
    private final static QName _DescriptionOfDrawings_QNAME = new QName("", "description-of-drawings");
    private final static QName _BackgroundArt_QNAME = new QName("", "background-art");
    private final static QName _TechnicalField_QNAME = new QName("", "technical-field");
    private final static QName _Pre_QNAME = new QName("", "pre");
    private final static QName _P_QNAME = new QName("", "p");
    private final static QName _TableExternalDoc_QNAME = new QName("", "table-external-doc");
    private final static QName _Tables_QNAME = new QName("", "tables");
    private final static QName _Figref_QNAME = new QName("", "figref");
    private final static QName _Dl_QNAME = new QName("", "dl");
    private final static QName _Dt_QNAME = new QName("", "dt");
    private final static QName _Ul_QNAME = new QName("", "ul");
    private final static QName _Li_QNAME = new QName("", "li");
    private final static QName _Maths_QNAME = new QName("", "maths");
    private final static QName _Chemistry_QNAME = new QName("", "chemistry");
    private final static QName _Chem_QNAME = new QName("", "chem");
    private final static QName _Ol_QNAME = new QName("", "ol");
    private final static QName _Img_QNAME = new QName("", "img");
    private final static QName _Crossref_QNAME = new QName("", "crossref");
    private final static QName _Heading_QNAME = new QName("", "heading");
    private final static QName _DocPage_QNAME = new QName("", "doc-page");
    private final static QName _Drawings_QNAME = new QName("", "drawings");
    private final static QName _CnAbstractDrawing_QNAME = new QName("", "cn-abstract-drawing");
    private final static QName _Abstract_QNAME = new QName("", "abstract");
    private final static QName _Claims_QNAME = new QName("", "claims");
    private final static QName _ClaimText_QNAME = new QName("", "claim-text");
    private final static QName _Br_QNAME = new QName("", "br");
    private final static QName _Description_QNAME = new QName("", "description");
    private final static QName _Dd_QNAME = new QName("", "dd");
    private final static QName _BioDeposit_QNAME = new QName("", "bio-deposit");
    private final static QName _Depositary_QNAME = new QName("", "depositary");
    private final static QName _BioAccno_QNAME = new QName("", "bio-accno");
    private final static QName _Term_QNAME = new QName("", "term");
    private final static QName _CnRelatedDocuments_QNAME = new QName("", "cn-related-documents");
    private final static QName _Assignees_QNAME = new QName("", "assignees");
    private final static QName _Assignee_QNAME = new QName("", "assignee");
    private final static QName _Table_QNAME = new QName("", "table");
    private final static QName _Tgroup_QNAME = new QName("", "tgroup");
    private final static QName _Colspec_QNAME = new QName("", "colspec");
    private final static QName _Thead_QNAME = new QName("", "thead");
    private final static QName _Tbody_QNAME = new QName("", "tbody");
    private final static QName _Row_QNAME = new QName("", "row");
    private final static QName _Entry_QNAME = new QName("", "entry");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.jaxb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Title }
     * 
     */
    public Title createTitle() {
        return new Title();
    }

    /**
     * Create an instance of {@link Math }
     * 
     */
    public Math createMath() {
        return new Math();
    }

    /**
     * Create an instance of {@link CnPatentDocument }
     * 
     */
    public CnPatentDocument createCnPatentDocument() {
        return new CnPatentDocument();
    }

    /**
     * Create an instance of {@link CnBibliographicData }
     * 
     */
    public CnBibliographicData createCnBibliographicData() {
        return new CnBibliographicData();
    }

    /**
     * Create an instance of {@link SequenceListDoc }
     * 
     */
    public SequenceListDoc createSequenceListDoc() {
        return new SequenceListDoc();
    }

    /**
     * Create an instance of {@link SequenceList }
     * 
     */
    public SequenceList createSequenceList() {
        return new SequenceList();
    }

    /**
     * Create an instance of {@link CnPublicationReference }
     * 
     */
    public CnPublicationReference createCnPublicationReference() {
        return new CnPublicationReference();
    }

    /**
     * Create an instance of {@link ApplicationReference }
     * 
     */
    public ApplicationReference createApplicationReference() {
        return new ApplicationReference();
    }

    /**
     * Create an instance of {@link Correction }
     * 
     */
    public Correction createCorrection() {
        return new Correction();
    }

    /**
     * Create an instance of {@link PriorityClaims }
     * 
     */
    public PriorityClaims createPriorityClaims() {
        return new PriorityClaims();
    }

    /**
     * Create an instance of {@link PriorityClaim }
     * 
     */
    public PriorityClaim createPriorityClaim() {
        return new PriorityClaim();
    }

    /**
     * Create an instance of {@link ClassificationIpc }
     * 
     */
    public ClassificationIpc createClassificationIpc() {
        return new ClassificationIpc();
    }

    /**
     * Create an instance of {@link ClassificationsIpcr }
     * 
     */
    public ClassificationsIpcr createClassificationsIpcr() {
        return new ClassificationsIpcr();
    }

    /**
     * Create an instance of {@link ClassificationIpcr }
     * 
     */
    public ClassificationIpcr createClassificationIpcr() {
        return new ClassificationIpcr();
    }

    /**
     * Create an instance of {@link InventionTitle }
     * 
     */
    public InventionTitle createInventionTitle() {
        return new InventionTitle();
    }

    /**
     * Create an instance of {@link ReferencesCited }
     * 
     */
    public ReferencesCited createReferencesCited() {
        return new ReferencesCited();
    }

    /**
     * Create an instance of {@link Citation }
     * 
     */
    public Citation createCitation() {
        return new Citation();
    }

    /**
     * Create an instance of {@link Division }
     * 
     */
    public Division createDivision() {
        return new Division();
    }

    /**
     * Create an instance of {@link CnRelatedPublication }
     * 
     */
    public CnRelatedPublication createCnRelatedPublication() {
        return new CnRelatedPublication();
    }

    /**
     * Create an instance of {@link CnParties }
     * 
     */
    public CnParties createCnParties() {
        return new CnParties();
    }

    /**
     * Create an instance of {@link DatePctArticle2239Fulfilled }
     * 
     */
    public DatePctArticle2239Fulfilled createDatePctArticle2239Fulfilled() {
        return new DatePctArticle2239Fulfilled();
    }

    /**
     * Create an instance of {@link PctOrRegionalFilingData }
     * 
     */
    public PctOrRegionalFilingData createPctOrRegionalFilingData() {
        return new PctOrRegionalFilingData();
    }

    /**
     * Create an instance of {@link Us371C124Date }
     * 
     */
    public Us371C124Date createUs371C124Date() {
        return new Us371C124Date();
    }

    /**
     * Create an instance of {@link PctOrRegionalPublishingData }
     * 
     */
    public PctOrRegionalPublishingData createPctOrRegionalPublishingData() {
        return new PctOrRegionalPublishingData();
    }

    /**
     * Create an instance of {@link Figures }
     * 
     */
    public Figures createFigures() {
        return new Figures();
    }

    /**
     * Create an instance of {@link FigureToPublish }
     * 
     */
    public FigureToPublish createFigureToPublish() {
        return new FigureToPublish();
    }

    /**
     * Create an instance of {@link FigNumber }
     * 
     */
    public FigNumber createFigNumber() {
        return new FigNumber();
    }

    /**
     * Create an instance of {@link NumberOfFigures }
     * 
     */
    public NumberOfFigures createNumberOfFigures() {
        return new NumberOfFigures();
    }

    /**
     * Create an instance of {@link NumberOfDrawingSheets }
     * 
     */
    public NumberOfDrawingSheets createNumberOfDrawingSheets() {
        return new NumberOfDrawingSheets();
    }

    /**
     * Create an instance of {@link TypeOfCorrection }
     * 
     */
    public TypeOfCorrection createTypeOfCorrection() {
        return new TypeOfCorrection();
    }

    /**
     * Create an instance of {@link DocumentCorrected }
     * 
     */
    public DocumentCorrected createDocumentCorrected() {
        return new DocumentCorrected();
    }

    /**
     * Create an instance of {@link GazetteReference }
     * 
     */
    public GazetteReference createGazetteReference() {
        return new GazetteReference();
    }

    /**
     * Create an instance of {@link GazetteNum }
     * 
     */
    public GazetteNum createGazetteNum() {
        return new GazetteNum();
    }

    /**
     * Create an instance of {@link Serial }
     * 
     */
    public Serial createSerial() {
        return new Serial();
    }

    /**
     * Create an instance of {@link Sertitle }
     * 
     */
    public Sertitle createSertitle() {
        return new Sertitle();
    }

    /**
     * Create an instance of {@link Alttitle }
     * 
     */
    public Alttitle createAlttitle() {
        return new Alttitle();
    }

    /**
     * Create an instance of {@link Subname }
     * 
     */
    public Subname createSubname() {
        return new Subname();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link Prefix }
     * 
     */
    public Prefix createPrefix() {
        return new Prefix();
    }

    /**
     * Create an instance of {@link LastName }
     * 
     */
    public LastName createLastName() {
        return new LastName();
    }

    /**
     * Create an instance of {@link Orgname }
     * 
     */
    public Orgname createOrgname() {
        return new Orgname();
    }

    /**
     * Create an instance of {@link FirstName }
     * 
     */
    public FirstName createFirstName() {
        return new FirstName();
    }

    /**
     * Create an instance of {@link MiddleName }
     * 
     */
    public MiddleName createMiddleName() {
        return new MiddleName();
    }

    /**
     * Create an instance of {@link Suffix }
     * 
     */
    public Suffix createSuffix() {
        return new Suffix();
    }

    /**
     * Create an instance of {@link Iid }
     * 
     */
    public Iid createIid() {
        return new Iid();
    }

    /**
     * Create an instance of {@link Role }
     * 
     */
    public Role createRole() {
        return new Role();
    }

    /**
     * Create an instance of {@link Department }
     * 
     */
    public Department createDepartment() {
        return new Department();
    }

    /**
     * Create an instance of {@link Synonym }
     * 
     */
    public Synonym createSynonym() {
        return new Synonym();
    }

    /**
     * Create an instance of {@link RegisteredNumber }
     * 
     */
    public RegisteredNumber createRegisteredNumber() {
        return new RegisteredNumber();
    }

    /**
     * Create an instance of {@link Addressbook }
     * 
     */
    public Addressbook createAddressbook() {
        return new Addressbook();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link Address1 }
     * 
     */
    public Address1 createAddress1() {
        return new Address1();
    }

    /**
     * Create an instance of {@link Address2 }
     * 
     */
    public Address2 createAddress2() {
        return new Address2();
    }

    /**
     * Create an instance of {@link Address3 }
     * 
     */
    public Address3 createAddress3() {
        return new Address3();
    }

    /**
     * Create an instance of {@link Mailcode }
     * 
     */
    public Mailcode createMailcode() {
        return new Mailcode();
    }

    /**
     * Create an instance of {@link Pobox }
     * 
     */
    public Pobox createPobox() {
        return new Pobox();
    }

    /**
     * Create an instance of {@link Room }
     * 
     */
    public Room createRoom() {
        return new Room();
    }

    /**
     * Create an instance of {@link AddressFloor }
     * 
     */
    public AddressFloor createAddressFloor() {
        return new AddressFloor();
    }

    /**
     * Create an instance of {@link Building }
     * 
     */
    public Building createBuilding() {
        return new Building();
    }

    /**
     * Create an instance of {@link Street }
     * 
     */
    public Street createStreet() {
        return new Street();
    }

    /**
     * Create an instance of {@link City }
     * 
     */
    public City createCity() {
        return new City();
    }

    /**
     * Create an instance of {@link County }
     * 
     */
    public County createCounty() {
        return new County();
    }

    /**
     * Create an instance of {@link State }
     * 
     */
    public State createState() {
        return new State();
    }

    /**
     * Create an instance of {@link Postcode }
     * 
     */
    public Postcode createPostcode() {
        return new Postcode();
    }

    /**
     * Create an instance of {@link Text }
     * 
     */
    public Text createText() {
        return new Text();
    }

    /**
     * Create an instance of {@link Phone }
     * 
     */
    public Phone createPhone() {
        return new Phone();
    }

    /**
     * Create an instance of {@link Fax }
     * 
     */
    public Fax createFax() {
        return new Fax();
    }

    /**
     * Create an instance of {@link Email }
     * 
     */
    public Email createEmail() {
        return new Email();
    }

    /**
     * Create an instance of {@link Url }
     * 
     */
    public Url createUrl() {
        return new Url();
    }

    /**
     * Create an instance of {@link Ead }
     * 
     */
    public Ead createEad() {
        return new Ead();
    }

    /**
     * Create an instance of {@link Dtext }
     * 
     */
    public Dtext createDtext() {
        return new Dtext();
    }

    /**
     * Create an instance of {@link Issue }
     * 
     */
    public Issue createIssue() {
        return new Issue();
    }

    /**
     * Create an instance of {@link Imprint }
     * 
     */
    public Imprint createImprint() {
        return new Imprint();
    }

    /**
     * Create an instance of {@link Pubdate }
     * 
     */
    public Pubdate createPubdate() {
        return new Pubdate();
    }

    /**
     * Create an instance of {@link Sdate }
     * 
     */
    public Sdate createSdate() {
        return new Sdate();
    }

    /**
     * Create an instance of {@link Edate }
     * 
     */
    public Edate createEdate() {
        return new Edate();
    }

    /**
     * Create an instance of {@link Time }
     * 
     */
    public Time createTime() {
        return new Time();
    }

    /**
     * Create an instance of {@link Descrip }
     * 
     */
    public Descrip createDescrip() {
        return new Descrip();
    }

    /**
     * Create an instance of {@link Notes }
     * 
     */
    public Notes createNotes() {
        return new Notes();
    }

    /**
     * Create an instance of {@link Issn }
     * 
     */
    public Issn createIssn() {
        return new Issn();
    }

    /**
     * Create an instance of {@link Isbn }
     * 
     */
    public Isbn createIsbn() {
        return new Isbn();
    }

    /**
     * Create an instance of {@link Pubid }
     * 
     */
    public Pubid createPubid() {
        return new Pubid();
    }

    /**
     * Create an instance of {@link Vid }
     * 
     */
    public Vid createVid() {
        return new Vid();
    }

    /**
     * Create an instance of {@link Ino }
     * 
     */
    public Ino createIno() {
        return new Ino();
    }

    /**
     * Create an instance of {@link Cpyrt }
     * 
     */
    public Cpyrt createCpyrt() {
        return new Cpyrt();
    }

    /**
     * Create an instance of {@link DocumentId }
     * 
     */
    public DocumentId createDocumentId() {
        return new DocumentId();
    }

    /**
     * Create an instance of {@link DocNumber }
     * 
     */
    public DocNumber createDocNumber() {
        return new DocNumber();
    }

    /**
     * Create an instance of {@link Kind }
     * 
     */
    public Kind createKind() {
        return new Kind();
    }

    /**
     * Create an instance of {@link Date }
     * 
     */
    public Date createDate() {
        return new Date();
    }

    /**
     * Create an instance of {@link OfficeOfFiling }
     * 
     */
    public OfficeOfFiling createOfficeOfFiling() {
        return new OfficeOfFiling();
    }

    /**
     * Create an instance of {@link Region }
     * 
     */
    public Region createRegion() {
        return new Region();
    }

    /**
     * Create an instance of {@link PriorityDocRequested }
     * 
     */
    public PriorityDocRequested createPriorityDocRequested() {
        return new PriorityDocRequested();
    }

    /**
     * Create an instance of {@link PriorityDocAttached }
     * 
     */
    public PriorityDocAttached createPriorityDocAttached() {
        return new PriorityDocAttached();
    }

    /**
     * Create an instance of {@link Class }
     * 
     */
    public Class createClass() {
        return new Class();
    }

    /**
     * Create an instance of {@link ClassificationDataSource }
     * 
     */
    public ClassificationDataSource createClassificationDataSource() {
        return new ClassificationDataSource();
    }

    /**
     * Create an instance of {@link ClassificationStatus }
     * 
     */
    public ClassificationStatus createClassificationStatus() {
        return new ClassificationStatus();
    }

    /**
     * Create an instance of {@link GeneratingOffice }
     * 
     */
    public GeneratingOffice createGeneratingOffice() {
        return new GeneratingOffice();
    }

    /**
     * Create an instance of {@link ActionDate }
     * 
     */
    public ActionDate createActionDate() {
        return new ActionDate();
    }

    /**
     * Create an instance of {@link ClassificationValue }
     * 
     */
    public ClassificationValue createClassificationValue() {
        return new ClassificationValue();
    }

    /**
     * Create an instance of {@link SymbolPosition }
     * 
     */
    public SymbolPosition createSymbolPosition() {
        return new SymbolPosition();
    }

    /**
     * Create an instance of {@link Subgroup }
     * 
     */
    public Subgroup createSubgroup() {
        return new Subgroup();
    }

    /**
     * Create an instance of {@link MainGroup }
     * 
     */
    public MainGroup createMainGroup() {
        return new MainGroup();
    }

    /**
     * Create an instance of {@link Subclass }
     * 
     */
    public Subclass createSubclass() {
        return new Subclass();
    }

    /**
     * Create an instance of {@link Section }
     * 
     */
    public Section createSection() {
        return new Section();
    }

    /**
     * Create an instance of {@link ClassificationLevel }
     * 
     */
    public ClassificationLevel createClassificationLevel() {
        return new ClassificationLevel();
    }

    /**
     * Create an instance of {@link IpcVersionIndicator }
     * 
     */
    public IpcVersionIndicator createIpcVersionIndicator() {
        return new IpcVersionIndicator();
    }

    /**
     * Create an instance of {@link B }
     * 
     */
    public B createB() {
        return new B();
    }

    /**
     * Create an instance of {@link I }
     * 
     */
    public I createI() {
        return new I();
    }

    /**
     * Create an instance of {@link U }
     * 
     */
    public U createU() {
        return new U();
    }

    /**
     * Create an instance of {@link Smallcaps }
     * 
     */
    public Smallcaps createSmallcaps() {
        return new Smallcaps();
    }

    /**
     * Create an instance of {@link Sup }
     * 
     */
    public Sup createSup() {
        return new Sup();
    }

    /**
     * Create an instance of {@link Sub }
     * 
     */
    public Sub createSub() {
        return new Sub();
    }

    /**
     * Create an instance of {@link Patcit }
     * 
     */
    public Patcit createPatcit() {
        return new Patcit();
    }

    /**
     * Create an instance of {@link RelPassage }
     * 
     */
    public RelPassage createRelPassage() {
        return new RelPassage();
    }

    /**
     * Create an instance of {@link Passage }
     * 
     */
    public Passage createPassage() {
        return new Passage();
    }

    /**
     * Create an instance of {@link Category }
     * 
     */
    public Category createCategory() {
        return new Category();
    }

    /**
     * Create an instance of {@link RelClaims }
     * 
     */
    public RelClaims createRelClaims() {
        return new RelClaims();
    }

    /**
     * Create an instance of {@link Nplcit }
     * 
     */
    public Nplcit createNplcit() {
        return new Nplcit();
    }

    /**
     * Create an instance of {@link Article }
     * 
     */
    public Article createArticle() {
        return new Article();
    }

    /**
     * Create an instance of {@link Author }
     * 
     */
    public Author createAuthor() {
        return new Author();
    }

    /**
     * Create an instance of {@link Atl }
     * 
     */
    public Atl createAtl() {
        return new Atl();
    }

    /**
     * Create an instance of {@link Book }
     * 
     */
    public Book createBook() {
        return new Book();
    }

    /**
     * Create an instance of {@link BookTitle }
     * 
     */
    public BookTitle createBookTitle() {
        return new BookTitle();
    }

    /**
     * Create an instance of {@link Conference }
     * 
     */
    public Conference createConference() {
        return new Conference();
    }

    /**
     * Create an instance of {@link Conftitle }
     * 
     */
    public Conftitle createConftitle() {
        return new Conftitle();
    }

    /**
     * Create an instance of {@link Confno }
     * 
     */
    public Confno createConfno() {
        return new Confno();
    }

    /**
     * Create an instance of {@link Confplace }
     * 
     */
    public Confplace createConfplace() {
        return new Confplace();
    }

    /**
     * Create an instance of {@link Confsponsor }
     * 
     */
    public Confsponsor createConfsponsor() {
        return new Confsponsor();
    }

    /**
     * Create an instance of {@link Subtitle }
     * 
     */
    public Subtitle createSubtitle() {
        return new Subtitle();
    }

    /**
     * Create an instance of {@link Edition }
     * 
     */
    public Edition createEdition() {
        return new Edition();
    }

    /**
     * Create an instance of {@link Series }
     * 
     */
    public Series createSeries() {
        return new Series();
    }

    /**
     * Create an instance of {@link Mst }
     * 
     */
    public Mst createMst() {
        return new Mst();
    }

    /**
     * Create an instance of {@link Msn }
     * 
     */
    public Msn createMsn() {
        return new Msn();
    }

    /**
     * Create an instance of {@link Absno }
     * 
     */
    public Absno createAbsno() {
        return new Absno();
    }

    /**
     * Create an instance of {@link Location }
     * 
     */
    public Location createLocation() {
        return new Location();
    }

    /**
     * Create an instance of {@link Serpart }
     * 
     */
    public Serpart createSerpart() {
        return new Serpart();
    }

    /**
     * Create an instance of {@link Sersect }
     * 
     */
    public Sersect createSersect() {
        return new Sersect();
    }

    /**
     * Create an instance of {@link Chapter }
     * 
     */
    public Chapter createChapter() {
        return new Chapter();
    }

    /**
     * Create an instance of {@link Pp }
     * 
     */
    public Pp createPp() {
        return new Pp();
    }

    /**
     * Create an instance of {@link Ppf }
     * 
     */
    public Ppf createPpf() {
        return new Ppf();
    }

    /**
     * Create an instance of {@link Ppl }
     * 
     */
    public Ppl createPpl() {
        return new Ppl();
    }

    /**
     * Create an instance of {@link Column }
     * 
     */
    public Column createColumn() {
        return new Column();
    }

    /**
     * Create an instance of {@link Colf }
     * 
     */
    public Colf createColf() {
        return new Colf();
    }

    /**
     * Create an instance of {@link Coll }
     * 
     */
    public Coll createColl() {
        return new Coll();
    }

    /**
     * Create an instance of {@link Para }
     * 
     */
    public Para createPara() {
        return new Para();
    }

    /**
     * Create an instance of {@link Paraf }
     * 
     */
    public Paraf createParaf() {
        return new Paraf();
    }

    /**
     * Create an instance of {@link Paral }
     * 
     */
    public Paral createParal() {
        return new Paral();
    }

    /**
     * Create an instance of {@link Line }
     * 
     */
    public Line createLine() {
        return new Line();
    }

    /**
     * Create an instance of {@link Linef }
     * 
     */
    public Linef createLinef() {
        return new Linef();
    }

    /**
     * Create an instance of {@link Linel }
     * 
     */
    public Linel createLinel() {
        return new Linel();
    }

    /**
     * Create an instance of {@link Bookno }
     * 
     */
    public Bookno createBookno() {
        return new Bookno();
    }

    /**
     * Create an instance of {@link Keyword }
     * 
     */
    public Keyword createKeyword() {
        return new Keyword();
    }

    /**
     * Create an instance of {@link Refno }
     * 
     */
    public Refno createRefno() {
        return new Refno();
    }

    /**
     * Create an instance of {@link Artid }
     * 
     */
    public Artid createArtid() {
        return new Artid();
    }

    /**
     * Create an instance of {@link Online }
     * 
     */
    public Online createOnline() {
        return new Online();
    }

    /**
     * Create an instance of {@link OnlineTitle }
     * 
     */
    public OnlineTitle createOnlineTitle() {
        return new OnlineTitle();
    }

    /**
     * Create an instance of {@link Hosttitle }
     * 
     */
    public Hosttitle createHosttitle() {
        return new Hosttitle();
    }

    /**
     * Create an instance of {@link History }
     * 
     */
    public History createHistory() {
        return new History();
    }

    /**
     * Create an instance of {@link Received }
     * 
     */
    public Received createReceived() {
        return new Received();
    }

    /**
     * Create an instance of {@link Accepted }
     * 
     */
    public Accepted createAccepted() {
        return new Accepted();
    }

    /**
     * Create an instance of {@link Revised }
     * 
     */
    public Revised createRevised() {
        return new Revised();
    }

    /**
     * Create an instance of {@link Misc }
     * 
     */
    public Misc createMisc() {
        return new Misc();
    }

    /**
     * Create an instance of {@link Hostno }
     * 
     */
    public Hostno createHostno() {
        return new Hostno();
    }

    /**
     * Create an instance of {@link Avail }
     * 
     */
    public Avail createAvail() {
        return new Avail();
    }

    /**
     * Create an instance of {@link Datecit }
     * 
     */
    public Datecit createDatecit() {
        return new Datecit();
    }

    /**
     * Create an instance of {@link Srchterm }
     * 
     */
    public Srchterm createSrchterm() {
        return new Srchterm();
    }

    /**
     * Create an instance of {@link Srchdate }
     * 
     */
    public Srchdate createSrchdate() {
        return new Srchdate();
    }

    /**
     * Create an instance of {@link Othercit }
     * 
     */
    public Othercit createOthercit() {
        return new Othercit();
    }

    /**
     * Create an instance of {@link DateSearchCompleted }
     * 
     */
    public DateSearchCompleted createDateSearchCompleted() {
        return new DateSearchCompleted();
    }

    /**
     * Create an instance of {@link DateSearchReportMailed }
     * 
     */
    public DateSearchReportMailed createDateSearchReportMailed() {
        return new DateSearchReportMailed();
    }

    /**
     * Create an instance of {@link PlaceOfSearch }
     * 
     */
    public PlaceOfSearch createPlaceOfSearch() {
        return new PlaceOfSearch();
    }

    /**
     * Create an instance of {@link SearchReportPublication }
     * 
     */
    public SearchReportPublication createSearchReportPublication() {
        return new SearchReportPublication();
    }

    /**
     * Create an instance of {@link Searcher }
     * 
     */
    public Searcher createSearcher() {
        return new Searcher();
    }

    /**
     * Create an instance of {@link IpcVersion }
     * 
     */
    public IpcVersion createIpcVersion() {
        return new IpcVersion();
    }

    /**
     * Create an instance of {@link MainClassification }
     * 
     */
    public MainClassification createMainClassification() {
        return new MainClassification();
    }

    /**
     * Create an instance of {@link FurtherClassification }
     * 
     */
    public FurtherClassification createFurtherClassification() {
        return new FurtherClassification();
    }

    /**
     * Create an instance of {@link AdditionalInfo }
     * 
     */
    public AdditionalInfo createAdditionalInfo() {
        return new AdditionalInfo();
    }

    /**
     * Create an instance of {@link LinkedIndexingCodeGroup }
     * 
     */
    public LinkedIndexingCodeGroup createLinkedIndexingCodeGroup() {
        return new LinkedIndexingCodeGroup();
    }

    /**
     * Create an instance of {@link MainLinkedIndexingCode }
     * 
     */
    public MainLinkedIndexingCode createMainLinkedIndexingCode() {
        return new MainLinkedIndexingCode();
    }

    /**
     * Create an instance of {@link SubLinkedIndexingCode }
     * 
     */
    public SubLinkedIndexingCode createSubLinkedIndexingCode() {
        return new SubLinkedIndexingCode();
    }

    /**
     * Create an instance of {@link UnlinkedIndexingCode }
     * 
     */
    public UnlinkedIndexingCode createUnlinkedIndexingCode() {
        return new UnlinkedIndexingCode();
    }

    /**
     * Create an instance of {@link CorrespondingDocs }
     * 
     */
    public CorrespondingDocs createCorrespondingDocs() {
        return new CorrespondingDocs();
    }

    /**
     * Create an instance of {@link ClassificationNational }
     * 
     */
    public ClassificationNational createClassificationNational() {
        return new ClassificationNational();
    }

    /**
     * Create an instance of {@link Substitution }
     * 
     */
    public Substitution createSubstitution() {
        return new Substitution();
    }

    /**
     * Create an instance of {@link CnDomesticPriorityClaim }
     * 
     */
    public CnDomesticPriorityClaim createCnDomesticPriorityClaim() {
        return new CnDomesticPriorityClaim();
    }

    /**
     * Create an instance of {@link CnDomesticPriorityClaims }
     * 
     */
    public CnDomesticPriorityClaims createCnDomesticPriorityClaims() {
        return new CnDomesticPriorityClaims();
    }

    /**
     * Create an instance of {@link Relation }
     * 
     */
    public Relation createRelation() {
        return new Relation();
    }

    /**
     * Create an instance of {@link ParentDoc }
     * 
     */
    public ParentDoc createParentDoc() {
        return new ParentDoc();
    }

    /**
     * Create an instance of {@link ParentPctDocument }
     * 
     */
    public ParentPctDocument createParentPctDocument() {
        return new ParentPctDocument();
    }

    /**
     * Create an instance of {@link ParentStatus }
     * 
     */
    public ParentStatus createParentStatus() {
        return new ParentStatus();
    }

    /**
     * Create an instance of {@link ParentGrantDocument }
     * 
     */
    public ParentGrantDocument createParentGrantDocument() {
        return new ParentGrantDocument();
    }

    /**
     * Create an instance of {@link ChildDoc }
     * 
     */
    public ChildDoc createChildDoc() {
        return new ChildDoc();
    }

    /**
     * Create an instance of {@link CnApplicants }
     * 
     */
    public CnApplicants createCnApplicants() {
        return new CnApplicants();
    }

    /**
     * Create an instance of {@link CnApplicant }
     * 
     */
    public CnApplicant createCnApplicant() {
        return new CnApplicant();
    }

    /**
     * Create an instance of {@link Nationality }
     * 
     */
    public Nationality createNationality() {
        return new Nationality();
    }

    /**
     * Create an instance of {@link Residence }
     * 
     */
    public Residence createResidence() {
        return new Residence();
    }

    /**
     * Create an instance of {@link CnInventors }
     * 
     */
    public CnInventors createCnInventors() {
        return new CnInventors();
    }

    /**
     * Create an instance of {@link CnInventor }
     * 
     */
    public CnInventor createCnInventor() {
        return new CnInventor();
    }

    /**
     * Create an instance of {@link CorrespondenceAddress }
     * 
     */
    public CorrespondenceAddress createCorrespondenceAddress() {
        return new CorrespondenceAddress();
    }

    /**
     * Create an instance of {@link CustomerNumber }
     * 
     */
    public CustomerNumber createCustomerNumber() {
        return new CustomerNumber();
    }

    /**
     * Create an instance of {@link CnAgents }
     * 
     */
    public CnAgents createCnAgents() {
        return new CnAgents();
    }

    /**
     * Create an instance of {@link CnAgent }
     * 
     */
    public CnAgent createCnAgent() {
        return new CnAgent();
    }

    /**
     * Create an instance of {@link CnAgency }
     * 
     */
    public CnAgency createCnAgency() {
        return new CnAgency();
    }

    /**
     * Create an instance of {@link ApplicationBody }
     * 
     */
    public ApplicationBody createApplicationBody() {
        return new ApplicationBody();
    }

    /**
     * Create an instance of {@link Figure }
     * 
     */
    public Figure createFigure() {
        return new Figure();
    }

    /**
     * Create an instance of {@link AbstSolution }
     * 
     */
    public AbstSolution createAbstSolution() {
        return new AbstSolution();
    }

    /**
     * Create an instance of {@link AbstProblem }
     * 
     */
    public AbstProblem createAbstProblem() {
        return new AbstProblem();
    }

    /**
     * Create an instance of {@link Claim }
     * 
     */
    public Claim createClaim() {
        return new Claim();
    }

    /**
     * Create an instance of {@link ClaimRef }
     * 
     */
    public ClaimRef createClaimRef() {
        return new ClaimRef();
    }

    /**
     * Create an instance of {@link SequenceListText }
     * 
     */
    public SequenceListText createSequenceListText() {
        return new SequenceListText();
    }

    /**
     * Create an instance of {@link IndustrialApplicability }
     * 
     */
    public IndustrialApplicability createIndustrialApplicability() {
        return new IndustrialApplicability();
    }

    /**
     * Create an instance of {@link ModeForInvention }
     * 
     */
    public ModeForInvention createModeForInvention() {
        return new ModeForInvention();
    }

    /**
     * Create an instance of {@link BestMode }
     * 
     */
    public BestMode createBestMode() {
        return new BestMode();
    }

    /**
     * Create an instance of {@link Disclosure }
     * 
     */
    public Disclosure createDisclosure() {
        return new Disclosure();
    }

    /**
     * Create an instance of {@link AdvantageousEffects }
     * 
     */
    public AdvantageousEffects createAdvantageousEffects() {
        return new AdvantageousEffects();
    }

    /**
     * Create an instance of {@link TechSolution }
     * 
     */
    public TechSolution createTechSolution() {
        return new TechSolution();
    }

    /**
     * Create an instance of {@link TechProblem }
     * 
     */
    public TechProblem createTechProblem() {
        return new TechProblem();
    }

    /**
     * Create an instance of {@link DescriptionOfDrawings }
     * 
     */
    public DescriptionOfDrawings createDescriptionOfDrawings() {
        return new DescriptionOfDrawings();
    }

    /**
     * Create an instance of {@link BackgroundArt }
     * 
     */
    public BackgroundArt createBackgroundArt() {
        return new BackgroundArt();
    }

    /**
     * Create an instance of {@link TechnicalField }
     * 
     */
    public TechnicalField createTechnicalField() {
        return new TechnicalField();
    }

    /**
     * Create an instance of {@link Pre }
     * 
     */
    public Pre createPre() {
        return new Pre();
    }

    /**
     * Create an instance of {@link P }
     * 
     */
    public P createP() {
        return new P();
    }

    /**
     * Create an instance of {@link TableExternalDoc }
     * 
     */
    public TableExternalDoc createTableExternalDoc() {
        return new TableExternalDoc();
    }

    /**
     * Create an instance of {@link Tables }
     * 
     */
    public Tables createTables() {
        return new Tables();
    }

    /**
     * Create an instance of {@link Figref }
     * 
     */
    public Figref createFigref() {
        return new Figref();
    }

    /**
     * Create an instance of {@link Dl }
     * 
     */
    public Dl createDl() {
        return new Dl();
    }

    /**
     * Create an instance of {@link Dt }
     * 
     */
    public Dt createDt() {
        return new Dt();
    }

    /**
     * Create an instance of {@link Ul }
     * 
     */
    public Ul createUl() {
        return new Ul();
    }

    /**
     * Create an instance of {@link Li }
     * 
     */
    public Li createLi() {
        return new Li();
    }

    /**
     * Create an instance of {@link Maths }
     * 
     */
    public Maths createMaths() {
        return new Maths();
    }

    /**
     * Create an instance of {@link Chemistry }
     * 
     */
    public Chemistry createChemistry() {
        return new Chemistry();
    }

    /**
     * Create an instance of {@link Chem }
     * 
     */
    public Chem createChem() {
        return new Chem();
    }

    /**
     * Create an instance of {@link Ol }
     * 
     */
    public Ol createOl() {
        return new Ol();
    }

    /**
     * Create an instance of {@link Img }
     * 
     */
    public Img createImg() {
        return new Img();
    }

    /**
     * Create an instance of {@link Crossref }
     * 
     */
    public Crossref createCrossref() {
        return new Crossref();
    }

    /**
     * Create an instance of {@link Heading }
     * 
     */
    public Heading createHeading() {
        return new Heading();
    }

    /**
     * Create an instance of {@link DocPage }
     * 
     */
    public DocPage createDocPage() {
        return new DocPage();
    }

    /**
     * Create an instance of {@link Drawings }
     * 
     */
    public Drawings createDrawings() {
        return new Drawings();
    }

    /**
     * Create an instance of {@link CnAbstractDrawing }
     * 
     */
    public CnAbstractDrawing createCnAbstractDrawing() {
        return new CnAbstractDrawing();
    }

    /**
     * Create an instance of {@link Abstract }
     * 
     */
    public Abstract createAbstract() {
        return new Abstract();
    }

    /**
     * Create an instance of {@link Claims }
     * 
     */
    public Claims createClaims() {
        return new Claims();
    }

    /**
     * Create an instance of {@link ClaimText }
     * 
     */
    public ClaimText createClaimText() {
        return new ClaimText();
    }

    /**
     * Create an instance of {@link Br }
     * 
     */
    public Br createBr() {
        return new Br();
    }

    /**
     * Create an instance of {@link Description }
     * 
     */
    public Description createDescription() {
        return new Description();
    }

    /**
     * Create an instance of {@link Dd }
     * 
     */
    public Dd createDd() {
        return new Dd();
    }

    /**
     * Create an instance of {@link BioDeposit }
     * 
     */
    public BioDeposit createBioDeposit() {
        return new BioDeposit();
    }

    /**
     * Create an instance of {@link Depositary }
     * 
     */
    public Depositary createDepositary() {
        return new Depositary();
    }

    /**
     * Create an instance of {@link BioAccno }
     * 
     */
    public BioAccno createBioAccno() {
        return new BioAccno();
    }

    /**
     * Create an instance of {@link Term }
     * 
     */
    public Term createTerm() {
        return new Term();
    }

    /**
     * Create an instance of {@link CnRelatedDocuments }
     * 
     */
    public CnRelatedDocuments createCnRelatedDocuments() {
        return new CnRelatedDocuments();
    }

    /**
     * Create an instance of {@link Assignees }
     * 
     */
    public Assignees createAssignees() {
        return new Assignees();
    }

    /**
     * Create an instance of {@link Assignee }
     * 
     */
    public Assignee createAssignee() {
        return new Assignee();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link Tgroup }
     * 
     */
    public Tgroup createTgroup() {
        return new Tgroup();
    }

    /**
     * Create an instance of {@link Colspec }
     * 
     */
    public Colspec createColspec() {
        return new Colspec();
    }

    /**
     * Create an instance of {@link Thead }
     * 
     */
    public Thead createThead() {
        return new Thead();
    }

    /**
     * Create an instance of {@link Tbody }
     * 
     */
    public Tbody createTbody() {
        return new Tbody();
    }

    /**
     * Create an instance of {@link Row }
     * 
     */
    public Row createRow() {
        return new Row();
    }

    /**
     * Create an instance of {@link Entry }
     * 
     */
    public Entry createEntry() {
        return new Entry();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Title }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "title")
    public JAXBElement<Title> createTitle(Title value) {
        return new JAXBElement<Title>(_Title_QNAME, Title.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Math }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "math")
    public JAXBElement<Math> createMath(Math value) {
        return new JAXBElement<Math>(_Math_QNAME, Math.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnPatentDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-patent-document")
    public JAXBElement<CnPatentDocument> createCnPatentDocument(CnPatentDocument value) {
        return new JAXBElement<CnPatentDocument>(_CnPatentDocument_QNAME, CnPatentDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnBibliographicData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-bibliographic-data")
    public JAXBElement<CnBibliographicData> createCnBibliographicData(CnBibliographicData value) {
        return new JAXBElement<CnBibliographicData>(_CnBibliographicData_QNAME, CnBibliographicData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListDoc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sequence-list-doc")
    public JAXBElement<SequenceListDoc> createSequenceListDoc(SequenceListDoc value) {
        return new JAXBElement<SequenceListDoc>(_SequenceListDoc_QNAME, SequenceListDoc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sequence-list")
    public JAXBElement<SequenceList> createSequenceList(SequenceList value) {
        return new JAXBElement<SequenceList>(_SequenceList_QNAME, SequenceList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnPublicationReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-publication-reference")
    public JAXBElement<CnPublicationReference> createCnPublicationReference(CnPublicationReference value) {
        return new JAXBElement<CnPublicationReference>(_CnPublicationReference_QNAME, CnPublicationReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "application-reference")
    public JAXBElement<ApplicationReference> createApplicationReference(ApplicationReference value) {
        return new JAXBElement<ApplicationReference>(_ApplicationReference_QNAME, ApplicationReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Correction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "correction")
    public JAXBElement<Correction> createCorrection(Correction value) {
        return new JAXBElement<Correction>(_Correction_QNAME, Correction.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityClaims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority-claims")
    public JAXBElement<PriorityClaims> createPriorityClaims(PriorityClaims value) {
        return new JAXBElement<PriorityClaims>(_PriorityClaims_QNAME, PriorityClaims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityClaim }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority-claim")
    public JAXBElement<PriorityClaim> createPriorityClaim(PriorityClaim value) {
        return new JAXBElement<PriorityClaim>(_PriorityClaim_QNAME, PriorityClaim.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationIpc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-ipc")
    public JAXBElement<ClassificationIpc> createClassificationIpc(ClassificationIpc value) {
        return new JAXBElement<ClassificationIpc>(_ClassificationIpc_QNAME, ClassificationIpc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationsIpcr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classifications-ipcr")
    public JAXBElement<ClassificationsIpcr> createClassificationsIpcr(ClassificationsIpcr value) {
        return new JAXBElement<ClassificationsIpcr>(_ClassificationsIpcr_QNAME, ClassificationsIpcr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationIpcr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-ipcr")
    public JAXBElement<ClassificationIpcr> createClassificationIpcr(ClassificationIpcr value) {
        return new JAXBElement<ClassificationIpcr>(_ClassificationIpcr_QNAME, ClassificationIpcr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventionTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "invention-title")
    public JAXBElement<InventionTitle> createInventionTitle(InventionTitle value) {
        return new JAXBElement<InventionTitle>(_InventionTitle_QNAME, InventionTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReferencesCited }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "references-cited")
    public JAXBElement<ReferencesCited> createReferencesCited(ReferencesCited value) {
        return new JAXBElement<ReferencesCited>(_ReferencesCited_QNAME, ReferencesCited.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Citation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "citation")
    public JAXBElement<Citation> createCitation(Citation value) {
        return new JAXBElement<Citation>(_Citation_QNAME, Citation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Division }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "division")
    public JAXBElement<Division> createDivision(Division value) {
        return new JAXBElement<Division>(_Division_QNAME, Division.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnRelatedPublication }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-related-publication")
    public JAXBElement<CnRelatedPublication> createCnRelatedPublication(CnRelatedPublication value) {
        return new JAXBElement<CnRelatedPublication>(_CnRelatedPublication_QNAME, CnRelatedPublication.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnParties }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-parties")
    public JAXBElement<CnParties> createCnParties(CnParties value) {
        return new JAXBElement<CnParties>(_CnParties_QNAME, CnParties.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DatePctArticle2239Fulfilled }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date-pct-article-22-39-fulfilled")
    public JAXBElement<DatePctArticle2239Fulfilled> createDatePctArticle2239Fulfilled(DatePctArticle2239Fulfilled value) {
        return new JAXBElement<DatePctArticle2239Fulfilled>(_DatePctArticle2239Fulfilled_QNAME, DatePctArticle2239Fulfilled.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PctOrRegionalFilingData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pct-or-regional-filing-data")
    public JAXBElement<PctOrRegionalFilingData> createPctOrRegionalFilingData(PctOrRegionalFilingData value) {
        return new JAXBElement<PctOrRegionalFilingData>(_PctOrRegionalFilingData_QNAME, PctOrRegionalFilingData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Us371C124Date }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-371c124-date")
    public JAXBElement<Us371C124Date> createUs371C124Date(Us371C124Date value) {
        return new JAXBElement<Us371C124Date>(_Us371C124Date_QNAME, Us371C124Date.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PctOrRegionalPublishingData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pct-or-regional-publishing-data")
    public JAXBElement<PctOrRegionalPublishingData> createPctOrRegionalPublishingData(PctOrRegionalPublishingData value) {
        return new JAXBElement<PctOrRegionalPublishingData>(_PctOrRegionalPublishingData_QNAME, PctOrRegionalPublishingData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Figures }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figures")
    public JAXBElement<Figures> createFigures(Figures value) {
        return new JAXBElement<Figures>(_Figures_QNAME, Figures.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigureToPublish }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figure-to-publish")
    public JAXBElement<FigureToPublish> createFigureToPublish(FigureToPublish value) {
        return new JAXBElement<FigureToPublish>(_FigureToPublish_QNAME, FigureToPublish.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fig-number")
    public JAXBElement<FigNumber> createFigNumber(FigNumber value) {
        return new JAXBElement<FigNumber>(_FigNumber_QNAME, FigNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberOfFigures }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "number-of-figures")
    public JAXBElement<NumberOfFigures> createNumberOfFigures(NumberOfFigures value) {
        return new JAXBElement<NumberOfFigures>(_NumberOfFigures_QNAME, NumberOfFigures.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberOfDrawingSheets }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "number-of-drawing-sheets")
    public JAXBElement<NumberOfDrawingSheets> createNumberOfDrawingSheets(NumberOfDrawingSheets value) {
        return new JAXBElement<NumberOfDrawingSheets>(_NumberOfDrawingSheets_QNAME, NumberOfDrawingSheets.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TypeOfCorrection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "type-of-correction")
    public JAXBElement<TypeOfCorrection> createTypeOfCorrection(TypeOfCorrection value) {
        return new JAXBElement<TypeOfCorrection>(_TypeOfCorrection_QNAME, TypeOfCorrection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentCorrected }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "document-corrected")
    public JAXBElement<DocumentCorrected> createDocumentCorrected(DocumentCorrected value) {
        return new JAXBElement<DocumentCorrected>(_DocumentCorrected_QNAME, DocumentCorrected.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GazetteReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "gazette-reference")
    public JAXBElement<GazetteReference> createGazetteReference(GazetteReference value) {
        return new JAXBElement<GazetteReference>(_GazetteReference_QNAME, GazetteReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GazetteNum }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "gazette-num")
    public JAXBElement<GazetteNum> createGazetteNum(GazetteNum value) {
        return new JAXBElement<GazetteNum>(_GazetteNum_QNAME, GazetteNum.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Serial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "serial")
    public JAXBElement<Serial> createSerial(Serial value) {
        return new JAXBElement<Serial>(_Serial_QNAME, Serial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sertitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sertitle")
    public JAXBElement<Sertitle> createSertitle(Sertitle value) {
        return new JAXBElement<Sertitle>(_Sertitle_QNAME, Sertitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Alttitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "alttitle")
    public JAXBElement<Alttitle> createAlttitle(Alttitle value) {
        return new JAXBElement<Alttitle>(_Alttitle_QNAME, Alttitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subname")
    public JAXBElement<Subname> createSubname(Subname value) {
        return new JAXBElement<Subname>(_Subname_QNAME, Subname.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Name }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name")
    public JAXBElement<Name> createName(Name value) {
        return new JAXBElement<Name>(_Name_QNAME, Name.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Prefix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix")
    public JAXBElement<Prefix> createPrefix(Prefix value) {
        return new JAXBElement<Prefix>(_Prefix_QNAME, Prefix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name")
    public JAXBElement<LastName> createLastName(LastName value) {
        return new JAXBElement<LastName>(_LastName_QNAME, LastName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Orgname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname")
    public JAXBElement<Orgname> createOrgname(Orgname value) {
        return new JAXBElement<Orgname>(_Orgname_QNAME, Orgname.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name")
    public JAXBElement<FirstName> createFirstName(FirstName value) {
        return new JAXBElement<FirstName>(_FirstName_QNAME, FirstName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name")
    public JAXBElement<MiddleName> createMiddleName(MiddleName value) {
        return new JAXBElement<MiddleName>(_MiddleName_QNAME, MiddleName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Suffix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix")
    public JAXBElement<Suffix> createSuffix(Suffix value) {
        return new JAXBElement<Suffix>(_Suffix_QNAME, Suffix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Iid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid")
    public JAXBElement<Iid> createIid(Iid value) {
        return new JAXBElement<Iid>(_Iid_QNAME, Iid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Role }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role")
    public JAXBElement<Role> createRole(Role value) {
        return new JAXBElement<Role>(_Role_QNAME, Role.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Department }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department")
    public JAXBElement<Department> createDepartment(Department value) {
        return new JAXBElement<Department>(_Department_QNAME, Department.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Synonym }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym")
    public JAXBElement<Synonym> createSynonym(Synonym value) {
        return new JAXBElement<Synonym>(_Synonym_QNAME, Synonym.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number")
    public JAXBElement<RegisteredNumber> createRegisteredNumber(RegisteredNumber value) {
        return new JAXBElement<RegisteredNumber>(_RegisteredNumber_QNAME, RegisteredNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addressbook }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressbook")
    public JAXBElement<Addressbook> createAddressbook(Addressbook value) {
        return new JAXBElement<Addressbook>(_Addressbook_QNAME, Addressbook.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address")
    public JAXBElement<Address> createAddress(Address value) {
        return new JAXBElement<Address>(_Address_QNAME, Address.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-1")
    public JAXBElement<Address1> createAddress1(Address1 value) {
        return new JAXBElement<Address1>(_Address1_QNAME, Address1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-2")
    public JAXBElement<Address2> createAddress2(Address2 value) {
        return new JAXBElement<Address2>(_Address2_QNAME, Address2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address3 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-3")
    public JAXBElement<Address3> createAddress3(Address3 value) {
        return new JAXBElement<Address3>(_Address3_QNAME, Address3 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mailcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mailcode")
    public JAXBElement<Mailcode> createMailcode(Mailcode value) {
        return new JAXBElement<Mailcode>(_Mailcode_QNAME, Mailcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pobox }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pobox")
    public JAXBElement<Pobox> createPobox(Pobox value) {
        return new JAXBElement<Pobox>(_Pobox_QNAME, Pobox.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Room }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "room")
    public JAXBElement<Room> createRoom(Room value) {
        return new JAXBElement<Room>(_Room_QNAME, Room.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFloor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-floor")
    public JAXBElement<AddressFloor> createAddressFloor(AddressFloor value) {
        return new JAXBElement<AddressFloor>(_AddressFloor_QNAME, AddressFloor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Building }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "building")
    public JAXBElement<Building> createBuilding(Building value) {
        return new JAXBElement<Building>(_Building_QNAME, Building.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Street }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "street")
    public JAXBElement<Street> createStreet(Street value) {
        return new JAXBElement<Street>(_Street_QNAME, Street.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link City }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "city")
    public JAXBElement<City> createCity(City value) {
        return new JAXBElement<City>(_City_QNAME, City.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link County }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "county")
    public JAXBElement<County> createCounty(County value) {
        return new JAXBElement<County>(_County_QNAME, County.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link State }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state")
    public JAXBElement<State> createState(State value) {
        return new JAXBElement<State>(_State_QNAME, State.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Postcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postcode")
    public JAXBElement<Postcode> createPostcode(Postcode value) {
        return new JAXBElement<Postcode>(_Postcode_QNAME, Postcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country")
    public JAXBElement<String> createCountry(String value) {
        return new JAXBElement<String>(_Country_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Text }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "text")
    public JAXBElement<Text> createText(Text value) {
        return new JAXBElement<Text>(_Text_QNAME, Text.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Phone }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "phone")
    public JAXBElement<Phone> createPhone(Phone value) {
        return new JAXBElement<Phone>(_Phone_QNAME, Phone.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fax }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fax")
    public JAXBElement<Fax> createFax(Fax value) {
        return new JAXBElement<Fax>(_Fax_QNAME, Fax.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Email }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "email")
    public JAXBElement<Email> createEmail(Email value) {
        return new JAXBElement<Email>(_Email_QNAME, Email.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Url }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "url")
    public JAXBElement<Url> createUrl(Url value) {
        return new JAXBElement<Url>(_Url_QNAME, Url.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ead }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ead")
    public JAXBElement<Ead> createEad(Ead value) {
        return new JAXBElement<Ead>(_Ead_QNAME, Ead.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dtext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dtext")
    public JAXBElement<Dtext> createDtext(Dtext value) {
        return new JAXBElement<Dtext>(_Dtext_QNAME, Dtext.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Issue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issue")
    public JAXBElement<Issue> createIssue(Issue value) {
        return new JAXBElement<Issue>(_Issue_QNAME, Issue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Imprint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "imprint")
    public JAXBElement<Imprint> createImprint(Imprint value) {
        return new JAXBElement<Imprint>(_Imprint_QNAME, Imprint.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pubdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pubdate")
    public JAXBElement<Pubdate> createPubdate(Pubdate value) {
        return new JAXBElement<Pubdate>(_Pubdate_QNAME, Pubdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sdate")
    public JAXBElement<Sdate> createSdate(Sdate value) {
        return new JAXBElement<Sdate>(_Sdate_QNAME, Sdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Edate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edate")
    public JAXBElement<Edate> createEdate(Edate value) {
        return new JAXBElement<Edate>(_Edate_QNAME, Edate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Time }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "time")
    public JAXBElement<Time> createTime(Time value) {
        return new JAXBElement<Time>(_Time_QNAME, Time.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Descrip }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "descrip")
    public JAXBElement<Descrip> createDescrip(Descrip value) {
        return new JAXBElement<Descrip>(_Descrip_QNAME, Descrip.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notes")
    public JAXBElement<Notes> createNotes(Notes value) {
        return new JAXBElement<Notes>(_Notes_QNAME, Notes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Issn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issn")
    public JAXBElement<Issn> createIssn(Issn value) {
        return new JAXBElement<Issn>(_Issn_QNAME, Issn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Isbn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "isbn")
    public JAXBElement<Isbn> createIsbn(Isbn value) {
        return new JAXBElement<Isbn>(_Isbn_QNAME, Isbn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pubid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pubid")
    public JAXBElement<Pubid> createPubid(Pubid value) {
        return new JAXBElement<Pubid>(_Pubid_QNAME, Pubid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Vid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "vid")
    public JAXBElement<Vid> createVid(Vid value) {
        return new JAXBElement<Vid>(_Vid_QNAME, Vid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ino }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ino")
    public JAXBElement<Ino> createIno(Ino value) {
        return new JAXBElement<Ino>(_Ino_QNAME, Ino.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cpyrt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cpyrt")
    public JAXBElement<Cpyrt> createCpyrt(Cpyrt value) {
        return new JAXBElement<Cpyrt>(_Cpyrt_QNAME, Cpyrt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "document-id")
    public JAXBElement<DocumentId> createDocumentId(DocumentId value) {
        return new JAXBElement<DocumentId>(_DocumentId_QNAME, DocumentId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-number")
    public JAXBElement<DocNumber> createDocNumber(DocNumber value) {
        return new JAXBElement<DocNumber>(_DocNumber_QNAME, DocNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Kind }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "kind")
    public JAXBElement<Kind> createKind(Kind value) {
        return new JAXBElement<Kind>(_Kind_QNAME, Kind.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Date }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date")
    public JAXBElement<Date> createDate(Date value) {
        return new JAXBElement<Date>(_Date_QNAME, Date.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OfficeOfFiling }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "office-of-filing")
    public JAXBElement<OfficeOfFiling> createOfficeOfFiling(OfficeOfFiling value) {
        return new JAXBElement<OfficeOfFiling>(_OfficeOfFiling_QNAME, OfficeOfFiling.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Region }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "region")
    public JAXBElement<Region> createRegion(Region value) {
        return new JAXBElement<Region>(_Region_QNAME, Region.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityDocRequested }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority-doc-requested")
    public JAXBElement<PriorityDocRequested> createPriorityDocRequested(PriorityDocRequested value) {
        return new JAXBElement<PriorityDocRequested>(_PriorityDocRequested_QNAME, PriorityDocRequested.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityDocAttached }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority-doc-attached")
    public JAXBElement<PriorityDocAttached> createPriorityDocAttached(PriorityDocAttached value) {
        return new JAXBElement<PriorityDocAttached>(_PriorityDocAttached_QNAME, PriorityDocAttached.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Class }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "class")
    public JAXBElement<Class> createClass(Class value) {
        return new JAXBElement<Class>(_Class_QNAME, Class.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationDataSource }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-data-source")
    public JAXBElement<ClassificationDataSource> createClassificationDataSource(ClassificationDataSource value) {
        return new JAXBElement<ClassificationDataSource>(_ClassificationDataSource_QNAME, ClassificationDataSource.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-status")
    public JAXBElement<ClassificationStatus> createClassificationStatus(ClassificationStatus value) {
        return new JAXBElement<ClassificationStatus>(_ClassificationStatus_QNAME, ClassificationStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GeneratingOffice }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "generating-office")
    public JAXBElement<GeneratingOffice> createGeneratingOffice(GeneratingOffice value) {
        return new JAXBElement<GeneratingOffice>(_GeneratingOffice_QNAME, GeneratingOffice.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActionDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "action-date")
    public JAXBElement<ActionDate> createActionDate(ActionDate value) {
        return new JAXBElement<ActionDate>(_ActionDate_QNAME, ActionDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationValue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-value")
    public JAXBElement<ClassificationValue> createClassificationValue(ClassificationValue value) {
        return new JAXBElement<ClassificationValue>(_ClassificationValue_QNAME, ClassificationValue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SymbolPosition }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "symbol-position")
    public JAXBElement<SymbolPosition> createSymbolPosition(SymbolPosition value) {
        return new JAXBElement<SymbolPosition>(_SymbolPosition_QNAME, SymbolPosition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subgroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subgroup")
    public JAXBElement<Subgroup> createSubgroup(Subgroup value) {
        return new JAXBElement<Subgroup>(_Subgroup_QNAME, Subgroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "main-group")
    public JAXBElement<MainGroup> createMainGroup(MainGroup value) {
        return new JAXBElement<MainGroup>(_MainGroup_QNAME, MainGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subclass }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subclass")
    public JAXBElement<Subclass> createSubclass(Subclass value) {
        return new JAXBElement<Subclass>(_Subclass_QNAME, Subclass.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Section }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "section")
    public JAXBElement<Section> createSection(Section value) {
        return new JAXBElement<Section>(_Section_QNAME, Section.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationLevel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-level")
    public JAXBElement<ClassificationLevel> createClassificationLevel(ClassificationLevel value) {
        return new JAXBElement<ClassificationLevel>(_ClassificationLevel_QNAME, ClassificationLevel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IpcVersionIndicator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ipc-version-indicator")
    public JAXBElement<IpcVersionIndicator> createIpcVersionIndicator(IpcVersionIndicator value) {
        return new JAXBElement<IpcVersionIndicator>(_IpcVersionIndicator_QNAME, IpcVersionIndicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link B }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b")
    public JAXBElement<B> createB(B value) {
        return new JAXBElement<B>(_B_QNAME, B.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link I }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i")
    public JAXBElement<I> createI(I value) {
        return new JAXBElement<I>(_I_QNAME, I.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link U }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u")
    public JAXBElement<U> createU(U value) {
        return new JAXBElement<U>(_U_QNAME, U.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Smallcaps }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps")
    public JAXBElement<Smallcaps> createSmallcaps(Smallcaps value) {
        return new JAXBElement<Smallcaps>(_Smallcaps_QNAME, Smallcaps.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup")
    public JAXBElement<Sup> createSup(Sup value) {
        return new JAXBElement<Sup>(_Sup_QNAME, Sup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub")
    public JAXBElement<Sub> createSub(Sub value) {
        return new JAXBElement<Sub>(_Sub_QNAME, Sub.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Patcit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit")
    public JAXBElement<Patcit> createPatcit(Patcit value) {
        return new JAXBElement<Patcit>(_Patcit_QNAME, Patcit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelPassage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rel-passage")
    public JAXBElement<RelPassage> createRelPassage(RelPassage value) {
        return new JAXBElement<RelPassage>(_RelPassage_QNAME, RelPassage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Passage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "passage")
    public JAXBElement<Passage> createPassage(Passage value) {
        return new JAXBElement<Passage>(_Passage_QNAME, Passage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Category }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "category")
    public JAXBElement<Category> createCategory(Category value) {
        return new JAXBElement<Category>(_Category_QNAME, Category.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelClaims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rel-claims")
    public JAXBElement<RelClaims> createRelClaims(RelClaims value) {
        return new JAXBElement<RelClaims>(_RelClaims_QNAME, RelClaims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Nplcit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit")
    public JAXBElement<Nplcit> createNplcit(Nplcit value) {
        return new JAXBElement<Nplcit>(_Nplcit_QNAME, Nplcit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Article }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "article")
    public JAXBElement<Article> createArticle(Article value) {
        return new JAXBElement<Article>(_Article_QNAME, Article.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Author }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "author")
    public JAXBElement<Author> createAuthor(Author value) {
        return new JAXBElement<Author>(_Author_QNAME, Author.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Atl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "atl")
    public JAXBElement<Atl> createAtl(Atl value) {
        return new JAXBElement<Atl>(_Atl_QNAME, Atl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Book }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "book")
    public JAXBElement<Book> createBook(Book value) {
        return new JAXBElement<Book>(_Book_QNAME, Book.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BookTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "book-title")
    public JAXBElement<BookTitle> createBookTitle(BookTitle value) {
        return new JAXBElement<BookTitle>(_BookTitle_QNAME, BookTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Conference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conference")
    public JAXBElement<Conference> createConference(Conference value) {
        return new JAXBElement<Conference>(_Conference_QNAME, Conference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Conftitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conftitle")
    public JAXBElement<Conftitle> createConftitle(Conftitle value) {
        return new JAXBElement<Conftitle>(_Conftitle_QNAME, Conftitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confno")
    public JAXBElement<Confno> createConfno(Confno value) {
        return new JAXBElement<Confno>(_Confno_QNAME, Confno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confplace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confplace")
    public JAXBElement<Confplace> createConfplace(Confplace value) {
        return new JAXBElement<Confplace>(_Confplace_QNAME, Confplace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confsponsor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confsponsor")
    public JAXBElement<Confsponsor> createConfsponsor(Confsponsor value) {
        return new JAXBElement<Confsponsor>(_Confsponsor_QNAME, Confsponsor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subtitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subtitle")
    public JAXBElement<Subtitle> createSubtitle(Subtitle value) {
        return new JAXBElement<Subtitle>(_Subtitle_QNAME, Subtitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Edition }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edition")
    public JAXBElement<Edition> createEdition(Edition value) {
        return new JAXBElement<Edition>(_Edition_QNAME, Edition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Series }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "series")
    public JAXBElement<Series> createSeries(Series value) {
        return new JAXBElement<Series>(_Series_QNAME, Series.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mst }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mst")
    public JAXBElement<Mst> createMst(Mst value) {
        return new JAXBElement<Mst>(_Mst_QNAME, Mst.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msn")
    public JAXBElement<Msn> createMsn(Msn value) {
        return new JAXBElement<Msn>(_Msn_QNAME, Msn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Absno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "absno")
    public JAXBElement<Absno> createAbsno(Absno value) {
        return new JAXBElement<Absno>(_Absno_QNAME, Absno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Location }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "location")
    public JAXBElement<Location> createLocation(Location value) {
        return new JAXBElement<Location>(_Location_QNAME, Location.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Serpart }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "serpart")
    public JAXBElement<Serpart> createSerpart(Serpart value) {
        return new JAXBElement<Serpart>(_Serpart_QNAME, Serpart.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sersect }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sersect")
    public JAXBElement<Sersect> createSersect(Sersect value) {
        return new JAXBElement<Sersect>(_Sersect_QNAME, Sersect.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chapter }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chapter")
    public JAXBElement<Chapter> createChapter(Chapter value) {
        return new JAXBElement<Chapter>(_Chapter_QNAME, Chapter.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pp")
    public JAXBElement<Pp> createPp(Pp value) {
        return new JAXBElement<Pp>(_Pp_QNAME, Pp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ppf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppf")
    public JAXBElement<Ppf> createPpf(Ppf value) {
        return new JAXBElement<Ppf>(_Ppf_QNAME, Ppf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ppl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppl")
    public JAXBElement<Ppl> createPpl(Ppl value) {
        return new JAXBElement<Ppl>(_Ppl_QNAME, Ppl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Column }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "column")
    public JAXBElement<Column> createColumn(Column value) {
        return new JAXBElement<Column>(_Column_QNAME, Column.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Colf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colf")
    public JAXBElement<Colf> createColf(Colf value) {
        return new JAXBElement<Colf>(_Colf_QNAME, Colf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Coll }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coll")
    public JAXBElement<Coll> createColl(Coll value) {
        return new JAXBElement<Coll>(_Coll_QNAME, Coll.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Para }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "para")
    public JAXBElement<Para> createPara(Para value) {
        return new JAXBElement<Para>(_Para_QNAME, Para.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Paraf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paraf")
    public JAXBElement<Paraf> createParaf(Paraf value) {
        return new JAXBElement<Paraf>(_Paraf_QNAME, Paraf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Paral }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paral")
    public JAXBElement<Paral> createParal(Paral value) {
        return new JAXBElement<Paral>(_Paral_QNAME, Paral.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Line }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "line")
    public JAXBElement<Line> createLine(Line value) {
        return new JAXBElement<Line>(_Line_QNAME, Line.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Linef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linef")
    public JAXBElement<Linef> createLinef(Linef value) {
        return new JAXBElement<Linef>(_Linef_QNAME, Linef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Linel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linel")
    public JAXBElement<Linel> createLinel(Linel value) {
        return new JAXBElement<Linel>(_Linel_QNAME, Linel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Bookno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bookno")
    public JAXBElement<Bookno> createBookno(Bookno value) {
        return new JAXBElement<Bookno>(_Bookno_QNAME, Bookno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Keyword }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "keyword")
    public JAXBElement<Keyword> createKeyword(Keyword value) {
        return new JAXBElement<Keyword>(_Keyword_QNAME, Keyword.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Refno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "refno")
    public JAXBElement<Refno> createRefno(Refno value) {
        return new JAXBElement<Refno>(_Refno_QNAME, Refno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Artid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "artid")
    public JAXBElement<Artid> createArtid(Artid value) {
        return new JAXBElement<Artid>(_Artid_QNAME, Artid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Online }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "online")
    public JAXBElement<Online> createOnline(Online value) {
        return new JAXBElement<Online>(_Online_QNAME, Online.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnlineTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "online-title")
    public JAXBElement<OnlineTitle> createOnlineTitle(OnlineTitle value) {
        return new JAXBElement<OnlineTitle>(_OnlineTitle_QNAME, OnlineTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Hosttitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hosttitle")
    public JAXBElement<Hosttitle> createHosttitle(Hosttitle value) {
        return new JAXBElement<Hosttitle>(_Hosttitle_QNAME, Hosttitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link History }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "history")
    public JAXBElement<History> createHistory(History value) {
        return new JAXBElement<History>(_History_QNAME, History.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Received }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "received")
    public JAXBElement<Received> createReceived(Received value) {
        return new JAXBElement<Received>(_Received_QNAME, Received.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Accepted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accepted")
    public JAXBElement<Accepted> createAccepted(Accepted value) {
        return new JAXBElement<Accepted>(_Accepted_QNAME, Accepted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Revised }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "revised")
    public JAXBElement<Revised> createRevised(Revised value) {
        return new JAXBElement<Revised>(_Revised_QNAME, Revised.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Misc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "misc")
    public JAXBElement<Misc> createMisc(Misc value) {
        return new JAXBElement<Misc>(_Misc_QNAME, Misc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Hostno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hostno")
    public JAXBElement<Hostno> createHostno(Hostno value) {
        return new JAXBElement<Hostno>(_Hostno_QNAME, Hostno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Avail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "avail")
    public JAXBElement<Avail> createAvail(Avail value) {
        return new JAXBElement<Avail>(_Avail_QNAME, Avail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Datecit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "datecit")
    public JAXBElement<Datecit> createDatecit(Datecit value) {
        return new JAXBElement<Datecit>(_Datecit_QNAME, Datecit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Srchterm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "srchterm")
    public JAXBElement<Srchterm> createSrchterm(Srchterm value) {
        return new JAXBElement<Srchterm>(_Srchterm_QNAME, Srchterm.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Srchdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "srchdate")
    public JAXBElement<Srchdate> createSrchdate(Srchdate value) {
        return new JAXBElement<Srchdate>(_Srchdate_QNAME, Srchdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Othercit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "othercit")
    public JAXBElement<Othercit> createOthercit(Othercit value) {
        return new JAXBElement<Othercit>(_Othercit_QNAME, Othercit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateSearchCompleted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date-search-completed")
    public JAXBElement<DateSearchCompleted> createDateSearchCompleted(DateSearchCompleted value) {
        return new JAXBElement<DateSearchCompleted>(_DateSearchCompleted_QNAME, DateSearchCompleted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateSearchReportMailed }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date-search-report-mailed")
    public JAXBElement<DateSearchReportMailed> createDateSearchReportMailed(DateSearchReportMailed value) {
        return new JAXBElement<DateSearchReportMailed>(_DateSearchReportMailed_QNAME, DateSearchReportMailed.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PlaceOfSearch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "place-of-search")
    public JAXBElement<PlaceOfSearch> createPlaceOfSearch(PlaceOfSearch value) {
        return new JAXBElement<PlaceOfSearch>(_PlaceOfSearch_QNAME, PlaceOfSearch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchReportPublication }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "search-report-publication")
    public JAXBElement<SearchReportPublication> createSearchReportPublication(SearchReportPublication value) {
        return new JAXBElement<SearchReportPublication>(_SearchReportPublication_QNAME, SearchReportPublication.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Searcher }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "searcher")
    public JAXBElement<Searcher> createSearcher(Searcher value) {
        return new JAXBElement<Searcher>(_Searcher_QNAME, Searcher.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IpcVersion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ipc-version")
    public JAXBElement<IpcVersion> createIpcVersion(IpcVersion value) {
        return new JAXBElement<IpcVersion>(_IpcVersion_QNAME, IpcVersion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainClassification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "main-classification")
    public JAXBElement<MainClassification> createMainClassification(MainClassification value) {
        return new JAXBElement<MainClassification>(_MainClassification_QNAME, MainClassification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FurtherClassification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "further-classification")
    public JAXBElement<FurtherClassification> createFurtherClassification(FurtherClassification value) {
        return new JAXBElement<FurtherClassification>(_FurtherClassification_QNAME, FurtherClassification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdditionalInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "additional-info")
    public JAXBElement<AdditionalInfo> createAdditionalInfo(AdditionalInfo value) {
        return new JAXBElement<AdditionalInfo>(_AdditionalInfo_QNAME, AdditionalInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinkedIndexingCodeGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linked-indexing-code-group")
    public JAXBElement<LinkedIndexingCodeGroup> createLinkedIndexingCodeGroup(LinkedIndexingCodeGroup value) {
        return new JAXBElement<LinkedIndexingCodeGroup>(_LinkedIndexingCodeGroup_QNAME, LinkedIndexingCodeGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainLinkedIndexingCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "main-linked-indexing-code")
    public JAXBElement<MainLinkedIndexingCode> createMainLinkedIndexingCode(MainLinkedIndexingCode value) {
        return new JAXBElement<MainLinkedIndexingCode>(_MainLinkedIndexingCode_QNAME, MainLinkedIndexingCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubLinkedIndexingCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub-linked-indexing-code")
    public JAXBElement<SubLinkedIndexingCode> createSubLinkedIndexingCode(SubLinkedIndexingCode value) {
        return new JAXBElement<SubLinkedIndexingCode>(_SubLinkedIndexingCode_QNAME, SubLinkedIndexingCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlinkedIndexingCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unlinked-indexing-code")
    public JAXBElement<UnlinkedIndexingCode> createUnlinkedIndexingCode(UnlinkedIndexingCode value) {
        return new JAXBElement<UnlinkedIndexingCode>(_UnlinkedIndexingCode_QNAME, UnlinkedIndexingCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrespondingDocs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "corresponding-docs")
    public JAXBElement<CorrespondingDocs> createCorrespondingDocs(CorrespondingDocs value) {
        return new JAXBElement<CorrespondingDocs>(_CorrespondingDocs_QNAME, CorrespondingDocs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationNational }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-national")
    public JAXBElement<ClassificationNational> createClassificationNational(ClassificationNational value) {
        return new JAXBElement<ClassificationNational>(_ClassificationNational_QNAME, ClassificationNational.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Substitution }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "substitution")
    public JAXBElement<Substitution> createSubstitution(Substitution value) {
        return new JAXBElement<Substitution>(_Substitution_QNAME, Substitution.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnDomesticPriorityClaim }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-domestic-priority-claim")
    public JAXBElement<CnDomesticPriorityClaim> createCnDomesticPriorityClaim(CnDomesticPriorityClaim value) {
        return new JAXBElement<CnDomesticPriorityClaim>(_CnDomesticPriorityClaim_QNAME, CnDomesticPriorityClaim.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnDomesticPriorityClaims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-domestic-priority-claims")
    public JAXBElement<CnDomesticPriorityClaims> createCnDomesticPriorityClaims(CnDomesticPriorityClaims value) {
        return new JAXBElement<CnDomesticPriorityClaims>(_CnDomesticPriorityClaims_QNAME, CnDomesticPriorityClaims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Relation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "relation")
    public JAXBElement<Relation> createRelation(Relation value) {
        return new JAXBElement<Relation>(_Relation_QNAME, Relation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParentDoc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "parent-doc")
    public JAXBElement<ParentDoc> createParentDoc(ParentDoc value) {
        return new JAXBElement<ParentDoc>(_ParentDoc_QNAME, ParentDoc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParentPctDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "parent-pct-document")
    public JAXBElement<ParentPctDocument> createParentPctDocument(ParentPctDocument value) {
        return new JAXBElement<ParentPctDocument>(_ParentPctDocument_QNAME, ParentPctDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParentStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "parent-status")
    public JAXBElement<ParentStatus> createParentStatus(ParentStatus value) {
        return new JAXBElement<ParentStatus>(_ParentStatus_QNAME, ParentStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParentGrantDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "parent-grant-document")
    public JAXBElement<ParentGrantDocument> createParentGrantDocument(ParentGrantDocument value) {
        return new JAXBElement<ParentGrantDocument>(_ParentGrantDocument_QNAME, ParentGrantDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChildDoc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "child-doc")
    public JAXBElement<ChildDoc> createChildDoc(ChildDoc value) {
        return new JAXBElement<ChildDoc>(_ChildDoc_QNAME, ChildDoc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnApplicants }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-applicants")
    public JAXBElement<CnApplicants> createCnApplicants(CnApplicants value) {
        return new JAXBElement<CnApplicants>(_CnApplicants_QNAME, CnApplicants.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnApplicant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-applicant")
    public JAXBElement<CnApplicant> createCnApplicant(CnApplicant value) {
        return new JAXBElement<CnApplicant>(_CnApplicant_QNAME, CnApplicant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Nationality }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nationality")
    public JAXBElement<Nationality> createNationality(Nationality value) {
        return new JAXBElement<Nationality>(_Nationality_QNAME, Nationality.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Residence }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "residence")
    public JAXBElement<Residence> createResidence(Residence value) {
        return new JAXBElement<Residence>(_Residence_QNAME, Residence.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnInventors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-inventors")
    public JAXBElement<CnInventors> createCnInventors(CnInventors value) {
        return new JAXBElement<CnInventors>(_CnInventors_QNAME, CnInventors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnInventor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-inventor")
    public JAXBElement<CnInventor> createCnInventor(CnInventor value) {
        return new JAXBElement<CnInventor>(_CnInventor_QNAME, CnInventor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrespondenceAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "correspondence-address")
    public JAXBElement<CorrespondenceAddress> createCorrespondenceAddress(CorrespondenceAddress value) {
        return new JAXBElement<CorrespondenceAddress>(_CorrespondenceAddress_QNAME, CorrespondenceAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomerNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "customer-number")
    public JAXBElement<CustomerNumber> createCustomerNumber(CustomerNumber value) {
        return new JAXBElement<CustomerNumber>(_CustomerNumber_QNAME, CustomerNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnAgents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-agents")
    public JAXBElement<CnAgents> createCnAgents(CnAgents value) {
        return new JAXBElement<CnAgents>(_CnAgents_QNAME, CnAgents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnAgent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-agent")
    public JAXBElement<CnAgent> createCnAgent(CnAgent value) {
        return new JAXBElement<CnAgent>(_CnAgent_QNAME, CnAgent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnAgency }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-agency")
    public JAXBElement<CnAgency> createCnAgency(CnAgency value) {
        return new JAXBElement<CnAgency>(_CnAgency_QNAME, CnAgency.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationBody }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "application-body")
    public JAXBElement<ApplicationBody> createApplicationBody(ApplicationBody value) {
        return new JAXBElement<ApplicationBody>(_ApplicationBody_QNAME, ApplicationBody.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Figure }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figure")
    public JAXBElement<Figure> createFigure(Figure value) {
        return new JAXBElement<Figure>(_Figure_QNAME, Figure.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstSolution }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abst-solution")
    public JAXBElement<AbstSolution> createAbstSolution(AbstSolution value) {
        return new JAXBElement<AbstSolution>(_AbstSolution_QNAME, AbstSolution.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstProblem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abst-problem")
    public JAXBElement<AbstProblem> createAbstProblem(AbstProblem value) {
        return new JAXBElement<AbstProblem>(_AbstProblem_QNAME, AbstProblem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Claim }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim")
    public JAXBElement<Claim> createClaim(Claim value) {
        return new JAXBElement<Claim>(_Claim_QNAME, Claim.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim-ref")
    public JAXBElement<ClaimRef> createClaimRef(ClaimRef value) {
        return new JAXBElement<ClaimRef>(_ClaimRef_QNAME, ClaimRef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sequence-list-text")
    public JAXBElement<SequenceListText> createSequenceListText(SequenceListText value) {
        return new JAXBElement<SequenceListText>(_SequenceListText_QNAME, SequenceListText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IndustrialApplicability }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "industrial-applicability")
    public JAXBElement<IndustrialApplicability> createIndustrialApplicability(IndustrialApplicability value) {
        return new JAXBElement<IndustrialApplicability>(_IndustrialApplicability_QNAME, IndustrialApplicability.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModeForInvention }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mode-for-invention")
    public JAXBElement<ModeForInvention> createModeForInvention(ModeForInvention value) {
        return new JAXBElement<ModeForInvention>(_ModeForInvention_QNAME, ModeForInvention.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BestMode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "best-mode")
    public JAXBElement<BestMode> createBestMode(BestMode value) {
        return new JAXBElement<BestMode>(_BestMode_QNAME, BestMode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Disclosure }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "disclosure")
    public JAXBElement<Disclosure> createDisclosure(Disclosure value) {
        return new JAXBElement<Disclosure>(_Disclosure_QNAME, Disclosure.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdvantageousEffects }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "advantageous-effects")
    public JAXBElement<AdvantageousEffects> createAdvantageousEffects(AdvantageousEffects value) {
        return new JAXBElement<AdvantageousEffects>(_AdvantageousEffects_QNAME, AdvantageousEffects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechSolution }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tech-solution")
    public JAXBElement<TechSolution> createTechSolution(TechSolution value) {
        return new JAXBElement<TechSolution>(_TechSolution_QNAME, TechSolution.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechProblem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tech-problem")
    public JAXBElement<TechProblem> createTechProblem(TechProblem value) {
        return new JAXBElement<TechProblem>(_TechProblem_QNAME, TechProblem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DescriptionOfDrawings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description-of-drawings")
    public JAXBElement<DescriptionOfDrawings> createDescriptionOfDrawings(DescriptionOfDrawings value) {
        return new JAXBElement<DescriptionOfDrawings>(_DescriptionOfDrawings_QNAME, DescriptionOfDrawings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BackgroundArt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "background-art")
    public JAXBElement<BackgroundArt> createBackgroundArt(BackgroundArt value) {
        return new JAXBElement<BackgroundArt>(_BackgroundArt_QNAME, BackgroundArt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechnicalField }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "technical-field")
    public JAXBElement<TechnicalField> createTechnicalField(TechnicalField value) {
        return new JAXBElement<TechnicalField>(_TechnicalField_QNAME, TechnicalField.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre")
    public JAXBElement<Pre> createPre(Pre value) {
        return new JAXBElement<Pre>(_Pre_QNAME, Pre.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link P }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "p")
    public JAXBElement<P> createP(P value) {
        return new JAXBElement<P>(_P_QNAME, P.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableExternalDoc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table-external-doc")
    public JAXBElement<TableExternalDoc> createTableExternalDoc(TableExternalDoc value) {
        return new JAXBElement<TableExternalDoc>(_TableExternalDoc_QNAME, TableExternalDoc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tables }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tables")
    public JAXBElement<Tables> createTables(Tables value) {
        return new JAXBElement<Tables>(_Tables_QNAME, Tables.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Figref }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref")
    public JAXBElement<Figref> createFigref(Figref value) {
        return new JAXBElement<Figref>(_Figref_QNAME, Figref.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl")
    public JAXBElement<Dl> createDl(Dl value) {
        return new JAXBElement<Dl>(_Dl_QNAME, Dl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dt")
    public JAXBElement<Dt> createDt(Dt value) {
        return new JAXBElement<Dt>(_Dt_QNAME, Dt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ul }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul")
    public JAXBElement<Ul> createUl(Ul value) {
        return new JAXBElement<Ul>(_Ul_QNAME, Ul.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Li }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "li")
    public JAXBElement<Li> createLi(Li value) {
        return new JAXBElement<Li>(_Li_QNAME, Li.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Maths }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths")
    public JAXBElement<Maths> createMaths(Maths value) {
        return new JAXBElement<Maths>(_Maths_QNAME, Maths.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chemistry }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry")
    public JAXBElement<Chemistry> createChemistry(Chemistry value) {
        return new JAXBElement<Chemistry>(_Chemistry_QNAME, Chemistry.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chem")
    public JAXBElement<Chem> createChem(Chem value) {
        return new JAXBElement<Chem>(_Chem_QNAME, Chem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ol }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol")
    public JAXBElement<Ol> createOl(Ol value) {
        return new JAXBElement<Ol>(_Ol_QNAME, Ol.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Img }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img")
    public JAXBElement<Img> createImg(Img value) {
        return new JAXBElement<Img>(_Img_QNAME, Img.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Crossref }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref")
    public JAXBElement<Crossref> createCrossref(Crossref value) {
        return new JAXBElement<Crossref>(_Crossref_QNAME, Crossref.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Heading }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "heading")
    public JAXBElement<Heading> createHeading(Heading value) {
        return new JAXBElement<Heading>(_Heading_QNAME, Heading.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocPage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-page")
    public JAXBElement<DocPage> createDocPage(DocPage value) {
        return new JAXBElement<DocPage>(_DocPage_QNAME, DocPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Drawings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "drawings")
    public JAXBElement<Drawings> createDrawings(Drawings value) {
        return new JAXBElement<Drawings>(_Drawings_QNAME, Drawings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnAbstractDrawing }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-abstract-drawing")
    public JAXBElement<CnAbstractDrawing> createCnAbstractDrawing(CnAbstractDrawing value) {
        return new JAXBElement<CnAbstractDrawing>(_CnAbstractDrawing_QNAME, CnAbstractDrawing.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Abstract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abstract")
    public JAXBElement<Abstract> createAbstract(Abstract value) {
        return new JAXBElement<Abstract>(_Abstract_QNAME, Abstract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Claims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claims")
    public JAXBElement<Claims> createClaims(Claims value) {
        return new JAXBElement<Claims>(_Claims_QNAME, Claims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim-text")
    public JAXBElement<ClaimText> createClaimText(ClaimText value) {
        return new JAXBElement<ClaimText>(_ClaimText_QNAME, ClaimText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Br }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br")
    public JAXBElement<Br> createBr(Br value) {
        return new JAXBElement<Br>(_Br_QNAME, Br.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Description }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description")
    public JAXBElement<Description> createDescription(Description value) {
        return new JAXBElement<Description>(_Description_QNAME, Description.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dd")
    public JAXBElement<Dd> createDd(Dd value) {
        return new JAXBElement<Dd>(_Dd_QNAME, Dd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDeposit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit")
    public JAXBElement<BioDeposit> createBioDeposit(BioDeposit value) {
        return new JAXBElement<BioDeposit>(_BioDeposit_QNAME, BioDeposit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Depositary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "depositary")
    public JAXBElement<Depositary> createDepositary(Depositary value) {
        return new JAXBElement<Depositary>(_Depositary_QNAME, Depositary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioAccno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-accno")
    public JAXBElement<BioAccno> createBioAccno(BioAccno value) {
        return new JAXBElement<BioAccno>(_BioAccno_QNAME, BioAccno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Term }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "term")
    public JAXBElement<Term> createTerm(Term value) {
        return new JAXBElement<Term>(_Term_QNAME, Term.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnRelatedDocuments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn-related-documents")
    public JAXBElement<CnRelatedDocuments> createCnRelatedDocuments(CnRelatedDocuments value) {
        return new JAXBElement<CnRelatedDocuments>(_CnRelatedDocuments_QNAME, CnRelatedDocuments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Assignees }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "assignees")
    public JAXBElement<Assignees> createAssignees(Assignees value) {
        return new JAXBElement<Assignees>(_Assignees_QNAME, Assignees.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Assignee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "assignee")
    public JAXBElement<Assignee> createAssignee(Assignee value) {
        return new JAXBElement<Assignee>(_Assignee_QNAME, Assignee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Table }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table")
    public JAXBElement<Table> createTable(Table value) {
        return new JAXBElement<Table>(_Table_QNAME, Table.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tgroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tgroup")
    public JAXBElement<Tgroup> createTgroup(Tgroup value) {
        return new JAXBElement<Tgroup>(_Tgroup_QNAME, Tgroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Colspec }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colspec")
    public JAXBElement<Colspec> createColspec(Colspec value) {
        return new JAXBElement<Colspec>(_Colspec_QNAME, Colspec.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Thead }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "thead")
    public JAXBElement<Thead> createThead(Thead value) {
        return new JAXBElement<Thead>(_Thead_QNAME, Thead.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tbody }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tbody")
    public JAXBElement<Tbody> createTbody(Tbody value) {
        return new JAXBElement<Tbody>(_Tbody_QNAME, Tbody.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Row }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "row")
    public JAXBElement<Row> createRow(Row value) {
        return new JAXBElement<Row>(_Row_QNAME, Row.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Entry }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "entry")
    public JAXBElement<Entry> createEntry(Entry value) {
        return new JAXBElement<Entry>(_Entry_QNAME, Entry.class, null, value);
    }

}
