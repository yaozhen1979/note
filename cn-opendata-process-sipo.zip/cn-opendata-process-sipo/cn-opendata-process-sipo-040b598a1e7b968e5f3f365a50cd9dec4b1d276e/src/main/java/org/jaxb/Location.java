//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>location complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="location"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}serpart" minOccurs="0"/&gt;
 *           &lt;element ref="{}sersect" minOccurs="0"/&gt;
 *           &lt;element ref="{}chapter" minOccurs="0"/&gt;
 *           &lt;element ref="{}pp" minOccurs="0"/&gt;
 *           &lt;element ref="{}column" minOccurs="0"/&gt;
 *           &lt;element ref="{}para" minOccurs="0"/&gt;
 *           &lt;element ref="{}line" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "location", propOrder = {
    "text",
    "serpart",
    "sersect",
    "chapter",
    "pp",
    "column",
    "para",
    "line"
})
public class Location {

    protected Text text;
    protected Serpart serpart;
    protected Sersect sersect;
    protected Chapter chapter;
    protected Pp pp;
    protected Column column;
    protected Para para;
    protected Line line;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * 取得 serpart 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Serpart }
     *     
     */
    public Serpart getSerpart() {
        return serpart;
    }

    /**
     * 設定 serpart 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Serpart }
     *     
     */
    public void setSerpart(Serpart value) {
        this.serpart = value;
    }

    /**
     * 取得 sersect 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Sersect }
     *     
     */
    public Sersect getSersect() {
        return sersect;
    }

    /**
     * 設定 sersect 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Sersect }
     *     
     */
    public void setSersect(Sersect value) {
        this.sersect = value;
    }

    /**
     * 取得 chapter 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Chapter }
     *     
     */
    public Chapter getChapter() {
        return chapter;
    }

    /**
     * 設定 chapter 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Chapter }
     *     
     */
    public void setChapter(Chapter value) {
        this.chapter = value;
    }

    /**
     * 取得 pp 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pp }
     *     
     */
    public Pp getPp() {
        return pp;
    }

    /**
     * 設定 pp 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pp }
     *     
     */
    public void setPp(Pp value) {
        this.pp = value;
    }

    /**
     * 取得 column 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Column }
     *     
     */
    public Column getColumn() {
        return column;
    }

    /**
     * 設定 column 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Column }
     *     
     */
    public void setColumn(Column value) {
        this.column = value;
    }

    /**
     * 取得 para 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Para }
     *     
     */
    public Para getPara() {
        return para;
    }

    /**
     * 設定 para 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Para }
     *     
     */
    public void setPara(Para value) {
        this.para = value;
    }

    /**
     * 取得 line 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Line }
     *     
     */
    public Line getLine() {
        return line;
    }

    /**
     * 設定 line 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Line }
     *     
     */
    public void setLine(Line value) {
        this.line = value;
    }

}
