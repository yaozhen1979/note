//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>address complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="address"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;sequence&gt;
 *             &lt;element ref="{}address-1" minOccurs="0"/&gt;
 *             &lt;element ref="{}address-2" minOccurs="0"/&gt;
 *             &lt;element ref="{}address-3" minOccurs="0"/&gt;
 *             &lt;element ref="{}mailcode" minOccurs="0"/&gt;
 *             &lt;element ref="{}pobox" minOccurs="0"/&gt;
 *             &lt;element ref="{}room" minOccurs="0"/&gt;
 *             &lt;element ref="{}address-floor" minOccurs="0"/&gt;
 *             &lt;element ref="{}building" minOccurs="0"/&gt;
 *             &lt;element ref="{}street" minOccurs="0"/&gt;
 *             &lt;element ref="{}city" minOccurs="0"/&gt;
 *             &lt;element ref="{}county" minOccurs="0"/&gt;
 *             &lt;element ref="{}state" minOccurs="0"/&gt;
 *             &lt;element ref="{}postcode" minOccurs="0"/&gt;
 *             &lt;element ref="{}country"/&gt;
 *           &lt;/sequence&gt;
 *           &lt;element ref="{}text"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "address", propOrder = {
    "address1",
    "address2",
    "address3",
    "mailcode",
    "pobox",
    "room",
    "addressFloor",
    "building",
    "street",
    "city",
    "county",
    "state",
    "postcode",
    "country",
    "text"
})
public class Address {

    @XmlElement(name = "address-1")
    protected Address1 address1;
    @XmlElement(name = "address-2")
    protected Address2 address2;
    @XmlElement(name = "address-3")
    protected Address3 address3;
    protected Mailcode mailcode;
    protected Pobox pobox;
    protected Room room;
    @XmlElement(name = "address-floor")
    protected AddressFloor addressFloor;
    protected Building building;
    protected Street street;
    protected City city;
    protected County county;
    protected State state;
    protected Postcode postcode;
    protected String country;
    protected Text text;

    /**
     * 取得 address1 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address1 }
     *     
     */
    public Address1 getAddress1() {
        return address1;
    }

    /**
     * 設定 address1 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address1 }
     *     
     */
    public void setAddress1(Address1 value) {
        this.address1 = value;
    }

    /**
     * 取得 address2 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address2 }
     *     
     */
    public Address2 getAddress2() {
        return address2;
    }

    /**
     * 設定 address2 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address2 }
     *     
     */
    public void setAddress2(Address2 value) {
        this.address2 = value;
    }

    /**
     * 取得 address3 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address3 }
     *     
     */
    public Address3 getAddress3() {
        return address3;
    }

    /**
     * 設定 address3 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address3 }
     *     
     */
    public void setAddress3(Address3 value) {
        this.address3 = value;
    }

    /**
     * 取得 mailcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Mailcode }
     *     
     */
    public Mailcode getMailcode() {
        return mailcode;
    }

    /**
     * 設定 mailcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Mailcode }
     *     
     */
    public void setMailcode(Mailcode value) {
        this.mailcode = value;
    }

    /**
     * 取得 pobox 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pobox }
     *     
     */
    public Pobox getPobox() {
        return pobox;
    }

    /**
     * 設定 pobox 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pobox }
     *     
     */
    public void setPobox(Pobox value) {
        this.pobox = value;
    }

    /**
     * 取得 room 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Room }
     *     
     */
    public Room getRoom() {
        return room;
    }

    /**
     * 設定 room 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Room }
     *     
     */
    public void setRoom(Room value) {
        this.room = value;
    }

    /**
     * 取得 addressFloor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AddressFloor }
     *     
     */
    public AddressFloor getAddressFloor() {
        return addressFloor;
    }

    /**
     * 設定 addressFloor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFloor }
     *     
     */
    public void setAddressFloor(AddressFloor value) {
        this.addressFloor = value;
    }

    /**
     * 取得 building 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Building }
     *     
     */
    public Building getBuilding() {
        return building;
    }

    /**
     * 設定 building 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Building }
     *     
     */
    public void setBuilding(Building value) {
        this.building = value;
    }

    /**
     * 取得 street 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Street }
     *     
     */
    public Street getStreet() {
        return street;
    }

    /**
     * 設定 street 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Street }
     *     
     */
    public void setStreet(Street value) {
        this.street = value;
    }

    /**
     * 取得 city 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link City }
     *     
     */
    public City getCity() {
        return city;
    }

    /**
     * 設定 city 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link City }
     *     
     */
    public void setCity(City value) {
        this.city = value;
    }

    /**
     * 取得 county 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link County }
     *     
     */
    public County getCounty() {
        return county;
    }

    /**
     * 設定 county 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link County }
     *     
     */
    public void setCounty(County value) {
        this.county = value;
    }

    /**
     * 取得 state 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link State }
     *     
     */
    public State getState() {
        return state;
    }

    /**
     * 設定 state 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link State }
     *     
     */
    public void setState(State value) {
        this.state = value;
    }

    /**
     * 取得 postcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Postcode }
     *     
     */
    public Postcode getPostcode() {
        return postcode;
    }

    /**
     * 設定 postcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Postcode }
     *     
     */
    public void setPostcode(Postcode value) {
        this.postcode = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

}
