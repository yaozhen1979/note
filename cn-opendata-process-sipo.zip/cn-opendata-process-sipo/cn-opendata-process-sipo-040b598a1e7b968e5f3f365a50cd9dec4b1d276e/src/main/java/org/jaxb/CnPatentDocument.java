//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>cn-patent-document complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="cn-patent-document"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}doc-page" minOccurs="0"/&gt;
 *         &lt;element ref="{}cn-bibliographic-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}application-body" minOccurs="0"/&gt;
 *         &lt;element ref="{}sequence-list-doc" minOccurs="0"/&gt;
 *         &lt;element ref="{}table-external-doc" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="file" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="country" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="file-reference-id" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="correction-code" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="doc-number" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="kind" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="date-produced" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="date-publ" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cn-patent-document", propOrder = {
    "docPage",
    "cnBibliographicData",
    "applicationBody",
    "sequenceListDoc",
    "tableExternalDoc"
})
public class CnPatentDocument {

    @XmlElement(name = "doc-page")
    protected DocPage docPage;
    @XmlElement(name = "cn-bibliographic-data")
    protected CnBibliographicData cnBibliographicData;
    @XmlElement(name = "application-body")
    protected ApplicationBody applicationBody;
    @XmlElement(name = "sequence-list-doc")
    protected SequenceListDoc sequenceListDoc;
    @XmlElement(name = "table-external-doc")
    protected List<TableExternalDoc> tableExternalDoc;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String lang;
    @XmlAttribute(name = "dtd-version")
    @XmlSchemaType(name = "anySimpleType")
    protected String dtdVersion;
    @XmlAttribute(name = "file")
    @XmlSchemaType(name = "anySimpleType")
    protected String file;
    @XmlAttribute(name = "country", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String country;
    @XmlAttribute(name = "file-reference-id")
    @XmlSchemaType(name = "anySimpleType")
    protected String fileReferenceId;
    @XmlAttribute(name = "correction-code")
    @XmlSchemaType(name = "anySimpleType")
    protected String correctionCode;
    @XmlAttribute(name = "doc-number")
    @XmlSchemaType(name = "anySimpleType")
    protected String docNumber;
    @XmlAttribute(name = "kind")
    @XmlSchemaType(name = "anySimpleType")
    protected String kind;
    @XmlAttribute(name = "date-produced")
    @XmlSchemaType(name = "anySimpleType")
    protected String dateProduced;
    @XmlAttribute(name = "date-publ")
    @XmlSchemaType(name = "anySimpleType")
    protected String datePubl;
    @XmlAttribute(name = "status")
    @XmlSchemaType(name = "anySimpleType")
    protected String status;

    /**
     * 取得 docPage 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DocPage }
     *     
     */
    public DocPage getDocPage() {
        return docPage;
    }

    /**
     * 設定 docPage 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DocPage }
     *     
     */
    public void setDocPage(DocPage value) {
        this.docPage = value;
    }

    /**
     * 取得 cnBibliographicData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnBibliographicData }
     *     
     */
    public CnBibliographicData getCnBibliographicData() {
        return cnBibliographicData;
    }

    /**
     * 設定 cnBibliographicData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnBibliographicData }
     *     
     */
    public void setCnBibliographicData(CnBibliographicData value) {
        this.cnBibliographicData = value;
    }

    /**
     * 取得 applicationBody 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationBody }
     *     
     */
    public ApplicationBody getApplicationBody() {
        return applicationBody;
    }

    /**
     * 設定 applicationBody 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationBody }
     *     
     */
    public void setApplicationBody(ApplicationBody value) {
        this.applicationBody = value;
    }

    /**
     * 取得 sequenceListDoc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListDoc }
     *     
     */
    public SequenceListDoc getSequenceListDoc() {
        return sequenceListDoc;
    }

    /**
     * 設定 sequenceListDoc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListDoc }
     *     
     */
    public void setSequenceListDoc(SequenceListDoc value) {
        this.sequenceListDoc = value;
    }

    /**
     * Gets the value of the tableExternalDoc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tableExternalDoc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTableExternalDoc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TableExternalDoc }
     * 
     * 
     */
    public List<TableExternalDoc> getTableExternalDoc() {
        if (tableExternalDoc == null) {
            tableExternalDoc = new ArrayList<TableExternalDoc>();
        }
        return this.tableExternalDoc;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 dtdVersion 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * 設定 dtdVersion 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * 取得 file 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFile() {
        return file;
    }

    /**
     * 設定 file 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFile(String value) {
        this.file = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 fileReferenceId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileReferenceId() {
        return fileReferenceId;
    }

    /**
     * 設定 fileReferenceId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileReferenceId(String value) {
        this.fileReferenceId = value;
    }

    /**
     * 取得 correctionCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrectionCode() {
        return correctionCode;
    }

    /**
     * 設定 correctionCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrectionCode(String value) {
        this.correctionCode = value;
    }

    /**
     * 取得 docNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocNumber() {
        return docNumber;
    }

    /**
     * 設定 docNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocNumber(String value) {
        this.docNumber = value;
    }

    /**
     * 取得 kind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * 設定 kind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * 取得 dateProduced 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateProduced() {
        return dateProduced;
    }

    /**
     * 設定 dateProduced 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateProduced(String value) {
        this.dateProduced = value;
    }

    /**
     * 取得 datePubl 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDatePubl() {
        return datePubl;
    }

    /**
     * 設定 datePubl 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatePubl(String value) {
        this.datePubl = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
