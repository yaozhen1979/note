//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>online complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="online"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}author" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}online-title" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}hosttitle" minOccurs="0"/&gt;
 *           &lt;element ref="{}subname" minOccurs="0"/&gt;
 *           &lt;element ref="{}edition" minOccurs="0"/&gt;
 *           &lt;choice minOccurs="0"&gt;
 *             &lt;element ref="{}serial"/&gt;
 *             &lt;element ref="{}book"/&gt;
 *           &lt;/choice&gt;
 *           &lt;element ref="{}imprint" minOccurs="0"/&gt;
 *           &lt;element ref="{}pubdate" minOccurs="0"/&gt;
 *           &lt;element ref="{}history" minOccurs="0"/&gt;
 *           &lt;element ref="{}series" minOccurs="0"/&gt;
 *           &lt;element ref="{}hostno" minOccurs="0"/&gt;
 *           &lt;element ref="{}location" minOccurs="0"/&gt;
 *           &lt;element ref="{}notes" minOccurs="0"/&gt;
 *           &lt;element ref="{}avail"/&gt;
 *           &lt;element ref="{}class" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}keyword" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}cpyrt" minOccurs="0"/&gt;
 *           &lt;element ref="{}issn" minOccurs="0"/&gt;
 *           &lt;element ref="{}isbn" minOccurs="0"/&gt;
 *           &lt;element ref="{}datecit" minOccurs="0"/&gt;
 *           &lt;element ref="{}srchterm" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}srchdate" minOccurs="0"/&gt;
 *           &lt;element ref="{}refno" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "online", propOrder = {
    "text",
    "author",
    "onlineTitle",
    "hosttitle",
    "subname",
    "edition",
    "serial",
    "book",
    "imprint",
    "pubdate",
    "history",
    "series",
    "hostno",
    "location",
    "notes",
    "avail",
    "clazz",
    "keyword",
    "cpyrt",
    "issn",
    "isbn",
    "datecit",
    "srchterm",
    "srchdate",
    "refno"
})
public class Online {

    protected Text text;
    protected List<Author> author;
    @XmlElement(name = "online-title")
    protected List<OnlineTitle> onlineTitle;
    protected Hosttitle hosttitle;
    protected Subname subname;
    protected Edition edition;
    protected Serial serial;
    protected Book book;
    protected Imprint imprint;
    protected Pubdate pubdate;
    protected History history;
    protected Series series;
    protected Hostno hostno;
    protected Location location;
    protected Notes notes;
    protected Avail avail;
    @XmlElement(name = "class")
    protected List<Class> clazz;
    protected List<Keyword> keyword;
    protected Cpyrt cpyrt;
    protected Issn issn;
    protected Isbn isbn;
    protected Datecit datecit;
    protected List<Srchterm> srchterm;
    protected Srchdate srchdate;
    protected List<Refno> refno;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the author property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Author }
     * 
     * 
     */
    public List<Author> getAuthor() {
        if (author == null) {
            author = new ArrayList<Author>();
        }
        return this.author;
    }

    /**
     * Gets the value of the onlineTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the onlineTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOnlineTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OnlineTitle }
     * 
     * 
     */
    public List<OnlineTitle> getOnlineTitle() {
        if (onlineTitle == null) {
            onlineTitle = new ArrayList<OnlineTitle>();
        }
        return this.onlineTitle;
    }

    /**
     * 取得 hosttitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Hosttitle }
     *     
     */
    public Hosttitle getHosttitle() {
        return hosttitle;
    }

    /**
     * 設定 hosttitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Hosttitle }
     *     
     */
    public void setHosttitle(Hosttitle value) {
        this.hosttitle = value;
    }

    /**
     * 取得 subname 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Subname }
     *     
     */
    public Subname getSubname() {
        return subname;
    }

    /**
     * 設定 subname 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Subname }
     *     
     */
    public void setSubname(Subname value) {
        this.subname = value;
    }

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Edition }
     *     
     */
    public Edition getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Edition }
     *     
     */
    public void setEdition(Edition value) {
        this.edition = value;
    }

    /**
     * 取得 serial 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Serial }
     *     
     */
    public Serial getSerial() {
        return serial;
    }

    /**
     * 設定 serial 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Serial }
     *     
     */
    public void setSerial(Serial value) {
        this.serial = value;
    }

    /**
     * 取得 book 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Book }
     *     
     */
    public Book getBook() {
        return book;
    }

    /**
     * 設定 book 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Book }
     *     
     */
    public void setBook(Book value) {
        this.book = value;
    }

    /**
     * 取得 imprint 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Imprint }
     *     
     */
    public Imprint getImprint() {
        return imprint;
    }

    /**
     * 設定 imprint 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Imprint }
     *     
     */
    public void setImprint(Imprint value) {
        this.imprint = value;
    }

    /**
     * 取得 pubdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pubdate }
     *     
     */
    public Pubdate getPubdate() {
        return pubdate;
    }

    /**
     * 設定 pubdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pubdate }
     *     
     */
    public void setPubdate(Pubdate value) {
        this.pubdate = value;
    }

    /**
     * 取得 history 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link History }
     *     
     */
    public History getHistory() {
        return history;
    }

    /**
     * 設定 history 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link History }
     *     
     */
    public void setHistory(History value) {
        this.history = value;
    }

    /**
     * 取得 series 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Series }
     *     
     */
    public Series getSeries() {
        return series;
    }

    /**
     * 設定 series 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Series }
     *     
     */
    public void setSeries(Series value) {
        this.series = value;
    }

    /**
     * 取得 hostno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Hostno }
     *     
     */
    public Hostno getHostno() {
        return hostno;
    }

    /**
     * 設定 hostno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Hostno }
     *     
     */
    public void setHostno(Hostno value) {
        this.hostno = value;
    }

    /**
     * 取得 location 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getLocation() {
        return location;
    }

    /**
     * 設定 location 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setLocation(Location value) {
        this.location = value;
    }

    /**
     * 取得 notes 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Notes }
     *     
     */
    public Notes getNotes() {
        return notes;
    }

    /**
     * 設定 notes 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Notes }
     *     
     */
    public void setNotes(Notes value) {
        this.notes = value;
    }

    /**
     * 取得 avail 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Avail }
     *     
     */
    public Avail getAvail() {
        return avail;
    }

    /**
     * 設定 avail 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Avail }
     *     
     */
    public void setAvail(Avail value) {
        this.avail = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clazz property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClazz().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Class }
     * 
     * 
     */
    public List<Class> getClazz() {
        if (clazz == null) {
            clazz = new ArrayList<Class>();
        }
        return this.clazz;
    }

    /**
     * Gets the value of the keyword property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyword property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyword().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Keyword }
     * 
     * 
     */
    public List<Keyword> getKeyword() {
        if (keyword == null) {
            keyword = new ArrayList<Keyword>();
        }
        return this.keyword;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Cpyrt }
     *     
     */
    public Cpyrt getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Cpyrt }
     *     
     */
    public void setCpyrt(Cpyrt value) {
        this.cpyrt = value;
    }

    /**
     * 取得 issn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Issn }
     *     
     */
    public Issn getIssn() {
        return issn;
    }

    /**
     * 設定 issn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Issn }
     *     
     */
    public void setIssn(Issn value) {
        this.issn = value;
    }

    /**
     * 取得 isbn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Isbn }
     *     
     */
    public Isbn getIsbn() {
        return isbn;
    }

    /**
     * 設定 isbn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Isbn }
     *     
     */
    public void setIsbn(Isbn value) {
        this.isbn = value;
    }

    /**
     * 取得 datecit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Datecit }
     *     
     */
    public Datecit getDatecit() {
        return datecit;
    }

    /**
     * 設定 datecit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Datecit }
     *     
     */
    public void setDatecit(Datecit value) {
        this.datecit = value;
    }

    /**
     * Gets the value of the srchterm property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the srchterm property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSrchterm().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Srchterm }
     * 
     * 
     */
    public List<Srchterm> getSrchterm() {
        if (srchterm == null) {
            srchterm = new ArrayList<Srchterm>();
        }
        return this.srchterm;
    }

    /**
     * 取得 srchdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Srchdate }
     *     
     */
    public Srchdate getSrchdate() {
        return srchdate;
    }

    /**
     * 設定 srchdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Srchdate }
     *     
     */
    public void setSrchdate(Srchdate value) {
        this.srchdate = value;
    }

    /**
     * Gets the value of the refno property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refno property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefno().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Refno }
     * 
     * 
     */
    public List<Refno> getRefno() {
        if (refno == null) {
            refno = new ArrayList<Refno>();
        }
        return this.refno;
    }

}
