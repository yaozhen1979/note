package org.valid;

import java.io.IOException;
import java.io.StringReader;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class CnIgnoreDTDEntityResolver implements EntityResolver {
    
    private String schemaLocation;
    
    CnIgnoreDTDEntityResolver(String schemaLocation) {
        this.schemaLocation = schemaLocation;
    }
    
    @Override
    public InputSource resolveEntity(String publicId, String systemId)
            throws SAXException, IOException {
        // System.out.println("systemId = " + systemId);
        if (systemId.contains(schemaLocation)) {
            return new InputSource(new StringReader(""));
        } else {
            return null;
        }
    }

}
