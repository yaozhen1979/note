/**
 * unzip 特定folder至指定資料夾
 */
package org.unzip;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.unzip.UnzipUtil;

/**
 * unzip CN 全文影像檔:
 * 
 * 把相關tif or jpg移至fullpage, 且檔名去0, 只有整數.
 * 
 * @author tonykuo
 *
 */
public class ExtractSelectFilesWithInputStream {
	
	private final int BUFF_SIZE = 4096;
	
	/**
	 * 
	 * @param zipFilePath T:/cn_img/20150819/TIFFWG_20150819_001.zip
	 * @param destinationFolderPath T:/cn_img/20150819
	 * @param type WG
	 */
	public ExtractSelectFilesWithInputStream(String zipFilePath, String destinationFolderPath, String type) {
		
		try {
			// Initiate the ZipFile => T:\cn_img\20150819\TIFFWG_20150819_001
			ZipFile zipFile = new ZipFile(zipFilePath);
			String destinationPath = destinationFolderPath + System.getProperty("file.separator") + type;
			
			if (!zipFile.isValidZipFile()) {  
                throw new ZipException("bad zip file...");  
            } else {
                System.out.println("good zip file");
            }
            
            // If zip file is password protected then set the password
            if (zipFile.isEncrypted()) {
                zipFile.setPassword("password");
            } else {
                System.out.println("no Encrypt...");
            }
			
            // T:\cn_img\20150819\TIFFWG_20150819_001.ZIP\WG\2015\3133\
            List fileHeaderList = zipFile.getFileHeaders();
			
            for (int i = 0; i < fileHeaderList.size(); i++) {
                
                FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
                //
                if (fileHeader != null) {
                    
                    // new ZipFile(fileHeader.get)
                    
                    // Build the output file => Name: XX\2015\20151202\201220144399.7\000001.TIF
                    // 
                    String fileName = fileHeader.getFileName();
                    
                    if (fileName.endsWith("TIFF") || fileName.endsWith("TIF") || fileName.endsWith("tiff") || fileName.endsWith("tif") ||  
                            fileName.endsWith("JPG") || fileName.endsWith("JPGE") || fileName.endsWith("jpeg") || fileName.endsWith("jpg")) {
                        
                        String[] fileNameList = fileName.split("[\\\\|/]");
                        String appNumber = fileNameList[3];
                        // System.out.println("appNumber = " + appNumber);
                        if (!appNumber.contains(".")) {
                            String checkCode = appNumber.substring(appNumber.length() - 1);
                            appNumber = appNumber.substring(0, appNumber.length() - 1) + "." + checkCode;
                        }
                        // System.out.println("appNumber = " + appNumber);
                        
                        String imgFileName = fileNameList[4].split("\\.")[0];
                        String imgFileFormat = fileNameList[4].split("\\.")[1];
                        String newFileName = fileNameList[2] + System.getProperty("file.separator") + 
                                appNumber + System.getProperty("file.separator") +  
                                "fullImage" + System.getProperty("file.separator") + 
                                Integer.valueOf(imgFileName) + "." + imgFileFormat;
                        
                        // System.out.println("newFileName = " + newFileName);
                        
                        String outFilePath = destinationPath + System.getProperty("file.separator") + newFileName;
                        File outFile = new File(outFilePath);
                        
                        //Checks if the file is a directory
                        if (fileHeader.isDirectory()) {
                            //This functionality is up to your requirements
                            //For now I create the directory
                            outFile.mkdirs();
                            return;
                        }
                        
                        //Check if the directories(including parent directories)
                        //in the output file path exists
                        File parentDir = outFile.getParentFile();
                        if (!parentDir.exists()) {
                            parentDir.mkdirs(); //If not create those directories
                        }
                        
                        unzeipFileByStream(zipFile, fileHeader, outFile);
                        
                        //To restore File attributes (ex: last modified file time, 
                        //read only flag, etc) of the extracted file, a utility class
                        //can be used as shown below
                        UnzipUtil.applyFileAttributes(fileHeader, outFile);
                        
                        System.out.println("Done extracting: " + newFileName);
                        
                    }
                   
                } else {
                    System.err.println("FileHeader does not exist");
                }
            }
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param zipFile
	 * @param fileHeader
	 * @param outFile
	 * @throws ZipException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
    private void unzeipFileByStream(ZipFile zipFile, FileHeader fileHeader,
            File outFile) throws ZipException, FileNotFoundException,
            IOException {
        //Get the InputStream from the ZipFile
        ZipInputStream is = zipFile.getInputStream(fileHeader);
        //Initialize the output stream
        OutputStream os = new FileOutputStream(outFile);
        
        int readLen = -1;
        byte[] buff = new byte[BUFF_SIZE];
        
        //Loop until End of File and write the contents to the output stream
        while ((readLen = is.read(buff)) != -1) {
            os.write(buff, 0, readLen);
        }
        
        //Closing inputstream also checks for CRC of the the just extracted file.
        //If CRC check has to be skipped (for ex: to cancel the unzip operation, etc)
        //use method is.close(boolean skipCRCCheck) and set the flag,
        //skipCRCCheck to false
        //NOTE: It is recommended to close outputStream first because Zip4j throws 
        //an exception if CRC check fails
        is.close();
        
        //Close output stream
        os.close();
    }
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	    
	    long startTime = System.nanoTime();
	    
	    /**
	     * 
	     * @param zipFilePath T:/cn_img/20150819/TIFFWG_20150819_001.zip
	     * @param destinationFolderPath T:/cn_img/20150819
	     * @param type WG
	     */
		// new ExtractSelectFilesWithInputStream("T:/cn_img/20150819/TIFFWG_20150819_001.zip", "T:/cn_img/20150819", "WG");
		// new ExtractSelectFilesWithInputStream("T:/cn_img/20150819/TIFFWG_20150819_002.zip", "T:/cn_img/20150819", "WG");
		
	    // String unzipFolder = "T:/cn_img/20150916";
	    String unzipFolder = "D:/share/cn_img";
	    
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_001.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_002.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_003.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_004.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_005.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_006.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_007.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_008.zip", unzipFolder, "FM");
	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFFM_20151223_009.zip", unzipFolder, "FM");
		
		// TIFFSD_20151223_001
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFSD_20151223_001.zip", unzipFolder, "SD");
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFSD_20151223_002.zip", unzipFolder, "SD");
		
		// TIFFWG_20151223_001
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFWG_20151223_001.zip", unzipFolder, "WG");
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFWG_20151223_002.zip", unzipFolder, "WG");
		
		// TIFFXX_20151223_001
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFXX_20151223_001.zip", unzipFolder, "XX");
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFXX_20151223_002.zip", unzipFolder, "XX");
		new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/TIFFXX_20151223_003.zip", unzipFolder, "XX");
	    
	    // INVENTION-A-IMAGE-007
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-001.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-002.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-003.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-004.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-005.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-006.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-007.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-008.zip", unzipFolder, "FM");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-A-IMAGE-009.zip", unzipFolder, "FM");
//	    
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INDUSTRIAL-DESIGN-IMAGE-001.zip", unzipFolder, "WG");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INDUSTRIAL-DESIGN-IMAGE-002.zip", unzipFolder, "WG");
//	    
//	    // INVENTION-B-IMAGE-001
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-B-IMAGE-001.zip", unzipFolder, "SD");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/INVENTION-B-IMAGE-002.zip", unzipFolder, "SD");
//	    
//	    // UTILITY-IMAGE-001
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/UTILITY-IMAGE-001.zip", unzipFolder, "XX");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/UTILITY-IMAGE-002.zip", unzipFolder, "XX");
//	    new ExtractSelectFilesWithInputStream("T:/cn_img/20151223/UTILITY-IMAGE-003.zip", unzipFolder, "XX");
	    
		long stopTime = System.nanoTime();
		
		long duration = stopTime - startTime;
		
		System.out.println(TimeUnit.SECONDS.convert(duration, TimeUnit.NANOSECONDS));
	}

}
