cn-opendata-process 說明
===

### 更新流程 ###

1. 每週三, SIPO會放出當期的專利資料, 但`CN Open Data`約在星期四的下午時會放出資料在FTP上.  
   資料從龍群那再傳回台灣台北.

2. 資料傳送完成後, 即可執行資料解壓縮的動作(相關程式為**FullTextFilesExtractor.groovy**, 但相關程式在解壓縮完成後, 數量出現錯誤, 待處理).

3. Raw Data 處理  
  * 程式為`CnRawDataImporter.groovy`  
  * DB名稱一樣為**[PatentRawCNIPR]**.(11月份的資料才會move to 121上, 之前的目前先save to localhost)  
  * FM, SD, XX 為全文XML, WG為TXT, 所以程式處理方式不同

4. Marshall Data 處理
  * 程式為`CnMarshallDataImporter.groovy`
  * DB名稱為**[PatentMarshallCN]**. (基本上是全部都要有一份在121上, 但目前也先save to localhost)

5. Info Data 處理
  * 程式為`CnInfoDataImporter.groovy`  
  * DB名稱一樣為**[PatentInfoCNIPR]**. (11月份開始的每期更新資料都會以121為主.)

6. Solr Index 處理
  * 相同處理流程

7. FM, SD, XX 全文First Image, Clip Image, Embed Image 處理
  * 等資料寫入**Marshall DB**後, 再以appNumber和Clip Image, First Image的展開資訊, 去搬移相關圖檔至指定位置.  
  * 處理程式為**[ImageCopyProcess2.groovy]**

8. 設定檔為`config.properties`, 其中以  
  * **raw_data_folder_path**  
  * **image_data_folder_path**

   最為重要.  

<br/>
#### CN Open Data Error 說明

1. 錯誤資料, 查詢條件:  

         marshallId = 564f3fb55eeeda211a66bf82,
         patentNumer = CN105027615A  

     ipcr 中有一筆資料為 **\n**, 造成InfoDataUtil無法parse,  
     經查驗SIPO後, 發現該筆資料的IPC也只有一筆, 所以直接在marshall db中修改  

2. 2015-11-04 該期的資料XML 皆為BOM FILE, 所以SAX在讀取XML DOM時, 會出現`[Content is not allowed in prolog.]`  

3. open data 中會有資料 沒有提供`全文影像檔頁數`(filePageNumber) => 請找出範例資料 ???

4. SD, CN102222467B => reference-cited 中的內文有問題... => \n\t\t\t\t 的內文...

5. 資料, 查詢條件:  

       "patentType" : "SD", 
       "patentNumber" : "CN103086956B",  

    "CN 101602710 A ,2009.12.16,C07D211/90.;CN 101759631 A ,2010.06.30,全文.;CN 102827068 A ,2012.12.19,实施例2;第29-30段.;WO 0031035 A1 ,2000.06.02,全文.;WO 2011130852 A1 ,2011.10.27,1-10.;WO 9512578 A1 ,1995.05.11,全文."

     => 第29-30段 無法解析

6. citedPatents 會出現有像 US 4163929 1979.08.07 的資料出現, 所以不像只用[,]來split...

7. 資料, 查詢條件:  

         "patentType" : "SD", 
         "patentNumber" : "CN103245228B"  
       
       "text" : "CN 102440219 A,2012.05.09,全文.;CN 102563978 A,2012.07.11,说明书第0029-0030,0033-0041段;附图1-6.;CN 1639521 A,2005.07.13,说明书第4页倒数第4段至第1页第3段，附图1-4.;CN 201772799 U,2011.03.23,全文.;CN 202328922 U,2012.07.11,说明书第0017-0021段，附图2.;CN 203413989 U,2014.01.29,权利要求1-6.;DE 2507870 A1,1975.09.04,全文.;US 2007/235173 A1,2007.10.11,全文.;WO 2012/007344 A2,2012.01.19,全文." 


<br/>
#### 注意事項和處理事項
---

1. org.utils 太亂了, 是否要把 org.utils.info org.utils.MarshallDataUtil org.utils.RawDataUitl 切出來 ???

2. MiscUtil.removeMapNullValue 要再實作...

3. PatentRawCN 還是改回用 PatentRawCNIPR(mongodb 3.0) ???

4. 轉換資料源後, WG在PatentRawCNIPR的path, 不再以如"WG/2015/3138/[申請號]"為儲存依據, 而是直接儲存如"WG/2015/20150923/[申請號]"的格式.

5. WG的項目資料為GB2312編碼, 但在本地處理資料要額外手動把檔案儲存為UTF-8編碼

6. InfoDataUtil.groovy && WGInfoDataUtil => 去除json data中null或是空值的部份, 請refactor...

