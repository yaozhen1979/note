SIPO DATA 處理說明
===

1. Raw Data => 先驗證, 再存入DB.
   => 因現在WG的資料也有XML, 但因其資料結構和FM, SD, XX不同, 所以需另外獨立成一份XSD來使用,
   => XSD file = cn-patent-document-v1.xsd
   => XSD file = wg-cn-patent-document-v1.xsd
   => 相關程式: org.importer.rawdata.SipoRawDataImporter.groovy

2. Marshall Data => 直接存入DB
   => 相關程式: org.importer.marshalldata.SipoRawDataImporter.groovy
   
3. Info Data 待2月份取得資料後, 再行處理...