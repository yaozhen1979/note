//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ��� 
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2015.10.31 �� 02:35:32 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>cn-patent-document complex type �� Java ���O.
 * 
 * <p>�U�C���n���q�|���w�����O���]�t���w�����e.
 * 
 * <pre>
 * &lt;complexType name="cn-patent-document">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{}doc-page" minOccurs="0"/>
 *         &lt;element ref="{}cn-bibliographic-data" minOccurs="0"/>
 *         &lt;element ref="{}application-body" minOccurs="0"/>
 *         &lt;element ref="{}sequence-list-doc" minOccurs="0"/>
 *         &lt;element ref="{}table-external-doc" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" />
 *       &lt;attribute name="lang" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="file" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="country" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="file-reference-id" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="correction-code" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="doc-number" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="kind" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="date-produced" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="date-publ" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cn-patent-document", propOrder = {
    "docPage",
    "cnBibliographicData",
    "applicationBody",
    "sequenceListDoc",
    "tableExternalDoc"
})
@XmlRootElement(name = "cn-patent-document")
public class CnPatentDocument {

    @XmlElement(name = "doc-page")
    protected DocPage docPage;
    @XmlElement(name = "cn-bibliographic-data")
    protected CnBibliographicData cnBibliographicData;
    @XmlElement(name = "application-body")
    protected ApplicationBody applicationBody;
    @XmlElement(name = "sequence-list-doc")
    protected SequenceListDoc sequenceListDoc;
    @XmlElement(name = "table-external-doc")
    protected List<TableExternalDoc> tableExternalDoc;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String lang;
    @XmlAttribute(name = "dtd-version")
    @XmlSchemaType(name = "anySimpleType")
    protected String dtdVersion;
    @XmlAttribute(name = "file")
    @XmlSchemaType(name = "anySimpleType")
    protected String file;
    @XmlAttribute(name = "country", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String country;
    @XmlAttribute(name = "file-reference-id")
    @XmlSchemaType(name = "anySimpleType")
    protected String fileReferenceId;
    @XmlAttribute(name = "correction-code")
    @XmlSchemaType(name = "anySimpleType")
    protected String correctionCode;
    @XmlAttribute(name = "doc-number")
    @XmlSchemaType(name = "anySimpleType")
    protected String docNumber;
    @XmlAttribute(name = "kind")
    @XmlSchemaType(name = "anySimpleType")
    protected String kind;
    @XmlAttribute(name = "date-produced")
    @XmlSchemaType(name = "anySimpleType")
    protected String dateProduced;
    @XmlAttribute(name = "date-publ")
    @XmlSchemaType(name = "anySimpleType")
    protected String datePubl;
    @XmlAttribute(name = "status")
    @XmlSchemaType(name = "anySimpleType")
    protected String status;

    /**
     * ���o docPage �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link DocPage }
     *     
     */
    public DocPage getDocPage() {
        return docPage;
    }

    /**
     * �]�w docPage �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link DocPage }
     *     
     */
    public void setDocPage(DocPage value) {
        this.docPage = value;
    }

    /**
     * ���o cnBibliographicData �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link CnBibliographicData }
     *     
     */
    public CnBibliographicData getCnBibliographicData() {
        return cnBibliographicData;
    }

    /**
     * �]�w cnBibliographicData �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link CnBibliographicData }
     *     
     */
    public void setCnBibliographicData(CnBibliographicData value) {
        this.cnBibliographicData = value;
    }

    /**
     * ���o applicationBody �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationBody }
     *     
     */
    public ApplicationBody getApplicationBody() {
        return applicationBody;
    }

    /**
     * �]�w applicationBody �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationBody }
     *     
     */
    public void setApplicationBody(ApplicationBody value) {
        this.applicationBody = value;
    }

    /**
     * ���o sequenceListDoc �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListDoc }
     *     
     */
    public SequenceListDoc getSequenceListDoc() {
        return sequenceListDoc;
    }

    /**
     * �]�w sequenceListDoc �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListDoc }
     *     
     */
    public void setSequenceListDoc(SequenceListDoc value) {
        this.sequenceListDoc = value;
    }

    /**
     * Gets the value of the tableExternalDoc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tableExternalDoc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTableExternalDoc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TableExternalDoc }
     * 
     * 
     */
    public List<TableExternalDoc> getTableExternalDoc() {
        if (tableExternalDoc == null) {
            tableExternalDoc = new ArrayList<TableExternalDoc>();
        }
        return this.tableExternalDoc;
    }

    /**
     * ���o id �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * �]�w id �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * ���o lang �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * �]�w lang �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * ���o dtdVersion �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * �]�w dtdVersion �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * ���o file �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFile() {
        return file;
    }

    /**
     * �]�w file �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFile(String value) {
        this.file = value;
    }

    /**
     * ���o country �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * �]�w country �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * ���o fileReferenceId �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileReferenceId() {
        return fileReferenceId;
    }

    /**
     * �]�w fileReferenceId �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileReferenceId(String value) {
        this.fileReferenceId = value;
    }

    /**
     * ���o correctionCode �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrectionCode() {
        return correctionCode;
    }

    /**
     * �]�w correctionCode �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrectionCode(String value) {
        this.correctionCode = value;
    }

    /**
     * ���o docNumber �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocNumber() {
        return docNumber;
    }

    /**
     * �]�w docNumber �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocNumber(String value) {
        this.docNumber = value;
    }

    /**
     * ���o kind �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * �]�w kind �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * ���o dateProduced �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateProduced() {
        return dateProduced;
    }

    /**
     * �]�w dateProduced �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateProduced(String value) {
        this.dateProduced = value;
    }

    /**
     * ���o datePubl �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDatePubl() {
        return datePubl;
    }

    /**
     * �]�w datePubl �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatePubl(String value) {
        this.datePubl = value;
    }

    /**
     * ���o status �S�ʪ���.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * �]�w status �S�ʪ���.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
