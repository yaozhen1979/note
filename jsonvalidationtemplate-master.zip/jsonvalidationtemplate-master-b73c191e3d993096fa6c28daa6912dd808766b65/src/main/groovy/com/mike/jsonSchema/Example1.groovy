package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jackson.JsonLoader
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * 基本型態說明
 * @author mikelin
 *
 */
class Example1 extends BaseAction {
    
    def static main(args) {
        Example1 ex = new Example1()
        ex.execute()
    }
    
    def execute() {
        /*
        JsonNode schema1 = JsonLoader.fromPath("D:\\workspace-sts-3.7.0.RELEASE\\JsonSchemaProject\\src\\main\\groovy\\com\\mike\\jsonSchema\\schema\\schema1.json")
        JsonNode example1 = JsonLoader.fromPath("D:\\workspace-sts-3.7.0.RELEASE\\JsonSchemaProject\\src\\main\\groovy\\com\\mike\\jsonSchema\\example\\example1.json")
        */
        JsonNode schema1 = BaseUtils.loadResource("/schema/schema1.json")
        
        JsonNode example1_good = BaseUtils.loadResource("/example/example1.json")
        
//        JsonNode example1_bad = BaseUtils.loadResource("/example/example1_bad.json")
        
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault()
        
        JsonSchema schema = factory.getJsonSchema(schema1)
        
        ProcessingReport report = null 
        
        report = schema.validate(example1_good)
        
        printLog "example1_good: ${report}"
        
//        report = schema.validate(example1_bad)
//        
//        printLog "example1_bad: ${report}"
//        
    }

}
