package com.mike.jsonSchema

import java.text.SimpleDateFormat

class BaseAction {

    def printLog(msg) {
        
        println new SimpleDateFormat("yyyy-MM-dd HH:ss:mm").format(new Date()) + " " + msg
        
    }
    
}
