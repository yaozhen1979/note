package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 *
 * @author mikelin
 *
 */
class PatternPropertiesExample extends BaseAction {
    
    def static main(args) {
        PatternPropertiesExample ex = new PatternPropertiesExample()
        ex.execute()
    }
    
    def execute() {
        
        ProcessingReport report = JsonValidationUtil.verify("/schema/patternProperties-schema.json", "/example/patternProperties-example.json")
        
        if (!!report) {
            printLog "patternPropertiesExample: ${report}"
        }
        
    }

}
