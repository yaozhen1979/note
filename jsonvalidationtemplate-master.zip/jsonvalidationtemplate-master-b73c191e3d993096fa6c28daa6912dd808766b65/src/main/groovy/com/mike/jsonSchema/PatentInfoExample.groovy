package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * PatentInfo Example
 * @author mikelin
 *
 */
class PatentInfoExample extends BaseAction {
    
    def static main(args) {
        PatentInfoExample ex = new PatentInfoExample()
        ex.execute()
    }
    
    def execute() {
        
        ProcessingReport report = JsonValidationUtil.verify("/schema/patentInfo-schema.json", "/example/patentInfo-example.json")
        
        if (!!report) {
            printLog "patternExample: ${report}"
        }
        
    }

}
