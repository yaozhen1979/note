package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * Enum Example
 * @author mikelin
 *
 */
class EnumExample extends BaseAction {
    
    def static main(args) {
        EnumExample ex = new EnumExample()
        ex.execute()
    }
    
    def execute() {
        
        ProcessingReport report = JsonValidationUtil.verify("/schema/enum-schema.json", "/example/enum-example.json")
        
        if (!!report) {
            printLog "enumExample: ${report}"
        }
        
    }

}
