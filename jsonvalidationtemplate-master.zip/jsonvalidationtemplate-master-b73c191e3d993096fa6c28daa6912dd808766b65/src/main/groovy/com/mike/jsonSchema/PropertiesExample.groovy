package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * Properties Example
 * @author mikelin
 *
 */
class PropertiesExample extends BaseAction {
    
    def static main(args) {
        PropertiesExample ex = new PropertiesExample()
        ex.execute()
    }
    
    def execute() {
        
        ProcessingReport report = JsonValidationUtil.verify("/schema/properties-schema.json", "/example/properties-example.json")
        
        if (!!report) {
            
            printLog "propertiesExample: ${report}"
            
        }
        
    }

}
