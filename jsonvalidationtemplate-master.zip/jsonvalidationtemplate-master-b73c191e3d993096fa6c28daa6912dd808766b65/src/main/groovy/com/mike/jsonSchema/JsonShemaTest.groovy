
import com.mike.jsonSchema.*

//properties example
//new PropertiesExample().execute()

//enum example
//new EnumExample().execute()

//items example
//new ItemsExample().execute()

//pattern example
//new PatternExample().execute()

//$ref example
//new RefExample().execute()

//PatternProperties Example
new PatternPropertiesExample().execute()

//patentInfo example
//new PatentInfoExample().execute()


