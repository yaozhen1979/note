package com.mike.jsonSchema

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.examples.Utils;

class BaseUtils {

    def static final String PKGBASE

    static {
        
        final String pkgName = BaseUtils.class.getPackage().getName()
        
        PKGBASE = "/" + pkgName.replace(".", "/")
    }

    BaseUtils() {
        
    }
    

    /**
     * Load one resource from the current package as a {@link JsonNode}
     *
     * @param name name of the resource (<b>MUST</b> start with {@code /}
     * @return a JSON document
     * @throws IOException resource not found
     */
    def static JsonNode loadResource(final String name) throws IOException {
        
        return JsonLoader.fromResource(PKGBASE + name)
        
    }
}
