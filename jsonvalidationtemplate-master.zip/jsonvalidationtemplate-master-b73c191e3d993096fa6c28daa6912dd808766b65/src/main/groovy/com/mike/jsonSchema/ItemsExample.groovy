package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * Items Example
 * @author mikelin
 *
 */
class ItemsExample extends BaseAction {
    
    def static main(args) {
        ItemsExample ex = new ItemsExample()
        ex.execute()
    }
    
    def execute() {
        
        ProcessingReport report = JsonValidationUtil.verify("/schema/items-schema.json", "/example/items-example.json")
        
        if (!!report) {
            
            printLog "itemsExample: ${report}"
            
        }
        
    }

}
