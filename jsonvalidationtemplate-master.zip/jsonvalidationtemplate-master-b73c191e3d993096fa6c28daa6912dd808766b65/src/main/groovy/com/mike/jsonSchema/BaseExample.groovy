package com.mike.jsonSchema 
import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory

class BaseExample extends BaseAction {
    
    def static main(args) {
        BaseExample example = new BaseExample()
        example.execute()
    }
    
    def execute() {
        
        JsonNode fstabSchema = BaseUtils.loadResource("/fstab.json")
        JsonNode good = BaseUtils.loadResource("/fstab-good.json")
        JsonNode bad = BaseUtils.loadResource("/fstab-bad.json")
        JsonNode bad2 = BaseUtils.loadResource("/fstab-bad2.json")
        /*
        JsonNode fstabSchema = JsonLoader.fromPath("D:\\test\\fstab.json")
        JsonNode good = JsonLoader.fromPath("D:\\test\\fstab-good.json")
        JsonNode bad = JsonLoader.fromPath("D:\\test\\fstab-bad.json")
        JsonNode bad2 = JsonLoader.fromPath("D:\\test\\fstab-bad2.json")
        */
        
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault()
        
        JsonSchema schema = factory.getJsonSchema(fstabSchema)
        ProcessingReport report
        
        report = schema.validate(good)
        
        printLog report.isSuccess()
        if (!report.isSuccess()) {
            printLog report
        }
        
        
        report = schema.validate(bad)
        printLog report.isSuccess()
        if (!report.isSuccess()) {
            printLog report
        }
        
        report = schema.validate(bad2)
        printLog report.isSuccess()
        if (!report.isSuccess()) {
            printLog report
        }
        
    }
    
}

