package com.mike.jsonSchema

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory


/**
 * 基本型態說明
 * @author mikelin
 *
 */
class JsonValidationUtil {
    
    /**
     * 
     * @param schemaPath => "/schema/pattern-schema.json"
     * @param dataPath => "/example/pattern-example.json" 
     * @return
     */
    def static verify(schemaPath, dataPath) {
        
        JsonNode dataSchema = BaseUtils.loadResource(schemaPath)
        
        JsonNode data = BaseUtils.loadResource(dataPath)
        
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault()
        
        JsonSchema schema = factory.getJsonSchema(dataSchema)
        
        ProcessingReport report = null
        
        report = schema.validate(data)
        
        return report
        
    }

}
