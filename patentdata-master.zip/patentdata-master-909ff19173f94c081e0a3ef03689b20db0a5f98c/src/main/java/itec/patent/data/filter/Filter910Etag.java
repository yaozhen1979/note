package itec.patent.data.filter;

import javax.servlet.annotation.WebFilter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.filter.CheckEtag;

@WebFilter(asyncSupported = true, urlPatterns = {
    "*.json",
    "*.jsp",
    "*.image",
    "*.pdf",
    "*.xls",
    "*.xml",
    "*.staticjson",
})
public class Filter910Etag extends CheckEtag {

    static Log log = LogFactory.getLog(Filter910Etag.class);

}
