package itec.patent.data.servlet;

import itec.patent.data.param.DataParamContext;
import itec.patent.data.param.PatentFile;
import itec.patent.data.param.PatentPath;
import itec.patent.data.utils.ImageUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;
import org.tsaikd.java.utils.ServletUtils;

import com.mongodb.DBObject;

@WebServlet(urlPatterns = "/fullPage.pdf")
public class FullPagePDF extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(FullPagePDF.class);

    private static class OutError extends JSonOutput {

        public LinkedList<DBObject> nopdf = new LinkedList<>();

    }
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        DataParamContext pcxt = new DataParamContext(req, res);
        OutError outerror = new OutError();
        LinkedList<PatentFile> verifypdfs = new LinkedList<>();

        LinkedList<PatentPath> patpaths = pcxt.getPatentPaths();
        String fileName = pcxt.getParam("fileName", pcxt.getParam("filename", ""));
        for (PatentPath patpath : patpaths) {
            PatentFile pdffile = ImageUtils.getFullPDF(patpath);
            if (pdffile.file.exists()) {
                verifypdfs.add(pdffile);
            } else {
                outerror.nopdf.add(patpath.info.toDBObject());
            }
        }
        
        if (verifypdfs.size() < 2) {
            for (PatentFile pdffile : verifypdfs) {
                res.setContentType("application/pdf");
                res.setContentLength((int) pdffile.file.length());
                if (!pcxt.getParamBoolean("inline", false)) {
                    if (fileName != null && fileName.length() > 0) {
                        fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "") + ".pdf";
                    } else {
                        fileName = pdffile.info.patentNumber + ".pdf";
                    }
                    res.setHeader("Content-Disposition", "attachment; filename=" + fileName);
                }
                if (ServletUtils.checkEtagIsCached(req, res, pdffile.file.lastModified())) {
                    return;
                }
                ServletOutputStream out = res.getOutputStream();
                FileInputStream fis = new FileInputStream(pdffile.file);
                IOUtils.copy(fis, out);
                out.close();
                fis.close();
            }
        } else {
            res.setContentType("application/zip");
            if (fileName != null && fileName.length() > 0) {
                fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "") + ".zip";
            } else {
                fileName = "FullPDF-Patentcloud.zip";
            }
            res.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            ZipOutputStream out = new ZipOutputStream(res.getOutputStream());
            for (PatentFile pdffile : verifypdfs) {
                ZipEntry zentry = new ZipEntry(pdffile.info.patentNumber + ".pdf");
                out.putNextEntry(zentry);
                FileInputStream fis = new FileInputStream(pdffile.file);
                IOUtils.copy(fis, out);
                out.closeEntry();
                fis.close();
            }
            out.close();
        }
    }

}
