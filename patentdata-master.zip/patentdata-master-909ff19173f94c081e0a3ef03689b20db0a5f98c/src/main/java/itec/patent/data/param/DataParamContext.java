package itec.patent.data.param;

import itec.patent.common.PatentParamContext;
import itec.patent.data.utils.PatentDataConfig;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DataParamContext extends PatentParamContext {

    static Log log = LogFactory.getLog(DataParamContext.class);

    public DataParamContext(HttpServletRequest req, HttpServletResponse res) {
        super(req, res);
    }

    @SuppressWarnings("serial")
    public static HashMap<Pto, String> ptoPathMap = new HashMap<Pto, String>() {{
        put(Pto.USPTO    , "us");
        put(Pto.US        , "us");
        put(Pto.TIPO    , "tw");
        put(Pto.TW        , "tw");
        put(Pto.CNIPR    , "cn");
        put(Pto.CN        , "cn");
        put(Pto.JPO        , "jp");
        put(Pto.JP        , "jp");
        put(Pto.KIPO    , "kr");
        put(Pto.KR        , "kr");
        put(Pto.EPO        , "ep");
        put(Pto.EP        , "ep");
        put(Pto.WIPO    , "wo");
        put(Pto.WO        , "wo");
        put(Pto.DPMA    , "de");
        put(Pto.DE        , "de");
        put(Pto.INPI    , "fr");
        put(Pto.FR        , "fr");
        put(Pto.UKIPO    , "gb");
        put(Pto.GB        , "gb");
        put(Pto.IGE        , "ch");
        put(Pto.CH        , "ch");
    }};

    public static String getRelPatentPath(PatentInfo2 info) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        return String.format("%1$s%2$d%3$s/%4$s/%5$s"
            , ptoPathMap.get(info.pto)
            , info.stat
            , info.kindcode == null ? "" : info.kindcode.toLowerCase()
            , sdf.format(info.doDate)
            , info.patentNumber.replaceAll("[\\/\\s]", "").toLowerCase()
        );
    }

    /**
     * path search order: cache -> google patent -> data
     */
    protected PatentPath preparePatentPath(PatentInfo2 info, boolean onlyimagestorage) {
        PatentPath patentPath = new PatentPath(info);
        String relpath = getRelPatentPath(info);

        if(!onlyimagestorage) {
            // cache path
            for (File file : PatentDataConfig.cachepathPtoMap.get(info.pto)) {
                patentPath.paths.add(file.toPath().resolve(relpath));
            }
    
            // google patent path
            for (File file : PatentDataConfig.googlepatentpathPtoMap.get(info.pto)) {
                patentPath.paths.add(file.toPath().resolve(relpath));
            }
        }
        // pto data path
        for (File file : PatentDataConfig.datapathPtoMap.get(info.pto)) {
            patentPath.paths.add(file.toPath().resolve(relpath));
        }

        return patentPath;
    }

    private LinkedList<PatentPath> patentPaths;
    public LinkedList<PatentPath> getPatentPaths() {
        return getPatentPaths(false);
    }
    public LinkedList<PatentPath> getPatentPaths(boolean onlyimagestorage) {
        if (patentPaths == null) {
            patentPaths = new LinkedList<>();
            LinkedList<PatentInfo2> patentInfos = getPatentInfosByPaths();
            if (patentInfos == null || patentInfos.size() <= 0) {
                if (PatentDataConfig.isPtopidEnabled()) {
                    patentInfos = getPatentInfos("pto", "stat", "kindcode", "doDate", "openDate",
                            "appNumber", "decisionDate", "patentNumber", "openNumber", "decisionNumber", "type",
                            "filePageNumber", "relPatents", "filePageFig");
                } else {
                    return patentPaths;
                }
            }
            for (PatentInfo2 info : patentInfos) {
                patentPaths.add(preparePatentPath(info, onlyimagestorage));
            }

            // support input patent info by param, but info not enough for all pto download
            // for example, download first image from cnipr, need patent type
            String pto = getParam("pto", null);
            int stat = getParamInt("stat", 0);
            String kindcode = getParam("kindcode", "");
            Date doDate = getParamDate("doDate", null);
            String pn = getParam("pn", null);
            if (pn != null && stat != 0 && doDate != null && pto != null) {
                PatentInfo2 info = PatentInfo2.newInfo(Pto.valueOf(pto.toUpperCase()));
                info.stat = stat;
                info.kindcode = kindcode;
                info.doDate = doDate;
                info.patentNumber = pn;
                patentPaths.add(preparePatentPath(info, onlyimagestorage));
            }
        }
        return patentPaths;
    }

    private PatentPath patentPath;
    public PatentPath getPatentPath() {
        if (patentPath == null) {
            LinkedList<PatentPath> patentPaths = getPatentPaths();
            if (patentPaths.isEmpty()) {
                return null;
            } else {
                patentPath = patentPaths.getLast();
            }
        }
        return patentPath;
    }

    private String fileName;
    public String getFileName() {
        if (fileName == null) {
            fileName = getParam("fileName");
        }
        return fileName;
    }
    
    /**
     * path -> PatentInfo2
     * path: [pto][stat][kindcode]/[doDate:yyyy]/[doDate:MM]/[doDate:dd]/patentNumber, e.g., us1a1/2001/06/21/20010004534
     */
    public LinkedList<PatentInfo2> getPatentInfosByPaths() {
        LinkedList<PatentInfo2> patentInfos = new LinkedList<PatentInfo2>();
        LinkedList<String> paths = getParamSeps(",", "path");
        if (paths == null || paths.size() <= 0) {
            return patentInfos;
        }
        PatentInfo2 patentInfo = null;
        for (String path : paths) {
            patentInfo = new PatentInfo2();
            try {
                String[] info = path.split("/|\\\\"); // path can be separated by "/" or "\"
                patentInfo.pto = Pto.valueOf(info[0].replaceAll("^(\\w{2}).*", "$1").toUpperCase());
                patentInfo.stat = Integer.valueOf(info[0].replaceAll("^\\w{2}(\\d).*", "$1"));
                patentInfo.kindcode = info[0].replaceAll("\\w{3}(.*)", "$1").toUpperCase();
                patentInfo.doDate = new SimpleDateFormat("yyyyMMdd").parse(info[1] + info[2] + info[3]);
                patentInfo.patentNumber = info[4];
                if (patentInfo.pto.toString().contains("CN")) {
                    if (info.length > 5) {
                        String type = info[5];
                        patentInfo.type = type;
                    }
                }
                patentInfos.add(patentInfo);
            } catch (Exception e) {
                //e.printStackTrace();
            }
        }
        return patentInfos;
    }
    
}
