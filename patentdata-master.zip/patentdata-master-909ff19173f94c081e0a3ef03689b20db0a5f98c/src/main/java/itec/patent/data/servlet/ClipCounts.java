package itec.patent.data.servlet;

import itec.patent.data.param.DataParamContext;
import itec.patent.data.param.PatentPath;
import itec.patent.data.utils.ImageUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet(urlPatterns = "/clip.counts")
public class ClipCounts extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(ClipCounts.class);
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        DataParamContext pcxt = new DataParamContext(req, res);

        boolean getOnlyDataPath = true;
        LinkedList<PatentPath> patpaths = pcxt.getPatentPaths(getOnlyDataPath);
        if(patpaths.size() > 1){
            res.sendError(404, "can't load clip counts with level3 id");
            return;
        }
        int clipCounts = ImageUtils.getClipCounts(patpaths.get(0));
        
        res.setContentType("application/json");
        PrintWriter out = res.getWriter();
        out.write("{\"clipCounts\":" + clipCounts + "}");
        out.close();
    }
}
