package itec.patent.data.servlet;

import itec.patent.data.param.DataParamContext;
import itec.patent.data.param.PatentFile;
import itec.patent.data.param.PatentPath;
import itec.patent.data.utils.ImageUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ServletUtils;

@WebServlet(urlPatterns = "/clip.image")
public class ClipImage extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(ClipImage.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        DataParamContext pcxt = new DataParamContext(req, res);

        LinkedList<PatentPath> patpaths = pcxt.getPatentPaths();
        if(patpaths.size() > 1){
            res.sendError(404, "can't load clip image with level3 id");
            return;
        }
        PatentFile pfile = ImageUtils.getClipImage(patpaths.get(0), pcxt.getNum());
        if (!pfile.file.exists()) {
            res.sendError(404, "no image found");
            return;
        }

        if (ServletUtils.checkEtagIsCached(req, res, pfile.file.lastModified())) {
            return;
        }

        res.setContentType(pfile.mimeType);
        res.setContentLength((int) pfile.file.length());
        ServletOutputStream out = res.getOutputStream();
        FileInputStream fis = new FileInputStream(pfile.file);
        IOUtils.copy(fis, out);
        out.close();
        fis.close();
    }

}
