package itec.patent.data.filter;

import itec.patent.data.utils.PatentDataLogger;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Filter999Log implements Filter {

    static Log log = LogFactory.getLog(Filter999Log.class);

    @WebFilter(asyncSupported = true
        , urlPatterns = {
            "*.jsp",
        })
    public static class LogFilter_enterPage extends Filter999Log {
        @Override
        public void doFilter(ServletRequest request, ServletResponse response,
                FilterChain chain) throws IOException, ServletException {
            chain.doFilter(request, response);
            //PatentDataLogger.getInstance().dbLogPage((HttpServletRequest) request, (HttpServletResponse) response
            //    , "enterPage", true, true);
        }
    }

    @WebFilter(asyncSupported = true
        , urlPatterns = {
            "*.image",
        })
    public static class LogFilter_patentImage extends Filter999Log {
        @Override
        public void doFilter(ServletRequest request, ServletResponse response,
                FilterChain chain) throws IOException, ServletException {
            chain.doFilter(request, response);
            //PatentDataLogger.getInstance().dbLogPage((HttpServletRequest) request, (HttpServletResponse) response
            //    , "image", true, true);
        }
    }

    @WebFilter(asyncSupported = true
        , urlPatterns = {
            "*.json",
        })
    public static class LogFilter_json extends Filter999Log {
        @Override
        public void doFilter(ServletRequest request, ServletResponse response,
                FilterChain chain) throws IOException, ServletException {
            chain.doFilter(request, response);
            //PatentDataLogger.getInstance().dbLogPage((HttpServletRequest) request, (HttpServletResponse) response
            //    , "json", true, true);
        }
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
    }

    @Override
    public void destroy() {
    }

}
