package itec.patent.data.utils;

import itec.patent.common.ServletLogger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;

public class PatentDataLogger extends ServletLogger {

    static Log log = LogFactory.getLog(PatentDataLogger.class);

    public static ServletLogger getInstance() {
        //if (instance == null) {
            //instance = new ServletLogger();
            //instance.mongocol = MappedClass.db.getSisterDB("PatentDataLog").getCollection("PatentDataLog");
        //}
        return instance;
    }
}
