package itec.patent.data.param;

import itec.patent.mongodb.PatentInfo2;

import java.io.File;

public class PatentFile {

    public PatentInfo2 info;

    public File file = new File("");

    public String mimeType = "";

}
