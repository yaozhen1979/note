package itec.patent.data.filter;

import javax.servlet.annotation.WebFilter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.filter.CompressJsp;

@WebFilter(urlPatterns = {"*.jsp"})
public class Filter015CompressJsp extends CompressJsp {

    static Log log = LogFactory.getLog(Filter015CompressJsp.class);

}
