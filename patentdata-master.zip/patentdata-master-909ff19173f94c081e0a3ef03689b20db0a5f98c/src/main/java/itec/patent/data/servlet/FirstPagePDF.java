package itec.patent.data.servlet;

import itec.patent.data.param.DataParamContext;
import itec.patent.data.param.PatentFile;
import itec.patent.data.param.PatentPath;
import itec.patent.data.utils.ImageUtils;
import itec.patent.data.utils.PDFUtils;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfWriter;
import com.mongodb.DBObject;

@WebServlet(urlPatterns = "/firstPage.pdf")
public class FirstPagePDF extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(FirstPagePDF.class);

    private static class OutError extends JSonOutput {
        public LinkedList<DBObject> noFirstPagePdf = new LinkedList<>();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        DataParamContext pcxt = new DataParamContext(req, res);
    
        OutError outerror = new OutError();
        LinkedList<PatentFile> verifyFirstPages = new LinkedList<>();
        LinkedList<PatentPath> patpaths = pcxt.getPatentPaths();
        String fileName = pcxt.getParam("fileName", pcxt.getParam("filename", ""));
        for (PatentPath patpath : patpaths) {
            PatentFile pdffile = ImageUtils.getFirstPagePdf(patpath);
            if (pdffile.file.exists()) {
                verifyFirstPages.add(pdffile);
            } else {
                outerror.noFirstPagePdf.add(patpath.info.toDBObject());
            }
        }

        if(verifyFirstPages.size() > 0) {
            res.setContentType("application/pdf");
            if (!pcxt.getParamBoolean("inline", false)) {
                if (fileName != null && fileName.length() > 0) {
                    fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "") + ".pdf";
                } else {
                    fileName = "FirstPage-Patentcloud.pdf";
                }
                res.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            }
            Document doc = null;
            ServletOutputStream out = null;
            PdfWriter pdfWriter = null;
            try {
                doc = new Document();
                out = res.getOutputStream();
                pdfWriter = PdfWriter.getInstance(doc, out);
                doc.open();
                for (PatentFile patentFile : verifyFirstPages) {
                    PDFUtils.mergeFirstPagePDFs(doc, pdfWriter, patentFile.file.toPath());
                    out.flush();
                }
            } catch (DocumentException e) {
                throw new IOException(e);
            } finally {
                if (doc != null) {
                    doc.close();
                    pdfWriter.close();
                    out.close();
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doGet(req, res);
    }
}
