package itec.patent.data.servlet;

import itec.patent.data.utils.PatentDataConfig;
import itec.patent.mongodb.Pto;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.servlet.JSonOutput;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;

@WebServlet(urlPatterns = "/TestConfig.json")
public class TestConfig extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(TestConfig.class);

    @SuppressWarnings("unused")
    private static class Output extends JSonOutput {

        public String sys01ContextPath;

        public String sys02FreeMem;

        public String sys03TotalMem;

        public String sys04MaxMem;

        public String mongouri;

        public String patentwebSolr;

        public BasicDBObject dataConfig = new BasicDBObject();

        public BasicDBObject cacheConfig = new BasicDBObject();

        public BasicDBObject epoopsConfig = new BasicDBObject();

        public BasicDBObject googlepatentConfig = new BasicDBObject();

        public BasicDBObject cniprConfig = new BasicDBObject();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output output = new Output();

        output.sys01ContextPath = req.getContextPath();
        output.sys02FreeMem = FileUtils.byteCountToDisplaySize(Runtime.getRuntime().freeMemory());
        output.sys03TotalMem = FileUtils.byteCountToDisplaySize(Runtime.getRuntime().totalMemory());
        output.sys04MaxMem = FileUtils.byteCountToDisplaySize(Runtime.getRuntime().maxMemory());

        for (Pto pto : PatentDataConfig.datapathPtoMap.keySet()) {
            BasicDBList list = new BasicDBList();
            for (File file : PatentDataConfig.datapathPtoMap.get(pto)) {
                list.add(file.toString());
            }
            output.dataConfig.put(pto.toString(), list);
        }
        for (Pto pto : PatentDataConfig.cachepathPtoMap.keySet()) {
            BasicDBList list = new BasicDBList();
            for (File file : PatentDataConfig.cachepathPtoMap.get(pto)) {
                list.add(file.toString());
            }
            output.cacheConfig.put(pto.toString(), list);
        }
        for (Pto pto : PatentDataConfig.epoopspathPtoMap.keySet()) {
            BasicDBList list = new BasicDBList();
            for (File file : PatentDataConfig.epoopspathPtoMap.get(pto)) {
                list.add(file.toString());
            }
            output.epoopsConfig.put(pto.toString(), list);
        }
        for (Pto pto : PatentDataConfig.googlepatentpathPtoMap.keySet()) {
            BasicDBList list = new BasicDBList();
            for (File file : PatentDataConfig.googlepatentpathPtoMap.get(pto)) {
                list.add(file.toString());
            }
            output.googlepatentConfig.put(pto.toString(), list);
        }
        for (Pto pto : PatentDataConfig.cniprpathPtoMap.keySet()) {
            BasicDBList list = new BasicDBList();
            for (File file : PatentDataConfig.cniprpathPtoMap.get(pto)) {
                list.add(file.toString());
            }
            output.cniprConfig.put(pto.toString(), list);
        }

        output.mongouri = MappedClass.db.getMongo().debugString();

        output.patentwebSolr = PatentDataConfig.patentwebSolr.getBaseURL();

        res.setContentType("application/json");
        PrintWriter out = res.getWriter();
        out.write(output.toDBObject(true, true, true).toString());
        out.close();
    }

    /* unused
    private CloseableHttpClient httpClient = WebClient.newHttpClient();
    private boolean checkWebpage(String url) {
        HttpGet method = new HttpGet(url);
        try {
            HttpResponse response = httpClient.execute(method);
            HttpEntity entity = response.getEntity();
            EntityUtils.consume(entity);
            if (response.getStatusLine().getStatusCode() < 400) {
                return true;
            } else {
                return false;
            }
        } catch (IOException e) {
            return false;
        }
    }
     */

}
