package itec.patent.data.servlet;

import itec.patent.data.param.DataParamContext;
import itec.patent.data.param.PatentFile;
import itec.patent.data.param.PatentPath;
import itec.patent.data.utils.ImageUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;
import org.tsaikd.java.utils.ServletUtils;

import com.mongodb.DBObject;

@WebServlet(urlPatterns = "/singleFullPage.pdf")
public class singleFullPagePDF extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(singleFullPagePDF.class);

    private static class OutError extends JSonOutput {

        public LinkedList<DBObject> nopdf = new LinkedList<>();

    }
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        DataParamContext pcxt = new DataParamContext(req, res);
        OutError outerror = new OutError();
        LinkedList<PatentFile> verifypdfs = new LinkedList<>();

        LinkedList<PatentPath> patpaths = pcxt.getPatentPaths();
        PatentFile pdffile = ImageUtils.getFullPDF(patpaths.get(0));

        if (!pdffile.file.exists()) {
            res.sendError(404, "no image found");
            return;
        }
        if (ServletUtils.checkEtagIsCached(req, res, pdffile.file.lastModified())) {
            return;
        }
        res.setContentType("application/pdf");
        if (!pcxt.getParamBoolean("inline", false)) {
            String doNumber = pdffile.info.patentNumber;
            String doDate = sdf.format(pdffile.info.doDate);
            res.setHeader("Content-Disposition", "attachment; filename=" + doNumber + "(" + doDate + ")"+ ".pdf");
        }
        res.setContentLength((int) pdffile.file.length());
        ServletOutputStream out = res.getOutputStream();
        FileInputStream fis = new FileInputStream(pdffile.file);
        IOUtils.copy(fis, out);
        out.close();
        fis.close();
    }

}
