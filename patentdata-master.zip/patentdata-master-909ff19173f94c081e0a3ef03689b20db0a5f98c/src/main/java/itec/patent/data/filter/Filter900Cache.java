package itec.patent.data.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Filter900Cache implements Filter {

    static Log log = LogFactory.getLog(Filter900Cache.class);

    @WebFilter(urlPatterns = {
        "*.js",
        "*.css",
        "*.pdf",
        "*.image",
        "*.xls",
        "*.xml",
        "*.staticjson",
    })
    public static class Filter900Cache_Long extends Filter900Cache {
        @Override
        public String getCacheControl() {
            return "max-age=86400";
        }
    }

    @WebFilter(urlPatterns = {"*.json"})
    public static class Filter900Cache_Short extends Filter900Cache {
        @Override
        public String getCacheControl() {
            return "max-age=600";
        }
    }

    @WebFilter(urlPatterns = {"*.jsp"})
    public static class Filter900Cache_No extends Filter900Cache {
        @Override
        public String getCacheControl() {
            return "no-cache, must-revalidate";
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        if (req.getMethod().equalsIgnoreCase("GET")) {
            chain.doFilter(request, new HttpServletResponseWrapper(res) {
                @Override
                public ServletOutputStream getOutputStream() throws IOException {
                    if (getStatus() >= 200 && getStatus() < 400) {
                        setHeader("Cache-Control", getCacheControl());
                    }
                    return super.getOutputStream();
                }
                @Override
                public PrintWriter getWriter() throws IOException {
                    if (getStatus() >= 200 && getStatus() < 400) {
                        setHeader("Cache-Control", getCacheControl());
                    }
                    return super.getWriter();
                }
                @Override
                public void sendError(int sc, String msg) throws IOException {
                    if (sc >= 200 && sc < 400) {
                        setHeader("Cache-Control", getCacheControl());
                    }
                    super.sendError(sc, msg);
                }
                @Override
                public void sendError(int sc) throws IOException {
                    if (sc >= 200 && sc < 400) {
                        setHeader("Cache-Control", getCacheControl());
                    }
                    super.sendError(sc);
                }
                @Override
                public void setStatus(int sc) {
                    if (sc >= 200 && sc < 400) {
                        setHeader("Cache-Control", getCacheControl());
                    }
                    super.setStatus(sc);
                }
            });
        } else {
            // pass the request/response on
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {
    }

    public String getCacheControl() {
        return "";
    }

}
