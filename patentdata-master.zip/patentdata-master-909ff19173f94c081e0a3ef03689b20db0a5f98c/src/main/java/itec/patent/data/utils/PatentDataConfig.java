package itec.patent.data.utils;

import itec.patent.common.MongoInitUtils;
import itec.patent.data.param.DataParamContext;
import itec.patent.mongodb.Pto;

import java.io.File;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.LinkedList;

import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.tsaikd.java.mongodb.MongoObject;
import org.tsaikd.java.utils.ConfigUtils;

public class PatentDataConfig extends MongoObject {

    public static HashMap<Pto, LinkedList<File>> datapathPtoMap = new HashMap<>();

    public static HashMap<Pto, LinkedList<File>> cachepathPtoMap = new HashMap<>();

    public static HashMap<Pto, LinkedList<File>> epoopspathPtoMap = new HashMap<>();

    public static HashMap<Pto, LinkedList<File>> googlepatentpathPtoMap = new HashMap<>();

    public static HashMap<Pto, LinkedList<File>> cniprpathPtoMap = new HashMap<>();

    public static HttpSolrServer patentwebSolr = new HttpSolrServer("");
    
    private static Boolean ptopidEnabled = ConfigUtils.getBool("ptopidEnabled", false);

    static {
        reload();
    }

    protected static void addConfigList(String confkey, LinkedList<File> list) {
        File file = new File(ConfigUtils.get(confkey, ""));
        if (file.isDirectory()) {
            list.add(file);
        }
    }

    public static void reload() {
        datapathPtoMap.clear();
        cachepathPtoMap.clear();
        epoopspathPtoMap.clear();
        googlepatentpathPtoMap.clear();
        cniprpathPtoMap.clear();

        patentwebSolr = new HttpSolrServer(ConfigUtils.get("patentweb.solr", "http://127.0.0.1:8080/solr/core0"));

        for (Pto pto : Pto.values()) {
            LinkedList<File> list;
            String confkey;

            list = new LinkedList<>();
            confkey = String.format("data.path.%s", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("data.path.%s2", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("data.path.%s3", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("data.path", list);
            addConfigList("data.path2", list);
            addConfigList("data.path3", list);
            datapathPtoMap.put(pto, list);

            list = new LinkedList<>();
            confkey = String.format("cache.path.%s", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cache.path.%s2", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cache.path.%s3", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("cache.path", list);
            addConfigList("cache.path2", list);
            addConfigList("cache.path3", list);
            cachepathPtoMap.put(pto, list);

            list = new LinkedList<>();
            confkey = String.format("epoops.path.%s", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("epoops.path.%s2", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("epoops.path.%s3", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("epoops.path", list);
            addConfigList("epoops.path2", list);
            addConfigList("epoops.path3", list);
            epoopspathPtoMap.put(pto, list);

            list = new LinkedList<>();
            confkey = String.format("googlepatent.path.%s", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("googlepatent.path.%s2", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("googlepatent.path.%s3", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("googlepatent.path", list);
            addConfigList("googlepatent.path2", list);
            addConfigList("googlepatent.path3", list);
            googlepatentpathPtoMap.put(pto, list);

            list = new LinkedList<>();
            confkey = String.format("cnipr.path.%s", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cnipr.path.%s2", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cnipr.path.%s3", DataParamContext.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("cnipr.path", list);
            addConfigList("cnipr.path2", list);
            addConfigList("cnipr.path3", list);
            cniprpathPtoMap.put(pto, list);
        }

        try {
            MongoInitUtils.reload();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static void nothing() {}

    public static Boolean isPtopidEnabled() {
        return ptopidEnabled;
    }

    public static void setPtopidEnabled(Boolean ptopidEnabled) {
        PatentDataConfig.ptopidEnabled = ptopidEnabled;
    }

}
