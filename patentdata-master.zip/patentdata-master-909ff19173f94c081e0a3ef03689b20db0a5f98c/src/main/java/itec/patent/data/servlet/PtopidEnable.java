package itec.patent.data.servlet;

import itec.patent.data.utils.PatentDataConfig;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet(urlPatterns = "/ptopid.enable")
public class PtopidEnable extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(PtopidEnable.class);
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        PatentDataConfig.setPtopidEnabled(!PatentDataConfig.isPtopidEnabled());
        ServletOutputStream out = res.getOutputStream();
        out.println("ptopidEnabled: " + PatentDataConfig.isPtopidEnabled());
        out.close();
    }

}
