package itec.patent.data.utils;

import itec.patent.data.param.PatentFile;
import itec.patent.data.utils.ImageUtils.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;

public class PDFBoxUtils {

	static Log log = LogFactory.getLog(PDFBoxUtils.class);
	
	 /**
	  * split first page of fullpdf
	 * @param pfile
	 * @throws IOException
	 */
	public static void splitFirstPagePDF(PatentFile pfile) throws IOException {
		if (!pfile.file.exists()) {
			return;
		}
		//get cache file
		File cacheFile = ImageUtils.getCacheFile(pfile, Paths.get("firstPage.pdf"));
		FileUtils.sureDirExists(cacheFile.getParentFile(), false);

		try {
			//load fullpage.pdf
			PDDocument pdDoc = PDDocument.load(pfile.file.getAbsolutePath());
			//split fullpage to list
			List<PDDocument> pdDocList = new Splitter().split(pdDoc);
			//get firstpage pdf
			PDDocument pd = pdDocList.listIterator().next();
			//save to cache
			pd.save(cacheFile);

		} catch (COSVisitorException anException) {
			log.error("Something went wrong with splitFirstPagePDF , file: " + pfile.file.getAbsolutePath() + ", error: " + anException);
		}
	 }
	
}
