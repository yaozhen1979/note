package itec.patent.data.param;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.nio.file.Path;
import java.util.Date;
import java.util.LinkedList;

public class PatentPath {
    public PatentInfo2 info;
    public LinkedList<Path> paths = new LinkedList<>();

    public PatentPath(PatentInfo2 info, Path... paths) {
        this.info = info;
        for (Path path : paths) {
            this.paths.add(path);
        }
    }

    public PatentPath(String pto, int stat, String kindcode, Date doDate, String pn, Path... paths) {
        this.info = PatentInfo2.newInfo(Pto.valueOf(pto.toUpperCase()));
        this.info.stat = stat;
        this.info.kindcode = kindcode;
        this.info.doDate = doDate;
        this.info.patentNumber = pn;
        for (Path path : paths) {
            this.paths.add(path);
        }
    }
}
