package itec.patent.data.servlet;

import itec.patent.data.utils.PatentDataConfig;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

@WebServlet(loadOnStartup = 1, urlPatterns = {"/__init__"})
public class InitServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    static Log log = LogFactory.getLog(InitServlet.class);

    static {
        ConfigUtils.setSearchBase(InitServlet.class);
        PatentDataConfig.nothing();
    }

    static public void nothing() {}

}
