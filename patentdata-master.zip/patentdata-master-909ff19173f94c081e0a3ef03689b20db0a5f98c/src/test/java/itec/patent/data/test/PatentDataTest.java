package itec.patent.data.test;

import itec.patent.common.MongoInitUtils;

import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

public class PatentDataTest {

    static Log log = LogFactory.getLog(PatentDataTest.class);

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(PatentDataTest.class);
        MongoInitUtils.nothing();
    }

    public static void main(String[] args) throws Exception {
        if (PatentDataTest.class.getSimpleName().equals("PatentDataTest")) {
        }
        log.debug("finished");
    }

}
