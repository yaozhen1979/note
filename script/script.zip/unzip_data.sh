#!/bin/bash

path="/mnt/patentsource/CN/SIPO/1-3/FullText/2007/XX"
unzip_path="/mnt/patentsource/CN/SIPO/fullText/2007/XX"

cd $path

# for i in $(find /mnt/patentsource/CN/SIPO/1-3/FullText/2015/FM -type f -printf "%f\n")
for i in $(find . -type f -printf "%f\n")
do
  #echo "file name = ${i}"
  zipPath="${path}/${i}"
  #echo "zip path = ${zipPath}"
  doDate="${i:0:8}"
  #echo "doDate = ${doDate}"
  unzipPath="$unzip_path/$doDate"
  #echo "unzip path = ${unzipPath}"a

  mkdir -p ${unzipPath} &&
  unzip ${zipPath} -d ${unzipPath}
  
done

echo "finished..."

