#!/bin/bash

#echo "\$0 ==> $0"
#echo "\$1 ==> $1"
#echo "\$2 ==> $2"

echo "===count cn image count==="
echo "===count $1.$2.$3==="

FM=`ls -d /mnt/nhdell/patent_cn/data/cn1a/$1/$2/$3/*/ | wc -l`
SD=`ls -d /mnt/nhdell/patent_cn/data/cn2b/$1/$2/$3/*/ | wc -l`
XX=`ls -d /mnt/nhdell/patent_cn/data/cn2u/$1/$2/$3/*/ | wc -l`
WG=`ls -d /mnt/nhdell/patent_cn/data/cn2s/$1/$2/$3/*/ | wc -l`

echo "FM = $FM"
echo "SD = $SD"
echo "XX = $XX"
echo "WG = $WG"

echo "=====finished====="
