#!/bin/bash

#echo "\$0 ==> $0"
#echo "\$1 ==> $1"
#echo "\$2 ==> $2"

echo "===rsync cn img==="

#WG=`ls -d /mnt/nhdell/patent_cn/data/cn2s/$1/$2/$3/*/ | wc -l`
#echo "WG = $WG"

sudo rsync -av /mnt/share/cn_img/FM/20160518/. /mnt/nhdell/patent_cn/data/cn1a/2016/05/18/
sudo rsync -av /mnt/share/cn_img/SD/20160518/. /mnt/nhdell/patent_cn/data/cn2b/2016/05/18/
sudo rsync -av /mnt/share/cn_img/XX/20160518/. /mnt/nhdell/patent_cn/data/cn2u/2016/05/18/
sudo rsync -av /mnt/share/cn_img/WG/3220/. /mnt/nhdell/patent_cn/data/cn2s/2016/05/18/

echo "=====finished====="
