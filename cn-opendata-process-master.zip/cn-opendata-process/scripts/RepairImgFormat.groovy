import org.apache.commons.io.FileUtils
import org.utils.FileUtil
import org.utils.RestTimeProcess

// D:\temp\opendata_img\FM\2015\09\23\201180019236.4

File destDir = new File("D:/temp/opendata_img/XX/2015/09/23")
        
def fileCount = destDir.listFiles().size()
println "fileCount = ${fileCount}"
        
RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)

destDir.listFiles().each { it -> 
    
    it.eachFile { file1 ->
        
        if (file1.isDirectory()) {
            file1.eachFile { file2 ->
                // println file2.name
                renameFile(file2)
            }
        } else {
            // println file1.name
            renameFile(file1)
        }
        
    }
    
    restTimeProcess.process()
}

println "finished..."

def renameFile(File file) {
    
    if (file.name.endsWith("TIFF") || file.name.endsWith("tiff")) {
        def newFileName = file.name.replaceAll(/(TIFF|tiff)/, "TIF")
        def newFilePath = file.getParentFile().getAbsolutePath() + "/" + newFileName
        // println "newFilePath = ${newFilePath}"
        FileUtils.moveFile(file, new File(newFilePath))
        // println "rename ok..."
    }
}