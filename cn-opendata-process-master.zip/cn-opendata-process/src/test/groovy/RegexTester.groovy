// 

// def ipc = "H04N   15/12"
// println ipc ==~ /\w{4}\s+\d{1,4}\/\d{1,6}[\s]*(\(\d{4}\.\d{2}\))?/


//def regexPattern = /^\d{1,2}[\s\-]*(\d{1,4})(\s)*/
//
//def loc = "03-03(10)"
//
//loc.find(regexPattern) { it -> 
//    println it[0]
//}


def citedPatent = "US 4163929 1979.08.07"

citedPatent.find(/\d{4}\.\d{2}\.\d{2}/) { it -> 
    println it
}

