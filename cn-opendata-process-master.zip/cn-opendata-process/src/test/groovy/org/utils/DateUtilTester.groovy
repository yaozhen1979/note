package org.utils;

import static org.junit.Assert.*;

import org.junit.Test;
import org.utils.DateUtil;

public class DateUtilTester {

    @Test
    public void testParseChineseDate() {
        
        println DateUtil.parseChineseDate("2016年3月30日")
        
    }

}
