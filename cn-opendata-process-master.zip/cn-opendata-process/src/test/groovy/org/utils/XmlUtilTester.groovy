package org.utils;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class XmlUtilTester {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testGenerateCnOpenDataJsonObject() {
        
        String xmlStr = new File("opendata-sample/0-us/20150342107.xml").text
        
        println org.utils.XmlUtil.generateCnOpenDataJsonObject(xmlStr)
        
    }
    
    // @Test
    public void testParseClaim() {
        
        String xmlStr = new File("opendata-sample/0-us/20150342107.xml").text
        
        org.utils.XmlUtil.parseClaim(xmlStr, 0)
        
    }

}
