package org.img

import org.exception.CnException
import org.service.BaseService;
import org.utils.DateUtil
import org.utils.FileUtil
import org.utils.RestTimeProcess
import org.utils.MailUtil
import org.utils.MongoUtil

class ImageCopyProcess2 extends BaseService {
    
    private final static String IMAGE_FORMAT = ".TIF"
    private final static String FIRST_IMAGE_NAME = "firstImage" + IMAGE_FORMAT
    private final static String CLIP_IMAGE_FOLER = "clip"
    private final static String EMBED_IMAGE_FOLDER = "figure"
    
    def void process(def args, def period) {
        
        String argDoPath = args.argDoPath
        String patentType = args.patentType
        Date doDate = DateUtil.parseDate(period);
        log.info "args = ${args}"
        log.info "doDate = ${doDate}"
        
        File dir = new File(RAW_DATA_FOLDER_PATH + argDoPath)
        println "path = ${RAW_DATA_FOLDER_PATH + argDoPath}"
        
        File fileLog = new File("logs/ImageCopyProcess.log")
        
        if (!dir.exists()) {
            throw new Exception("No Raw Data Folder Exist")
        }
        
        // IMAGE_DATA_FOLDER_PATH
        File destDir = new File(IMAGE_DATA_FOLDER_PATH + "/"+ argDoPath)
        if (!destDir.exists()) {
            FileUtil.mkdir(destDir)
        }
        
        def fileCount = dir.listFiles().size()
        println "fileCount = ${fileCount}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, this.class.name)
        
        // def dbClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, MONGODB_IP, MONGODB_PORT, 'admin')
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        def db = dbClient.getDB("PatentMarshallCN")
        def patentMarshallCN = db.getCollection("PatentMarshallCN")
        
        dir.listFiles().eachWithIndex { File folder, index ->
            
            def sipoNumber = folder.name;
            def queryMap = [doDate: doDate, sipoNumber: sipoNumber]
            
            def imgData = null
            try {
                imgData = queryImgData(patentMarshallCN, queryMap)
            } catch (e) {
                throw new Exception("queryMap = ${queryMap}, e = ${e.toString()}")
            }
            // println "imgData = ${imgData}"
            def appNumber = imgData.appNumber;
            
            folder.listFiles().each { File file ->
                
                // println "file name = ${file.name}"
                if (!file.name.toUpperCase().contains("XML") && (file.name != "Thumbs.db") && (!file.name.toUpperCase().contains("ERROR"))) {
                    
                    def firstImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/" + FIRST_IMAGE_NAME
                    def clipImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/clip"
                    def embedImagePath = destDir.getAbsolutePath() + "/" + appNumber + "/figure"
                    
                    // check image format
                    if (!file.name.endsWith("TIF")) {
                        throw new CnException("CN OPEN DATA image format error => ${appNumber}, ${folder.getAbsolutePath()}/${file.name}")
                    }
                    
                    def imgName = file.name; // .replace(IMAGE_FORMAT, "")
                    
                    if (imgData.firstImg == imgName) {
                        // println "it is first image"
                        FileUtil.copyFileUsingStream(file, new File(firstImagePath))
                    } else if (imgData.clipImgList.containsValue(imgName)) {
                        // println "it is clip image"
                        imgData.clipImgList.each { k, v -> 
                            if (v == imgName) {
                                def clipImageName = k + IMAGE_FORMAT;
                                // println "clipImageName = ${clipImageName}"
                                FileUtil.copyFileUsingStream(file, new File(clipImagePath + "/" + clipImageName))
                            }
                        }
                    } else {
                        // println "it is embed image"
                        FileUtil.copyFileUsingStream(file, new File(embedImagePath + "/" + file.name))
                    }
                    
                }  // end if (!it.name.toUpperCase().contains("XML"))
                
            }  // end folder.listFiles()
            
            restTimeProcess.process()
            
        }
        
        dbClient.close()
        
        /*
        MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data Img : doDate = ${doDate}, patentType= ${patentType}",
            "cn open data image move completed, doDate = ${doDate}, patentType= ${patentType}")
        */
        
    }  // end process
    
    /**
     * 
     * @param queryMap
     * @return
     */
    def queryImgData(def patentMarshallCN, def queryMap) throws Exception {
        
        def queryCursor = patentMarshallCN.find(queryMap);
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        def imgData = ["firstImg" : "", "clipImgList" : [:], "appNumber" : ""]
        // println "queryCursor.size() = ${queryCursor.size()}"
        
        if (queryCursor.size() > 1) {
            throw new Exception("queryMap = ${queryMap}, query over 1 count...")
        }
        
        def queryData = queryCursor[0]
        if (!!queryData) {
            
            // appNumber
            imgData.appNumber = queryData.appNumber;
            
            // clip image
            def clipImgDataList = queryData.data.expansion."cn-patent-document"."application-body"?."drawings"?."figure"
            if (!!clipImgDataList) {
                clipImgDataList.each { clip ->
                    // println clip.img.file
                    // "figure-labels" : "图1"
                    // "num" : "0003"
                    try {
                        def imagePage = clip."num" as int
                        // NOTE: key = 圖片頁數, value = 圖片檔名
                        imgData.clipImgList << ["${imagePage}" : clip.img.file]
                    } catch(e) {
                        throw new Exception("queryData = ${queryData}, e = {e.toString()}")
                    }
                }
            }
            
            // first image
            def firstImgData = queryData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing"?."figure"?."img"
            if (!!firstImgData) {
                // println "first image file name = ${firstImgData.file}"
                imgData.firstImg = firstImgData.file
            }
            
        } else {
            throw new Exception("no marshall data find...by queryMap = ${queryMap}")
        }
        
        return imgData
    }
    
    static main(args) {
        
        /*
         * 已完成期數
         */
        def year = "2016"
        def period = "20160511"
        
        // 20160427, skip FM, CN112013000013679CN0000104812762A8TXTZH20160427CN009
        // "FM", "SD", "XX"
        ["FM", "SD", "XX"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['argDoPath' : "${patentType}/${year}/${period}"]
            argMap << ['patentType' : patentType]
            
            new ImageCopyProcess2().process(argMap, period);
            
        }
        
        println "finished..."
        
    }
    
}
