package org.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {
    
    private static Properties properties = PropertiesUtil.load("config.properties");
    
    /**
     * 
     * @param fileName 設定檔名稱
     * @return
     */
    private static Properties load(final String fileName) {

        Properties prop = new Properties();
        InputStream is = null;

        try {
            // TODO: hard code...
            is = FileUtil.searchPropFromResource(fileName);
            // load a properties file
            prop.load(is);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return prop;
    }
    
    public static String getXsdFile() {
        return properties.getProperty("xsd_file");
    }
    
    public static String getWgXsdFile() {
        return properties.getProperty("wg_xsd_file");
    }
    
    public static String getRawLevelCode() {
        return properties.getProperty("raw_level_code");
    }
    
    public static String getMarshallLevelCode() {
        return properties.getProperty("marshall_level_code");
    }
    
    public static String getInfoLevelCode() {
        return properties.getProperty("info_level_code");
    }
    
    public static String getVersionTag() {
        return properties.getProperty("version_tag");
    }
    
    public static String getRawDB() {
        return properties.getProperty("raw_db");
    }
    
    public static String getRawCol() {
        return properties.getProperty("raw_col");
    }
    
    public static String getRawErrCol() {
        return properties.getProperty("raw_err_col");
    }
    
    public static String getMarshallDB() {
        return properties.getProperty("marshall_db");
    }
    
    public static String getMarshallCol() {
        return properties.getProperty("marshall_col");
    }
    
    public static String getMarshallErrCol() {
        return properties.getProperty("marshall_err_col");
    }
    
    public static String getInfoDB() {
        return properties.getProperty("info_db");
    }
    
    public static String getInfoCol() {
        return properties.getProperty("info_col");
    }
    
    public static String getInfoErrCol() {
        return properties.getProperty("info_err_col");
    }
    
    public static void main(String[] args) {
        
        // println PropertiesUtil.getMetaClass().getTheClass().getResourceAsStream("../../config.properties")
        // println PropertiesUtil.getWgXsdFile()
        
    }
    
}
