package org.utils

import java.io.File;
import java.util.Date;

import org.common.Constants

/**
 * 設定存入[PatentMarshallCN]的資料內容
 * 
 * @author tonykuo
 *
 */
class RawDataUtil {
    
    /**
     * mongodb schema <br/>
     *
     * unique key = patentNumber + path => 其實個別都可以當成unique key... <br/>
     *
     * _id: mongodb object id => 保留原objectId, 如之後以patentNumber有_id, 則可變更. <br/>
     * provider: 資料源提供者 <br/>
     * sourceType: 處理檔案格式 <br/>
     * doDate: 公佈日 <br/>
     * pto: Patent and Trademark Office <br/>
     * truncate: 是否有切檔 <br/>
     * patentType: 專利資料類型: FM, SD, XX, WG
     * xsd: 檢證XML之XSD => xsd 改為抓取 Gitlab ??? <br/>
     * <br/>
     * data: 處理[data], 如現在資料已有bibo, claim, description, 則保存. <br/>
     * data.text: CN Open Data Raw Data <br/>
     * <br/>
     * NOTE: path: 處理檔案所在路徑 => WG 的處理路徑統一, 不依照舊有格式(WG/2015/3138/[appNumber]). <br/>
     * patentNumber: 預計之後的_id是以patentNumber來取代, 而不使用ObjectId. => 格式為 CN + doDate + patentNumber + kindcode <br/>
     * <br/>
     * mongoSyncFlag.init: 該筆資料最初處理時間 <br/>
     * mongoSyncFlag.last: 該筆資料最後處理時間 <br/>
     *
     * @param xmlStr
     * @param expansionDataMap Patent Type = WG, 才會傳入.
     * @param doDate
     * @param path
     * @param patentType
     * @param existData
     * @return
     */
    static generateRawData(String text, Date doDate, String path, String patentType, def existData) {
        
        def now = new Date()
        def rawData = [:]
        
        rawData << ["provider" : Constants.DATA_PROVIDER]
        rawData << ["doDate" : doDate]
        rawData << ["pto" : Constants.PTO]
        rawData << ["truncate" : false]
        rawData << ["patentType" : patentType]
        
        if (patentType == "WG") {
            rawData << ["soureType" : "txt"]
        } else {
            rawData << ["soureType" : "xml"]
            rawData << ["xsd" : Constants.XSD_FILE_PATH]
        }
        
        if (!!existData) {
            // 保留原有objectId
            rawData << ["_id" : existData._id]
            // 如現在資料已有bibo, claim, description, 則保存.
            def dataMap = existData.data
            dataMap.text = text
            rawData << ["data": dataMap]
        } else {
            def dataMap = [:] << ["text" : text]
            rawData << ["data" : dataMap]
        }
        
        // NOTE: 2015-11-23 會再補上appNumber是為在marshall而用, 並且在找出clip, embed, first image時的資料夾名稱.
        // NOTE: 2016-04-16 SIPO 資料的檔名就不是會appNumber了, 所以raw data中的appNumber基本就是判別是否為SIPO資料而已.
        rawData << ["appNumber" : path.split("/")[3].trim()]
        rawData << ["path" : path]
        rawData << MiscUtil.getTagAndFile(existData, "rawLevel")
        rawData << MiscUtil.getMongoSyncFlag(existData)
        
        return rawData
        
    }  // end generateRawData function
    
}
