package org.utils

/**
 * 
 * @author tonykuo
 *
 */
class CaptchaUtil {
    
    /**
     * 
     * @param appNumber
     * @param isDot appNumber是否要包含著逗點
     * @return
     */
    public static genAppNumberWithCaptcha(String appNumber, boolean isDot) throws Exception {
        
        String originNumber = appNumber;
        int mod = genCaptcha(appNumber);
        
        if (!mod.toString()) {
            return originNumber;
        } else if (mod == 10) {
            return isDot == true ? originNumber + '.X' : originNumber + 'X'; 
        } else {
            return isDot == true ? originNumber + '.' + mod.toString() : originNumber + mod.toString(); 
        }
        
    }
    
    public static int genCaptcha(String appNumber) throws Exception {
        
        int mod;
        int divisor = 11;
        // number to string
        String[] checkNumber = appNumber.toCharArray();

        if (!!checkNumber) {

            if (checkNumber.length == 12) {

                int x4 = checkNumber[0] as int;
                int x3 = checkNumber[1] as int;
                int x2 = checkNumber[2] as int;
                int x1 = checkNumber[3] as int;
                int y = checkNumber[4] as int;
                int z7 = checkNumber[5] as int;
                int z6 = checkNumber[6] as int;
                int z5 = checkNumber[7] as int;
                int z4 = checkNumber[8] as int;
                int z3 = checkNumber[9] as int;
                int z2 = checkNumber[10] as int;
                int z1 = checkNumber[11] as int;

                int total = x4 * 2 + x3 * 3 + x2 * 4 +
                    x1 * 5 + y * 6 + z7 * 7 + z6 * 8 + z5 * 9 +
                    z4 * 2 + z3 * 3 + z2 * 4 + z1 * 5;

                mod = total % divisor;

            } else if (checkNumber.length == 8) {

                int x4 = checkNumber[0] as int;
                int x3 = checkNumber[1] as int;
                int x2 = checkNumber[2] as int;
                int x1 = checkNumber[3] as int;
                int y = checkNumber[4] as int;
                int z7 = checkNumber[5] as int;
                int z6 = checkNumber[6] as int;
                int z5 = checkNumber[7] as int;

                int total = x4 * 2 + x3 * 3 + x2 * 4 +
                    x1 * 5 + y * 6 + z7 * 7 + z6 * 8 + z5 * 9;

                mod = total % divisor;

            } else {
                // throw "appNumber length error"
                throw new Exception("appNumber length is not equal 8 or 12 error");
            }

        } else {
            // return originNumber;
            throw new Exception("checkNumber is empty error");
        }   // end if (!!checkNumber)
        
        return mod;
    }
    
}
