package org.utils

import org.common.Constants
import org.utils.XmlUtil

class MarshallDataUtil {
    
    /**
     * 
     * @param expansionDataMap
     * @param doDate
     * @param patentType
     * @param existData = null
     * @return
     */
    static generateMarshallData(def expansionDataMap, def rawData, def existData = null) {
        
        def marshallData = [:]
        
        // cn open data 是使用 rawData.appNumber
        
        marshallData << ["doDate" : rawData.doDate]
        marshallData << ["pto" : Constants.PTO]
        marshallData << ["patentType" : rawData.patentType]
        
        def patentNumber = null;
        if (rawData.patentType == "WG") {
            patentNumber = expansionDataMap.patentNumber
            // 
            marshallData << ["appNumber" : rawData.appNumber]
        } else {
            patentNumber = XmlUtil.getPatentNumber(expansionDataMap)
            // sipo 則是使用
            marshallData << ["appNumber" :  XmlUtil.getAppNumber(expansionDataMap)]
            marshallData << ["sipoNumber" :  rawData.appNumber]
        }
        marshallData << ["patentNumber" : patentNumber]
        
        if (!!existData) {
            
            // 保留原有objectId
            marshallData << ["_id" : existData._id]
            // 如現在資料已有bibo, claim, description, 則保存.
            def dataMap = existData.data
            dataMap.expansion = expansionDataMap
            marshallData << ["data": dataMap]
            
        } else {
            def dataMap = [:] << ["expansion" : expansionDataMap]
            marshallData << ["data" : dataMap]
        }
        
        marshallData << MiscUtil.getRelRawdatas(rawData, existData, patentNumber)
        marshallData << MiscUtil.getTagAndFile(existData, "marshallLevel")
        marshallData << MiscUtil.getMongoSyncFlag(existData)

        return marshallData
        
    }  // end generateRawData function
    
}
