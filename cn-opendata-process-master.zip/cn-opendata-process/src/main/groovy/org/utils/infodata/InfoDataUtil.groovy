package org.utils.infodata

import org.utils.DateUtil
import org.utils.StringUtil
import org.utils.MiscUtil
import org.exception.CnException
import org.error.CnDataErrorProcess

class InfoDataUtil extends BaseInfoData {
    
    /**
     * 
     * For FM, SD, XX
     * 
     * @param marshallData
     * @param existInfoData
     * @return
     */
    static generateInfoData(def marshallData, def existInfoData, def errorPatentInfoCNIPR) {
        
        def infoData = [:]
        def tempData = setTempDate(marshallData)
        
        def agents = getAgents(marshallData)
        if (agents.size() > 0) {
            infoData << ["agents" : agents]
        }
        
        def agentOperators = getAgentOperators(marshallData)
        if (agentOperators.size() > 0) {
            infoData << ["agentOperators" : agentOperators]
        }
        
        def inventors = getInventors(marshallData)
        if (inventors.size() > 0) {
            infoData << ["inventors" : getInventors(marshallData)]
        }
        
        def assignees = getAssignees(marshallData)
        if (assignees.size() > 0) {
            infoData << ["assignees" : assignees]
        }
        
        infoData << ["appNumber" : getAppNumber(marshallData)]
        infoData << ["appNumberNormal" : getAppNumberNormal(marshallData)]
        infoData << ["appDate" : getAppDate(marshallData)]
        infoData << ["brief" : getBrief(marshallData)]
        infoData << ["claim" : getClaim(marshallData)]
        infoData << ["country" : getCountry(marshallData)]
        infoData << ["description" : getDescription(marshallData)]
        infoData << ["doDate" : getDoDate(marshallData)]
        
        def filePageNumber = getFilePageNumber(marshallData)
        if (!!filePageNumber) {
            infoData << ["filePageNumber" : getFilePageNumber(marshallData)]
        }
        def firstImgInfo = getFirstImgInfo(marshallData)
        if (!!firstImgInfo) {
            infoData << ["firstImgInfo" : getFirstImgInfo(marshallData)]
        }
        
        if (marshallData.patentType == "FM" || marshallData.patentType == "SD" ||
            marshallData.patentType == "XX") {
            infoData << ["mainIPC" : getMainIPC(marshallData, errorPatentInfoCNIPR, tempData)]
            infoData << ["mainIPCNormal" : getMainIPCNormal(marshallData, errorPatentInfoCNIPR, tempData)]
            infoData << ["ipcs" : getIpcs(marshallData, errorPatentInfoCNIPR, tempData)]
            infoData << ["ipcsNormal" : getIpcsNormal(marshallData, errorPatentInfoCNIPR, tempData)]
        } else {
            def errMsg = "Exception = error patentType = ${marshallData.patentType}"
            log.error errMsg
            throw new Exception(errMsg)
        }
        
        infoData << ["kindcode" : getKindcode(marshallData)]
        infoData << ["patentNumber" : getAppNumber(marshallData)]
        
        def stat = getStat(marshallData)
        infoData << ["stat" : stat]
        
        if (stat == 1) {
            infoData << ["openDate" : getDoDate(marshallData)]
            infoData << ["openNumber" : getPatentNumber(marshallData)]
            infoData << ["openNumberNormal" : getPatentNumber(marshallData)]
        } else if (stat == 2) {
            infoData << ["decisionDate" : getDoDate(marshallData)]
            infoData << ["decisionNumber" : getPatentNumber(marshallData)]
            infoData << ["decisionNumberNormal" : getPatentNumber(marshallData)]
        }
        
        infoData << ["title" : getTitle(marshallData)]
        
        // PCT Data => 尚未使用
        def pctNationFilingData = getPctNationFilingData(marshallData)
        if (pctNationFilingData.size() > 0) {
            infoData << ["pctNationFilingData" : pctNationFilingData]
        }
        def pctOrRegionalPublishingData = getPctOrRegionalPublishingData(marshallData)
        if (pctOrRegionalPublishingData.size() > 0) {
            infoData << ["pctOrRegionalPublishingData" : pctOrRegionalPublishingData]
        }
        
        // PCT Data => 為配合目前(2015.11.19)Solr而使用
        def pctAppDate = getPctAppDate(marshallData)
        if (!!pctAppDate) {
            infoData << ["pctAppDate" : pctAppDate]
        }
        
        def pctAppNumber = getPctAppNumber(marshallData)
        if (!!pctAppNumber) {
            infoData << ["pctAppNumber" : pctAppNumber]
        }
        
        def pctOpenDate = getPctOpenDate(marshallData)
        if (!!pctOpenDate) {
            infoData << ["pctOpenDate" : pctOpenDate]
        }
        
        def pctOpenNumber = getPctOpenNumber(marshallData)
        if (!!pctOpenNumber) {
            infoData << ["pctOpenNumber" : pctOpenNumber]
        }
        
        def gazetteNumber = getGazetteNumber(marshallData)
        if (!!gazetteNumber) {
            infoData << ["gazetteNumber" : gazetteNumber]
        }
        
        def gazettePublicDate = getGazettePublicDate(marshallData)
        if (!!gazettePublicDate) {
            infoData << ["gazettePublicDate" : gazettePublicDate]
        }
        
        // citedPatents 有資料 ??? => 201410218369.X => db.PatentMarshallCN.find({patentNumber: 'CN103977133B'})
        def citedPatents = getCitedPatents(marshallData)
        if (citedPatents.size() > 0) {
            infoData << ["citedPatents" : citedPatents]
        }
        
        // otherReferences 有資料 ??? => db.PatentMarshallCN.find({patentNumber: 'CN103977133B'})
        def otherReferences = getOtherReferences(marshallData)
        if (otherReferences.size() > 0) {
            infoData << ["otherReferences" : otherReferences]
        }
        
        // priorityPatents => db.PatentMarshallCN.find({patentNumber: 'CN104929793A'})
        def priorityPatents = getPriorityPatents(marshallData)
        if (priorityPatents.size() > 0) {
            infoData << ["priorityPatents" : priorityPatents]
        }
        
        // TODO: clipPageNumber
        
        infoData << generateBasicData(marshallData, existInfoData)
        
        return infoData
    }
    
    private static getAppDate(def marshallData) {
        def appNumber = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."application-reference"."document-id"."date"
        return DateUtil.parseDate(appNumber)
    }
    
    /**
     * NOTE: 目前前台所使用的欄位, 但實際為顯示代理機構, 而非代理人.
     * 
     * @param marshallData
     * @return
     */
    private static getAgents(def marshallData) {
        
        def agentList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-parties"."cn-agents"."cn-agent"
        
        def agents = []
        agentList.each { it -> 
            // CN 有代理機構欄位, 為[cn-agency]
            def agency = it."cn-agency"[0]."name"[0].value
            agents << agency
        }
        
        // NOTE: 排除重複資料, 但目前CN尚未看到有二筆以上不同的代理機構, 所以也無沒法判斷資料正確性
        def agentSet = []
        agents.toSet().each { it -> 
            agentSet << [name : [origin: it]]
        }
        
        return agentSet
    }
    
    private static getAgentOperators(def marshallData) {
        
        def agentOperatorList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-parties"."cn-agents"."cn-agent"
        def agentOperator = []
        
        agentOperatorList.each { it ->
            
            // CN 有代理機構欄位, 為[cn-agency]
            def agency = it."cn-agency"[0]."name"[0].value
            // agent為代理人, 為CN OPEN DATA所額外加入的欄位
            def agent = it."name"[0].value
            
            agentOperator << [
                name: [origin: agent],
                agency : [origin: agency]
            ];
        }
        
        return agentOperator
    }
    
    private static getAppNumber(def marshallData) {
        def appNumber = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."application-reference"."document-id"."doc-number"
        return appNumber
    }
    
    private static getAppNumberNormal(def marshallData) {
        
        def appNumber = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."application-reference"."document-id"."doc-number"
        def appNumberNormal = "CN" + appNumber.replace(".", "")
        
        return appNumberNormal
    }
    
    private static getAssignees(def marshallData) {
        
        def addressbookList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-parties"."cn-applicants"."cn-applicant"
        
        def assignees = []
        addressbookList.each { addressbook -> 
            
            def address =  addressbook.addressbook[0].address[0].text
            def name = addressbook.addressbook[0].name[0].value
            def assignee = [:]
            
            assignee << [name : [origin: name]]
            if (!!address) {
                assignee << [address: [origin: address]]
            }
            // open data xml 缺CNIPR中的[國省代碼], 所以不會有[country]的欄位資料 => 2016.03.03, 神回小屁孩2號, 讓他當場啞口無言 !!!
            
            assignees << assignee
        }
        
        return assignees 
    }
    
    private static getBrief(def marshallData) {
        def brief = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."abstract"
        return [origin: brief]
    }
    
    private static getClaim(def marshallData) {
        def claim = marshallData.data.expansion."cn-patent-document"."application-body"."claims"
        return [origin: claim]
    }
    
    private static getCountry(def marshallData) {
        def documentId = getCnPublicationReference(marshallData)
        return documentId.country
    }
    
    private static getDescription(def marshallData) {
        def description = marshallData.data.expansion."cn-patent-document"."application-body"."description"
        return [origin: description]
    }
    
    private static getDoDate(def marshallData) {
        def documentId = getCnPublicationReference(marshallData)
        def doDate = documentId.date
        return DateUtil.parseDate(doDate)
    }
    
    private static getFilePageNumber(def marshallData) {
        
        if (!!marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing") {
            return marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing"."figure"."num" as int
        } else {
            return null
        }
        
    }
    
    private static getFirstImgInfo(def marshallData) {
        
        if (!!marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing") {
            def fileName = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing"."figure"."img"."file"
            def imgForamt = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-abstract-drawing"."figure"."img"."img-format"
            return ["file" : fileName, "img-format" : imgForamt]
        } else {
            return null
        }
        
    }
    
    private static getInventors(def marshallData) {
        
        def inventorList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-parties"."cn-inventors"."cn-inventor"
        
        def inventors = []
        inventorList.each { inventor -> 
            def name = inventor.name[0].value
            inventors << [name: [origin: name]]
        }
        
        return inventors
    }
    
    private static getMainIPC(def marshallData, def errorPatentInfoCNIPR, def tempData) {
        return getIpcs(marshallData, errorPatentInfoCNIPR, tempData)[0]
    }
    
    private static getMainIPCNormal(def marshallData, def errorPatentInfoCNIPR, def tempData) {
        return getIpcsNormal(marshallData, errorPatentInfoCNIPR, tempData)[0]
    }
    
    private static getIpcs(def marshallData, def errorPatentInfoCNIPR, def tempData) {
        // 
        def ipcs = []
        def ipcList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."classifications-ipcr"."classification-ipcr"
        ipcList.each { ipc -> 
            
            /*
             *  ipc error => 目前只能找到一個算一個...
             *  且在doDate=2015-11-04的資料中, ipc的錯誤看起來都是同一樣, 所以推測是OPEN DATA的問題,
             *  所以此錯誤目前只是先記錄留存, 且忽略其錯誤.
             *  
             *  TODO: 因改在Raw Data XSD 檢核時就先處理...
             */
            if (ipc.text ==~ /\n\s+/ || ipc.text.trim() == "") {
                CnDataErrorProcess.saveInfoDataIpcError(errorPatentInfoCNIPR, tempData, "ipc pattern error = [\\n\\s+] or empty")
                // throw new Exception("ipcr error...")
            } else {
                // EX: H01M    4/86    (2006.01)  I => 項目資料中的格式
                // EX: H01M    4/86    (2006.01)    => 全文資料中的格式
                if (!(ipc.text ==~ /\w{4}\s+\d{1,4}\/\d{1,6}[\s]*(\(\d{4}\.\d{2}\))?[\s]*\w{0,2}/)) {
                    throw new CnException("ipcr regex pattern error, marshallData = ${marshallData}")
                }
                def dataArray = ipc.text.split(/(?sm)\s+/)
                ipc = dataArray[0] + " " + dataArray[1]
                ipcs << ipc
            }
            
        }
        
        return ipcs
    }
    
    private static getIpcsNormal(def marshallData, def errorPatentInfoCNIPR, def tempData) {
        def ipcsNormal = []
        def ipcList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."classifications-ipcr"."classification-ipcr";
        ipcList.each { ipc ->
            if (ipc.text ==~ /\n\s+/ || ipc.text.trim() == "") {
                CnDataErrorProcess.saveInfoDataIpcError(errorPatentInfoCNIPR, tempData, "ipc pattern error = [\\n\\s+] or empty")
                // throw new Exception("ipcr error...")
            } else {
                if (!(ipc.text ==~ /\w{4}\s+\d{1,4}\/\d{1,6}[\s]*(\(\d{4}\.\d{2}\))?[\s]*\w{0,2}/)) {
                    throw new CnException("ipcr noraml regex pattern error, marshallData = ${marshallData}")
                }
                def dataArray = ipc.text.split(/(?sm)\s+/)
                def ipcrGroup = dataArray[1].split("/");
                def ipcNormal = dataArray[0] + StringUtil.leftPad(ipcrGroup[0], 4, '0') + StringUtil.rightPad(ipcrGroup[1], 6, '0');
                ipcsNormal << ipcNormal;
            }
        }
        
        return ipcsNormal
    }
    
    private static getKindcode(def marshallData) {
        def documentId = getCnPublicationReference(marshallData)
        return documentId."kind"
    }
    
    private static getPatentNumber(def marshallData) {
        def documentId = getCnPublicationReference(marshallData)
        return documentId."country" + documentId."doc-number" + documentId."kind"
    }
    
    private static getStat(def marshallData) {
        
        def documentId = getCnPublicationReference(marshallData)
        def kindcode = documentId.kind
        
        def stat
        switch(kindcode) {
            case "A":
                stat = 1
                break;
            case "B":
                stat = 2
                break;
            case "U":
                stat = 2
                break;
            case "S":
                stat = 2
                break;
            default:
                throw new Exception("marshallData._id = ${marshallData._id}, kindcode error")
                break;
        }
        
        return stat
    }
    
    private static getTitle(def marshallData) {
        return ["origin" : marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."invention-title"]
    }
    
    /**
     * 可分別取出 country, pub-date, patentNumber, kindcode
     * 
     * @param marshallData
     * @return
     */
    private static getCnPublicationReference(def marshallData) {
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."document-id"
        return documentId
    }
    
    private static getPctNationFilingData(def marshallData) {
        
        def dataMap = [:]
        
        def pctNationalFilingDate = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."date-pct-article-22-39-fulfilled"?."date"
        if (!!pctNationalFilingDate) {
            dataMap << [
                "pctNationalFilingDate" : DateUtil.parseDate(pctNationalFilingDate)
            ];
        }
        
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-filing-data"?."document-id"
        if (!!documentId) {
            dataMap << ["country" : documentId?.country]
            dataMap << ["date" : DateUtil.parseDate(documentId?.date)]
            dataMap << ["docNumber" : documentId?."doc-number"]
        }
        
        return dataMap
    }
    
    private static getPctOrRegionalPublishingData(def marshallData) {
        
        def dataMap = [:]
        
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-publishing-data"?."document-id"
        if (!!documentId) {
            dataMap << ["country" : documentId?.country]
            dataMap << ["date" : DateUtil.parseDate(documentId?.date)]
            dataMap << ["docNumber" : documentId?.country + documentId?."doc-number"]
            dataMap << ["lang" : documentId?.lang]
        }
        
        return dataMap
    }
    
    private static getPctAppDate(def marshallData) {
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-filing-data"?."document-id"
        return DateUtil.parseDate(documentId?.date)
    }
    
    private static getPctAppNumber(def marshallData) {
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-filing-data"?."document-id"
        return documentId?."doc-number"
    }
    
    private static getPctOpenDate(def marshallData) {
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-publishing-data"?."document-id"
        return DateUtil.parseDate(documentId?.date)
    }
    
    private static getPctOpenNumber(def marshallData) {
        def documentId = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."pct-or-regional-publishing-data"?."document-id"
        if (!!documentId) {
            return documentId?.country + documentId?."doc-number"
        }
        return null
    }
    
    private static getGazetteNumber(def marshallData) {
        def gazetteReference = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."gazetteReference"
        return gazetteReference?."gazette-num"
    }
    
    private static getGazettePublicDate(def marshallData) {
        def gazetteReference = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."cn-publication-reference"."gazetteReference"
        return DateUtil.parseDate(gazetteReference?.date)
    }
    
    /**
     * NOTE: 2015-11-23 目前假定資料為 otherReferences 和 citedPatents 會一起出現...
     * 
     * @param marshallData
     * @return
     */
    private static getCitedPatents(def marshallData) {

        def dataList = []
        def citation = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."references-cited"?.citation
        
        if (!!citation) {
            
            citation.each { data -> 
                
                def patcit = data.patcit
                
                if (!!patcit) {
                    
                    recordCitedOrReference(marshallData, data.id, "cit0001")
                    
                    // patcit.text.trim() 寫在這是為了防止[text]中出現像是\n\t\t\t空值的資料出現
                    def replaceText = patcit.text.replaceAll("(?sm)[\\t\\n\\r\\s]*", "")
                    if (replaceText != "") {
                        
                        def citedPatentList = patcit.text?.split(";");
                        
                        /*
                         *  cited 範例: CN 103800833 A,2014.05.21,全文.;CN 1839998 A,2006.10.04,全文.
                         */
                        citedPatentList.each { it ->
                            
                            if (it.toString().length() > 2 && it.substring(0, 2) ==~ /^[A-Z]{2}/) {
                                
                                def dataMap = [:]
                                
                                dataMap << ["pto" : it.substring(0, 2)]
                                def doDateStr = null
                                it.find(/\d{4}\.\d{2}\.\d{2}/) { yyyyMMdd ->
                                    doDateStr = yyyyMMdd
                                }
                                def doDate = DateUtil.parseDate(doDateStr)
                                def patentNumber = it.replaceAll("(?ism)[\\s]*(\\d{4}\\.\\d{2}\\.\\d{2}[\\S\\s]*)", "").replaceAll("[,\\s]*", "")
                                
                                // def citedDescription = it.replaceAll("(?ism)[\\S\\s]*(\\d{4}\\.\\d{2}\\.\\d{2}[,;])", "")
                                // log.info "citedDescription = ${citedDescription}"
                                
                                dataMap << ["patentNumber" : patentNumber]
                                dataMap << ["doDate" : doDate]
                                
                                dataList << dataMap
                                
                            } else {
                                // throw new Exception("citedPatents data error, pto regex pattern error = ${it}")
                                log.error("citedPatents data error, pto regex pattern error = ${it}")
                            }
                            
                        }
                        
                    }  // end if (patcit.text.trim() != "")
                    
                }  // end if(!!patcit)
            }
            
        }  // end if (!!referencesCited)
        
        return dataList
    }
    
    /**
     * NOTE: 2015-11-23 目前假定資料為 otherReferences 和 citedPatents 會一起出現...
     * 
     * @param marshallData
     * @return
     */
    private static getOtherReferences(def marshallData) {
        
        def dataList = []
        def citation = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."references-cited"?.citation
        
        if (!!citation) {
            citation.each { data ->
                
                def nplcit = data.nplcit
                
                if (!!nplcit) {
                    
                    recordCitedOrReference(marshallData, data.id, "cit0002")
                    
                    // nplcit.text.trim() 寫在這是為了防止[text]中出現像是\n\t\t\t空值的資料出現
                    def replaceText = nplcit.text.replaceAll("(?sm)[\\t\\n\\r\\s]*", "")
                    if (replaceText != "") {
                        def otherReferenceList = nplcit.text?.split(";")
                        otherReferenceList.each { it ->
                            dataList << it.trim()
                        }
                    }  // end if (nplcit.text.trim() != "")
                    
                }  // end if (!!nplcit) {
            }
        }  // end if (!!referencesCited) {
        
        return dataList
    }
    
    private static getPriorityPatents(def marshallData) {
        
        def dataList = []
        def dataMap = [:]
        def priorityClaimList = marshallData.data.expansion."cn-patent-document"."cn-bibliographic-data"."priority-claims"?."priority-claim"
        
        if (!!priorityClaimList) {
            priorityClaimList.each { it -> 
                if (!!it.country) {
                    dataMap << ["pto" : it.country]
                }
                if (!!it."doc-number") {
                    dataMap << ["appNumber" : it."doc-number"]
                }
                if (!!it?.date) {
                    dataMap << ["appDate" : DateUtil.parseDate(it?.date)]
                }
                if (!!it.kind) {
                    dataMap << ["kindcode" : it.kind]
                }
                if (!!it.sequence) {
                    def sequence = it.sequence as int
                    dataMap << ["sequence" : sequence]
                }
            }
            dataList << dataMap
        }
        return dataList
    }
    
    /**
     * 單純為了citedPatent && otherReferences記錄資料而用, 等資料確認後, 即可刪除...
     * 
     * @param marshallData
     * @param id
     * @return
     */
    private static void recordCitedOrReference(def marshallData, def id, def expectedId) {
        def ln = System.getProperty('line.separator')
        File fileLog = new File("logs/citedAndReferencePatents_info.log")
        // cit0001
        // 固定為"cit0002" ???
        if (id != expectedId) {
            fileLog << "marshall._id = ${marshallData._id} have unexpected citedAndReferencePatent data..." << ln
        }
    }
    
    /**
     * tempData for save error collection
     * 
     * @param marshallData
     * @return
     */
    private static setTempDate(def marshallData) {
        def tempData = [:]
        tempData << [_id: marshallData._id]
        tempData << [patentNumber: marshallData.patentNumber]
        tempData << [doDate: marshallData.doDate]
        tempData << [patentType: marshallData.patentType]
        return tempData
    }
        
}
