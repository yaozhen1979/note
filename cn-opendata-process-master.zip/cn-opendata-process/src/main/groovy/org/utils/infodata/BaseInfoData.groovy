package org.utils.infodata

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.utils.MiscUtil
import org.common.Constants

class BaseInfoData {
    
    protected static Logger log = LoggerFactory.getLogger(InfoDataUtil.class);
    
    static generateBasicData(def marshallData, def existInfoData) {
        
        def infoData = [:]
        
        // NOTE: pto hard code...因歷史原因, 目前就只能維持使用CNIPR...
        infoData << ["pto" : Constants.PTO]
        infoData << ["type" : getType(marshallData)]
        infoData << MiscUtil.getRelRawdatas(marshallData, existInfoData)
        infoData << MiscUtil.getTagAndFile(existInfoData, "infoLevel")
        infoData << MiscUtil.getMongoSyncFlag(existInfoData)
        
        return infoData
    }
    
    private static getType(def marshallData) {
        def type = null
        switch(marshallData.patentType) {
            case "FM":
                type = "发明专利"
                break;
            case "SD":
                type = "发明专利"
                break;
            case "XX":
                type = "实用新型"
                break;
            case "WG":
                type = "外观专利"
                break;
            default:
                throw new Exception("getType error = ${marshallData}")
                break;
        }
    }
    
}
