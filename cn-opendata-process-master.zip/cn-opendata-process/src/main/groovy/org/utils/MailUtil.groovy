package org.utils

import org.apache.commons.mail.DefaultAuthenticator
import org.apache.commons.mail.Email
import org.apache.commons.mail.SimpleEmail
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class MailUtil {
    
    private static Logger log = LoggerFactory.getLogger(MailUtil.class);
    
    /**
     * 
     * @param emailTo
     * @param subject
     * @param msg
     */
    static void sendToPatentCloud(def emailTo, def subject, def msg) {
        
        Email email = new SimpleEmail();
        email.setHostName("10.60.94.110");
        email.setSmtpPort(25);
        // email.setAuthenticator(new DefaultAuthenticator("username", "password"));
        // email.setSSLOnConnect(true);
        email.setFrom("service@patentcloud.com");
        email.setSubject(subject);
        email.setMsg(msg);
        // email.addTo("tonykuo@patentcloud.com", "tony kuo");
        // email.addTo("mikelin@patentcloud.com", "tony kuo");
        email.addTo(emailTo);
        email.send();
        
        log.info "send mail complete..."
    } 
    
}
