package org.error

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class CnDataErrorProcess {
    
    Logger log = LoggerFactory.getLogger(CnDataErrorProcess.class);
    
    /**
     * ErrorPatentRawCN schema
     * 
     * path : unique key => FM/2015/20150923/[appNumber]
     * patentType: 專利類型 FM, SD, XX, WG
     * doDate: 處理資料之公佈日
     * errorMsg: <br/> 
     *   append data, 同一筆資料, 會一直append errorMsg的資料 <br/>
     *   [
     *     exception: 錯誤訊息,
     *     errorTime: 記錄錯誤訊息時間
     *   ]
     * updateFlag: 是否已修改Flag
     * mongoSyncFlagData: 資料處理時間 <br/>
     *   [
     *     init: 最初處理時間,
     *     last: 最新處理時間
     *   ]
     * 
     * 
     * @param errorPatentMarshallCN
     * @param path
     * @param patentType
     * @param doDate
     * @param e
     */
    static void saveRawDataError(def errorPatentRawCN, String path, String patentType, Date doDate, String exceptionMsg) {
        
        def existErrorData = errorPatentRawCN.findOne([path: path]);
        def now = new Date()
        
        if (!!existErrorData) {
            
            existErrorData.errorMsg << [
                'exception' : exceptionMsg,
                'errorTime' : now
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentRawCN.save(existErrorData)
            
        } else {
            
            def errorMap = [
                "path" : path,
                "patentType" : patentType,
                "doDate" : doDate,
                "errorMsg" : [] << [
                    'exception' : exceptionMsg,
                    'errorTime' : now
                ],
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentRawCN.save(errorMap)
            
        }
        
    }  //  end saveRawDataError
    
    /**
     * 
     * 
     * @param errorPatentInfoCNIPR
     * @param tempData
     * @param errMsg
     */
    static void saveInfoDataIpcError(def errorPatentInfoCNIPR, def tempData, def errMsg) {
        
        def existErrorData = errorPatentInfoCNIPR.findOne([doDate: tempData.doDate, patentNumber: tempData.patentNumber, errType: "ipc"]);
        def now = new Date()
        
        if (!!existErrorData) {
            
            existErrorData.errorMsg << [
                'exception' : errMsg,
                'errorTime' : now
            ]
            
            existErrorData.mongoSyncFlagData.last = now
            
            errorPatentInfoCNIPR.save(existErrorData)
            
        } else {
            def errorMap = [
                "doDate" : tempData.doDate,
                "patentNumber" : tempData.patentNumber,
                "patentType" : tempData.patentType,
                "errorMsg" : [] << [
                    'exception' : errMsg,
                    'errorTime' : now
                ],
                "errType" : "ipc",
                "updateFlag" : false,
                "mongoSyncFlagData" : [
                    init : now,
                    last : now
                ]
            ]
            
            errorPatentInfoCNIPR.save(errorMap)
        }
    }
    
}
