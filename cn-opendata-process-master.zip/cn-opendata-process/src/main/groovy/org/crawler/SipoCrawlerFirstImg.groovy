package org.crawler

import groovy.time.TimeCategory
import org.jsoup.Connection.Response
import org.utils.MailUtil

/**
 *  該隻為目前每週三時, 爬取sipo的申請號程式.
 */
class SipoCrawlerFirstImg {
    
    private static final String SIPO_QUREY_URL = "http://epub.sipo.gov.cn/patentoutline.action"
    
    private static final String SIPO_SERVER = "http://epub.sipo.gov.cn"
    
    private static final String LINE_SEPARATOR = System.getProperty('line.separator')
    
    /**
     * 
     * @param querydate 查詢日期(yyyy.MM.dd)
     * @param folderName 資料名稱
     * @param type 專利類型  1.發明公佈 2.發明授權 3. 實用新型 4. 外觀設定
     * @return
     */
    static void crawlerFirstImgUtil(querydate, folderName, type, def fileLog) {
        
        // date formate yyyy.MM.dd
        // def querydate = '2015.01.21';
        // def folderName = "20150121"
        // def type = 1;  // 1.發明公佈 2.發明授權 3. 實用新型 4. 外觀設定
        // System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]
        
        def typeCode;
        def ln = System.getProperty('line.separator')
        def date = Date.parse('yyyy.MM.dd', querydate);
        def nextPage = true;
        def pageNum = 745;  // 爬取頁數...FM/745
        def pageSize = 16;
        
        // TODO: set cookies
        Map<String, String> cookieMap = new HashMap<String, String>() {
            {
                put("WEB", "20111116");
                put("_gscu_2029180466", "455636501szgmu68");
                put("_gscbrs_2029180466", "1");
                put("_gscu_1718069323", "45563650jw771057");
                put("_gscbrs_1718069323", "1");
                put("JSESSIONID", "46BF04EA18EC5DB8ED3B422B0CACBEE7");
            }
        };
        
        
        switch(type) {
            case 1 : typeCode = 'FM'
              break
            case 2 : typeCode = 'SD'
              break
            case 3 : typeCode = 'XX'
              break
            case 4 : typeCode = 'WG'
              break
            Default :
              break
        }
        
        // TODO: mkdir save folder
        // hard code => 
        File saveFolder = new File("T:/cnlist/firstImage/${folderName}/${typeCode}")
        org.apache.commons.io.FileUtils.forceMkdir(saveFolder)
        
        println "to start..."
        
        while (nextPage) {
        
            def doc = null;
            def retry = 0;
        
            while (retry < 10)  {
                try {
                    // for 列表模式
                    // showType=0&strWord=公开（公告）日='2015.05.06'&numSortMethod=0&strLicenseCode=&selected=fmsq&numFMGB=&numFMSQ=4609&numSYXX=&numWGSQ=&pageSize=10&pageNow=1
                    doc = org.jsoup.Jsoup.connect(SIPO_QUREY_URL).timeout(300000)
                            .userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36")
                            .referrer("http://epub.sipo.gov.cn/gjcx.jsp")
                            .header("Content-Length", "200")
                            .header("Cache-Control", "max-age=0")
                            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                            .header("Origin", "http://epub.sipo.gov.cn")
                            .header("Accept-Encoding", "gzip, deflate")
                            .header("Accept-Language", "zh-TW,zh;q=0.8,en-US;q=0.6,en;q=0.4,zh-CN;q=0.2")
                            .cookies(cookieMap)
                            .data("showType", "2")
                            //.data("strWord", "公开（公告）日=BETWEEN['${date.format('yyyy.MM.dd')}','${enddate.format('yyyy.MM.dd')}']")
                            .data("strWord", "公开（公告）日='${querydate}'")
                            .data("pageSize", pageSize.toString())
                            .data("pageNow", pageNum.toString())
                            .data("numFMGB", type == 1 ? "0":"")   // 發明公佈
                            .data("numFMSQ", type == 2 ? "0":"")
                            .data("numSYXX", type == 3 ? "0":"")
                            .data("numWGSQ", type == 4 ? "0":"")
                            .post();
                    break;
                } catch (Exception e) {
                    retry++;
                    println 'will retry list:' + retry
                    println "Exception = ${e}"
                }
            }
        
            if (doc == null) {
                println 'could not get list!';
                break;
            }
            
            def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
            println "cntt = ${cntt}"
            
            def cnt = cntt.substring(5, cntt.length()-1) as int
            println "cnt = ${cnt}"
            
            def pages = ((cnt + pageSize - 1) / pageSize) as int
            println "${querydate} type::${type} cnt:${cnt} pages:${pageNum}/${pages}"
            
            // parse img url
            // println doc.html()
            
            doc.select("div.w790.right > dl.ft_cpdl2").eachWithIndex { node, index -> 
                
                def imgHref = node.select("a.ft").attr('href')
                
                def appNumber = node.select("strong > a").text()
                // println "appNumber = ${appNumber}"
                
                if (imgHref != 'images/cp_noimg.jpg') {
                    
                    def originImgUrl = SIPO_SERVER + "/" + imgHref
                    def originFileName = imgHref.split("/")[-1]
                    
                    def thumbImgUrl = SIPO_SERVER + "/" + node.select("img").attr("src")
                    def thumbImgFileName = thumbImgUrl.split("/")[-1]
                    
                    def saveImgFolderPath = saveFolder.getAbsolutePath() + "/${appNumber}"
                    org.apache.commons.io.FileUtils.forceMkdir(new File(saveImgFolderPath))
                    
                    // save origin first image
                    saveImg(originImgUrl, saveImgFolderPath + "/" + originFileName);
                    
                    // save thumb first image
                    saveImg(thumbImgUrl, saveImgFolderPath + "/" + thumbImgFileName);
                    
                    // 故意的...
                    Thread.sleep(500)
                    
                } else {
                    def noImgMsg = "${folderName}/${typeCode}/${appNumber} no first image"
                    println noImgMsg
                    fileLog << noImgMsg << LINE_SEPARATOR
                }
                
            }
            
            pageNum++
            
            if (pageNum > pages) {
                break
            }
        
        }  // end while
        
        // fos.close()
        
        println "${typeCode} crawler first image finished!"
    }
    
    /**
     * 
     * @param originImgUrl
     * @param filePath
     * @return
     */
    private static void saveImg(String originImgUrl, String filePath) {
        
        def retry = 0;
        
        while (retry < 10) {
            
            try {
                Response firstImageResponse = org.jsoup.Jsoup.connect(originImgUrl).timeout(5 * 60 * 1000).ignoreContentType(true).execute();
                FileOutputStream out1 = (new FileOutputStream(new File(filePath)));
                out1.write(firstImageResponse.bodyAsBytes());
                out1.close()
                break;
            } catch (Exception e) {
                retry++;
                println 'will retry list:' + retry
                println "Exception = ${e}"
                //
                MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Crawler First Image Error", e.toString())
            }
            
        }
        
    }
    
    /**
     * ref apache common fileutil api 2.5
     * 
     * @param file
     * @param append
     * @return
     * @throws IOException
     */
    static FileOutputStream openOutputStream(final File file, final boolean append) throws IOException {
        if (file.exists()) {
            if (file.isDirectory()) {
                throw new IOException("File '" + file + "' exists but is a directory");
            }
            if (file.canWrite() == false) {
                throw new IOException("File '" + file + "' cannot be written to");
            }
        } else {
            final File parent = file.getParentFile();
            if (parent != null) {
                if (!parent.mkdirs() && !parent.isDirectory()) {
                    throw new IOException("Directory '" + parent + "' could not be created");
                }
            }
        }
        return new FileOutputStream(file, append);
    }
    
}

