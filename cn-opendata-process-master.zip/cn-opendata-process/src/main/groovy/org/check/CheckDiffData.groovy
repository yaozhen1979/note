package org.check

import org.db.transfer.InfoDataMoveProcess
import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess

/**
 * 
 * check 二 Mongo DB 中, 差異的_id
 * 
 * @author tonykuo
 *
 */
class CheckDiffData {

    def excute(def queryMap) {
        
        def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "10.60.80.31", 27017, 'admin')
        def db = dbClient.getDB("PatentInfoCNIPR")
        def srcCol = db.PatentInfoCNIPR
        
        def remoteDbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017, 'admin')
        def remoteDB = remoteDbClient.getDB("PatentInfoCNIPR")
        def tarCol = remoteDB.PatentInfoCNIPR
        
        def queryCursor = tarCol.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it ->
            
            // tarCol.save(it)
            
            def data = srcCol.findOne([_id: it._id])
            
            if (!data) {
                println "id = ${it._id}, no exist..."
            }
            
            restTimeProcess.process()
        }
        
        dbClient.close()
        remoteDbClient.close()
        
    }
    
    static main(args) {
        
        def queryMap = [doDate: DateUtil.parseDate("2016-05-04"), kindcode: "A"]
        // def queryMap = [_id: new ObjectId("5729c70b5eeef107469aade7")]
        
        new CheckDiffData().excute(queryMap)
        
        println "finished..."
        
    }

}
