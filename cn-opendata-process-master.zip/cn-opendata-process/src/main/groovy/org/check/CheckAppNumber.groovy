package org.check

/**
 * 取得某期doDate的appNumber list
 * 
 * @author tonykuo
 *
 */
class CheckAppNumber {

    static main(args) {
    
        // TODO
        
    }

}
