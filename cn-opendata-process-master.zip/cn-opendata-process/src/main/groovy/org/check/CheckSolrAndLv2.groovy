/**
 * check solr 和 PatentInfoCNIPR Lv2 中的資料差異.
 * 
 */
import groovy.json.JsonSlurper

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.utils.DateUtil


class CheckSolrAndLv2 {
    
    /**
     * http://10.60.90.113:5566/solr/docdb/select?q=ptopid%3A+DOCDB.55786df1b4411f24f1693bd0&fl=ptopid%2Cid&wt=json
     *
     * @param start
     * @param rows
     * @return
     */
    static def querySolr() {
        
        // http://10.60.90.176/solr/cn/select?q=*%3A*&fl=doDate&df=id&wt=json&indent=true&facet=true&facet.field=doDate&facet.limit=-1
        def xml = ("http://10.60.90.176/solr/cn/select?q=*%3A*&fl=doDate&df=id&wt=json&indent=true&facet=true&facet.field=doDate&facet.limit=-1&wt=json").toURL().text
        def jsonSlurper = new JsonSlurper();
        def object = jsonSlurper.parseText(xml)
        return object;
    }
    
    static main (def args) {
        
        println "to start..."
        
        def ln = System.getProperty('line.separator')
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
        
        def db = client.getDB("PatentInfoCNIPR")
        
        File fileLog = new File("logs/CheckSolrAndLv2.log")
        
        
        def lv2Count = 0
        def doDate = null
        
        querySolr()."facet_counts"."facet_fields"."doDate".eachWithIndex { it, index ->
            
            if (index % 2 == 0) {
                doDate = it.toString().substring(0, 10).trim()
                lv2Count = db.PatentInfoCNIPR.count([doDate: DateUtil.parseDate(doDate)])
            } else if (index % 2 == 1) {
            
                def solrCount = it as int
                if (lv2Count - solrCount != 0) {
                    fileLog << "doDate = ${doDate}, diff count = ${lv2Count - solrCount}" << ln
                    println "doDate = ${doDate}, diff count = ${lv2Count - solrCount}"
                }
            }
            
        }
        
        println 'finished!'
        
    }
    
}

