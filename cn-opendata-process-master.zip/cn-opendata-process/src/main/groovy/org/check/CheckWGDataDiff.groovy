package org.check

/**
 * 比對檢查CN appNumber和WG Data差異, 並移同相關檔案
 * 
 * @author tonykuo
 *
 */
class CheckWGDataDiff {

    static main(args) {
        
        def fileList1 = []
        
        def fileList2 = []
        
        // tarSrc T:\cnlist\sipo\WG\diff\20120125 || D:\temp\wg_20120125_data
        
        // T:\cnlist\appNumber\20120125\sipo-WG-2012.01.25.txt
        
        new File("T:/cnlist/appNumber/20090114/sipo-WG-2009.01.14.txt").eachLine { it ->
            
            // println it.toString()
            def appNumber = it.toString().substring(12).split(/\./)[0].trim()
            // println "appNumber = ${appNumber}"
            
            fileList1 << appNumber
            
        }
        
        // T:\cnlist\sipo\WG\patentcloud3\2012\20120125_ERROR
        new File("T:/cnlist/sipo/WG/patentcloud3/2009/20090114_ERROR").eachFile { it2 ->
            
            def appNumber = it2.name.split(/\./)[0].trim().substring(0, 12)
            // println "appNumber = ${appNumber}"
            
            if (fileList1.contains(appNumber)) {
                // fileList2 << appNumber
                new File("T:/cnlist/sipo/WG/diff/20090114/${it2.name}") << it2.text
            } else {
                new File("T:/cnlist/sipo/WG/diff/20091104/${it2.name}") << it2.text
            }
            
        }
        
        // println "fileList1 size = ${fileList1.size()}"
        // println "fileList2 size = ${fileList2.size()}"
        
        println "finished..."
    }

}
