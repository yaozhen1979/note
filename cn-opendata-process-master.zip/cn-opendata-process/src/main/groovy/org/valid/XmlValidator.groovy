package org.valid;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.utils.XmlUtil
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import org.common.Constants

public class XmlValidator {
    
    /**
     * 
     * @param validXmlPath
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public boolean validate(String validXmlPath) throws SAXException, IOException,
            ParserConfigurationException {
        return validate(new File(validXmlPath));
    }
    
    /**
     * 
     * @param validXml
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public boolean validate(File file) throws SAXException, IOException,
            ParserConfigurationException {
        
        SchemaFactory factory = SchemaFactory
                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        
        File schemaLocation = new File(Constants.XSD_FILE_PATH);
        Schema schema = factory.newSchema(schemaLocation);
        
        def fileText = XmlUtil.reomoveDTDDeclaration(file.getText(Constants.LANG_ENCODING))
        // println fileText
        
        InputStream is = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        Source source = new StreamSource(is);
        
        Validator validator = schema.newValidator();
        validator.validate(source);
        
        return true
    }
    
    static main(args) {
        
        // T:/cnlist/opendata/FM/2015/20151202/201380068962.4
        // println new XmlValidator().validate("opendata-sample/FM/201180019236.4/201180019236NEW.XML")
        println new XmlValidator().validate("T:/cnlist/opendata/FM/2015/20151202/201380068962.4/201380068962NEW.XML")
        
    }

}
