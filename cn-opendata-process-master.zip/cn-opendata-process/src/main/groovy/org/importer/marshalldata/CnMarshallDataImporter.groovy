package org.importer.marshalldata

import java.util.Date;

import org.bson.types.ObjectId
import org.service.BaseService;
import org.service.WGService
import org.utils.RestTimeProcess
import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.MarshallDataUtil
import org.utils.XmlUtil
import org.utils.MailUtil

class CnMarshallDataImporter extends BaseService {
    
    /**
     * 
     * @param args
     * @param period
     * @return
     */
    def processMarshallData(def args, def period, def queryMap = null) {
        
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        def rawDataDB = dbClient.getDB("PatentRawCN")
        
        // NOTE: 暫時使用... 等正式使用11月份的資料時再統一使用dbClient
        // def remoteClient = MongoUtil.connect3X(MONGODB_USER_NAME, MONGODB_PWD, "10.60.90.101", MONGODB_PORT, 'admin')
        def marshallDataDB = dbClient.getDB("PatentMarshallCN")
        
        def patentRawCNIPR = rawDataDB.getCollection("PatentRawOpenData")
        def patentMarshallCN = marshallDataDB.getCollection("PatentMarshallCN")
        def errorPatentMarshallCN = marshallDataDB.getCollection("ErrorPatentMarshallCN");
        //
        // 可自定義查詢條件
        if (!queryMap) {
            String patentType = args.patentType
            Date doDate = DateUtil.parseDate(period);
            // log.info "args = ${args}"
            // log.info "doDate = ${doDate}"
            queryMap = [doDate: doDate, patentType: patentType]
        }
        def rawDataCursor = patentRawCNIPR.find(queryMap).limit(0)
        rawDataCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        if (rawDataCursor.size() == 0) {
            throw new Exception("no data find...")
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(rawDataCursor.size(), this.class.name)
        
        def _id = null;  // for exception message
        
        try {
            rawDataCursor.each { rawData ->
                
                _id = rawData._id
                
                def expansionData = null
                def existDate = null
                if (rawData.patentType == "WG") {
                    expansionData = new WGService().processMarshallData(rawData.data.text)
                    existDate = patentMarshallCN.findOne([doDate: rawData.doDate, patentNumber: expansionData.patentNumber])
                } else {
                    try {
                        expansionData = XmlUtil.generateCnOpenDataJsonObject(rawData)
                    } catch(e) {
                        throw new Exception("rawData._id = ${rawData._id}, exception = ${e}")
                    }
                    
                    existDate = patentMarshallCN.findOne([doDate: rawData.doDate, patentNumber: XmlUtil.getPatentNumber(expansionData)])
                }
                
                def marshallData = MarshallDataUtil.generateMarshallData(expansionData, rawData, existDate)
                
                // patentMarshallCN.save(marshallData)
                if (!!marshallData._id) {
                    patentMarshallCN.update([_id: marshallData._id], marshallData, true, false, com.mongodb.WriteConcern.ACKNOWLEDGED)
                } else {
                    patentMarshallCN.insert(marshallData, com.mongodb.WriteConcern.ACKNOWLEDGED)
                }
                
                restTimeProcess.process()
            }
        } catch (e) {
            log.error "Exception = ${e}"
            // MailUtil.sendToPatentCloud(USER_MAIL, "CN Open Data Exception Error", "${_id} = ${e.toString()}")
        } finally {
            dbClient.close()
            // remoteClient.close()
        }
        
    }
    
    static main(args) {
        
        //
        def period = "20160511"
        
        // "FM" => ERROR org.service.BaseService - Exception = java.lang.NullPointerException: Cannot get property 'cn-bibliographic-data' on null object => 18720 ???
        // "XX" ??? => ERROR org.service.BaseService - Exception = java.lang.NullPointerException: Cannot get property 'cn-bibliographic-data' on null object => 18720 ???
        ["FM", "SD", "XX", "WG"].each { patentType ->
            
            def argMap = [:]
            
            // argDoPath => 當期資料路徑
            argMap << ['patentType' : patentType]
            // def queryMap = [_id: new ObjectId("573029b05eeedd13a687c348")]
            
            new CnMarshallDataImporter().processMarshallData(argMap, period);
            
        }
        
        println "finished..."
        
    }
    
}
