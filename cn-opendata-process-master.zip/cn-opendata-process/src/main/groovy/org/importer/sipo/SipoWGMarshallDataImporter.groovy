package org.importer.sipo

import org.apache.commons.lang3.StringUtils

import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.XmlUtil
import org.utils.RestTimeProcess
import org.utils.CaptchaUtil
import org.utils.PropertiesUtil

class SipoWGMarshallDataImporter {
    
    // SPACE = 空一格
    private static final String SPACE = " ";
    
    public void process(String doDateStr = "", String patentType = "", def queryMap = null) {
        
        if (!queryMap) {
            String doYear = "";
            Date doDate = null;
            
            if (!patentType) {
                throw new Exception("patentType is empty...");
            }
            
            if (!!doDateStr) {
                //
                doDate = DateUtil.parseDate(doDateStr)
                if (!!doDate) {
                    doYear = doDateStr.substring(0, 4);
                } else {
                    throw new Exception("doDate is null...")
                }
                
            } else {
                throw new Exception("doDate is empty...")
            }
            //
            queryMap = [doDate: doDate, patentType: patentType]
        }
        
        // def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "127.0.0.1", 27017, 'admin')
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        
        def patentRawSIPO = dbClient.getDB("PatentRawSIPO").getCollection("PatentRawSIPO")
        //
        def patentMarshallSIPO = dbClient.getDB("PatentMarshallSIPO").getCollection("PatentMarshallSIPO")
        def errorPatentMarshallSIPO = dbClient.getDB("PatentMarshallSIPO").getCollection("ErrorPatentMarshallSIPO")
        //
        def nationCode = dbClient.getDB("PatentRawCN").getCollection("NationCode")
        def agency = dbClient.getDB("PatentRawCN").getCollection("Agency")
        
        def queryCursor = patentRawSIPO.find(queryMap).sort([doDate: 1]).limit(0)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        if (queryCursor.size() == 0) {
            throw new Exception("no data find...")
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.size(), this.class.name)
        
//        #字段名称            #字段含义
//        APNNO       申请号
//        PUBNR       公开号
//        APPNR       公告号
//        apd         申请日
//        pud         公开日
//        grd         授权日
//        grpd        授权日
//        appd        授权日
//        nc          国别
//        agency      代理机构代码
//        address     申请人地址
//        agent       代理人
//        title       标题
//        zip         邮编
//        abstr       摘要
//        claim       权利要求
//        ipc         分类号
//        appl        申请人
//        inventor    发明人
        queryCursor.each { rawData ->
            
            // TODO
            String exceptionMsg = "rawData._id = ${rawData._id}, doDate = ${rawData.doDate}"
            // println "exceptionMsg = ${exceptionMsg}"
            
            def marshallData = [:];
            // println "xml = ${rawData.data.text}"
            
            def xmlObject = null
            
            try {
                xmlObject = XmlUtil.xml2Object(rawData.data.text)
            } catch (e) {
                //
                String errorMsg = "${exceptionMsg}, XmlUtil exception = ${e}"
                println errorMsg
                rawData << [exceptionMsg : errorMsg]
                rawData << [errorTime : new Date()]
                rawData << [updateFlag : false]
                errorPatentMarshallSIPO.save(rawData)
                // throw new Exception(errorMsg)
                return false;  // keep looping
            }
            
            // 申請號12碼(未滿12碼，前補0)+一碼驗證碼+一碼kindcode => 200910312514XA
            // String _id = StringUtils.leftPad(appNumber, 12, "0") + captcha + kindcode.toUpperCase();
            String appNumber = xmlObject.'**'.find{ node-> node.name() == 'APNNO' }.text().trim()
            // println "appNumber = ${appNumber}"
            if (appNumber.length() == 8 || appNumber.length() == 12) {
                String appNumberFmt = StringUtils.leftPad(appNumber, 12, "0");
                // println CaptchaUtil.genAppNumberWithCaptcha(appNumber, true)
                String captcha = CaptchaUtil.genCaptcha(appNumber).toString();
                // println captcha
                marshallData << [_id: appNumberFmt + captcha + "S"]
            } else {
                throw new Exception("${exceptionMsg}, appNumber length error.")
            }
            
            def existData = patentMarshallSIPO.findOne([_id: marshallData._id])
            
            marshallData << [appNumber: appNumber]
            marshallData << [doDate: rawData.doDate]
            marshallData << [pto: "CN"]
            marshallData << [patentType: "WG"]
            
            def expansion = [:]
            
            // 申請號(含驗證碼)
            expansion << [appNumber: "CN" + CaptchaUtil.genAppNumberWithCaptcha(appNumber, true)]
            
            // 申請日
            String applicationDateStr = xmlObject.'**'.find{ node-> node.name() == 'APD' }.text().trim()
            if (!!applicationDateStr) {
                expansion << [applicationDate: DateUtil.toISODateFormat(DateUtil.parseChineseDate(applicationDateStr), "yyyy.MM.dd")]
            } else {
                throw new Exception("${exceptionMsg}, applicationDate is empty.")
            }
            
            // 公布日
            String publicationDateStr = xmlObject.'**'.find{ node-> node.name() == 'GRD' }.text().trim()
            if (!!publicationDateStr) {
                expansion << [publicationDate: DateUtil.toISODateFormat(DateUtil.parseChineseDate(publicationDateStr), "yyyy.MM.dd")]
            } else {
                throw new Exception("${exceptionMsg}, publicationDate is empty.")
            }
            
            // 標題
            String title = xmlObject.'**'.find{ node-> node.name() == 'TITLE' }.text().trim()
            expansion << [title: title]
            
            // LOC分類號
            def locs = xmlObject.'**'.findAll{ node-> node.name() == 'IPC' }*.text()*.trim()
            if (!!locs) {
                expansion << [mainLOC: locs[0]]
                expansion << [locs: locs]
            } else {
                throw new Exception("${exceptionMsg}, loc is empty.")
            }
            
            // 申請人地址
            String address = xmlObject.'**'.find{ node-> node.name() == 'ADDRESS' }.text().trim()
            if (!!address) {
                // 郵遞區號
                String zip = xmlObject.'**'.find{ node-> node.name() == 'ZIP' }?.text().trim()
                if (!!zip) {
                    address = zip + SPACE + address
                }
                
                expansion << [address: address]
            } else {
                throw new Exception("${exceptionMsg}, address is empty.")
            }
            
            // 國家代碼
            String countryCode = xmlObject.'**'.find{ node-> node.name() == 'NC' }.text().trim()
            
//            // for test: start
//            if (countryCode == "94") {
//                println "${exceptionMsg}, countryCode = 94"
//            } else if (countryCode == "92") {
//                println "${exceptionMsg}, countryCode = 92"
//            } else if (countryCode == "84") {
//                println "${exceptionMsg}, countryCode = 84"
//            } else if (countryCode == "90") {
//                println "${exceptionMsg}, countryCode = 90"
//            } else if (countryCode == "97") {
//                println "${exceptionMsg}, countryCode = 97"
//            } else if (countryCode == "86") {
//                println "${exceptionMsg}, countryCode = 86"
//            } else if (countryCode == "82") {
//                println "${exceptionMsg}, countryCode = 82"
//            } else if (countryCode == "88") {
//                println "${exceptionMsg}, countryCode = 88"
//            } else if (countryCode.trim() == "") {
//                println "${exceptionMsg}, countryCode is empty, address = ${address}"
//            }
//            // for test: end
            
            def nationCodeData = nationCode.findOne([_id: countryCode]);
            // println "nationCodeData = ${nationCodeData}"
            
            if (!nationCodeData) {
                // 判斷[address] 彰化
                if (isTwAddress(address)) {
                    nationCodeData = [_id: "71", nationName: "臺灣"]
                }
            }
            
            if (!!nationCodeData) {
                expansion << [country: [
                    countryName: nationCodeData.nationName,
                    countryCode: nationCodeData._id
                ]]
            } else {
                //
                String errorMsg = "${exceptionMsg}, countryCode = ${countryCode}, not found."
                println "errorMsg = ${errorMsg}"
                rawData << [exceptionMsg : errorMsg]
                rawData << [errorTime : new Date()]
                rawData << [updateFlag : false]
                errorPatentMarshallSIPO.save(rawData)
                // throw new Exception(errorMsg)
                return false;  // keep looping
            }
            
            // 發明者
            def inventors = xmlObject.'**'.findAll{ node -> node.name() == 'INVENTOR' }*.text()*.trim()
            expansion << [inventors: inventors]
            
            // 代理機構 => 有可能是空值
            String agencyCode = xmlObject.'**'.find{ node-> node.name() == 'AGENCY' }.text().trim()
            def agencyData = agency.findOne([_id: agencyCode]);
            if (!!agencyData) {
                expansion << [agency: "${agencyData.agencyName} ${agencyData._id}"]
            }
            
            // 代理人 => 有可能是空值
            String agents = xmlObject.'**'.find{ node-> node.name() == 'AGENT' }.text().trim()
            if (!!agents) {
                def agentDataList = []
                agents.split(/\s+/).each { agent -> 
                    agentDataList << agent
                }
                expansion << [agents: agentDataList]
            }
            
            // TODO: 優先權
            def priorityList = xmlObject.'**'.findAll{ node-> node.name() == 'PRI' }
            // println "priorityList = ${priorityList}"
            if (!!priorityList) {
                def priorityPatents = []
                priorityList.each { it -> 
                    // println "it = ${it.value.size()}"
                    if (it.value.size() > 0) {
                        String country = it."CO".text().trim()
                        String priorityNumber = it."NR".text().trim()
                        String priorityDate = DateUtil.toISODateFormat(DateUtil.parseChineseDate(it."DATE".text().trim()), "yyyy.MM.dd")
                        String priorityData = priorityDate + SPACE + country + SPACE + priorityNumber
                        priorityPatents << priorityData
                    }
                }
                if (priorityPatents.size() > 0) {
                    expansion << [priorityPatents: priorityPatents]
                }
            }
            
            // 申請(專利權)人
            def assigneeList = xmlObject.'**'.findAll{ node-> node.name() == 'APPL' }*.text()*.trim()
            if (!!assigneeList) {
                def assignees = []
                assigneeList.each { assignee ->
                    assignees << assignee
                }
                expansion << [assignees: assignees]
            } else {
                throw new Exception("${exceptionMsg}, assignee is empty.")
            }
            
            // TODO: 摘要, brief may be empty or no [ABSTR] element
            String brief = ""
            def abstr = xmlObject.'**'.find{node -> node.name() == 'ABSTR'}
            
            if (!!abstr) {
                brief = abstr.text().trim()
            }
            
            if (!!brief) {
                expansion << [brief: brief]
            } else if (rawData._id == "WG/2015/20150610/200930127128.xml" ||
              rawData._id == "WG/2014/20140813/200930037071.xml" || 
              rawData._id == "WG/2013/20131127/200830000928.xml" || 
              rawData._id == "WG/2013/20130220/200830300953.xml" || 
              rawData._id == "WG/2013/20130213/200830006591.xml" || 
              rawData._id == "WG/2012/20121128/200830351496.xml" ||
              rawData._id == "WG/2012/20120502/200830139105.xml" || 
              rawData._id == "WG/2012/20120502/200830300814.xml" || 
              rawData._id == "WG/2012/20120118/200830211494.xml" ||
              rawData._id == "WG/2012/20120125/200930209733.xml" || 
              rawData._id == "WG/2012/20120125/200930046859.xml" ||
              rawData._id == "WG/2012/20120208/201130332528.xml" ||
              rawData._id == "WG/2012/20120229/200730002360.xml" ||
              rawData._id == "WG/2011/20110105/200930244003.xml" ||
              rawData._id == "WG/2011/20110105/200930227792.xml" ||
              rawData._id == "WG/2011/20110105/200930209815.xml" ||
              rawData._id == "WG/2011/20110105/200930207276.xml" ||
              rawData._id == "WG/2011/20110105/200930207096.xml" ||
              rawData._id == "WG/2011/20110105/200930207086.xml" ||
              rawData._id == "WG/2011/20110105/200930207076.xml" ||
              rawData._id == "WG/2011/20110105/200930203443.xml") {
                expansion << [brief: null]
            }else {
                // throw new Exception("${exceptionMsg}, brief is empty.")
                println "${exceptionMsg}, brief is empty."
                expansion << [brief: null]
            }
            
            // 分案號
            String divisionalAppCountry = xmlObject.'**'.find{node-> node.name() == 'Contry'}?.text()?.trim()
            String divisionalAppDivAppNo = xmlObject.'**'.find{node-> node.name() == 'DivAppNo'}?.text()?.trim()
            String divisionalAppAppD = xmlObject.'**'.find{node-> node.name() == 'AppD'}?.text()?.trim()
            if (!!divisionalAppDivAppNo) {
                String originAppNumber = divisionalAppDivAppNo + SPACE + divisionalAppAppD
                expansion << [divisionalApplication: [
                    originAppNumber: originAppNumber,
                    divisionalAppCountry: divisionalAppCountry,
                    divisionalAppDivAppNo: divisionalAppDivAppNo,
                    divisionalAppAppD: divisionalAppAppD
                ]]
            }
            
            marshallData << [data: expansion]
            
            marshallData << getRelRawdatas(rawData, existData)
            marshallData << getTagAndFile(existData, "SipoWGRawDataImporter.groovy")
            marshallData << getMongoSyncFlag(existData)
            
            // println "marshallData = ${marshallData}"
            
            if (!!existData) {
                patentMarshallSIPO.update([_id: marshallData._id], marshallData, true, false, com.mongodb.WriteConcern.ACKNOWLEDGED)
            } else {
                patentMarshallSIPO.insert(marshallData, com.mongodb.WriteConcern.ACKNOWLEDGED)
            }
            
            restTimeProcess.process();
        }
        
    }   // end process
    
    /**
     * 判斷是否為重複的relRawdatas._id
     *
     * @param newData
     * @param existData
     * @return
     */
    static getRelRawdatas(def newData, def existData) {
        
        def dataMap = [:]
        
        if (!!existData?.relRawdatas) {
            // 排除重複insert or update的資料
            if (existData.relRawdatas[-1]._id != newData._id) {
                dataMap << [
                    "relRawdatas" : existData.relRawdatas << [
                        _id: newData._id
                    ]
                ]
            } else {
                dataMap << ["relRawdatas" : existData.relRawdatas]
            }
            
        } else {
            def relRawdatas = [] << [_id: newData._id]
            dataMap << ["relRawdatas" : relRawdatas]
        }
        
        return dataMap
    }
    
    /**
     * 判斷是否為重的tagAndFile
     *
     * @param existData
     * @param codeLevel rawLevel, marshallLevel, infoLevel
     * @return
     */
    static getTagAndFile(def existData, String codeName) {
        
        def dataMap = [:]
        
        def tag = PropertiesUtil.load("config.properties").getProperty("version_tag")
        
        if (!!existData?.tagAndFile) {
            
            if (existData.tagAndFile[-1].file != codeName ||
                existData.tagAndFile[-1].tag != tag) {
                
                dataMap << ["tagAndFile" : existData.tagAndFile <<
                    [
                        "file" : codeName,
                        "tag" : tag
                    ]
                ]
                
            } else {
                dataMap << ["tagAndFile" : existData.tagAndFile]
            }
            
        } else {
            //
            dataMap << ["tagAndFile" : [] <<
                [
                    "file" : codeName,
                    "tag" : tag
                ]
            ]
        }  // end existData.tagAndFile
        
        return dataMap
    }
    
    static getMongoSyncFlag(def existData) {
        
        def dataMap = [:]
        if (!!existData) {
            def mongoSyncFlagData = existData.mongoSyncFlag
            mongoSyncFlagData.last = new Date()
            dataMap << ["mongoSyncFlag": mongoSyncFlagData]
        } else {
            def now = new Date()
            def mongoSyncFlagData = ["init" : now, "last" : now]
            dataMap << ["mongoSyncFlag" : mongoSyncFlagData]
        }
        
        return dataMap
    }
    
    /**
     * 判斷地址是否包含台灣省份
     * 
     * @param address
     * @return
     */
    static isTwAddress(String address) {
        
        boolean isTwFlag = false
        
        def twAddress = ['彰化', '台北', '高雄', '台中', '台南', '新竹', '嘉義']
        
        twAddress.each { it -> 
            // println "TwAddress = ${it}"
            if (address.contains(it.toString())) {
                println "contain ${it}"
                isTwFlag = true
            }
        }
                
        return isTwFlag;
    }
    
    /**
     * 
     * @param args
     */
    static main(args) {
        
        // 
        String doDateStr = "20160330"
        String patentType = "WG"
        
        // WG/2016/20160330/201530562288.xml => 有優先權
        //                                   => 分案號
        // def queryMap = [_id : "WG/2016/20160330/201530562288.xml"]
        
        // WG/2016/20160330/201530480040.xml => APPL 有二個
        // def queryMap = [_id : "WG/2016/20160330/201530480040.xml"]
        
        // WG/2016/20160330/201530453946.xml => 有二個優先權
        // def queryMap = [_id : "WG/2016/20160330/201530453946.xml"]
        
        // WG/2016/20160330/201530035412.xml => 代理人為空值, 且地址有遞區號
        // def queryMap = [_id: "WG/2016/20160330/201530035412.xml"]
        
        // WG/2016/20160330/201530029681.xml => loc 有二個資料
        
        // rawData._id = WG/2015/20151230/201530348169.xml, countryCode = , not found.
        
        // db.PatentRawSIPO.find({doDate: {$gte: ISODate("2015-01-01T00:00:000Z"), $lt: ISODate("2016-01-01T00:00:000Z")}, patentType: "WG"}).count()
        
        // 2015-01-01 ~ 2016-01-01 = 474079 = marshall data + error data
        // rawData._id = WG/2013/20130410/201230604648.xml, doDate = Wed Apr 10 08:00:00 CST 2013, XmlUtil exception = org.xml.sax.SAXParseException; lineNumber: 11; columnNumber: 1; XML 文件結構的開頭與結尾必須在相同實體內。
        
        // def queryMap = [doDate: [$gte: DateUtil.parseDate("2010-02-24"), $lt: DateUtil.parseDate("2011-01-01")], patentType: "WG"]
        // def queryMap = [doDate: [$gte: DateUtil.parseDate("2013-10-02"), $lt: DateUtil.parseDate("2013-10-10")], patentType: "WG"]
        
        def queryMap = [doDate: DateUtil.parseDate("2012-10-03"), patentType: "WG"]
        
        new SipoWGMarshallDataImporter().process(doDateStr, patentType, queryMap);
        
        println "finished"
        
    }

}
