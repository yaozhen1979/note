package org.importer.sipo

import org.utils.DateUtil;
import org.utils.FileUtil;
import org.utils.RestTimeProcess

class SipoWGRawDataTransfer {

    private static final String ENCODING_UTF8 = "UTF-8";
    private static final String LINE_SEPARATOR = System.getProperty('line.separator');
    private static final String SAVE_FOLDER_PATH = "T:/cnlist/sipo/WG/patentcloud3";
    
    static main(args) {
        
//        // PROCESS NOTE 1: 處理單筆資料
//        File file = new File("T:/cnlist/sipo/WG/WG/1985/30000/198530000003.xml");
//        // File file = new File("opendata-sample/WG/sipo/198530000003.xml");
//        try {
//            writeFileByUTF8(file);
//        } catch(Exception e) {
//            throw new Exception("${file.path} - Exception = " + e);
//        }
        
        // PROCESS NOTE 2: 處理年度資料
        // 1985~2011 finished
        // 2012/30245 ing
        // 2013/30147 ing
        
        // PROCESS NOTE 3: 處理年度資料 again
        // 2012/490~599 ing
        // 2012/600~667 finished
        // 1998 check
        // finished => 1985, 1986, 1987, 1988, 1989, 1990~1999, 2000, 2001~2011, 2013, 2014, 2015
        File dir = new File("T:/cnlist/sipo/WG/WG/2012");
        
        dir.listFiles().each { it -> 
            
//            // 如有例外, 則以此為判斷:start
            int folderName = it.name as int;
            if (folderName < 30600) {
                return false;
            }
//            // 如有例外, 則以此為判斷:end
            
            int fileCount = 0;
            
            if (it.isDirectory()) {
                it.listFiles().each { it2 -> 
                    fileCount++;
                }
            }
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(fileCount, "${it.path}")
            
            if (it.isDirectory()) {
                it.listFiles().each { it2 ->
                    
//                    // 處理單筆資料
//                    if (it2.name != "201230245652.xml") {
//                        return false;
//                    }
//                    println "file name = ${it2.name}"
                    
                    try {
                        writeFileByUTF8(it2);
                        restTimeProcess.process();
                    } catch(Exception e) {
                        throw new Exception("${it2.path} - Exception = " + e);
                    }
                }
            }   // end if (it.isDirectory())
            
        }   // end dir.listFiles()
        
        println "finished..."
        
    }

    private static writeFileByUTF8(File file) throws Exception {
        
        String encoding = ""
        def breakLine = 1

        file.eachLine { it, line ->
            // println "${line}, ${it}"
            if (line == breakLine) {
                def encodingGroup = it.toString() =~ /(?ism)encoding="(\S)+"/
                encoding = encodingGroup[0][0].replaceAll(/(?ism)encoding=/, "").replaceAll(/(?ism)\"/, "")
                // println "encoding = ${encoding}"
            }
        }

        String xmlStr = file.getText(encoding)
        // println xmlStr

        // parse appNumber => APNNO
        // parse doDate => APPD
        def doDateGroup = xmlStr =~ /(?ism)<APPD>\s*(\S)+\s*<\/APPD>/
        // println "doDateGroup[0][0] = ${doDateGroup[0][0]}"
        // String doDate = doDateGroup[0][0].replaceAll(/(?ism)<[\/]?APPD>/, "").replaceAll(/\s*[日]?/, "").replaceAll("[年月]", "-")
        String doDate = doDateGroup[0][0].replaceAll(/(?ism)<[\/]?APPD>/, "").replaceAll(/[^\d]/, "")
        // println "doDate = ${doDate}"
        String doDateFmt = DateUtil.toISODateFormat(DateUtil.parseChineseDate(doDate), "yyyyMMdd")
        // println "doDateFmt = ${doDateFmt}"
        // println "doDate = ${DateUtil.parseChineseDate(doDate)}"

        String doYear = doDateFmt.substring(0, 4)

        def appNumberGroup = xmlStr =~ /(?ism)<APNNO>\s*(\S)+\s*<\/APNNO>/
        String appNumber = appNumberGroup[0][0].replaceAll(/(?ism)<[\/]?APNNO>/, "").replaceAll(/\s*/, "")
        // println "appNumber = ${appNumber}"

        // write encoding = UTF-8 file => T:\cnlist\sipo\WG\patentcloud
        File writeDir = new File("${SAVE_FOLDER_PATH}/${doYear}/${doDateFmt}");
        File writeFile = new File("${SAVE_FOLDER_PATH}/${doYear}/${doDateFmt}/${appNumber}.xml");

        if (writeFile.exists() == false) {
            FileUtil.mkdir(writeDir)
            writeFile.createNewFile()
        } else {
            writeFile.delete()
            writeFile.createNewFile()
        }

        file.eachLine(encoding) { it, line ->
            if (line == breakLine) {
                writeFile << it.toString().replaceAll(encoding, ENCODING_UTF8) << LINE_SEPARATOR
            } else {
                writeFile << it.toString() << LINE_SEPARATOR
            }
        }
    }

}
