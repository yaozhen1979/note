package org.importer.sipo

import groovy.io.FileType

import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.PropertiesUtil
import org.utils.CaptchaUtil

/**
 * 
 * @author tonykuo
 *
 */
class SipoWGRawDataImporter {
    
    /**
     * 
     * @param dir
     * @param patentType
     * @param doDateStr
     */
    public void process(File dir, String patentType, String doDateStr) {
        
        String doYear = "";
        Date doDate = null;
        
        if (!patentType) {
            throw new Exception("patentType is empty...");
        }
        
        if (!!doDateStr) {
            //
            doDate = DateUtil.parseDate(doDateStr)
            if (!!doDate) {
                doYear = doDateStr.substring(0, 4);
            } else {
                throw new Exception("doDate is null...")
            }
            
        } else {
            throw new Exception("doDate is empty...")
        }
        
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        // def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "127.0.0.1", 27017, 'admin')
        def patentRawSIPO = dbClient.getDB("PatentRawSIPO").getCollection("PatentRawSIPO")
        
        int count = 0;
        println "doDate = ${doDateStr}, start parsing..."
        
        // dir.eachFileRecurse(FileType.FILES) { file ->
        dir.eachFileMatch(FileType.FILES, ~/.*\.xml/) { file ->
            
            String appNumberWithoutCaptcha = file.name.replace(".xml", "")
            String _id = "${patentType}/${doYear}/${doDateStr}/${file.name}"
            def existData = patentRawSIPO.findOne([_id: _id])
            
            def rawDataMap = [:]
            
            rawDataMap << [_id: _id]
            rawDataMap << [provider: "SIPO"]
            rawDataMap << [doDate: doDate]
            rawDataMap << [pto: "CN"]
            rawDataMap << [truncate: false]
            rawDataMap << [patentType: patentType]
            rawDataMap << [soureType: "xml"]
            rawDataMap << [fileType: 1]
            rawDataMap << [data: [text: file.getText("UTF-8")]]
            rawDataMap << [appNumber: CaptchaUtil.genAppNumberWithCaptcha(appNumberWithoutCaptcha, true)]
            //
            rawDataMap << getTagAndFile(existData, "SipoWGRawDataImporter.groovy")
            rawDataMap << getMongoSyncFlag(existData)
            
            // println "rawDataMap = ${rawDataMap}"
            
            patentRawSIPO.save(rawDataMap);
            count++;
            
            // println "process data: ${count}"
            
            
        }
        
        println "doDate = ${doDateStr}, count = ${count}, finished..."
        
    }   // end process
    
    /**
     * 判斷是否為重的tagAndFile
     *
     * @param existData
     * @param codeLevel rawLevel, marshallLevel, infoLevel
     * @return
     */
    static getTagAndFile(def existData, String codeName) {
        
        def dataMap = [:]
        
        def tag = PropertiesUtil.load("config.properties").getProperty("version_tag")
        
        if (!!existData?.tagAndFile) {
            
            if (existData.tagAndFile[-1].file != codeName ||
                existData.tagAndFile[-1].tag != tag) {
                
                dataMap << ["tagAndFile" : existData.tagAndFile <<
                    [
                        "file" : codeName,
                        "tag" : tag
                    ]
                ]
                
            } else {
                dataMap << ["tagAndFile" : existData.tagAndFile]
            }
            
        } else {
            //
            dataMap << ["tagAndFile" : [] <<
                [
                    "file" : codeName,
                    "tag" : tag
                ]
            ]
        }  // end existData.tagAndFile
        
        return dataMap
        
    }   // end getTagAndFile
    
    /**
     * 
     * @param existData
     * @return
     */
    static getMongoSyncFlag(def existData) {
        
        def dataMap = [:]
        if (!!existData) {
            def mongoSyncFlagData = existData.mongoSyncFlag
            mongoSyncFlagData.last = new Date()
            dataMap << ["mongoSyncFlag": mongoSyncFlagData]
        } else {
            def now = new Date()
            def mongoSyncFlagData = ["init" : now, "last" : now]
            dataMap << ["mongoSyncFlag" : mongoSyncFlagData]
        }
        
        return dataMap
        
    }   // end getMongoSyncFlag
    
    static main(args) {
        
        // NOTE:1 單期處厘
        // T:\cnlist\sipo\WG\Cn_Design_Biblio\2016\20160330
        // File wgDir = new File("T:/cnlist/sipo/WG/Cn_Design_Biblio/2016/20160330");
        // String patentType = "WG"
        // String doDate = "20160330"
        // new SipoWGRawDataImporter().process(wgDir, patentType, doDate)
        
        // NOTE:2 整匹處理
        /*
         * 
         * 1985, 1986, 1988 finished
         */
        // T:\cnlist\sipo\WG\patentcloud3\2014
        def doYear = [
//            "1989", "1990", "1991", "1992", "1993", "1994", "1995", 
//            "1996", "1997", "1998", "1999", "2000", "2001", "2002", 
//            "2003", "2004", "2005"
//            "2006", "2007", "2008", 
            "2009" 
//            "2010"
//            "2011", 
//            "2012"
//            "2013"
//            "2014"
//            "2015"
        ]
        
        doYear.each { year ->
            // 
            new File("T:/cnlist/sipo/WG/patentcloud3/${year}").eachFile(FileType.DIRECTORIES) { dir ->
                
                if (dir.name == "20090107" || 
                    dir.name == "20090114" || 
                    dir.name == "20091007" || 
                    dir.name == "20091104" || 
                    dir.name == "20091202" || 
                    dir.name == "20091209" ) {
                    
                    println "dir name = ${dir.name}"
                    
                    String patentType = "WG";
                    String doDate = dir.name;
                    new SipoWGRawDataImporter().process(dir, patentType, doDate)
                    
                } else {
                    return false;
                }
                
            }
        }
        
        println "finished..."
        
    }

}
