package org.importer.infodata

import com.mongodb.DBCursor
import org.bson.types.ObjectId
import org.exception.CnException
import org.service.BaseService
import org.utils.RestTimeProcess

import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.infodata.InfoDataUtil
import org.utils.infodata.WGInfoDataUtil

class CnInfoDataImporter extends BaseService {
    
    //
    def processInfoData(def args, def period, def queryMap = null) {
        
        // NOTE: 暫時使用... 等正式使用11月份的資料時再統一使用dbClient
        def remoteClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        def marshallDB = remoteClient.getDB("PatentMarshallCN")
        def patentMarshallCN = marshallDB.getCollection("PatentMarshallCN")
        //
        def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "127.0.0.1", 27017, 'admin')
        def infoDB = dbClient.getDB("PatentInfoCNIPR")
        def patentInfoCNIPR = infoDB.getCollection("PatentInfoCNIPR")
        def errorPatentInfoCNIPR = infoDB.getCollection("ErrorPatentInfoCNIPR");
        
        // 可自定義查詢條件
        if (!queryMap) {
            String patentType = args.patentType
            Date doDate = DateUtil.parseDate(period);
            log.info "args = ${args}"
            log.info "doDate = ${doDate}"
            queryMap = [patentType: patentType, doDate: doDate]
        }
        
        DBCursor marshallCursor = patentMarshallCN.find(queryMap).limit(0);
        marshallCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        log.info "marshall data size = ${marshallCursor.size()}"
        
        if (marshallCursor.size() == 0) {
            throw new Exception("no data find...")
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(marshallCursor.size(), this.class.name)
        
        def _id = null;  // for exception message
        
        try {
            
            marshallCursor.each { it -> 
                
                // TODO:
                // NOTE: 2016.05.09, from 2016.04.27 開始, CN有[更正文献出版日], 目前暫時不處理
                if (it._id.toString() == "573052975eeed0af5500bf02" || 
                    it._id.toString() == "57304a235eee6f1bd8e468da" ||
                    it._id.toString() == "573052ef5eeed0af5500c53f" ||
                    it._id.toString() == "573052f95eeed0af5500c8f4") {
                    return false;
                }
                    
                // NOTO: 2016.05.11, doDate = 2016.05.04
                if (it._id.toString() == "5732e3105eee81ccc49299b4" || 
                    it._id.toString() == "5732e6d05eee81ccc4930e01" || 
                    it._id.toString() == "5732e7a45eee81ccc4931f9b" || 
                    it._id.toString() == "5732e6445eee81ccc492fc08" || 
                    it._id.toString() == "5732e71f5eee81ccc4931977" || 
                    it._id.toString() == "5732e78c5eee81ccc4931eeb" || 
                    it._id.toString() == "5732e7a65eee81ccc4931ff7" || 
                    it._id.toString() == "5732e8d95eee81ccc4937a78") {
                    return false;
                }
                    
                // NOTE: 2016.05.19, doDate = 2016.05.11
                //     : 573d3d295eee4f9f0991abfd -> 這一筆SIPO官網那查不到
                if (it._id.toString() == "573d381e5eee4f9f09912d1a" || 
                    
                    it._id.toString() == "573d3c005eee4f9f09919033" ||    // SD
                    it._id.toString() == "573d3cac5eee4f9f0991a4c3" ||    // SD
                    it._id.toString() == "573d3d295eee4f9f0991abfd" ||    // SD
                    
                    it._id.toString() == "573d3d645eee4f9f0991aea7" || 
                    it._id.toString() == "573d3d6c5eee4f9f0991b03f" || 
                    it._id.toString() == "573d3d8a5eee4f9f0991b59f" || 
                    it._id.toString() == "573d3f7d5eee4f9f09921b5c" ) {
                    return false;
                }
                
                _id = it._id
                
                def expansionData = it.data.expansion
                def queryMapForExistData = queryMapForExistData(it)
                
                // NOTE: 預先判斷是否會有多筆資料的出現, 提早處理問題... 
                DBCursor existInfolDataCursor = patentInfoCNIPR.find(queryMapForExistData)
                if (existInfolDataCursor.size() > 1) {
                    String errMsg = "marshall._id = ${it._id} query over 1 data...";
                    throw new Exception(errMsg);
                }
                
                // NOTE: findOne應沒資料可測試, 所以先暫時留著.
                def existInfolData = patentInfoCNIPR.findOne(queryMapForExistData)
                
                def infoData = null
                
                if (it.patentType == "WG") {
                    infoData = WGInfoDataUtil.generateWGInfoData(it, existInfolData)
                } else {
                    infoData = InfoDataUtil.generateInfoData(it, existInfolData, errorPatentInfoCNIPR)
                }
                // println "infoData = ${infoData}"
                
                // TODO: json validator
                
                if (!!existInfolData) {
                    patentInfoCNIPR.update([_id: existInfolData._id], infoData, true, false, com.mongodb.WriteConcern.ACKNOWLEDGED)
                } else {
                    patentInfoCNIPR.insert(infoData, com.mongodb.WriteConcern.ACKNOWLEDGED)
                }
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            // TODO: save to error collection
            def errMsg = "marshall._id = ${_id}, Exception => ${e.message}"
            log.error errMsg
            throw new CnException(errMsg)
        } finally {
            dbClient.close()
        }
        
    }
    
    /**
     * 
     * @param lv1Data
     * @return
     */
    def queryMapForExistData(def marshallData) {
        
        def queryMap = [:]
        queryMap << [doDate: marshallData.doDate]
        
        // NOTE: CN, KR 因為歷史原因, 導致在infoDB中patentNumber = appNumber. 
        queryMap << [appNumber: marshallData.appNumber]
        
        def patentType = marshallData.patentType
        switch (patentType) {
            case "FM":
                queryMap << [stat : 1]
                break;
            case "SD":
                queryMap << [stat : 2]
                break;
            case "XX":
                queryMap << [stat : 2]
                break;
            case "WG":
                queryMap << [stat : 2]
                break;
            defualt:
                throw new Exception("marshallData._id = ${marshallData._id}, patentType error")
                break;
        }
        
        return queryMap
    }
    
    static main(args) {
        
        def year = "2016"
        def period = "20160511"
        
        // "FM", "SD", "XX", "WG"
        ["SD", "XX", "WG"].each { patentType ->
            
            def argMap = [:]
            
            argMap << ['patentType' : patentType]
            
            new CnInfoDataImporter().processInfoData(argMap, period);
            
        }
        
        // 5729c6145eee304823880b7f
//        def queryMap = [_id: new ObjectId("5729c6145eee304823880b7f")]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // CN303429845S / CN303429939S
//        def queryMap = [_id: new ObjectId("56f215245eeed09905880004")]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for FM test pct data CN104937930A
        // for FM ipcr data have [\n]
//        def queryMap = [openNumber: "CN105027243A"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for SD test CN102611705B
//        def queryMap = [decisionNumber: "CN102611705B"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for XX test data
//        def queryMap = [decisionNumber: "CN204667289U"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // for WG test data / CN303380514S / CN303380733S
//        def queryMap = [decisionNumber: "CN303380514S"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        //  for WG agents = null test / CN303380516S / CN303381713S
//        def queryMap = [decisionNumber: "CN303381713S"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // test for priorityPatents CN104929793A
//        def queryMap = [patentNumber: "CN104929793A"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        // test for citedPatents && otherReferences \ CN102551747B \ CN103977133B
//        def queryMap = [patentNumber: "CN103977133B"]
//        new CnInfoDataImporter().processInfoData(null, null, queryMap);
        
        println "finished..."
        
    }

}
