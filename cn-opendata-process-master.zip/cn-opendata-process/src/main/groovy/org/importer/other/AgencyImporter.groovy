package org.importer.other

import org.utils.MongoUtil

/**
 * 匯入CN代理機構資料, agency-utf8.txt
 * 
 * @author tonykuo
 *
 */
class AgencyImporter {

    static main(args) {
        
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        // def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "127.0.0.1", 27017, 'admin')
        def agencyCol = dbClient.getDB("PatentRawCN").getCollection("Agency")
        
        File agencyFile = new File("opendata-sample/WG/agency-utf8.txt")
        
        int count = agencyCol.count()
        println "agency count = ${count}"
        
        agencyFile.eachLine { line, number -> 
            if (number <= 1) {
                return
            }
            // println "${number} = ${line}"
            def mapData = [:]
            //
            def data = line.split(/\s+/)
            // println data[0].trim() + " " + data[1].trim()
            mapData << [_id : data[0].trim()]
            mapData << [agencyName : data[1].trim()]
            //
            agencyCol.save(mapData)
        }
        
        println "finished"
    }

}
