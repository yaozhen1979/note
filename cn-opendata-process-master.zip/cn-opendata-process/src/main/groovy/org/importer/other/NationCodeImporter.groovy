package org.importer.other

import org.utils.MongoUtil

class NationCodeImporter {

    static main(args) {
        
        def dbClient = MongoUtil.connect3X("datateamcn", "hadfhastr", "10.60.90.101", 27017, 'admin')
        // def dbClient = MongoUtil.connect3X("patentdata", "data.cloud.Abc12345", "127.0.0.1", 27017, 'admin')
        def ncCol = dbClient.getDB("PatentRawCN").getCollection("NationCode")
        
        File nationCodeFile = new File("opendata-sample/WG/nation-code.txt")
        
        int count = ncCol.count()
        // println "agency count = ${count}"
        
        nationCodeFile.eachLine { line, number ->
            
            // println "${number} = ${line}"
            def mapData = [:]
            //
            def data = line.split(/\s+/)
            // println data[0].trim() + " " + data[1].trim()
            mapData << [_id : data[0].trim()]
            mapData << [nationName : data[1].trim()]
            //
            ncCol.save(mapData)
            
        }
        
        println "finished"
    }

}
