package org.service;

import java.util.Properties;
import org.utils.PropertiesUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * refactor ???
 * 
 * 只放由讀取config.properties中的資料
 * 
 * @author tonykuo
 *
 */
public abstract class BaseService {
    
    protected static Logger log = LoggerFactory.getLogger(BaseService.class);
    
    // TODO: load class refactor 
    protected Properties propertyUtil = PropertiesUtil.load("config.properties");
    // protected Properties propertyUtil = PropertiesUtil.load("config.properties");
    
    protected final String USER_MAIL = propertyUtil.getProperty("user_mail");
    
    // MONGO DB SETTING
    // protected final String MONGODB_USER_NAME = propertyUtil.getProperty("mongodb_username");
    // protected final String MONGODB_PWD = propertyUtil.getProperty("mongodb_pwd");
    // protected final String MONGODB_IP = propertyUtil.getProperty("mongodb_ip");
    // protected final int MONGODB_PORT = Integer.valueOf(propertyUtil.getProperty("mongodb_port"));
    
    protected final String RAW_DATA_FOLDER_PATH = propertyUtil.getProperty("raw_data_folder_path");
    protected final String IMAGE_DATA_FOLDER_PATH = propertyUtil.getProperty("image_data_folder_path")
    
}
