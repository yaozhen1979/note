//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>classification-national complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="classification-national"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}country"/&gt;
 *         &lt;element ref="{}edition" minOccurs="0"/&gt;
 *         &lt;element ref="{}main-classification"/&gt;
 *         &lt;element ref="{}further-classification" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}additional-info"/&gt;
 *           &lt;element ref="{}linked-indexing-code-group"/&gt;
 *           &lt;element ref="{}unlinked-indexing-code"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element ref="{}text" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classification-national", propOrder = {
    "country",
    "edition",
    "mainClassification",
    "furtherClassification",
    "additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode",
    "text"
})
public class ClassificationNational {

    @XmlElement(required = true)
    protected String country;
    protected Edition edition;
    @XmlElement(name = "main-classification", required = true)
    protected MainClassification mainClassification;
    @XmlElement(name = "further-classification")
    protected List<FurtherClassification> furtherClassification;
    @XmlElements({
        @XmlElement(name = "additional-info", type = AdditionalInfo.class),
        @XmlElement(name = "linked-indexing-code-group", type = LinkedIndexingCodeGroup.class),
        @XmlElement(name = "unlinked-indexing-code", type = UnlinkedIndexingCode.class)
    })
    protected List<Object> additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;
    protected Text text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Edition }
     *     
     */
    public Edition getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Edition }
     *     
     */
    public void setEdition(Edition value) {
        this.edition = value;
    }

    /**
     * 取得 mainClassification 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainClassification }
     *     
     */
    public MainClassification getMainClassification() {
        return mainClassification;
    }

    /**
     * 設定 mainClassification 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainClassification }
     *     
     */
    public void setMainClassification(MainClassification value) {
        this.mainClassification = value;
    }

    /**
     * Gets the value of the furtherClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the furtherClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFurtherClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FurtherClassification }
     * 
     * 
     */
    public List<FurtherClassification> getFurtherClassification() {
        if (furtherClassification == null) {
            furtherClassification = new ArrayList<FurtherClassification>();
        }
        return this.furtherClassification;
    }

    /**
     * Gets the value of the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInfo }
     * {@link LinkedIndexingCodeGroup }
     * {@link UnlinkedIndexingCode }
     * 
     * 
     */
    public List<Object> getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode() {
        if (additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode == null) {
            additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode = new ArrayList<Object>();
        }
        return this.additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

}
