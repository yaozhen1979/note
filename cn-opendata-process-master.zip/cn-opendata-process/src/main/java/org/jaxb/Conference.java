//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>conference complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="conference"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}conftitle"/&gt;
 *           &lt;element ref="{}date" minOccurs="0"/&gt;
 *           &lt;element ref="{}confno" minOccurs="0"/&gt;
 *           &lt;element ref="{}confplace" minOccurs="0"/&gt;
 *           &lt;element ref="{}confsponsor" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "conference", propOrder = {
    "text",
    "conftitle",
    "date",
    "confno",
    "confplace",
    "confsponsor"
})
public class Conference {

    protected Text text;
    protected Conftitle conftitle;
    protected Date date;
    protected Confno confno;
    protected Confplace confplace;
    protected List<Confsponsor> confsponsor;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * 取得 conftitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Conftitle }
     *     
     */
    public Conftitle getConftitle() {
        return conftitle;
    }

    /**
     * 設定 conftitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Conftitle }
     *     
     */
    public void setConftitle(Conftitle value) {
        this.conftitle = value;
    }

    /**
     * 取得 date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Date }
     *     
     */
    public Date getDate() {
        return date;
    }

    /**
     * 設定 date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Date }
     *     
     */
    public void setDate(Date value) {
        this.date = value;
    }

    /**
     * 取得 confno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Confno }
     *     
     */
    public Confno getConfno() {
        return confno;
    }

    /**
     * 設定 confno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Confno }
     *     
     */
    public void setConfno(Confno value) {
        this.confno = value;
    }

    /**
     * 取得 confplace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Confplace }
     *     
     */
    public Confplace getConfplace() {
        return confplace;
    }

    /**
     * 設定 confplace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Confplace }
     *     
     */
    public void setConfplace(Confplace value) {
        this.confplace = value;
    }

    /**
     * Gets the value of the confsponsor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the confsponsor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConfsponsor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Confsponsor }
     * 
     * 
     */
    public List<Confsponsor> getConfsponsor() {
        if (confsponsor == null) {
            confsponsor = new ArrayList<Confsponsor>();
        }
        return this.confsponsor;
    }

}
