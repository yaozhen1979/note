//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>cn-applicant complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="cn-applicant"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;sequence&gt;
 *             &lt;choice&gt;
 *               &lt;element ref="{}name"/&gt;
 *               &lt;sequence&gt;
 *                 &lt;element ref="{}prefix" minOccurs="0"/&gt;
 *                 &lt;choice&gt;
 *                   &lt;element ref="{}last-name"/&gt;
 *                   &lt;element ref="{}orgname"/&gt;
 *                 &lt;/choice&gt;
 *                 &lt;element ref="{}first-name" minOccurs="0"/&gt;
 *                 &lt;element ref="{}middle-name" minOccurs="0"/&gt;
 *                 &lt;element ref="{}suffix" minOccurs="0"/&gt;
 *                 &lt;element ref="{}iid" minOccurs="0"/&gt;
 *                 &lt;element ref="{}role" minOccurs="0"/&gt;
 *                 &lt;element ref="{}orgname" minOccurs="0"/&gt;
 *                 &lt;element ref="{}department" minOccurs="0"/&gt;
 *                 &lt;element ref="{}synonym" maxOccurs="unbounded" minOccurs="0"/&gt;
 *               &lt;/sequence&gt;
 *             &lt;/choice&gt;
 *             &lt;element ref="{}registered-number" minOccurs="0"/&gt;
 *           &lt;/sequence&gt;
 *           &lt;element ref="{}addressbook" maxOccurs="unbounded"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element ref="{}nationality" minOccurs="0"/&gt;
 *         &lt;element ref="{}residence" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" use="required" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cn-applicant", propOrder = {
    "content"
})
public class CnApplicant {

    @XmlElementRefs({
        @XmlElementRef(name = "name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "role", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "iid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "orgname", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "prefix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "first-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "synonym", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "last-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "addressbook", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "middle-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "department", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "nationality", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "residence", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "registered-number", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "suffix", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<?>> content;
    @XmlAttribute(name = "sequence", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String sequence;

    /**
     * 取得其餘的內容模型. 
     * 
     * <p>
     * 基於下列原因, 您取得此 "catch-all" 特性: 
     * 綱要的兩個不同部分均使用欄位名稱 "Orgname". 請參閱: 
     * file:/D:/workspace/pc/cn-opendata-process/xsd/cn-patent-document-update.xsd 的第 1218 行
     * file:/D:/workspace/pc/cn-opendata-process/xsd/cn-patent-document-update.xsd 的第 1211 行
     * <p>
     * 為去除此特性, 請將特性自訂項目套用至下列兩個宣告的
     * 其中之一, 以變更它們的名稱: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link Name }{@code >}
     * {@link JAXBElement }{@code <}{@link Role }{@code >}
     * {@link JAXBElement }{@code <}{@link Iid }{@code >}
     * {@link JAXBElement }{@code <}{@link Orgname }{@code >}
     * {@link JAXBElement }{@code <}{@link Prefix }{@code >}
     * {@link JAXBElement }{@code <}{@link FirstName }{@code >}
     * {@link JAXBElement }{@code <}{@link Synonym }{@code >}
     * {@link JAXBElement }{@code <}{@link LastName }{@code >}
     * {@link JAXBElement }{@code <}{@link Addressbook }{@code >}
     * {@link JAXBElement }{@code <}{@link MiddleName }{@code >}
     * {@link JAXBElement }{@code <}{@link Department }{@code >}
     * {@link JAXBElement }{@code <}{@link Nationality }{@code >}
     * {@link JAXBElement }{@code <}{@link Residence }{@code >}
     * {@link JAXBElement }{@code <}{@link RegisteredNumber }{@code >}
     * {@link JAXBElement }{@code <}{@link Suffix }{@code >}
     * 
     * 
     */
    public List<JAXBElement<?>> getContent() {
        if (content == null) {
            content = new ArrayList<JAXBElement<?>>();
        }
        return this.content;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

}
