//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>office-of-filing complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="office-of-filing"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}region"/&gt;
 *           &lt;element ref="{}country" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{}country"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "office-of-filing", propOrder = {
    "content"
})
public class OfficeOfFiling {

    @XmlElementRefs({
        @XmlElementRef(name = "country", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "region", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<?>> content;

    /**
     * 取得其餘的內容模型. 
     * 
     * <p>
     * 基於下列原因, 您取得此 "catch-all" 特性: 
     * 綱要的兩個不同部分均使用欄位名稱 "Country". 請參閱: 
     * file:/D:/workspace/pc/cn-opendata-process/xsd/cn-patent-document-update.xsd 的第 600 行
     * file:/D:/workspace/pc/cn-opendata-process/xsd/cn-patent-document-update.xsd 的第 598 行
     * <p>
     * 為去除此特性, 請將特性自訂項目套用至下列兩個宣告的
     * 其中之一, 以變更它們的名稱: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link Region }{@code >}
     * 
     * 
     */
    public List<JAXBElement<?>> getContent() {
        if (content == null) {
            content = new ArrayList<JAXBElement<?>>();
        }
        return this.content;
    }

}
