//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.11.12 於 02:24:00 PM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>cn-parties complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="cn-parties"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}cn-applicants"/&gt;
 *         &lt;element ref="{}cn-inventors" minOccurs="0"/&gt;
 *         &lt;element ref="{}correspondence-address" minOccurs="0"/&gt;
 *         &lt;element ref="{}cn-agents" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cn-parties", propOrder = {
    "cnApplicants",
    "cnInventors",
    "correspondenceAddress",
    "cnAgents"
})
public class CnParties {

    @XmlElement(name = "cn-applicants", required = true)
    protected CnApplicants cnApplicants;
    @XmlElement(name = "cn-inventors")
    protected CnInventors cnInventors;
    @XmlElement(name = "correspondence-address")
    protected CorrespondenceAddress correspondenceAddress;
    @XmlElement(name = "cn-agents")
    protected CnAgents cnAgents;

    /**
     * 取得 cnApplicants 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnApplicants }
     *     
     */
    public CnApplicants getCnApplicants() {
        return cnApplicants;
    }

    /**
     * 設定 cnApplicants 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnApplicants }
     *     
     */
    public void setCnApplicants(CnApplicants value) {
        this.cnApplicants = value;
    }

    /**
     * 取得 cnInventors 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnInventors }
     *     
     */
    public CnInventors getCnInventors() {
        return cnInventors;
    }

    /**
     * 設定 cnInventors 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnInventors }
     *     
     */
    public void setCnInventors(CnInventors value) {
        this.cnInventors = value;
    }

    /**
     * 取得 correspondenceAddress 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CorrespondenceAddress }
     *     
     */
    public CorrespondenceAddress getCorrespondenceAddress() {
        return correspondenceAddress;
    }

    /**
     * 設定 correspondenceAddress 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrespondenceAddress }
     *     
     */
    public void setCorrespondenceAddress(CorrespondenceAddress value) {
        this.correspondenceAddress = value;
    }

    /**
     * 取得 cnAgents 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CnAgents }
     *     
     */
    public CnAgents getCnAgents() {
        return cnAgents;
    }

    /**
     * 設定 cnAgents 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CnAgents }
     *     
     */
    public void setCnAgents(CnAgents value) {
        this.cnAgents = value;
    }

}
