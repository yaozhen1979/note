package org.common;

public final class Constants {

    public static final String DATA_PROVIDER = "SIPO";
    // PTO 為CNIPR是歷史因素...
    public static final String PTO = "CNIPR";
    public final static String XSD_FILE_PATH = "xsd/cn-patent-document-update.xsd";
    public final static String LANG_ENCODING = "UTF-8";
    public final static String LANG_ENCODING_CN = "GB2312";
    public final static String WG_BIB_FILE_NAME = "INDUSTRIAL-DESIGN-BIB-UTF8.TXT";
    
    
    private Constants() {
    }

}
