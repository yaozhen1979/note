KDLib_SolrClient
================

KDLib module, solr client
