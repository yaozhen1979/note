package patentdata.utils;

import java.util.Properties;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;

public class PropertiesUtil {
    private static Logger log = (Logger) LoggerFactory.getLogger(PropertiesUtil.class);
    
    public static Properties properties;
    private static final String CONFIG_PATH = "config/config.properties";
    
    public static Properties getProperties() {
        
        log.info("load config.properties : " + CONFIG_PATH);
        
        if (properties == null) {
            try {
                properties = new Properties();
                properties.load(PropertiesUtil.class.getClassLoader().getResourceAsStream(CONFIG_PATH));
            } catch (Exception ex) {
                log.error(ex.getMessage(), ex);
            }
        }
        
        return properties;
    }

}
