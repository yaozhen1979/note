package patentdata.utils;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;

public class ConfigUtil {

    private static Logger log = (Logger) LoggerFactory.getLogger(ConfigUtil.class);
    
    /**
     * @param key
     * @return
     */
    public static String findConfigByKey(String key) {
        
        log.info("find config, key => " + key);
        
        return PropertiesUtil.getProperties().getProperty(key);
    }
    

}
