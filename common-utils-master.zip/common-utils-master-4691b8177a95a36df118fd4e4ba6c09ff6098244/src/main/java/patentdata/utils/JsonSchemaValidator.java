package patentdata.utils;

import java.util.Iterator;

import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import ch.qos.logback.classic.Logger;

/**
 * note: <br>
 * 1.src/main/resources 中新增config/config.properties 檔案<br>
 * 2.將json schema path以key-value格式寫入config.properties， ex. json.schema.path=/jsonSchema/patentInfo-schema.json<br>
 * 3.將json schema 檔案放至 src/main/resources 下，位置如第2點所定義<br>
 * 4.呼叫JsonSchemaValidatorUtil.valid(String jsonStr) 回傳 ProcessingReport 物件<br>
 * 5.if (ProcessingReport.isSuccess()) {<br>
 *       do something<br>
 *   } else {<br>
 *       JsonSchemaValidatorUtil.parseErrorJsonStr(result2)<br>
 *   }<br>
 * @author mikelin
 *
 */
public class JsonSchemaValidator {

    private static JsonSchema schema;
    private static boolean jsonInited;

    private static Logger log = (Logger) LoggerFactory.getLogger(JsonSchemaValidator.class);

    /**
     * initial JsonSchema
     * 
     * @throws Exception
     */
    private static void initJson(String schemaPath) throws Exception {

        if (jsonInited) {
            return;
        }

        // jsonSchema.path(可換) => 在 src/main/resources/config/config.properties 中定義
        JsonNode dataSchema = JsonLoader.fromResource(ConfigUtil.findConfigByKey(schemaPath));
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
        schema = factory.getJsonSchema(dataSchema);

        jsonInited = true;
    }

    /**
     * @param jsonStr
     * @return ProcessingReport
     * @throws Exception
     */
    public static ProcessingReport valid(String jsonStr) throws Exception {

        initJson("json.schema.path");

        JsonNode data = JsonLoader.fromString(jsonStr);
        ProcessingReport report = schema.validate(data);

        return report;
    }
    
    /**
     * @param schemaPath
     * @param jsonStr
     * @return
     * @throws Exception
     */
    public static ProcessingReport valid(String schemaPath, String jsonStr) throws Exception {

        initJson(schemaPath);

        JsonNode data = JsonLoader.fromString(jsonStr);
        ProcessingReport report = schema.validate(data);

        return report;
    }

    /**
     * @param report
     * @return errorJsonStr
     */
    public static String parseErrorJsonStr(ProcessingReport report) {

        String errorJsonStr = "";

        for (Iterator<ProcessingMessage> it = report.iterator(); it.hasNext();) {

            ProcessingMessage msg = it.next();

            errorJsonStr = msg.asJson().toString();
        }

        return errorJsonStr;

    }
    
    public static void main(String[] args) throws Exception {
        String jsonData1 = "{ \r\n" + "    \"pto\" : \"USPTO\", \r\n" + "    \"stat\" : 2, \r\n"
                + "    \"kindcode\" : \"B2\", \r\n" + "    \"appNumber\" : \"10/427577\", \r\n"
                + "    \"brief\" : {\r\n"
                + "        \"origin\" : \"<p id=\\\"P-00001\\\" num=\\\"00001\\\">A method for forming a polysilicon FinFET (<b>10</b>) or other thin film transistor structure includes forming an insulative layer (<b>12</b>) over a semiconductor substrate (<b>14</b>). An amorphous silicon layer (<b>32</b>) forms over the insulative layer (<b>12</b>). A silicon germanium seed layer (<b>44</b>) forms in association with the amorphous silicon layer (<b>32</b>) for controlling silicon grain growth. The polysilicon layer arises from annealing the amorphous silicon layer (<b>32</b>). During the annealing step, silicon germanium seed layer (<b>44</b>), together with silicon germanium layer (<b>34</b>), catalyzes silicon recrystallization to promote growing larger crystalline grains, as well as fewer grain boundaries within the resulting polysilicon layer. Source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) regions are formed within the polysilicon layer. A double-gated region (<b>24</b>) forms in association with source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) to produce polysilicon FinFET (<b>10</b>).</p>\"\r\n"
                + "    }, \r\n" + "    \"assignees\" : [\r\n" + "        {\r\n" + "            \"name\" : {\r\n"
                + "                \"origin\" : \"Freescale Semiconductor, Inc.\"\r\n" + "            }, \r\n"
                + "            \"address\" : {\r\n" + "                \"origin\" : \"Austin,TX\"\r\n"
                + "            }, \r\n" + "            \"country\" : {\r\n" + "                \"origin\" : \"US\"\r\n"
                + "            }\r\n" + "        }\r\n" + "    ],\r\n" + "    \"mainIPC\" : \"H01L 21/00\", \r\n"
                + "    \"ipcs\" : [\r\n" + "        \"H01L 21/00\", \r\n" + "        \"H01L 21/20\", \r\n"
                + "        \"H01L 21/3205\"\r\n" + "    ], \r\n" + "    \"familyId\" : 33310189, \r\n"
                + "    \"truncate\" : false\r\n" + "}";

        String jsonData2 = "{ \r\n" + "    \"pto\" : \"USPTO\", \r\n" + "    \"stat\" : \"1\", \r\n"
                + "    \"kindcode\" : \"B2\", \r\n" + "    \"appNumber\" : \"10/427577\", \r\n"
                + "    \"brief\" : {\r\n"
                + "        \"origin\" : \"<p id=\\\"P-00001\\\" num=\\\"00001\\\">A method for forming a polysilicon FinFET (<b>10</b>) or other thin film transistor structure includes forming an insulative layer (<b>12</b>) over a semiconductor substrate (<b>14</b>). An amorphous silicon layer (<b>32</b>) forms over the insulative layer (<b>12</b>). A silicon germanium seed layer (<b>44</b>) forms in association with the amorphous silicon layer (<b>32</b>) for controlling silicon grain growth. The polysilicon layer arises from annealing the amorphous silicon layer (<b>32</b>). During the annealing step, silicon germanium seed layer (<b>44</b>), together with silicon germanium layer (<b>34</b>), catalyzes silicon recrystallization to promote growing larger crystalline grains, as well as fewer grain boundaries within the resulting polysilicon layer. Source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) regions are formed within the polysilicon layer. A double-gated region (<b>24</b>) forms in association with source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) to produce polysilicon FinFET (<b>10</b>).</p>\"\r\n"
                + "    }, \r\n" + "    \"assignees\" : [\r\n" + "        {\r\n" + "            \"name\" : {\r\n"
                + "                \"origin\" : \"Freescale Semiconductor, Inc.\"\r\n" + "            }, \r\n"
                + "            \"address\" : {\r\n" + "                \"origin\" : \"Austin,TX\"\r\n"
                + "            }, \r\n" + "            \"country\" : {\r\n" + "                \"origin\" : \"US\"\r\n"
                + "            }\r\n" + "        }\r\n" + "    ],\r\n" + "    \"mainIPC\" : \"H01L 21/00\", \r\n"
                + "    \"ipcs\" : [\r\n" + "        \"H01L 21/00\", \r\n" + "        \"H01L 21/20\", \r\n"
                + "        \"H01L 21/3205\"\r\n" + "    ], \r\n" + "    \"familyId\" : 33310189, \r\n"
                + "    \"truncate\" : false\r\n" + "}";

        ProcessingReport result1 = JsonSchemaValidator.valid("json.schema.path", jsonData1);
        if (result1.isSuccess()) {
            log.info("success");
        } else {
            log.info("msg : " + JsonSchemaValidator.parseErrorJsonStr(result1));
        }

        ProcessingReport result2 = JsonSchemaValidator.valid(jsonData2);
        if (result2.isSuccess()) {
            log.info("success");
        } else {
            log.info(JsonSchemaValidator.parseErrorJsonStr(result2));
        }
    }

}
