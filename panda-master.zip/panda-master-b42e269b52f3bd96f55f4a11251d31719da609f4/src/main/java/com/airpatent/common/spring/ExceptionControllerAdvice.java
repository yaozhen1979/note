package com.airpatent.common.spring;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.airpatent.util.StackTraceUtils;
import com.airpatent.vo.ResultVO;
import com.google.gson.JsonObject;

@ControllerAdvice
public class ExceptionControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(ExceptionControllerAdvice.class);
    
    @ExceptionHandler(value = { Exception.class })
    public Object handleException(Exception exception, WebRequest request) {

        boolean ajax = StringUtils.equalsIgnoreCase(request.getHeader("x-requested-with"), "XMLHttpRequest");
        logger.error(exception.toString(), exception);
        if (ajax) {
            JsonObject errorJson = new JsonObject();
            errorJson.addProperty("status", ResultVO.STATUS_FAIL);
            errorJson.addProperty("message", exception.getMessage());
            String errorDetail = StackTraceUtils.getStackTrace(exception);
            errorJson.addProperty("exception", errorDetail);

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

            ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                    HttpStatus.INTERNAL_SERVER_ERROR);
            
            return responseEntity;
        } else {
            ModelAndView model = new ModelAndView("error/error");
            model.addObject("exception", exception);
            return model;
        }
    }
    
}
