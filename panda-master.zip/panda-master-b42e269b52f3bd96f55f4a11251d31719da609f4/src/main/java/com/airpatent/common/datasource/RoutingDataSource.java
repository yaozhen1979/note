package com.airpatent.common.datasource;

import org.slf4j.MDC;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

public class RoutingDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        String ds = DataSourceRouteHolder.getDataSource();
        if (ds == null) {
            MDC.put("ds", DataSourceRouteHolder.DS_SLAVE);
        } else {
            MDC.put("ds", ds);
        }
        return ds;
    }

}
