package com.airpatent.common.datasource;

import org.aspectj.lang.JoinPoint;

public class DataSourceAspect {
    
    public void useMasterDS(JoinPoint point) {
        DataSourceRouteHolder.setDataSource(DataSourceRouteHolder.DS_MASTER);
    }
}
