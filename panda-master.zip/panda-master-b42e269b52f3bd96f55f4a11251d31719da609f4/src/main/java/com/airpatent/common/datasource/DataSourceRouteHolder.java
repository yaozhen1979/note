package com.airpatent.common.datasource;

public class DataSourceRouteHolder {

    public static final String DS_MASTER = "master";
    public static final String DS_SLAVE = "slave";
    
    private static final ThreadLocal<String> dataSources = new ThreadLocal<String>();
    
    public static void setDataSource(String ds) {
        dataSources.set(ds);
    }
    
    public static String getDataSource() {
        return (String) dataSources.get();
    }
    
    public static void clearDataSourceKey() {
        dataSources.remove();
    }
    
}
