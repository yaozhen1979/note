package com.airpatent.common;

public class Constant {

    public static final String SESSION_USER_PROFILE = "session_userProfile";
    
}
