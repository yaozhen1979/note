package com.airpatent.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigUtil {

    public String test = "Test";
    
    public @Value("${jdbc.write.username}") String user;
    
}
