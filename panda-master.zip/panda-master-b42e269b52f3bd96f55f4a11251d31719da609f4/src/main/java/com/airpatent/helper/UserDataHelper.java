package com.airpatent.helper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.airpatent.common.hibernate.QueryBuilder;
import com.airpatent.model.UserData;

@Repository
public class UserDataHelper extends BaseHelper {

    public UserData findUserById(String userId) {
        QueryBuilder query = newQueryBuilder("from UserData");
        query.eq("id", userId);
        return (UserData) query.querySingle();
    }
    
    public List<UserData> queryUsers() {
        QueryBuilder query = newQueryBuilder("from UserData");
        return query.query();
    }
    
}
