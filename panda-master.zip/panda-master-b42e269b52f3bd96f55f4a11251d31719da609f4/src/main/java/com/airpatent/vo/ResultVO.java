package com.airpatent.vo;

public class ResultVO {

    public static final int STATUS_SUCCESS = 0; 
    public static final int STATUS_FAIL = 1; 
    
    private int status;
    private String code;
    private String message;
    private Object result;
    private String exception;
    
    public ResultVO() {
        
    }

    public ResultVO(int status) {
        super();
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    public String getException() {
        return exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }
    
}
