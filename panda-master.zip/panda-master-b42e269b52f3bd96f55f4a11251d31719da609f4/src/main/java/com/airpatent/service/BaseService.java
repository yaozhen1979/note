package com.airpatent.service;

import com.airpatent.helper.BaseHelper;

public class BaseService extends BaseHelper {

}
