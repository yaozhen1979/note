package com.airpatent.service;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airpatent.helper.UserDataHelper;
import com.airpatent.model.AccessLog;
import com.airpatent.model.UserData;

@Service
public class HelloService extends BaseService {
    
    @Autowired
    private UserDataHelper userDataHelper;
    @Autowired
    private AccessLogService accessLogService;

    public UserData saveUser(String id, String name) {
        Session session = getCurrentSession();
        UserData user = new UserData();
        user.setId(id);
        user.setName(name);
        session.save(user);
        
        accessLogService.txlog(String.format("save user: %s, %s", user.getId(), user.getName()));
        
        user = userDataHelper.findUserById(id);
//        if (true) {
//            throw new RuntimeException("test");
//        }
        
        return user;
    }
    
}
