package com.airpatent.service;

import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.airpatent.model.AccessLog;

@Service
public class AccessLogService extends BaseService {
    
    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public void txlog(String logMsg) {
        Session session = getCurrentSession();
        AccessLog log = new AccessLog();
        log.setLogMsg(logMsg);
        session.save(log);
    }
    
}
