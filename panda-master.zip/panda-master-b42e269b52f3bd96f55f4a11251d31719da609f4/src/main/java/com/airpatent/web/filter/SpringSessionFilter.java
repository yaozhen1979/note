package com.airpatent.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.filter.DelegatingFilterProxy;

import com.airpatent.web.listener.ProfileListener;

public class SpringSessionFilter implements Filter {

    @Autowired
    private boolean active;
    
    private DelegatingFilterProxy proxy = null;
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        if (active) {
            proxy.doFilter(request, response, filterChain);
        } else {
            filterChain.doFilter(request, response);
        }
    }
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        if (StringUtils.containsIgnoreCase(ProfileListener.springActiveProfile, "redis")) {
            proxy = new DelegatingFilterProxy();
            proxy.init(filterConfig);
            active = true;
        }
    }

    @Override
    public void destroy() {
        if (active) {
            proxy.destroy();
        }
    }
    
}
