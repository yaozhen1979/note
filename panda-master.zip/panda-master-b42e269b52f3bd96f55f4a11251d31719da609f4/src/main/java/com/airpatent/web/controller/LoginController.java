package com.airpatent.web.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airpatent.common.Constant;
import com.airpatent.vo.ResultVO;
import com.airpatent.vo.UserProfile;

@RestController
@RequestMapping("/login")
public class LoginController {

    @RequestMapping(path="", method = { RequestMethod.POST })
    public ResultVO login(HttpSession session, @RequestParam("id") String id, @RequestParam("pwd") String pwd) {
        UserProfile user = new UserProfile();
        user.setId(id);
        user.setName("Name" + id);
        session.setAttribute(Constant.SESSION_USER_PROFILE, user);
        
        ResultVO vo = new ResultVO(ResultVO.STATUS_SUCCESS);
        return vo;
    }
    
    
    @RequestMapping(path="", method = { RequestMethod.GET })
    public UserProfile getUserInfo(HttpSession session) {
        return (UserProfile) session.getAttribute(Constant.SESSION_USER_PROFILE); 
    }
}
