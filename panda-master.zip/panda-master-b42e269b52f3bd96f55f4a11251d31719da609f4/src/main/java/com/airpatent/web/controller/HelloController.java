package com.airpatent.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.airpatent.helper.UserDataHelper;
import com.airpatent.model.UserData;
import com.airpatent.service.HelloService;

@RestController
@RequestMapping("/hello")
public class HelloController {

    @Autowired
    private HelloService helloService;

    @Autowired
    private UserDataHelper userDataHelper;
    
    @RequestMapping("")
    public String hello() {
        return "Hello!";
    }
    
    @RequestMapping("index")
    public ModelAndView index() {
        return new ModelAndView("/hello/index");
    }

    @RequestMapping("user")
    public List<UserData> user() {
        return userDataHelper.queryUsers();
    }
    
    @RequestMapping(path="user", method = { RequestMethod.POST })
    public UserData save(@RequestParam("id") String id, @RequestParam("name") String name) {
        UserData user = helloService.saveUser(id, name);
        return user;
    }
}
