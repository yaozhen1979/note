package com.airpatent.web.listener;

import java.io.InputStream;
import java.util.Map;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.AbstractEnvironment;
import org.yaml.snakeyaml.Yaml;

public class ProfileListener implements ServletContextListener {

    private Logger log = LoggerFactory.getLogger(ProfileListener.class); 
    public static String springActiveProfile;
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        Yaml yaml = new Yaml();
        Map<String, Object> result = (Map<String, Object>) yaml.load(ProfileListener.class.getResourceAsStream("/airpatent/config.yml"));
        String profile = getKey(result, "spring.profiles.active");
        if (profile != null && profile.trim().length() > 0) {
            log.info("spring.profiles.active:" + profile);
            springActiveProfile = profile;
            System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, profile);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        
    }
    
    private String getKey(Map<String, Object> data, String key) {
        String[] keys = key.split("\\.");
        Map<String, Object> target = data;
        for (int i = 0; i < keys.length - 1; i++) {
            Object v = target.get(keys[i]);
            if (v != null) {
                target = (Map<String, Object>) v;
            } else {
                return null;
            }
        }
        String value = (String) target.get(keys[keys.length-1]);
        return value;
    }
}
