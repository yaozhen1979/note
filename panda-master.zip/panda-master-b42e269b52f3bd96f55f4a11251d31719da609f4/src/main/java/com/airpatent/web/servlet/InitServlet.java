package com.airpatent.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.logicalcobwebs.proxool.ProxoolFacade;

public class InitServlet extends HttpServlet {

    @Override
    public void destroy() {
        
        ProxoolFacade.shutdown(3);
        
    }

    @Override
    public void init() throws ServletException {
        super.init();
    }

    
    
}
