package com.airpatent.model;

public class AccessLog {
    
    private int id;
    private String logMsg;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLogMsg() {
        return logMsg;
    }
    public void setLogMsg(String logMsg) {
        this.logMsg = logMsg;
    }
    
}
