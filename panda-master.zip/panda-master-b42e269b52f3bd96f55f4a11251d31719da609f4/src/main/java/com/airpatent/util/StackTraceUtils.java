package com.airpatent.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Provides some useful exception utility methods.
 * 
 * @author Allan Huang
 */
public final class StackTraceUtils {

    public static final String getStackTrace(Throwable throwable) {
        final Writer result = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(result);
        throwable.printStackTrace(printWriter);

        return result.toString();
    }

    public static final String getStackTrace(String customFormat, Throwable throwable) {
        // add the class name and any message passed to constructor
        final StringBuilder result = new StringBuilder(customFormat);
        result.append(throwable.toString());
        final String newLine = System.getProperty("line.separator");
        result.append(newLine);

        // add each element of the stack trace
        for (StackTraceElement element : throwable.getStackTrace()) {
            result.append(element);
            result.append(newLine);
        }
        return result.toString();
    }
}
