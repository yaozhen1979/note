package com.airpatent.hello;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;

import com.airpatent.junit.AbstractJUnit4TestCase;
import com.airpatent.model.UserData;
import com.airpatent.service.HelloService;

public class HelloServiceTest extends AbstractJUnit4TestCase {

    @Autowired
    HelloService helloService;
    
    @Test
    @Rollback(true)
    public void testSave() {
        UserData u = helloService.saveUser("97", "Test");
        System.out.println(u);
    }
    
}
