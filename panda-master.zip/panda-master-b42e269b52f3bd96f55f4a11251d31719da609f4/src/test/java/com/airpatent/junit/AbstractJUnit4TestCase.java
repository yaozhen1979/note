package com.airpatent.junit;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

@ContextConfiguration(locations = {
        "classpath:conf/spring/appContext_core.xml",    
        "classpath:conf/spring/appContext_test.xml" })
abstract public class AbstractJUnit4TestCase extends AbstractTransactionalJUnit4SpringContextTests {

    @Test
    public void empty() {
        
    }
}
