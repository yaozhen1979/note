package itec.patent.common.test;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.common.PatentInfoToSolr;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.solr.SolrPatentInfo2;

import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class TestPatentCommon {

    static Log log = LogFactory.getLog(TestPatentCommon.class);

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(TestPatentCommon.class);
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        log.debug("Start");
        MongoInitUtils.reload();
        String pn = "07/209568";
        QueryHelp query = new QueryHelp();
        query.filter("appNumber", pn);
        if (query != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + query);
            Thread.sleep(5000);
        }

        log.debug("counting total documents");
        DBCollection col = PatentInfo2.getCollection(Pto.US);
        DBObject dbobj = col.findOne(query);
                PatentInfo2 mongoInfo = PatentInfo2.fromObject(Pto.US, dbobj);
                String kindcode = mongoInfo.kindcode;    
                SolrPatentInfo2 solrInfo = PatentInfoToSolr
                        .Mongo2Solr(mongoInfo);
        log.info("End");
    }
}
