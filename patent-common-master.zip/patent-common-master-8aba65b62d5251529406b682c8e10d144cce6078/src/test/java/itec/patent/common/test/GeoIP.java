package itec.patent.common.test;

import com.maxmind.geoip.Location;
import com.maxmind.geoip.LookupService;

public class GeoIP {
    static String dbfile = "c:\\GeoIP\\GeoLiteCity.dat";
    static LookupService cl;
    static {
        try {
            cl = new LookupService(dbfile, LookupService.GEOIP_MEMORY_CACHE );
        } catch (Exception e) {
            //todo
        }
    }
    public static void main(String[] args) throws Exception {
        Location loc = cl.getLocation("223.138.86.3");
        try {
            if (loc != null) {
                System.out.println(loc.countryName);
                System.out.println(loc.city);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
