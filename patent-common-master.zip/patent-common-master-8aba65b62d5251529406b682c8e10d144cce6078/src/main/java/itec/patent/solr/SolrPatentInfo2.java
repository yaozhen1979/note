package itec.patent.solr;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.solr.client.solrj.beans.Field;

public class SolrPatentInfo2 {

    @Field
    public String id;

    @Field
    public String pto;

    @Field
    public Date app_date;

    /**
     * extract year of {@link #app_date}
     */
    @Field
    public Integer app_year;

    /**
     * extract year and month of {@link #app_date}
     */
    @Field
    public Integer app_yearmon;

    /**
     * MongoDB certificateDate
     */
    @Field
    public Date certificate_date;

    /**
     * extract year of {@link #certificate_date}
     */
    @Field
    public Integer certificate_year;

    /**
     * extract year and month of {@link #certificate_date}
     */
    @Field
    public Integer certificate_yearmon;

    @Field
    public Date decision_date;

    /**
     * extract year of {@link #decision_date}
     */
    @Field
    public Integer decision_year;

    /**
     * extract year and month of {@link #decision_date}
     */
    @Field
    public Integer decision_yearmon;

    @Field
    public Date exam_date;

    /**
     * extract year of {@link #exam_date}
     */
    @Field
    public Integer exam_year;

    /**
     * extract year and month of {@link #exam_date}
     */
    @Field
    public Integer exam_yearmon;

    @Field
    public Date open_date;

    /**
     * extract year of {@link #open_date}
     */
    @Field
    public Integer open_year;

    /**
     * extract year and month of {@link #open_date}
     */
    @Field
    public Integer open_yearmon;

    @Field
    public String app_number;

    /**
     * extend more possible value of {@link #app_number}
     */
    @Field
    public ArrayList<String> app_numberall = new ArrayList<>();

    @Field
    public String certificate_number;

    /**
     * extend more possible value of {@link #certificate_number}
     */
    @Field
    public ArrayList<String> certificate_numberall = new ArrayList<>();

    @Field
    public String decision_number;

    /**
     * extend more possible value of {@link #decision_number}
     */
    @Field
    public ArrayList<String> decision_numberall = new ArrayList<>();

    @Field
    public String open_number;

    /**
     * extend more possible value of {@link #open_number}
     */
    @Field
    public ArrayList<String> open_numberall = new ArrayList<>();

    @Field
    public ArrayList<String> patent_numberall = new ArrayList<>();

    @Field
    public String mainCPC_pc;

    @Field
    public String mainIPC_pc;

    @Field
    public String mainIPCR_pc;

    @Field
    public String mainLOC_pc;

    @Field
    public String mainUSPC_pc;

    @Field
    public String mainFI_pc;

    @Field
    public String mainFTerm_pc;

    @Field
    public String mainDI_pc;

    @Field
    public String mainDTerm_pc;

    @Field
    public ArrayList<String> cpcs_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> ipcs_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> ipcrs_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> locs_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> uspcs_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> fis_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> fterms_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> dis_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> dterms_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> eclas_pcs = new ArrayList<>();

    @Field
    public ArrayList<String> agents_name = new ArrayList<>();

    @Field
    public ArrayList<String> agents_address  = new ArrayList<>();

    @Field
    public ArrayList<String> agents_country = new ArrayList<>();

    @Field
    public ArrayList<String> agents_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> agents_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators_name = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators_address = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators_country = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> assignees_name = new ArrayList<>();

    @Field
    public ArrayList<String> assignees_address  = new ArrayList<>();

    @Field
    public ArrayList<String> assignees_country = new ArrayList<>();

    @Field
    public ArrayList<String> assignees_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> assignees_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> inventors_name = new ArrayList<>();

    @Field
    public ArrayList<String> inventors_address  = new ArrayList<>();

    @Field
    public ArrayList<String> inventors_country = new ArrayList<>();

    @Field
    public ArrayList<String> inventors_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> inventors_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters_name = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters_address  = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters_country = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves_name = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves_address  = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves_country = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves_facetname = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves_facetNC = new ArrayList<>();

    @Field
    public ArrayList<String> cited_patents_numberall = new ArrayList<>();

    @Field
    public ArrayList<String> other_references = new ArrayList<>();

    @Field
    public ArrayList<String> priority_patents_numberall = new ArrayList<>();
    
    @Field
    public String reissuefrom_number;

    @Field
    public String kindcode;

    @Field
    public String type;

    /**
     * save order by relPatents
     */
    @Field
    public ArrayList<Integer> stats = new ArrayList<>();

    /**
     * save order by relPatents
     */
    @Field
    public ArrayList<String> briefs = new ArrayList<>();

    /**
     * save order by relPatents
     */
    @Field
    public ArrayList<String> claims = new ArrayList<>();

    /**
     * save order by relPatents
     */
    @Field
    public ArrayList<String> descriptions = new ArrayList<>();

    /**
     * save order by relPatents
     */
    @Field
    public ArrayList<String> titles = new ArrayList<>();

    @Field
    public Date do_date;

    @Field
    public ArrayList<String> stat_dates = new ArrayList<>();

    /**
     * extract year of {@link #do_date}
     */
    @Field
    public Integer do_year;

    /**
     * extract year and month of {@link #do_date}
     */
    @Field
    public Integer do_yearmon;

    @Field
    public ArrayList<String> rel_patents = new ArrayList<>();

    @Field
    public Date solrIndexTime = new Date();

    // project usage
    @Field
    public String projid;

    @Field
    public List<String> treeid;

    @Field
    public List<String> nodeid;

    @Field
    public String patentid;

    @Field
    public List<String> tag;

    //record source from pto or patentcloud
    @Field
    public int source;

    @Field
    public List<String> tag_value;

    //check use or not
    @Field
    public String propatid;
    
    //check use or not
    @Field
    public Boolean trash;

    //check use or not
    @Field
    public ArrayList<String> labels = new ArrayList<>();

    //search result list usage
    @Field
    public String original_title_store;

    @Field
    public String original_brief_store;

    @Field
    public ArrayList<String> original_assignees_name_store = new ArrayList<>();

    @Field
    public ArrayList<String> original_inventors_name_store = new ArrayList<>();

    @Field
    public ArrayList<String> original_ipcs_store = new ArrayList<>();

    @Field
    public ArrayList<String> original_locs_store = new ArrayList<>();
}
