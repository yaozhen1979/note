package itec.patent.solr;

import java.util.Date;

import org.apache.solr.client.solrj.beans.Field;

public class PatentWeb {

    @Field
    public String url;

    @Field
    public String pto_sl;

    @Field
    public String page_s;

    @Field
    public String provider_sl;

    @Field
    public Date do_date;

}
