package itec.patent.assignment.us;

import itec.patent.mongodb.AssignmentCountry;
import itec.patent.mongodb.embed.MongoSyncFlag;

import java.util.Date;
import java.util.ArrayList;
import org.apache.solr.client.solrj.beans.Field;
import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
/**
 * @author F3222904
 */
public class AssignmentText extends MongoObjectObjId {

	public MongoSyncFlag mongoSyncFlag;
	
	public String rel_id;
	
	public String path;

	public int update_log;

	public Date doDate;
	// AssignmentRecord
	@Field("reelframeNo")
	public String reelframeNo;
	
	@Field("reelNo")
	public String reelNo;
	
	@Field("frameNo")
	public String frameNo;
	
	@Field("lastUpdate")
	public Date lastUpdate;
	
	@Field("purgeIndicator")
	public String purgeIndicator = "N";
	
	@Field("recordedDate")
	public Date recordedDate;
	
	@Field("pageCount")
	public String pageCount;
	
	@Field("Correspondentname")
	public String Correspondentname;
	
	@Field("Correspondentaddress1")
	public String Correspondentaddress1;
	
	@Field("Correspondentaddress2")
	public String Correspondentaddress2;
	
	@Field("Correspondentaddress3")
	public String Correspondentaddress3;
	
	@Field("Correspondentaddress4")
	public String Correspondentaddress4;
	
	@Field("conveyanceText")
	public String conveyanceText;

	// ArrayList<PatentAssignor>
	@Field("PatentAssignor")
	public ArrayList<String> PatentAssignor;
	
	@Field("assignorName")
	public ArrayList<String> assignorName;
	
	@Field("executionDate")
	public ArrayList<Date> executionDate;
	
	@Field("assignorAddress1")
	public ArrayList<String> assignorAddress1;
	
	@Field("assignorAddress2")
	public ArrayList<String> assignorAddress2;
	
	@Field("dateAcknowledged")
	public ArrayList<Date> dateAcknowledged;

	// ArrayList<PatentAssignee>
	@Field("PatentAssignee")
	public ArrayList<String> PatentAssignee;
	
	@Field("assigneeName")
	public ArrayList<String> assigneeName;
	
	@Field("assigneeAddress1")
	public ArrayList<String> assigneeAddress1;
	
	@Field("assigneeAddress2")
	public ArrayList<String> assigneeAddress2;
	
	@Field("assigneeCity")
	public ArrayList<String> assigneeCity;

	@Field("assigneeState")
	public ArrayList<String> assigneeState;
	
	@Field("assigneeCountry")
	public ArrayList<String> assigneeCountry;
	
	@Field("assigneePostcode")
	public ArrayList<String> assigneePostcode;
	

	// ArrayList<PatentProperty>
	@Field("PatentProperty")
	public ArrayList<String> PatentProperty;
	
	@Field("kind")
	public ArrayList<String> kind;
	
	@Field("applicationDate")
	public ArrayList<Date> appDate;
	
	@Field("applicationNumber")
	public ArrayList<String> appNumber;
	
	@Field("publicationDate")
	public ArrayList<Date> publicationDate;
	
	@Field("publicationNumber")
	public ArrayList<String> publicationNumber;
	
	@Field("publicationKind")
	public ArrayList<String> publicationKind;
	
	@Field("issueDate")
	public ArrayList<Date> issueDate;
	
	@Field("patentNumber")
	public ArrayList<String> patentNumber;
	
	@Field("issueKind")
	public ArrayList<String> issueKind;
	
	@Field("documentCountry")
	private ArrayList<String> documentCountry;
	
	@Field("patentName")
	public ArrayList<String> inventionTitle;
	
	@Field("country")
	private ArrayList<String> country;
		
	public String getReelNo() {
		return reelNo;
	}
	public void setReelNo(String reelNo) {
		this.reelNo = reelNo;
	}
	public String getFrameNo() {
		return frameNo;
	}
	public void setFrameNo(String frameNo) {
		this.frameNo = frameNo;
	}
	public Date getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public String getPurgeIndicator() {
		return purgeIndicator;
	}
	public void setPurgeIndicator(String purgeIndicator) {
		this.purgeIndicator = purgeIndicator;
	}
	public Date getRecordedDate() {
		return recordedDate;
	}
	public void setRecordedDate(Date recordedDate) {
		this.recordedDate = recordedDate;
	}
	public String getPageCount() {
		return pageCount;
	}
	public void setPageCount(String pageCount) {
		this.pageCount = pageCount;
	}
	public String getCorrespondentname() {
		return Correspondentname;
	}
	public void setCorrespondentname(String correspondentname) {
		Correspondentname = correspondentname;
	}
	public String getCorrespondentaddress1() {
		return Correspondentaddress1;
	}
	public void setCorrespondentaddress1(String correspondentaddress1) {
		Correspondentaddress1 = correspondentaddress1;
	}
	public String getCorrespondentaddress2() {
		return Correspondentaddress2;
	}
	public void setCorrespondentaddress2(String correspondentaddress2) {
		Correspondentaddress2 = correspondentaddress2;
	}
	public String getCorrespondentaddress3() {
		return Correspondentaddress3;
	}
	public void setCorrespondentaddress3(String correspondentaddress3) {
		Correspondentaddress3 = correspondentaddress3;
	}
	public String getCorrespondentaddress4() {
		return Correspondentaddress4;
	}
	public void setCorrespondentaddress4(String correspondentaddress4) {
		Correspondentaddress4 = correspondentaddress4;
	}
	public String getConveyanceText() {
		return conveyanceText;
	}
	public void setConveyanceText(String conveyanceText) {
		this.conveyanceText = conveyanceText;
	}
	public ArrayList<String> getPatentAssignor() {
		return PatentAssignor;
	}
	public void setPatentAssignor(ArrayList<String> patentAssignor) {
		PatentAssignor = patentAssignor;
	}
	public ArrayList<String> getAssignorName() {
		return assignorName;
	}
	public void setAssignorName(ArrayList<String> assignorName) {
		this.assignorName = assignorName;
	}
	public ArrayList<Date> getExecutionDate() {
		return executionDate;
	}
	public void setExecutionDate(ArrayList<Date> executionDate) {
		this.executionDate = executionDate;
	}
	public ArrayList<String> getAssignorAddress1() {
		return assignorAddress1;
	}
	public void setAssignorAddress1(ArrayList<String> assignorAddress1) {
		this.assignorAddress1 = assignorAddress1;
	}
	public ArrayList<String> getAssignorAddress2() {
		return assignorAddress2;
	}
	public void setAssignorAddress2(ArrayList<String> assignorAddress2) {
		this.assignorAddress2 = assignorAddress2;
	}
	public ArrayList<Date> getDateAcknowledged() {
		return dateAcknowledged;
	}
	public void setDateAcknowledged(ArrayList<Date> dateAcknowledged) {
		this.dateAcknowledged = dateAcknowledged;
	}
	public ArrayList<String> getPatentAssignee() {
		return PatentAssignee;
	}
	public void setPatentAssignee(ArrayList<String> patentAssignee) {
		PatentAssignee = patentAssignee;
	}
	public ArrayList<String> getAssigneeName() {
		return assigneeName;
	}
	public void setAssigneeName(ArrayList<String> assigneeName) {
		this.assigneeName = assigneeName;
	}
	public ArrayList<String> getAssigneeAddress1() {
		return assigneeAddress1;
	}
	public void setAssigneeAddress1(ArrayList<String> assigneeAddress1) {
		this.assigneeAddress1 = assigneeAddress1;
	}
	public ArrayList<String> getAssigneeAddress2() {
		return assigneeAddress2;
	}
	public void setAssigneeAddress2(ArrayList<String> assigneeAddress2) {
		this.assigneeAddress2 = assigneeAddress2;
	}
	public ArrayList<String> getAssigneeCity() {
		return assigneeCity;
	}
	public void setAssigneeCity(ArrayList<String> assigneeCity) {
		this.assigneeCity = assigneeCity;
	}
	public ArrayList<String> getAssigneeState() {
		return assigneeState;
	}
	public void setAssigneeState(ArrayList<String> assigneeState) {
		this.assigneeState = assigneeState;
	}
	public ArrayList<String> getAssigneeCountry() {
		return assigneeCountry;
	}
	public void setAssigneeCountry(ArrayList<String> assigneeCountry) {
		this.assigneeCountry = assigneeCountry;
	}
	public ArrayList<String> getAssigneePostcode() {
		return assigneePostcode;
	}
	public void setAssigneePostcode(ArrayList<String> assigneePostcode) {
		this.assigneePostcode = assigneePostcode;
	}
	public ArrayList<String> getPatentProperty() {
		return PatentProperty;
	}
	public void setPatentProperty(ArrayList<String> patentProperty) {
		PatentProperty = patentProperty;
	}
	public ArrayList<String> getKind() {
		return kind;
	}
	public void setKind(ArrayList<String> kind) {
		this.kind = kind;
	}
	public ArrayList<Date> getAppDate() {
		return appDate;
	}
	public void setAppDate(ArrayList<Date> appDate) {
		this.appDate = appDate;
	}
	public ArrayList<String> getAppNumber() {
		return appNumber;
	}
	public void setAppNumber(ArrayList<String> appNumber) {
		this.appNumber = appNumber;
	}
	public ArrayList<Date> getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(ArrayList<Date> publicationDate) {
		this.publicationDate = publicationDate;
	}
	public ArrayList<String> getPublicationNumber() {
		return publicationNumber;
	}
	public void setPublicationNumber(ArrayList<String> publicationNumber) {
		this.publicationNumber = publicationNumber;
	}
	public ArrayList<String> getPublicationKind() {
		return publicationKind;
	}
	public void setPublicationKind(ArrayList<String> publicationKind) {
		this.publicationKind = publicationKind;
	}
	public ArrayList<Date> getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(ArrayList<Date> issueDate) {
		this.issueDate = issueDate;
	}
	public ArrayList<String> getPatentNumber() {
		return patentNumber;
	}
	public void setPatentNumber(ArrayList<String> patentNumber) {
		this.patentNumber = patentNumber;
	}
	public ArrayList<String> getIssueKind() {
		return issueKind;
	}
	public void setIssueKind(ArrayList<String> issueKind) {
		this.issueKind = issueKind;
	}
	public ArrayList<String> getDocumentCountry() {
		return documentCountry;
	}
	public void setDocumentCountry(ArrayList<String> documentCountry) {
		this.documentCountry = documentCountry;
	}
	public ArrayList<String> getInventionTitle() {
		return inventionTitle;
	}
	public void setInventionTitle(ArrayList<String> inventionTitle) {
		this.inventionTitle = inventionTitle;
	}
	public ArrayList<String> getCountry() {
		return country;
	}
	public void setCountry(ArrayList<String> country) {
		this.country = country;
	}
	public MongoSyncFlag getMongoSyncFlag() {
		return mongoSyncFlag;
	}
	public void setMongoSyncFlag(MongoSyncFlag mongoSyncFlag) {
		this.mongoSyncFlag = mongoSyncFlag;
	}
	public String getRel_id() {
		return rel_id;
	}
	public void setRel_id(String rel_id) {
		this.rel_id = rel_id;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getUpdate_log() {
		return update_log;
	}
	public void setUpdate_log(int update_log) {
		this.update_log = update_log;
	}
	public Date getDoDate() {
		return doDate;
	}
	public void setDoDate(Date doDate) {
		this.doDate = doDate;
	}
	public String getReelframeNo() {
		return reelframeNo;
	}
	public void setReelframeNo(String reelframeNo) {
		this.reelframeNo = reelframeNo;
	}

	public static Class<? extends AssignmentText> getClass(AssignmentCountry pto) {
		switch (pto) {
		case us:
		
			return itec.patent.assignment.us.AssignmentInfoUSPTO.class;
		default:
			return null;
		}
	}

	public static DBCollection getCollection(AssignmentCountry pto) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		return MappedClass.getMappedClass(clazz).getCol();
	}

	public static <T extends AssignmentText> T newInfo(Class<T> clazz) {
		try {
			return clazz.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			throw new IllegalArgumentException(e.getMessage(), e);
		}
	}

	public static AssignmentText newInfo(AssignmentCountry pto) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		AssignmentText ret = newInfo(clazz);
		return ret;
	}

	public static AssignmentText findOne(AssignmentCountry pto, ObjectId id) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		return findOne(clazz, id);
	}

	public static AssignmentText findOne(AssignmentCountry pto, String id) {
		return findOne(pto, new ObjectId(id));
	}

	public static AssignmentText findOne(AssignmentCountry pto, ObjectId id, DBObject fields) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		return findOne(clazz, id, fields);
	}

	public static AssignmentText findOne(AssignmentCountry pto, String id, DBObject fields) {
		return findOne(pto, new ObjectId(id), fields);
	}

	public static AssignmentText findOne(AssignmentCountry pto, ObjectId id, String... fields) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		return findOne(clazz, id, fields);
	}

	public static AssignmentText findOne(AssignmentCountry pto, String id, String... fields) {
		return findOne(pto, new ObjectId(id), fields);
	}

	public static AssignmentText findPN(AssignmentCountry pto, String patentNumber) {
		
		Class<? extends AssignmentText> clazz = getClass(pto);
		BasicDBObject query = new BasicDBObject("patentNumber", patentNumber);
		return findOne(clazz, query);
	}

	public static AssignmentText findPN(AssignmentCountry pto, String patentNumber, int stat) {
	
		Class<? extends AssignmentText> clazz = getClass(pto);
		BasicDBObject query = new BasicDBObject("patentNumber", patentNumber);
		query.put("stat", stat);
		return findOne(clazz, query);
	}

	public static AssignmentText fromObject(AssignmentCountry pto, Object obj) {
		Class<? extends AssignmentText> clazz = getClass(pto);
		return fromObject(clazz, obj);
	}

}
