package itec.patent.assignment.us;

public class AssignmentInfoUSPTO extends AssignmentText {
}
