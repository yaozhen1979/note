package itec.patent.assignment.us;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class PatentAssignor extends MongoObject{
    
    private String patentAssignorJson;
    private String assignorName;
    private Date executionDate;
    private String assignorAddress1;
    private String assignorAddress2;
    private Date dateAcknowledged;
    
    public String getAssignorName() {
        return assignorName;
    }
    public void setAssignorName(String assignorName) {
        this.assignorName = assignorName;
    }
    public Date getExecutionDate() {
        return executionDate;
    }
    public void setExecutionDate(Date executionDate) {
        this.executionDate = executionDate;
    }
    public String getAssignorAddress1() {
        return assignorAddress1;
    }
    public void setAssignorAddress1(String assignorAddress1) {
        this.assignorAddress1 = assignorAddress1;
    }
    public String getAssignorAddress2() {
        return assignorAddress2;
    }
    public void setAssignorAddress2(String assignorAddress2) {
        this.assignorAddress2 = assignorAddress2;
    }
    public Date getDateAcknowledged() {
        return dateAcknowledged;
    }
    public void setDateAcknowledged(Date dateAcknowledged) {
        this.dateAcknowledged = dateAcknowledged;
    }
    public String getPatentAssignorJson() {
        return patentAssignorJson;
    }
    public void setPatentAssignorJson(String patentAssignorJson) {
        this.patentAssignorJson = patentAssignorJson;
    }
}
