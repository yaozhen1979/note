package itec.patent.assignment.us;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class AssignmentRecord extends MongoObject{
    private String reelNo;
    private String frameNo;
    private Date lastUpdate;
    private String purgeIndicator="N";
    private Date recordedDate;
    private String pageCount;
    private Correspondent correspondent;
    private String conveyanceText;
    
    public String getReelNo() {
        return reelNo;
    }
    public void setReelNo(String reelNo) {
        this.reelNo = reelNo;
    }
    public String getFrameNo() {
        return frameNo;
    }
    public void setFrameNo(String frameNo) {
        this.frameNo = frameNo;
    }
    public Date getLastUpdate() {
        return lastUpdate;
    }
    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    public String getPurgeIndicator() {
        return purgeIndicator;
    }
    public void setPurgeIndicator(String purgeIndicator) {
        this.purgeIndicator = purgeIndicator;
    }
    public Date getRecordedDate() {
        return recordedDate;
    }
    public void setRecordedDate(Date recordedDate) {
        this.recordedDate = recordedDate;
    }
    public String getPageCount() {
        return pageCount;
    }
    public void setPageCount(String pageCount) {
        this.pageCount = pageCount;
    }
    public Correspondent getCorrespondent() {
        return correspondent;
    }
    public void setCorrespondent(Correspondent correspondent) {
        this.correspondent = correspondent;
    }
    public String getConveyanceText() {
        return conveyanceText;
    }
    public void setConveyanceText(String conveyanceText) {
        this.conveyanceText = conveyanceText;
    }
    
}
