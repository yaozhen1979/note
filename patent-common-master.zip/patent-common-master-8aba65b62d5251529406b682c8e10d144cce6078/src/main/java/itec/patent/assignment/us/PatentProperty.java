package itec.patent.assignment.us;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;
public class PatentProperty extends MongoObject{
    private String patentPropertyJson;
    private String kind;
    private Date appDate;
    private String appNumber;
    private Date openDate;
    private String openNumber;
    private String openKind;
    private Date decisionDate;
    private String decisionNumber;
    private String decisionKind;
    private String documentCountry;
    private String inventionTitle;
    private String country="US";
    
    

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getInventionTitle() {
        return inventionTitle;
    }

    public void setInventionTitle(String inventionTitle) {
        this.inventionTitle = inventionTitle;
    }

    public Date getAppDate() {
        return appDate;
    }

    public void setAppDate(Date appDate) {
        this.appDate = appDate;
    }

    public String getAppNumber() {
        return appNumber;
    }

    public void setAppNumber(String appNumber) {
        this.appNumber = appNumber;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public String getOpenNumber() {
        return openNumber;
    }

    public void setOpenNumber(String openNumber) {
        this.openNumber = openNumber;
    }

    public Date getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(Date decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getDecisionNumber() {
        return decisionNumber;
    }

    public void setDecisionNumber(String decisionNumber) {
        this.decisionNumber = decisionNumber;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getDocumentCountry() {
        return documentCountry;
    }

    public void setDocumentCountry(String documentCountry) {
        this.documentCountry = documentCountry;
    }

    public String getOpenKind() {
        return openKind;
    }

    public void setOpenKind(String openKind) {
        this.openKind = openKind;
    }

    public String getDecisionKind() {
        return decisionKind;
    }

    public void setDecisionKind(String decisionKind) {
        this.decisionKind = decisionKind;
    }

    public String getPatentPropertyJson() {
        return patentPropertyJson;
    }

    public void setPatentPropertyJson(String patentPropertyJson) {
        this.patentPropertyJson = patentPropertyJson;
    }

    
}
