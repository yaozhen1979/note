package itec.patent.assignment.us;

import org.tsaikd.java.mongodb.MongoObject;

public class PatentAssignee extends MongoObject{
    private String patentAssigneeJson;
    private String assigneeName;
    private String assigneeAddress1;
    private String assigneeAddress2;
    private String assigneeCity;
    private String assigneeState;
    private String assigneeCountry;
    private String assigneePostcode;
    
    public String getAssigneeName() {
        return assigneeName;
    }
    public void setAssigneeName(String assigneeName) {
        this.assigneeName = assigneeName;
    }
    public String getAssigneeAddress1() {
        return assigneeAddress1;
    }
    public void setAssigneeAddress1(String assigneeAddress1) {
        this.assigneeAddress1 = assigneeAddress1;
    }
    public String getAssigneeAddress2() {
        return assigneeAddress2;
    }
    public void setAssigneeAddress2(String assigneeAddress2) {
        this.assigneeAddress2 = assigneeAddress2;
    }
    public String getAssigneeCity() {
        return assigneeCity;
    }
    public void setAssigneeCity(String assigneeCity) {
        this.assigneeCity = assigneeCity;
    }
    public String getAssigneeState() {
        return assigneeState;
    }
    public void setAssigneeState(String assigneeState) {
        this.assigneeState = assigneeState;
    }
    public String getAssigneeCountry() {
        return assigneeCountry;
    }
    public void setAssigneeCountry(String assigneeCountry) {
        this.assigneeCountry = assigneeCountry;
    }
    public String getAssigneePostcode() {
        return assigneePostcode;
    }
    public void setAssigneePostcode(String assigneePostcode) {
        this.assigneePostcode = assigneePostcode;
    }
    public String getPatentAssigneeJson() {
        return patentAssigneeJson;
    }
    public void setPatentAssigneeJson(String patentAssigneeJson) {
        this.patentAssigneeJson = patentAssigneeJson;
    }
    
    
    
}
