package itec.patent.assignment.us;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class DocumentID extends MongoObject{
    private String documentCountry;
    private String documentNumber;
    private String kind;
    private Date documentDate;
    private String documentDateString;
    private Date appDate;
    private String appDateString;
    private String appNumber;
    private String opedKind;
    private Date openDate;
    private String openDateString;
    private String openNumber;
    private String decisionKind;
    private Date decisionDate;
    private String decisionDateString;
    private String decisionNumber;
    
    public String getDocumentCountry() {
        return documentCountry;
    }
    public void setDocumentCountry(String documentCountry) {
        this.documentCountry = documentCountry;
    }
    public String getDocumentNumber() {
        return documentNumber;
    }
    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }
    public String getKind() {
        return kind;
    }
    public void setKind(String kind) {
        this.kind = kind;
    }
    public Date getDocumentDate() {
        return documentDate;
    }
    public void setDocumentDate(Date documentDate) {
        this.documentDate = documentDate;
    }
    public Date getAppDate() {
        return appDate;
    }
    public void setAppDate(Date appDate) {
        this.appDate = appDate;
    }
    public String getAppNumber() {
        return appNumber;
    }
    public void setAppNumber(String appNumber) {
        this.appNumber = appNumber;
    }
    public Date getOpenDate() {
        return openDate;
    }
    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }
    public String getOpenNumber() {
        return openNumber;
    }
    public void setOpenNumber(String openNumber) {
        this.openNumber = openNumber;
    }
    public Date getDecisionDate() {
        return decisionDate;
    }
    public void setDecisionDate(Date decisionDate) {
        this.decisionDate = decisionDate;
    }
    public String getDecisionNumber() {
        return decisionNumber;
    }
    public void setDecisionNumber(String decisionNumber) {
        this.decisionNumber = decisionNumber;
    }
    public String getOpedKind() {
        return opedKind;
    }
    public void setOpedKind(String opedKind) {
        this.opedKind = opedKind;
    }
    public String getDecisionKind() {
        return decisionKind;
    }
    public void setDecisionKind(String decisionKind) {
        this.decisionKind = decisionKind;
    }
    public String getDocumentDateString() {
        return documentDateString;
    }
    public void setDocumentDateString(String documentDateString) {
        this.documentDateString = documentDateString;
    }
    public String getAppDateString() {
        return appDateString;
    }
    public void setAppDateString(String appDateString) {
        this.appDateString = appDateString;
    }
    public String getOpenDateString() {
        return openDateString;
    }
    public void setOpenDateString(String openDateString) {
        this.openDateString = openDateString;
    }
    public String getDecisionDateString() {
        return decisionDateString;
    }
    public void setDecisionDateString(String decisionDateString) {
        this.decisionDateString = decisionDateString;
    }
    
    
    
    
    
}
