package itec.patent.assignment.us;

public class PatentAssigneeMentData {/*
    private AssignmentRecord assignmentRecord;
    private List<PatentAssignor> patentAssignor;   //轉讓人
    private List<PatentAssignee> patentAssignee; //專利權人
    private List<PatentProperty> PatentProperties;
    
    public AssignmentRecord getAssignmentRecord() {
        return assignmentRecord;
    }
    public void setAssignmentRecord(AssignmentRecord assignmentRecord) {
        this.assignmentRecord = assignmentRecord;
    }
    public List<PatentAssignor> getPatentAssignor() {
        return patentAssignor;
    }
    public void setPatentAssignor(List<PatentAssignor> patentAssignor) {
        this.patentAssignor = patentAssignor;
    }
    public List<PatentAssignee> getPatentAssignee() {
        return patentAssignee;
    }
    public void setPatentAssignee(List<PatentAssignee> patentAssignee) {
        this.patentAssignee = patentAssignee;
    }
    public List<PatentProperty> getPatentProperties() {
        return PatentProperties;
    }
    public void setPatentProperties(List<PatentProperty> patentProperties) {
        PatentProperties = patentProperties;
    }
*/}
