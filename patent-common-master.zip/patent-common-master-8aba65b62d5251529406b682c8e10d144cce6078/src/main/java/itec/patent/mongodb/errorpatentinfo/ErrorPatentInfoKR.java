package itec.patent.mongodb.errorpatentinfo;

import itec.patent.mongodb.ErrorPatentInfo;

public class ErrorPatentInfoKR extends ErrorPatentInfo {

}
