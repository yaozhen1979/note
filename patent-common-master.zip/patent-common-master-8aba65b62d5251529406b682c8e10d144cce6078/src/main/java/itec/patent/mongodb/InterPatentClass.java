package itec.patent.mongodb;

import itec.patent.mongodb.base.BasePatentClass;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoException;

public class InterPatentClass extends BasePatentClass {

    private static Class<InterPatentClass> clazz = InterPatentClass.class;

    public static InterPatentClass findOne(String str) {
        return findOne(clazz, new BasicDBObject("_id", str));
    }

    public static InterPatentClass getAddNormalize(String str) throws MongoException {
        str = normalize(str).get(0);
        InterPatentClass data = findOne(str);
        if (data == null) {
            data = new InterPatentClass();
            data.name = str;
            data.save();
        }
        return data;
    }

    private static Pattern pcPattern = Pattern.compile("^(\\S)(\\S\\S)(\\S)[\\s\\-]*(\\d+)[/:](\\d+)([\\s.](\\d+))?$");
    public static List<String> normalize(String pc) {
        List<String> ret = new ArrayList<String>();
        if (pc == null) {
            ret.add(null);
            return ret;
        }

        pc = pc.trim();
        Matcher matcher = pcPattern.matcher(pc);
        if (matcher.find()) {
            String a = matcher.group(1);
            String b = matcher.group(2);
            String c = matcher.group(3);
            String d = matcher.group(4);
            d = d.replaceAll("^0+", "");
            if (d.isEmpty()) {
                d = "0";
            }
            String e = matcher.group(5);
            while (e.length() < 2) {
                e = "0" + e;
            }
            String g = matcher.group(7);
            if (g != null && !g.isEmpty()) {
                e += "." + g;
            }
            pc = a + b + c + " " + d + "/" + e;
            ret.add(pc);
            ret.add(a);
            ret.add(b);
            ret.add(c);
            ret.add(d);
            ret.add(e);
        } else {
            ret.add(pc);
        }
        return ret;
    }

}
