package itec.patent.mongodb.patentinfo2;

import itec.patent.mongodb.PatentInfo2;

public class PatentInfoEPO extends PatentInfo2 {
}
