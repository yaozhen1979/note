package itec.patent.mongodb;

import itec.patent.mongodb.embed.MongoSyncFlag;

import java.util.Date;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoException;

public class AssignmentRaw extends MongoObjectObjId {

    public AssignmentCountry country;

    public String path;

    public BasicDBObject data;

    public String type;

    public int size ;
    
    public String provider;
    
    public static Class<? extends AssignmentRaw> getClass(AssignmentCountry country) {
        switch (country) {
        case us:
            return itec.patent.mongodb.assignmentraw.AssignmentRawUSPTO.class;
        default:
            return null;
        }
    }

    public static DBCollection getCollection(AssignmentCountry country) throws MongoException {
        Class<? extends AssignmentRaw> clazz = getClass(country);
        return MappedClass.getMappedClass(clazz).getCol();
    }

    public static <T extends AssignmentRaw> T newInfo(Class<T> clazz) {
        try {
            return clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public static AssignmentRaw newInfo(AssignmentCountry country) {
        Class<? extends AssignmentRaw> clazz = getClass(country);
        AssignmentRaw ret = newInfo(clazz);
        ret.country = country;
        return ret;
    }

    public static AssignmentRaw fromObject(AssignmentCountry country, Object obj) throws MongoException {
        Class<? extends AssignmentRaw> clazz = getClass(country);
        return fromObject(clazz, obj);
    }

}
