package itec.patent.mongodb.patentraw;

import itec.patent.mongodb.PatentRaw;

public class PatentRawWIPO extends PatentRaw {
}
