package itec.patent.mongodb.embed;

import org.tsaikd.java.mongodb.MongoObject;

public class Person extends MongoObject {

    public MultiLangString name;

    public MultiLangString country;

    public MultiLangString address;

}
