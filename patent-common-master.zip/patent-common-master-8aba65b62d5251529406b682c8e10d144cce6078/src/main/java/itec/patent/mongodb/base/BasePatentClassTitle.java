package itec.patent.mongodb.base;

import itec.patent.mongodb.embed.MultiLangString;

import java.util.HashMap;

import org.tsaikd.java.mongodb.MongoObject;

public class BasePatentClassTitle extends MongoObject {

    protected static Class<?> clazz = BasePatentClassTitle.class;

    public MultiLangString text;

    public MultiLangString ref;

    public HashMap<String, String> reflinks;

}
