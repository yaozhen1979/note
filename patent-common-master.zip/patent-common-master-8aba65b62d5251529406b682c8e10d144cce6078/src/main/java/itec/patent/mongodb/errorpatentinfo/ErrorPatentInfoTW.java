package itec.patent.mongodb.errorpatentinfo;

import itec.patent.mongodb.ErrorPatentInfo;

public class ErrorPatentInfoTW extends ErrorPatentInfo {

}
