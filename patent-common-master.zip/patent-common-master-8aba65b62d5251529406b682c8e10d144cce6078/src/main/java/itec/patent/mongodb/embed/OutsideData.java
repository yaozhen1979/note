package itec.patent.mongodb.embed;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class OutsideData extends MongoObject {

    public String type;

    public String data;

    public Date updateTime;

}
