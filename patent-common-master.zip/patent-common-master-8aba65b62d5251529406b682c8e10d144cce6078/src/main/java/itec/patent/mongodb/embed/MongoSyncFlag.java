package itec.patent.mongodb.embed;

import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class MongoSyncFlag extends MongoObject {

    public Date init;

    public Date last;
    
    public Date update;

}
