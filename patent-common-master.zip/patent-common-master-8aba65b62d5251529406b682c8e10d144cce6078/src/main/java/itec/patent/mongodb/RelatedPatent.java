package itec.patent.mongodb;

import itec.patent.mongodb.embed.Person;

import java.util.ArrayList;
import java.util.Date;

import org.tsaikd.java.mongodb.MongoObjectObjId;

public class RelatedPatent extends MongoObjectObjId {
    public String pto;
    public String appNumber;
    public String patentNumber;
    public String decsisionNumber;
    public String openNumber;
    public String doNumber;
    public String kindcode;
    public Integer stat;
    public Date appDate;
    public Date decisionDate;
    public Date openDate;
    public Date doDate;
    public String relation;
    public ArrayList<Person> inventors = new ArrayList<>();
}
