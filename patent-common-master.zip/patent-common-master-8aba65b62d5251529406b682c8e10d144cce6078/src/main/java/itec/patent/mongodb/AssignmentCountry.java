package itec.patent.mongodb;

public enum AssignmentCountry {
    us
}
