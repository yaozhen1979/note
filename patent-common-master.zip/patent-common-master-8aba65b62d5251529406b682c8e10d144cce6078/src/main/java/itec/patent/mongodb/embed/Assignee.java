package itec.patent.mongodb.embed;

import org.tsaikd.java.mongodb.MongoObject;

public class Assignee extends MongoObject {

    public String name;
    public String address1;
    public String address2;
    public String city;
    public String state;
    public String countryname;
    public String postcode;

}
