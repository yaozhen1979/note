package itec.patent.mongodb.base;

import itec.patent.mongodb.embed.MultiLangString;

import java.util.ArrayList;
import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;
import org.tsaikd.java.mongodb.annotations.Id;
import org.tsaikd.java.mongodb.annotations.Reference;

import com.mongodb.BasicDBObject;

public class BasePatentClass extends MongoObject {

    public static <T extends BasePatentClass> T findOne(Class<T> clazz, String id) {
        return findOne(clazz, new BasicDBObject("_id", id));
    }

    @Id
    public String name;

    @Deprecated
    public MultiLangString text;

    public ArrayList<BasePatentClassTitle> titles = new ArrayList<BasePatentClassTitle>();

    public Integer level;

    @Reference
    public BasePatentClass parent;

    public Date updateTime = new Date();

    @Override
    public String toString() {
        return name;
    }

}
