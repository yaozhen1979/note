package itec.patent.mongodb.assignmentraw;

import itec.patent.mongodb.AssignmentRaw;

public class AssignmentRawUSPTO extends AssignmentRaw {
}
