package itec.patent.mongodb.errorpatentinfo;

import itec.patent.mongodb.ErrorPatentInfo;

public class ErrorPatentInfoJP extends ErrorPatentInfo {

}
