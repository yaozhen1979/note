package itec.patent.mongodb;

import java.util.Date;

import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;

import com.mongodb.DBCollection;
import com.mongodb.MongoException;

public class ErrorPatentInfo extends MongoObjectObjId {

    public class Message extends MongoObjectObjId {
        public String msg;
    }

    public class Doc extends MongoObjectObjId {
        public ObjectId _id;
        public Pto pto;
        public String kindcode;
        public int stat;
        public Date appDate;
        public Date doDate;
        public String patentNumber;
    }

    public Date doDate;
    public Message msg;
    public Doc doc;
    
    public static Class<? extends ErrorPatentInfo> getClass(Pto pto) {
        switch (pto) {
        case US:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoUS.class;
        case TW:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoTW.class;
        case CN:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoCN.class;
        case JP:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoJP.class;
        case KR:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoKR.class;
        case WO:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoWO.class;
        case EP:
            return itec.patent.mongodb.errorpatentinfo.ErrorPatentInfoTW.class;
        default:
            return null;
        }
    }

    public static DBCollection getCollection(Pto pto) throws MongoException {
        Class<? extends ErrorPatentInfo> clazz = getClass(pto);
        return MappedClass.getMappedClass(clazz).getCol();
    }

    public static <T extends ErrorPatentInfo> T newInfo(Class<T> clazz) {
        try {
            return clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public static ErrorPatentInfo newInfo(Pto pto) {
        Class<? extends ErrorPatentInfo> clazz = getClass(pto);
        ErrorPatentInfo ret = newInfo(clazz);
        return ret;
    }

    public static ErrorPatentInfo fromObject(Pto pto, Object obj) throws MongoException {
        Class<? extends ErrorPatentInfo> clazz = getClass(pto);
        return fromObject(clazz, obj);
    }
}
