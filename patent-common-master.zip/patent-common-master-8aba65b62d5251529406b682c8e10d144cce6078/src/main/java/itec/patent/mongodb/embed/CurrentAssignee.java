package itec.patent.mongodb.embed;

import java.util.ArrayList;
import java.util.Date;

import org.tsaikd.java.mongodb.MongoObject;

public class CurrentAssignee extends MongoObject {

    public ArrayList<Assignee> assignees = new ArrayList<>();
    
    public ArrayList<Assignee> editAssignees = new ArrayList<>();
    
    public Integer status;

    public Integer version;

    public Date update;
    
    public Date last;

}
