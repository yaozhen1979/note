package itec.patent.mongodb;

import itec.patent.mongodb.base.BasePatentClass;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mongodb.BasicDBObject;

public class USPatentClass extends BasePatentClass {

    private static Class<USPatentClass> clazz = USPatentClass.class;

    public static USPatentClass findOne(String str) {
        return findOne(clazz, new BasicDBObject("_id", str));
    }

    public static USPatentClass getAddNormalize(String str) {
        str = normalize(str).get(0);
        USPatentClass data = findOne(str);
        if (data == null) {
            data = new USPatentClass();
            data.name = str;
            data.save();
        }
        return data;
    }

    private static Pattern pcPattern = Pattern.compile("^(\\S{1,3})(/(\\S{1,3})(\\.(\\S{1,3}))?)?$");
    public static List<String> normalize(String pc) {
        List<String> ret = new ArrayList<String>();
        if (pc == null) {
            ret.add(null);
            return ret;
        }

        pc = pc.trim();
        Matcher matcher = pcPattern.matcher(pc);
        if (matcher.find()) {
            String a = matcher.group(1);
            String b = matcher.group(3);
            String c = matcher.group(5);
            ret.add(pc);
            ret.add(a);
            ret.add(b);
            ret.add(c);
        } else {
            ret.add(pc);
        }
        return ret;
    }

}
