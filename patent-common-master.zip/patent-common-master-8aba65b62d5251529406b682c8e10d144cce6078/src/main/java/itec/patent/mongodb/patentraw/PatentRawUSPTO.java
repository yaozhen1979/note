package itec.patent.mongodb.patentraw;

import itec.patent.mongodb.PatentRaw;

public class PatentRawUSPTO extends PatentRaw {
}
