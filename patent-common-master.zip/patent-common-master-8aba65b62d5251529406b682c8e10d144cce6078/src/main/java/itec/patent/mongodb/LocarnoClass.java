package itec.patent.mongodb;

import itec.patent.mongodb.base.BasePatentClass;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mongodb.BasicDBObject;

public class LocarnoClass extends BasePatentClass {

    private static Class<LocarnoClass> clazz = LocarnoClass.class;

    public static LocarnoClass findOne(String str) {
        return findOne(clazz, new BasicDBObject("_id", str));
    }

    public static LocarnoClass getAddNormalize(String str) {
        str = normalize(str).get(0);
        LocarnoClass data = findOne(str);
        if (data == null) {
            data = new LocarnoClass();
            data.name = str;
            data.save();
        }
        return data;
    }

    private static Pattern strPattern = Pattern.compile("^(\\d\\d)-?(\\d\\d)?$");
    public static List<String> normalize(String str) {
        List<String> ret = new ArrayList<String>();
        if (str == null) {
            return null;
        }

        str = str.trim();
        Matcher matcher = strPattern.matcher(str);
        if (matcher.find()) {
            String a = matcher.group(1);
            String b = matcher.group(2);
            if (b == null || b.isEmpty()) {
                ret.add(a);
                ret.add(a);
            } else {
                ret.add(a + "-" + b);
                ret.add(a);
                ret.add(b);
            }
        } else {
            ret.add(str);
        }
        return ret;
    }

}
