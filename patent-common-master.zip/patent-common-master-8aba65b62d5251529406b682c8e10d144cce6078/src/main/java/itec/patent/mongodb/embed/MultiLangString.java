package itec.patent.mongodb.embed;

import java.lang.reflect.Field;

import org.tsaikd.java.mongodb.MongoObject;

public class MultiLangString extends MongoObject {

    protected static Class<?> clazz = MultiLangString.class;

    protected static String languages[] = {
        "origin", "en", "zhTW", "zhCN", "jp", "kr", "fr", "de", "ru", "es", "pt", "ar"
    };

    public String origin;

    public String en;

    public String zhTW;

    public String zhCN;

    public String jp;

    public String kr;

    public String fr;

    public String de;

    public String ru;

    public String es;

    public String pt;

    public String ar;

    public interface LangFilter {
        public String filter(String lang, String value, MultiLangString context);
    }

    public MultiLangString filter(LangFilter langFilter) {
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!isEmpty(value)) {
                    field.set(this, langFilter.filter(lang, value, this));
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return this;
    }

    @Override
    public boolean isEmpty() {
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!isEmpty(value)) {
                    return false;
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return true;
    }

    @Override
    public String toString() {
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!isEmpty(value)) {
                    return value;
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return "";
    }

    public static MultiLangString getSet(MultiLangString old) {
        MultiLangString ret;
        if (old != null) {
            ret = old;
        } else {
            ret = new MultiLangString();
        }
        return ret;
    }

    protected static boolean isEmpty(String str) {
        return (str == null || str.isEmpty());
    }

}
