package itec.patent.mongodb;

import java.util.Date;

import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoException;

public class PatentRaw extends MongoObjectObjId {

    public Pto pto;

    public String path;

    public BasicDBObject data;

    public String type;

    public String provider;

    public Date doDate;

    public boolean truncate;
    
    public BasicDBObject dataJson;
    
    public String patentNumber;

    public static Class<? extends PatentRaw> getClass(Pto pto) {
        switch (pto) {
        case USPTO:
            return itec.patent.mongodb.patentraw.PatentRawUSPTO.class;
        case TIPO:
            return itec.patent.mongodb.patentraw.PatentRawTIPO.class;
        case CNIPR:
            return itec.patent.mongodb.patentraw.PatentRawCNIPR.class;
        case JPO:
            return itec.patent.mongodb.patentraw.PatentRawJPO.class;
        case KIPO:
            return itec.patent.mongodb.patentraw.PatentRawKIPO.class;
        case WIPO:
            return itec.patent.mongodb.patentraw.PatentRawWIPO.class;
        case EPO:
            return itec.patent.mongodb.patentraw.PatentRawEPO.class;
        case DPMA:
            return itec.patent.mongodb.patentraw.PatentRawDPMA.class;
        case INPI:
            return itec.patent.mongodb.patentraw.PatentRawINPI.class;
        case UKIPO:
            return itec.patent.mongodb.patentraw.PatentRawUKIPO.class;
        case IGE:
            return itec.patent.mongodb.patentraw.PatentRawIGE.class;
        default:
            return null;
        }
    }

    public static DBCollection getCollection(Pto pto) throws MongoException {
        Class<? extends PatentRaw> clazz = getClass(pto);
        return MappedClass.getMappedClass(clazz).getCol();
    }

    public static <T extends PatentRaw> T newInfo(Class<T> clazz) {
        try {
            return clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public static PatentRaw newInfo(Pto pto) {
        Class<? extends PatentRaw> clazz = getClass(pto);
        PatentRaw ret = newInfo(clazz);
        ret.pto = pto;
        return ret;
    }

    public static PatentRaw fromObject(Pto pto, Object obj) throws MongoException {
        Class<? extends PatentRaw> clazz = getClass(pto);
        return fromObject(clazz, obj);
    }

}
