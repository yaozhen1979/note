package itec.patent.mongodb;

import itec.patent.mongodb.embed.CurrentAssignee;
import itec.patent.mongodb.embed.MongoSyncFlag;
import itec.patent.mongodb.embed.MultiLangString;
import itec.patent.mongodb.embed.OutsideData;
import itec.patent.mongodb.embed.Person;

import java.util.ArrayList;
import java.util.Date;

import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

public class PatentInfo2 extends MongoObjectObjId {

    public static class PtoPid {

        public Pto pto;

        public ObjectId id;

        @Override
        public String toString() {
            return pto.toString() + "." + id.toString();
        }

    }

    public Pto pto;

    // date info
    public Date appDate;

    public Date certificateDate;

    public Date decisionDate;

    public Date examDate;

    public Date openDate;

    public Date pctAppDate;

    public Date pctOpenDate;

    // number info
    public String appNumber;

    public String certificateNumber;

    public String decisionNumber;

    public String openNumber;

    public String patentNumber;

    public String pctAppNumber;

    public String pctOpenNumber;

    // patent class
    public String mainCPC;

    public String mainIPC;

    public String mainIPCR;

    public String mainLOC;

    public String mainUSPC;

    public String mainFI;

    public String mainFTerm;

    public String mainDI;

    public String mainDTerm;

    public ArrayList<String> cpcs = new ArrayList<>();

    public ArrayList<String> ipcs = new ArrayList<>();

    public ArrayList<String> ipcrs = new ArrayList<>();

    public ArrayList<String> locs = new ArrayList<>();

    public ArrayList<String> uspcs = new ArrayList<>();

    public ArrayList<String> fis = new ArrayList<>();

    public ArrayList<String> fterms = new ArrayList<>();

    public ArrayList<String> dis = new ArrayList<>();

    public ArrayList<String> dterms = new ArrayList<>();

    public ArrayList<String> eclas = new ArrayList<>();
    
    // person info
    public ArrayList<Person> agents = new ArrayList<>();

    public ArrayList<Person> agentOperators = new ArrayList<>();

    public ArrayList<Person> assignees = new ArrayList<>();

    public ArrayList<Person> inventors = new ArrayList<>();

    public ArrayList<Person> examinerMasters = new ArrayList<>();

    public ArrayList<Person> examinerSlaves = new ArrayList<>();

    // PDF file page
    public Integer filePageClaim;

    public Integer filePageDesc;

    public Integer filePageFig;

    public Integer filePageFirst;

    public Integer filePageNumber;

    public Integer gazettePageNumber;
    
    public Integer clipPageNumber;
    
    public Integer figurePageNumber;
    
    public boolean firstImagePageFlag = false;
    
    // citation
    public ArrayList<RelatedPatent> citedPatents = new ArrayList<>();

    public ArrayList<String> otherReferences = new ArrayList<String>();

    // priority
    public ArrayList<RelatedPatent> priorityPatents = new ArrayList<>();

    // related
    public ArrayList<RelatedPatent> relatedPatents = new ArrayList<>();

    // division
    public RelatedPatent dividedPatent;

    // document status latest
    public String kindcode;

    public String type;

    public Integer stat;

    // multiple language latest
    public MultiLangString brief;

    public MultiLangString claim;

    public MultiLangString description;

    public MultiLangString title;

    // outside cache data
    public OutsideData family;

    public OutsideData strength;

    // extend variables
    public Date doDate;

    public boolean truncate;

    public ArrayList<RelatedPatent> relPatents = new ArrayList<>();

    public MongoSyncFlag mongoSyncFlag;
    
    public CurrentAssignee currentAssignee;

    public static Class<? extends PatentInfo2> getClass(Pto pto) {
        switch (pto) {
        case USPTO:
            return itec.patent.mongodb.patentinfo2.PatentInfoUSPTO.class;
        case US:
            return itec.patent.mongodb.patentinfo2.PatentInfoUS.class;
        case TIPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoTIPO.class;
        case TW:
            return itec.patent.mongodb.patentinfo2.PatentInfoTW.class;
        case CNIPR:
            return itec.patent.mongodb.patentinfo2.PatentInfoCNIPR.class;
        case CN:
            return itec.patent.mongodb.patentinfo2.PatentInfoCN.class;
        case JPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoJPO.class;
        case JP:
            return itec.patent.mongodb.patentinfo2.PatentInfoJP.class;
        case KIPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoKIPO.class;
        case KR:
            return itec.patent.mongodb.patentinfo2.PatentInfoKR.class;
        case WIPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoWIPO.class;
        case WO:
            return itec.patent.mongodb.patentinfo2.PatentInfoWO.class;
        case EPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoEPO.class;
        case EP:
            return itec.patent.mongodb.patentinfo2.PatentInfoEP.class;
        case DPMA:
            return itec.patent.mongodb.patentinfo2.PatentInfoDPMA.class;
        case DE:
            return itec.patent.mongodb.patentinfo2.PatentInfoDE.class;
        case INPI:
            return itec.patent.mongodb.patentinfo2.PatentInfoINPI.class;
        case FR:
            return itec.patent.mongodb.patentinfo2.PatentInfoFR.class;
        case UKIPO:
            return itec.patent.mongodb.patentinfo2.PatentInfoUKIPO.class;
        case GB:
            return itec.patent.mongodb.patentinfo2.PatentInfoGB.class;
        case IGE:
            return itec.patent.mongodb.patentinfo2.PatentInfoIGE.class;
        case CH:
            return itec.patent.mongodb.patentinfo2.PatentInfoCH.class;
        default:
            return null;
        }
    }

    public static DBCollection getCollection(Pto pto) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        return MappedClass.getMappedClass(clazz).getCol();
    }

    public static <T extends PatentInfo2> T newInfo(Class<T> clazz) {
        try {
            return clazz.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    public static PatentInfo2 newInfo(Pto pto) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        PatentInfo2 ret = newInfo(clazz);
        ret.pto = pto;
        return ret;
    }

    public static PatentInfo2 findOne(Pto pto, ObjectId id) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        return findOne(clazz, id);
    }

    public static PatentInfo2 findOne(Pto pto, String id) {
        return findOne(pto, new ObjectId(id));
    }

    public static PatentInfo2 findOne(Pto pto, ObjectId id, DBObject fields) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        return findOne(clazz, id, fields);
    }

    public static PatentInfo2 findOne(Pto pto, String id, DBObject fields) {
        return findOne(pto, new ObjectId(id), fields);
    }

    public static PatentInfo2 findOne(Pto pto, ObjectId id, String... fields) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        return findOne(clazz, id, fields);
    }

    public static PatentInfo2 findOne(Pto pto, String id, String... fields) {
        return findOne(pto, new ObjectId(id), fields);
    }

    public static PatentInfo2 findPN(Pto pto, String patentNumber) {
        switch (pto) {
        case USPTO:
        case US:
        case TIPO:
        case TW:
        case JPO:
        case JP:
        case EPO:
        case EP:
        case WIPO:
        case WO:
            break;
        case CNIPR:
        case CN:
        case KIPO:
        case KR:
            throw new IllegalArgumentException("use findPN(pto, patentNumber, stat) instead");
        default:
            throw new IllegalArgumentException("no supported pto");
        }
        Class<? extends PatentInfo2> clazz = getClass(pto);
        BasicDBObject query = new BasicDBObject("patentNumber", patentNumber);
        return findOne(clazz, query);
    }

    public static PatentInfo2 findPN(Pto pto, String patentNumber, int stat) {
        switch (pto) {
        case USPTO:
        case US:
        case TIPO:
        case TW:
        case JPO:
        case JP:
            throw new IllegalArgumentException("use findPN(pto, patentNumber) instead");
        case CNIPR:
        case CN:
        case KIPO:
        case KR:
            break;
        case EPO:
        case EP:
        case WIPO:
        case WO:
            throw new IllegalArgumentException("use findPN(pto, patentNumber, kindcode) instead");
        default:
            throw new IllegalArgumentException("no supported pto");
        }
        Class<? extends PatentInfo2> clazz = getClass(pto);
        BasicDBObject query = new BasicDBObject("patentNumber", patentNumber);
        query.put("stat", stat);
        return findOne(clazz, query);
    }

    public static PatentInfo2 fromObject(Pto pto, Object obj) {
        Class<? extends PatentInfo2> clazz = getClass(pto);
        return fromObject(clazz, obj);
    }

}
