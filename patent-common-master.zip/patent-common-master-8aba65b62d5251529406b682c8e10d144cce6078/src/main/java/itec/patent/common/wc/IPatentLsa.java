package itec.patent.common.wc;

public interface IPatentLsa {

    public String LSA(Long projectID, Long[] patentID);

    public String hello(String name);

    public String sleep(int sleepTimeMs);

}
