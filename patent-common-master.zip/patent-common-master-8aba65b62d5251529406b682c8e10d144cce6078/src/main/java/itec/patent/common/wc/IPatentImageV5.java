package itec.patent.common.wc;

import java.util.Date;

public interface IPatentImageV5 {

    public boolean buildPDFV5(String pto, int stat, String kindcode, Date appDate, Date doDate, String patentNumber, int maxNum);

    public boolean clipFullImageV5(String pto, int stat, String kindcode, Date appDate, Date doDate, String patentNumber, int num);

    public boolean convertFullImageV5(String pto, int stat, String kindcode, Date appDate, Date doDate, String patentNumber, int num);

    public String genClipFullImagePathV1(String patentNumber, int num);

    public String genClipFullImagePathV5(int num);

    public String genFirstImagePathV1(String patentNumber);

    public String genFirstImagePathV5();

    public String genFullImagePathV1(String patentNumber, int num, String ext);

    public String genFullImagePathV5(int num);

    public String genFullPDFPathV1();

    public String genFullPDFPathV5();

    public String genPatentPathV1(String pto, Date date, String patentNumber);

    public String genPatentPathV5(String pto, int stat, String kindcode, Date date, String patentNumber);

    public String genResizeImagePathV5(String path, int width, int height);

    public String helloWorld();

    public boolean resizeImageV5(String path, int width, int height);

    public boolean splitFirstImageV5(String pto, int stat, String kindcode, Date appDate, Date doDate, String patentNumber);

    public int splitPDF2PNGV5(String pto, int stat, String kindcode, Date appDate, Date doDate, String patentNumber);

    public String[] splitPDF2PNGV5compatV1(String path);

    public String[] testConfig();

}
