package itec.patent.common.wc;

import java.util.Date;

import javax.jws.WebService;

@WebService(targetNamespace = IPatentImageV4.targetNamespace, name = IPatentImageV4.portType)
public interface IPatentImageV4 {
    public static final String targetNamespace = "http://itec.ip-in-house.com/patent.image.ws/kangaroo/";
    public static final String portType = "KangarooV4Soap";
    public static final String serviceName = "KangarooV4";

    public boolean buildPDFV4(String pto, int stat, Date appDate, Date doDate, String patentNumber, int maxNum);

    public boolean clipFullImageV4(String pto, int stat, Date appDate, Date doDate, String patentNumber, int num);

    public boolean convertFullImageV4(String pto, int stat, Date appDate, Date doDate, String patentNumber, int num);

    public String genClipFullImagePathV1(String patentNumber, int num) throws Exception;

    public String genClipFullImagePathV4(int num) throws Exception;

    public String genFirstImagePathV1(String patentNumber) throws Exception;

    public String genFirstImagePathV4() throws Exception;

    public String genFullImagePathV1(String patentNumber, int num, String ext) throws Exception;

    public String genFullImagePathV4(int num) throws Exception;

    public String genFullPDFPathV1() throws Exception;

    public String genFullPDFPathV4() throws Exception;

    public String genPatentPathV1(String pto, Date date, String patentNumber) throws Exception;

    public String genPatentPathV4(String pto, int stat, Date date, String patentNumber) throws Exception;

    public String genResizeImagePathV4(String path, int width, int height) throws Exception;

    public String helloWorld() throws Exception;

    public boolean resizeImageV4(String path, int width, int height);

    public boolean splitFirstImageV4(String pto, int stat, Date appDate, Date doDate, String patentNumber);

    public String[] testConfig() throws Exception;

}
