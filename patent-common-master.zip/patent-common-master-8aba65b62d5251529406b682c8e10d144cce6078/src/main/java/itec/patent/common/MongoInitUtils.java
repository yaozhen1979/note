package itec.patent.common;

import itec.patent.mongodb.patentinfo2.PatentInfoCN;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;
import itec.patent.mongodb.patentinfo2.PatentInfoEP;
import itec.patent.mongodb.patentinfo2.PatentInfoEPO;
import itec.patent.mongodb.patentinfo2.PatentInfoJP;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoKR;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoTW;
import itec.patent.mongodb.patentinfo2.PatentInfoUS;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoWO;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.TimeZone;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.ClassUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;

public class MongoInitUtils {

    static Log log = LogFactory.getLog(MongoInitUtils.class);

    public static final String opt_mongodb_uri = "mongodb.uri";
    public static final String opt_mongodb_pd = "mongodb.pd";
    public static final String opt_mongodb_ac = "mongodb.ac";
    public static final String opt_mongodb_uri_default = "mongodb://tpe-mongos-01.ip-in-house.com";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongodb_uri, true, opt_mongodb_uri_default, "mongodb uri, start with mongodb://"),
    };

    public static Builder mongoopt = MongoClientOptions.builder()
            .readPreference(ReadPreference.secondaryPreferred());

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        try {
            reload();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static void initMongoClass(Class<?> clazz, String config_name, String defuri) throws UnknownHostException {
        String uriString = ConfigUtils.get(config_name, defuri);
        if (log.isDebugEnabled()) {
            if (!uriString.equals(defuri)) {
                log.debug(ClassUtils.getShortCanonicalName(clazz) + ": " + uriString);
            }
        }
        log.debug("initMongoClass opt_mongodb_uri: " + ConfigUtils.get(opt_mongodb_uri));
        MongoCredential credential = MongoCredential.createCredential(new String(Base64.decodeBase64(ConfigUtils.get(opt_mongodb_ac))), ClassUtils.getShortCanonicalName(clazz), new String(Base64.decodeBase64(ConfigUtils.get(opt_mongodb_pd))).toCharArray());
        MongoClient mongo = new MongoClient(new ServerAddress(ConfigUtils.get(opt_mongodb_uri), 27017), Arrays.asList(credential));
        MappedClass.getMappedClass(clazz, mongo.getDB(clazz.getSimpleName()));
    }

    public static void initMongoClass(Class<?> clazz, String config_name) throws UnknownHostException {
        String defuri = ConfigUtils.get(opt_mongodb_uri, opt_mongodb_uri_default);
        initMongoClass(clazz, config_name, defuri);
    }

    public static void nothing() {}

    private static void reload(String defuri) throws UnknownHostException {
        log.debug("reload opt_mongodb_uri: " + ConfigUtils.get(opt_mongodb_uri));
        MongoCredential credential = MongoCredential.createCredential(new String(Base64.decodeBase64(ConfigUtils.get(opt_mongodb_ac))), "admin", new String(Base64.decodeBase64(ConfigUtils.get(opt_mongodb_pd))).toCharArray());
        MongoClient mongo = new MongoClient(new ServerAddress(ConfigUtils.get(opt_mongodb_uri), 27017), Arrays.asList(credential));
        MappedClass.db = mongo.getDB("admin");

        initMongoClass(PatentInfoUSPTO.class    , "mongodb.PatentInfoUSPTO.uri"    , defuri);
        initMongoClass(PatentInfoTIPO.class        , "mongodb.PatentInfoTIPO.uri"    , defuri);
        initMongoClass(PatentInfoCNIPR.class    , "mongodb.PatentInfoCNIPR.uri"    , defuri);
        initMongoClass(PatentInfoJPO.class        , "mongodb.PatentInfoJPO.uri"    , defuri);
        initMongoClass(PatentInfoKIPO.class        , "mongodb.PatentInfoKIPO.uri"    , defuri);
        initMongoClass(PatentInfoWIPO.class        , "mongodb.PatentInfoWIPO.uri"    , defuri);
        initMongoClass(PatentInfoEPO.class        , "mongodb.PatentInfoEPO.uri"    , defuri);
        initMongoClass(PatentInfoUS.class        , "mongodb.PatentInfoUS.uri"    , defuri);
        initMongoClass(PatentInfoTW.class        , "mongodb.PatentInfoTW.uri"    , defuri);
        initMongoClass(PatentInfoCN.class        , "mongodb.PatentInfoCN.uri"    , defuri);
        initMongoClass(PatentInfoJP.class        , "mongodb.PatentInfoJP.uri"    , defuri);
        initMongoClass(PatentInfoKR.class        , "mongodb.PatentInfoKR.uri"    , defuri);
        initMongoClass(PatentInfoWO.class        , "mongodb.PatentInfoWO.uri"    , defuri);
        initMongoClass(PatentInfoEP.class        , "mongodb.PatentInfoEP.uri"    , defuri);
    }

    public static void reload(ArgParser argParser) throws UnknownHostException {
        String defuri = argParser.getOptString(opt_mongodb_uri);
        reload(defuri);
    }

    public static void reload() throws UnknownHostException {
        String defuri = ConfigUtils.get(opt_mongodb_uri, opt_mongodb_uri_default);
        reload(defuri);
    }

}
