package itec.patent.common;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.RelatedPatent;
import itec.patent.mongodb.embed.MultiLangString;
import itec.patent.mongodb.embed.MultiLangString.LangFilter;
import itec.patent.mongodb.embed.Person;
import itec.patent.solr.SolrPatentInfo2;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mongodb.BasicDBObjectBuilder;

public class PatentInfoToSolr {

    static Log log = LogFactory.getLog(PatentInfoToSolr.class);

    private static HashMap<Pto, String> ptoMap = new HashMap<>();
    static {
        ptoMap.put(Pto.USPTO,    "US");
        ptoMap.put(Pto.US,        "US");
        ptoMap.put(Pto.TIPO,    "TW");
        ptoMap.put(Pto.TW,        "TW");
        ptoMap.put(Pto.CNIPR,    "CN");
        ptoMap.put(Pto.CN,        "CN");
        ptoMap.put(Pto.JPO,        "JP");
        ptoMap.put(Pto.JP,        "JP");
        ptoMap.put(Pto.KIPO,    "KR");
        ptoMap.put(Pto.KR,        "KR");
        ptoMap.put(Pto.EPO,        "EP");
        ptoMap.put(Pto.EP,        "EP");
        ptoMap.put(Pto.WIPO,    "WO");
        ptoMap.put(Pto.WO,        "WO");
        ptoMap.put(Pto.DPMA,    "DE");
        ptoMap.put(Pto.DE,        "DE");
        ptoMap.put(Pto.INPI,    "FR");
        ptoMap.put(Pto.FR,        "FR");
        ptoMap.put(Pto.UKIPO,    "GB");
        ptoMap.put(Pto.GB,        "GB");
        ptoMap.put(Pto.IGE,        "CH");
        ptoMap.put(Pto.CH,        "CH");
    }

    public static SolrPatentInfo2 Mongo2Solr(PatentInfo2 mongoInfo) {
        SolrPatentInfo2 solrInfo = new SolrPatentInfo2();

        solrInfo.id = mongoInfo.id.toString();

        solrInfo.pto = mongoInfo.pto.toString();

        fillDate(mongoInfo.appDate, solrInfo, "app");

        fillDate(mongoInfo.certificateDate, solrInfo, "certificate");

        fillDate(mongoInfo.decisionDate, solrInfo, "decision");

        fillDate(mongoInfo.examDate, solrInfo, "exam");

        fillDate(mongoInfo.openDate, solrInfo, "open");

        fillNumber(mongoInfo.appNumber, solrInfo, "app", mongoInfo.pto);

        if(mongoInfo.pto.equals(Pto.CN)) {
            fillNumber(mongoInfo.appNumber, solrInfo, "patent", mongoInfo.pto);
        }

        fillNumber(mongoInfo.certificateNumber, solrInfo, "certificate", mongoInfo.pto);

        solrInfo.mainCPC_pc = mongoInfo.mainCPC;

        solrInfo.mainIPC_pc = mongoInfo.mainIPC;

        solrInfo.mainIPCR_pc = mongoInfo.mainIPCR;

        solrInfo.mainLOC_pc = mongoInfo.mainLOC;

        solrInfo.mainUSPC_pc = mongoInfo.mainUSPC;

        solrInfo.mainFI_pc = mongoInfo.mainFI;

        solrInfo.mainFTerm_pc = mongoInfo.mainFTerm;

        solrInfo.mainDI_pc = mongoInfo.mainDI;

        solrInfo.mainDTerm_pc = mongoInfo.mainDTerm;

        solrInfo.cpcs_pcs = mongoInfo.cpcs;

        solrInfo.ipcs_pcs = mongoInfo.ipcs;

        solrInfo.ipcrs_pcs = mongoInfo.ipcrs;

        solrInfo.locs_pcs = mongoInfo.locs;

        solrInfo.uspcs_pcs = mongoInfo.uspcs;

        solrInfo.fis_pcs = mongoInfo.fis;

        solrInfo.fterms_pcs = mongoInfo.fterms;

        solrInfo.dis_pcs = mongoInfo.dis;

        solrInfo.dterms_pcs = mongoInfo.dterms;

        solrInfo.eclas_pcs = mongoInfo.eclas;

        for (Person person : mongoInfo.agents) {
            fillPerson(person, solrInfo, "agents");
        }

        for (Person person : mongoInfo.agentOperators) {
            fillPerson(person, solrInfo, "agentOperators");
        }

        for (Person person : mongoInfo.assignees) {
            fillPerson(person, solrInfo, "assignees");
        }

        for (Person person : mongoInfo.inventors) {
            fillPerson(person, solrInfo, "inventors");
        }

        for (Person person : mongoInfo.examinerMasters) {
            fillPerson(person, solrInfo, "examinerMasters");
        }

        for (Person person : mongoInfo.examinerSlaves) {
            fillPerson(person, solrInfo, "examinerSlaves");
        }

        for (RelatedPatent pat : mongoInfo.citedPatents) {
            addUnique(solrInfo.cited_patents_numberall, pat.patentNumber);
        }

        for (RelatedPatent pat : mongoInfo.priorityPatents) {
            if(pat.appNumber!=null) {
                addUnique(solrInfo.priority_patents_numberall, pat.appNumber);
            } else {
                addUnique(solrInfo.priority_patents_numberall, pat.patentNumber);
            }
        }

        for (RelatedPatent pat : mongoInfo.relatedPatents) {
            if(pat.relation !=null && pat.relation.equals("ReissueOf")) {
                solrInfo.reissuefrom_number = pat.patentNumber;
            }
        }

        for (String other_references : mongoInfo.otherReferences) {
            addUnique(solrInfo.other_references, other_references);
        }

        solrInfo.kindcode = mongoInfo.kindcode;

        solrInfo.type = mongoInfo.type;

        for (RelatedPatent relpat : mongoInfo.relPatents) {
            PatentInfo2 relinfo = PatentInfo2.findOne(Pto.valueOf(relpat.pto), relpat.id
                    ,"decisionNumber", "openNumber", "stat", "brief", "claim", "description", "title"
                    , "inventors", "assignees", "ipcs", "locs", "pto");
            if (relinfo == null) {
                log.error(
                    BasicDBObjectBuilder
                        .start()
                        .add("pto", mongoInfo.pto.toString())
                        .add("id", mongoInfo.id)
                        .add("relpto", relpat.pto.toString())
                        .add("relid", relpat.id)
                        .get()
                        .toString()
                );
            } else {
                fillStatDates(relpat.doDate, relpat.stat, solrInfo);
                solrInfo.stats.add(relinfo.stat);
                if (relinfo.brief != null) {    // 無摘要不建索引 ep
                    solrInfo.briefs.add(getMultiLang(relinfo.brief, ""));
                }
                solrInfo.claims.add(getMultiLang(relinfo.claim, ""));
                solrInfo.descriptions.add(getMultiLang(relinfo.description, ""));
                solrInfo.titles.add(getMultiLang(relinfo.title, ""));
                //solrInfo.do_dates.add(relpat.doDate);
                fillNumber(relinfo.decisionNumber, solrInfo, "patent", relinfo.pto);
                fillNumber(relinfo.openNumber, solrInfo, "patent", relinfo.pto);
                addUnique(solrInfo.rel_patents, relpat.toDBObject().toString());

                //search result usage
                if(relinfo.id.equals(mongoInfo.relPatents.get(0).getId())) {
                    solrInfo.original_title_store = getMultiLang(relinfo.title, null);
                    solrInfo.original_brief_store = getMultiLang(relinfo.brief, null);
                    for (Person assignee : relinfo.assignees) {
                        solrInfo.original_assignees_name_store.add(getMultiLang(assignee.name, null));
                    }
                    for (Person inventor : relinfo.inventors) {
                        solrInfo.original_inventors_name_store.add(getMultiLang(inventor.name, null));
                    }
                    for (String ipc : relinfo.ipcs) {
                        solrInfo.original_ipcs_store.add(ipc);
                    }
                    for (String loc : relinfo.locs) {
                        solrInfo.original_locs_store.add(loc);
                    }
                }
            }
        }

        fillDate(mongoInfo.doDate, solrInfo, "do");

        return solrInfo;
    }

    protected static boolean isEmpty(String value) {
        if (value == null) {
            return true;
        }
        if (value.trim().isEmpty()) {
            return true;
        }
        return false;
    }

    protected static boolean isEmpty(MultiLangString value) {
        if (value == null) {
            return true;
        }
        return isEmpty(getMultiLang(value, null));
    }

    protected static void addUnique(List<String> field, String value) {
        if (isEmpty(value)) {
            return;
        }
        if (!field.contains(value)) {
            field.add(value);
        }
    }

    protected static String genString(String... args) {
        StringBuffer sb = new StringBuffer();
        for (String s : args) {
            if (!isEmpty(s)) {
                sb.append(s);
            }
        }
        return sb.toString();
    }

    protected static String getMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        String ret = data.toDBObject().toString();
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    protected static String getPersonNameMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        data = MultiLangString.fromObject(MultiLangString.class, data);
        data.filter(new LangFilter() {
            @Override
            public String filter(String lang, String value, MultiLangString context) {
                return value.toLowerCase().replaceAll("[\\s`~!@#$%^&*()\\-_=+\\[{\\]};:'\",<.>/?]+", "");
            }
        });
        String ret = data.toDBObject().toString();
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    protected static void fillPerson(Person person, SolrPatentInfo2 solr, String solrFieldName) {
        if (person == null) {
            return;
        }

        try {
            Field fname = solr.getClass().getField(solrFieldName + "_name");
            ArrayList<String> pname = (ArrayList<String>) fname.get(solr);
            pname.add(getMultiLang(person.name, ""));

            Field faddress = solr.getClass().getField(solrFieldName + "_address");
            ArrayList<String> paddress = (ArrayList<String>) faddress.get(solr);
            paddress.add(getMultiLang(person.address, ""));

            Field fcountry = solr.getClass().getField(solrFieldName + "_country");
            ArrayList<String> pcountry = (ArrayList<String>) fcountry.get(solr);
            pcountry.add(getMultiLang(person.country, ""));

            Field ffacetname = solr.getClass().getField(solrFieldName + "_facetname");
            ArrayList<String> pfacetname = (ArrayList<String>) ffacetname.get(solr);
            pfacetname.add(getPersonNameMultiLang(person.name, ""));

            Field ffacetNC = solr.getClass().getField(solrFieldName + "_facetNC");
            ArrayList<String> pfacetNC = (ArrayList<String>) ffacetNC.get(solr);
            if (isEmpty(person.country)) {
                pfacetNC.add(getPersonNameMultiLang(person.name, ""));
            } else {
                pfacetNC.add("[" + getPersonNameMultiLang(person.name, "") + ", " + getMultiLang(person.country, "") + "]");
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    protected static void fillDate(Date date, SolrPatentInfo2 solr, String solrFieldName) {
        if (date == null) {
            return;
        }

        try {
            Field fdate = solr.getClass().getField(solrFieldName + "_date");
            fdate.set(solr, date);

            Field fdateYear = solr.getClass().getField(solrFieldName + "_year");
            SimpleDateFormat fmtYear = new SimpleDateFormat("yyyy");
            fdateYear.set(solr, Integer.parseInt(fmtYear.format(date)));

            Field fdateYearMon = solr.getClass().getField(solrFieldName + "_yearmon");
            SimpleDateFormat fmtYearMon = new SimpleDateFormat("yyyyMM");
            fdateYearMon.set(solr, Integer.parseInt(fmtYearMon.format(date)));
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    protected static void fillStatDates(Date date, Integer stat,  SolrPatentInfo2 solr) {
        if (date == null || stat ==null) {
            return;
        }
        SimpleDateFormat fmtYearMonDate = new SimpleDateFormat("yyyyMMdd");
        solr.stat_dates.add(stat + "_" + fmtYearMonDate.format(date));
    }

    // US1: US008295630 US00D242762 US000PP3994 US00RE28691 US0000H1443
    private static Pattern rePatentNumberUS1 = Pattern.compile("^(US)?0*((D|PP|RE|H)?\\d+)$");
    // US2: 12/575,551
    private static Pattern rePatentNumberUS2 = Pattern.compile("^(US)?(\\d+)/(\\d*),?(\\d*)$");
    // US3: 20040095078 2004095078, EPDOC use secondary
    private static Pattern rePatentNumberUS3 = Pattern.compile("^(\\d{4})0(\\d{6})$");
    // TW1: 079100883 I319544 M363691 D138757
    private static Pattern rePatentNumberTW1 = Pattern.compile("^(TW)?0*((I|M|D)?\\d+)$");
    // CN1: 200810306395.2 CN200810306395
    private static Pattern rePatentNumberCN1 = Pattern.compile("^(CN)?(\\d{12})(\\.\\S+)?$");
    // CN2: CN101751575A 101751575 
    private static Pattern rePatentNumberCN2 = Pattern.compile("^(CN)?(\\d{7,9})(\\D)?$");

    private static Pattern rePatentNumberTail = Pattern.compile("^(\\S+)(\\d\\d\\d)$");
    // added by yiyun for WO 2013/10/31        WO: WO 2012/000001
    private static Pattern rePatentNumberWO = Pattern.compile("^WO(\\s)(\\d{4})/(\\d{6})$");
    // added by yiyun for WO 2014/04/08     APN: PCT/US2007/022037
    private static Pattern rePatentNumberWO1 = Pattern.compile("^PCT/(\\w{6})/0?(\\d*)$");
    // added by yh
    // EP1: appNo: 11165961.1
    private static Pattern rePatentNumberEP1 = Pattern.compile("^(\\d{8})(\\.\\S+)?$");
    // EP2: pn/openNo : EP2398401
    private static Pattern rePatentNumberEP2 = Pattern.compile("^(EP)(\\d{7})?$");
    //added by luken 20131109
    private static Pattern rePatentNumberKR1 = Pattern.compile("^(\\d{13})?$");
    //added end
    
    @SuppressWarnings("unchecked")
    protected static void fillNumber(String number, SolrPatentInfo2 solr, String solrFieldName, Pto pto) {
        if (isEmpty(number)) {
            return;
        }

        ArrayList<String> numberall = new ArrayList<>();
        ArrayList<String> numberfix = new ArrayList<>();
        numberall.add(number);
        numberfix.add(number);

        String fix;
        Matcher matcher;

        matcher = rePatentNumberUS1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }

        matcher = rePatentNumberUS2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);

            fix = genString(matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }

        matcher = rePatentNumberUS3.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }

        matcher = rePatentNumberTW1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }

        matcher = rePatentNumberCN1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }

        matcher = rePatentNumberCN2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        
        // added by yiyun for WO 2013/10/31
        matcher = rePatentNumberWO.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        // added by yiyun for WO 2014/04/08
        matcher = rePatentNumberWO1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
            
            fix = genString("PCT/", matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        
        // added by yh
        matcher = rePatentNumberEP1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);

            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        
        matcher = rePatentNumberEP2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        // add end
        
        //added by luken 20131129
        matcher = rePatentNumberKR1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);
            addUnique(numberfix, fix);
        }
        
        //added end
        
        String ptoprefix = ptoMap.get(pto);
        if (ptoprefix == null) {
            //官網檢索此欄位為國家
            ptoprefix = pto.name();
        }
        // added by hanyao 20140624
        if (ptoprefix.contains("JP")) {
            if (number.contains("(") || number.contains(")")) {
                String temNumber = number.substring(0, number.indexOf("("));
                addUnique(numberfix, temNumber);
                addUnique(numberall, temNumber);
            }
            String regx = "\\d{1,}-?\\d{1,}";
            Pattern reNumberJP = Pattern.compile(regx);
            matcher = reNumberJP.matcher(number);
            if (matcher.find()) {
                String temp = matcher.group(0);
                if (temp.contains("-")) {
                    String preTemp = temp.substring(0, temp.indexOf("-"));
                    String aftTemp = temp.substring(temp.indexOf("-") + 1);
                    if (preTemp.length() < 2) {
                        preTemp = "0" + preTemp;
                    }
                    temp = preTemp + "-" + aftTemp;
                    addUnique(numberfix, temp);
                    addUnique(numberall, temp);
                    if (aftTemp.length() < 6) {
                        int i = 6 - aftTemp.length();
                        switch (i) {
                        case 1:
                            aftTemp = "0" + aftTemp;
                            break;
                        case 2:
                            aftTemp = "00" + aftTemp;
                            break;
                        case 3:
                            aftTemp = "000" + aftTemp;
                            break;
                        case 4:
                            aftTemp = "0000" + aftTemp;
                            break;
                        case 5:
                            aftTemp = "00000" + aftTemp;
                            break;
                        }
                        temp = preTemp + "-" + aftTemp;
                        addUnique(numberfix, temp);
                        addUnique(numberall, temp);
                    }
                    String num = temp.substring(temp.indexOf("-") + 1);
                    String year = temp.substring(0,temp.indexOf("-"));
                    String jpNum = "";
                    int j = Integer.parseInt(num);
                    num = j + "";
                    num = temp.substring(0, temp.indexOf("-") + 1) + num;
                    addUnique(numberfix, num);
                    addUnique(numberfix, "JP" + num);
                    addUnique(numberall, num);
                    addUnique(numberall, "JP" + num);
                    if (number.contains("平")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1988) + temp.substring(temp.indexOf("-"));
                        num = "H" + num;
                        temp = "H" + temp;
                        addUnique(numberfix, "JP" + jpNum);
                        addUnique(numberfix, jpNum);
                        addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    if (number.contains("昭")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1925) + temp.substring(temp.indexOf("-"));
                        num = "S" + num;
                        temp = "S" + temp;
                        addUnique(numberfix, "JP" + jpNum);
                        addUnique(numberfix, jpNum);
                        addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    addUnique(numberall, "JP" + num);
                    addUnique(numberall, "JP" + temp);
                    addUnique(numberall, temp);
                    addUnique(numberall, num);
                    addUnique(numberfix, num);
                    addUnique(numberfix, temp);
                    addUnique(numberfix, "JP" + num);
                    addUnique(numberfix, "JP" + temp);
                } else {
                    addUnique(numberfix, temp);
                    addUnique(numberfix, "JP" + temp);
                    addUnique(numberall, temp);
                    addUnique(numberall, "JP" + temp);
                }
            }
        } else if (!ptoprefix.contains("JP")) {
            for (String n : (ArrayList<String>) numberfix.clone()) {
                matcher = rePatentNumberTail.matcher(number);
                if (matcher.find()) {
                    fix = genString(matcher.group(2));
                    // addUnique(numberall, fix); // no add tail 3 digit to
                    // numberall
                    addUnique(numberfix, fix);
                }

                if (n.length() > 3 && !n.startsWith(ptoprefix)) {
                    fix = ptoprefix + n;
                    addUnique(numberall, fix);
                    addUnique(numberfix, fix);
                }
            }
        }
        //added end
        if (!ptoprefix.contains("JP")) {
            for (String n : (ArrayList<String>) numberfix.clone()) {
                matcher = rePatentNumberTail.matcher(number);
                if (matcher.find()) {
                    fix = genString(matcher.group(2));
                    // addUnique(numberall, fix); // no add tail 3 digit to
                    // numberall
                    addUnique(numberfix, fix);
                }

                if (n.length() > 3 && !n.startsWith(ptoprefix)) {
                    fix = ptoprefix + n;
                    addUnique(numberall, fix);
                    addUnique(numberfix, fix);
                }
            }
        }
        //added end
        try {
            //專利號不提供顯示，僅建可檢索的號碼格式
            if(solrFieldName.equals("patent")) {
                solr.patent_numberall.addAll(numberall);
            } else {
            Field fnumber = solr.getClass().getField(solrFieldName + "_number");
            fnumber.set(solr, number);
            Field fnumberall = solr.getClass().getField(solrFieldName + "_numberall");
            fnumberall.set(solr, numberall);
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

}
