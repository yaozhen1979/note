package itec.patent.common;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.PatentInfo2.PtoPid;
import itec.patent.mongodb.Pto;

import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.servlet.BaseParamContext;
import org.tsaikd.java.utils.ConfigUtils;

public class PatentParamContext extends BaseParamContext {

    static Log log = LogFactory.getLog(PatentParamContext.class);

    public PatentParamContext(HttpServletRequest req, HttpServletResponse res) {
        super(req, res);
    }

    private Boolean isDebug;
    public Boolean getIsDebug() {
        if (isDebug == null) {
            isDebug = getParamBoolean("isDebug", ConfigUtils.getBool("servlet.debug", false));
        }
        return isDebug;
    }

    private LinkedList<Integer> nums;
    public LinkedList<Integer> getNums() {
        if (nums == null) {
            nums = getParamInts("num");
        }
        return nums;
    }

    private Integer num;
    public Integer getNum() {
        if (num == null) {
            LinkedList<Integer> nums = getNums();
            if (nums.isEmpty()) {
                return null;
            } else {
                num = nums.getLast();
            }
        }
        return num;
    }

    private LinkedList<PtoPid> ptopids;
    public LinkedList<PtoPid> getPtoPids() {
        if (ptopids == null) {
            ptopids = new LinkedList<>();
            LinkedList<String> values = getParamSeps(",", "ptopid");
            for (String value : values) {
                PtoPid pid = new PtoPid();
                String[] ppidSep = value.split("\\.");
                pid.pto = Pto.valueOf(ppidSep[0].toUpperCase());
                pid.id = new ObjectId(ppidSep[1]);
                ptopids.add(pid);
            }
        }
        return ptopids;
    }

    private PtoPid ptopid;
    public PtoPid getPtoPid() {
        if (ptopid == null) {
            LinkedList<PtoPid> ptopids = getPtoPids();
            if (ptopids.isEmpty()) {
                return null;
            } else {
                ptopid = ptopids.getLast();
            }
        }
        return ptopid;
    }

    private LinkedList<PatentInfo2> patentInfos;
    public LinkedList<PatentInfo2> getPatentInfos(String... fields) {
        if (patentInfos == null) {
            patentInfos = new LinkedList<>();
            for (PtoPid ptopid : getPtoPids()) {
                PatentInfo2 info = PatentInfo2.findOne(ptopid.pto, ptopid.id, fields);
                if (info != null) {
                    patentInfos.add(info);
                }
            }
        }
        return patentInfos;
    }

    private PatentInfo2 patentInfo;
    public PatentInfo2 getPatentInfo(String... fields) {
        if (patentInfo == null) {
            LinkedList<PatentInfo2> patentInfos = getPatentInfos(fields);
            if (patentInfos.isEmpty()) {
                return null;
            } else {
                patentInfo = patentInfos.getLast();
            }
        }
        return patentInfo;
    }

}
