package itec.patent.common;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PathUtils {

    static Log log = LogFactory.getLog(PathUtils.class);

    private static String format(Date date) {
        DateFormat fmtPath = new SimpleDateFormat("yyyy/MM/dd");
        return fmtPath.format(date);
    }

    public static String concatPath1(String... paths) {
        StringBuilder sb = new StringBuilder();
        sb.append(paths[0]);
        for (int i=1 ; i<paths.length ; i++) {
            sb.append(File.separator);
            sb.append(paths[i]);
        }
        return sb.toString();
    }

    public static String concatPath2(String base, String... paths) {
        StringBuilder sb = new StringBuilder();
        sb.append(base);
        for (int i=0 ; i<paths.length ; i++) {
            sb.append(File.separator);
            sb.append(paths[i]);
        }
        return sb.toString();
    }

    public static String concatPath3(String base1, String base2, String... paths) {
        StringBuilder sb = new StringBuilder();
        sb.append(base1);
        sb.append(File.separator);
        sb.append(base2);
        for (int i=0 ; i<paths.length ; i++) {
            sb.append(File.separator);
            sb.append(paths[i]);
        }
        return sb.toString();
    }

    // pid path
    public static String genPidPath(long patentId) {
        StringBuilder sb = new StringBuilder();
        String pid = String.valueOf(patentId);
        int len = pid.length();
        for (int i=0 ; i<len ; i++) {
            if (i % 3 == 0) {
                sb.append(File.separator);
            }
            sb.append(pid.charAt(i));
        }
        return sb.substring(1);
    }

    // patent path
    public static String genPatentPathV1(String pto, int stat, Date date, String patentNumber) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int iMon = cal.get(Calendar.MONTH); // 0 ~ 11
        int iCent = iMon / 3 + 1;
        if (stat == 1) {
            if (pto.equalsIgnoreCase("cn") || pto.equalsIgnoreCase("kr")) {
                return pto.toUpperCase() + "/" + cal.get(Calendar.YEAR) + iCent + "/" + patentNumber + "@O";
            }
        }
        if (pto.equalsIgnoreCase("tw")) {
            return "TWGA/" + cal.get(Calendar.YEAR) + iCent + "/" + patentNumber;
        }
        if (pto.equalsIgnoreCase("jp")) {
            try {
                return pto.toUpperCase() + "/" + cal.get(Calendar.YEAR) + iCent + "/" + Base64.encodeBase64String(patentNumber.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return pto.toUpperCase() + "/" + cal.get(Calendar.YEAR) + iCent + "/" + patentNumber;
    }

    private static Pattern patJPPatentNumber = Pattern.compile("\\d+");
    public static String genPatentPathV5(String pto, int stat, String kindcode, Date date, String patentNumber) {
        if (kindcode == null || kindcode.equalsIgnoreCase("undefined")) {
            kindcode = "";
        }
        patentNumber = patentNumber.replaceAll("[/\\\\\\s]+", "");
        if (pto.equalsIgnoreCase("jp")) {
            Matcher matcher = patJPPatentNumber.matcher(patentNumber);
            if (matcher.find()) {
                return pto.toLowerCase() + stat + kindcode.toLowerCase() + "/" + format(date) + "/" + matcher.group();
            }
        }
        return pto.toLowerCase() + stat + kindcode.toLowerCase() + "/" + format(date) + "/" + patentNumber.toLowerCase();
    }

    // cnipr patent path
    public static String genPatentPathCnipr(Date date, String patentNumber) {
        DateFormat fmtCniprPath = new SimpleDateFormat("yyyy/yyyyMMdd");
        return fmtCniprPath.format(date) + "/" + patentNumber.toLowerCase();
    }

    // full image path
    public static String genFullImagePathV1(String pto, int stat, String patentNumber, int num, String ext) {
        if (stat == 1) {
            if (pto.equalsIgnoreCase("cn") || pto.equalsIgnoreCase("kr")) {
                return patentNumber + "@O_" + num + "." + ext;
            }
        }
        return patentNumber + "_" + num + "." + ext;
    }

    public static String genFullImagePathV5(int num) {
        return "fullImage/" + num + ".png";
    }

    // first image path
    public static String genFirstImagePathV1(String patentNumber) {
        return patentNumber + "_1_1.png";
    }

    public static String genFirstImagePathV5() {
        return "firstImage.png";
    }

    // clip full image path
    public static String genClipFullImagePathV1(String patentNumber, int num) {
        return patentNumber + "_" + num + "_clip.png";
    }

    public static String genClipFullImagePathV5(int num) {
        return "clip/" + num + ".png";
    }

    // resize image path
    public static String genResizeImagePathV5(String path, int width, int height) {
        return width + "x" + height + "/" + path;
    }

    // full pdf path
    public static String genFullPDFPathV1() {
        return "fullpage.pdf";
    }

    public static String genFullPDFPathV5() {
        return "fullPage.pdf";
    }

}
