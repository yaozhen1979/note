package itec.patent.common.wc;

import java.util.ArrayList;

import org.tsaikd.java.mongodb.MongoObject;

public class PatentLsaResponse {

    public static class LsaResponse extends MongoObject {

        public static class Result extends MongoObject {

            public Integer patentID;

            public ArrayList<String> UDC = new ArrayList<>();

        }

        public ArrayList<Result> result = new ArrayList<>();

    }

}
