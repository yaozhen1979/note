package itec.patent.common.wc;

import java.util.Date;

import javax.jws.WebService;

@WebService(targetNamespace = IPatentImage.targetNamespace, name = IPatentImage.portType)
public interface IPatentImage {
    public static final String targetNamespace = "http://itec.ip-in-house.com/patent.image.ws/kangaroo/";
    public static final String portType = "KangarooSoap";
    public static final String serviceName = "Kangaroo";

    public boolean buildPDFV3(String pto, Date appDate, Date doDate, String patentNumber, int maxNum);

    public boolean clipFullImageV3(String pto, Date appDate, Date doDate, String patentNumber, int num);

    public boolean convertFullImageV1(String pto, Date appDate, Date doDate, String patentNumber, int num);

    public String genClipFullImagePathV1(String patentNumber, int num) throws Exception;

    public String genClipFullImagePathV3(int num) throws Exception;

    public String genFirstImagePathV1(String patentNumber) throws Exception;

    public String genFirstImagePathV3() throws Exception;

    public String genFullImagePathV1(String patentNumber, int num, String ext) throws Exception;

    public String genFullImagePathV3(int num) throws Exception;

    public String genFullPDFPathV1() throws Exception;

    public String genFullPDFPathV3() throws Exception;

    public String genPatentPathV1(String pto, Date date, String patentNumber) throws Exception;

    public String genPatentPathV3(String pto, Date date, String patentNumber) throws Exception;

    public String genResizeImagePathV3(String path, int width, int height) throws Exception;

    public String helloWorld() throws Exception;

    public boolean resizeImageV3(String path, int width, int height);

    public boolean splitFirstImageV3(String pto, Date appDate, Date doDate, String patentNumber);

    public String[] testConfig() throws Exception;

}
