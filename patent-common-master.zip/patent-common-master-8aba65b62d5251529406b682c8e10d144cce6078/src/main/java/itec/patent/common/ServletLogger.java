package itec.patent.common;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ServletUtils;

import com.maxmind.geoip.Location;
import com.maxmind.geoip.LookupService;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

public class ServletLogger{
    static Log log = LogFactory.getLog(ServletLogger.class);
    public static final int version = 6;

    public DBCollection mongocol = MappedClass.db.getCollection("actionLog");
    static String dbfile = ConfigUtils.get("geo.ip.kangaroolog.path");
    static LookupService cl;
    static {
        try {
            cl = new LookupService(dbfile, LookupService.GEOIP_MEMORY_CACHE );
        } catch (Exception e) {
            log.error(e);
        }
    }
    static Map<String, String> ipTypeRef = new HashMap<String, String>();
    static {
        ipTypeRef.put("10.60.90", "PatentCloud-SBP");
        ipTypeRef.put("10.60.94" , "PatentCloud-SBP");
        ipTypeRef.put("10.60.92" , "WISPRO");
        ipTypeRef.put("10.60.91", "PatentCloud-SBP");
        ipTypeRef.put("10.60.93", "WISPRO");
        ipTypeRef.put("10.60.80", "PatentCloud-SBP");
        ipTypeRef.put("10.60.81", "WISPRO");
        ipTypeRef.put("10.180", "PatentCloud-SBP");
        ipTypeRef.put("10.62.39", "PatentCloud-SBP");
        ipTypeRef.put("10.62.40", "PatentCloud-SBP");
        ipTypeRef.put("10.62.41", "PatentCloud-SBP");
        ipTypeRef.put("10.62.42", "PatentCloud-SBP");      
        try {
            cl = new LookupService(dbfile, LookupService.GEOIP_MEMORY_CACHE );
        } catch (Exception e) {
            //todo
        }
    }
    public String[] logRequestHeaders = {
        "Accept-Charset",
        "Accept-Encoding",
        "Accept-Language",
        "Referer",
        "User-Agent",
    };

    public String[] logResponseHeaders = {
        "Content-Length",
    };

    @SuppressWarnings("serial")
    public HashSet<String> logRequestParamSepComma = new HashSet<String>() {{
        add("field");
    }};

    public interface ExtraLog {
        public void filter(HttpServletRequest req, HttpServletResponse res, DBObject dbobj);
    }

    public LinkedList<ExtraLog> extraLogList = new LinkedList<>();

    protected static ServletLogger instance = null;
    public static ServletLogger getInstance() {
        if (instance == null) {
            instance = new ServletLogger();
        }
        return instance;
    }

    public void dbLog(HttpServletRequest req, HttpServletResponse res, DBObject dbobj, boolean async) {
        try {
            HttpSession sess = req.getSession(false);
            validateAction(sess, dbobj);
    
            BasicDBObject requestObj = new BasicDBObject();
            {
                requestObj.put("requestURL", req.getRequestURL().toString());
                requestObj.put("localAddr", req.getLocalAddr());
                requestObj.put("localName", req.getLocalName());
                requestObj.put("contextPath", req.getContextPath());
                requestObj.put("servletPath", req.getServletPath());
                requestObj.put("requestURI", req.getRequestURI());
                requestObj.put("method", req.getMethod());
                BasicDBObject requestHeaderObj = new BasicDBObject();
                for (int i=0 ; i<logRequestHeaders.length ; i++) {
                    String header = logRequestHeaders[i];
                    String headerData = req.getHeader(header);
                    if (headerData != null) {
                        header = replaceStr(header);
                        requestHeaderObj.put(header, headerData);
                    }
                }
                if (!requestHeaderObj.isEmpty()) {
                    requestObj.put("header", requestHeaderObj);
                }
            }
            dbobj.put("request", requestObj);
    
            BasicDBObject responseObj = new BasicDBObject();
            {
                responseObj.put("status", res.getStatus());
                String contentType = res.getContentType();
                if (contentType != null) {
                    responseObj.put("contentType", contentType);
                }
    
                BasicDBObject responseHeaderObj = new BasicDBObject();
                for (int i=0 ; i<logResponseHeaders.length ; i++) {
                    String header = logResponseHeaders[i];
                    String headerData = res.getHeader(header);
                    if (headerData != null) {                    
                        header = replaceStr(header);
                        responseHeaderObj.put(header, headerData);
                    }
                }
                if (!responseHeaderObj.isEmpty()) {
                    responseObj.put("responseHeader", responseHeaderObj);
                }
            }
            dbobj.put("response", responseObj);
            dbobj.put("host", InetAddress.getLocalHost().getHostAddress());
            BasicDBObject clientObj = new BasicDBObject();
            {
                clientObj.put("ip", req.getRemoteAddr());
                BasicDBList ips = new BasicDBList();
                for (String ip : ServletUtils.getRemoteRealIPs(req)) {
                    ips.add(ip);
                }
                clientObj.put("ips", ips);
                if (!ips.isEmpty()) {
                    clientObj.put("realip", ips.get(0));
                    try {
                        clientObj.put("IPtype", getIPType(ips.get(0).toString()));
                        Location loc = cl.getLocation(ips.get(0).toString());
                        if (loc != null) {
                            clientObj.put("country", loc.countryName);
                            clientObj.put("city", loc.city);
                        } else {
                            clientObj.put("country", "");
                            clientObj.put("city", "");
                        }
                    } catch (Exception e){
                        log.error(e);
                    }
                }
            }
            dbobj.put("client", clientObj);
    
            if (sess != null) {
                dbobj.put("sessionId", sess.getId());
            }
    
            dbobj.put("version", version);
            dbobj.put("endTime", new Date());
    
            for (ExtraLog extraLog: extraLogList) {
                extraLog.filter(req, res, dbobj);
            }
    
            insertLog(dbobj, async);
        } catch (Exception e) {
            log.error(e);
        }
    }
    
    public void dbLog(HttpServletRequest req, HttpServletResponse res, String data, boolean async) {
        DBObject dbobj = (DBObject) JSON.parse(data);
        dbLog(req, res, dbobj, async);
    }

    public void dbLogPage(HttpServletRequest req, HttpServletResponse res, String actionName, boolean logData, boolean async) {
        try {
            BasicDBObject dbobj = new BasicDBObject();
            BasicDBObject actionObj = new BasicDBObject();
            BasicDBObject logObj = new BasicDBObject();
            actionObj.put("name", actionName);
            actionObj.put("url", req.getServletPath());
            
            String query = req.getQueryString();
            if (query != null) {
                actionObj.put("query", query);
            }
            logObj.put("code", req.getAttribute("actionCode"));
            logObj.put("result", req.getAttribute("resultLog"));
            logObj.put("message", req.getAttribute("messageLog"));
            logObj.put("actionLog", req.getAttribute("actionLog"));
            logObj.put("uiLog", req.getAttribute("uiLog"));
            if (logData) {
                BasicDBObject dataObj = new BasicDBObject();
                Enumeration<String> names = req.getParameterNames();
                while (names.hasMoreElements()) {
                    String name = names.nextElement();
                    String[] value = req.getParameterValues(name);
                    if (value != null) {
                        if (value.length == 1 && logRequestParamSepComma.contains(name)) {
                            name = replaceStr(name);
                            dataObj.put(name, value[0].split(","));
                        } else {
                            name = replaceStr(name);                       
                            if(name.toString().equals("password") && !value[0].equals("logout")){
                                value[0] = "*******";
                            }
                            dataObj.put(name, value);
                        }
                    }
                }
                if (!dataObj.isEmpty()) {
                    actionObj.put("data", dataObj);
                }
            }
            dbobj.put("action", actionObj);
            dbobj.put("log", logObj);
            dbLog(req, res, dbobj, async);
        } catch (Exception e) {
            log.error(e);
        }
    }
    
    public void dbErrorLogPage(HttpServletRequest req, HttpServletResponse res, String actionName, boolean logData, boolean async, Exception e) {
        try {
            BasicDBObject dbobj = new BasicDBObject();
            BasicDBObject actionObj = new BasicDBObject();
            BasicDBObject logObj = new BasicDBObject();
            actionObj.put("name", actionName);
            actionObj.put("url", req.getServletPath());
    
            String query = req.getQueryString();
            if (query != null) {
                actionObj.put("query", query);
            }
    
            logObj.put("code", req.getAttribute("actionCode"));
            logObj.put("result", req.getAttribute("resultLog"));
            logObj.put("message", req.getAttribute("messageLog"));
            logObj.put("actionLog", req.getAttribute("actionLog"));
            logObj.put("uiLog", req.getAttribute("uiLog"));
            
            if (logData) {
                BasicDBObject dataObj = new BasicDBObject();
                Enumeration<String> names = req.getParameterNames();
                while (names.hasMoreElements()) {
                    String name = names.nextElement();
                    String[] value = req.getParameterValues(name);
                    if (value != null) {
                        if (value.length == 1 && logRequestParamSepComma.contains(name)) {                        
                            name = replaceStr(name);
                            dataObj.put(name, value[0].split(","));
                        } else {
                            name = replaceStr(name);
                            if(name.toString().equals("password") && !value[0].equals("logout")){
                                value[0] = "*******";
                            }
                            dataObj.put(name, value);
                        }
                    }
                }
                if (!dataObj.isEmpty()) {
                    actionObj.put("data", dataObj);
                }
            }
            dbobj.put("action", actionObj);
            dbobj.put("log", logObj);
            
            BasicDBObject exceptionObj = new BasicDBObject();
            StringWriter exceptionStackTrace = new StringWriter();
            e.printStackTrace(new PrintWriter(exceptionStackTrace));
            exceptionObj.put("message", e.getMessage());
            exceptionObj.put("stackTrace", exceptionStackTrace.toString());
            dbobj.put("exception", exceptionObj);        
            dbLog(req, res, dbobj, async);
        } catch (Exception ex) {
            log.error(ex);
        }
    }

    protected DBObject validateAction(HttpSession sess, DBObject dbobj) {
        if (!dbobj.containsField("action")) {
            if (sess != null) {
                sess.setAttribute("AJaxLogger.invalid", true);
            }
            throw new IllegalArgumentException("empty action");
        }
        Object obj = dbobj.get("action");
        String name = obj.getClass().getName();
        if (name.equals("com.mongodb.BasicDBObject")) {
            com.mongodb.BasicDBObject actionObj = (com.mongodb.BasicDBObject) obj;
            if (!actionObj.containsField("name")) {
                throw new IllegalArgumentException("action object without name");
            }
            return actionObj;
        } else {
            throw new IllegalArgumentException("invalid action object");
        }
    }

    protected void insertLog(final DBObject dbobj, boolean async) {
        if (async) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mongocol.insert(dbobj);
                }
            });
            thread.setPriority(Thread.MIN_PRIORITY);
            thread.start();
        } else {
            mongocol.insert(dbobj);
        }
    }
    
    private String replaceStr(String oriStr){        
        if(oriStr.contains(".")){
            oriStr = oriStr.replaceAll("\\.","_");
        }
        return oriStr;
    }
    
    private static String getIPType(String ip) {
        for(Map.Entry entry : ipTypeRef.entrySet()) {
            String value = entry.getValue().toString();
            if (ip.indexOf(entry.getKey().toString()) == 0) {
                return value;
            }
        }
        if (ip.substring(0,3).equals("10.")) {
            return "Private";
        }
        if (ip.substring(0,4).equals("172.")) {
            int secnum = Integer.valueOf(ip.substring(4,6));
            if (secnum >= 16 && secnum <= 31) {
                return "Private";
            }
        }
        return "External";
    }
}
