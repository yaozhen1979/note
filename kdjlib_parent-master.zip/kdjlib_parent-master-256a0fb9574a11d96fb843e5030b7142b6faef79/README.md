KDJLib_parent
=============

KDJLib maven base pom
