package itec.common.check;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * Check level2 patent image exist
 * 
 * execute jar:
 *      java -jar ImageCheck.jar -pto USPTO -t 20060101-20061231
 *      
 * @author yiyun 2015.04.03
 */
public class ImageCheck {
    
    static Log log = LogFactory.getLog(ImageCheck.class);
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private File errorFile = new File("./log/errorLog.txt");
    
    public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "CNIPR"; 
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    public static void main(String[] args) throws Exception {
        ImageCheck check = new ImageCheck();
        check.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(ImageCheck.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        MongoUtils.init(pto);
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        String dateRange = argParser.getOptString("t");
        
        QueryHelp query = MongoUtils.getDateRange(dateRange);
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count()).setFormatDefNum();
        while (cursor.hasNext()) {
            PatentInfo2 info = null;
            try {
                DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                String relpath = MongoUtils.getRelPatentPath(info);
                Path path = targetPath.resolve(relpath);
                
                File fullImageFile = path.resolve("fullImage").toFile();
                File fullPdfFile = path.resolve("fullPage.pdf").toFile();
                if (fullPdfFile.exists()) {
                	continue;
                }
                if (fullImageFile.exists() && fullImageFile.listFiles().length > 0) {
                	continue;
                }
                log.debug(path.toString() + " no exist");
                String logFilePath = String.format("./log/%s/%s.txt", pto.toString(), new SimpleDateFormat("yyyy").format(info.doDate));
                File logFile = new File(logFilePath);
                String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                FileUtil.writeInfo(logFile, message, true);
                
                pe.addNum().debug(log, 10000, sdf.format(info.doDate));
            } catch (Exception e) {
                log.debug(e, e);
                FileUtil.writeInfo(errorFile, info.patentNumber + " ; " + e.getMessage(), true);
            }
        }
    }
}
