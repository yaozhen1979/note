package itec.common.check;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.text.SimpleDateFormat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * Query No filePageNumber patent
 * 
 * execute jar:
 *      java -jar QueryNoFilePageNumber -file log/filePageNumber/text.txt -t 20150101-20150102
 *      
 * @author yiyun 2015.05.18
 */
public class QueryNoFilePageNumber {
    
    static Log log = LogFactory.getLog(QueryNoFilePageNumber.class);
    
    public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "EPO";
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/JPO/filePageNumber/2003.txt";
      
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public static void main(String[] args) throws Exception {
        QueryNoFilePageNumber query = new QueryNoFilePageNumber();
        query.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(QueryNoFilePageNumber.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        MongoUtils.init(pto);
        File file = new File(argParser.getOptString("file"));
        String dateRange = argParser.getOptString("t");
        
        int count = 0;
        PatentInfo2 info = null;
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = null;
        
        QueryHelp noExistsQuery = MongoUtils.getDateRange(dateRange);
        noExistsQuery.filter("filePageNumber", new QueryHelp("$exists", false));
        log.debug(noExistsQuery.toString());
        cursor = col.find(noExistsQuery).sort(new BasicDBObject("doDate", 1));
        while (cursor.hasNext()) {
            try {
                DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                log.debug(info.patentNumber);
                count++;
                String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                FileUtil.writeInfo(file, message, true);
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
        
        QueryHelp eqZeroQuery = MongoUtils.getDateRange(dateRange); 
        eqZeroQuery.filter("filePageNumber", 0);
        log.debug(eqZeroQuery.toString());
        cursor = col.find(eqZeroQuery).sort(new BasicDBObject("doDate", 1));
        while (cursor.hasNext()) {
            try {
                DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                log.debug(info.patentNumber);
                count++;
                String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                FileUtil.writeInfo(file, message, true);
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
        log.debug("count: " + count);
    }
}
