package itec.common.check;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Group CNIPR missing fullPage text
 * 
 * @author yiyunsun 2015.05.13
 */
public class GroupList {
    
    static Log log = LogFactory.getLog(GroupList.class);
    private String filePath = "./log/CNIPR/2014.txt";
    
    public static void main(String[] args) throws Exception {
        GroupList group = new GroupList();
        group.execute();
    }
    
    public void execute() throws Exception {
        HashMap<String, ArrayList<String>> map = new HashMap<>();
        List<String> list = FileUtils.readLines(new File(filePath));
        for (String line: list) {
            String[] arr = line.split(";");
            String patentNumber = arr[1].trim();
            String date = arr[2].trim();
            
            if (!map.containsKey(date)) {
                map.put(date, new ArrayList<String>());
            }
            map.get(date).add(patentNumber);
        }
        
        for (String date: map.keySet()) {
            log.debug(date + " : " + map.get(date).size());
//            System.out.println(date + " " + map.get(date).size());
        }
    }
}
