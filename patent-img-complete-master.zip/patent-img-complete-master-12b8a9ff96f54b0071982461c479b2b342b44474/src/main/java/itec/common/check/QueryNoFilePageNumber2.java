package itec.common.check;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class QueryNoFilePageNumber2 {
	
	static Log log = LogFactory.getLog(QueryNoFilePageNumber2.class);
	
	public static final String PTO = "pto";
	public static final String PTO_DEFAULT = "JPO";
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "./log/JPO/2007.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "./log/JPO/error.txt";
    
    public static ArgParser.Option[] opts = {
    	new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws Exception {
		QueryNoFilePageNumber2 query = new QueryNoFilePageNumber2();
		query.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(QueryNoFilePageNumber2.class).parse(args);
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}		
		
		Pto pto = Pto.valueOf(argParser.getOptString("pto"));
		MongoUtils.init(pto);
	    File file = new File(argParser.getOptString("file"));
	    File errorFile = new File(argParser.getOptString("error.file"));
	    
	    if (!file.exists()) {
            String dateRange = argParser.getOptString("t");
            QueryHelp query = MongoUtils.getDateRange(dateRange);
            DBCollection col = PatentInfo2.getCollection(pto);
            DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                PatentInfo2 info = null;
                try {
                    DBObject dbobj = cursor.next();
                    info = PatentInfo2.fromObject(pto, dbobj);
                    String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                    FileUtil.writeInfo(file, message, true);
                } catch (Exception e) {
                    log.debug(e, e);
                }
            }
        } 
	    
	    List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                
                if (info.filePageNumber == null || info.filePageNumber == 0) {
                	String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                	log.debug(message);
                	FileUtil.writeInfo(errorFile, message, true);
                }
                pe.addNum().debug(log, 10000, sdf.format(info.doDate)); 
            } catch (Exception e) {
            	log.debug(e, e);
            }
        }
	}
}
