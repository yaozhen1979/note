package itec.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class JPOUtils {

    static Log log = LogFactory.getLog(JPOUtils.class);

    public static String Jplatpat_home = "https://www7.j-platpat.inpit.go.jp";
    public static String Jplatpat_search = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_Top.action";
    
    public static int SEARCH_COUNT = 1;
    public static int SEARCH_RESULT = 2;
    
    public static String DETAILED_TEXT = "01";	// 項目表示
    public static String DETAILED_PDF = "02";	// PDF表示

	public class JPDownloadObj {
		public String name;
		public String checkList;
		public String checkListValue;
		public String searchItemList;
		public String searchNumber;
	}
	
	public JPDownloadObj getJPDownloadObj(String number) {
		JPDownloadObj obj = new JPDownloadObj();
		Matcher mat = null;
		
		mat = Pattern.compile("特開平(\\d{2})-(\\d+)").matcher(number);	// 52b2d92497d80a7436dcd070 ; 特開平06-025589 ; 1994-02-01
		if (mat.find())  {
			obj.name = "特開平";
			int year = Integer.parseInt(mat.group(1));
        	obj.searchNumber = String.valueOf((1988 + year)) + mat.group(2);
        	obj.searchItemList = "31";	// 公開番号
        	obj.checkList = "bTmFCOMDTO.officialInfoList[0]";
        	obj.checkListValue = "01";
			return obj;
		}
		
		mat = Pattern.compile("実公平(\\d{2})-(\\d+)").matcher(number);	// 52b2fad197d80a7436e55233 ; 実公平06-049030 ; 1994-12-12
		if (mat.find()) {
			obj.name = "実公平";
			int year = Integer.parseInt(mat.group(1));
        	obj.searchNumber = String.valueOf((1988 + year)) + mat.group(2);
        	obj.searchItemList = "33";	// 公告番号
        	obj.checkList = "bTmFCOMDTO.officialInfoList[4]";
        	obj.checkListValue = "05";
			return obj;
		}
		
		mat = Pattern.compile("実登(\\d+)").matcher(number);	// 52b3f73d9ddebb0bf448c481 ; 実登2592273 ; 1999-03-17
		if (mat.find()) {
			obj.name = "実登";
			obj.searchNumber = mat.group(1);
			obj.searchItemList = "35";	// 登録番号
			obj.checkList = "bTmFCOMDTO.officialInfoList[4]";
        	obj.checkListValue = "05";
			return obj;
		}
		
		mat = Pattern.compile("特開(\\d{4})-(\\d+)").matcher(number);	// 52b47331fb5a67e84a931180 ; 特開2002-116228 ; 2002-04-19
		if (mat.find()) {
			obj.name = "特開";
			obj.searchNumber = mat.group(1) + mat.group(2);
			obj.searchItemList = "31";		// 公開番号
			obj.checkList = "bTmFCOMDTO.officialInfoList[0]";
        	obj.checkListValue = "01";
			return obj;
		}
		
		mat = Pattern.compile("特許(\\d+)").matcher(number);	// 52b3c6fb9ddebb0bf440013c ; 特許2718197 ; 1998-02-25
		if (mat.find()) {
			obj.name = "特許";
			obj.searchNumber = mat.group(1);
			obj.searchItemList = "35";		// 登録番号
			obj.checkList = "bTmFCOMDTO.officialInfoList[1]";
			obj.checkListValue = "02";
			return obj;
		}
		
		mat = Pattern.compile("特公平(\\d{2})-(\\d+)").matcher(number); // 52b3232e97d80a7436effe41 ; 特公平08-026747 ; 1996-03-21
		if (mat.find()) {
			obj.name = "特公平";
			int year = Integer.parseInt(mat.group(1));
        	obj.searchNumber = String.valueOf((1988 + year)) + mat.group(2);
        	obj.searchItemList = "33";	// 公告番号
        	obj.checkList = "bTmFCOMDTO.officialInfoList[1]";
			obj.checkListValue = "02";
        	return obj;
		}
		
		mat = Pattern.compile("実開(\\d{4})-(\\d+)").matcher(number);	// 52b4c607fb5a67e84aa284a3 ; 実開2004-000006 ; 2004-04-02
		if (mat.find()) {
			obj.name = "実開";
			obj.searchNumber = mat.group(1) + mat.group(2);
			obj.searchItemList = "31";	// 公開番号
			obj.checkList = "bTmFCOMDTO.officialInfoList[3]";
			obj.checkListValue = "04";
			return obj;
		}
		
		mat = Pattern.compile("実開平(\\d{2})-(\\d+)").matcher(number); // 52b3259997d80a7436f09cfd ; 実開平08-000565 ; 1996-04-02
		if (mat.find()) {
			obj.name = "実開平";
			int year = Integer.parseInt(mat.group(1));
        	obj.searchNumber = String.valueOf((1988 + year)) + mat.group(2);
        	obj.searchItemList = "31";	// 公開番号
        	obj.checkList = "bTmFCOMDTO.officialInfoList[3]";
			obj.checkListValue = "04"; 
			return obj;
		}
		
		return null;
	}
	
	public static String getJplatepatSession(String content) {
        String tempSession = null;
        Matcher mat = Pattern.compile("<div id=\"jplatpatSession\".*?>(.*?)</div>", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            tempSession = mat.group(1);
        }
        return tempSession;
    }
}
