package itec.common.utils;

import itec.patent.mongodb.PatentInfo2;

import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class USPTOUtils {
    
    static Log log = LogFactory.getLog(USPTOUtils.class);
    
    public static String formatUSPTOPatentNumber(String patentNumber) throws UnsupportedEncodingException {
        Matcher zeroMat = Pattern.compile("US0*(\\w+)", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
        if (zeroMat.find()) {
            patentNumber = zeroMat.group(1);
        }
        if (patentNumber.length() > 8) {    // publication patent number
            return patentNumber;
        }
        
        String formatNumber = null;
        try {
            Matcher mat = Pattern.compile("(\\D*)(\\d+)", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
            if (mat.find()) {
                String type = mat.group(1);
                String number = mat.group(2);
                int zeroLength = 8 - type.length() - number.length();
                String zeros = "";
                for (int i = 0; i < zeroLength; i++) {
                    zeros = zeros + 0;
                }
                formatNumber = String.format("%s%s%s", type, zeros, number);
            }
            return formatNumber;
        } catch (Exception e) {
            throw new UnsupportedEncodingException("unsupported patent number for USPTO patent: " + patentNumber);
        }
    }
    
    public static String formatGooglePatentNumber(PatentInfo2 info) throws UnsupportedEncodingException {
        String pn;
        switch (info.pto) {
        case US:
        case USPTO:
            pn = info.patentNumber.replaceAll("(?i)^(US)?0*", "US");
            break;
        default:
            throw new UnsupportedEncodingException("unsupported pto for google patent: " + info.pto);
        }
        return pn;
    }
    
    private static final String FULLPAGE_PAT_URL = "http://pimg-fpiw.uspto.gov/fdd";
    private static final String FULLPAGE_APP_URL = "http://pimg-faiw.uspto.gov/fdd";
    /**
     *  publication
     *  url:    http://pimg-faiw.uspto.gov/fdd/54/2014/05/025/0.pdf
     *  eg: 20140250554     /54/2014/05/025/0.pdf
     *  
     *  grant
     *  url:    http://pimg-fpiw.uspto.gov/fdd/21/543/076/0.pdf
     *  eg: 7654321         /21/543/076/0.pdf
     *  eg: D697290         /90/972/D06/0.pdf
     *  eg: RE044728        /28/447/RE0/0.pdf
     *  eg: PP24165         /65/241/PP0/0.pdf
     */
    public static String makeFullPageUrl(Integer stat, String patentNumber) {
        String ret = null;
        Matcher mat;
        try {
            if (stat == 1) {
                mat = Pattern.compile("(\\d{4})(\\d{3})(\\d{2})(\\d{2})", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
                if (mat.find()) {
                    ret = String.format("%s/%s/%s/%s/%s/0.pdf", FULLPAGE_APP_URL, mat.group(4), mat.group(1), mat.group(3), mat.group(2));
                }
            } else {
                mat = Pattern.compile("(\\w{3})(\\d{3})(\\d{2})", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
                if (mat.find()) {
                    ret = String.format("%s/%s/%s/%s/0.pdf", FULLPAGE_PAT_URL, mat.group(3), mat.group(2), mat.group(1));
                }
            }
            return ret;
        } catch (Exception e) {
            throw new IllegalArgumentException("make fullPage url error, patentNumber: " + patentNumber);
        }
    }
}
