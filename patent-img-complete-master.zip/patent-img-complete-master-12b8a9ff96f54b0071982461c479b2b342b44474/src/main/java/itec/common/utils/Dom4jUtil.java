package itec.common.utils;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;

/**
 * Dom4j parse XML utils
 * 
 * @author yiyun 2014.12.25
 */
public class Dom4jUtil {
    
    public static SAXReader reader;
    public static SAXReader getSAXReader() {
        if (reader == null) {
            reader = new SAXReader();
        }
        return reader;
    }
    
    public static Document parseDocument(File file) throws DocumentException {
        return getSAXReader().read(file);
    }
    
    public static Document parseDocument(InputStream is) throws DocumentException {
        return getSAXReader().read(is);
    }
    
    public static Document parseDocument(InputSource is) throws DocumentException {
        return getSAXReader().read(is);
    }
    
    public static Document parseDocument(String url) throws DocumentException {
        return getSAXReader().read(url);
    }

    public static Element selectSingleElement(Document document, String... eleNames) {
        String xpath = getXPath(eleNames);
        return (Element) document.selectSingleNode(xpath);
    }

    @SuppressWarnings("unchecked")
    public static List<Element> selectElementList(Document document, String... eleNames) {
        String xpath = getXPath(eleNames);
        return (List<Element>) document.selectNodes(xpath);
    }
    
    public static Element selectSingleElement(Element element, String... eleNames) {
        if (element != null) {
            List<Element> list =  selectElementList(element, eleNames);
            if (list.size() > 0) {
                return list.get(0);
            }
        }
        return null;
    }
    
    public static List<Element> selectElementList(Element element, String... eleNames) {
        LinkedList<String> list = new LinkedList<>();
        for (String eleName: eleNames) {
            list.add(eleName);
        }
        return selectElementList(element, list);
    }
    
    @SuppressWarnings("unchecked")
    public static List<Element> selectElementList(Element element, LinkedList<String> list) {
        List<Element> eleList = new ArrayList<Element>();
        if (list.size() > 0) {
            String eleName = list.removeFirst();
            eleList = element.elements(eleName);
            
            if (list.size() > 0) {
                List<Element> totleEleList = new ArrayList<>();
                for (Element subELe: eleList) {
                    String[] names = list.toArray(new String[] {});
                    totleEleList.addAll(selectElementList(subELe, names));
                }
                return totleEleList;
            } 
            return eleList;
        }
        return eleList;
    }
    
    public static String getElementValue(Element element, String tagName) {
        if (element != null) {
            Element subElement = element.element(tagName);
            return subElement != null ? subElement.getTextTrim() : null;
        } 
        return null;
    }
    
    public static String getElementXml(Element element) {
        if (element != null) {
            String value = element.asXML();
            value = value.substring(value.indexOf(">") + 1, value.lastIndexOf("<")).trim();
            return value;
        }
        return null;
    }
    
    public static String getAttributeValue(Element element, String attrName) {
        if (element != null) {
            Attribute attr = element.attribute(attrName);
            return attr != null ? attr.getText() : null;
        }
        return null;
    }
    
    public static String getXPath(String... eleNames) {
        String xpath = "";
        for (String name: eleNames) {
            xpath = xpath.equals("") ? xpath + name : xpath + "/" + name;
        }
        return xpath;
    }
}
