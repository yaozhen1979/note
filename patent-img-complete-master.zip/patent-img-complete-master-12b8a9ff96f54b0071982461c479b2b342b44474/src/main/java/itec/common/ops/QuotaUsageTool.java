package itec.common.ops;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.tsaikd.java.utils.WebClient;

public class QuotaUsageTool {
    
    private static Log log = LogFactory.getLog(QuotaUsageTool.class);
     
    public String query() throws Exception {
        OPSAuthTool auth = new OPSAuthTool();
        CloseableHttpClient httpClient = WebClient.newHttpClient();
        HttpGet method = new HttpGet("https://ops.epo.org/3.1/developers/me/stats/usage?timeRange=09/09/2015~15/09/2015");
        method.addHeader("Authorization", "Bearer " + auth.accessToken());
        
        HttpResponse cliRes = httpClient.execute(method);
        
        int resCode = cliRes.getStatusLine().getStatusCode();
        log.debug("resCode:" + resCode);
        String resData = EntityUtils.toString(cliRes.getEntity(), "UTF-8");
        log.debug(resData);
        return resData;
    }
    
    public static void main(String[] args) throws Exception {
        QuotaUsageTool tool = new QuotaUsageTool();
        tool.query();
    }
}
