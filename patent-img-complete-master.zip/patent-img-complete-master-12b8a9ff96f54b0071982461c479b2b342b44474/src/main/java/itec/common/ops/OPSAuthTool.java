package itec.common.ops;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.WebClient;

public class OPSAuthTool {
    
    private static Log log = LogFactory.getLog(OPSAuthTool.class);
    
    private static String token;
    private static long expiresTimestamp;
    
    private String consumerKey;
    private String consumerSecret;
    
    public OPSAuthTool() {
        consumerKey = ConfigUtils.get("epo.consumer.key");
        consumerSecret = ConfigUtils.get("epo.consumer.secret.key");
    }

    public OPSAuthTool(String consumerKey, String consumerSecret) {
        this.consumerKey = consumerKey;
        this.consumerSecret = consumerSecret;
    }
    
    public String accessToken() {
        try {
            return accessToken(false);
        } catch (Exception e) {
            log.debug(e, e);
            return null;
        }
    }
    
    public String accessToken(boolean force) throws Exception {
        if (!force) {
            //若沒過期，則重複使用 token
            if (token != null && System.currentTimeMillis() < expiresTimestamp) {
//                log.debug("token don't expires, use hold token!");
                return token;
            }
        }
        long currTime = System.currentTimeMillis();
        String authKey = Base64.encodeBase64String((consumerKey + ":" + consumerSecret).getBytes());
        CloseableHttpClient httpClient = WebClient.newHttpClient();
        HttpPost method = new HttpPost("https://ops.epo.org/3.1/auth/accesstoken");
        method.addHeader("Authorization", "Basic " + authKey);
        
        StringEntity input = new StringEntity("grant_type=client_credentials");
        input.setContentType("application/x-www-form-urlencoded");
        method.setEntity(input);
        
        HttpResponse cliRes = httpClient.execute(method);
        
        int resCode = cliRes.getStatusLine().getStatusCode();
        //log.debug("resCode:" + resCode);
        String resData = EntityUtils.toString(cliRes.getEntity(), "UTF-8");
        //log.debug(resData);
        Header[] headers = cliRes.getAllHeaders();
//        for (Header h : headers) {
//            log.debug(h.getName() + ":" + h.getValue());
//        }
        JSONObject object = new JSONObject(resData);
        token = object.getString("access_token");
        int expires = 15 * 60;
        try {
            expires = Integer.parseInt(object.getString("expires_in"));
        } catch (Exception e) {
            log.debug(e, e);
        }
        expiresTimestamp = currTime + expires * 1000;
        return token;
    }

}
