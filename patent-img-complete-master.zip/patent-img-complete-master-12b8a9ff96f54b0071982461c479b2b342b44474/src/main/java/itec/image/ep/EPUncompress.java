package itec.image.ep;

import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;

/**
 * EP source zip uncompress
 * 
 * Execute jar 
 * 		java -jar EPUncompress.jar -source S:/originaldata/EP/disk/1413_backfile_ep_bin_pdf/B/1994 -target E:/EPO (-start 199401.zip)
 * 
 * @author yiyunsun 2015.09.01
 */
public class EPUncompress {
	
	static Log log = LogFactory.getLog(EPUncompress.class);
	
	public static final String SOURCE = "source";
    public static final String SOURCE_DEFAULT = "S:/originaldata/EP/disk/1413_backfile_ep_bin_pdf/B/1994";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "E:/EPO";
    
    public static final String START = "start";
    public static final String START_DEFAULT = "";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, SOURCE, true, SOURCE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, ""),
        new ArgParser.Option(null, START, true, START_DEFAULT, ""),};
	
	public static void main(String[] args) throws Exception {
		EPUncompress uncompress = new EPUncompress();
		uncompress.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(EPUncompress.class).parse(args);
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}
		String source = argParser.getOptString("source");
		String target = argParser.getOptString("target");
		String start = argParser.getOptString("start");
		
		File sourceFile = new File(source);
		List<String> fileList = new ArrayList<>();
		if (start != null && !start.isEmpty()) {
			fileList = FileUtil.getFileRange(sourceFile, start, "");
		} else {
			File[] files = sourceFile.listFiles();
			for (File file: files) {
				fileList.add(file.getAbsolutePath());
			}
		}
		
		for (String filePath: fileList) {
			uncompress(filePath, target);
			log.debug("uncompress success, path: " + filePath);
		}
	}
	
	public void uncompress(String sourcePath, String targetPath) {
		FileInputStream fis = null;
        ZipInputStream zis = null;
        FileOutputStream fos = null;
        ZipEntry entry = null;
        try {
            File sourceFile = new File(sourcePath);
            fis = new FileInputStream(sourceFile);
            zis = new ZipInputStream(fis);
            while ((entry = zis.getNextEntry()) != null) {
                int count = 0;
                byte[] data = new byte[1024];
                
                String entryName = new File(entry.getName()).getName();
                String fileName = "";
                String date = "";
                Matcher mat = Pattern.compile("(\\w+)(\\d{8}).pdf").matcher(entryName);
                if (mat.find()) {
                	fileName = mat.group(1);
                	date = mat.group(2);
                }
                		
                String target = Paths.get(targetPath).resolve(date).resolve(fileName + ".pdf").toString();
                File file = mkFile(target);
                fos = new FileOutputStream(file);
                while ((count = zis.read(data, 0, 1024)) != -1) {
                    fos.write(data, 0, count);
                }
                fos.flush();
                fos.close();
            }
        } catch (IOException e) {
            log.debug(e, e);
        } finally {
            try {
                fis.close();
                zis.close();
            } catch (Exception e) {
               log.debug(e, e);
            }
        }
	}
	
	public static File mkFile(String fileName) {
        File file = new File(fileName);
        try {
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            file.createNewFile();
        } catch (IOException e) {
            log.debug(e, e);
        }
        return file;
    }
}
