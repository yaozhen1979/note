package itec.image.ep;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.SimpleBookmark;

/**
 * EP Complete from Source File
 * 
 * Execute jar
 * 		java -jar EPComplete.jar -file log/EPO/test.txt -error.file log/EPO/error.txt -source E:/EPO	
 * 
 * @author yiyunsun 2015.08.28
 */
public class EPComplete {

	static Log log = LogFactory.getLog(EPComplete.class);
	
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/EPO/1992.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/EPO/error.txt";
    
    public static final String SOURCE = "source";
    public static final String SOURCE_DEFAULT = "S:/originaldata/EP/compress/1992";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, SOURCE, true, SOURCE_DEFAULT, "")};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd");

	public static void main(String[] args) throws Exception {
		EPComplete complete = new EPComplete();
		complete.execute(args);
	}

	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(EPComplete.class).parse(args);
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}
		
		Pto pto = Pto.valueOf("EPO");
		MongoUtils.init(pto);
		Path sourcePath = Paths.get(argParser.getOptString("source"));
		Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
		File file = new File(argParser.getOptString("file"));
		File errorFile = new File(argParser.getOptString("error.file"));
		
		List<String> list = FileUtils.readLines(file);
		ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
		for (String line: list) {
			try {
				String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                String number = info.patentNumber;
                
                File patFile = null;
                LinkedList<File> fileList = new LinkedList<>();
                fileList.add(sourcePath.resolve(number + ".pdf").toFile());
                fileList.add(sourcePath.resolve(sdf2.format(info.doDate)).resolve(number + ".pdf").toFile());
                fileList.add(sourcePath.resolve(sdf2.format(info.doDate)).resolve(number + sdf2.format(info.doDate) + ".pdf").toFile());
                for (File pFile: fileList) {
                	if (pFile.exists()) {
                		patFile = pFile;
                		break;
                	}
                }
                
                if (patFile != null && patFile.exists()) {
                	FileInputStream fis = null;
                    FileOutputStream fos = null;
                    try {
                    	String tarPath = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf");
                    	File tarFile = new File(tarPath);
                        FileUtil.sureDirExists(tarFile, true);
                        fis = new FileInputStream(patFile);
                        fos = new FileOutputStream(tarFile);
                        IOUtils.copy(fis, fos);
                        
                        PdfReader pdfReader = new PdfReader(patFile.getAbsolutePath());
                        info.filePageNumber = pdfReader.getNumberOfPages();
                        List<?> bookmarks = SimpleBookmark.getBookmark(pdfReader);
                        if (bookmarks != null && bookmarks.size() > 0) {
                        	for (Iterator<?> i = bookmarks.iterator (); i.hasNext ();) {
                                 HashMap<?,?> bookMark = (HashMap<?,?>) i.next();
                                 String title = ((String) bookMark.get("Title")).toLowerCase();
                                 String page = (String) bookMark.get("Page");
                                 Matcher mat = Pattern.compile("(\\d+)\\s+.*?").matcher(page);
                                 if (mat.find()) {
                                	 int pageNumber = Integer.parseInt(mat.group(1).trim());
                                	 if (title.equals("abstract") || title.equals("bibliography") || title.equals("bibliographie")) {
                                    	 info.filePageFirst = pageNumber;
                                     } else if(title.equals("description") || title.equals("beschreibung")) {
                                    	 info.filePageDesc = pageNumber;
                                     } else if(title.equals("claims") || title.equals("ansprüche") || title.equals("revendications")) {
                                    	 info.filePageClaim = pageNumber;
                                     } else if(title.equals("drawings") || title.equals("zeichnungen") || title.equals("dessins")) {
                                    	 info.filePageFig = pageNumber;
                                     }
                                 }
                              }
                        }
                    	info.save();    
                    } catch (IOException ioe) {
                    	log.debug(ioe, ioe);
                    } finally {
                    	if (fis != null) {
                    		fis.close();
                    		fis = null;
                    	}
                    	if (fos != null) {
                    		fos.close();
                    		fos = null;
                    	}
                    }
                } else {
                    log.debug(line);
                    FileUtil.writeInfo(errorFile, line, true);
                }
                
                pe.addNum().debug(log, 10000, sdf.format(info.doDate));
			} catch (Exception e) {
				log.debug(e, e);
       		 	FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
			}
		}
	}
}
