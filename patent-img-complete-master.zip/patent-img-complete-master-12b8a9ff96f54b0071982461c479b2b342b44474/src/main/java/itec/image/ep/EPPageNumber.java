package itec.image.ep;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.SimpleBookmark;

/**
 * EP filePageNumber complete, some patent has fullPage.pdf but no filePageNumber
 * 
 * Execute jar 
 * 		java -jar EPPageNumber.jar -file log/EPO/test.txt -error.file log/EPO/error.txt 
 * 
 * @author yiyunsun 2015.08.31
 */
public class EPPageNumber {
	
	static Log log = LogFactory.getLog(EPPageNumber.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/EPO/filePageNumber/2003.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/EPO/error.txt";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
	public static void main(String[] args) throws Exception {
		EPPageNumber pageNumber = new EPPageNumber();
		pageNumber.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(EPPageNumber.class).parse(args);
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}
		
		Pto pto = Pto.valueOf("EPO");
		MongoUtils.init(pto);
		Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
		File file = new File(argParser.getOptString("file"));
		File errorFile = new File(argParser.getOptString("error.file"));
		
		List<String> list = FileUtils.readLines(file);
		ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
		for (String line: list) {
			try {
				String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                
                String path = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf"); 
                File imageFile = new File(path);
                if (imageFile.exists()) {
                	PdfReader pdfReader = new PdfReader(imageFile.getAbsolutePath());
                    info.filePageNumber = pdfReader.getNumberOfPages();
                    
                    List<?> bookmarks = SimpleBookmark.getBookmark(pdfReader);
                    if (bookmarks != null && bookmarks.size() > 0) {
                    	for (Iterator<?> i = bookmarks.iterator (); i.hasNext ();) {
                             HashMap<?,?> bookMark = (HashMap<?,?>) i.next();
                             String title = ((String) bookMark.get("Title")).toLowerCase();
                             String page = (String) bookMark.get("Page");
                             if (page == null) {
                            	 continue;
                             }
                             Matcher mat = Pattern.compile("(\\d+)\\s+.*?").matcher(page);
                             if (mat.find()) {
                            	 int pageNumber = Integer.parseInt(mat.group(1).trim());
                            	 if (title.equals("abstract") || title.equals("bibliography") || title.equals("bibliographie")) {
                                	 info.filePageFirst = pageNumber;
                                 } else if(title.equals("description") || title.equals("beschreibung")) {
                                	 info.filePageDesc = pageNumber;
                                 } else if(title.equals("claims") || title.equals("ansprüche") || title.equals("revendications")) {
                                	 info.filePageClaim = pageNumber;
                                 } else if(title.equals("drawings") || title.equals("zeichnungen") || title.equals("dessins")) {
                                	 info.filePageFig = pageNumber;
                                 }
                             }
                          }
                    }
                	info.save(); 
                } else {
                    FileUtil.writeInfo(errorFile, line, true);
                }
                pe.addNum().debug(log, 10000, sdf.format(info.doDate));
			} catch (Exception e) {
				log.debug(e, e);
				FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
			}
		}
	}
}
