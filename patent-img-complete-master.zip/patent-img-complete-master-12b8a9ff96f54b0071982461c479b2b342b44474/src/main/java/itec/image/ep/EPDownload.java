package itec.image.ep;

import itec.common.ops.OPSAuthTool;
import itec.common.utils.Dom4jUtil;
import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.bson.types.ObjectId;
import org.dom4j.Document;
import org.dom4j.Element;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;
import org.tsaikd.java.utils.WebClient;

/**
 * EP download fullImage from OPS
 * 
 * Execute jar 
 * 		java -jar EPDownload.jar -file log/EPO/test.txt -error.file log/EPO/error.txt -target E:/EPO
 * 
 * @author yiyunsun 2015.09.02
 */
public class EPDownload {
	
	static Log log = LogFactory.getLog(EPDownload.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/EPO/2006.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/EPO/error.txt";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "E:/EPO";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, "")};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws Exception {
		EPDownload download = new EPDownload();
		download.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(EPDownload.class).parse(args);
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}
		
		Pto pto = Pto.valueOf("EPO");
		MongoUtils.init(pto);
		Path targetPath = Paths.get(argParser.getOptString("target"));
		File file = new File(argParser.getOptString("file"));
		File errorFile = new File(argParser.getOptString("error.file"));
		
		List<String> list = FileUtils.readLines(file);
		ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
		for (String line: list) {
			try {
				String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                pe.addNum().debug(log, 10000, sdf.format(info.doDate));
                
                String number = formatNumber(info.patentNumber);
                if (number == null) {
                	log.debug("invalid format " + line);
                	FileUtil.writeInfo(errorFile, line + " invalid format", true);
                	continue;
                }
                
                String imageDescUrl = "https://ops.epo.org/rest-services/published-data/publication/epodoc/images";
                HttpPost method = new HttpPost(imageDescUrl);
                method.setEntity(new StringEntity(number));
                method.addHeader("Authorization", "Bearer " + getToken());
                
                HttpResponse cliRes = getClient().execute(method);
                int resCode = cliRes.getStatusLine().getStatusCode();
                if (resCode != 200) {
                	log.debug("Post error, res: " + cliRes.getStatusLine());
                	FileUtil.writeInfo(errorFile, line + " post error", true);
                	continue;
                }
                HttpEntity entity = cliRes.getEntity();
                String content = EntityUtils.toString(entity, "UTF-8");
                EntityUtils.consume(entity);
                
                Document doc = Dom4jUtil.getSAXReader().read(new ByteArrayInputStream(content.getBytes("UTF-8")));
                List<Element> docEles = Dom4jUtil.selectElementList(doc.getRootElement(), "document-inquiry", "inquiry-result", "document-instance");
                for (Element docEle: docEles) {
                	String attrValue = Dom4jUtil.getAttributeValue(docEle, "desc");
                	String link = Dom4jUtil.getAttributeValue(docEle, "link");
                	
                	if ("FullDocument".equals(attrValue) && link.contains("EP")) {
                		String pageNum = Dom4jUtil.getAttributeValue(docEle, "number-of-pages");
                		
                		if ("1".equals(pageNum)) {
                			String imageUrl = "https://ops.epo.org/rest-services/" + link + ".pdf?Range=1";
                			String tarPath = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf");
                			
                			HttpGet getMethod = new HttpGet(imageUrl);
                			getMethod.addHeader("Authorization", "Bearer " + getToken());
                			HttpResponse response = getClient().execute(getMethod);
                			resCode = response.getStatusLine().getStatusCode();
                			
                			HttpEntity imgEntity = response.getEntity();
                			InputStream is = imgEntity.getContent();
                			File tarFile = new File(tarPath);
                			FileUtil.sureDirExists(tarFile, true);
                			FileOutputStream fos = new FileOutputStream(tarFile);
                			IOUtils.copy(is, fos);
                			if (is != null) {
                				is.close();
                				is = null;
                			}
                			if (fos != null) {
                				fos.close();
                				fos = null;
                			}
                			EntityUtils.consume(imgEntity);
                			
                			info.filePageNumber = 1;
                			info.save();
                		} else {
                			log.debug("more than 1 page number " + line);
                			FileUtil.writeInfo(errorFile, line + " more than 1page number", true);
                		}
                		break;
                	}
                }
			} catch (Exception e) {
				log.debug(e, e);
       		 	FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
			}
		}
	}
	
	public String formatNumber(String number) {
		String ret = null;
		Matcher mat = Pattern.compile("EP(\\d+)(\\w+)").matcher(number);
		if (mat.find()) {
			ret = String.format("EP.%s.%s", mat.group(1), mat.group(2));
		}
		return ret;
	}
	
	private OPSAuthTool tool;
    public String getToken() {
        if (tool == null) {
            tool = new OPSAuthTool();
        }
        String token = tool.accessToken();
        return token;
    }
    
    private CloseableHttpClient client;
    public CloseableHttpClient getClient() {
    	if (client == null) {
    		client = WebClient.newHttpClient();
    	}
    	return client;
    }
}
