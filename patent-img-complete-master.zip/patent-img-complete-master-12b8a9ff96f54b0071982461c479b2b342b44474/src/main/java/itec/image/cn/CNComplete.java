package itec.image.cn;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

public class CNComplete {
    
    static Log log = LogFactory.getLog(CNComplete.class);
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "./log/CNIPR/2014.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "./log/CNIPR/error.txt";
    
    public static final String SOURCE = "source";
    public static final String SOURCE_DEFAULT = "P:/originaldata/CN/image/BOOKS";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "P:/originaldata/CN/CNIPR/20140827";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, SOURCE, true, SOURCE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, ""),};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public static void main(String[] args) throws Exception {
    	CNComplete complete = new CNComplete();
        complete.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(CNComplete.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("CNIPR");
        MongoUtils.init(pto);
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        Path sourcePath = Paths.get(argParser.getOptString("source"));
        Path targetPath = Paths.get(argParser.getOptString("target"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                File patFile = null;
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));;
                pe.addNum().debug(log, 10000, sdf.format(info.doDate)); 
                
                if (info.stat == 1) {
                    LinkedList<File> fileList = new LinkedList<>();
                    fileList.add(sourcePath.resolve(Paths.get("FM")).resolve(formatCNSourcePath(info)).toFile());
                    fileList.add(sourcePath.resolve(Paths.get("SD")).resolve(formatCNSourcePath(info)).toFile()); 
                    fileList.add(sourcePath.resolve(Paths.get("SQ")).resolve(formatCNSourcePath(info)).toFile()); 
                    fileList.add(sourcePath.resolve(Paths.get("XK")).resolve(formatCNSourcePath(info)).toFile()); 
                    fileList.add(sourcePath.resolve(Paths.get("XX")).resolve(formatCNSourcePath(info)).toFile()); 
                    for (File pFile: fileList) {
                        if (pFile.exists()) {
                            patFile = pFile;
                            break;
                        }
                    }
                } else {
                    if (info.type.equals("外观专利")) {
                        String file_year = "";
                        String file_week = "";
                        
                        String year = new SimpleDateFormat("yyyy").format(info.doDate);
                        if (Integer.parseInt(year) >= 2003) {
                            file_year = String.valueOf(Integer.parseInt(year.substring(2)) + 16);
                        } else {
                            file_year = year.substring(2);
                        }
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(info.doDate);
                        String week = String.valueOf(cal.get(Calendar.WEEK_OF_YEAR)); 
                        file_week = (week.length() == 1) ? 0 + week : week;
                        
                        patFile = sourcePath.resolve(Paths.get("WG")).resolve(formatCNWGSourcePath(info, file_year, file_week)).toFile();
                    } else {
                        LinkedList<File> fileList = new LinkedList<>();
                        fileList.add(sourcePath.resolve(Paths.get("FM")).resolve(formatCNSourcePath(info)).toFile()); 
                        fileList.add(sourcePath.resolve(Paths.get("SD")).resolve(formatCNSourcePath(info)).toFile()); 
                        fileList.add(sourcePath.resolve(Paths.get("SQ")).resolve(formatCNSourcePath(info)).toFile()); 
                        fileList.add(sourcePath.resolve(Paths.get("XK")).resolve(formatCNSourcePath(info)).toFile()); 
                        fileList.add(sourcePath.resolve(Paths.get("XX")).resolve(formatCNSourcePath(info)).toFile()); 
                        for (File pFile: fileList) {
                            if (pFile.exists()) {
                                patFile = pFile;
                                break;
                            }
                        }
                    }
                }
                
                if (patFile != null && patFile.exists()) {
                    List<String> imgFileList = new FileUtil().getFileList(patFile, "tif", "jpg");
                    if (imgFileList.size() > 0) {
                        info.filePageNumber = imgFileList.size();
                        
                        for (File srcImgFile: patFile.listFiles()) {
                            FileInputStream fis = null;
                            FileOutputStream fos = null;
                            try {
                                String fileName = null;
                                Matcher mat = Pattern.compile("0*(\\d+).(tif|jpg)", Pattern.CASE_INSENSITIVE).matcher(srcImgFile.getName());
                                if (mat.find()) {
                                    fileName = (mat.group(1) + "." + mat.group(2)).toLowerCase();
                                }
                                String tarPath = String.format("%s/%s/%s/%s"
                                        , targetPath.toString()
                                        , MongoUtils.getRelPatentPath(info)
                                        , "fullImage"
                                        , fileName);
                                
                                File tarFile = new File(tarPath);
                                FileUtil.sureDirExists(tarFile, true);
                                fis = new FileInputStream(srcImgFile);
                                fos = new FileOutputStream(tarFile);
                                IOUtils.copy(fis, fos);
                            } catch (IOException ioe) {
                                log.debug(ioe, ioe);
                            } finally {
                                if (fis != null) {
                                    fis.close();
                                    fis = null;
                                }
                                if (fos != null) {
                                    fos.close();
                                    fos = null;
                                }
                            }
                        }
                        info.save();
                    }
                } else {
                    String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                    log.debug(message);
                    FileUtil.writeInfo(errorFile, message, true);
                }
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
        pe.debug(log);
        log.debug("finish");
    }
    
    public String formatCNSourcePath(PatentInfo2 info) {
        return String.format("%s/%s/%s"
                , new SimpleDateFormat("yyyy").format(info.doDate)
                , new SimpleDateFormat("yyyyMMdd").format(info.doDate) + "bu"
                , info.patentNumber);
    }
    
    public String formatCNWGSourcePath(PatentInfo2 info, String fileYear, String fileWeek) {
        return String.format("%s/%s/%s"
                , new SimpleDateFormat("yyyy").format(info.doDate)
                , fileYear + fileWeek
                , info.patentNumber.replaceAll("\\.", ""));
    }
}
