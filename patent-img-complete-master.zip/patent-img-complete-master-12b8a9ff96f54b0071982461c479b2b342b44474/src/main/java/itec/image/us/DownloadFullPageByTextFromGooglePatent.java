package itec.image.us;

import itec.common.utils.MongoUtils;
import itec.common.utils.USPTOUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.util.FileUtil;
import itec.util.HttpUtil;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DBObject;

/**
 * Download fullPage.pdf from Google Patent by input text
 * 
 * execute jar:
 *      java -jar DownloadFullPageByTextFromGooglePatent.jar -file log/USPTO/2006.txt
 *      
 * @author yiyunsun 2015.05.04
 */
public class DownloadFullPageByTextFromGooglePatent {
    
    static Log log = LogFactory.getLog(DownloadFullPageByTextFromGooglePatent.class);
    
    public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "USPTO";
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/USPTO/2006.txt";
   
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/USPTO/error.txt";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, "")
    };
    
    public static void main(String[] args) throws Exception {
        DownloadFullPageByTextFromGooglePatent download = new DownloadFullPageByTextFromGooglePatent();
        download.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(DownloadFullPageByTextFromGooglePatent.class).parse(args);
        MongoInitUtils.nothing();
        MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                pe.addNum().debug(log, 10000, line);
                String id = line.split(";")[0].trim();
                DBObject dbobj = MongoObjectObjId.findOneDBObj(PatentInfoUSPTO.class, id);
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                
                String pn = USPTOUtils.formatGooglePatentNumber(info);
                String url = String.format("http://patentimages.storage.googleapis.com/pdfs/%1$s.pdf", pn);
                
                File pdfFile = targetPath.resolve(MongoUtils.getRelPatentPath(info)).resolve("fullPage.pdf").toFile();
                HttpUtil.downloadFile(url, pdfFile);
            } catch (Exception e) {
                log.debug(e, e);
                FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true); 
            }
        }
    }
}
