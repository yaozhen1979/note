package itec.image.us;

import itec.common.utils.USPTOUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.util.FileUtil;
import itec.util.HttpUtil;

import java.io.File;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class DownloadPageNumberByText {
    
    static Log log = LogFactory.getLog(DownloadFullPageByText.class);
    
    public static final String IMAGE_PAGE_PAT_URL = "http://pdfpiw.uspto.gov";
    public static final String IMAGE_PAGE_APP_URL = "http://pdfaiw.uspto.gov";
    
    public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "USPTO";
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/USPTO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "./log/USPTO/error.txt";
    
    public static void main(String[] args) throws Exception {
        DownloadPageNumberByText download = new DownloadPageNumberByText();
        download.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(DownloadPageNumberByText.class).parse(args);
        MongoInitUtils.nothing();
        MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                pe.addNum().debug(log, 10000, line);
                
                String id = line.split(";")[0].trim();
                DBObject dbobj = MongoObjectObjId.findOneDBObj(PatentInfoUSPTO.class, id);
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                String patentNumber = info.patentNumber;
                
                // withdrawn patent
                BasicDBObject ob = (BasicDBObject) dbobj.get("withdrawn");
                if (ob != null) {
                    log.debug("withdrawn " + patentNumber);
                    continue;
                }
                
                Integer stat = info.stat;
                patentNumber = USPTOUtils.formatUSPTOPatentNumber(patentNumber);
                
                String imagePageUrl = (stat == 1) 
                        ? IMAGE_PAGE_APP_URL + "/.aiw?Docid=" + patentNumber 
                        : IMAGE_PAGE_PAT_URL + "/.piw?Docid=" + patentNumber;
                String content = HttpUtil.getResponseAsString(imagePageUrl);
                
                // Error Message: Unable to locate
                if (content.contains("Error Message: Unable to locate")) {
                    log.debug("Unable to locate " + patentNumber);
                    continue;
                }
                
                // save page number
                content = StringUtils.substringBetween(content, "Sections", "</form>");
                Matcher mat = Pattern.compile("<nobr><big>.*?<a href=\"(.*?)\"><img.*?<b>(.*?)</b></font></a></nobr><br>", Pattern.DOTALL).matcher(content);
                while (mat.find()) {
                    String url = mat.group(1).trim();
                    String type = mat.group(2).trim();
                    url = (stat == 1) ? IMAGE_PAGE_APP_URL + url : IMAGE_PAGE_PAT_URL + url;
                    String section = HttpUtil.getResponseAsString(url);
                    
                    Integer num = null;
                    Integer pageNum = null;
                    Matcher numMat = Pattern.compile("<b>(.*?)of(.*?)pages").matcher(section);
                    if (numMat.find()) {
                         num = Integer.parseInt(numMat.group(1).trim());
                         pageNum = Integer.parseInt(numMat.group(2).trim());
                    }
                    switch (type) {
                    case "Front Page":      info.filePageFirst = num;   break;
                    case "Drawings":        info.filePageFig = num;     break;
                    case "Specifications":  info.filePageDesc = num;    break;
                    case "Claims":          info.filePageClaim = num;   break;
                    default:    break;  
                    }
                    info.filePageNumber = pageNum;
                }
                info.save();
            } catch (Exception e) {
                log.debug(e, e);
                FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
            }
        }
        pe.debug(log);
        log.debug("finish");
    }
}
