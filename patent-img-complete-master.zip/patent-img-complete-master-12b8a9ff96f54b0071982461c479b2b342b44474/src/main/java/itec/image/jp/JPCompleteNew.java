package itec.image.jp;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;

/**
 * JP complete 2015 new 
 * 
 * Execute jar
 * 		java -jar JPCompleteNew.jar -file log/JPO/test.txt -error.file log/JPO/error.txt -list.file log/JPO/U/04.txt 
 * 						-source S:/originaldata/JP/jpo/published_registered_utility_model_applications/2015/004
 * 
 * @author yiyunsun 2015.08
 */
public class JPCompleteNew {
	
	static Log log = LogFactory.getLog(JPCompleteNew.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/JPO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/JPO/error.txt";
    
    public static final String LIST_FILE = "list.file";
    public static final String LIST_FILE_DEFAULT = "log/JPO/JPNEW/U/04.txt";
    
    public static final String SOURCE = "source";
    public static final String SOURCE_DEFAULT = "S:/originaldata/JP/jpo/published_registered_utility_model_applications/2015/004";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, LIST_FILE, true, LIST_FILE_DEFAULT, ""),
        new ArgParser.Option(null, SOURCE, true, SOURCE_DEFAULT, "")};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws Exception {
		JPCompleteNew complete = new JPCompleteNew();
		complete.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(JPCompleteNew.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("JPO");
        MongoUtils.init(pto);
        Path sourcePath = Paths.get(argParser.getOptString("source"));
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        File listFile = new File(argParser.getOptString("list.file"));
        
        if (!listFile.exists()) {
        	List<String> pathList = new FileUtil().getFileList(sourcePath.toFile(), "pdf");
        	FileUtils.writeLines(listFile, pathList);
        }
        
        List<String> list = FileUtils.readLines(file);
        List<String> pathList = FileUtils.readLines(listFile);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                pe.addNum().debug(log, 10000, sdf.format(info.doDate));
                
                String number = formatNumber(info.patentNumber);
                if (number == null) {
                	log.debug(line + " invalid format");
                	FileUtil.writeInfo(errorFile, line, true);
                	continue;
                }
                
                File patFile = null;
                for (String path: pathList) {
                	String fileName = new File(path).getName();
                	if (fileName.equals(number + ".pdf")) {
                		patFile = new File(path);
                		break;
                	}
                }
                
                if (patFile != null && patFile.exists()) {
                	FileInputStream fis = null;
                    FileOutputStream fos = null;
                    try {
                    	String tarPath = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf");
                    	File tarFile = new File(tarPath);
                        FileUtil.sureDirExists(tarFile, true);
                        fis = new FileInputStream(patFile);
                        fos = new FileOutputStream(tarFile);
                        IOUtils.copy(fis, fos);
                        
                        PdfReader pdfReader = new PdfReader(tarPath);
                        info.filePageNumber = pdfReader.getNumberOfPages();
                    	info.save();    
                    } catch (IOException ioe) {
                    	log.debug(ioe, ioe);
                    } finally {
                    	if (fis != null) {
                    		fis.close();
                    		fis = null;
                    	}
                    	if (fos != null) {
                    		fos.close();
                    		fos = null;
                    	}
                    }
                } else {
                    log.debug(line);
                    FileUtil.writeInfo(errorFile, line, true);
                }
            } catch (Exception e) {
            	log.debug(e, e);
       		 	FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
            }
        }
	}
	
	public String formatNumber(String number) {
		Matcher mat = null;
		mat = Pattern.compile("特許(\\d+)").matcher(number);	// 52b7ae99439b3cbc7bcf8c61 ; 特許4790791 ; 2011-10-12
		if (mat.find()) {
			return "000" + mat.group(1);
		}
		mat = Pattern.compile("特開(\\d{4})-(\\d+)").matcher(number); // 52b783bc439b3cbc7bc99353 ; 特開2011-018566 ; 2011-01-27
		if (mat.find()) {
			return mat.group(1) + mat.group(2);
		}
		mat = Pattern.compile("実登(\\d+)").matcher(number);	// 52b78574439b3cbc7bc9dbbc ; 実登3165477 ; 2011-01-27
		if (mat.find()) {
			return "000" + mat.group(1);
		}
		return null;
	}
}
