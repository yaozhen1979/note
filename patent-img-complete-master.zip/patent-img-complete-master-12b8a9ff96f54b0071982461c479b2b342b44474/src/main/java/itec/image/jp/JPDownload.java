package itec.image.jp;

import itec.common.utils.JPOUtils;
import itec.common.utils.JPOUtils.JPDownloadObj;
import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;
import itec.util.HttpUtilWithSession;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;
import org.tsaikd.java.utils.WebClient;

/**
 * JP patent download except D2
 * 
 * Execute jar
 * 		java -jar JPDownload.jar -file log/JPO/test.txt -error.file log/JPO/error.txt -target E:/JPO
 * 
 * @author yiyunsun	2015.08
 */
public class JPDownload {
	
	static Log log = LogFactory.getLog(JPDownload.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "./log/JPO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "./log/JPO/error.txt";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "E:/JPO";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, "")};

    private HttpUtilWithSession httpUtils = null;
	
	public static void main(String[] args) throws Exception {
		JPDownload download = new JPDownload();
		download.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(JPDownload.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("JPO");
        MongoUtils.init(pto);
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        Path targetPath = Paths.get(argParser.getOptString("target"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        httpUtils = new HttpUtilWithSession();
        for (String line: list) {
        	try {
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                
                JPDownloadObj obj = new JPOUtils().getJPDownloadObj(info.patentNumber); 
                if (obj == null) {
                	FileUtil.writeInfo(errorFile, line, true);
                	continue;
                }
                
                String searchPage = httpUtils.getResponseAsString(JPOUtils.Jplatpat_search);
                String searchSession = JPOUtils.getJplatepatSession(searchPage);
                        
                String searchCountPage = searchResult(obj, searchSession, JPOUtils.SEARCH_COUNT);
                String countSession = JPOUtils.getJplatepatSession(searchCountPage); 
                
                String resultPage = searchResult(obj, countSession, JPOUtils.SEARCH_RESULT);
                String resultSession = JPOUtils.getJplatepatSession(resultPage); 
                
                String imagePage = searchDetail(resultSession);
                int pageNum = getPageNum(imagePage);
                if (pageNum > 0) {
                	String patentPath = MongoUtils.getRelPatentPath(info);
                    Path imagePath = targetPath.resolve(Paths.get(patentPath));
                	
                    for (int i = 1; i < pageNum + 1; i++) {
                    	if (i != 1) {
                            String pdfSession = JPOUtils.getJplatepatSession(imagePage);
                            imagePage = searchPDF(i, pdfSession);
                        }
                        String imageUrl = getImageUrl(imagePage);
                        String fileName = String.valueOf(i) + ".pdf";
                        Path path = imagePath.resolve("fullImage").resolve(fileName);
                         
                        Thread.sleep(2000);
                        downloadImage(imageUrl, path.toFile());
                    }
                    info.filePageNumber = pageNum;
                    info.save();
                } else {
                	FileUtil.writeInfo(errorFile, line, true);
                }
               
                pe.addNum().debug(log, 10000, line);
        	} catch (Exception e) {
        		log.debug(e, e);
                FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
        	}
        }
	}
    
    @SuppressWarnings("serial")
    public String searchResult(JPDownloadObj obj, String searchSession, int type) throws Exception {
        String url = null;
        switch (type) {
        case 1:
        	url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action";
        	break;
        case 2:
        	url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_SearchResult.action";
        	break;
        default:
        	break;	
        }
        
        HashMap<String, String> map = new HashMap<String, String>() { {
        	put("__checkbox_bTmFCOMDTO.officialInfoList[0]", "01");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04");
            put("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05");
            put("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06");
            put("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07");
            put("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[0]", "1");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[1]", "2");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[2]", "3");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[3]", "4");
            put("bTmFCOMDTO.fukumuFukumanaiList[0]", "01");
            put("bTmFCOMDTO.searchSystemList[0]", "01");
            put("bTmFCOMDTO.searchItemList[1]", "05");
            put("bTmFCOMDTO.fukumuFukumanaiList[1]", "01");
            put("bTmFCOMDTO.searchKeywordList[1]", "");
            put("bTmFCOMDTO.searchSystemList[1]", "01");
            put("bTmFCOMDTO.ronrishiki", "");
            put("bTmFCOMDTO.fillingRowCount", "2");
        } };
        map.put("jplatpatSession", searchSession);
        map.put("bTmFCOMDTO.searchKeywordList[0]", obj.searchNumber);
        map.put("bTmFCOMDTO.searchItemList[0]", obj.searchItemList);
        map.put(obj.checkList, obj.checkListValue);
        String resultPage = httpUtils.getResponseAsString(url, map);
        return resultPage;
    }
    
    @SuppressWarnings("serial")
    public String searchDetail(String resultSession) throws Exception {
        String url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM301_Detailed.action";
        HashMap<String, String> map = new HashMap<String, String>() { {
            put("bTmFCOMDTO.hyojiPtnValue", JPOUtils.DETAILED_PDF);
            put("bTmFCOMDTO.fillingCurrentBunkenIndex", "0");
        } };
        map.put("jplatpatSession", resultSession);
        String detailPage = httpUtils.getResponseAsString(url, map);
        return detailPage;
    }
    
    public Integer getPageNum(String content) {
        Integer pageNum = 0;
        Matcher mat = Pattern.compile("1頁目/(\\d+)頁", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            pageNum = Integer.parseInt(mat.group(1));
        }
        return pageNum;
    }
    
    public String getImageUrl(String content) {
        String url = null;
        Matcher mat = Pattern.compile("<embed.*?alt=\"PDF\".*?src='(.*?)'", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            url = JPOUtils.Jplatpat_home + mat.group(1);
        }
        return url;
    }
    
    public String searchPDF(int i, String pdfSession) throws Exception {
        String url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM407_ToPDF.action";
        HashMap<String, String> map = new HashMap<>();
        map.put("bTmFCOMDTO.fillingYokyuPage", String.valueOf(i));
        map.put("jplatpatSession", pdfSession);
        
        String imagePage = httpUtils.getResponseAsString(url, map);
        return imagePage;
    }
    
    public void downloadImage(String url, File file) throws IOException {
        FileUtil.sureDirExists(file, true);
        byte[] content = getResponseBody(url);
        FileOutputStream fout = new FileOutputStream(file);
        fout.write(content);
        fout.close();
    }
    
    public byte[] getResponseBody(String url) throws IOException {
        byte[] content = new byte[0];
        CloseableHttpClient client = WebClient.newHttpClient();
        HttpGet method = new HttpGet(url);
        
        HttpResponse response = client.execute(method);
        HttpEntity entity = response.getEntity();
        if (response.getStatusLine().getStatusCode() < 400) {
            content = EntityUtils.toByteArray(entity);
        } else {
            content = getResponseBody(url);
        }
        return content;
    }
}
