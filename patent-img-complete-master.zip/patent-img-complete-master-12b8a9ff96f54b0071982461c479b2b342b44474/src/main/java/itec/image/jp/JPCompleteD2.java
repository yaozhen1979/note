package itec.image.jp;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;

/**
 * JP complete D2 patent
 * 
 * Execute jar
 * 		java -jar JPCompleteD2.jar -file log/JPO/test.txt -error.file log/JPO/error.txt -source E:/JPO
 * 
 * @author yiyunsun	2015.08
 */
public class JPCompleteD2 {
	
	static Log log = LogFactory.getLog(JPCompleteD2.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "./log/JPO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "./log/JPO/error.txt";
    
    public static final String SOURCE = "source";
    public static final String SOURCE_DEFAULT = "S:/originaldata/JP/compress/JPD_2000_CONVERT/DG";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, SOURCE, true, SOURCE_DEFAULT, "")};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws Exception {
		JPCompleteD2 complete = new JPCompleteD2();
		complete.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(JPCompleteD2.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("JPO");
        MongoUtils.init(pto);
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        Path sourcePath = Paths.get(argParser.getOptString("source"));
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
        	try {
        		File patFile = null;
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                pe.addNum().debug(log, 10000, sdf.format(info.doDate)); 
                
                if (!info.kindcode.equals("D2")) {
                	FileUtil.writeInfo(errorFile, line, true);
                	continue;
                }
                
                LinkedList<File> fileList = new LinkedList<>();
                for (int i = 0; i < 20; i++) {
                	fileList.add(sourcePath.resolve("PDF_" + String.valueOf(i)).resolve(formatJPD2Path(info.patentNumber)).toFile());
                }
                for (File pFile: fileList) {
                    if (pFile.exists()) {
                        patFile = pFile;
                        break;
                    }
                }
                
                if (patFile != null && patFile.exists()) {
                	FileInputStream fis = null;
                    FileOutputStream fos = null;
                    try {
                    	String tarPath = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf");
                    	File tarFile = new File(tarPath);
                        FileUtil.sureDirExists(tarFile, true);
                        fis = new FileInputStream(patFile);
                        fos = new FileOutputStream(tarFile);
                        IOUtils.copy(fis, fos);
                        
                        PdfReader pdfReader = new PdfReader(tarPath);
                        info.filePageNumber = pdfReader.getNumberOfPages();
                    	info.save();    
                    } catch (IOException ioe) {
                    	log.debug(ioe, ioe);
                    } finally {
                    	if (fis != null) {
                    		fis.close();
                    		fis = null;
                    	}
                    	if (fos != null) {
                    		fos.close();
                    		fos = null;
                    	}
                    }
                } else {
                    FileUtil.writeInfo(errorFile, line, true);
                }
        	} catch (Exception e) {
        		 log.debug(e, e);
        		 FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
        	}
        }
        pe.debug(log);
        log.debug("finish");
	}

	public String formatJPD2Path(String number) {
		String ret = null;
		Matcher mat = null;
        mat = Pattern.compile("^意匠登録(\\d{7})$", Pattern.CASE_INSENSITIVE).matcher(number);	// 5332ffdd01020da83aa8bfae ; 意匠登録1059983 ; 2009-06-15
        if (mat.find()) {
        	ret = mat.group(1);
        }
        
        mat = Pattern.compile("^意匠登録(\\d{7})-(\\d{1})$", Pattern.CASE_INSENSITIVE).matcher(number);// 533ba2f3eb628b2ea4c29a85 ; 意匠登録1061908-1 ; 2000-02-28
        if (mat.find()) {
        	ret = mat.group(1) + "-" + mat.group(2);
        }
        
        mat = Pattern.compile("^意匠類似(\\d{7})-(\\d{3})$", Pattern.CASE_INSENSITIVE).matcher(number);// 5332e4ca01020da83aa5feb9 ; 意匠類似0728657-002 ; 2003-08-18
        if (mat.find()) {
        	ret = mat.group(1) + "_" + mat.group(2);
        }
        
        mat = Pattern.compile("^意匠類似(\\d{7})-(\\d{3})-(\\d{1})$", Pattern.CASE_INSENSITIVE).matcher(number);//533b7cab66db282693b33166 ; 意匠類似1057676-001-2 ; 2000-12-04 
        if (mat.find()) {
        	ret = mat.group(1) + "_" + mat.group(2) + "-" + mat.group(3);
        }
        
        if (ret == null) {
        	throw new IllegalArgumentException("Invalid format JP D2 number" + number);
        }
		return ret + ".pdf";
	}
}
