package itec.image.jp;

import itec.common.utils.JPOUtils;
import itec.common.utils.JPOUtils.JPDownloadObj;
import itec.common.utils.MongoUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import itec.util.FileUtil;
import itec.util.HttpUtil;
import itec.util.HttpUtilWithSession;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;
import org.tsaikd.java.utils.WebClient;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class JPClipDownload {
	
	static Log log = LogFactory.getLog(JPClipDownload.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/JPO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/JPO/error.txt";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "E:/JPO";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private HttpUtilWithSession httpUtils = null;
	
	public static void main(String[] args) throws Exception {
		JPClipDownload download = new JPClipDownload();
		download.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(JPClipDownload.class).parse(args);
		MongoInitUtils.nothing();
		MappedClass.getMappedClass(PatentInfoJPO.class).setDB(MappedClass.db.getSisterDB("PatentInfoJPO"));
		if (log.isDebugEnabled()) {
			log.debug("start, opt: " + argParser.getParsedMap());
		}
		Pto pto = Pto.valueOf("JPO");
		File file = new File(argParser.getOptString("file"));
		File errorFile = new File(argParser.getOptString("error.file"));
		Path targetPath = Paths.get(argParser.getOptString("target"));
		
		if (!file.exists()) {
            String dateRange = argParser.getOptString("t");
            QueryHelp query = MongoUtils.getDateRange(dateRange);
            DBCollection col = PatentInfo2.getCollection(pto);
            DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                DBObject dbobj = cursor.next();
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                FileUtil.writeInfo(file, message, true);
            }
        }
		
		List<String> list = FileUtils.readLines(file);
		ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
		httpUtils = new HttpUtilWithSession();
		for (String line: list) {
        	try {
                String id = line.split(";")[0].trim();
                PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
                pe.addNum().debug(log, 10000, line);
                
                if (info.kindcode.equals("D2")) {
                	continue;
                }
                
                JPDownloadObj obj = new JPOUtils().getJPDownloadObj(info.patentNumber); 
                if (obj == null) {
                	FileUtil.writeInfo(errorFile, line, true);
                	continue;
                }
                Path imagePath = targetPath.resolve(Paths.get(MongoUtils.getRelPatentPath(info)));
                
                String searchPage = httpUtils.getResponseAsString(JPOUtils.Jplatpat_search);
                String searchSession = JPOUtils.getJplatepatSession(searchPage);
                        
                String searchCountPage = searchResult(obj, searchSession, JPOUtils.SEARCH_COUNT);
                String countSession = JPOUtils.getJplatepatSession(searchCountPage); 
                
                String resultPage = searchResult(obj, countSession, JPOUtils.SEARCH_RESULT);
                String resultSession = JPOUtils.getJplatepatSession(resultPage); 
                
                String patentPage = searchDetail(resultSession);
                String patentSession = JPOUtils.getJplatepatSession(patentPage);
                
                Matcher mat = null;
                // firstImage
                mat = Pattern.compile("<img.*?alt='代表図面'.*?src='(.*?)'", Pattern.DOTALL).matcher(patentPage);
                if (mat.find()) {
                	String url = JPOUtils.Jplatpat_home + mat.group(1);
                	String suffix = url.substring(url.lastIndexOf("."));
                	Path firstImagePath =  imagePath.resolve("firstImage" + suffix);
                	HttpUtil.downloadFile(url, firstImagePath.toFile());
                	info.firstImagePageFlag = true;
                }
                
                // figureImage
                mat = Pattern.compile("<img class=\"itembodyimage\" src=\"(.*?)\".*?/>", Pattern.DOTALL).matcher(patentPage);
                int figureCount = 0;
                while (mat.find()) {
                	figureCount++;
                	String url = JPOUtils.Jplatpat_home + mat.group(1);
                	String fileName = url.substring(url.lastIndexOf("/") + 1);	
                	fileName = fileName.substring(fileName.indexOf("_") + 1);
                	Path figurePath = imagePath.resolve("figure").resolve(fileName);
                	downloadImage(url, figurePath.toFile());
                }
                if (figureCount > 0) {
                	info.figurePageNumber = figureCount;
                }
                
                // clipImage
                mat = Pattern.compile("<a.*?id='(.*?)'.*?class=\"item\".*?>(.*?)</a>", Pattern.DOTALL).matcher(patentPage);
                String itemKey = null;
                while (mat.find()) {
                	String itemValue = mat.group(2).trim();
                	if (itemValue.equals("図面")) {
                		itemKey = mat.group(1).trim();
                        break;
                	}
                }
                if (itemKey != null) {	
                	String clipPage = searchClip(patentSession, itemKey);
                    mat = Pattern.compile("<img class=\"itembodyimage\" src=\"(.*?)\".*?/>", Pattern.DOTALL).matcher(clipPage);
                    int clipCount = 0;
                    while (mat.find()) {
                    	clipCount++;
                    	String url = JPOUtils.Jplatpat_home + mat.group(1);
                    	String suffix = url.substring(url.lastIndexOf("."));
                    	Path clipPath = imagePath.resolve("clip").resolve(String.valueOf(clipCount) + suffix);
                    	downloadImage(url, clipPath.toFile());
                    } 
                    if (clipCount > 0) {
                    	info.clipPageNumber = clipCount;
                    }
                }
                
                info.save();
                Thread.sleep(2000);
        	} catch (Exception e) {
        		log.debug(e, e);
        		FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
        	}
		}
	}
	
    @SuppressWarnings("serial")
    public String searchResult(JPDownloadObj obj, String searchSession, int type) throws Exception {
        String url = null;
        switch (type) {
        case 1:
        	url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action";
        	break;
        case 2:
        	url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_SearchResult.action";
        	break;
        default:
        	break;	
        }
        
        HashMap<String, String> map = new HashMap<String, String>() { {
        	put("__checkbox_bTmFCOMDTO.officialInfoList[0]", "01");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03");
        	put("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04");
            put("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05");
            put("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06");
            put("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07");
            put("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[0]", "1");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[1]", "2");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[2]", "3");
            put("__checkbox_bTmFCOMDTO.jglobalsearchList[3]", "4");
            put("bTmFCOMDTO.fukumuFukumanaiList[0]", "01");
            put("bTmFCOMDTO.searchSystemList[0]", "01");
            put("bTmFCOMDTO.searchItemList[1]", "05");
            put("bTmFCOMDTO.fukumuFukumanaiList[1]", "01");
            put("bTmFCOMDTO.searchKeywordList[1]", "");
            put("bTmFCOMDTO.searchSystemList[1]", "01");
            put("bTmFCOMDTO.ronrishiki", "");
            put("bTmFCOMDTO.fillingRowCount", "2");
        } };
        map.put("jplatpatSession", searchSession);
        map.put("bTmFCOMDTO.searchKeywordList[0]", obj.searchNumber);
        map.put("bTmFCOMDTO.searchItemList[0]", obj.searchItemList);
        map.put(obj.checkList, obj.checkListValue);
        String resultPage = httpUtils.getResponseAsString(url, map);
        return resultPage;
    }
    
    @SuppressWarnings("serial")
    public String searchDetail(String resultSession) throws Exception {
        String url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM301_Detailed.action";
        HashMap<String, String> map = new HashMap<String, String>() { {
            put("bTmFCOMDTO.hyojiPtnValue", JPOUtils.DETAILED_TEXT);
            put("bTmFCOMDTO.fillingCurrentBunkenIndex", "0");
        } };
        map.put("jplatpatSession", resultSession);
        String detailPage = httpUtils.getResponseAsString(url, map);
        return detailPage;
    }
    
    @SuppressWarnings("serial")
    public String searchClip(String session, String itemKey) throws Exception {
    	String url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM401_ToItem.action";
    	HashMap<String, String> map = new HashMap<String, String>() { {
    		put("bTmFCOMDTO.fillingHighlightMode", "01");
    	} };
    	map.put("bTmFCOMDTO.fillingItemKey", itemKey);
    	map.put("jplatpatSession", session);
    	String clipPage = httpUtils.getResponseAsString(url, map);
    	return clipPage;
    }
    
    public void downloadImage(String url, File file) throws IOException {
        byte[] content = getResponseBody(url);
        if (content.length == 0) {
        	throw new IOException("download eror, url: " + url);
        }
        FileUtil.sureDirExists(file, true);
        FileOutputStream fout = new FileOutputStream(file);
        fout.write(content);
        fout.close();
    }
    
    public CloseableHttpClient client = null;
    public CloseableHttpClient getClient() {
    	if (client == null) {
    		client = WebClient.newHttpClient();
    	}
    	return client;
    }
    
    public byte[] getResponseBody(String url) throws IOException {
        byte[] content = new byte[0];
        CloseableHttpClient client = getClient();
        HttpGet method = new HttpGet(url);
        
        HttpResponse response = client.execute(method);
        HttpEntity entity = response.getEntity();
        if (response.getStatusLine().getStatusCode() < 400) {
            content = EntityUtils.toByteArray(entity);
        }
        EntityUtils.consume(entity);
        return content;
    }
}
