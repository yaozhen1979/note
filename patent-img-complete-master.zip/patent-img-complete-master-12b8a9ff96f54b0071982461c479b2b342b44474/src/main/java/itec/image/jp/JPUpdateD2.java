package itec.image.jp;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import itec.util.FileUtil;
import itec.util.HttpUtilWithSession;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.tsaikd.java.mongodb.MongoObjectObjId;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;
import org.tsaikd.java.utils.WebClient;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * JP update D2 patent 2015 new 
 * 
 * Execute jar
 * 		java -jar JPUpdateD2.jar -file log/JPO/test.txt -error.file log/JPO/error.txt 
 * 
 * @author yiyunsun 2015.08
 */
public class JPUpdateD2 {
    
    static Log log = LogFactory.getLog(JPUpdateD2.class);
    
    private static String Jplatpat_home = "https://www.j-platpat.inpit.go.jp";
    private static String Jplatpat_search = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM201_Top.action";
    
    public static final String PTO = "pto"; 
    public static final String PTO_DEFAULT = "JPO";
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/JPO/test.txt";
    
    public static final String ERROR_FILE = "error.file";
    public static final String ERROR_FILE_DEFAULT = "log/JPO/error.txt";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, PTO, true, PTO_DEFAULT, ""),
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, ERROR_FILE, true, ERROR_FILE_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private HttpUtilWithSession httpUtils = null;
    
    public static void main(String[] args) throws Exception {
    	JPUpdateD2 update = new JPUpdateD2();
    	update.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(JPUpdateD2.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf(argParser.getOptString("pto"));
        MongoUtils.init(pto);
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        File file = new File(argParser.getOptString("file"));
        File errorFile = new File(argParser.getOptString("error.file"));
        
        if (!file.exists()) {
            String dateRange = argParser.getOptString("t");
            QueryHelp query = MongoUtils.getDateRange(dateRange);
            DBCollection col = PatentInfo2.getCollection(pto);
            DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                PatentInfo2 info = null;
                try {
                    DBObject dbobj = cursor.next();
                    info = PatentInfo2.fromObject(pto, dbobj);
                    if (info.kindcode.equals("D2")) {
                        String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                        FileUtil.writeInfo(file, message, true); 
                    }
                } catch (Exception e) {
                    log.debug(e, e);
                }
            }
        }
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        httpUtils = new HttpUtilWithSession();
        for (String line: list) {
            try {
                String id = line.split(";")[0].trim();
                DBObject dbobj = MongoObjectObjId.findOneDBObj(PatentInfoJPO.class, id);
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                
                String patentPath = MongoUtils.getRelPatentPath(info);
                Path imagePath = targetPath.resolve(Paths.get(patentPath));
                String number = formatNumber(info.patentNumber);
                
                String searchPage = httpUtils.getResponseAsString(Jplatpat_search);
                String searchSession = getJplatepatSession(searchPage);
                        
                String resultPage = searchResult(number, searchSession);
                String resultSession = getJplatepatSession(resultPage); 
                
                String imagePage = searchDetail(number, resultSession);
                int pageNum = getPageNum(imagePage);
                for (int i = 1; i < pageNum + 1; i++) {
                    if (i != 1) {
                        String pdfSession = getJplatepatSession(imagePage);
                        imagePage = searchPDF(i, pdfSession);
                    }
                    String imageUrl = getImageUrl(imagePage);
                    String fileName = String.valueOf(i) + ".pdf";
                    Path path = imagePath.resolve("fullImage").resolve(fileName);
                    
                    Thread.sleep(2000);
                    downloadImage(imageUrl, path.toFile());
                }
                info.filePageNumber = pageNum;
                info.save();
                
                pe.addNum().debug(log, 10000, line);
            } catch (Exception e) {
                log.debug(e, e);
                FileUtil.writeInfo(errorFile, line + " " + e.getMessage(), true);
            }
        }
    }
    
    public String formatNumber(String input) {
        String number = null;
        Matcher mat = Pattern.compile("\\D*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(input);
        if (mat.find()) {
            number = mat.group(1);
        }
        return number;
    }
    
    public String getJplatepatSession(String content) {
        String tempSession = null;
        Matcher mat = Pattern.compile("<div id=\"jplatpatSession\".*?>(.*?)</div>", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            tempSession = mat.group(1);
        }
        return tempSession;
    }
    
    @SuppressWarnings("serial")
    public String searchResult(String number, String searchSession) throws Exception {
        String url = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM201_SearchResult.action";
        HashMap<String, String> map = new HashMap<String, String>() { {
            put("bTmFCOMDTO.fillingOnlyPartialDesign", "off");
            put("bTmFCOMDTO.fillingSokyuuHukumu", "off");
            put("bTmFCOMDTO.fillingPageBango", "1");
            put("bTmFCOMDTO.fillingPublicationType", "SS");
            put("bTmFCOMDTO.fillingRelatedDesign", "0");
            put("bTmFCOMDTO.fillingSearchConditionList[0].searchItemValue", "14");
            put("bTmFCOMDTO.fillingSearchConditionList[0].searchSystemValue", "2");
            put("bTmFCOMDTO.fillingSearchConditionList[1].searchItemValue", "19");
            put("bTmFCOMDTO.fillingSearchConditionList[1].searchKeywordValue", "");
            put("bTmFCOMDTO.fillingSearchConditionList[1].searchSystemValue", "2");
            put("bTmFCOMDTO.fillingConditionListCount", "2");
            put("bTmFCOMDTO.fillingShowListMode", "1");
        } };
        map.put("jplatpatSession", searchSession);
        map.put("bTmFCOMDTO.fillingSearchConditionList[0].searchKeywordValue", number);
        
        String resultPage = httpUtils.getResponseAsString(url, map);
        return resultPage;
    }
    
    @SuppressWarnings("serial")
    public String searchDetail(String number, String resultSession) throws Exception {
        String url = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM301_Detailed.action";
        HashMap<String, String> map = new HashMap<String, String>() { {
            put("bTmFCOMDTO.fillingSelectedDocIndex", "0");
            put("bTmFCOMDTO.fillingCurrentPage", "1");
            put("bTmFCOMDTO.fillingDisplayFormat", "1");
        } };
        map.put("jplatpatSession", resultSession);
        
        String detailPage = httpUtils.getResponseAsString(url, map);
        return detailPage;
    }
    
    public Integer getPageNum(String content) {
        Integer pageNum = 0;
        Matcher mat = Pattern.compile("1頁目/(\\d+)頁", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            pageNum = Integer.parseInt(mat.group(1));
        }
        return pageNum;
    }
    
    public String getImageUrl(String content) {
        String url = null;
        Matcher mat = Pattern.compile("<embed.*?alt=\"PDF\".*?src='(.*?)'", Pattern.DOTALL).matcher(content);
        if (mat.find()) {
            url = Jplatpat_home + mat.group(1);
        }
        return url;
    }
    
    public String searchPDF(int i, String pdfSession) throws Exception {
        String url = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM402_ToPDF.action";
        HashMap<String, String> map = new HashMap<>();
        map.put("bTmFCOMDTO.fillingYokyuPage", String.valueOf(i));
        map.put("jplatpatSession", pdfSession);
        
        String imagePage = httpUtils.getResponseAsString(url, map);
        return imagePage;
    }
    
    public void downloadImage(String url, File file) throws IOException {
        FileUtil.sureDirExists(file, true);
        byte[] content = getResponseBody(url);
        FileOutputStream fout = new FileOutputStream(file);
        fout.write(content);
        fout.close();
    }
    
    public byte[] getResponseBody(String url) throws IOException {
        byte[] content = new byte[0];
        CloseableHttpClient client = WebClient.newHttpClient();
        HttpGet method = new HttpGet(url);
        
        HttpResponse response = client.execute(method);
        HttpEntity entity = response.getEntity();
        if (response.getStatusLine().getStatusCode() < 400) {
            content = EntityUtils.toByteArray(entity);
        } else {
            content = getResponseBody(url);
        }
        return content;
    }
}
