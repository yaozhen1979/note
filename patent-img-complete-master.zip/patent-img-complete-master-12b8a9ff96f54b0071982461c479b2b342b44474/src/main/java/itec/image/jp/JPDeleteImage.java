package itec.image.jp;

import itec.common.utils.MongoUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

/**
 * JP fullPage.pdf delete, because some patent fullPage.pdf broken
 * 
 * Execute jar
 * 		java -jar JPDeleteImage.jar -file log/JPO/test.txt
 * 
 * @author yiyunsun	2015.08
 *
 */
public class JPDeleteImage {
	
	static Log log = LogFactory.getLog(JPDeleteImage.class);
	
	public static final String FILE = "file";
    public static final String FILE_DEFAULT = "log/JPO/filePageNumber/test.txt";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),};
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws Exception {
		JPDeleteImage delete = new JPDeleteImage();
		delete.execute(args);
	}
	
	public void execute(String[] args) throws Exception {
		ArgParser argParser = new ArgParser().addOpt(JPDeleteImage.class).parse(args);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("JPO");
        MongoUtils.init(pto);
        File file = new File(argParser.getOptString("file"));
        Path targetPath = Paths.get(ConfigUtils.get(pto.toString().toLowerCase() + ".image"));
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
        	try {
        		String id = line.split(";")[0].trim();
        		PatentInfo2 info = PatentInfo2.findOne(pto, new ObjectId(id));
        		String path = String.format("%s/%s/%s", targetPath.toString(), MongoUtils.getRelPatentPath(info), "fullPage.pdf");
        		File pdfFile = new File(path);
        		if (pdfFile.exists()) {
        			pdfFile.delete();
        		}
        		pe.addNum().debug(log, 10000, sdf.format(info.doDate));
        	} catch (Exception e) {
        		log.debug(e, e);
        	}
        }
	}
}
