package itec.image.embedd;

import itec.common.utils.MongoUtils;
import itec.common.utils.USPTOUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.util.FileUtil;
import itec.util.HttpUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * EmbeddedImage download from Google Patent
 * 
 * Execute jar
 *      java -jar DownloadEmbeddedImageFromGoogle.jar -file log/embedded/text.txt -t 19900101-19901231
 * 
 * @author yiyun 2015.05.28
 */
public class EmbeddedDownloadFromGoogle {
    
    static Log log = LogFactory.getLog(EmbeddedDownloadFromGoogle.class);
    
    public static final String FILE = "file";
    public static final String FILE_DEFAULT = "./log/embedded/text.txt";
    
    public static final String TARGET = "target";
    public static final String TARGET_DEFAULT = "/mnt/patentsource/US/google/clipImage/download";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, FILE, true, FILE_DEFAULT, ""),
        new ArgParser.Option(null, TARGET, true, TARGET_DEFAULT, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public static void main(String[] args) throws Exception {
    	EmbeddedDownloadFromGoogle download = new EmbeddedDownloadFromGoogle();
        download.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(EmbeddedDownloadFromGoogle.class).parse(args);
        MongoInitUtils.nothing();
        MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        Pto pto = Pto.valueOf("USPTO");
        Path targetPath = Paths.get(argParser.getOptString("target"));
        File file = new File(argParser.getOptString("file"));
        
        if (!file.exists()) {
            String dateRange = argParser.getOptString("t");
            QueryHelp query = MongoUtils.getDateRange(dateRange);
            DBCollection col = PatentInfo2.getCollection(pto);
            DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                PatentInfo2 info = null;
                try {
                    DBObject dbobj = cursor.next();
                    info = PatentInfo2.fromObject(pto, dbobj);
                    String message = info.id + " ; " + info.patentNumber + " ; " + sdf.format(info.doDate);
                    FileUtil.writeInfo(file, message, true);
                } catch (Exception e) {
                    log.debug(e, e);
                }
            }
        }
        
        List<String> list = FileUtils.readLines(file);
        ProcessEstimater pe = new ProcessEstimater(list.size()).setFormatDefNum();
        for (String line: list) {
            try {
                String id = line.split(";")[0].trim();
                DBObject dbobj = MongoObjectObjId.findOneDBObj(PatentInfoUSPTO.class, id);
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                
                String patentPath = MongoUtils.getRelPatentPath(info);
                Path imagePath = targetPath.resolve(Paths.get(patentPath));
                
                String pn = USPTOUtils.formatGooglePatentNumber(info);
                String patentUrl = String.format("https://www.google.com/patents/%s", pn);
                String patentContent = HttpUtil.getResponseAsString(patentUrl);
                
                LinkedList<String> imgList = new LinkedList<>();
                Matcher mat = Pattern.compile("<div class=\"patent-image\">(.*?)</div>").matcher(patentContent);
                while (mat.find()) {
                    String temp = mat.group();
                    Matcher imgUrlMat = Pattern.compile("<a href=\"(.*?)\">").matcher(temp);
                    if (imgUrlMat.find()) {
                        imgList.add("http:" + imgUrlMat.group(1));
                    }
                }
                
                Path path = null;
//                for (String url: imgList) {
//                    String fileName = new File(url).getName();
//                    mat = Pattern.compile("^.*D0*(\\d*)\\.(tif|png)$", Pattern.CASE_INSENSITIVE).matcher(fileName);
//                    if (mat.find()) {
//                        String num = mat.group(1);
//                        path = num.equals("") ? imagePath.resolve("firstImage.png") : imagePath.resolve(Paths.get("clip")).resolve(num + ".png");
//                    }
//                    mat = Pattern.compile("^^(?!.*D\\d*).*\\.(tif|png)$", Pattern.CASE_INSENSITIVE).matcher(fileName);
//                    if (mat.find()) {
//                        path = imagePath.resolve(Paths.get("figure")).resolve(fileName);
//                    }
//                    saveImage(url, path.toFile());
//                }
                
                // before 2001 eg: http://patentimages.storage.googleapis.com/pages/US5856242-2.png
                for (String url: imgList) {
                    String fileName = new File(url).getName();
                    mat = Pattern.compile("^.*-(\\d*)\\.(tif|png)$", Pattern.CASE_INSENSITIVE).matcher(fileName);
                    if (mat.find()) {
                        String num = mat.group(1);
                        path = num.equals("0") ? imagePath.resolve("firstImage.png") : imagePath.resolve(Paths.get("clip")).resolve(num + ".png");
                    }
                    saveImage(url, path.toFile());
                }
                pe.addNum().debug(log, 10000, sdf.format(info.doDate)); 
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
    }
    
    public void saveImage(String image_url, File savePath) throws Exception {
        FileUtil.sureDirExists(savePath, true);
        byte[] image_content = HttpUtil.getResponseBody(image_url);
        FileOutputStream fout = new FileOutputStream(savePath);
        fout.write(image_content);
        fout.close();
    }
}
