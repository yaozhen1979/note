package itec.image.embedd;

import itec.common.utils.MongoUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * upload patent firstImage, clipImage number, figureImage number
 * 
 * Execute jar
 * 		java -jar EmbeddedNumberImporter.jar -t 20010101-20020101
 * 
 * @author yiyun 2015.03.05
 */
public class EmbeddedNumberImporter {
    
    static Log log = LogFactory.getLog(EmbeddedNumberImporter.class);
    
    public static final String opt_pto = "pto"; 
    public static final String opt_pto_default = "USPTO"; 
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
        new ArgParser.Option("t", null, true, "",
                "Patent open/decision date rage\n"
                    + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                    + "Format: YYYYMMDD+n (20110101+31)\n"
                    + "Format: YYYYMM+n (201101+12)\n"
                    + "Format: YYYYMM+n (2011+1)\n"), };
    
    public static void main(String[] args) throws Exception {
    	EmbeddedNumberImporter importer = new EmbeddedNumberImporter();
        importer.execute(args);
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(EmbeddedNumberImporter.class).parse(args);
        MongoInitUtils.nothing();
        MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        Pto pto = Pto.valueOf(argParser.getOptString("pto").toUpperCase());
        Path targetPath = Paths.get(ConfigUtils.get("uspto.image"));
        String date_range = argParser.getOptString("t");
        QueryHelp query = MongoUtils.getDateRange(date_range);
//        QueryHelp query = new QueryHelp("patentNumber", "20110010811");
        
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count()).setFormatDefNum();
        while (cursor.hasNext()) {
            try {
                DBObject dbobj = cursor.next();
                PatentInfo2 info = PatentInfo2.fromObject(pto, dbobj);
                String path = MongoUtils.getRelPatentPath(info);
                File pathFile = targetPath.resolve(path).toFile();
                
                File[] files = pathFile.listFiles();
                for (File file: files) {
                    switch (file.getName()) {
                    case "firstImage.tif":
                    case "firstImage.png":
                        info.firstImagePageFlag = true;
                        break;
                    case "clip":
                        info.clipPageNumber = file.listFiles().length;
                        break;
                    case "figure":
                        info.figurePageNumber = file.listFiles().length;
                        break;
                    default:
                        break;
                    }
                }
                info.save();
                pe.addNum().debug(log, 10000, new SimpleDateFormat("yyyy-MM-dd").format(info.doDate));
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
        log.debug("finish");
    }
}
