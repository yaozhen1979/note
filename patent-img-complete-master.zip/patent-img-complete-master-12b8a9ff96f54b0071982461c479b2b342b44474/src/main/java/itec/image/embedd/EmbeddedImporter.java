package itec.image.embedd;

import itec.common.utils.MongoUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.util.CompressUtil;
import itec.util.FileUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class EmbeddedImporter {
    
    static Log log = LogFactory.getLog(EmbeddedImporter.class);
    static Log error_log = LogFactory.getLog("error_log");

    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\US\\google\\EmbeddedImages\\Publication\\2015\\I20150219.tar";
    
    public static final String opt_unzip_path = "unzip.path";
    public static final String opt_unzip_path_default = "E:\\us_image\\compress\\Publication";
    
    public static final String opt_start_file_name = "start.file";
    public static final String opt_start_file_name_default = "";
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "/mnt/nhdell/patent_us/data";
    
    public static final String opt_pto = "USPTO";
    
    private Path targetPath;
    private String type;
        
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, ""),
        new ArgParser.Option(null, opt_unzip_path, true, opt_unzip_path_default, ""),
        new ArgParser.Option(null, opt_start_file_name, true, opt_start_file_name_default, ""),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, ""),
    };
    
    public static void main(String[] args) throws Exception {
    	EmbeddedImporter importer = new EmbeddedImporter();
        importer.worker(args);
    }
    
    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(EmbeddedImporter.class).parse(args);
        MongoInitUtils.nothing();
        MappedClass.getMappedClass(PatentInfoUSPTO.class).setDB(MappedClass.db.getSisterDB("PatentInfoUSPTO"));
        
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        
        String sourcePath = argParser.getOptString("source.path");
        type = sourcePath.contains("Grant") ? "grant" : "publication";
        String unzipPath = argParser.getOptString("unzip.path");
        targetPath = Paths.get(argParser.getOptString("target.path"));
        String start = argParser.getOptString("start.file");
        
        File sourceFile = new File(sourcePath);
        if (!sourceFile.exists()) {
            throw new NullPointerException("source file not exist");
        }
        List<String> fileList = new FileUtil().getFileList(sourceFile, "zip", "tar");
        if (start != null && !start.equals("")) {
            fileList = FileUtil.getListRange(fileList, start);
        }
        
        // run normal
        for (String filePath: fileList) {
            log.debug("start compress file, file path: " + filePath);
            String unzipTargetPath = unzipPath + filePath.substring(filePath.lastIndexOf(File.separator), filePath.lastIndexOf("."));
            String suffix = filePath.substring(filePath.lastIndexOf(".")).toLowerCase();
            if (suffix.endsWith("tar")) {
                CompressUtil.compressTarFile(filePath, unzipTargetPath);
            } else if (suffix.endsWith("zip")) {
                CompressUtil.compressZipFile(filePath, unzipTargetPath);
            }
            log.debug("compress finish");
            
            log.debug("start upload EmbeddedImage in 5 seconds, file path: " + unzipTargetPath);
            Thread.sleep(5000);
            
            List<String> zipList = new FileUtil().getFileList(new File(unzipTargetPath), "zip");
            ProcessEstimater pe = new ProcessEstimater(zipList.size()).setFormatDefNum();
            for (String zipFilePath: zipList) {
                try {
                    String fileName = new File(zipFilePath).getName();
                    if (fileName.indexOf("-") < 0 || fileName.indexOf("SUPP") != -1) {
                        continue;
                    }
                    uploadEmbeddedImage(fileName, zipFilePath);
                    pe.addNum().debug(log, 10000);
                } catch (Exception e) {
                    log.debug(e, e);
                    error_log.error(e.getMessage() + ", file path: " + zipFilePath);
                }
            }
            pe.debug(log);
        }
        log.debug("finish");
    }
    
    public void uploadEmbeddedImage(String fileName, String filePath) throws Exception {
        ZipEntry entry = null;
        FileInputStream fis = null;
        ZipInputStream zis = null;
        Matcher mat;
        Path path = null;
        int clipPageNumber = 0;
        int figurePageNumber = 0;
        
        String patentNumber = fileName.substring(0, fileName.indexOf("-"));
        PatentInfo2 info = getPatentInfo2(patentNumber);
        Path imagePath = targetPath.resolve(Paths.get(MongoUtils.getRelPatentPath(info)));
        
        fis = new FileInputStream(new File(filePath));
        zis = new ZipInputStream(fis);
        
        while ((entry = zis.getNextEntry()) != null) {
            String entryName = new File(entry.getName()).getName();
            if (!entryName.endsWith("TIF")) {
                continue;
            }
            // firstImage flag & clipImage page number 
            mat = Pattern.compile("^.*D0*(\\d*)\\.tif$", Pattern.CASE_INSENSITIVE).matcher(entryName);
            if (mat.find()) {
                String num = mat.group(1);
                if (num.equals("")) {
                    path = imagePath.resolve("firstImage.tif");
                    info.firstImagePageFlag = true;
                } else {
                    path = imagePath.resolve(Paths.get("clip")).resolve(num + ".tif");
                    clipPageNumber += 1;
                }
            }
            // figureImage page number
            mat = Pattern.compile("^^(?!.*D\\d*).*\\.tif$", Pattern.CASE_INSENSITIVE).matcher(entryName);
            if (mat.find()) {
                path = imagePath.resolve(Paths.get("figure")).resolve(entryName);
                figurePageNumber += 1;
            }
            // copy src file path to tar path
            FileUtil.makeDirs(path);
            FileOutputStream fos = new FileOutputStream(path.toFile());
            IOUtils.copy(zis, fos);
            fos.close();
        }
        // save patentInfo2
        info.clipPageNumber = clipPageNumber > 0 ? clipPageNumber : null;
        info.figurePageNumber = figurePageNumber > 0 ? figurePageNumber : null;
        info.save();
        
        fis.close();
        zis.close();
    }
    
    public PatentInfo2 getPatentInfo2(String patentNumber) throws Exception {
        switch (type) {
        case "grant":
            patentNumber = patentNumber.replaceAll("USD0*", "D").replaceAll("USPP0*", "PP").replaceAll("USRE0*", "RE").replaceAll("USH0*", "H");
            Matcher mat = Pattern.compile("^US0*(\\d+)$", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
            if (mat.find()) {
                patentNumber = mat.group(1);
            }
            int num = 9 - patentNumber.length();
            for (int i = 0; i < num; i++) {
                patentNumber = 0 + patentNumber;
            }
            patentNumber = "US" + patentNumber;
            break;
        case "publication":
            Matcher mat1 = Pattern.compile("^US(\\d*)\\D*.*$", Pattern.CASE_INSENSITIVE).matcher(patentNumber);
            if (mat1.find()) {
                patentNumber = mat1.group(1);
            }
            break;
        default:
            throw new IllegalArgumentException("Invalid Patent Type");
        }
        
        QueryHelp query = new QueryHelp("patentNumber", patentNumber);
        Pto pto = Pto.valueOf(opt_pto.toUpperCase());
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        if (cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            PatentInfo2 mongoInfo = PatentInfo2.fromObject(pto, dbobj);
            return mongoInfo;
        } else {
            throw new NullPointerException("can not find patent, patentNumber: " + patentNumber);
        }
    }
}
