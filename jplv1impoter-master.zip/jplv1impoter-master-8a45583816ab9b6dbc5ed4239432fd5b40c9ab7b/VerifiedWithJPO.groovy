#!/usr/bin/env groovy

@Grab('org.jsoup:jsoup:1.8.3')
@Grab(group='org.mongodb', module='mongo-java-driver', version='3.1.0')

import org.apache.commons.cli.Option
import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.util.JSON
import java.text.SimpleDateFormat

//parser args
def cli = new CliBuilder(
	usage: 'compare patent count in mongo with patent count in JPO ',
	header: '\nAvailable options (use -h for help):\n')

cli.with
{
	h(longOpt: 'help', 'Usage Information', required: false)
	d(longOpt: 'date', '2015/01/01', args: 1, required: true)
	t(longOpt: 'type', '特許公開', args: 1, required: true)
	m(longOpt: 'mongo.ip', '', args: 1, required: true)
	u(longOpt: 'mongo.user', '', args: 1, required: true)
	p(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)

if (!opt) { 
	cli.usage()
	assert opt : "some argument is required"	
}

if (opt.h) cli.usage()

def date = opt.d
def jpPatentType = opt.t
def mongoIP = opt.m
def mongoUser = opt.u
def mongoPwd = opt.p

System.properties << [ 'https.proxyHost':'10.60.94.41', 'https.proxyPort':'3128' ]

def jpoCount
if (jpPatentType == "意匠公報") {
	jpoCount = getJPODesignCount(date)
} else {
	jpoCount = getJPOPatentCount(jpPatentType, date)
}

//get count from mongo
MongoCredential credential = MongoCredential
								.createCredential(mongoUser,"admin",
											mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIP, 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")

SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))

BasicDBObject dbobj = new BasicDBObject([
						"doDate" : sdf.parse(date),
						"patentTypeJP": jpPatentType])

println dbobj
mongoCount = collection.count(dbobj)

assert jpoCount == mongoCount : "count in mongodb not equal to JPO"
println "jpo count: " + jpoCount
println "mongo count: " + mongoCount

def getJPODesignCount(date) {
	def url = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM201_SearchCount.action"
	def doc = org.jsoup.Jsoup.connect(url)
					.data("bTmFCOMDTO.fillingOnlyPartialDesign", "off")
					.data("bTmFCOMDTO.fillingSokyuuHukumu", "off")
					.data("bTmFCOMDTO.fillingPageBango", "1")
					.data("bTmFCOMDTO.fillingPublicationType", "SS")
					.data("bTmFCOMDTO.fillingRelatedDesign", "0")
					.data("bTmFCOMDTO.fillingSearchConditionList[0].searchItemValue", "16")
					.data("bTmFCOMDTO.fillingSearchConditionList[0].searchKeywordValue", date)
					.data("bTmFCOMDTO.fillingSearchConditionList[0].searchSystemValue", "2")
					.data("bTmFCOMDTO.fillingSearchConditionList[1].searchItemValue", "19")
					.data("bTmFCOMDTO.fillingSearchConditionList[1].searchKeywordValue", "")
					.data("bTmFCOMDTO.fillingSearchConditionList[1].searchSystemValue", "2")
					.data("bTmFCOMDTO.fillingConditionListCount": "2")
					.post()
	ele = doc.select("strong[class=searchbox-result-count]")
	def jpoCount = ele.text().replace("件", "")
	return jpoCount.toInteger()
}

def getJPOPatentCount(jpPatentType, date) {
	def url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action"
	def searchItemCode
	def officalInfoListCode
	switch (jpPatentType) {
		case "特許公開":
			searchItemCode = "32" //公開日
			officalInfoListCode = "01" //公開特許公報 (特開･特表(A)、再公表(A1))
			break
		case "公表":
			searchItemCode = "39" //公表日
			officalInfoListCode = "01" //公開特許公報 (特開･特表(A)、再公表(A1))
			break
		case "再公表":
			searchItemCode = "40" //再公表發明日
			officalInfoListCode = "01"//公開特許公報 (特開･特表(A)、再公表(A1))
			break
		case "特許公告":
			searchItemCode = "41"//公報發明日
			officalInfoListCode = "02"//特許公報 (特公･特許(B))
			break
		case "公開実用新案":
			searchItemCode = "41"//公報發明日
			officalInfoListCode = "04"//公開実用新案公報 (実開･実表･登実(U)、再公表(A1))
			break
		case "実用新案":
			searchItemCode = "41"//公報發明日
			officalInfoListCode = "05"//実用新案公報 (実公・実登(Y))
			break
		default:
			searchItemCode = "32"
			officalInfoListCode = "01"
			break
	}

	def doc
	def tryCount = 0
	while(true) {
		try {
			tryCount++
			doc = org.jsoup.Jsoup.connect(url)
							.data("bTmFCOMDTO.officialInfoList[0]", officalInfoListCode)
							.data("__checkbox_bTmFCOMDTO.officialInfoList[0]", "01")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07")
							.data("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08")
							.data("bTmFCOMDTO.searchItemList[0]", searchItemCode)
							.data("bTmFCOMDTO.fukumuFukumanaiList[0]","01")
							.data("bTmFCOMDTO.searchKeywordList[0]", date)
							.data("bTmFCOMDTO.searchSystemList[0]", "01")
							.data("bTmFCOMDTO.searchItemList[1]", "05")
							.data("bTmFCOMDTO.fukumuFukumanaiList[1]", "01")
							.data("bTmFCOMDTO.searchKeywordList[1]", "")
							.data("bTmFCOMDTO.searchSystemList[1]", "01")
							.data("bTmFCOMDTO.ronrishiki", "")
							.data("bTmFCOMDTO.fillingRowCount", "2")
							.userAgent("Mozilla")
							.post()
			break
		} catch (Exception e) {
			def sleepSec = 5*tryCount
			println "connect to JPO error, wait " + sleepSec + " sec and try again"
			sleep(sleepSec*1000)
		}
	}
	ele = doc.select("strong[class=searchbox-result-count]")
	def jpoCount = ele.text().replace("件", "")
	return jpoCount.toInteger()
}

