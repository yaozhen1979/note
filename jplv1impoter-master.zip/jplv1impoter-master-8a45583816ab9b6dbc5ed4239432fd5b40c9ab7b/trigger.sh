#!/bin/bash

OPTIND=1 
show_help() {
	cat << EOF
	Usage: ${0##*/} [-haj]
	find new vol dir and trigger jp import task in jenkins
	-a	raw data path for jp, ex. /mnt/khdell/patentsource/originaldata/JP/jpo
	-j	jekkins job url. ex/ http://10.62.41.134:5678/job/test/buildWithParameters?volpath=
EOF
}

rawpath=""
joburlPrefix=""

while getopts "h?a:j:" opt; do
    case "$opt" in
    h|\?)
        show_help
        exit 0
        ;;
    a)
        rawpath=$OPTARG
        ;;
	j)
		joburlPrefix=$OPTARG
		;;
	esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift

if [ "$rawpath" == "" ] || [ "$joburlPrefix" == "" ]; then
	echo "you may lose some arg..."
	show_help
	exit 0
fi




#找所有在一天內上傳的原始資料目錄 (避免處理歷史資料而非更新資料)
#考慮到不會在凌晨拷貝光碟，因此不設定條件去判斷該目錄是否正在傳資料
find $rawpath -maxdepth 3 -mindepth 3 -ctime -1 -type d | awk -F'/jpo' '{print $2}' | while read vol; do
	updateCmd="curl ${joburlPrefix}${vol}"
	echo $updateCmd
	$updateCmd
done
