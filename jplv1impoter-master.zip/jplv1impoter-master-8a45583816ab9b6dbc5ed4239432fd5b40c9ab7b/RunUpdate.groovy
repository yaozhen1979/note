#!/bin/sbin/env groovy

@Grab('org.jsoup:jsoup:1.8.3')

import groovy.json.JsonSlurper

def cli = new CliBuilder(
	usage: 'get update info from etcd, then run import & verify',
	header: '\nAvailable options (use -h for help):\n')

cli.with
{
	h(longOpt: 'help', 'Usage Information', required: false)
	a(longOpt: 'rawdata.abspath', 
				'/mnt/khdell/patentsource/originaldata/JP/jpo', 
				args: 1, required: true)
	m(longOpt: 'mongo.ip', '', args: 1, required: true)
	u(longOpt: 'mongo.user', '', args: 1, required: true)
	p(longOpt: 'mongo.pwd', '', args: 1, required: true)
	v(longOpt: 'volpath', '/japanese_patent_and_registered_utility_model_specifications/2014/050/', 
				args: 1, required: true)
}

def opt = cli.parse(args)

if (!opt) {
	cli.usage()
	assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def vol = opt.v
def rawdataPath = opt.a
def rawdataRelPath = opt.r
def mongoIP = opt.m
def mongoUser = opt.u
def mongoPwd = opt.p

println "*****start process vol: " + vol + "*****"
def cmd = "-a " + rawdataPath + " -m " + mongoIP + " -p " + mongoPwd + 
				" -u " + mongoUser + " -v " + vol
//import
println "**** EXEC: groovy JPOImpoter.groovy " + cmd + " ****"
run(new File("./JPOImpoter.groovy"), cmd.split(" "))

//verify	
def file = new File(rawdataPath + vol + "/ABSTRACT.csv")
assert file.exists() == true
assert file.isFile() == true
def filecontents = file.getText('EUC-JP')
def datefinder = (filecontents =~ /\(([0-9]{4})\)?\.([0-9]{1,2})\.([0-9]{1,2})/)
def dateStr = ""
if(datefinder) {
	def year = datefinder.group(1)
	def mon = datefinder.group(2).padLeft(2, "0")
	def day = datefinder.group(3).padLeft(2, "0")
	dateStr = year + "/" + mon + "/" + day
}

assert dateStr.length() == 10
if(file =~ /(?i)published_unexamined_patent_applications/) {
	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 特許公開"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))

	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 公表"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))

	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 再公表"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))
} else if (file =~ /(?i)japanese_patent_and_registered_utility_model_specifications/) {
	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 特許公告"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))
} else if (file =~ /(?i)published_registered_utility_model_applications/) {
	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 公開実用新案"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))
} else if (file =~ /(?i)published_registered_design_applications/) {
	cmd = "-d " + dateStr + " -m " + mongoIP + " -p " + mongoPwd +
				" -u " + mongoUser + " -t 意匠公報"
	println "**** EXEC: groovy VerifiedWithJPO.groovy " + cmd + " ****"
	run(new File("./VerifiedWithJPO.groovy"), cmd.split(" "))
}

