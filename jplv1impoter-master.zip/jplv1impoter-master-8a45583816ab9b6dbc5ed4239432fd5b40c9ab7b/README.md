## JPOImpoter.groovy
Import rawdata from JPO to mongodb: PatentRawJPO  
導入日本專利 rawdata到 mongodb : PatentRawJPO
```
groovy JPOImpoter.groovy -a $rawdataPath -m $mongoIp -p $mongoPwd -u $mongoUser -v $volPath
```

## VerifiedWithJPO.groovy
Verify patent count through JPO https://www.j-platpat.inpit.go.jp/web/all/top/BTmTopPage  
ps. date format is yyyy/MM/dd  
驗證導入到 mongodb 的數量和官一致  
ps. 日期格式為 yyyy/MM/dd
```
groovy VerifiedWithJPO.groovy -d $date -m $mongoIp -p $mongoPwd -u $mongoUser -t $patentType
```

## RunUpdate.groovy
run update process to import raw data to mongo and check count is equal ot not.  
上傳流程會先導 rawdata 進 mongod， 再驗證和官網數量是否一致
```
groovy RunUpdate.groovy -a $rawdataPath -m $mongoIp -p $mongoPwd -u $mongoUser -v $volpath
```

## trigger.sh (only supptor in linux)
check raw data dir, and find all vol dirs which are updated within a day, and trigger remote
jenkins job to build  
掃描 rawdata  所有在一天內上傳的目路，利用 jenkins remote build 去啟動 job
```
bash trigger.sh -a $rawdataPath -j $jenkinsJobBuildUrl
```