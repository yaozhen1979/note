#!/usr/bin/env groovy

@Grab(group='org.json', module='json', version='20150729')
@Grab(group='org.mongodb', module='mongo-java-driver', version='3.1.0')

import groovy.io.FileType
import org.apache.commons.cli.Option
import org.json.JSONException
import org.json.JSONObject
import org.json.XML
import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.util.JSON
import java.text.SimpleDateFormat

sdfCurTime = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss")
sdfDoDate = new SimpleDateFormat("yyyy/MM/dd")
sdfParseSgmDoDate = new SimpleDateFormat("yyyy.MM.dd")
sdfParseSgmDoDate.setTimeZone(TimeZone.getTimeZone("GMT"))
sdfParseXmlDoDate = new SimpleDateFormat("yyyyMMdd")
sdfParseXmlDoDate.setTimeZone(TimeZone.getTimeZone("GMT"))

//parser args
def cli = new CliBuilder(
	usage: 'import jp raw data (2015~) to mongo ',
	header: '\nAvailable options (use -h for help):\n')

cli.with
{
	h(longOpt: 'help', 'Usage Information', required: false)
	a(longOpt: 'rawdata.abspath', 
				'/mnt/khdell/patentsource/originaldata/JP/jpo', 
			args: 1, required: true)
	v(longOpt: 'rawdata.volpath', 
			'/japanese_patent_and_registered_utility_model_specifications/2014/050/', 
			args: 1, required: true)
	m(longOpt: 'mongo.ip', '', args: 1, required: true)
	u(longOpt: 'mongo.user', '', args: 1, required: true)
	p(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)

if (!opt) {
	cli.usage()
	assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def rawdataPath = opt.a
def volPath = opt.v
def mongoIP = opt.m
def mongoUser = opt.u
def mongoPwd = opt.p
MongoCredential credential = MongoCredential
								.createCredential(mongoUser,"admin",
											mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIP, 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("PatentRawJPO")
								.getCollection("PatentRawJPO")

def count = 0

//parser rawdata
println "process path:" + rawdataPath + volPath
File dir = new File(rawdataPath + volPath)
filelist = extractRawFilesAndTypeCode(dir)
def len = filelist.size()
def startTime = Calendar.instance.time.time
def filesizeLimit = 1024 * 1024 * 16
filelist.each { file ->
//def file = new File("/mnt/khdell/patentsource/originaldata/JP/jpo/japanese_patent_and_registered_utility_model_specifications/2015/tmp/DOCUMENT/B9/0005649001/0005649201/0005649261/0005649263.xml")
	count++
	def fileContents = file.getText('EUC-JP')
	def pto = "JPO"
	def provider = "JPO"
	def path = file.toString().replace(rawdataPath + "/", "")
	def patentTypeJP = getPatentTypeJP(path)
	if(patentTypeJP) {
		try {
			(doDate, data, type) = parser(fileContents, patentTypeJP)
			if(doDate != null && data != null && 
				type != null && patentTypeJP != null)  {
				def pathquery = new BasicDBObject(["path" : path])	
				collection.remove(pathquery)
				def rawObj = new BasicDBObject()

				def filesize = file.length()
				//原始檔案過大的話，依比例刪除description內容
				if (filesize > filesizeLimit) {
					println "exceed file size:" + file
					def sizeScalae = (filesize/filesizeLimit)*1.2 //縮放比例再乘上 1.2 倍緩衝
					def oriDesc = data.get("jp-official-gazette").get("description")
					def oriLength = oriDesc.toString().length()
					def desc = oriDesc.toString().substring(0, (int)(oriLength/sizeScalae))
					desc += "...."
					data.get("jp-official-gazette").remove("description")
					data.get("jp-official-gazette").put("description", desc)
					rawObj.append("truncte", true)					
				}

				rawObj.append("pto", pto)
				rawObj.append("path", path)
				rawObj.append("data", (BasicDBObject) 
										JSON.parse(data.toString()))
				rawObj.append("type", type)
				rawObj.append("provider", provider)
				rawObj.append("doDate", doDate)
				rawObj.append("patentTypeJP", patentTypeJP)
				collection.insert(rawObj)
			}
			//每處理五百篇 print 處理進度
			if(count%500 == 0) {
				printlnProgress(count, len, startTime, doDate)
			}
		} catch (Exception e) {
			println "err at " + path
			throw e;
		}
	}
}
printlnProgress(count, len, startTime, doDate)

def printlnProgress(count, len, startTime, doDate) {	
	def curTime = Calendar.instance.time.time
	def rest = (float)(curTime-startTime)*(float)(len - count)
	rest = rest/count
	def msec = ((int)rest%1000)
	rest = (int)rest/1000
	def sec = (int) (rest%60)
	rest = (int)rest/60
	def min = (int) (rest%60)
	rest = (int)rest/60
	def hr = (int) rest;
	def percent = (int)count*100/len
	def restStr
	if (hr > 0) {
			restStr = sprintf('%02d:%02d:%02d', hr, min, sec)
		} else if (min > 0) {
			restStr = sprintf('%02d:%02d', min, sec)
		} else {
			restStr = sprintf('%02d.%02d', sec, msec)
	}
	println sprintf('%s - %d/%d(%d%%), rest time: %s, cur doDate %s', 
					sdfCurTime.format(new Date()), count, len, percent, restStr, 
					sdfDoDate.format(doDate))
}

def getPatentTypeJP(path) {
	if(path =~ /(?i).*\/A\/.*/) {
		return "特許公開"
	} else if (path =~ /(?i).*\/T\/.*/) {
		return "公表"
	} else if (path =~ /(?i).*\/S\/.*/) {
		return "再公表"
	} else if (path =~ /(?i).*\/B9\/.*/) {
		return "特許公告"
	} else if (path =~ /(?i).*\/U9\/.*/) {
		return "公開実用新案"
	} else if (path =~ /(?i).*\/DG\/.*/) {
		return "意匠公報"
	} else {
		return null
	}
}

def parser(fileContents, patentTypeJP) {
	def doDate
	def data
	def type
	//設計專利為 SGM 檔，以純文字另外處理
	if(patentTypeJP == "意匠公報") {
		def pubDateInfoMatcher = fileContents =~ 
			/(?i)<PUBLICATION-DATE>.*<\/PUBLICATION-DATE/
		pubDateInfo = fullwidthTohalfwidth(pubDateInfoMatcher[0])
		def pubdateMatcher = pubDateInfo =~ /\d+\.\d+\.\d+/
		doDate = sdfParseSgmDoDate.parse(pubdateMatcher[0])
		data = new JSONObject().put("sgm", fileContents)
		type = "sgm/sgm"
	} else {
		def xmlJSONObj = XML.toJSONObject(fileContents)
		//jp:sequence-list 不是 patent
		if(xmlJSONObj.isNull("jp:sequence-list")) {
			doDate = getXmlDoDate(xmlJSONObj, patentTypeJP)
			data = xmlJSONObj
			type = "xml/xml"
		}
	}
	return [doDate, data, type]
}

def fullwidthTohalfwidth(String str){
  for(char c:str.toCharArray()){
    str = str.replaceAll("　", " ");
    if((int)c >= 65281 && (int)c <= 65374){
      str = str.replace(c, (char)(((int)c)-65248));
    }
  }
  return str;
}

def getXmlDoDate(xmlJSONObj, patentTypeJP) {
	def biblioObj = xmlJSONObj.get("jp-official-gazette")
	if (!biblioObj.isNull("bibliographic-data")) {
		biblioObj = biblioObj.get("bibliographic-data")
	}
	def doDateStr
	if( patentTypeJP == "特許公告" || patentTypeJP == "公開実用新案") {
		doDateStr = biblioObj.isNull("dates-of-public-availability") ? 
								"00000000" : 
								biblioObj.get("dates-of-public-availability")
											.get("printed-with-grant")
											.get("document-id").get("date")
											.toString()
	} else {
		doDateStr = biblioObj.isNull("publication-reference") ? 
								"00000000" : 
								biblioObj.get("publication-reference")
											.get("document-id").get("date")
											.toString()
	}
	def doDate = sdfParseXmlDoDate.parse(doDateStr)
	return doDate
}

//擷取所有必須處理的 xml 列表
def extractRawFilesAndTypeCode(dir) {
	println "extract raw data file list..."
	def list = []
	def jpPatentType
	dir.eachFileRecurse (FileType.FILES) { file ->
		//從路徑判斷專利類型 P1[發明公開] P2[發明公告] U3[公開実用新案] D[意匠公報]
		if (file =~ /(?i)published_unexamined_patent_applications/) {
			if (file =~ /(?i).*\.xml$/ ) { 
				list << file
			}
		} else if (file =~ /(?i)japanese_patent_and_registered_utility_model_specifications/) {
			if (file =~ /(?i).*\.xml$/ ) { 
				list << file
			}
		} else if (file =~ /(?i)published_registered_utility_model_applications/) {
			if (file =~ /(?i).*\.xml$/ ) { 
				list << file
			}
		} else if (file =~ /(?i)published_registered_design_applications/) {
			if (file =~ /(?i).*\.sgm$/ ) { 
				list << file
			}
		}
	}
	return list
}
