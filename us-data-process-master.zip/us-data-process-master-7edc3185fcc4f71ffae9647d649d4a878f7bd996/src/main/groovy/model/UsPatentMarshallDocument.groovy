package model

class UsPatentMarshallDocument {

    String xsdPath
    
    String contextPath
    
    String oxmPath
    
    String dtd
    
    Class<?> rootClass
    
    ClassLoader cl
    
    Object root
    
    int stat
    
    Date doDate
    
    String xml
    
    String jsonStr
    
    String toString() { "UsPatentMarshallDocument [xsdPath=$xsdPath, contextPath=$contextPath, oxmPath=$oxmPath, dtd=$dtd , cl=$cl, stat=$stat, doDate=$doDate, xml=$xml ]" }
    
}
