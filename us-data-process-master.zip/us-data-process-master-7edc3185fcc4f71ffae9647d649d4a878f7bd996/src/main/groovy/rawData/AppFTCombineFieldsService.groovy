package rawData

import org.slf4j.LoggerFactory

import services.CrawlRawDataCombineFieldsService
import utils.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.Bytes

/**
 * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I><BR>
 * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I> 取得 <I>appDate</I>
 */
class AppFTCombineFieldsService extends CrawlRawDataCombineFieldsService {


    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver")
    static {
        mongoLogger.setLevel(Level.OFF);
    }

    public AppFTCombineFieldsService(String collName, String statCollName) {
        super(collName, statCollName)
    }



    @Override
    public void combineFields() {
        def statCur = statCol.find(['status' : 1, "combined" : 0]).sort([_id:1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        if (statCur.count() == 0) {
            println  "no new record needs to be combined ~"
            return
        }

        while (statCur.hasNext()) {

            def statDoc = statCur.next()

            def statId = statDoc._id

            statCol.update(["_id" : statId], [$set:["combined" : -1]])

            def queryMap = ["statId" : statId]

            println "count patFt range $statId "
            def appFtTotal = col.count(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
            RestTimeProcess rtp = new RestTimeProcess(appFtTotal, AppFTCombineFieldsService.class.name)

            def appFtCur = col.find(queryMap)

            while (appFtCur.hasNext()) {
                def rawDoc = appFtCur.next()

                def cpcDoc = findCPCByPatentNumber(rawDoc._id)
                rawDoc << [combineCPC : false]
                if (!!cpcDoc) {
                    // 用 patentNumber 查詢 AssignmentInfoUSPTO
                    combineAppNo(rawDoc, cpcDoc)
                }

                rawDoc << [combineAsg : false]
                combineAppDate(rawDoc)

                //                save(rawDoc)
                println "rawDoc : $rawDoc"

                rtp.process(rawDoc.createDate)

                break

            }

            statCol.update(["_id" : statId], [$set:["combined" : 1]])

            printLog "combine range $statId finish!"
            break
        }
    }

    static main(args) {
        CrawlRawDataCombineFieldsService appFTService = new AppFTCombineFieldsService("AppFT", "AppFTStat")
        appFTService.combineFields()
    }
}
