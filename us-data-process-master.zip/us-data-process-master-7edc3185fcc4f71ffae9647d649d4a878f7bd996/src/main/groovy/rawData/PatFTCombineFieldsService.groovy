package rawData

import org.slf4j.LoggerFactory

import services.CrawlRawDataCombineFieldsService
import utils.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.Bytes

/**
 * 用 patentNumber 查詢 <I>CPC_201510</I> 取得  <I>kindCode</I><BR>
 * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I><BR>
 * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I> 取得 <I>appDate</I>
 */
class PatFTCombineFieldsService extends CrawlRawDataCombineFieldsService {

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver")

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    public PatFTCombineFieldsService(String collName, String statCollName) {
        super(collName, statCollName)
    }

    @Override
    public void combineFields() {
        def statCur = statCol.find(['status' : 1, "combined" : 0]).sort([_id:1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        if (statCur.count() == 0) {
            println  "no new record needs to be combined ~"
            return
        }

        while (statCur.hasNext()) {

            def statDoc = statCur.next()

            def statId = statDoc._id

            statCol.update(["_id" : statId], [$set:["combined" : -1]])

            def queryMap = ["statId" : statId]

            println "count patFt range $statId "
            def patFtTotal = col.count(queryMap)
            RestTimeProcess rtp = new RestTimeProcess(patFtTotal, PatFTCombineFieldsService.class.name + " " + statId)
            
            def patFtCur = col.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

            while (patFtCur.hasNext()) {
                def rawDoc = patFtCur.next()

                def cpcDoc = findCPCByPatentNumber(parseCPCPatentNumber(rawDoc._id))
                rawDoc << [combineCPC : false]
                if (!!cpcDoc) {
                    // 用 patentNumber 查詢 CPC_201510 取得  kindCode
                    combineKindCode(rawDoc, cpcDoc)
                    // 用 patentNumber 查詢 AssignmentInfoUSPTO
                    combineAppNo(rawDoc, cpcDoc)
                }

                rawDoc << [combineAsg : false]
                combineAppDate(rawDoc)

                save(rawDoc)

                rtp.process(rawDoc.createDate)

            }

            statCol.update(["_id" : statId], [$set:["combined" : 1]])

            printLog "combine range $statId finish!"

        }
    }

    static main(args) {
        CrawlRawDataCombineFieldsService patFTService = new PatFTCombineFieldsService("PatFT", "Stat")
        patFTService.combineFields()
    }
}
