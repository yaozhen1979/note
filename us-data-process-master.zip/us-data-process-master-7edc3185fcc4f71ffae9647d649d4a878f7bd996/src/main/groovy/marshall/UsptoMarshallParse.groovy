package marshall

import org.slf4j.LoggerFactory

import services.BaseService
import uspto.patent.model.UsPatentMarshallDocument
import utils.JaxbUtil
import utils.MarshallDataUtil
import utils.MongoUtil
import utils.RestTimeProcess
import utils.XmlUtil
import valid.XmlValidator
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.Bytes
import com.mongodb.DBCursor

class UsptoMarshallParse extends BaseService {

    private static Logger log = LoggerFactory.getLogger(UsptoMarshallParse.class);

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");

    def PRETTY_PRINT_INDENT_FACTOR = 4

    def ln = System.getProperty('line.separator')

    def dateStr = "T00:00:00"

    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    //********** arguments ***********

    def dateS = "2016-04-07"

    def dateE = "2016-04-08"

    def rawDbName = "PatentRawUSPTO"

    //    def marshallDbName = "PatentMarshallUSTest"
    def marshallDbName = "PatentMarshallUS"

    //********** arguments ***********

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    static main(args) {

        UsptoMarshallParse parse = new UsptoMarshallParse()

        parse.action()

    }

    def action() {

        //        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()
        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        // raw
        def rawClient = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        def rawCol = rawClient.getDB(rawDbName).getCollection(rawDbName)
        // marshall
        def marshallCol = client.getDB(marshallDbName).getCollection(marshallDbName)
        // error
        def errCol = client.getDB(marshallDbName).getCollection("Error" + marshallDbName)

        def doDateS = Date.parse(dateFormat, dateS + dateStr)

        def doDateE = Date.parse(dateFormat, dateE + dateStr)

        def queryMap = [:]

        queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

        // if marshall db exists, remove that
        /*
        if (marshallCol.count(queryMap) > 0) {

            log.info "datas exist, queryMap $queryMap, remove that!"

            marshallCol.remove(queryMap)

        }
*/
        def rawTotal = rawCol.count(queryMap)

        log.info "raw data date range [${dateS} ~ ${dateE}]"

        RestTimeProcess rtp = new RestTimeProcess(rawTotal, UsptoMarshallParse.class.name)

        DBCursor rawCur = rawCol.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        while (rawCur.hasNext()) {

            // 預期的錯誤true
            boolean isContinued = false
            try {
                def rawDoc = rawCur.next()

                // raw data 非 xml 格式
                if (rawDoc.type != "xml/xml") {
                    writeError(errCol,
                            isGrant(rawDoc.doDate),
                            rawDoc.type,
                            0.toInteger(),
                            "type error",
                            "type error",
                            rawDoc.doDate,
                            rawDoc._id)

                    isContinued = true
                    throw new Exception("type error")
                }

                UsPatentMarshallDocument doc
                try {
                    doc = UsPatentMarshallDocumentGenerator.generator(rawDoc)
                } catch (e) {
                    writeError(errCol,
                            isGrant(rawDoc.doDate),
                            rawDoc.data.xml,
                            1.toInteger(),
                            "generate jaxb properties error",
                            e.toString(),
                            rawDoc.doDate,
                            rawDoc._id)

                    isContinued = true
                    throw new Exception("generate jaxb properties error : ${e}")
                }

                // valid xml with xsd ，為了加快marshall層寫入速度，xsd驗證提前處理
                /*
                 try {
                 XmlValidator.validate(doc)
                 } catch (e) {
                 println "xml validation fails => raw id: " + rawDoc._id
                 writeError(errCol,
                 doc.stat,
                 doc.xml,
                 2.toInteger(),
                 "xml validation fails",
                 e.toString(),
                 rawDoc.doDate,
                 rawDoc._id)
                 }
                 */
                // jaxb convert xml to json string
                try {
                    JaxbUtil.xml2JsonStr(doc)
                } catch (e) {
                    writeError(errCol,
                            doc.stat,
                            doc.xml,
                            3.toInteger(),
                            "jaxb xml to json error",
                            e.toString(),
                            rawDoc.doDate,
                            rawDoc._id)

                    isContinued = true
                    throw new Exception("jaxb xml to json error : ${e}")
                }

                // jsoup convert json string to json object
                def jsonObj
                try {
                    jsonObj = XmlUtil.generateUsOpenDataJsonObject(doc)
                } catch (e) {
                    writeError(errCol,
                            doc.stat,
                            doc.xml,
                            4.toInteger(),
                            "json string to json object error",
                            e.toString(),
                            rawDoc.doDate,
                            rawDoc._id)
                    isContinued = true
                    throw new Exception("json string to json object error : ${e}")
                }

                // gereate marshall doc to insert mongodb
                def marshallDoc
                try {
                    marshallDoc = MarshallDataUtil.generateMarshallData(doc, rawDoc, jsonObj)
                } catch (e) {
                    writeError(errCol,
                            doc.stat,
                            doc.xml,
                            5.toInteger(),
                            "generateMarshallData error",
                            e.toString(),
                            rawDoc.doDate,
                            rawDoc._id)

                    isContinued = true
                    throw new Exception("generateMarshallData error : ${e}")
                }

                //                marshallCol.insert(marshallDoc, com.mongodb.WriteConcern.ACKNOWLEDGED)
                marshallCol.save(marshallDoc)

                //                println marshallDoc
                rtp.process(rawDoc.doDate)

            } catch (e) {
                println "${e}"
                if (!isContinued) {
                    throw e
                }
            }

        }

        log.info "marshall finish!!, date range: $dateS - $dateE"
        //        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "marshall finish", "date range: $dateS - $dateE")

    }

    def writeError(def errCol, int stat, String data, int errCode, String errMsg, String errLog, def doDate, def rawId) {

        def errDoc = [:]
        errDoc << ["stat" : stat]
        errDoc << ["data" : data]
        errDoc << ["createDate" : new Date()]
        errDoc << ["errCode" : errCode]
        errDoc << ["errMsg" : errMsg]
        errDoc << ["errLog" : errLog]
        errDoc << ["doDate" : doDate]
        errDoc << ["relRawDataId" : rawId]
        errCol.save(errDoc)

        // send error mail
        //        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "marshall Error", "Err: $errCode - $errMsg ==> $errLog")
    }

}
