package marshall

import org.slf4j.LoggerFactory

import model.UsPatentMarshallDocument
import utils.JaxbUtils
import utils.MongoUtil
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.Bytes
import com.mongodb.DBCursor

class UsMarshallTest {

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
    
    def PRETTY_PRINT_INDENT_FACTOR = 4

    def ln = System.getProperty('line.separator')

    def dateStr = "T00:00:00"

    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    //********** arguments ***********

    def dateS = "2015-12-03"

    def dateE = "2015-12-04"

    def rawDbName = "PatentRawUSPTO"

    def marshallDbName = "PatentMarshallUS"

    //********** arguments ***********
    
    static {
        mongoLogger.setLevel(Level.OFF);
    }

    public static void main(String[] args) {

        UsMarshallTest test = new UsMarshallTest()

        test.action()

    }
    
    def action() {

        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()

        // raw
        def rawCol = client.getDB(rawDbName).getCollection(rawDbName)
        
        println "date range [${dateS} ~ ${dateE}]"
        
        dateS = dateS + dateStr
        
        dateE = dateE + dateStr

        def doDateS = Date.parse(dateFormat, dateS)

        def doDateE = Date.parse(dateFormat, dateE)

        def queryMap = [:]

        queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

        //        queryMap << ['_id' : new ObjectId("562f09589526810a0f629189")]

        def total = rawCol.count(queryMap)
        
        println "total: $total"

        DBCursor rawCur = rawCol.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT).limit(1)
        
        while (rawCur.hasNext()) {
            
            def rawDoc = rawCur.next()
            
            UsPatentMarshallDocument doc = UsPatentMarshallDocumentGenerator.generator(rawDoc)
            
            JaxbUtils.xml2Json(doc)
            
            println doc.jsonStr
            
            break
        }
        
    }
}
