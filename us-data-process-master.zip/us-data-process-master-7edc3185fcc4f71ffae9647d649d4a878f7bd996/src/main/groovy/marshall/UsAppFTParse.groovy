package marshall

import info.UsptoInfoParse

import org.slf4j.LoggerFactory

import patft.UsptoAppFTWebTool
import patft.exception.GeneralRuntimeException
import patft.vo.patent.UsptoPublicationPatent
import services.BaseService;
import utils.MarshallDataUtil
import utils.MongoUtil
import utils.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.mongodb.DBObject
import com.mongodb.util.JSON

class UsAppFTParse extends BaseService {

    private static Logger log = LoggerFactory.getLogger(UsAppFTParse.class);

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");

    def PRETTY_PRINT_INDENT_FACTOR = 4

    def ln = System.getProperty('line.separator')

    def dateStr = "T00:00:00"

    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    //********** arguments ***********

    def dateS = "2000-01-01"

    def dateE = "2000-01-11"

    def rawDbName = "PatentRawUSPTO"

    def appFtName = "AppFT"

    def statColName = "AppFTStat"

    def marshallDbName = "PatentMarshallUS"

    //********** arguments ***********

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    static main(args) {

        UsAppFTParse parse = new UsAppFTParse()

        parse.action()

    }

    def action() {

        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        // marshall
        def marshallCol = client.getDB(marshallDbName).getCollection(marshallDbName)
        // appFt
        def appFtCol = client.getDB(rawDbName).getCollection(appFtName)
        // Stat
        def statCol = client.getDB(rawDbName).getCollection(statColName)
        // error
        def errCol = client.getDB(marshallDbName).getCollection("Error" + marshallDbName)

        def statCur = statCol.find(['status' : 1,'marshalled' : 0]).sort([_id:1])

        if (statCur.count() == 0) {
            println  "no new record needs to be marshalled ~"
            return
        }

        while (statCur.hasNext()) {

            def statDoc = statCur.next()

            def statId = statDoc._id

            statCol.update(["_id" : statId], [$set:["marshalled" : -1]])

            def queryMap = ["statId" : statId]
            //
            //                        def queryMap = ["statId" : "20010315_20010930"]
            //                        def queryMap = ["_id" : "20010003111"]

            def appFtTotal = appFtCol.count(queryMap)

            println "appFt range $statId , count : $appFtTotal"

            RestTimeProcess rtp = new RestTimeProcess(appFtTotal, UsAppFTParse.class.name)

            //            println "appFtTotal : $appFtTotal"

            def appFtCur = appFtCol.find(queryMap)

            while (appFtCur.hasNext()) {

                def appFtDoc = appFtCur.next()

                //                println "patft id : " + patFtDoc._id

                // html下載錯誤，須重新下載，先記錄在error No patents have matched your query
                if (appFtDoc.data.contains("Error #") || appFtDoc.data.contains("No patents have matched your query")) {
                    writeError(errCol,
                            appFtDoc.data,
                            7.toInteger(),
                            "parse html error",
                            "download failed",
                            appFtDoc._id)

                    continue
                }

                try {

                    String jsonStr = parseHtml2JsonStr(appFtDoc.data)

                    def jsonObj = (DBObject)JSON.parse(jsonStr)

                    def marshallDoc = MarshallDataUtil.generateMarshallDataFromWeb(appFtDoc, jsonObj)

                    rtp.process(marshallDoc.doDate)

                    marshallCol.save(marshallDoc)
                } catch (GeneralRuntimeException gre) {
                    writeError(errCol,
                            appFtDoc.data,
                            6.toInteger(),
                            "parse html error",
                            gre.toString(),
                            appFtDoc._id)

                } catch (Exception e) {
                    writeError(errCol,
                            appFtDoc.data,
                            6.toInteger(),
                            "parse html error",
                            e.toString(),
                            appFtDoc._id)
                    throw e
                }

                //                break

            }


            statCol.update(["_id" : statId], [$set:["marshalled" : 1]])

            printLog "parse range $statId finish!"

            //                        break
        }

    }

    def writeError(def errCol, String data, int errCode, String errMsg, String errLog, def rawId) {

        def errDoc = [:]
        errDoc << ['_id' : rawId]
        errDoc << ["data" : data]
        errDoc << ["createDate" : new Date()]
        errDoc << ["errCode" : errCode]
        errDoc << ["errMsg" : errMsg]
        errDoc << ["errLog" : errLog]
        errDoc << ["relRawDataId" : rawId]
        errCol.save(errDoc)

        printLog "marshall Error, id : $rawId, Err: $errCode - $errMsg ==> $errLog"

    }

    def String parseHtml2JsonStr(String xml) {

        UsptoAppFTWebTool tool = new UsptoAppFTWebTool()

        UsptoPublicationPatent patent = tool.parseHtml(xml)

        GsonBuilder builder = new GsonBuilder()
        builder.setDateFormat("yyyy-MM-dd")
        Gson gson = builder.create()

        return gson.toJson(patent)

    }

}
