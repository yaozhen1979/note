package marshall

import java.text.SimpleDateFormat

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import uspto.patent.model.UsPatentMarshallDocument


class UsPatentMarshallDocumentGenerator {
    
    protected static Logger log = LoggerFactory.getLogger(UsPatentMarshallDocumentGenerator.class);
    
    def static main(String[] args) {
        
    }

    static UsPatentMarshallDocument generator(rawDoc) {
        
        UsPatentMarshallDocument doc = new UsPatentMarshallDocument()

        doc.doDate = rawDoc.doDate

        doc.stat = isGrant(rawDoc.doDate) ? 2.toInteger() : 1.toInteger()

        doc.xml = rawDoc.data.xml
        
        findJaxbProperties(doc)
        
        return doc
    }
    
    def static findJaxbProperties = {UsPatentMarshallDocument doc -> 
        
        if (doc.stat == 1) {
            
            doc.cl = uspto.patent.application.jaxb.UsPatentApplication.class.getClassLoader()
            
            doc.contextPath = "uspto.patent.application.jaxb"
            
        } else if (doc.stat == 2) {
        
            doc.cl = uspto.patent.grant.jaxb.UsPatentGrant.class.getClassLoader()
            
            doc.contextPath = "uspto.patent.grant.jaxb"
        
        }
        
        doc.oxmPath = "/jaxb/oxm/oxm.xml"
        
    }

    def static isGrant = {Date date ->

        def dayNumberOfWeek = new SimpleDateFormat('u').format(date)

        return dayNumberOfWeek == "2"
    }
}
