package marshall

import info.UsptoInfoParse

import java.util.regex.Pattern

import org.slf4j.LoggerFactory

import patft.UsptoPatFTWebTool
import patft.exception.GeneralRuntimeException
import patft.vo.patent.UsptoIssuePatent
import services.BaseService
import utils.MarshallDataUtil
import utils.MongoUtil
import utils.RestTimeProcess
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.mongodb.DBObject
import com.mongodb.util.JSON

class UsPatFTParse extends BaseService {

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");

    //********** arguments ***********
    def rawDbName = "PatentRawUSPTO"

    def patFtName = "PatFT"

    def statColName = "PatFTStat"

    def marshallDbName = "PatentMarshallUS"

    //********** arguments ***********

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    static main(args) {

        UsPatFTParse parse = new UsPatFTParse()

        parse.action()

    }

    def action() {

        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        // marshall
        def marshallCol = client.getDB(marshallDbName).getCollection(marshallDbName)
        // patFt
        def patFtCol = client.getDB(rawDbName).getCollection(patFtName)
        // Stat
        def statCol = client.getDB(rawDbName).getCollection(statColName)
        // error
        def errCol = client.getDB(marshallDbName).getCollection("Error" + marshallDbName + "1")

        def statCur = statCol.find(['status' : 1,'marshalled' : 0]).sort([_id:1])
        
//        def statCur = statCol.find(['_id' : "19780101_19780331", "status" : 1, 'marshalled' : 0])

        if (statCur.count() == 0) {
            println  "no new record needs to be marshalled ~"
            return
        }

        while (statCur.hasNext()) {

            def statDoc = statCur.next()

            def statId = statDoc._id
            
            statCol.update(["_id" : statId],[$set:["marshalled" : -1]])
            
            def queryMap = ["statId" : statId]
            // 19760101_19761231 19770101_19771231,19780101_19780331
//            def queryMap = ["statId" : "19760101_19761231"]
//            def queryMap = ["_id" : "4307845"]
            
            println "count patFt range $statId "
            def patFtTotal = patFtCol.count(queryMap)

            RestTimeProcess rtp = new RestTimeProcess(patFtTotal, UsPatFTParse.class.name)

            println "patFtTotal : $patFtTotal"

            def patFtCur = patFtCol.find(queryMap)
            
            while (patFtCur.hasNext()) {

                def patFtDoc = patFtCur.next()
                
                // html下載錯誤，須重新下載，先記錄在error No patents have matched your query 
                if (patFtDoc.data.contains("Error #") || patFtDoc.data.contains("No patents have matched your query")) {
                    writeError(errCol,
                        patFtDoc.data,
                        7.toInteger(),
                        "parse html error",
                        "download failed",
                        patFtDoc._id)
                    
                    continue
                }
                
                try {
                    
                    String jsonStr = parseHtml2JsonStr(patFtDoc.data)
                    
                    def jsonObj = (DBObject)JSON.parse(jsonStr)
                    
                    def marshallDoc = MarshallDataUtil.generateMarshallDataFromWeb(patFtDoc, jsonObj)
                    
                    rtp.process(marshallDoc.doDate)
                    
                    marshallCol.save(marshallDoc)
                } catch (GeneralRuntimeException gre) {
                    writeError(errCol,
                    patFtDoc.data,
                    6.toInteger(),
                    "parse html error",
                    gre.toString(),
                    patFtDoc._id)
                
                } catch (Exception e) {
                    writeError(errCol,
                        patFtDoc.data,
                        6.toInteger(),
                        "parse html error",
                        e.toString(),
                        patFtDoc._id)
                    throw e
                }
                
//                break
                
            }
            
            statCol.update(["_id" : statId], [$set:["marshalled" : 1]])
            
            printLog "parse range $statId finish!"

//            break
        }

    }
    
     def writeError(def errCol, String data, int errCode, String errMsg, String errLog, def rawId) {
        
        def errDoc = [:]
        errDoc << ['_id' : rawId]
        errDoc << ["data" : data]
        errDoc << ["createDate" : new Date()]
        errDoc << ["errCode" : errCode]
        errDoc << ["errMsg" : errMsg]
        errDoc << ["errLog" : errLog]
        errDoc << ["relRawDataId" : rawId]
        errCol.save(errDoc)

        // send error mail
//        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "marshall Error", "Err: $errCode - $errMsg ==> $errLog")
       printLog "marshall Error, id : $rawId, Err: $errCode - $errMsg ==> $errLog"
    }
    
    def String parseHtml2JsonStr(String xml) {
        
        UsptoPatFTWebTool tool = new UsptoPatFTWebTool()

        UsptoIssuePatent patent = tool.parseHtml(xml)

        GsonBuilder builder = new GsonBuilder()
        builder.setDateFormat("yyyy-MM-dd")
        Gson gson = builder.create()
        
        return gson.toJson(patent)
        
    }

}
