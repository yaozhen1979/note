package info

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import services.BaseService
import utils.MongoUtil
import utils.RestTimeProcess
import ch.qos.logback.classic.Level

class UsptoInfoParse extends BaseService {

    private static ch.qos.logback.classic.Logger log = LoggerFactory.getLogger(UsptoInfoParse.class);

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");

    def PRETTY_PRINT_INDENT_FACTOR = 4

    def ln = System.getProperty('line.separator')

    def dateStr = "T00:00:00"

    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    //********** arguments ***********

    def dateS = "2015-11-17"

    def dateE = "2015-11-18"

    def marshallDbName = "PatentMarshallUS"

    def infoDbName = "PatentInfoUS"

    //********** arguments ***********

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    static main(args) {

        UsptoInfoParse parse = new UsptoInfoParse()

        parse.action()

    }

    def action() {

        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()
        // marshall
        def marshallCol = client.getDB(marshallDbName).getCollection(marshallDbName)
        // info
        def infoCol = client.getDB(infoDbName).getCollection(infoDbName)
        // error
        def errCol = client.getDB(infoDbName).getCollection("Error" + infoDbName)

        def doDateS = Date.parse(dateFormat, dateS + dateStr)

        def doDateE = Date.parse(dateFormat, dateE + dateStr)

        def queryMap = [:]

        queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

        def marshallTotal = marshallCol.count(queryMap)

        println "marshall data date range [${dateS} ~ ${dateE}]"

        RestTimeProcess rtp = new RestTimeProcess(marshallTotal, UsptoInfoParse.class.name)
        
        println "marshallTotal : $marshallTotal"

//        DBCursor marshallCur = marshallCol.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

    }

}
