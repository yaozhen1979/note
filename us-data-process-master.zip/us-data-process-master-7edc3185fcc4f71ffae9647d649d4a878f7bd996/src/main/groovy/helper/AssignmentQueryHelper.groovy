package helper

import utils.MongoUtil

class AssignmentQueryHelper {
    
    def col
    public AssignmentQueryHelper() {
        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017).getClient()
        col = client.getDB("AssignmentInfoUSPTO").getCollection("AssignmentInfoUSPTO")
        
    }
    
    /**
     * 以 patentNumber 查詢 AssignmentInfoUSPTO Object
     * @param pn
     * @return AssignmentInfoUSPTO Object
     */
    def findAsgByPatentNumber(String pn) {

        def cursor = col.find([patentNumber:pn]).sort(["recordedDate" : -1])
        
        if (cursor.count() == 0) {
            return null
        }
        
        return cursor.next()
    }
    
    /**
     * 以 patentNumber 查詢 AssignmentInfoUSPTO 取得相對應的 appDate <BR>
     * AssignmentInfoUSPTO 下的 appDate 和 patentNumber 為 list，<BR>
     * 所以必須比對 patentNumber 後取得相對應的 appDate 位置
     * @param pn
     * @return appDate
     */
    def Date findAppDateByPatentNumber(String pn) {
        
        def asgDoc = findAsgByPatentNumber(pn)
        
        Date appDate = null
        def appDateIdx = null
        if (!!asgDoc) {
            def patentArry = asgDoc.patentNumber
            
            // AssignmentInfoUSPTO 下的 appDate 和 patentNumber 為 list，所以必須比對 patentNumber 後取得相對應的 appDate 位置
            patentArry.eachWithIndex {num, idx ->
                if (pn == num) {
                    appDateIdx = idx.toInteger()
                }
            }
            
            if (appDateIdx != null) {
                appDate =  asgDoc.appDate[appDateIdx]
            }
            
        }
        
        return appDate
    }

    
    static main(args) {
    
        AssignmentQueryHelper helper = new AssignmentQueryHelper()
        Date appDate = helper.findAppDateByPatentNumber("PP11193")
        println "appDate : $appDate"
        
    }

}
