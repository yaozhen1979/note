package helper

import patentdata.utils.ConfigUtil
import services.BaseService;
import utils.MongoUtil

class CPCQueryHelper extends BaseService {

    def col
    public CPCQueryHelper() {
        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        col = client.getDB("USPTO").getCollection("CPC_201510")
        
    }

    /**
     * 以patentNumber查詢CPC
     * @param pn
     * @return
     */
    def findCPCByPatentNumber(String pn) {
        
        def cursor = col.find([_id:pn])
        
        if (cursor.count() == 0) {
            return null
        }
        
        def cpcDoc = [:]
        cursor.each  {
            cpcDoc = it
        }
        
        cpcDoc << ["appNo" : cpcDoc."data"."ApplicationIdentification"."ApplicationNumber"."ApplicationNumberText"]
        
        if (cpcDoc.stat == 1) {
            cpcDoc << ["kindCode" : cpcDoc."data"."PatentPublicationIdentification"."PatentDocumentKindCode"]
        } else {
            cpcDoc << ["kindCode" : cpcDoc."data"."PatentGrantIdentification"."PatentDocumentKindCode"]
        }

        return cpcDoc
    }


    static main(args) {

        CPCQueryHelper helper = new CPCQueryHelper()
        def cpc = helper.findCPCByPatentNumber("US006014747")
        if (!!cpc) {
            println "kindcode : ${cpc.kindCode}, appNo : ${cpc.appNo}"
        } else {
            println "patentNumber D419398 could not find data"
        }
        
    }
}
