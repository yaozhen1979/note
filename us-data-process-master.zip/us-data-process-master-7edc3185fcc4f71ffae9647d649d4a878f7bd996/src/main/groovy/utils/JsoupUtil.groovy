package utils

import org.jsoup.Jsoup
import org.slf4j.LoggerFactory

import uspto.patent.model.UsPatentMarshallDocument
import ch.qos.logback.classic.Logger

import com.mongodb.DBObject
import com.mongodb.util.JSON

class JsoupUtil {
    
    private static Logger log = LoggerFactory.getLogger(JsoupUtil.class);
    
    /**
     * @param doc
     * 特別處理[invention-title], [abstract], [description], [claims]這4個欄位
     * 上述4個資料, 並不特別parse其data為json format, 而只取出其中的text而已
     * @return
     */
    static generateUsOpenDataJsonObject(UsPatentMarshallDocument doc) {
        
//        File test = new File("./tmp/test.txt")
//        test << doc.jsonStr
        
        def jsonObj = (DBObject)JSON.parse(doc.jsonStr)
        // JsonSlurper
//        def jsonObj = new JsonSlurper().parseText(doc.jsonStr)
        // org json
//        def jsonObj = new JSONObject(doc.jsonStr)
        
        
        def root = getUSPatentRoot(doc)
        
        if (!!root) {
            
            // docNumber
            def docNumber
            if (doc.stat == 1) {
                docNumber = root.select("us-bibliographic-data-application publication-reference document-id doc-number").text()
            } else {
                docNumber = root.select("us-bibliographic-data-grant publication-reference document-id doc-number").text()
            }
            doc.docNo = docNumber
            
            // title
            def titleText
            if (doc.stat == 1) {
                titleText = trimStr(root.select("us-bibliographic-data-application invention-title")[0].html())
                jsonObj."us-patent-application"."us-bibliographic-data-application"."invention-title" = titleText
            } else {
                titleText = trimStr(root.select("us-bibliographic-data-grant invention-title")[0].html())
                jsonObj."us-patent-grant"."us-bibliographic-data-grant"."invention-title" = titleText
            }
            
            // description
            def descriptionText = trimStr(root.select("description[id=description]")[0].html())
            if (doc.stat == 1) {
                jsonObj."us-patent-application"."description" = descriptionText
            } else {
                jsonObj."us-patent-grant"."description" = descriptionText
            }
            
            // abstract
            if (!!root.select("abstract[id=abstract]")[0]) {
                def abstractText = trimStr(root.select("abstract[id=abstract]")[0].html())
                if (doc.stat == 1) {
                    jsonObj."us-patent-application"."abstract" = abstractText
                } else {
                    jsonObj."us-patent-grant"."abstract" = abstractText
                }
            }
            
            // claims
            def claimsText = trimStr(root.select("claims[id=claims]")[0].html())
            if (doc.stat == 1) {
                jsonObj."us-patent-application"."claims" = claimsText
            } else {
                jsonObj."us-patent-grant"."claims" = claimsText
            }
            
            // otherReferences內文含有html tag,不需轉成json, 故直接由xml中取出後取代, only grant
            parseOtherReferences(doc.xml, jsonObj)
            
            return jsonObj
            
        } else {
            throw new Exception("xml root is not exists!")
        }
        
    }
    
    /**
     * @param doc
     * @return
     */
    static getUSPatentRoot(UsPatentMarshallDocument doc) {
        
        def jsoupDoc = Jsoup.parse(doc.xml.replace("&#", "&amp;#"))
//        def jsoupDoc = Jsoup.parse(doc.xml)
        
        def root
        if (doc.stat == 1) {
            root = jsoupDoc.select("us-patent-application")[0]
        } else {
            root = jsoupDoc.select("us-patent-grant")[0]
        }
        
        return root
    }
    
    /**
     * 依所傳入的每行字串, 執行trim().
     */
    private def static trimStr = { String text ->

        def trimStr = ""
        
        text.eachLine { line ->
            def lineStr = line.toString()
            trimStr += lineStr.trim().replace("<!--?", "<?").replace("?-->", "?>")
        }

        return trimStr
    }
    
    
    // otherReferences內文含有html tag,不需轉成json, 故直接由xml中取出後取代
    static parseOtherReferences(xmlStr, data) {
        
        def otherReferences = [:]
        
        if (xmlStr =~ /<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit><category>([\s\S]*?)<\/category><\/us-citation>/) {
            
            def cnt = 0
            
            xmlStr.replaceAll(/<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit><category>([\s\S]*?)<\/category><\/us-citation>/) {fullMatch, content, category ->
                
                cnt++
                
                otherReferences[cnt] =  content + " " + category + " ."
    
            }
    
        }
        
        if (otherReferences.size() > 0) {
            
            if (data['us-patent-grant']['us-bibliographic-data-grant']['otherReferences'] == null) {
                
                data['us-patent-grant']['us-bibliographic-data-grant']['otherReferences'] = []
                
            }
            
            otherReferences.each{ k, v ->
                 
                data['us-patent-grant']['us-bibliographic-data-grant']['otherReferences'].push(v)
                
            }
        }
        
    }
    
}
