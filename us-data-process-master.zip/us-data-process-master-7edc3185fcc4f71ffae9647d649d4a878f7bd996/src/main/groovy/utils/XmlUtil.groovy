package utils

import org.apache.commons.io.ByteOrderMark
import org.apache.commons.io.IOUtils
import org.apache.commons.io.input.BOMInputStream
import patentdata.utils.CDataProcess

import uspto.patent.model.UsPatentMarshallDocument
import xml.parse.CDataUtil;

import com.mongodb.DBObject
import com.mongodb.util.JSON
import common.Constants

class XmlUtil {

    final static String DTD_REMOVE_PATTERN = "<!DOCTYPE[\\S\\s]*?>"

    public static String reomoveDTDDeclaration (String xml) {
        return xml.replaceAll(DTD_REMOVE_PATTERN, "")
    }
    
    /**
     * @param doc
     * 特別處理[invention-title], [abstract], [description], [claims]這4個欄位
     * 上述4個資料, 並不特別parse其data為json format, 而只取出其中的text而已
     * @return
     */
    static generateUsOpenDataJsonObject(UsPatentMarshallDocument doc) {
        
        def jsonObj = (DBObject)JSON.parse(doc.jsonStr)
        // xml to xmlObject
        def root = getUSPatentRoot(doc)
        
        if (!!root) {
            
            // docNumber
            def docNumber
            if (doc.stat == 1) {
                docNumber = root."us-bibliographic-data-application"."publication-reference"."document-id"."doc-number".text()
            } else {
                docNumber = root."us-bibliographic-data-grant"."publication-reference"."document-id"."doc-number".text()
            }
            doc.docNo = docNumber
            
            // title
            parseTitleText(root, jsonObj, doc.stat)
            
            // description
            parseDescText(root, jsonObj, doc.stat)
            
            // abstract
            parseAbstractText(root, jsonObj, doc.stat)
            
            // claims
            parseClaimsText(root, jsonObj, doc.stat)
            
            // otherReferences內文含有html tag,不需轉成json, 故直接由xml中取出後取代, only grant
            parseOtherReferences(doc.xml, jsonObj)
            
            return jsonObj
            
        } else {
            throw new Exception("xml root is not exists!")
        }
        
    }
    
    /**
     * @param xmlRoot
     * @param jsonObj
     * @param stat
     * @return
     */
    static parseTitleText(def xmlRoot, def jsonObj, int stat) {
        
        def titleText
        if (stat == 1) {
            titleText = xmlRoot."us-bibliographic-data-application"."invention-title".text()
            jsonObj."us-patent-application"."us-bibliographic-data-application"."invention-title" = titleText
        } else {
            titleText = xmlRoot."us-bibliographic-data-grant"."invention-title".text()
            jsonObj."us-patent-grant"."us-bibliographic-data-grant"."invention-title" = titleText
        }
        
    }
    
    /**
     * @param xmlRoot
     * @param jsonObj
     * @param stat
     * @return
     */
    static parseDescText(def xmlRoot, def jsonObj, int stat) {
        
        def descText = xmlRoot."description".text()
        
        if (stat == 1) {
            jsonObj."us-patent-application"."description" = descText
        } else {
            jsonObj."us-patent-grant"."description" = descText
        }
        
    }
    
    /**
     * @param xmlRoot
     * @param jsonObj
     * @param stat
     * @return
     */
    static parseAbstractText(def xmlRoot, def jsonObj, int stat) {
        
        def abstractText = xmlRoot."abstract".text()
        if (!!abstractText) {
            if (stat == 1) {
                jsonObj."us-patent-application"."abstract" = abstractText
            } else {
                jsonObj."us-patent-grant"."abstract" = abstractText
            }
        }
    }
    
    /**
     * @param xmlRoot
     * @param jsonObj
     * @param stat
     * @return
     */
    static parseClaimsText(def xmlRoot, def jsonObj, int stat) {
        
        def claimsText = xmlRoot."claims".text()
        
        if (stat == 1) {
            jsonObj."us-patent-application"."claims" = claimsText
        } else {
            jsonObj."us-patent-grant"."claims" = claimsText
        }
        
    }
    
    
    /**
     * @param doc
     * @return
     */
    static getUSPatentRoot(UsPatentMarshallDocument doc) {
        
        CDataProcess process = CDataUtil.getCDataProcessByStat(doc.stat)
        String newXml = process.transfer(doc.xml);
        def root = new XmlParser().parseText(XmlUtil.reomoveDTDDeclaration(newXml))
        
        return root
    }
    
    
    // otherReferences內文含有html tag,不需轉成json, 故直接由xml中取出後取代
    static parseOtherReferences(xmlStr, data) {
        
        def otherReferences = [:]

        if (xmlStr =~ /<citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/citation>/) {

            def cnt = 0

            xmlStr.replaceAll(/<citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/citation>/) {fullMatch, content, categoryData->

                cnt++

                def category = null
                fullMatch.replaceAll(/<category>([\s\S]*?)<\/category>/) {fullMatch1, cg ->
                    category = cg;
                }
                
                if (!!category) {
                    otherReferences[cnt] =  content + " " + category + " .";
                } else {
                    otherReferences[cnt] =  content;
                }
                
            }

        }
        
        if (xmlStr =~ /<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/us-citation>/) {

            def cnt = 0

            xmlStr.replaceAll(/<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/us-citation>/) {fullMatch, content, categoryData->

                cnt++

                def category = null
                fullMatch.replaceAll(/<category>([\s\S]*?)<\/category>/) {fullMatch1, cg ->
                    category = cg;
                }

                if (!!category) {
                    otherReferences[cnt] =  content + " " + category + " .";
                } else {
                    otherReferences[cnt] =  content;
                }

            }

        }
        
        if (otherReferences.size() > 0) {

            def array = [];
            
            otherReferences.each{ k, v ->
                array << v;
            }
            
            data['us-patent-grant']['us-bibliographic-data-grant'] << ['otherReferences' : array]
        }
        
    }

    
    /**
     *
     * @param xmlStr
     * @return
     */
    static def xml2Object(String xmlStr) {
        def fileText = XmlUtil.reomoveDTDDeclaration(xmlStr)
        // NOTE: 判斷是否為BOM File, 且此判斷是否要移到RawData中實做 ???
        InputStream is = new ByteArrayInputStream(fileText.getBytes(Constants.LANG_ENCODING));
        BOMInputStream bomIn = new BOMInputStream(is, false, ByteOrderMark.UTF_8);
        if (bomIn.hasBOM()) {
            fileText = IOUtils.toString(bomIn, "UTF-8");
        }
        is.close()
        return new XmlParser().parseText(fileText)
    }

    /**
     * 依所傳入的每行字串, 執行trim().
     */
    private def static trimStr = { String text ->

        def trimStr = ""
        
        text.eachLine { line ->
            def lineStr = line.toString()
            trimStr += lineStr.trim().replace("<!--?", "<?").replace("?-->", "?>")
        }

        return trimStr
    }

}
