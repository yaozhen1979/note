package utils

//@Grab('org.eclipse.persistence:org.eclipse.persistence.moxy:2.6.1-RC1')
//@Grab('javax.validation:validation-api:1.1.0.Final')
//@Grab('org.eclipse.persistence:eclipselink:2.6.1')
//@Grab('com.sun.xml.bind:jaxb-xjc:2.2.11')
//@Grab('javax.xml.bind:jaxb-api:2.2.12')
//@Grab('com.sun.xml.bind:jaxb-core:2.2.11')

import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller

import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType
import org.slf4j.LoggerFactory

import uspto.patent.application.jaxb.UsPatentApplication
import uspto.patent.grant.jaxb.UsPatentGrant
import uspto.patent.model.UsPatentMarshallDocument
import ch.qos.logback.classic.Logger
import common.Constants;


class JaxbUtil {

    private static Logger log = LoggerFactory.getLogger(JaxbUtil.class);
    
    private static boolean jaxbInited;
    private static Unmarshaller unmarshallerAppl;
    private static Unmarshaller unmarshallerGrant;
    private static Marshaller marshallerAppl;
    private static Marshaller marshallerGrant;
    
    private static void jaxbInit(UsPatentMarshallDocument doc) throws Exception {
        
        if (jaxbInited) {
            return
        }
        
        // 公開
        JAXBContext jcAppl = JAXBContext.newInstance(Constants.JAXB_CONTEXT_PATH_APPLICATION)
        unmarshallerAppl = jcAppl.createUnmarshaller()
        // 公告
        JAXBContext jcGrant = JAXBContext.newInstance(Constants.JAXB_CONTEXT_PATH_GRANT)
        unmarshallerGrant = jcGrant.createUnmarshaller()
        /*
        InputStream importMoxyBinding = JaxbUtil.class.getResourceAsStream(Constants.JAXB_OXM_PATH)
        List<InputStream> moxyBindings = new ArrayList<>()
        moxyBindings.add(importMoxyBinding)
        */
        Map<String, Object> props = new HashMap<>()
        
//        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings)
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false)
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON)

        // 公開
        JAXBContext jc1Appl = JAXBContext.newInstance(Constants.JAXB_CONTEXT_PATH_APPLICATION, uspto.patent.application.jaxb.UsPatentApplication.class.getClassLoader(), props)
        marshallerAppl = jc1Appl.createMarshaller()
        marshallerAppl.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json")
        marshallerAppl.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshallerAppl.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)
        // 公告
        JAXBContext jc1Grant = JAXBContext.newInstance(Constants.JAXB_CONTEXT_PATH_GRANT, uspto.patent.grant.jaxb.UsPatentGrant.class.getClassLoader(), props)
        marshallerGrant = jc1Grant.createMarshaller()
        marshallerGrant.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json")
        marshallerGrant.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshallerGrant.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)

        jaxbInited = true;
    }
    
    public static void xml2JsonStr(UsPatentMarshallDocument doc) throws Exception {
        
        jaxbInit(doc)
        
        def xml = XmlUtil.reomoveDTDDeclaration(doc.xml)
        
        InputStream xmlStream = new ByteArrayInputStream(xml.getBytes(Constants.LANG_ENCODING))
        StringWriter sw = new StringWriter()
        
        if (doc.stat == 2) {
            UsPatentGrant usPatentGrant = (UsPatentGrant) unmarshallerGrant.unmarshal(xmlStream);
            usPatentGrant.setDescription(null);
            usPatentGrant.setClaims(null);
            usPatentGrant.getAbstract().clear();
            
            marshallerGrant.marshal(usPatentGrant, sw);
            
        } else {
            UsPatentApplication usPatentApplication = (UsPatentApplication) unmarshallerAppl.unmarshal(xmlStream);
            usPatentApplication.setDescription(null);
            usPatentApplication.setClaims(null);
            usPatentApplication.getAbstract().clear();
            marshallerAppl.marshal(usPatentApplication, sw);
            
        }
        
        doc.jsonStr = sw.toString()
        
    }
}
