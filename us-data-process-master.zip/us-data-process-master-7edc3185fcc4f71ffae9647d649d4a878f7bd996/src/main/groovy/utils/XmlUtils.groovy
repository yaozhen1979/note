package utils

class XmlUtils {
    
    final static String DTD_REMOVE_PATTERN = "<!DOCTYPE[\\S\\s]*?>"

    static reomoveDTDDeclaration = {String xml ->
        return xml.replaceAll(DTD_REMOVE_PATTERN, "")
    }
}
