package utils

import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.eclipse.persistence.jaxb.JAXBContext
import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType

import model.UsPatentMarshallDocument


class JaxbUtils {
    
    private static boolean inited
    private static Unmarshaller unmarshaller
    private static Marshaller marshaller
    
    private static void jaxbInit(UsPatentMarshallDocument doc) throws Exception {
        
        if (inited) {
            return
        }
        println "contextPath : $doc.contextPath"
        JAXBContext jc = JAXBContext.newInstance(doc.contextPath)
        unmarshaller = jc.createUnmarshaller()
        
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI)
        InputStream xsdis = JaxbUtils.class.getResourceAsStream(doc.xsdPath)
        Schema schema = sf.newSchema(new StreamSource(xsdis))
        unmarshaller.setSchema(schema)
        
        println 'valid pass'
        
        InputStream importMoxyBinding = JaxbUtils.class.getResourceAsStream(doc.oxmPath)
        List<InputStream> moxyBindings = new ArrayList<>()
        moxyBindings.add(importMoxyBinding)
        Map<String, Object> props = new HashMap<>()
        
        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings)
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false)
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON)

        JAXBContext jc1 = JAXBContext.newInstance(doc.contextPath, doc.cl, props)
        
        marshaller = jc1.createMarshaller()
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json")
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)

        inited = true;
        
    }
    
    static UsPatentMarshallDocument xml2Json(UsPatentMarshallDocument doc) throws Exception {
        
        jaxbInit(doc)
        
        def xml = XmlUtils.reomoveDTDDeclaration(doc.xml)
//        println "xml: $xml"
        
        InputStream xmlStream = new ByteArrayInputStream(xml.getBytes("utf-8"))
        
        Object elem = unmarshaller.unmarshal(xmlStream)
        StringWriter sw = new StringWriter()
        marshaller.marshal(elem, sw)
        
        doc.jsonStr = sw.toString()
        
        return doc
        
    }
    
}
