package utils

//@Grab('org.apache.commons:commons-email:1.4'')

import org.apache.commons.mail.Email
import org.apache.commons.mail.SimpleEmail

class MailUtil {
    
    /**
     * 
     * @param emailTo
     * @param subject
     * @param msg
     */
    static void sendToPatentCloud(def emailTo, def subject, def msg) {
        
        Email email = new SimpleEmail();
        email.setHostName("10.60.94.110");
        email.setSmtpPort(25);
        // email.setAuthenticator(new DefaultAuthenticator("username", "password"));
        // email.setSSLOnConnect(true);
        email.setFrom("service@patentcloud.com");
        email.setSubject(subject);
        email.setMsg(msg);
        // email.addTo("tonykuo@patentcloud.com", "tony kuo");
        // email.addTo("mikelin@patentcloud.com", "tony kuo");
        email.addTo(emailTo);
        email.send();
        
        println "send mail complete..."
    } 
    
    def static main(args) {
        
        sendToPatentCloud("mikelin@patentcloud.com","iamsubject","iammsg")
    }
    
}
