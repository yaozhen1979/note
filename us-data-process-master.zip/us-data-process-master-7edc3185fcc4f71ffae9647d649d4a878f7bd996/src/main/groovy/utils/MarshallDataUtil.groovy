package utils

import org.slf4j.LoggerFactory

import services.BaseService
import uspto.patent.model.UsPatentMarshallDocument
import ch.qos.logback.classic.Logger

class MarshallDataUtil extends BaseService {

    private static Logger log = LoggerFactory.getLogger(MarshallDataUtil.class);

    static generateMarshallData(UsPatentMarshallDocument doc, def rawDoc, def jsonObj) {

        def marshallDoc = [:]

        marshallDoc['_id'] = parsePatentNumberWithoutPrefix(doc.docNo)

        marshallDoc['data'] = jsonObj

        marshallDoc['pto'] = "USPTO"

        marshallDoc['doDate'] = rawDoc.doDate

        marshallDoc['stat'] = doc.stat

        def srcId = ['_id':rawDoc._id]

        marshallDoc['relRawdatas'] = [srcId]

        marshallDoc['relRawType'] = "XML"

        marshallDoc << ['mongoSyncFlag' : ['init' : new Date(), 'last' : new Date()]]

        marshallDoc['tagAndFile'] = [['file': 'UsptoMarshallParse.groovy', 'tag' : 'v1.0.0']]

        marshallDoc['truncate'] = (!!rawDoc.truncate) ? rawDoc.truncate : false

        return marshallDoc
    }

    static generateMarshallDataFromWeb(def data, def jsonObj) {

        def marshallDoc = [:]

        marshallDoc['_id'] = data._id
        
        marshallDoc['statId'] = data.statId

        marshallDoc['data'] = jsonObj

        marshallDoc['pto'] = "USPTO"

        def doDateStr = (!!jsonObj.issueDate) ? jsonObj.issueDate : jsonObj.publicationDate

        marshallDoc['doDate'] = toISODate(doDateStr, "yyyy-MM-dd")

        marshallDoc['stat'] = (!!jsonObj.issueDate) ? 2.toInteger() : 1.toInteger()

        def srcId = ['_id': data._id]

        marshallDoc['relRawdatas'] = [srcId]

        marshallDoc['relRawType'] = "HTML"

        marshallDoc << ['mongoSyncFlag' : ['init' : new Date(), 'last' : new Date()]]
        
        def file = (marshallDoc.stat == 1) ? "UsAppFTParse.groovy" : "UsPatFTParse.groovy"

        marshallDoc['tagAndFile'] = [['file': file, 'tag' : 'v1.0.0']]

        marshallDoc['truncate'] = false

        return marshallDoc
    }

    static parsePatentNumberWithoutPrefix(docNumber) {

        def patentNumber = ""

        if (docNumber =~ /D0*[1-9]\d+/) {

            docNumber.replaceAll(/D(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "D" + serialNo
            }
        } else if (docNumber =~ /RE0*[1-9]\d+/) {

            docNumber.replaceAll(/RE(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "RE" + serialNo
            }
        } else if (docNumber =~ /H0*[1-9]\d+/) {

            docNumber.replaceAll(/H(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "H" + serialNo
            }
        } else if (docNumber =~ /PP0*[1-9]\d+/) {

            docNumber.replaceAll(/PP(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "PP" + serialNo
            }
        } else if (docNumber =~ /T0*[1-9]\d+/) {

            docNumber.replaceAll(/T(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "T" + serialNo
            }
        } else if (docNumber =~ /^\d+$/) {

            docNumber.replaceAll(/(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = serialNo
            }
        } else {

            throw new RuntimeException("No PatentNumber or PatentNumber is not available : $docNumber")
        }

        return patentNumber
    }

    static parsePatentNumber(docNumber) {

        def patentNumber = ""

        if (docNumber =~ /D0*[1-9]\d+/) {

            docNumber.replaceAll(/D(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "US0" + zeros + "D" + serialNo
            }
        } else if (docNumber =~ /RE0*[1-9]\d+/) {

            docNumber.replaceAll(/RE(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "US0" + zeros + "RE" + serialNo
            }
        } else if (docNumber =~ /H0*[1-9]\d+/) {

            docNumber.replaceAll(/H(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "US0" + zeros + "H" + serialNo
            }
        } else if (docNumber =~ /PP0*[1-9]\d+/) {

            docNumber.replaceAll(/PP(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "US0" + zeros + "PP" + serialNo
            }
        } else if (docNumber =~ /^\d{8}$/) {

            patentNumber = "US0" + docNumber
        } else if (docNumber =~ /^\d{11}$/) {

            patentNumber = docNumber
        } else{

            throw new RuntimeException("No PatentNumber or PatentNumber is not available")
        }

        return patentNumber
    }
}
