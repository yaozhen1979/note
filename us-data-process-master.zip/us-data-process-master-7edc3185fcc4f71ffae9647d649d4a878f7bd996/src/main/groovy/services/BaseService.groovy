package services

import java.text.SimpleDateFormat

import org.slf4j.Logger
import org.slf4j.LoggerFactory

class BaseService {

    protected static Logger log = LoggerFactory.getLogger(BaseService.class);

    //print log with format date
    def static printLog(msg) {

        println new SimpleDateFormat("yyyy-MM-dd HH:ss:mm").format(new Date()) + " " + msg

    }

    def static isGrant(Date date) {

        def dayNumberOfWeek = new SimpleDateFormat('u').format(date)

        return dayNumberOfWeek == "2"
    }
    
    def static toISODate(def dateNumber, def pattern) {

        def doDate = null
        TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

        SimpleDateFormat sdf = new SimpleDateFormat(pattern)

        doDate = sdf.parse(dateNumber)

        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Taipei"))

        return doDate
    }

}
