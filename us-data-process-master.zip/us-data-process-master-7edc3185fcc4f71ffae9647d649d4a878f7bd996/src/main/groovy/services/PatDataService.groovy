package services

import com.patentdata.model.PatData;

class PatDataService {

    static main(args) {
    
    }
    
    def void generatePatData(Map marshallDoc, String country) {
        
        PatData patData = new PatData();
        patData.setPatId("")
    }

}
