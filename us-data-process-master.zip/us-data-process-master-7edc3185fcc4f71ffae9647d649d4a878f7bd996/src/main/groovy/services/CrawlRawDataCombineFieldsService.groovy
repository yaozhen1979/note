package services

import helper.AssignmentQueryHelper;
import helper.CPCQueryHelper
import utils.MongoUtil

abstract class CrawlRawDataCombineFieldsService extends BaseService {
    
    CPCQueryHelper cpcQuery = new CPCQueryHelper()
    AssignmentQueryHelper asgQuery = new AssignmentQueryHelper()
    
    def col
    def statCol
    public CrawlRawDataCombineFieldsService(String collName, String statCollName) {
        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient()
        col = client.getDB("PatentRawUSPTO").getCollection(collName)
        statCol = client.getDB("PatentRawUSPTO").getCollection(statCollName)
    }
    
    abstract def void combineFields()
    
    /**
     * 用 patentNumber 查詢 <I>CPC_201510</I>
     * @return
     */
    def findCPCByPatentNumber(String pn) {
        return cpcQuery.findCPCByPatentNumber(pn)
    }
    
    /**
     * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I> 的 <I>appDate</I>
     * @return
     */
    def Date findAppDateByPatentNumber(String pn) {
        return asgQuery.findAppDateByPatentNumber(pn)
    }

    /**
     * 用 patentNumber 查詢 <I>CPC_201510</I> 取得 <I>appNo</I>
     * @return
     */
    def void combineAppNo(def rawDoc, def cpcDoc) {
        if (!!cpcDoc.appNo) {
            rawDoc << [combineCPC : true]
            rawDoc << [appNoCPC : cpcDoc.appNo]
        }
    }
    
    /**
     * 用 patentNumber 查詢 <I>CPC_201510</I> 取得  <I>kindCode</I>
     * @param rawDoc
     * @return
     */
    def void combineKindCode(def rawDoc, cpcDoc) {
        if (!!cpcDoc.kindCode) {
            rawDoc << [combineCPC : true]
            rawDoc << [kindCodeCPC : cpcDoc.kindCode]
        }
    }
    
    /**
     * 轉換 PatFT 或 AppFT 的 id 符合 CPC_201510 的 patentNumber 格式 US0*[1-9]+
     * @param num 為 PatFT 或 AppFT 的 id
     * @return
     */
    def String parseCPCPatentNumber(String num) {
        return  "US" + '0' * (9 - num.length()) + num
    }

    /**
     * 用 patentNumber 查詢 <I>AssignmentInfoUSPTO</I> 取得 <I>appDate</I>
     * @param pn
     * @param rawDoc
     * @return
     */
    def void combineAppDate(def rawDoc) {
        
        Date appDate = findAppDateByPatentNumber(rawDoc._id)
        if (!!appDate) {
            rawDoc << [combineAsg : true]
            rawDoc << [appDateAsg : appDate]
        }
    }
    
    def void save(def rawDoc) {
        col.save(rawDoc)
    }

    static main(args) {
    }
}
