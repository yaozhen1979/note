package test

import org.jsoup.Jsoup

import utils.XmlUtil


class JsoupTest {

    static main(args) {
    
        String xml = new File("D:\\gitLab\\us-data-process\\xml\\20150361494.xml").text
        /*
        CDataProcess process = new CDataProcess("/us-patent-application/abstract", 
            "/us-patent-application/description", "/us-patent-application/claims",
            "/us-patent-application/us-bibliographic-data-application/invention-title");
        
        String newXml = process.transfer(xml);
        System.out.println(newXml);
        */
        
        
        def root = new XmlParser().parseText(XmlUtil.reomoveDTDDeclaration(xml))
        
        println root."description".text()
        
        println "finish!!"
    }

}
