package test

import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import utils.MailUtil
import utils.MongoUtil
import utils.RestTimeProcess
import ch.qos.logback.classic.Level

import com.mongodb.Bytes
import com.mongodb.DBCursor


public class OtherRefRecover {

    private static Logger logger = LoggerFactory.getLogger(OtherRefRecover.class);

    private static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");

    static {
        mongoLogger.setLevel(Level.OFF);
    }

    public void process(Map queryMap) {

        def dateBegin = Date.parse("yyyyMMdd", queryMap.beginDate);
        def dateEnd = Date.parse("yyyyMMdd", queryMap.endDate);

        def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];
//        def query = ['_id' : "9290450"];

        def client = new MongoUtil("datateamus", "dhtsrto", "10.60.90.101", 27017).getClient();
        def marshallCol = client.getDB("PatentMarshallUS").getCollection("PatentMarshallUS");
        def rawCol = client.getDB("PatentRawUSPTO").getCollection("PatentRawUSPTO");

        int skip = (StringUtils.isBlank(queryMap.skip)) ? 0 : queryMap.skip.toInteger();
        DBCursor cursor = marshallCol.find(query).limit(0).skip(skip).sort([doDate:1]).addOption(Bytes.QUERYOPTION_NOTIMEOUT);

        RestTimeProcess rtp = new RestTimeProcess(cursor.size(), "OtherRefRecover");

        int cnt = 0;
        while (cursor.hasNext()) {

            def doc = cursor.next();

            rtp.process(doc.doDate);

            // otherReferences 只有grant會出現
            if (doc.stat == 2) {

                def data = doc."data";
                def root = data."us-patent-grant";
                def biblio = root."us-bibliographic-data-grant";

                boolean nplFlag = false;
                try {
                    if (!!biblio."references-cited") {
                        if (!!biblio."references-cited"."citation") {
                            biblio."references-cited"."citation".each {citation ->
                                if (!!citation."nplcit") {
                                    throw new Exception("nplFlag is true, break");
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    nplFlag = true;
                }

                if (nplFlag) {

                    def rawDoc = rawCol.findOne([_id:doc.relRawdatas[0]._id]);

                    String xml = rawDoc.data.xml
                    // otherReferences內文含有html tag,不需轉成json, 故直接由xml中取出後取代, only grant
                    parseOtherReferences(xml, data);

                }
//                println "doc:" + doc
                marshallCol.save(doc);
            }

        }
    }

    public void parseOtherReferences(xmlStr, data) {

        def otherReferences = [:]

        if (xmlStr =~ /<citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/citation>/) {

            def cnt = 0;

            xmlStr.replaceAll(/<citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/citation>/) {fullMatch, content, categoryData->

                cnt++;

                def category = null;
                fullMatch.replaceAll(/<category>([\s\S]*?)<\/category>/) {fullMatch1, cg ->
                    category = cg;
                }

                if (!!category) {
                    otherReferences[cnt] =  content + " " + category + " .";
                } else {
                    otherReferences[cnt] =  content;
                }

            }

        }

        if (xmlStr =~ /<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/us-citation>/) {

            def cnt = 0

            xmlStr.replaceAll(/<us-citation><nplcit[\s\S]*?><othercit>([\s\S]*?)<\/othercit><\/nplcit>(<category>[\s\S]*<\/category>)?<\/us-citation>/) {fullMatch, content, categoryData->

                cnt++;

                def category = null;
                fullMatch.replaceAll(/<category>([\s\S]*?)<\/category>/) {fullMatch1, cg ->
                    category = cg;
                }

                if (!!category) {
                    otherReferences[cnt] =  content + " " + category + " .";
                } else {
                    otherReferences[cnt] =  content;
                }

            }

        }

        if (otherReferences.size() > 0) {

            def array = [];

            otherReferences.each{ k, v ->
                array << v;
            }

            data['us-patent-grant']['us-bibliographic-data-grant'] << ['otherReferences' : array];
        }

    }

    public static void main(String[] args) {

//        args = ["-b", "20050101", "-e", "20130115"];

        def cli = new CliBuilder(usage: 'OtherRefRecover.groovy -[hbe]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
            s longOpt: 'skip',   args: 1, argName: 'skip count', 'SKIP COUNT'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;
        def skip = options.s ?:"";

        def query = ["beginDate" : beginDate, "endDate" : endDate, "skip" : skip];

        new OtherRefRecover().process(query);

        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "OtherRefRecover finished", "$beginDate - $endDate");
        
        logger.info("OtherRefRecover doDate[$beginDate - $endDate] finished !");
    }
}
