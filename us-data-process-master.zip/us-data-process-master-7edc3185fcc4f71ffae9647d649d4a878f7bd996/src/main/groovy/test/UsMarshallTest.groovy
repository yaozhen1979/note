package test


import marshall.UsPatentMarshallDocumentGenerator

import org.bson.types.ObjectId
import org.slf4j.LoggerFactory

import uspto.patent.model.UsPatentMarshallDocument
import utils.JaxbUtil
import utils.JsoupUtil
import utils.MarshallDataUtil
import utils.MongoUtil
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.Bytes
import com.mongodb.DBCursor

class UsMarshallTest {

    def static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
    
    def PRETTY_PRINT_INDENT_FACTOR = 4

    def ln = System.getProperty('line.separator')

    def dateStr = "T00:00:00"

    def dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    //********** arguments ***********

    def dateS = "2015-12-03"

    def dateE = "2015-12-04"

    def rawDbName = "PatentRawUSPTO"

    def marshallDbName = "PatentMarshallUS"

    //********** arguments ***********
    
    static {
        mongoLogger.setLevel(Level.OFF);
    }

    public static void main(String[] args) {

        UsMarshallTest test = new UsMarshallTest()

        test.action()

    }
    
    def action() {
        
        def client = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017).getClient()

        // raw
        def rawCol = client.getDB(rawDbName).getCollection(rawDbName)
        
        println "date range [${dateS} ~ ${dateE}]"
        
        dateS = dateS + dateStr
        
        dateE = dateE + dateStr

        def doDateS = Date.parse(dateFormat, dateS)

        def doDateE = Date.parse(dateFormat, dateE)

        def queryMap = [:]

//        queryMap << ['doDate' : ['$gte' : doDateS, '$lt' : doDateE]]

        // grant
//                queryMap << ['_id' : new ObjectId("565d720fdcd8ee18a4b401a9")]
        
        // application
                queryMap << ['_id' : new ObjectId("5664ec12dcd8ee1b08ca4e39")]

        def total = rawCol.count(queryMap)
        
        println "total: $total"

        DBCursor rawCur = rawCol.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT).limit(1)
        
        while (rawCur.hasNext()) {
            
            try {
                
                def rawDoc = rawCur.next()
                
                println rawDoc._id
                
                UsPatentMarshallDocument doc = UsPatentMarshallDocumentGenerator.generator(rawDoc)
                
                JaxbUtil.xml2JsonStr(doc)
                
                File test = new File("./log/marshTest.txt")
                
                def jsonObj = JsoupUtil.generateUsOpenDataJsonObject(doc)
//                println jsonObj."us-patent-application"."us-bibliographic-data-application"."publication-reference"
//                test << jsonObj."us-patent-grant"."us-bibliographic-data-grant"."invention-title"
//                test << jsonObj."us-patent-application"."us-bibliographic-data-application"."invention-title"
//                test << jsonObj."us-patent-grant"."description"
//                test << jsonObj."us-patent-grant"."claims"
//                test << jsonObj."us-patent-application"."claims"
//                test << jsonObj."us-patent-application"."abstract"
                
                MarshallDataUtil.generateMarshallData()
                
                println "after jsonObj parse"
                
                
                
                
            } catch (e) {
            
                println e
            }
            
            break
            
        }
        
    }
}
