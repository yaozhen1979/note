package test;

public class PatTypeEnum {
    
    /**
     * US:1:Utility, 3:Design, 4:Plant, 5:Reissue, 6:SIR
     * @author mikelin
     *
     */
    public enum US {
        NO_DEFINED(-99, "Non-Defined"),
        UTILITY(1, "Utility"),
        DESIGN(3, "Design"),
        PLANT(4, "Plant"),
        REISSUE(5,"Reissue"),
        SIR(6, "SIR");
        
        private final int typeCode;
        private final String typeName;
        
        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private US(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }
        
        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (US element : US.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }
        
    }
    
    /**
     * CN:1:发明专利,2:实用新型,3:外观专利
     * @author mikelin
     *
     */
    public enum CN {
        NO_DEFINED(-99, "Non-Defined"),
        FM(1, "发明专利"),
        SD(2, "实用新型"),
        WG(3, "外观专利");
        
        private final int typeCode;
        private final String typeName;
        
        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private CN(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }
        
        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (CN element : CN.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }
        
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        System.out.println(PatTypeEnum.US.findPatTypeCode("Design"));
        System.out.println(PatTypeEnum.CN.findPatTypeCode("发明专利"));

    }

}
