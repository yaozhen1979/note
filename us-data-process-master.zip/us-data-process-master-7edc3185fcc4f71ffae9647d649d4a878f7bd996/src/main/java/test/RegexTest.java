package test;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;

public class RegexTest {

    public static void main(String[] args) throws UnsupportedEncodingException {
        // TODO Auto-generated method stub
        String html = "<font size=\"+1\"> Electric control device for a camera </font>";
        
        String pattern = "(?i)(<FONT\\s*size=\"\\S1\">)([\\s\\S]*?)(</font>)";
        
        String s1 = html.replaceAll(pattern, "$0");
        String s2 = html.replaceAll(pattern, "$1");
        String s3 = html.replaceAll(pattern, "$2").trim();
        
        System.out.println("s1: " + s1 + "\r\n s2: " + s2+ "\r\n s3: " + s3);
        
        System.out.println(new Base64().encodeToString("datateamus".getBytes("UTF-8")));
        System.out.println(new Base64().encodeToString("dhtsrto".getBytes("UTF-8")));
    }

}
