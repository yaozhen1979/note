package test;

import com.github.fge.jsonschema.core.report.ProcessingReport;

import patentdata.utils.JsonSchemaValidator;

public class JsonSchemaTest {

    public static void main(String[] args) throws Exception {
         String jsonData1 = "{ \r\n" + "    \"pto\" : \"USPTO\", \r\n" + "    \"stat\" : 2, \r\n"
                + "    \"kindcode\" : \"B2\", \r\n" + "    \"appNumber\" : \"10/427577\", \r\n"
                + "    \"brief\" : {\r\n"
                + "        \"origin\" : \"<p id=\\\"P-00001\\\" num=\\\"00001\\\">A method for forming a polysilicon FinFET (<b>10</b>) or other thin film transistor structure includes forming an insulative layer (<b>12</b>) over a semiconductor substrate (<b>14</b>). An amorphous silicon layer (<b>32</b>) forms over the insulative layer (<b>12</b>). A silicon germanium seed layer (<b>44</b>) forms in association with the amorphous silicon layer (<b>32</b>) for controlling silicon grain growth. The polysilicon layer arises from annealing the amorphous silicon layer (<b>32</b>). During the annealing step, silicon germanium seed layer (<b>44</b>), together with silicon germanium layer (<b>34</b>), catalyzes silicon recrystallization to promote growing larger crystalline grains, as well as fewer grain boundaries within the resulting polysilicon layer. Source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) regions are formed within the polysilicon layer. A double-gated region (<b>24</b>) forms in association with source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) to produce polysilicon FinFET (<b>10</b>).</p>\"\r\n"
                + "    }, \r\n" + "    \"assignees\" : [\r\n" + "        {\r\n" + "            \"name\" : {\r\n"
                + "                \"origin\" : \"Freescale Semiconductor, Inc.\"\r\n" + "            }, \r\n"
                + "            \"address\" : {\r\n" + "                \"origin\" : \"Austin,TX\"\r\n"
                + "            }, \r\n" + "            \"country\" : {\r\n" + "                \"origin\" : \"US\"\r\n"
                + "            }\r\n" + "        }\r\n" + "    ],\r\n" + "    \"mainIPC\" : \"H01L 21/00\", \r\n"
                + "    \"ipcs\" : [\r\n" + "        \"H01L 21/00\", \r\n" + "        \"H01L 21/20\", \r\n"
                + "        \"H01L 21/3205\"\r\n" + "    ], \r\n" + "    \"familyId\" : 33310189, \r\n"
                + "    \"truncate\" : false\r\n" + "}";

        String jsonData2 = "{ \r\n" + "    \"pto\" : \"USPTO\", \r\n" + "    \"stat\" : \"1\", \r\n"
                + "    \"kindcode\" : \"B2\", \r\n" + "    \"appNumber\" : \"10/427577\", \r\n"
                + "    \"brief\" : {\r\n"
                + "        \"origin\" : \"<p id=\\\"P-00001\\\" num=\\\"00001\\\">A method for forming a polysilicon FinFET (<b>10</b>) or other thin film transistor structure includes forming an insulative layer (<b>12</b>) over a semiconductor substrate (<b>14</b>). An amorphous silicon layer (<b>32</b>) forms over the insulative layer (<b>12</b>). A silicon germanium seed layer (<b>44</b>) forms in association with the amorphous silicon layer (<b>32</b>) for controlling silicon grain growth. The polysilicon layer arises from annealing the amorphous silicon layer (<b>32</b>). During the annealing step, silicon germanium seed layer (<b>44</b>), together with silicon germanium layer (<b>34</b>), catalyzes silicon recrystallization to promote growing larger crystalline grains, as well as fewer grain boundaries within the resulting polysilicon layer. Source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) regions are formed within the polysilicon layer. A double-gated region (<b>24</b>) forms in association with source (<b>16</b>), drain (<b>18</b>), and channel (<b>20</b>) to produce polysilicon FinFET (<b>10</b>).</p>\"\r\n"
                + "    }, \r\n" + "    \"assignees\" : [\r\n" + "        {\r\n" + "            \"name\" : {\r\n"
                + "                \"origin\" : \"Freescale Semiconductor, Inc.\"\r\n" + "            }, \r\n"
                + "            \"address\" : {\r\n" + "                \"origin\" : \"Austin,TX\"\r\n"
                + "            }, \r\n" + "            \"country\" : {\r\n" + "                \"origin\" : \"US\"\r\n"
                + "            }\r\n" + "        }\r\n" + "    ],\r\n" + "    \"mainIPC\" : \"H01L 21/00\", \r\n"
                + "    \"ipcs\" : [\r\n" + "        \"H01L 21/00\", \r\n" + "        \"H01L 21/20\", \r\n"
                + "        \"H01L 21/3205\"\r\n" + "    ], \r\n" + "    \"familyId\" : 33310189, \r\n"
                + "    \"truncate\" : false\r\n" + "}";

        ProcessingReport result1 = JsonSchemaValidator.valid("json.schema.path", jsonData1);
        if (result1.isSuccess()) {
            System.out.println("success");
        } else {
            System.out.println("msg : " + JsonSchemaValidator.parseErrorJsonStr(result1));
        }

        ProcessingReport result2 = JsonSchemaValidator.valid(jsonData2);
        if (result2.isSuccess()) {
            System.out.println("success");
        } else {
            System.out.println("msg : " + JsonSchemaValidator.parseErrorJsonStr(result2));
        }

    }

}
