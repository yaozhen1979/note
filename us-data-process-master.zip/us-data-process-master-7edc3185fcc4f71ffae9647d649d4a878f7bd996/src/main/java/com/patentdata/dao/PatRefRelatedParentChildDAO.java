package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefRelatedParentChild;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefRelatedParentChild.
 * 
 * @see com.patentdata.dao.PatRefRelatedParentChild
 * @author Hibernate Tools
 */
public class PatRefRelatedParentChildDAO extends GenericDAOImpl<PatRefRelatedParentChild> {
    // TODO Auto-generated function stub
}
