package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PersonLang;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PersonLang.
 * 
 * @see com.patentdata.dao.PersonLang
 * @author Hibernate Tools
 */
public class PersonLangDAO extends GenericDAOImpl<PersonLang> {
    // TODO Auto-generated function stub
}
