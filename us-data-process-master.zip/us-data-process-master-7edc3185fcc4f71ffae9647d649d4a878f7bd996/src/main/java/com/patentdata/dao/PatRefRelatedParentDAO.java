package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefRelatedParent;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefRelatedParent.
 * 
 * @see com.patentdata.dao.PatRefRelatedParent
 * @author Hibernate Tools
 */
public class PatRefRelatedParentDAO extends GenericDAOImpl<PatRefRelatedParent> {
    // TODO Auto-generated function stub
}
