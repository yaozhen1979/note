package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatEventRecordAmendLog;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatEventRecordAmendLog.
 * 
 * @see com.patentdata.dao.PatEventRecordAmendLog
 * @author Hibernate Tools
 */
public class PatEventRecordAmendLogDAO extends GenericDAOImpl<PatEventRecordAmendLog> {
    // TODO Auto-generated function stub
}
