package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatClsFi;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatClsFi.
 * 
 * @see com.patentdata.dao.PatClsFi
 * @author Hibernate Tools
 */
public class PatClsFiDAO extends GenericDAOImpl<PatClsFi> {
    // TODO Auto-generated function stub
}
