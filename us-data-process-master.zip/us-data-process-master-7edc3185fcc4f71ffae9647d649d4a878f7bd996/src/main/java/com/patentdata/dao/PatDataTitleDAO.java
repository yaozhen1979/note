package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatDataTitle;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatDataTitle.
 * 
 * @see com.patentdata.dao.PatDataTitle
 * @author Hibernate Tools
 */
public class PatDataTitleDAO extends GenericDAOImpl<PatDataTitle> {
    // TODO Auto-generated function stub
}
