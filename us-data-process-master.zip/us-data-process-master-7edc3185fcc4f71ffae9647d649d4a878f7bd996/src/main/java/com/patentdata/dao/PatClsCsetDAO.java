package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatClsCset;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatClsCset.
 * 
 * @see com.patentdata.dao.PatClsCset
 * @author Hibernate Tools
 */
public class PatClsCsetDAO extends GenericDAOImpl<PatClsCset> {
    // TODO Auto-generated function stub
}
