package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatPersonApplicant;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatPersonApplicant.
 * 
 * @see com.patentdata.dao.PatPersonApplicant
 * @author Hibernate Tools
 */
public class PatPersonApplicantDAO extends GenericDAOImpl<PatPersonApplicant> {
    // TODO Auto-generated function stub
}
