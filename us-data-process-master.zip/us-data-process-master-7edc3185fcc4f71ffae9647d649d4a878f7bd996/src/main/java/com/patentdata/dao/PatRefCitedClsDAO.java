package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefCitedCls;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefCitedCls.
 * 
 * @see com.patentdata.dao.PatRefCitedCls
 * @author Hibernate Tools
 */
public class PatRefCitedClsDAO extends GenericDAOImpl<PatRefCitedCls> {
    // TODO Auto-generated function stub
}
