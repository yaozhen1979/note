package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatPersonCorrespondenceAddrId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatPersonCorrespondenceAddrId.
 * 
 * @see com.patentdata.dao.PatPersonCorrespondenceAddrId
 * @author Hibernate Tools
 */
public class PatPersonCorrespondenceAddrIdDAO extends GenericDAOImpl<PatPersonCorrespondenceAddrId> {
    // TODO Auto-generated function stub
}
