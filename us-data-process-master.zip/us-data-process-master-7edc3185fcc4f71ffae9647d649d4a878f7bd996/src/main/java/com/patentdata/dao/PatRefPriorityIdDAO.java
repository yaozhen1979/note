package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefPriorityId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefPriorityId.
 * 
 * @see com.patentdata.dao.PatRefPriorityId
 * @author Hibernate Tools
 */
public class PatRefPriorityIdDAO extends GenericDAOImpl<PatRefPriorityId> {
    // TODO Auto-generated function stub
}
