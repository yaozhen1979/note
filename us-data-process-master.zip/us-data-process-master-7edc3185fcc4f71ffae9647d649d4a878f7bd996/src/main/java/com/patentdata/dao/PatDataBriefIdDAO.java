package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatDataBriefId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatDataBriefId.
 * 
 * @see com.patentdata.dao.PatDataBriefId
 * @author Hibernate Tools
 */
public class PatDataBriefIdDAO extends GenericDAOImpl<PatDataBriefId> {
    // TODO Auto-generated function stub
}
