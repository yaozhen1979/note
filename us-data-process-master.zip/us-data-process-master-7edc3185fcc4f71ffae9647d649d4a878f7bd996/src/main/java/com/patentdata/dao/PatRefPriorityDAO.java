package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefPriority;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefPriority.
 * 
 * @see com.patentdata.dao.PatRefPriority
 * @author Hibernate Tools
 */
public class PatRefPriorityDAO extends GenericDAOImpl<PatRefPriority> {
    // TODO Auto-generated function stub
}
