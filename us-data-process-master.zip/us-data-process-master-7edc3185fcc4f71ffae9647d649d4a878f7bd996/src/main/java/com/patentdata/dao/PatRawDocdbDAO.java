package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRawDocdb;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRawDocdb.
 * 
 * @see com.patentdata.dao.PatRawDocdb
 * @author Hibernate Tools
 */
public class PatRawDocdbDAO extends GenericDAOImpl<PatRawDocdb> {
    // TODO Auto-generated function stub
}
