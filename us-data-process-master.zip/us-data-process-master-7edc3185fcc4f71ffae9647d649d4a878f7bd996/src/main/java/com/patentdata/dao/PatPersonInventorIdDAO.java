package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatPersonInventorId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatPersonInventorId.
 * 
 * @see com.patentdata.dao.PatPersonInventorId
 * @author Hibernate Tools
 */
public class PatPersonInventorIdDAO extends GenericDAOImpl<PatPersonInventorId> {
    // TODO Auto-generated function stub
}
