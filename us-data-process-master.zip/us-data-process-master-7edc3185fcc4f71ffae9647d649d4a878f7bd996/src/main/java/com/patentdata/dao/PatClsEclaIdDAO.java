package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatClsEclaId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatClsEclaId.
 * 
 * @see com.patentdata.dao.PatClsEclaId
 * @author Hibernate Tools
 */
public class PatClsEclaIdDAO extends GenericDAOImpl<PatClsEclaId> {
    // TODO Auto-generated function stub
}
