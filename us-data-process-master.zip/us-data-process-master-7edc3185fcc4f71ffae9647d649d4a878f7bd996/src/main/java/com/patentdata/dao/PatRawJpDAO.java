package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRawJp;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRawJp.
 * 
 * @see com.patentdata.dao.PatRawJp
 * @author Hibernate Tools
 */
public class PatRawJpDAO extends GenericDAOImpl<PatRawJp> {
    // TODO Auto-generated function stub
}
