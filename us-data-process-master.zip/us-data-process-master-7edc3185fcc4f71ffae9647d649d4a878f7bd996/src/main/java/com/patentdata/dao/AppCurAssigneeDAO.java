package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.AppCurAssignee;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class AppCurAssignee.
 * 
 * @see com.patentdata.dao.AppCurAssignee
 * @author Hibernate Tools
 */
public class AppCurAssigneeDAO extends GenericDAOImpl<AppCurAssignee> {
    // TODO Auto-generated function stub
}
