package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRefRelatedParentId;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRefRelatedParentId.
 * 
 * @see com.patentdata.dao.PatRefRelatedParentId
 * @author Hibernate Tools
 */
public class PatRefRelatedParentIdDAO extends GenericDAOImpl<PatRefRelatedParentId> {
    // TODO Auto-generated function stub
}
