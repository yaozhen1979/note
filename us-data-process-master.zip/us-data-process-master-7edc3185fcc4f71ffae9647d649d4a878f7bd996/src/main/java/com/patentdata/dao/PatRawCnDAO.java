package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRawCn;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRawCn.
 * 
 * @see com.patentdata.dao.PatRawCn
 * @author Hibernate Tools
 */
public class PatRawCnDAO extends GenericDAOImpl<PatRawCn> {
    // TODO Auto-generated function stub
}
