package com.patentdata.dao;

import com.patentdata.common.dao.GenericDAOImpl;
import com.patentdata.model.PatRawTw;

/**
 * Generated 2016/1/22 下午 02:37:34 by Hibernate Tools 4.3.1.Final
 * object for domain model class PatRawTw.
 * 
 * @see com.patentdata.dao.PatRawTw
 * @author Hibernate Tools
 */
public class PatRawTwDAO extends GenericDAOImpl<PatRawTw> {
    // TODO Auto-generated function stub
}
