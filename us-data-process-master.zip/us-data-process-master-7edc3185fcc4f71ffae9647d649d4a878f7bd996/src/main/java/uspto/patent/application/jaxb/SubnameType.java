//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>subname-type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * <p>
 * <pre>
 * &lt;simpleType name="subname-type"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="editor"/&gt;
 *     &lt;enumeration value="translator"/&gt;
 *     &lt;enumeration value="other-subname-type"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "subname-type")
@XmlEnum
public enum SubnameType {

    @XmlEnumValue("editor")
    EDITOR("editor"),
    @XmlEnumValue("translator")
    TRANSLATOR("translator"),
    @XmlEnumValue("other-subname-type")
    OTHER_SUBNAME_TYPE("other-subname-type");
    private final String value;

    SubnameType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SubnameType fromValue(String v) {
        for (SubnameType c: SubnameType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
