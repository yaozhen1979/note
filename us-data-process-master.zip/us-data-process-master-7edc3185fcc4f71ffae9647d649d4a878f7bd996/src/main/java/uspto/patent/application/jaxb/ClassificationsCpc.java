//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}main-cpc"/&gt;
 *         &lt;element ref="{}further-cpc" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mainCpc",
    "furtherCpc"
})
@XmlRootElement(name = "classifications-cpc")
public class ClassificationsCpc {

    @XmlElement(name = "main-cpc", required = true)
    protected MainCpc mainCpc;
    @XmlElement(name = "further-cpc")
    protected FurtherCpc furtherCpc;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;

    /**
     * 取得 mainCpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainCpc }
     *     
     */
    public MainCpc getMainCpc() {
        return mainCpc;
    }

    /**
     * 設定 mainCpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainCpc }
     *     
     */
    public void setMainCpc(MainCpc value) {
        this.mainCpc = value;
    }

    /**
     * 取得 furtherCpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FurtherCpc }
     *     
     */
    public FurtherCpc getFurtherCpc() {
        return furtherCpc;
    }

    /**
     * 設定 furtherCpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FurtherCpc }
     *     
     */
    public void setFurtherCpc(FurtherCpc value) {
        this.furtherCpc = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

}
