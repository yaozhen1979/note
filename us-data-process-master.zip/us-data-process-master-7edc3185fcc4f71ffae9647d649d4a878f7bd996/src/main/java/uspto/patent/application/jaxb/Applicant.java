//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}addressbook" maxOccurs="unbounded"/&gt;
 *         &lt;element ref="{}nationality"/&gt;
 *         &lt;element ref="{}residence" minOccurs="0"/&gt;
 *         &lt;element ref="{}us-rights" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}designated-states" minOccurs="0"/&gt;
 *         &lt;element ref="{}designated-states-as-inventor" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" use="required" type="{}sequence-type" /&gt;
 *       &lt;attribute name="app-type" type="{}applicant-type" /&gt;
 *       &lt;attribute name="designation" type="{}designation-type" /&gt;
 *       &lt;attribute name="applicant-authority-category"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="assignee"/&gt;
 *             &lt;enumeration value="inventor"/&gt;
 *             &lt;enumeration value="party-of-interest"/&gt;
 *             &lt;enumeration value="obligated-assignee"/&gt;
 *             &lt;enumeration value="legal-representative"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "addressbook",
    "nationality",
    "residence",
    "usRights",
    "designatedStates",
    "designatedStatesAsInventor"
})
@XmlRootElement(name = "applicant")
public class Applicant {

    @XmlElement(required = true)
    protected List<Addressbook> addressbook;
    @XmlElement(required = true)
    protected Nationality nationality;
    protected Residence residence;
    @XmlElement(name = "us-rights")
    protected List<UsRights> usRights;
    @XmlElement(name = "designated-states")
    protected DesignatedStates designatedStates;
    @XmlElement(name = "designated-states-as-inventor")
    protected DesignatedStatesAsInventor designatedStatesAsInventor;
    @XmlAttribute(name = "sequence", required = true)
    protected String sequence;
    @XmlAttribute(name = "app-type")
    protected ApplicantType appType;
    @XmlAttribute(name = "designation")
    protected DesignationType designation;
    @XmlAttribute(name = "applicant-authority-category")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String applicantAuthorityCategory;

    /**
     * Gets the value of the addressbook property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addressbook property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddressbook().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Addressbook }
     * 
     * 
     */
    public List<Addressbook> getAddressbook() {
        if (addressbook == null) {
            addressbook = new ArrayList<Addressbook>();
        }
        return this.addressbook;
    }

    /**
     * 取得 nationality 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Nationality }
     *     
     */
    public Nationality getNationality() {
        return nationality;
    }

    /**
     * 設定 nationality 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Nationality }
     *     
     */
    public void setNationality(Nationality value) {
        this.nationality = value;
    }

    /**
     * 取得 residence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Residence }
     *     
     */
    public Residence getResidence() {
        return residence;
    }

    /**
     * 設定 residence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Residence }
     *     
     */
    public void setResidence(Residence value) {
        this.residence = value;
    }

    /**
     * Gets the value of the usRights property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the usRights property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUsRights().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UsRights }
     * 
     * 
     */
    public List<UsRights> getUsRights() {
        if (usRights == null) {
            usRights = new ArrayList<UsRights>();
        }
        return this.usRights;
    }

    /**
     * 取得 designatedStates 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignatedStates }
     *     
     */
    public DesignatedStates getDesignatedStates() {
        return designatedStates;
    }

    /**
     * 設定 designatedStates 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignatedStates }
     *     
     */
    public void setDesignatedStates(DesignatedStates value) {
        this.designatedStates = value;
    }

    /**
     * 取得 designatedStatesAsInventor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignatedStatesAsInventor }
     *     
     */
    public DesignatedStatesAsInventor getDesignatedStatesAsInventor() {
        return designatedStatesAsInventor;
    }

    /**
     * 設定 designatedStatesAsInventor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignatedStatesAsInventor }
     *     
     */
    public void setDesignatedStatesAsInventor(DesignatedStatesAsInventor value) {
        this.designatedStatesAsInventor = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

    /**
     * 取得 appType 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ApplicantType }
     *     
     */
    public ApplicantType getAppType() {
        return appType;
    }

    /**
     * 設定 appType 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicantType }
     *     
     */
    public void setAppType(ApplicantType value) {
        this.appType = value;
    }

    /**
     * 取得 designation 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignationType }
     *     
     */
    public DesignationType getDesignation() {
        return designation;
    }

    /**
     * 設定 designation 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignationType }
     *     
     */
    public void setDesignation(DesignationType value) {
        this.designation = value;
    }

    /**
     * 取得 applicantAuthorityCategory 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantAuthorityCategory() {
        return applicantAuthorityCategory;
    }

    /**
     * 設定 applicantAuthorityCategory 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantAuthorityCategory(String value) {
        this.applicantAuthorityCategory = value;
    }

}
