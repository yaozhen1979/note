//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}document-id"/&gt;
 *         &lt;element ref="{}parent-status" minOccurs="0"/&gt;
 *         &lt;element ref="{}parent-grant-document" minOccurs="0"/&gt;
 *         &lt;element ref="{}parent-pct-document" minOccurs="0"/&gt;
 *         &lt;element ref="{}international-filing-date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "documentId",
    "parentStatus",
    "parentGrantDocument",
    "parentPctDocument",
    "internationalFilingDate"
})
@XmlRootElement(name = "parent-doc")
public class ParentDoc {

    @XmlElement(name = "document-id", required = true)
    protected DocumentId documentId;
    @XmlElement(name = "parent-status")
    protected String parentStatus;
    @XmlElement(name = "parent-grant-document")
    protected ParentGrantDocument parentGrantDocument;
    @XmlElement(name = "parent-pct-document")
    protected ParentPctDocument parentPctDocument;
    @XmlElement(name = "international-filing-date")
    protected InternationalFilingDate internationalFilingDate;

    /**
     * 取得 documentId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DocumentId }
     *     
     */
    public DocumentId getDocumentId() {
        return documentId;
    }

    /**
     * 設定 documentId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentId }
     *     
     */
    public void setDocumentId(DocumentId value) {
        this.documentId = value;
    }

    /**
     * 取得 parentStatus 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentStatus() {
        return parentStatus;
    }

    /**
     * 設定 parentStatus 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentStatus(String value) {
        this.parentStatus = value;
    }

    /**
     * 取得 parentGrantDocument 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ParentGrantDocument }
     *     
     */
    public ParentGrantDocument getParentGrantDocument() {
        return parentGrantDocument;
    }

    /**
     * 設定 parentGrantDocument 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ParentGrantDocument }
     *     
     */
    public void setParentGrantDocument(ParentGrantDocument value) {
        this.parentGrantDocument = value;
    }

    /**
     * 取得 parentPctDocument 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ParentPctDocument }
     *     
     */
    public ParentPctDocument getParentPctDocument() {
        return parentPctDocument;
    }

    /**
     * 設定 parentPctDocument 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ParentPctDocument }
     *     
     */
    public void setParentPctDocument(ParentPctDocument value) {
        this.parentPctDocument = value;
    }

    /**
     * 取得 internationalFilingDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InternationalFilingDate }
     *     
     */
    public InternationalFilingDate getInternationalFilingDate() {
        return internationalFilingDate;
    }

    /**
     * 設定 internationalFilingDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InternationalFilingDate }
     *     
     */
    public void setInternationalFilingDate(InternationalFilingDate value) {
        this.internationalFilingDate = value;
    }

}
