//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}received"/&gt;
 *           &lt;element ref="{}accepted"/&gt;
 *           &lt;element ref="{}revised"/&gt;
 *           &lt;element ref="{}misc"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "text",
    "received",
    "accepted",
    "revised",
    "misc"
})
@XmlRootElement(name = "history")
public class History {

    protected String text;
    protected Received received;
    protected Accepted accepted;
    protected Revised revised;
    protected Misc misc;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
     * 取得 received 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Received }
     *     
     */
    public Received getReceived() {
        return received;
    }

    /**
     * 設定 received 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Received }
     *     
     */
    public void setReceived(Received value) {
        this.received = value;
    }

    /**
     * 取得 accepted 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Accepted }
     *     
     */
    public Accepted getAccepted() {
        return accepted;
    }

    /**
     * 設定 accepted 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Accepted }
     *     
     */
    public void setAccepted(Accepted value) {
        this.accepted = value;
    }

    /**
     * 取得 revised 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Revised }
     *     
     */
    public Revised getRevised() {
        return revised;
    }

    /**
     * 設定 revised 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Revised }
     *     
     */
    public void setRevised(Revised value) {
        this.revised = value;
    }

    /**
     * 取得 misc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Misc }
     *     
     */
    public Misc getMisc() {
        return misc;
    }

    /**
     * 設定 misc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Misc }
     *     
     */
    public void setMisc(Misc value) {
        this.misc = value;
    }

}
