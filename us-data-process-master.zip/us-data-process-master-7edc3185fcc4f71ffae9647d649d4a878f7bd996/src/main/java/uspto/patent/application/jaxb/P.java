//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element ref="{}b"/&gt;
 *         &lt;element ref="{}i"/&gt;
 *         &lt;element ref="{}u"/&gt;
 *         &lt;element ref="{}o"/&gt;
 *         &lt;element ref="{}sup"/&gt;
 *         &lt;element ref="{}sub"/&gt;
 *         &lt;element ref="{}smallcaps"/&gt;
 *         &lt;element ref="{}br"/&gt;
 *         &lt;element ref="{}pre"/&gt;
 *         &lt;element ref="{}dl"/&gt;
 *         &lt;element ref="{}ul"/&gt;
 *         &lt;element ref="{}ol"/&gt;
 *         &lt;element ref="{}patcit"/&gt;
 *         &lt;element ref="{}nplcit"/&gt;
 *         &lt;element ref="{}bio-deposit"/&gt;
 *         &lt;element ref="{}crossref"/&gt;
 *         &lt;element ref="{}figref"/&gt;
 *         &lt;element ref="{}img"/&gt;
 *         &lt;element ref="{}chemistry"/&gt;
 *         &lt;element ref="{}maths"/&gt;
 *         &lt;element ref="{}tables"/&gt;
 *         &lt;element ref="{}table-external-doc"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="num" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "content"
})
@XmlRootElement(name = "p")
public class P {

    @XmlElementRefs({
        @XmlElementRef(name = "figref", type = Figref.class, required = false),
        @XmlElementRef(name = "crossref", type = Crossref.class, required = false),
        @XmlElementRef(name = "table-external-doc", type = TableExternalDoc.class, required = false),
        @XmlElementRef(name = "b", type = B.class, required = false),
        @XmlElementRef(name = "br", type = Br.class, required = false),
        @XmlElementRef(name = "ol", type = Ol.class, required = false),
        @XmlElementRef(name = "o", type = O.class, required = false),
        @XmlElementRef(name = "dl", type = Dl.class, required = false),
        @XmlElementRef(name = "img", type = Img.class, required = false),
        @XmlElementRef(name = "maths", type = Maths.class, required = false),
        @XmlElementRef(name = "i", type = I.class, required = false),
        @XmlElementRef(name = "chemistry", type = Chemistry.class, required = false),
        @XmlElementRef(name = "sup", type = Sup.class, required = false),
        @XmlElementRef(name = "sub", type = Sub.class, required = false),
        @XmlElementRef(name = "bio-deposit", type = BioDeposit.class, required = false),
        @XmlElementRef(name = "nplcit", type = Nplcit.class, required = false),
        @XmlElementRef(name = "ul", type = Ul.class, required = false),
        @XmlElementRef(name = "patcit", type = Patcit.class, required = false),
        @XmlElementRef(name = "tables", type = Tables.class, required = false),
        @XmlElementRef(name = "u", type = U.class, required = false),
        @XmlElementRef(name = "pre", type = Pre.class, required = false),
        @XmlElementRef(name = "smallcaps", type = Smallcaps.class, required = false)
    })
    @XmlMixed
    protected List<Object> content;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "num")
    protected String num;

    /**
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Figref }
     * {@link Crossref }
     * {@link TableExternalDoc }
     * {@link B }
     * {@link Br }
     * {@link Ol }
     * {@link O }
     * {@link Dl }
     * {@link Img }
     * {@link Maths }
     * {@link I }
     * {@link Chemistry }
     * {@link Sup }
     * {@link String }
     * {@link Sub }
     * {@link BioDeposit }
     * {@link Nplcit }
     * {@link Ul }
     * {@link Patcit }
     * {@link Tables }
     * {@link U }
     * {@link Pre }
     * {@link Smallcaps }
     * 
     * 
     */
    public List<Object> getContent() {
        if (content == null) {
            content = new ArrayList<Object>();
        }
        return this.content;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 num 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNum() {
        return num;
    }

    /**
     * 設定 num 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNum(String value) {
        this.num = value;
    }

}
