//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the uspto.patent.application.jaxb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _FirstName_QNAME = new QName("", "first-name");
    private final static QName _MiddleName_QNAME = new QName("", "middle-name");
    private final static QName _Prefix_QNAME = new QName("", "prefix");
    private final static QName _LastName_QNAME = new QName("", "last-name");
    private final static QName _Orgname_QNAME = new QName("", "orgname");
    private final static QName _Suffix_QNAME = new QName("", "suffix");
    private final static QName _Iid_QNAME = new QName("", "iid");
    private final static QName _Role_QNAME = new QName("", "role");
    private final static QName _Department_QNAME = new QName("", "department");
    private final static QName _Synonym_QNAME = new QName("", "synonym");
    private final static QName _RegisteredNumber_QNAME = new QName("", "registered-number");
    private final static QName _AdditionalInfo_QNAME = new QName("", "additional-info");
    private final static QName _MainLinkedIndexingCode_QNAME = new QName("", "main-linked-indexing-code");
    private final static QName _SubLinkedIndexingCode_QNAME = new QName("", "sub-linked-indexing-code");
    private final static QName _UnlinkedIndexingCode_QNAME = new QName("", "unlinked-indexing-code");
    private final static QName _Section_QNAME = new QName("", "section");
    private final static QName _Class_QNAME = new QName("", "class");
    private final static QName _Subclass_QNAME = new QName("", "subclass");
    private final static QName _MainGroup_QNAME = new QName("", "main-group");
    private final static QName _Subgroup_QNAME = new QName("", "subgroup");
    private final static QName _Country_QNAME = new QName("", "country");
    private final static QName _DocNumber_QNAME = new QName("", "doc-number");
    private final static QName _Kind_QNAME = new QName("", "kind");
    private final static QName _Date_QNAME = new QName("", "date");
    private final static QName _UsApplicationSeriesCode_QNAME = new QName("", "us-application-series-code");
    private final static QName _UsOriginalPublicationVoluntary_QNAME = new QName("", "us-original-publication-voluntary");
    private final static QName _UsOriginalPublicationRedacted_QNAME = new QName("", "us-original-publication-redacted");
    private final static QName _UsOriginalPublicationAmended_QNAME = new QName("", "us-original-publication-amended");
    private final static QName _UsRepublicationCorrected_QNAME = new QName("", "us-republication-corrected");
    private final static QName _UsRepublicationRedacted_QNAME = new QName("", "us-republication-redacted");
    private final static QName _UsRepublicationAmended_QNAME = new QName("", "us-republication-amended");
    private final static QName _UsPublicationFilingType_QNAME = new QName("", "us-publication-filing-type");
    private final static QName _UsPublicationOfContinuedProsecutionApplication_QNAME = new QName("", "us-publication-of-continued-prosecution-application");
    private final static QName _ClassificationLevel_QNAME = new QName("", "classification-level");
    private final static QName _SymbolPosition_QNAME = new QName("", "symbol-position");
    private final static QName _ClassificationValue_QNAME = new QName("", "classification-value");
    private final static QName _ClassificationStatus_QNAME = new QName("", "classification-status");
    private final static QName _ClassificationDataSource_QNAME = new QName("", "classification-data-source");
    private final static QName _SchemeOriginationCode_QNAME = new QName("", "scheme-origination-code");
    private final static QName _GroupNumber_QNAME = new QName("", "group-number");
    private final static QName _RankNumber_QNAME = new QName("", "rank-number");
    private final static QName _Edition_QNAME = new QName("", "edition");
    private final static QName _Text_QNAME = new QName("", "text");
    private final static QName _LatinName_QNAME = new QName("", "latin-name");
    private final static QName _Variety_QNAME = new QName("", "variety");
    private final static QName _Passage_QNAME = new QName("", "passage");
    private final static QName _Category_QNAME = new QName("", "category");
    private final static QName _RelClaims_QNAME = new QName("", "rel-claims");
    private final static QName _NumberOfDrawingSheets_QNAME = new QName("", "number-of-drawing-sheets");
    private final static QName _NumberOfFigures_QNAME = new QName("", "number-of-figures");
    private final static QName _City_QNAME = new QName("", "city");
    private final static QName _Address1_QNAME = new QName("", "address-1");
    private final static QName _Address2_QNAME = new QName("", "address-2");
    private final static QName _Address3_QNAME = new QName("", "address-3");
    private final static QName _Mailcode_QNAME = new QName("", "mailcode");
    private final static QName _Pobox_QNAME = new QName("", "pobox");
    private final static QName _Room_QNAME = new QName("", "room");
    private final static QName _AddressFloor_QNAME = new QName("", "address-floor");
    private final static QName _Building_QNAME = new QName("", "building");
    private final static QName _Street_QNAME = new QName("", "street");
    private final static QName _County_QNAME = new QName("", "county");
    private final static QName _State_QNAME = new QName("", "state");
    private final static QName _Postcode_QNAME = new QName("", "postcode");
    private final static QName _Phone_QNAME = new QName("", "phone");
    private final static QName _Fax_QNAME = new QName("", "fax");
    private final static QName _Email_QNAME = new QName("", "email");
    private final static QName _Url_QNAME = new QName("", "url");
    private final static QName _Ead_QNAME = new QName("", "ead");
    private final static QName _Atl_QNAME = new QName("", "atl");
    private final static QName _Sertitle_QNAME = new QName("", "sertitle");
    private final static QName _Alttitle_QNAME = new QName("", "alttitle");
    private final static QName _Issue_QNAME = new QName("", "issue");
    private final static QName _Sdate_QNAME = new QName("", "sdate");
    private final static QName _Edate_QNAME = new QName("", "edate");
    private final static QName _Time_QNAME = new QName("", "time");
    private final static QName _Descrip_QNAME = new QName("", "descrip");
    private final static QName _Notes_QNAME = new QName("", "notes");
    private final static QName _Issn_QNAME = new QName("", "issn");
    private final static QName _Isbn_QNAME = new QName("", "isbn");
    private final static QName _Pubid_QNAME = new QName("", "pubid");
    private final static QName _Vid_QNAME = new QName("", "vid");
    private final static QName _Ino_QNAME = new QName("", "ino");
    private final static QName _Cpyrt_QNAME = new QName("", "cpyrt");
    private final static QName _BookTitle_QNAME = new QName("", "book-title");
    private final static QName _Conftitle_QNAME = new QName("", "conftitle");
    private final static QName _Confno_QNAME = new QName("", "confno");
    private final static QName _Subtitle_QNAME = new QName("", "subtitle");
    private final static QName _Mst_QNAME = new QName("", "mst");
    private final static QName _Msn_QNAME = new QName("", "msn");
    private final static QName _Absno_QNAME = new QName("", "absno");
    private final static QName _Serpart_QNAME = new QName("", "serpart");
    private final static QName _Sersect_QNAME = new QName("", "sersect");
    private final static QName _Chapter_QNAME = new QName("", "chapter");
    private final static QName _Ppf_QNAME = new QName("", "ppf");
    private final static QName _Ppl_QNAME = new QName("", "ppl");
    private final static QName _Colf_QNAME = new QName("", "colf");
    private final static QName _Coll_QNAME = new QName("", "coll");
    private final static QName _Paraf_QNAME = new QName("", "paraf");
    private final static QName _Paral_QNAME = new QName("", "paral");
    private final static QName _Linef_QNAME = new QName("", "linef");
    private final static QName _Linel_QNAME = new QName("", "linel");
    private final static QName _Bookno_QNAME = new QName("", "bookno");
    private final static QName _Keyword_QNAME = new QName("", "keyword");
    private final static QName _Artid_QNAME = new QName("", "artid");
    private final static QName _OnlineTitle_QNAME = new QName("", "online-title");
    private final static QName _Hosttitle_QNAME = new QName("", "hosttitle");
    private final static QName _Hostno_QNAME = new QName("", "hostno");
    private final static QName _Avail_QNAME = new QName("", "avail");
    private final static QName _Srchterm_QNAME = new QName("", "srchterm");
    private final static QName _ParentStatus_QNAME = new QName("", "parent-status");
    private final static QName _UsProvisionalApplicationStatus_QNAME = new QName("", "us-provisional-application-status");
    private final static QName _TypeOfCorrection_QNAME = new QName("", "type-of-correction");
    private final static QName _GazetteNum_QNAME = new QName("", "gazette-num");
    private final static QName _CustomerNumber_QNAME = new QName("", "customer-number");
    private final static QName _BioAccno_QNAME = new QName("", "bio-accno");
    private final static QName _Term_QNAME = new QName("", "term");
    private final static QName _ObjectContents_QNAME = new QName("", "object-contents");
    private final static QName _ObjectDescription_QNAME = new QName("", "object-description");
    private final static QName _ObjectId_QNAME = new QName("", "object-id");
    private final static QName _ObjectReference_QNAME = new QName("", "object-reference");
    private final static QName _UsAppendixData_QNAME = new QName("", "us-appendix-data");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: uspto.patent.application.jaxb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LastName }
     * 
     */
    public LastName createLastName() {
        return new LastName();
    }

    /**
     * Create an instance of {@link Prefix }
     * 
     */
    public Prefix createPrefix() {
        return new Prefix();
    }

    /**
     * Create an instance of {@link Orgname }
     * 
     */
    public Orgname createOrgname() {
        return new Orgname();
    }

    /**
     * Create an instance of {@link Othercit }
     * 
     */
    public Othercit createOthercit() {
        return new Othercit();
    }

    /**
     * Create an instance of {@link B }
     * 
     */
    public B createB() {
        return new B();
    }

    /**
     * Create an instance of {@link I }
     * 
     */
    public I createI() {
        return new I();
    }

    /**
     * Create an instance of {@link U }
     * 
     */
    public U createU() {
        return new U();
    }

    /**
     * Create an instance of {@link O }
     * 
     */
    public O createO() {
        return new O();
    }

    /**
     * Create an instance of {@link Sup }
     * 
     */
    public Sup createSup() {
        return new Sup();
    }

    /**
     * Create an instance of {@link Sup2 }
     * 
     */
    public Sup2 createSup2() {
        return new Sup2();
    }

    /**
     * Create an instance of {@link Sub2 }
     * 
     */
    public Sub2 createSub2() {
        return new Sub2();
    }

    /**
     * Create an instance of {@link Sub }
     * 
     */
    public Sub createSub() {
        return new Sub();
    }

    /**
     * Create an instance of {@link Smallcaps }
     * 
     */
    public Smallcaps createSmallcaps() {
        return new Smallcaps();
    }

    /**
     * Create an instance of {@link LinkedIndexingCodeGroup }
     * 
     */
    public LinkedIndexingCodeGroup createLinkedIndexingCodeGroup() {
        return new LinkedIndexingCodeGroup();
    }

    /**
     * Create an instance of {@link MainGroup }
     * 
     */
    public MainGroup createMainGroup() {
        return new MainGroup();
    }

    /**
     * Create an instance of {@link DocPage }
     * 
     */
    public DocPage createDocPage() {
        return new DocPage();
    }

    /**
     * Create an instance of {@link Country }
     * 
     */
    public Country createCountry() {
        return new Country();
    }

    /**
     * Create an instance of {@link DocNumber }
     * 
     */
    public DocNumber createDocNumber() {
        return new DocNumber();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link Date }
     * 
     */
    public Date createDate() {
        return new Date();
    }

    /**
     * Create an instance of {@link DocumentId }
     * 
     */
    public DocumentId createDocumentId() {
        return new DocumentId();
    }

    /**
     * Create an instance of {@link PublicationReference }
     * 
     */
    public PublicationReference createPublicationReference() {
        return new PublicationReference();
    }

    /**
     * Create an instance of {@link ApplicationReference }
     * 
     */
    public ApplicationReference createApplicationReference() {
        return new ApplicationReference();
    }

    /**
     * Create an instance of {@link UsOriginalPublicationVoluntary }
     * 
     */
    public UsOriginalPublicationVoluntary createUsOriginalPublicationVoluntary() {
        return new UsOriginalPublicationVoluntary();
    }

    /**
     * Create an instance of {@link UsOriginalPublicationRedacted }
     * 
     */
    public UsOriginalPublicationRedacted createUsOriginalPublicationRedacted() {
        return new UsOriginalPublicationRedacted();
    }

    /**
     * Create an instance of {@link UsOriginalPublicationAmended }
     * 
     */
    public UsOriginalPublicationAmended createUsOriginalPublicationAmended() {
        return new UsOriginalPublicationAmended();
    }

    /**
     * Create an instance of {@link UsRepublicationCorrected }
     * 
     */
    public UsRepublicationCorrected createUsRepublicationCorrected() {
        return new UsRepublicationCorrected();
    }

    /**
     * Create an instance of {@link UsRepublicationRedacted }
     * 
     */
    public UsRepublicationRedacted createUsRepublicationRedacted() {
        return new UsRepublicationRedacted();
    }

    /**
     * Create an instance of {@link UsRepublicationAmended }
     * 
     */
    public UsRepublicationAmended createUsRepublicationAmended() {
        return new UsRepublicationAmended();
    }

    /**
     * Create an instance of {@link UsPublicationFilingType }
     * 
     */
    public UsPublicationFilingType createUsPublicationFilingType() {
        return new UsPublicationFilingType();
    }

    /**
     * Create an instance of {@link UsPublicationOfContinuedProsecutionApplication }
     * 
     */
    public UsPublicationOfContinuedProsecutionApplication createUsPublicationOfContinuedProsecutionApplication() {
        return new UsPublicationOfContinuedProsecutionApplication();
    }

    /**
     * Create an instance of {@link Rule47Flag }
     * 
     */
    public Rule47Flag createRule47Flag() {
        return new Rule47Flag();
    }

    /**
     * Create an instance of {@link Region }
     * 
     */
    public Region createRegion() {
        return new Region();
    }

    /**
     * Create an instance of {@link OfficeOfFiling }
     * 
     */
    public OfficeOfFiling createOfficeOfFiling() {
        return new OfficeOfFiling();
    }

    /**
     * Create an instance of {@link PriorityDocRequested }
     * 
     */
    public PriorityDocRequested createPriorityDocRequested() {
        return new PriorityDocRequested();
    }

    /**
     * Create an instance of {@link PriorityDocAttached }
     * 
     */
    public PriorityDocAttached createPriorityDocAttached() {
        return new PriorityDocAttached();
    }

    /**
     * Create an instance of {@link PriorityClaim }
     * 
     */
    public PriorityClaim createPriorityClaim() {
        return new PriorityClaim();
    }

    /**
     * Create an instance of {@link PriorityClaims }
     * 
     */
    public PriorityClaims createPriorityClaims() {
        return new PriorityClaims();
    }

    /**
     * Create an instance of {@link IpcVersionIndicator }
     * 
     */
    public IpcVersionIndicator createIpcVersionIndicator() {
        return new IpcVersionIndicator();
    }

    /**
     * Create an instance of {@link ActionDate }
     * 
     */
    public ActionDate createActionDate() {
        return new ActionDate();
    }

    /**
     * Create an instance of {@link GeneratingOffice }
     * 
     */
    public GeneratingOffice createGeneratingOffice() {
        return new GeneratingOffice();
    }

    /**
     * Create an instance of {@link ClassificationIpcr }
     * 
     */
    public ClassificationIpcr createClassificationIpcr() {
        return new ClassificationIpcr();
    }

    /**
     * Create an instance of {@link ClassificationsIpcr }
     * 
     */
    public ClassificationsIpcr createClassificationsIpcr() {
        return new ClassificationsIpcr();
    }

    /**
     * Create an instance of {@link CpcVersionIndicator }
     * 
     */
    public CpcVersionIndicator createCpcVersionIndicator() {
        return new CpcVersionIndicator();
    }

    /**
     * Create an instance of {@link ClassificationCpc }
     * 
     */
    public ClassificationCpc createClassificationCpc() {
        return new ClassificationCpc();
    }

    /**
     * Create an instance of {@link MainCpc }
     * 
     */
    public MainCpc createMainCpc() {
        return new MainCpc();
    }

    /**
     * Create an instance of {@link CombinationRank }
     * 
     */
    public CombinationRank createCombinationRank() {
        return new CombinationRank();
    }

    /**
     * Create an instance of {@link CombinationSet }
     * 
     */
    public CombinationSet createCombinationSet() {
        return new CombinationSet();
    }

    /**
     * Create an instance of {@link FurtherCpc }
     * 
     */
    public FurtherCpc createFurtherCpc() {
        return new FurtherCpc();
    }

    /**
     * Create an instance of {@link ClassificationsCpc }
     * 
     */
    public ClassificationsCpc createClassificationsCpc() {
        return new ClassificationsCpc();
    }

    /**
     * Create an instance of {@link MainClassification }
     * 
     */
    public MainClassification createMainClassification() {
        return new MainClassification();
    }

    /**
     * Create an instance of {@link FurtherClassification }
     * 
     */
    public FurtherClassification createFurtherClassification() {
        return new FurtherClassification();
    }

    /**
     * Create an instance of {@link ClassificationLocarno }
     * 
     */
    public ClassificationLocarno createClassificationLocarno() {
        return new ClassificationLocarno();
    }

    /**
     * Create an instance of {@link ClassificationNational }
     * 
     */
    public ClassificationNational createClassificationNational() {
        return new ClassificationNational();
    }

    /**
     * Create an instance of {@link Br }
     * 
     */
    public Br createBr() {
        return new Br();
    }

    /**
     * Create an instance of {@link InventionTitle }
     * 
     */
    public InventionTitle createInventionTitle() {
        return new InventionTitle();
    }

    /**
     * Create an instance of {@link LatinName }
     * 
     */
    public LatinName createLatinName() {
        return new LatinName();
    }

    /**
     * Create an instance of {@link Variety }
     * 
     */
    public Variety createVariety() {
        return new Variety();
    }

    /**
     * Create an instance of {@link UsBotanic }
     * 
     */
    public UsBotanic createUsBotanic() {
        return new UsBotanic();
    }

    /**
     * Create an instance of {@link RelPassage }
     * 
     */
    public RelPassage createRelPassage() {
        return new RelPassage();
    }

    /**
     * Create an instance of {@link Patcit }
     * 
     */
    public Patcit createPatcit() {
        return new Patcit();
    }

    /**
     * Create an instance of {@link City }
     * 
     */
    public City createCity() {
        return new City();
    }

    /**
     * Create an instance of {@link State }
     * 
     */
    public State createState() {
        return new State();
    }

    /**
     * Create an instance of {@link Postcode }
     * 
     */
    public Postcode createPostcode() {
        return new Postcode();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link Phone }
     * 
     */
    public Phone createPhone() {
        return new Phone();
    }

    /**
     * Create an instance of {@link Fax }
     * 
     */
    public Fax createFax() {
        return new Fax();
    }

    /**
     * Create an instance of {@link Email }
     * 
     */
    public Email createEmail() {
        return new Email();
    }

    /**
     * Create an instance of {@link Dtext }
     * 
     */
    public Dtext createDtext() {
        return new Dtext();
    }

    /**
     * Create an instance of {@link Addressbook }
     * 
     */
    public Addressbook createAddressbook() {
        return new Addressbook();
    }

    /**
     * Create an instance of {@link Author }
     * 
     */
    public Author createAuthor() {
        return new Author();
    }

    /**
     * Create an instance of {@link Subname }
     * 
     */
    public Subname createSubname() {
        return new Subname();
    }

    /**
     * Create an instance of {@link Pubdate }
     * 
     */
    public Pubdate createPubdate() {
        return new Pubdate();
    }

    /**
     * Create an instance of {@link Imprint }
     * 
     */
    public Imprint createImprint() {
        return new Imprint();
    }

    /**
     * Create an instance of {@link Serial }
     * 
     */
    public Serial createSerial() {
        return new Serial();
    }

    /**
     * Create an instance of {@link Confplace }
     * 
     */
    public Confplace createConfplace() {
        return new Confplace();
    }

    /**
     * Create an instance of {@link Confsponsor }
     * 
     */
    public Confsponsor createConfsponsor() {
        return new Confsponsor();
    }

    /**
     * Create an instance of {@link Conference }
     * 
     */
    public Conference createConference() {
        return new Conference();
    }

    /**
     * Create an instance of {@link Series }
     * 
     */
    public Series createSeries() {
        return new Series();
    }

    /**
     * Create an instance of {@link Pp }
     * 
     */
    public Pp createPp() {
        return new Pp();
    }

    /**
     * Create an instance of {@link Column }
     * 
     */
    public Column createColumn() {
        return new Column();
    }

    /**
     * Create an instance of {@link Para }
     * 
     */
    public Para createPara() {
        return new Para();
    }

    /**
     * Create an instance of {@link Line }
     * 
     */
    public Line createLine() {
        return new Line();
    }

    /**
     * Create an instance of {@link Location }
     * 
     */
    public Location createLocation() {
        return new Location();
    }

    /**
     * Create an instance of {@link Refno }
     * 
     */
    public Refno createRefno() {
        return new Refno();
    }

    /**
     * Create an instance of {@link Book }
     * 
     */
    public Book createBook() {
        return new Book();
    }

    /**
     * Create an instance of {@link Article }
     * 
     */
    public Article createArticle() {
        return new Article();
    }

    /**
     * Create an instance of {@link Received }
     * 
     */
    public Received createReceived() {
        return new Received();
    }

    /**
     * Create an instance of {@link Accepted }
     * 
     */
    public Accepted createAccepted() {
        return new Accepted();
    }

    /**
     * Create an instance of {@link Revised }
     * 
     */
    public Revised createRevised() {
        return new Revised();
    }

    /**
     * Create an instance of {@link Misc }
     * 
     */
    public Misc createMisc() {
        return new Misc();
    }

    /**
     * Create an instance of {@link History }
     * 
     */
    public History createHistory() {
        return new History();
    }

    /**
     * Create an instance of {@link Datecit }
     * 
     */
    public Datecit createDatecit() {
        return new Datecit();
    }

    /**
     * Create an instance of {@link Srchdate }
     * 
     */
    public Srchdate createSrchdate() {
        return new Srchdate();
    }

    /**
     * Create an instance of {@link Online }
     * 
     */
    public Online createOnline() {
        return new Online();
    }

    /**
     * Create an instance of {@link Nplcit }
     * 
     */
    public Nplcit createNplcit() {
        return new Nplcit();
    }

    /**
     * Create an instance of {@link CorrespondingDocs }
     * 
     */
    public CorrespondingDocs createCorrespondingDocs() {
        return new CorrespondingDocs();
    }

    /**
     * Create an instance of {@link ClassificationIpc }
     * 
     */
    public ClassificationIpc createClassificationIpc() {
        return new ClassificationIpc();
    }

    /**
     * Create an instance of {@link ClassificationCpcText }
     * 
     */
    public ClassificationCpcText createClassificationCpcText() {
        return new ClassificationCpcText();
    }

    /**
     * Create an instance of {@link UsCitation }
     * 
     */
    public UsCitation createUsCitation() {
        return new UsCitation();
    }

    /**
     * Create an instance of {@link Citation }
     * 
     */
    public Citation createCitation() {
        return new Citation();
    }

    /**
     * Create an instance of {@link DateSearchCompleted }
     * 
     */
    public DateSearchCompleted createDateSearchCompleted() {
        return new DateSearchCompleted();
    }

    /**
     * Create an instance of {@link DateSearchReportMailed }
     * 
     */
    public DateSearchReportMailed createDateSearchReportMailed() {
        return new DateSearchReportMailed();
    }

    /**
     * Create an instance of {@link PlaceOfSearch }
     * 
     */
    public PlaceOfSearch createPlaceOfSearch() {
        return new PlaceOfSearch();
    }

    /**
     * Create an instance of {@link SearchReportPublication }
     * 
     */
    public SearchReportPublication createSearchReportPublication() {
        return new SearchReportPublication();
    }

    /**
     * Create an instance of {@link Searcher }
     * 
     */
    public Searcher createSearcher() {
        return new Searcher();
    }

    /**
     * Create an instance of {@link UsReferencesCited }
     * 
     */
    public UsReferencesCited createUsReferencesCited() {
        return new UsReferencesCited();
    }

    /**
     * Create an instance of {@link ReferencesCited }
     * 
     */
    public ReferencesCited createReferencesCited() {
        return new ReferencesCited();
    }

    /**
     * Create an instance of {@link ParentGrantDocument }
     * 
     */
    public ParentGrantDocument createParentGrantDocument() {
        return new ParentGrantDocument();
    }

    /**
     * Create an instance of {@link ParentPctDocument }
     * 
     */
    public ParentPctDocument createParentPctDocument() {
        return new ParentPctDocument();
    }

    /**
     * Create an instance of {@link InternationalFilingDate }
     * 
     */
    public InternationalFilingDate createInternationalFilingDate() {
        return new InternationalFilingDate();
    }

    /**
     * Create an instance of {@link ParentDoc }
     * 
     */
    public ParentDoc createParentDoc() {
        return new ParentDoc();
    }

    /**
     * Create an instance of {@link ChildDoc }
     * 
     */
    public ChildDoc createChildDoc() {
        return new ChildDoc();
    }

    /**
     * Create an instance of {@link Relation }
     * 
     */
    public Relation createRelation() {
        return new Relation();
    }

    /**
     * Create an instance of {@link Addition }
     * 
     */
    public Addition createAddition() {
        return new Addition();
    }

    /**
     * Create an instance of {@link Division }
     * 
     */
    public Division createDivision() {
        return new Division();
    }

    /**
     * Create an instance of {@link Continuation }
     * 
     */
    public Continuation createContinuation() {
        return new Continuation();
    }

    /**
     * Create an instance of {@link ContinuationInPart }
     * 
     */
    public ContinuationInPart createContinuationInPart() {
        return new ContinuationInPart();
    }

    /**
     * Create an instance of {@link ContinuingReissue }
     * 
     */
    public ContinuingReissue createContinuingReissue() {
        return new ContinuingReissue();
    }

    /**
     * Create an instance of {@link Reissue }
     * 
     */
    public Reissue createReissue() {
        return new Reissue();
    }

    /**
     * Create an instance of {@link UsRelation }
     * 
     */
    public UsRelation createUsRelation() {
        return new UsRelation();
    }

    /**
     * Create an instance of {@link UsDivisionalReissue }
     * 
     */
    public UsDivisionalReissue createUsDivisionalReissue() {
        return new UsDivisionalReissue();
    }

    /**
     * Create an instance of {@link Reexamination }
     * 
     */
    public Reexamination createReexamination() {
        return new Reexamination();
    }

    /**
     * Create an instance of {@link UsReexaminationReissueMerger }
     * 
     */
    public UsReexaminationReissueMerger createUsReexaminationReissueMerger() {
        return new UsReexaminationReissueMerger();
    }

    /**
     * Create an instance of {@link Substitution }
     * 
     */
    public Substitution createSubstitution() {
        return new Substitution();
    }

    /**
     * Create an instance of {@link UsProvisionalApplication }
     * 
     */
    public UsProvisionalApplication createUsProvisionalApplication() {
        return new UsProvisionalApplication();
    }

    /**
     * Create an instance of {@link UtilityModelBasis }
     * 
     */
    public UtilityModelBasis createUtilityModelBasis() {
        return new UtilityModelBasis();
    }

    /**
     * Create an instance of {@link DocumentCorrected }
     * 
     */
    public DocumentCorrected createDocumentCorrected() {
        return new DocumentCorrected();
    }

    /**
     * Create an instance of {@link GazetteReference }
     * 
     */
    public GazetteReference createGazetteReference() {
        return new GazetteReference();
    }

    /**
     * Create an instance of {@link Correction }
     * 
     */
    public Correction createCorrection() {
        return new Correction();
    }

    /**
     * Create an instance of {@link RelatedPublication }
     * 
     */
    public RelatedPublication createRelatedPublication() {
        return new RelatedPublication();
    }

    /**
     * Create an instance of {@link UsRelatedDocuments }
     * 
     */
    public UsRelatedDocuments createUsRelatedDocuments() {
        return new UsRelatedDocuments();
    }

    /**
     * Create an instance of {@link Nationality }
     * 
     */
    public Nationality createNationality() {
        return new Nationality();
    }

    /**
     * Create an instance of {@link Residence }
     * 
     */
    public Residence createResidence() {
        return new Residence();
    }

    /**
     * Create an instance of {@link UsRights }
     * 
     */
    public UsRights createUsRights() {
        return new UsRights();
    }

    /**
     * Create an instance of {@link DesignatedStates }
     * 
     */
    public DesignatedStates createDesignatedStates() {
        return new DesignatedStates();
    }

    /**
     * Create an instance of {@link DesignatedStatesAsInventor }
     * 
     */
    public DesignatedStatesAsInventor createDesignatedStatesAsInventor() {
        return new DesignatedStatesAsInventor();
    }

    /**
     * Create an instance of {@link UsApplicant }
     * 
     */
    public UsApplicant createUsApplicant() {
        return new UsApplicant();
    }

    /**
     * Create an instance of {@link Applicant }
     * 
     */
    public Applicant createApplicant() {
        return new Applicant();
    }

    /**
     * Create an instance of {@link UsApplicants }
     * 
     */
    public UsApplicants createUsApplicants() {
        return new UsApplicants();
    }

    /**
     * Create an instance of {@link Applicants }
     * 
     */
    public Applicants createApplicants() {
        return new Applicants();
    }

    /**
     * Create an instance of {@link Inventor }
     * 
     */
    public Inventor createInventor() {
        return new Inventor();
    }

    /**
     * Create an instance of {@link DeceasedInventor }
     * 
     */
    public DeceasedInventor createDeceasedInventor() {
        return new DeceasedInventor();
    }

    /**
     * Create an instance of {@link Inventors }
     * 
     */
    public Inventors createInventors() {
        return new Inventors();
    }

    /**
     * Create an instance of {@link CorrespondenceAddress }
     * 
     */
    public CorrespondenceAddress createCorrespondenceAddress() {
        return new CorrespondenceAddress();
    }

    /**
     * Create an instance of {@link Agent }
     * 
     */
    public Agent createAgent() {
        return new Agent();
    }

    /**
     * Create an instance of {@link Agents }
     * 
     */
    public Agents createAgents() {
        return new Agents();
    }

    /**
     * Create an instance of {@link UsParties }
     * 
     */
    public UsParties createUsParties() {
        return new UsParties();
    }

    /**
     * Create an instance of {@link Parties }
     * 
     */
    public Parties createParties() {
        return new Parties();
    }

    /**
     * Create an instance of {@link Assignee }
     * 
     */
    public Assignee createAssignee() {
        return new Assignee();
    }

    /**
     * Create an instance of {@link UsDeceasedInventor }
     * 
     */
    public UsDeceasedInventor createUsDeceasedInventor() {
        return new UsDeceasedInventor();
    }

    /**
     * Create an instance of {@link Assignees }
     * 
     */
    public Assignees createAssignees() {
        return new Assignees();
    }

    /**
     * Create an instance of {@link Depositary }
     * 
     */
    public Depositary createDepositary() {
        return new Depositary();
    }

    /**
     * Create an instance of {@link BioDeposit }
     * 
     */
    public BioDeposit createBioDeposit() {
        return new BioDeposit();
    }

    /**
     * Create an instance of {@link Us371C124Date }
     * 
     */
    public Us371C124Date createUs371C124Date() {
        return new Us371C124Date();
    }

    /**
     * Create an instance of {@link Us371C12Date }
     * 
     */
    public Us371C12Date createUs371C12Date() {
        return new Us371C12Date();
    }

    /**
     * Create an instance of {@link PctOrRegionalFilingData }
     * 
     */
    public PctOrRegionalFilingData createPctOrRegionalFilingData() {
        return new PctOrRegionalFilingData();
    }

    /**
     * Create an instance of {@link PctOrRegionalPublishingData }
     * 
     */
    public PctOrRegionalPublishingData createPctOrRegionalPublishingData() {
        return new PctOrRegionalPublishingData();
    }

    /**
     * Create an instance of {@link ObjectContents }
     * 
     */
    public ObjectContents createObjectContents() {
        return new ObjectContents();
    }

    /**
     * Create an instance of {@link ObjectDescription }
     * 
     */
    public ObjectDescription createObjectDescription() {
        return new ObjectDescription();
    }

    /**
     * Create an instance of {@link ObjectId }
     * 
     */
    public ObjectId createObjectId() {
        return new ObjectId();
    }

    /**
     * Create an instance of {@link ObjectReference }
     * 
     */
    public ObjectReference createObjectReference() {
        return new ObjectReference();
    }

    /**
     * Create an instance of {@link UsAppendixData }
     * 
     */
    public UsAppendixData createUsAppendixData() {
        return new UsAppendixData();
    }

    /**
     * Create an instance of {@link UsBibliographicDataApplication }
     * 
     */
    public UsBibliographicDataApplication createUsBibliographicDataApplication() {
        return new UsBibliographicDataApplication();
    }

    /**
     * Create an instance of {@link Pre }
     * 
     */
    public Pre createPre() {
        return new Pre();
    }

    /**
     * Create an instance of {@link Dt }
     * 
     */
    public Dt createDt() {
        return new Dt();
    }

    /**
     * Create an instance of {@link Crossref }
     * 
     */
    public Crossref createCrossref() {
        return new Crossref();
    }

    /**
     * Create an instance of {@link Figref }
     * 
     */
    public Figref createFigref() {
        return new Figref();
    }

    /**
     * Create an instance of {@link Img }
     * 
     */
    public Img createImg() {
        return new Img();
    }

    /**
     * Create an instance of {@link Chem }
     * 
     */
    public Chem createChem() {
        return new Chem();
    }

    /**
     * Create an instance of {@link Chemistry }
     * 
     */
    public Chemistry createChemistry() {
        return new Chemistry();
    }

    /**
     * Create an instance of {@link Math }
     * 
     */
    public Math createMath() {
        return new Math();
    }

    /**
     * Create an instance of {@link Maths }
     * 
     */
    public Maths createMaths() {
        return new Maths();
    }

    /**
     * Create an instance of {@link Title }
     * 
     */
    public Title createTitle() {
        return new Title();
    }

    /**
     * Create an instance of {@link Colspec }
     * 
     */
    public Colspec createColspec() {
        return new Colspec();
    }

    /**
     * Create an instance of {@link Entry }
     * 
     */
    public Entry createEntry() {
        return new Entry();
    }

    /**
     * Create an instance of {@link Row }
     * 
     */
    public Row createRow() {
        return new Row();
    }

    /**
     * Create an instance of {@link Thead }
     * 
     */
    public Thead createThead() {
        return new Thead();
    }

    /**
     * Create an instance of {@link Tbody }
     * 
     */
    public Tbody createTbody() {
        return new Tbody();
    }

    /**
     * Create an instance of {@link Tgroup }
     * 
     */
    public Tgroup createTgroup() {
        return new Tgroup();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link Tables }
     * 
     */
    public Tables createTables() {
        return new Tables();
    }

    /**
     * Create an instance of {@link Li }
     * 
     */
    public Li createLi() {
        return new Li();
    }

    /**
     * Create an instance of {@link Dl }
     * 
     */
    public Dl createDl() {
        return new Dl();
    }

    /**
     * Create an instance of {@link Dd }
     * 
     */
    public Dd createDd() {
        return new Dd();
    }

    /**
     * Create an instance of {@link Ul }
     * 
     */
    public Ul createUl() {
        return new Ul();
    }

    /**
     * Create an instance of {@link Ol }
     * 
     */
    public Ol createOl() {
        return new Ol();
    }

    /**
     * Create an instance of {@link TableExternalDoc }
     * 
     */
    public TableExternalDoc createTableExternalDoc() {
        return new TableExternalDoc();
    }

    /**
     * Create an instance of {@link P }
     * 
     */
    public P createP() {
        return new P();
    }

    /**
     * Create an instance of {@link AbstProblem }
     * 
     */
    public AbstProblem createAbstProblem() {
        return new AbstProblem();
    }

    /**
     * Create an instance of {@link AbstSolution }
     * 
     */
    public AbstSolution createAbstSolution() {
        return new AbstSolution();
    }

    /**
     * Create an instance of {@link Heading }
     * 
     */
    public Heading createHeading() {
        return new Heading();
    }

    /**
     * Create an instance of {@link Abstract }
     * 
     */
    public Abstract createAbstract() {
        return new Abstract();
    }

    /**
     * Create an instance of {@link Figure }
     * 
     */
    public Figure createFigure() {
        return new Figure();
    }

    /**
     * Create an instance of {@link Drawings }
     * 
     */
    public Drawings createDrawings() {
        return new Drawings();
    }

    /**
     * Create an instance of {@link TechnicalField }
     * 
     */
    public TechnicalField createTechnicalField() {
        return new TechnicalField();
    }

    /**
     * Create an instance of {@link BackgroundArt }
     * 
     */
    public BackgroundArt createBackgroundArt() {
        return new BackgroundArt();
    }

    /**
     * Create an instance of {@link TechProblem }
     * 
     */
    public TechProblem createTechProblem() {
        return new TechProblem();
    }

    /**
     * Create an instance of {@link TechSolution }
     * 
     */
    public TechSolution createTechSolution() {
        return new TechSolution();
    }

    /**
     * Create an instance of {@link AdvantageousEffects }
     * 
     */
    public AdvantageousEffects createAdvantageousEffects() {
        return new AdvantageousEffects();
    }

    /**
     * Create an instance of {@link Disclosure }
     * 
     */
    public Disclosure createDisclosure() {
        return new Disclosure();
    }

    /**
     * Create an instance of {@link DescriptionOfDrawings }
     * 
     */
    public DescriptionOfDrawings createDescriptionOfDrawings() {
        return new DescriptionOfDrawings();
    }

    /**
     * Create an instance of {@link BestMode }
     * 
     */
    public BestMode createBestMode() {
        return new BestMode();
    }

    /**
     * Create an instance of {@link ModeForInvention }
     * 
     */
    public ModeForInvention createModeForInvention() {
        return new ModeForInvention();
    }

    /**
     * Create an instance of {@link IndustrialApplicability }
     * 
     */
    public IndustrialApplicability createIndustrialApplicability() {
        return new IndustrialApplicability();
    }

    /**
     * Create an instance of {@link SequenceListText }
     * 
     */
    public SequenceListText createSequenceListText() {
        return new SequenceListText();
    }

    /**
     * Create an instance of {@link Description }
     * 
     */
    public Description createDescription() {
        return new Description();
    }

    /**
     * Create an instance of {@link SequenceList }
     * 
     */
    public SequenceList createSequenceList() {
        return new SequenceList();
    }

    /**
     * Create an instance of {@link SequenceListDoc }
     * 
     */
    public SequenceListDoc createSequenceListDoc() {
        return new SequenceListDoc();
    }

    /**
     * Create an instance of {@link UsSequenceListDoc }
     * 
     */
    public UsSequenceListDoc createUsSequenceListDoc() {
        return new UsSequenceListDoc();
    }

    /**
     * Create an instance of {@link UsMegatableDoc }
     * 
     */
    public UsMegatableDoc createUsMegatableDoc() {
        return new UsMegatableDoc();
    }

    /**
     * Create an instance of {@link UsChemistry }
     * 
     */
    public UsChemistry createUsChemistry() {
        return new UsChemistry();
    }

    /**
     * Create an instance of {@link UsMath }
     * 
     */
    public UsMath createUsMath() {
        return new UsMath();
    }

    /**
     * Create an instance of {@link UsClaimStatement }
     * 
     */
    public UsClaimStatement createUsClaimStatement() {
        return new UsClaimStatement();
    }

    /**
     * Create an instance of {@link ClaimRef }
     * 
     */
    public ClaimRef createClaimRef() {
        return new ClaimRef();
    }

    /**
     * Create an instance of {@link ClaimText }
     * 
     */
    public ClaimText createClaimText() {
        return new ClaimText();
    }

    /**
     * Create an instance of {@link Claim }
     * 
     */
    public Claim createClaim() {
        return new Claim();
    }

    /**
     * Create an instance of {@link Claims }
     * 
     */
    public Claims createClaims() {
        return new Claims();
    }

    /**
     * Create an instance of {@link UsPatentApplication }
     * 
     */
    public UsPatentApplication createUsPatentApplication() {
        return new UsPatentApplication();
    }

    /**
     * Create an instance of {@link FirstName }
     * 
     */
    public FirstName createFirstName() {
        return new FirstName();
    }

    /**
     * Create an instance of {@link MiddleName }
     * 
     */
    public MiddleName createMiddleName() {
        return new MiddleName();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name")
    public JAXBElement<LastName> createFirstName(LastName value) {
        return new JAXBElement<LastName>(_FirstName_QNAME, LastName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name")
    public JAXBElement<LastName> createMiddleName(LastName value) {
        return new JAXBElement<LastName>(_MiddleName_QNAME, LastName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Prefix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix")
    public JAXBElement<Prefix> createPrefix(Prefix value) {
        return new JAXBElement<Prefix>(_Prefix_QNAME, Prefix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name")
    public JAXBElement<LastName> createLastName(LastName value) {
        return new JAXBElement<LastName>(_LastName_QNAME, LastName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Orgname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname")
    public JAXBElement<Orgname> createOrgname(Orgname value) {
        return new JAXBElement<Orgname>(_Orgname_QNAME, Orgname.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix")
    public JAXBElement<String> createSuffix(String value) {
        return new JAXBElement<String>(_Suffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid")
    public JAXBElement<String> createIid(String value) {
        return new JAXBElement<String>(_Iid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role")
    public JAXBElement<String> createRole(String value) {
        return new JAXBElement<String>(_Role_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department")
    public JAXBElement<String> createDepartment(String value) {
        return new JAXBElement<String>(_Department_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym")
    public JAXBElement<String> createSynonym(String value) {
        return new JAXBElement<String>(_Synonym_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number")
    public JAXBElement<String> createRegisteredNumber(String value) {
        return new JAXBElement<String>(_RegisteredNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "additional-info")
    public JAXBElement<String> createAdditionalInfo(String value) {
        return new JAXBElement<String>(_AdditionalInfo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "main-linked-indexing-code")
    public JAXBElement<String> createMainLinkedIndexingCode(String value) {
        return new JAXBElement<String>(_MainLinkedIndexingCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub-linked-indexing-code")
    public JAXBElement<String> createSubLinkedIndexingCode(String value) {
        return new JAXBElement<String>(_SubLinkedIndexingCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unlinked-indexing-code")
    public JAXBElement<String> createUnlinkedIndexingCode(String value) {
        return new JAXBElement<String>(_UnlinkedIndexingCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "section")
    public JAXBElement<String> createSection(String value) {
        return new JAXBElement<String>(_Section_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "class")
    public JAXBElement<String> createClass(String value) {
        return new JAXBElement<String>(_Class_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subclass")
    public JAXBElement<String> createSubclass(String value) {
        return new JAXBElement<String>(_Subclass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "main-group")
    public JAXBElement<MainGroup> createMainGroup(MainGroup value) {
        return new JAXBElement<MainGroup>(_MainGroup_QNAME, MainGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subgroup")
    public JAXBElement<String> createSubgroup(String value) {
        return new JAXBElement<String>(_Subgroup_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Country }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country")
    public JAXBElement<Country> createCountry(Country value) {
        return new JAXBElement<Country>(_Country_QNAME, Country.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-number")
    public JAXBElement<DocNumber> createDocNumber(DocNumber value) {
        return new JAXBElement<DocNumber>(_DocNumber_QNAME, DocNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "kind")
    public JAXBElement<String> createKind(String value) {
        return new JAXBElement<String>(_Kind_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Date }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date")
    public JAXBElement<Date> createDate(Date value) {
        return new JAXBElement<Date>(_Date_QNAME, Date.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-application-series-code")
    public JAXBElement<String> createUsApplicationSeriesCode(String value) {
        return new JAXBElement<String>(_UsApplicationSeriesCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsOriginalPublicationVoluntary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-original-publication-voluntary")
    public JAXBElement<UsOriginalPublicationVoluntary> createUsOriginalPublicationVoluntary(UsOriginalPublicationVoluntary value) {
        return new JAXBElement<UsOriginalPublicationVoluntary>(_UsOriginalPublicationVoluntary_QNAME, UsOriginalPublicationVoluntary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsOriginalPublicationRedacted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-original-publication-redacted")
    public JAXBElement<UsOriginalPublicationRedacted> createUsOriginalPublicationRedacted(UsOriginalPublicationRedacted value) {
        return new JAXBElement<UsOriginalPublicationRedacted>(_UsOriginalPublicationRedacted_QNAME, UsOriginalPublicationRedacted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsOriginalPublicationAmended }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-original-publication-amended")
    public JAXBElement<UsOriginalPublicationAmended> createUsOriginalPublicationAmended(UsOriginalPublicationAmended value) {
        return new JAXBElement<UsOriginalPublicationAmended>(_UsOriginalPublicationAmended_QNAME, UsOriginalPublicationAmended.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsRepublicationCorrected }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-republication-corrected")
    public JAXBElement<UsRepublicationCorrected> createUsRepublicationCorrected(UsRepublicationCorrected value) {
        return new JAXBElement<UsRepublicationCorrected>(_UsRepublicationCorrected_QNAME, UsRepublicationCorrected.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsRepublicationRedacted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-republication-redacted")
    public JAXBElement<UsRepublicationRedacted> createUsRepublicationRedacted(UsRepublicationRedacted value) {
        return new JAXBElement<UsRepublicationRedacted>(_UsRepublicationRedacted_QNAME, UsRepublicationRedacted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsRepublicationAmended }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-republication-amended")
    public JAXBElement<UsRepublicationAmended> createUsRepublicationAmended(UsRepublicationAmended value) {
        return new JAXBElement<UsRepublicationAmended>(_UsRepublicationAmended_QNAME, UsRepublicationAmended.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsPublicationFilingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-publication-filing-type")
    public JAXBElement<UsPublicationFilingType> createUsPublicationFilingType(UsPublicationFilingType value) {
        return new JAXBElement<UsPublicationFilingType>(_UsPublicationFilingType_QNAME, UsPublicationFilingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsPublicationOfContinuedProsecutionApplication }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-publication-of-continued-prosecution-application")
    public JAXBElement<UsPublicationOfContinuedProsecutionApplication> createUsPublicationOfContinuedProsecutionApplication(UsPublicationOfContinuedProsecutionApplication value) {
        return new JAXBElement<UsPublicationOfContinuedProsecutionApplication>(_UsPublicationOfContinuedProsecutionApplication_QNAME, UsPublicationOfContinuedProsecutionApplication.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-level")
    public JAXBElement<String> createClassificationLevel(String value) {
        return new JAXBElement<String>(_ClassificationLevel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "symbol-position")
    public JAXBElement<String> createSymbolPosition(String value) {
        return new JAXBElement<String>(_SymbolPosition_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-value")
    public JAXBElement<String> createClassificationValue(String value) {
        return new JAXBElement<String>(_ClassificationValue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-status")
    public JAXBElement<String> createClassificationStatus(String value) {
        return new JAXBElement<String>(_ClassificationStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classification-data-source")
    public JAXBElement<String> createClassificationDataSource(String value) {
        return new JAXBElement<String>(_ClassificationDataSource_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "scheme-origination-code")
    public JAXBElement<String> createSchemeOriginationCode(String value) {
        return new JAXBElement<String>(_SchemeOriginationCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "group-number")
    public JAXBElement<String> createGroupNumber(String value) {
        return new JAXBElement<String>(_GroupNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rank-number")
    public JAXBElement<String> createRankNumber(String value) {
        return new JAXBElement<String>(_RankNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edition")
    public JAXBElement<String> createEdition(String value) {
        return new JAXBElement<String>(_Edition_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "text")
    public JAXBElement<String> createText(String value) {
        return new JAXBElement<String>(_Text_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LatinName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "latin-name")
    public JAXBElement<LatinName> createLatinName(LatinName value) {
        return new JAXBElement<LatinName>(_LatinName_QNAME, LatinName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Variety }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "variety")
    public JAXBElement<Variety> createVariety(Variety value) {
        return new JAXBElement<Variety>(_Variety_QNAME, Variety.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "passage")
    public JAXBElement<String> createPassage(String value) {
        return new JAXBElement<String>(_Passage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "category")
    public JAXBElement<String> createCategory(String value) {
        return new JAXBElement<String>(_Category_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rel-claims")
    public JAXBElement<String> createRelClaims(String value) {
        return new JAXBElement<String>(_RelClaims_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "number-of-drawing-sheets")
    public JAXBElement<Integer> createNumberOfDrawingSheets(Integer value) {
        return new JAXBElement<Integer>(_NumberOfDrawingSheets_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "number-of-figures")
    public JAXBElement<Integer> createNumberOfFigures(Integer value) {
        return new JAXBElement<Integer>(_NumberOfFigures_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link City }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "city")
    public JAXBElement<City> createCity(City value) {
        return new JAXBElement<City>(_City_QNAME, City.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-1")
    public JAXBElement<String> createAddress1(String value) {
        return new JAXBElement<String>(_Address1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-2")
    public JAXBElement<String> createAddress2(String value) {
        return new JAXBElement<String>(_Address2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-3")
    public JAXBElement<String> createAddress3(String value) {
        return new JAXBElement<String>(_Address3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mailcode")
    public JAXBElement<String> createMailcode(String value) {
        return new JAXBElement<String>(_Mailcode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pobox")
    public JAXBElement<String> createPobox(String value) {
        return new JAXBElement<String>(_Pobox_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "room")
    public JAXBElement<String> createRoom(String value) {
        return new JAXBElement<String>(_Room_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-floor")
    public JAXBElement<String> createAddressFloor(String value) {
        return new JAXBElement<String>(_AddressFloor_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "building")
    public JAXBElement<String> createBuilding(String value) {
        return new JAXBElement<String>(_Building_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "street")
    public JAXBElement<String> createStreet(String value) {
        return new JAXBElement<String>(_Street_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "county")
    public JAXBElement<String> createCounty(String value) {
        return new JAXBElement<String>(_County_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link State }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state")
    public JAXBElement<State> createState(State value) {
        return new JAXBElement<State>(_State_QNAME, State.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Postcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postcode")
    public JAXBElement<Postcode> createPostcode(Postcode value) {
        return new JAXBElement<Postcode>(_Postcode_QNAME, Postcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Phone }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "phone")
    public JAXBElement<Phone> createPhone(Phone value) {
        return new JAXBElement<Phone>(_Phone_QNAME, Phone.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fax }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fax")
    public JAXBElement<Fax> createFax(Fax value) {
        return new JAXBElement<Fax>(_Fax_QNAME, Fax.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Email }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "email")
    public JAXBElement<Email> createEmail(Email value) {
        return new JAXBElement<Email>(_Email_QNAME, Email.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "url")
    public JAXBElement<String> createUrl(String value) {
        return new JAXBElement<String>(_Url_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ead")
    public JAXBElement<String> createEad(String value) {
        return new JAXBElement<String>(_Ead_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "atl")
    public JAXBElement<String> createAtl(String value) {
        return new JAXBElement<String>(_Atl_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sertitle")
    public JAXBElement<String> createSertitle(String value) {
        return new JAXBElement<String>(_Sertitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "alttitle")
    public JAXBElement<String> createAlttitle(String value) {
        return new JAXBElement<String>(_Alttitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issue")
    public JAXBElement<String> createIssue(String value) {
        return new JAXBElement<String>(_Issue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sdate")
    public JAXBElement<String> createSdate(String value) {
        return new JAXBElement<String>(_Sdate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edate")
    public JAXBElement<String> createEdate(String value) {
        return new JAXBElement<String>(_Edate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "time")
    public JAXBElement<String> createTime(String value) {
        return new JAXBElement<String>(_Time_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "descrip")
    public JAXBElement<String> createDescrip(String value) {
        return new JAXBElement<String>(_Descrip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notes")
    public JAXBElement<String> createNotes(String value) {
        return new JAXBElement<String>(_Notes_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issn")
    public JAXBElement<String> createIssn(String value) {
        return new JAXBElement<String>(_Issn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "isbn")
    public JAXBElement<String> createIsbn(String value) {
        return new JAXBElement<String>(_Isbn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pubid")
    public JAXBElement<String> createPubid(String value) {
        return new JAXBElement<String>(_Pubid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "vid")
    public JAXBElement<String> createVid(String value) {
        return new JAXBElement<String>(_Vid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ino")
    public JAXBElement<String> createIno(String value) {
        return new JAXBElement<String>(_Ino_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cpyrt")
    public JAXBElement<String> createCpyrt(String value) {
        return new JAXBElement<String>(_Cpyrt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "book-title")
    public JAXBElement<String> createBookTitle(String value) {
        return new JAXBElement<String>(_BookTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conftitle")
    public JAXBElement<String> createConftitle(String value) {
        return new JAXBElement<String>(_Conftitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confno")
    public JAXBElement<String> createConfno(String value) {
        return new JAXBElement<String>(_Confno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subtitle")
    public JAXBElement<String> createSubtitle(String value) {
        return new JAXBElement<String>(_Subtitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mst")
    public JAXBElement<String> createMst(String value) {
        return new JAXBElement<String>(_Mst_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msn")
    public JAXBElement<String> createMsn(String value) {
        return new JAXBElement<String>(_Msn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "absno")
    public JAXBElement<String> createAbsno(String value) {
        return new JAXBElement<String>(_Absno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "serpart")
    public JAXBElement<String> createSerpart(String value) {
        return new JAXBElement<String>(_Serpart_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sersect")
    public JAXBElement<String> createSersect(String value) {
        return new JAXBElement<String>(_Sersect_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chapter")
    public JAXBElement<String> createChapter(String value) {
        return new JAXBElement<String>(_Chapter_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppf")
    public JAXBElement<String> createPpf(String value) {
        return new JAXBElement<String>(_Ppf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppl")
    public JAXBElement<String> createPpl(String value) {
        return new JAXBElement<String>(_Ppl_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colf")
    public JAXBElement<String> createColf(String value) {
        return new JAXBElement<String>(_Colf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coll")
    public JAXBElement<String> createColl(String value) {
        return new JAXBElement<String>(_Coll_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paraf")
    public JAXBElement<String> createParaf(String value) {
        return new JAXBElement<String>(_Paraf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paral")
    public JAXBElement<String> createParal(String value) {
        return new JAXBElement<String>(_Paral_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linef")
    public JAXBElement<String> createLinef(String value) {
        return new JAXBElement<String>(_Linef_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linel")
    public JAXBElement<String> createLinel(String value) {
        return new JAXBElement<String>(_Linel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bookno")
    public JAXBElement<String> createBookno(String value) {
        return new JAXBElement<String>(_Bookno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "keyword")
    public JAXBElement<String> createKeyword(String value) {
        return new JAXBElement<String>(_Keyword_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "artid")
    public JAXBElement<String> createArtid(String value) {
        return new JAXBElement<String>(_Artid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "online-title")
    public JAXBElement<String> createOnlineTitle(String value) {
        return new JAXBElement<String>(_OnlineTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hosttitle")
    public JAXBElement<String> createHosttitle(String value) {
        return new JAXBElement<String>(_Hosttitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hostno")
    public JAXBElement<String> createHostno(String value) {
        return new JAXBElement<String>(_Hostno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "avail")
    public JAXBElement<String> createAvail(String value) {
        return new JAXBElement<String>(_Avail_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "srchterm")
    public JAXBElement<String> createSrchterm(String value) {
        return new JAXBElement<String>(_Srchterm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "parent-status")
    public JAXBElement<String> createParentStatus(String value) {
        return new JAXBElement<String>(_ParentStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-provisional-application-status")
    public JAXBElement<String> createUsProvisionalApplicationStatus(String value) {
        return new JAXBElement<String>(_UsProvisionalApplicationStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "type-of-correction")
    public JAXBElement<String> createTypeOfCorrection(String value) {
        return new JAXBElement<String>(_TypeOfCorrection_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "gazette-num")
    public JAXBElement<String> createGazetteNum(String value) {
        return new JAXBElement<String>(_GazetteNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "customer-number")
    public JAXBElement<String> createCustomerNumber(String value) {
        return new JAXBElement<String>(_CustomerNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-accno")
    public JAXBElement<String> createBioAccno(String value) {
        return new JAXBElement<String>(_BioAccno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "term")
    public JAXBElement<String> createTerm(String value) {
        return new JAXBElement<String>(_Term_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectContents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "object-contents")
    public JAXBElement<ObjectContents> createObjectContents(ObjectContents value) {
        return new JAXBElement<ObjectContents>(_ObjectContents_QNAME, ObjectContents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectDescription }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "object-description")
    public JAXBElement<ObjectDescription> createObjectDescription(ObjectDescription value) {
        return new JAXBElement<ObjectDescription>(_ObjectDescription_QNAME, ObjectDescription.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "object-id")
    public JAXBElement<ObjectId> createObjectId(ObjectId value) {
        return new JAXBElement<ObjectId>(_ObjectId_QNAME, ObjectId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "object-reference")
    public JAXBElement<ObjectReference> createObjectReference(ObjectReference value) {
        return new JAXBElement<ObjectReference>(_ObjectReference_QNAME, ObjectReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsAppendixData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-appendix-data")
    public JAXBElement<UsAppendixData> createUsAppendixData(UsAppendixData value) {
        return new JAXBElement<UsAppendixData>(_UsAppendixData_QNAME, UsAppendixData.class, null, value);
    }

}
