//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}sertitle"/&gt;
 *         &lt;element ref="{}alttitle" minOccurs="0"/&gt;
 *         &lt;element ref="{}subname" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}issue" minOccurs="0"/&gt;
 *         &lt;element ref="{}imprint" minOccurs="0"/&gt;
 *         &lt;element ref="{}pubdate" minOccurs="0"/&gt;
 *         &lt;element ref="{}descrip" minOccurs="0"/&gt;
 *         &lt;element ref="{}notes" minOccurs="0"/&gt;
 *         &lt;element ref="{}issn" minOccurs="0"/&gt;
 *         &lt;element ref="{}isbn" minOccurs="0"/&gt;
 *         &lt;element ref="{}pubid" minOccurs="0"/&gt;
 *         &lt;element ref="{}vid" minOccurs="0"/&gt;
 *         &lt;element ref="{}ino" minOccurs="0"/&gt;
 *         &lt;element ref="{}cpyrt" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sertitle",
    "alttitle",
    "subname",
    "issue",
    "imprint",
    "pubdate",
    "descrip",
    "notes",
    "issn",
    "isbn",
    "pubid",
    "vid",
    "ino",
    "cpyrt"
})
@XmlRootElement(name = "serial")
public class Serial {

    @XmlElement(required = true)
    protected String sertitle;
    protected String alttitle;
    protected List<Subname> subname;
    protected String issue;
    protected Imprint imprint;
    protected Pubdate pubdate;
    protected String descrip;
    protected String notes;
    protected String issn;
    protected String isbn;
    protected String pubid;
    protected String vid;
    protected String ino;
    protected String cpyrt;

    /**
     * 取得 sertitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSertitle() {
        return sertitle;
    }

    /**
     * 設定 sertitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSertitle(String value) {
        this.sertitle = value;
    }

    /**
     * 取得 alttitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlttitle() {
        return alttitle;
    }

    /**
     * 設定 alttitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlttitle(String value) {
        this.alttitle = value;
    }

    /**
     * Gets the value of the subname property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subname property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubname().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Subname }
     * 
     * 
     */
    public List<Subname> getSubname() {
        if (subname == null) {
            subname = new ArrayList<Subname>();
        }
        return this.subname;
    }

    /**
     * 取得 issue 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssue() {
        return issue;
    }

    /**
     * 設定 issue 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssue(String value) {
        this.issue = value;
    }

    /**
     * 取得 imprint 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Imprint }
     *     
     */
    public Imprint getImprint() {
        return imprint;
    }

    /**
     * 設定 imprint 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Imprint }
     *     
     */
    public void setImprint(Imprint value) {
        this.imprint = value;
    }

    /**
     * 取得 pubdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pubdate }
     *     
     */
    public Pubdate getPubdate() {
        return pubdate;
    }

    /**
     * 設定 pubdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pubdate }
     *     
     */
    public void setPubdate(Pubdate value) {
        this.pubdate = value;
    }

    /**
     * 取得 descrip 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescrip() {
        return descrip;
    }

    /**
     * 設定 descrip 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescrip(String value) {
        this.descrip = value;
    }

    /**
     * 取得 notes 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotes() {
        return notes;
    }

    /**
     * 設定 notes 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotes(String value) {
        this.notes = value;
    }

    /**
     * 取得 issn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssn() {
        return issn;
    }

    /**
     * 設定 issn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssn(String value) {
        this.issn = value;
    }

    /**
     * 取得 isbn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * 設定 isbn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsbn(String value) {
        this.isbn = value;
    }

    /**
     * 取得 pubid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPubid() {
        return pubid;
    }

    /**
     * 設定 pubid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPubid(String value) {
        this.pubid = value;
    }

    /**
     * 取得 vid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVid() {
        return vid;
    }

    /**
     * 設定 vid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVid(String value) {
        this.vid = value;
    }

    /**
     * 取得 ino 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIno() {
        return ino;
    }

    /**
     * 設定 ino 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIno(String value) {
        this.ino = value;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCpyrt(String value) {
        this.cpyrt = value;
    }

}
