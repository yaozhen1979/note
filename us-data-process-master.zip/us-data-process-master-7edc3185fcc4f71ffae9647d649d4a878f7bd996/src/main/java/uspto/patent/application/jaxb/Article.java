//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}author" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}atl" minOccurs="0"/&gt;
 *           &lt;element ref="{}subname" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;choice&gt;
 *             &lt;element ref="{}serial"/&gt;
 *             &lt;element ref="{}book"/&gt;
 *           &lt;/choice&gt;
 *           &lt;element ref="{}absno" minOccurs="0"/&gt;
 *           &lt;element ref="{}location" minOccurs="0"/&gt;
 *           &lt;element ref="{}class" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}keyword" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element ref="{}cpyrt" minOccurs="0"/&gt;
 *           &lt;element ref="{}artid" minOccurs="0"/&gt;
 *           &lt;element ref="{}refno" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "text",
    "author",
    "atl",
    "subname",
    "serial",
    "book",
    "absno",
    "location",
    "clazz",
    "keyword",
    "cpyrt",
    "artid",
    "refno"
})
@XmlRootElement(name = "article")
public class Article {

    protected String text;
    protected List<Author> author;
    protected String atl;
    protected List<Subname> subname;
    protected Serial serial;
    protected Book book;
    protected String absno;
    protected Location location;
    @XmlElement(name = "class")
    protected List<String> clazz;
    protected List<String> keyword;
    protected String cpyrt;
    protected String artid;
    protected List<Refno> refno;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the author property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Author }
     * 
     * 
     */
    public List<Author> getAuthor() {
        if (author == null) {
            author = new ArrayList<Author>();
        }
        return this.author;
    }

    /**
     * 取得 atl 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtl() {
        return atl;
    }

    /**
     * 設定 atl 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtl(String value) {
        this.atl = value;
    }

    /**
     * Gets the value of the subname property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subname property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubname().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Subname }
     * 
     * 
     */
    public List<Subname> getSubname() {
        if (subname == null) {
            subname = new ArrayList<Subname>();
        }
        return this.subname;
    }

    /**
     * 取得 serial 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Serial }
     *     
     */
    public Serial getSerial() {
        return serial;
    }

    /**
     * 設定 serial 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Serial }
     *     
     */
    public void setSerial(Serial value) {
        this.serial = value;
    }

    /**
     * 取得 book 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Book }
     *     
     */
    public Book getBook() {
        return book;
    }

    /**
     * 設定 book 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Book }
     *     
     */
    public void setBook(Book value) {
        this.book = value;
    }

    /**
     * 取得 absno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAbsno() {
        return absno;
    }

    /**
     * 設定 absno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAbsno(String value) {
        this.absno = value;
    }

    /**
     * 取得 location 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getLocation() {
        return location;
    }

    /**
     * 設定 location 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setLocation(Location value) {
        this.location = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clazz property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClazz().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getClazz() {
        if (clazz == null) {
            clazz = new ArrayList<String>();
        }
        return this.clazz;
    }

    /**
     * Gets the value of the keyword property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyword property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyword().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getKeyword() {
        if (keyword == null) {
            keyword = new ArrayList<String>();
        }
        return this.keyword;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCpyrt(String value) {
        this.cpyrt = value;
    }

    /**
     * 取得 artid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArtid() {
        return artid;
    }

    /**
     * 設定 artid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArtid(String value) {
        this.artid = value;
    }

    /**
     * Gets the value of the refno property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refno property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefno().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Refno }
     * 
     * 
     */
    public List<Refno> getRefno() {
        if (refno == null) {
            refno = new ArrayList<Refno>();
        }
        return this.refno;
    }

}
