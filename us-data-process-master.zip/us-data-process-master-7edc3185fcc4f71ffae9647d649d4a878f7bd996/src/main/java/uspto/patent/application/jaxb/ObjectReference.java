//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>object-reference complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="object-reference"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}object-description"/&gt;
 *         &lt;element ref="{}object-id"/&gt;
 *         &lt;element ref="{}object-contents"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "object-reference", propOrder = {
    "objectDescription",
    "objectId",
    "objectContents"
})
public class ObjectReference {

    @XmlElement(name = "object-description", required = true)
    protected ObjectDescription objectDescription;
    @XmlElement(name = "object-id", required = true)
    protected ObjectId objectId;
    @XmlElement(name = "object-contents", required = true)
    protected ObjectContents objectContents;
    @XmlAttribute(name = "id", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;

    /**
     * 取得 objectDescription 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ObjectDescription }
     *     
     */
    public ObjectDescription getObjectDescription() {
        return objectDescription;
    }

    /**
     * 設定 objectDescription 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectDescription }
     *     
     */
    public void setObjectDescription(ObjectDescription value) {
        this.objectDescription = value;
    }

    /**
     * 取得 objectId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ObjectId }
     *     
     */
    public ObjectId getObjectId() {
        return objectId;
    }

    /**
     * 設定 objectId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectId }
     *     
     */
    public void setObjectId(ObjectId value) {
        this.objectId = value;
    }

    /**
     * 取得 objectContents 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ObjectContents }
     *     
     */
    public ObjectContents getObjectContents() {
        return objectContents;
    }

    /**
     * 設定 objectContents 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectContents }
     *     
     */
    public void setObjectContents(ObjectContents value) {
        this.objectContents = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

}
