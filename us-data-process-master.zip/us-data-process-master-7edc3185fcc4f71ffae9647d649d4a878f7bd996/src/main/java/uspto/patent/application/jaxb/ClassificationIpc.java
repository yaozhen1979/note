//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}edition"/&gt;
 *         &lt;element ref="{}main-classification"/&gt;
 *         &lt;element ref="{}further-classification" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;group ref="{}classification-additional-group" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}text" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "edition",
    "mainClassification",
    "furtherClassification",
    "classificationAdditionalGroup",
    "text"
})
@XmlRootElement(name = "classification-ipc")
public class ClassificationIpc {

    @XmlElement(required = true)
    protected String edition;
    @XmlElement(name = "main-classification", required = true)
    protected MainClassification mainClassification;
    @XmlElement(name = "further-classification")
    protected List<FurtherClassification> furtherClassification;
    @XmlElementRefs({
        @XmlElementRef(name = "linked-indexing-code-group", type = LinkedIndexingCodeGroup.class, required = false),
        @XmlElementRef(name = "unlinked-indexing-code", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "additional-info", type = JAXBElement.class, required = false)
    })
    protected List<Object> classificationAdditionalGroup;
    protected String text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEdition(String value) {
        this.edition = value;
    }

    /**
     * 取得 mainClassification 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainClassification }
     *     
     */
    public MainClassification getMainClassification() {
        return mainClassification;
    }

    /**
     * 設定 mainClassification 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainClassification }
     *     
     */
    public void setMainClassification(MainClassification value) {
        this.mainClassification = value;
    }

    /**
     * Gets the value of the furtherClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the furtherClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFurtherClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FurtherClassification }
     * 
     * 
     */
    public List<FurtherClassification> getFurtherClassification() {
        if (furtherClassification == null) {
            furtherClassification = new ArrayList<FurtherClassification>();
        }
        return this.furtherClassification;
    }

    /**
     * Gets the value of the classificationAdditionalGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the classificationAdditionalGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClassificationAdditionalGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link LinkedIndexingCodeGroup }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getClassificationAdditionalGroup() {
        if (classificationAdditionalGroup == null) {
            classificationAdditionalGroup = new ArrayList<Object>();
        }
        return this.classificationAdditionalGroup;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

}
