//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element ref="{}patcit"/&gt;
 *           &lt;element ref="{}nplcit"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element ref="{}corresponding-docs" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}rel-passage" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}category" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}rel-claims" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-ipc" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-ipcr" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-cpc-text" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-national" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="srep-phase" type="{}text-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "patcit",
    "nplcit",
    "correspondingDocs",
    "relPassage",
    "category",
    "relClaims",
    "classificationIpc",
    "classificationsIpcr",
    "classificationCpcText",
    "classificationNational"
})
@XmlRootElement(name = "citation")
public class Citation {

    protected Patcit patcit;
    protected Nplcit nplcit;
    @XmlElement(name = "corresponding-docs")
    protected List<CorrespondingDocs> correspondingDocs;
    @XmlElement(name = "rel-passage")
    protected List<RelPassage> relPassage;
    protected List<String> category;
    @XmlElement(name = "rel-claims")
    protected List<String> relClaims;
    @XmlElement(name = "classification-ipc")
    protected ClassificationIpc classificationIpc;
    @XmlElement(name = "classifications-ipcr")
    protected ClassificationsIpcr classificationsIpcr;
    @XmlElement(name = "classification-cpc-text")
    protected ClassificationCpcText classificationCpcText;
    @XmlElement(name = "classification-national")
    protected ClassificationNational classificationNational;
    @XmlAttribute(name = "srep-phase")
    protected String srepPhase;

    /**
     * 取得 patcit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Patcit }
     *     
     */
    public Patcit getPatcit() {
        return patcit;
    }

    /**
     * 設定 patcit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Patcit }
     *     
     */
    public void setPatcit(Patcit value) {
        this.patcit = value;
    }

    /**
     * 取得 nplcit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Nplcit }
     *     
     */
    public Nplcit getNplcit() {
        return nplcit;
    }

    /**
     * 設定 nplcit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Nplcit }
     *     
     */
    public void setNplcit(Nplcit value) {
        this.nplcit = value;
    }

    /**
     * Gets the value of the correspondingDocs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the correspondingDocs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCorrespondingDocs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CorrespondingDocs }
     * 
     * 
     */
    public List<CorrespondingDocs> getCorrespondingDocs() {
        if (correspondingDocs == null) {
            correspondingDocs = new ArrayList<CorrespondingDocs>();
        }
        return this.correspondingDocs;
    }

    /**
     * Gets the value of the relPassage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relPassage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelPassage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelPassage }
     * 
     * 
     */
    public List<RelPassage> getRelPassage() {
        if (relPassage == null) {
            relPassage = new ArrayList<RelPassage>();
        }
        return this.relPassage;
    }

    /**
     * Gets the value of the category property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the category property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCategory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCategory() {
        if (category == null) {
            category = new ArrayList<String>();
        }
        return this.category;
    }

    /**
     * Gets the value of the relClaims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relClaims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRelClaims() {
        if (relClaims == null) {
            relClaims = new ArrayList<String>();
        }
        return this.relClaims;
    }

    /**
     * 取得 classificationIpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpc }
     *     
     */
    public ClassificationIpc getClassificationIpc() {
        return classificationIpc;
    }

    /**
     * 設定 classificationIpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpc }
     *     
     */
    public void setClassificationIpc(ClassificationIpc value) {
        this.classificationIpc = value;
    }

    /**
     * 取得 classificationsIpcr 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public ClassificationsIpcr getClassificationsIpcr() {
        return classificationsIpcr;
    }

    /**
     * 設定 classificationsIpcr 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public void setClassificationsIpcr(ClassificationsIpcr value) {
        this.classificationsIpcr = value;
    }

    /**
     * 取得 classificationCpcText 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationCpcText }
     *     
     */
    public ClassificationCpcText getClassificationCpcText() {
        return classificationCpcText;
    }

    /**
     * 設定 classificationCpcText 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationCpcText }
     *     
     */
    public void setClassificationCpcText(ClassificationCpcText value) {
        this.classificationCpcText = value;
    }

    /**
     * 取得 classificationNational 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationNational }
     *     
     */
    public ClassificationNational getClassificationNational() {
        return classificationNational;
    }

    /**
     * 設定 classificationNational 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationNational }
     *     
     */
    public void setClassificationNational(ClassificationNational value) {
        this.classificationNational = value;
    }

    /**
     * 取得 srepPhase 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrepPhase() {
        return srepPhase;
    }

    /**
     * 設定 srepPhase 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrepPhase(String value) {
        this.srepPhase = value;
    }

}
