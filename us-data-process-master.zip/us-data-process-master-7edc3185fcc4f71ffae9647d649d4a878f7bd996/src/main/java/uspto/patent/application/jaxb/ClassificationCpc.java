//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}cpc-version-indicator"/&gt;
 *           &lt;group ref="{}classification-group"/&gt;
 *           &lt;element ref="{}symbol-position" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-value" minOccurs="0"/&gt;
 *           &lt;element ref="{}action-date" minOccurs="0"/&gt;
 *           &lt;element ref="{}generating-office" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-status" minOccurs="0"/&gt;
 *           &lt;element ref="{}classification-data-source" minOccurs="0"/&gt;
 *           &lt;element ref="{}scheme-origination-code" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" type="{}sequence-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cpcVersionIndicator",
    "section",
    "clazz",
    "subclass",
    "mainGroup",
    "subgroup",
    "symbolPosition",
    "classificationValue",
    "actionDate",
    "generatingOffice",
    "classificationStatus",
    "classificationDataSource",
    "schemeOriginationCode"
})
@XmlRootElement(name = "classification-cpc")
public class ClassificationCpc {

    @XmlElement(name = "cpc-version-indicator", required = true)
    protected CpcVersionIndicator cpcVersionIndicator;
    @XmlElement(required = true)
    protected String section;
    @XmlElement(name = "class", required = true)
    protected String clazz;
    @XmlElement(required = true)
    protected String subclass;
    @XmlElement(name = "main-group")
    protected MainGroup mainGroup;
    protected String subgroup;
    @XmlElement(name = "symbol-position")
    protected String symbolPosition;
    @XmlElement(name = "classification-value")
    protected String classificationValue;
    @XmlElement(name = "action-date")
    protected ActionDate actionDate;
    @XmlElement(name = "generating-office")
    protected GeneratingOffice generatingOffice;
    @XmlElement(name = "classification-status")
    protected String classificationStatus;
    @XmlElement(name = "classification-data-source")
    protected String classificationDataSource;
    @XmlElement(name = "scheme-origination-code")
    protected String schemeOriginationCode;
    @XmlAttribute(name = "sequence")
    protected String sequence;

    /**
     * 取得 cpcVersionIndicator 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CpcVersionIndicator }
     *     
     */
    public CpcVersionIndicator getCpcVersionIndicator() {
        return cpcVersionIndicator;
    }

    /**
     * 設定 cpcVersionIndicator 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CpcVersionIndicator }
     *     
     */
    public void setCpcVersionIndicator(CpcVersionIndicator value) {
        this.cpcVersionIndicator = value;
    }

    /**
     * 取得 section 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSection() {
        return section;
    }

    /**
     * 設定 section 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSection(String value) {
        this.section = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 subclass 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubclass() {
        return subclass;
    }

    /**
     * 設定 subclass 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubclass(String value) {
        this.subclass = value;
    }

    /**
     * 取得 mainGroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainGroup }
     *     
     */
    public MainGroup getMainGroup() {
        return mainGroup;
    }

    /**
     * 設定 mainGroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainGroup }
     *     
     */
    public void setMainGroup(MainGroup value) {
        this.mainGroup = value;
    }

    /**
     * 取得 subgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubgroup() {
        return subgroup;
    }

    /**
     * 設定 subgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubgroup(String value) {
        this.subgroup = value;
    }

    /**
     * 取得 symbolPosition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolPosition() {
        return symbolPosition;
    }

    /**
     * 設定 symbolPosition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolPosition(String value) {
        this.symbolPosition = value;
    }

    /**
     * 取得 classificationValue 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassificationValue() {
        return classificationValue;
    }

    /**
     * 設定 classificationValue 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassificationValue(String value) {
        this.classificationValue = value;
    }

    /**
     * 取得 actionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ActionDate }
     *     
     */
    public ActionDate getActionDate() {
        return actionDate;
    }

    /**
     * 設定 actionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionDate }
     *     
     */
    public void setActionDate(ActionDate value) {
        this.actionDate = value;
    }

    /**
     * 取得 generatingOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link GeneratingOffice }
     *     
     */
    public GeneratingOffice getGeneratingOffice() {
        return generatingOffice;
    }

    /**
     * 設定 generatingOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link GeneratingOffice }
     *     
     */
    public void setGeneratingOffice(GeneratingOffice value) {
        this.generatingOffice = value;
    }

    /**
     * 取得 classificationStatus 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassificationStatus() {
        return classificationStatus;
    }

    /**
     * 設定 classificationStatus 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassificationStatus(String value) {
        this.classificationStatus = value;
    }

    /**
     * 取得 classificationDataSource 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassificationDataSource() {
        return classificationDataSource;
    }

    /**
     * 設定 classificationDataSource 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassificationDataSource(String value) {
        this.classificationDataSource = value;
    }

    /**
     * 取得 schemeOriginationCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSchemeOriginationCode() {
        return schemeOriginationCode;
    }

    /**
     * 設定 schemeOriginationCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSchemeOriginationCode(String value) {
        this.schemeOriginationCode = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

}
