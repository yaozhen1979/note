//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.30 於 06:06:16 PM CST 
//


package uspto.patent.application.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}document-id" maxOccurs="unbounded"/&gt;
 *         &lt;choice&gt;
 *           &lt;element ref="{}us-371c124-date" minOccurs="0"/&gt;
 *           &lt;element ref="{}us-371c12-date" minOccurs="0"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "documentId",
    "us371C124Date",
    "us371C12Date"
})
@XmlRootElement(name = "pct-or-regional-filing-data")
public class PctOrRegionalFilingData {

    @XmlElement(name = "document-id", required = true)
    protected List<DocumentId> documentId;
    @XmlElement(name = "us-371c124-date")
    protected Us371C124Date us371C124Date;
    @XmlElement(name = "us-371c12-date")
    protected Us371C12Date us371C12Date;

    /**
     * Gets the value of the documentId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentId }
     * 
     * 
     */
    public List<DocumentId> getDocumentId() {
        if (documentId == null) {
            documentId = new ArrayList<DocumentId>();
        }
        return this.documentId;
    }

    /**
     * 取得 us371C124Date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Us371C124Date }
     *     
     */
    public Us371C124Date getUs371C124Date() {
        return us371C124Date;
    }

    /**
     * 設定 us371C124Date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Us371C124Date }
     *     
     */
    public void setUs371C124Date(Us371C124Date value) {
        this.us371C124Date = value;
    }

    /**
     * 取得 us371C12Date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Us371C12Date }
     *     
     */
    public Us371C12Date getUs371C12Date() {
        return us371C12Date;
    }

    /**
     * 設定 us371C12Date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Us371C12Date }
     *     
     */
    public void setUs371C12Date(Us371C12Date value) {
        this.us371C12Date = value;
    }

}
