package uspto.patent;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class XmlValidator2 {

    public static void main(String[] args) throws SAXException, IOException,
            ParserConfigurationException {

        DocumentBuilder db = null;

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        db = dbf.newDocumentBuilder();
        
        File file = new File("D:\\workspace-sts-3.7.0.RELEASE\\MyGroovyProject\\src\\main\\java\\uspto\\patent\\US00D741926.xml");
        
        String xml = FileUtils.readFileToString(file);
        
        xml = xml.replace("<!DOCTYPE us-patent-grant SYSTEM \"us-patent-grant-v45-2014-04-03.dtd\" [ ]>\r\n", "");
        
        Document doc = db.parse(new ByteArrayInputStream(xml.getBytes("utf-8")));

        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        
        File schemaLocation = new File("D:\\workspace-sts-3.7.0.RELEASE\\MyGroovyProject\\src\\main\\java\\uspto\\patent\\us-patent-grant-v45-2014-04-03.xsd");
        
        Schema schema = factory.newSchema(schemaLocation);
        
        Validator validator = schema.newValidator();

        validator.validate(new DOMSource(doc));

        System.out.println("valid xml ok...");

    }

}
