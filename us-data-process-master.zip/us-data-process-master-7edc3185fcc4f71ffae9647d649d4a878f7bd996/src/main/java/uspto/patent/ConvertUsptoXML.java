package uspto.patent;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.io.FileUtils;
import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;
import org.xml.sax.SAXException;

public class ConvertUsptoXML {

    private static boolean inited;
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    private static boolean isGrant;
    
    public static void main(String[] args) throws Exception {
        
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/US009173335.xml").getFile());
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/US00D741926.xml").getFile());
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/20150305535.xml").getFile());
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/20150305527.xml").getFile());
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/20150323655.xml").getFile());
//        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/9185579.xml").getFile());
        File file = new File (ConvertUsptoXML.class.getResource("/jaxb/xml/D0743117.xml").getFile());
        
        String xml = FileUtils.readFileToString(file);
        
        xml = xml.replace("<!DOCTYPE us-patent-grant SYSTEM \"us-patent-grant-v45-2014-04-03.dtd\" [ ]>\r\n", "");
        
//        xml = xml.replace("<!DOCTYPE us-patent-application SYSTEM \"us-patent-application-v44-2014-04-03.dtd\" [ ]>\r\n", "");
        
//        System.out.println("xml: " + xml);
        
        String jsonStr = null;
        
        try {
            jsonStr = xml2Json(xml, 2);
        } catch (JAXBException je) {
            je.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        System.out.println(jsonStr);
        
    }
    
    public static String xml2Json(String xml, int stat) throws Exception {
        
        isGrant = (stat == 1) ? false : true;
        
        return xml2Json(xml);
        
    }
    
    public static String xml2Json(String xml) throws Exception {
        return xml2Json(new ByteArrayInputStream(xml.getBytes("utf-8")));
    }
    
    private static void init() throws javax.xml.bind.JAXBException, SAXException {
        
        if (inited) {
            return;
        }
        
        JAXBContext jc = JAXBContext.newInstance("uspto.patent.jaxb");
        unmarshaller = jc.createUnmarshaller();
        
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        InputStream xsdis = ConvertUsptoXML.class.getResourceAsStream("/jaxb/xsd/patentcloud-us-patent-v1.xsd");
        Schema schema = sf.newSchema(new StreamSource(xsdis));
        unmarshaller.setSchema(schema);
        
        InputStream importMoxyBinding = ConvertUsptoXML.class.getResourceAsStream("/jaxb/oxm.xml");
        List<InputStream> moxyBindings = new ArrayList<InputStream>();
        moxyBindings.add(importMoxyBinding);
        Map<String, Object> props = new HashMap<String, Object>();
        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings);
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);
//        
//        JAXBContext jc1 = JAXBContext.newInstance("uspto.patent.jaxb", PatentcloudUsPatentDocumentType.class.getClassLoader(), props);
//        marshaller = jc1.createMarshaller();
//        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
//        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
//        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        
        inited = true;
    }
    
    public static String xml2Json(InputStream xml) throws javax.xml.bind.JAXBException, SAXException  {
        
        init();
        
        StringWriter sw = new StringWriter();
        
        if (isGrant) {
            /*
            UsPatentGrant doc = (UsPatentGrant) unmarshaller.unmarshal(xml);
            
            doc.setDescription(null);
            doc.setClaims(null);
            doc.getAbstract().clear();
            
            marshaller.marshal(doc, sw);
            */
            
        } else {
            /*
            UsPatentApplication doc = (UsPatentApplication) unmarshaller.unmarshal(xml);
            
            doc.setDescription(null);
            doc.setClaims(null);
            doc.getAbstract().clear();
            marshaller.marshal(doc, sw);
            */
        }
        return sw.toString();
    }
    
}
