package common;

public final class Constants {

    public final static String XSD_FILE_PATH_APPLICATION = "xsd/us-patent-application.xsd";
    public final static String XSD_FILE_PATH_GRANT = "xsd/us-patent-grant.xsd";
    public final static String JAXB_CONTEXT_PATH_APPLICATION = "uspto.patent.application.jaxb";
    public final static String JAXB_CONTEXT_PATH_GRANT = "uspto.patent.grant.jaxb";
    public final static String JAXB_OXM_PATH = "/jaxb/oxm/oxm.xml";
    public final static String LANG_ENCODING = "UTF-8";
    
    private Constants() {
    }

}
