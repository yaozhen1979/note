package patft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import patft.vo.patent.UsptoIssuePatent;

public class PatftParser {

    public static void main(String[] args) throws Exception {
        UsptoPatFTWebTool tool = new UsptoPatFTWebTool();
        
        String html = "\r\n" + 
                "<HTML>\r\n" + 
                "<HEAD>\r\n" + 
                "<BASE target=\"_top\">\r\n" + 
                "<TITLE>United States Patent: 5991329</TITLE></HEAD>\r\n" + 
                "<!-BUF1=5991329\r\n" + 
                "BUF7=1999\r\n" + 
                "BUF8=72610\r\n" + 
                "BUF9=/1/\r\n" + 
                "BUF51=5\r\n" + 
                "-->\r\n" + 
                "<BODY bgcolor=\"#FFFFFF\">\r\n" + 
                "<A name=\"top\"></A>\r\n" + 
                "<CENTER>\r\n" + 
                "<IMG src=\"/netaicon/PTO/patfthdr.gif\" alt=\"[US Patent & Trademark Office, Patent Full Text and Image Database]\">\r\n" + 
                "<BR>\r\n" + 
                "<TABLE>\r\n" + 
                "<TR><TD align=\"center\">\r\n" + 
                "<A href=\"/netahtml/PTO/index.html\"><IMG src=\"/netaicon/PTO/home.gif\" alt=\"[Home]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "<A href=\"/netahtml/PTO/search-bool.html\"><IMG src=\"/netaicon/PTO/boolean.gif\" alt=\"[Boolean Search]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "<A href=\"/netahtml/PTO/search-adv.htm\"><IMG border=\"0\" src=\"/netaicon/PTO/manual.gif\" ALT=\"[Manual Search]\" valign=\"middle\"></A>\r\n" + 
                "<A href=\"/netahtml/PTO/srchnum.htm\"><IMG src=\"/netaicon/PTO/number.gif\" alt=\"[Number Search]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "<A href=\"/netahtml/PTO/help/help.htm\"><IMG border=\"0\" valign=\"middle\" src=\"/netaicon/PTO/help.gif\" ALT=\"[Help]\"></A>\r\n" + 
                "</TD></TR>\r\n" + 
                "<TR><TD align=\"center\">\r\n" + 
                "<A href=\"#bottom\"><IMG src=\"/netaicon/PTO/bottom.gif\" alt=\"[Bottom]\" valign=\"middle\" border=\"0\"></A>\r\n" + 
                "</TD></TR>\r\n" + 
                "   <TR><TD align=\"center\">\r\n" + 
                "   <A href=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/ShowShoppingCart?backUrl1=http%3A//patft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%26r%3D1%26p%3D1%26f%3DG%26l%3D50%26d%3DPTXT%26S1%3D5991329.PN.%26OS%3DPN%2F5991329&backLabel1=Back%20to%20Document%3A%205991329\"><IMG border=\"0\" src=\"/netaicon/PTO/cart.gif\" border=\"0\" valign=\"middle\" alt=\"[\r\n" + 
                "View Shopping Cart]\"></A>\r\n" + 
                "   <A href=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/AddToShoppingCart?docNumber=5991329&backUrl1=http%3A//patft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%26r%3D1%26p%3D1%26f%3DG%26l%3D50%26d%3DPTXT%26S1%3D5991329.PN.%26OS%3DPN%2F5991329&backLabel1=Back%20to%20Document%3A%205991329\">\r\n" + 
                "   <IMG border=\"0\" src=\"/netaicon/PTO/order.gif\" valign=\"middle\" alt=\"[Add to Shopping Cart]\"></A>\r\n" + 
                "   </TD></TR>\r\n" + 
                "   <TR><TD align=\"center\">\r\n" + 
                "   <a href=http://pdfpiw.uspto.gov/.piw?Docid=05991329&homeurl=http%3A%2F%2Fpatft.uspto.gov%2Fnetacgi%2Fnph-Parser%3FSect1%3DPTO2%2526Sect2%3DHITOFF%2526u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%2526r%3D1%2526p%3D1%2526f%3DG%2526l%3D50%2526d%3DPTXT%2526S1%3D5991329.PN.%2526OS%3DPN%2F5991329%2526RS%3DPN%2F5991329&PageNum=&Rtype=&SectionNum=&idkey=NONE&Input=View+first+page><img src=\"/netaicon/PTO/image.gif\" alt=\"[Image]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "\r\n" + 
                "   </TD></TR>\r\n" + 
                "</TABLE>\r\n" + 
                "</CENTER>\r\n" + 
                "<TABLE width=\"100%\">\r\n" + 
                "<TR><TD align=\"left\" width=\"50%\">&nbsp;</TD>\r\n" + 
                "<TD align=\"right\" valign=\"bottom\" width=\"50%\"><FONT size=\"-1\">( <STRONG>1</STRONG></FONT> <FONT size=-2>of</FONT> <STRONG><FONT size=-1>1</STRONG> )</FONT></TD></TR></TABLE>\r\n" + 
                "<HR>\r\n" + 
                "   <TABLE width=\"100%\">\r\n" + 
                "   <TR> <TD align=\"left\" width=\"50%\"><b>United States Patent </b></TD>\r\n" + 
                "   <TD align=\"right\" width=\"50%\"><b><A Name=h1 HREF=#h0></A><A  HREF=#h2></A><B><I></I></B>5,991,329</b></TD>\r\n" + 
                "   </TR>\r\n" + 
                "     <TR><TD align=\"left\" width=\"50%\"><b>\r\n" + 
                "         Lomp\r\n" + 
                ", &nbsp; et al.</b>\r\n" + 
                "     </TD>\r\n" + 
                "     <TD align=\"right\" width=\"50%\"> <b>\r\n" + 
                "     November 23, 1999\r\n" + 
                "</b></TD>\r\n" + 
                "     </TR>\r\n" + 
                "     </TABLE>\r\n" + 
                "       <TABLE width=\"100%\">\r\n" + 
                "       <TR>\r\n" + 
                "       <TD align=\"center\" width=\"100%\"><FONT size=\"-2\"><b>**Please see images for: </b>\r\n" + 
                "         <FONT size=\"-2\"><b>( Certificate of Correction ) </b>\r\n" + 
                "       <FONT size=\"-2\"><b> **</b>\r\n" + 
                "       </TD>\r\n" + 
                "       </TR>\r\n" + 
                "       </TABLE>\r\n" + 
                "       <HR>\r\n" + 
                "       <FONT size=\"+1\"> Automatic power control system for a code division multiple access\r\n" + 
                "     (CDMA) communications system\r\n" + 
                "</FONT><BR>\r\n" + 
                "       <BR><CENTER><b>Abstract</b></CENTER>\r\n" + 
                "       <p>An automatic power control (APC) system for a spread-spectrum\r\n" + 
                "     communications system includes an automatic forward power control (AFPC)\r\n" + 
                "     system, and an automatic reverse power control (ARPC) system. In the AFPC,\r\n" + 
                "     each subscriber unit (SU) measures a forward signal-to-noise ratio of a\r\n" + 
                "     respective forward channel information signal to generate a respective\r\n" + 
                "     forward channel error signal which includes a measure of the uncorrelated\r\n" + 
                "     noise in the channel and a measure of the error between the respective\r\n" + 
                "     forward signal-to-noise ratio and a pre-determined signal-to-noise value.\r\n" + 
                "     A control signal generated from the respective forward channel error\r\n" + 
                "     signal is transmitted as part of a respective reverse channel information\r\n" + 
                "     signal. A base unit includes AFPC receivers which receive respective\r\n" + 
                "     reverse channel information signals and extract the forward channel error\r\n" + 
                "     signals therefrom to adjust the power levels of the respective forward\r\n" + 
                "     spread-spectrum signals. In the ARPC system, each base measures a reverse\r\n" + 
                "     signal-to-noise ratio of each of the respective reverse channel\r\n" + 
                "     information signals and generates a respective reverse channel error\r\n" + 
                "     signal which includes a measure of the uncorrelated noise in the channel\r\n" + 
                "     and a measure of the error between the respective reverse signal-to-noise\r\n" + 
                "     ratio and a pre-determined signal-to-noise value. The base unit transmits\r\n" + 
                "     a control signal generated from the respective reverse channel error\r\n" + 
                "     signal as a part of a respective forward channel information signal. Each\r\n" + 
                "     SU includes an ARPC receiver which receives the forward channel\r\n" + 
                "     information signal and extracts the respective reverse error signal to\r\n" + 
                "     adjust the reverse transmit power level of the respective reverse\r\n" + 
                "     spread-spectrum signal.\r\n" + 
                "</p>\r\n" + 
                "       <HR>\r\n" + 
                "<TABLE width=\"100%\"> <TR> <TH scope=\"row\" valign=\"top\" align=\"left\" width=\"10%\">Inventors:</TH> <TD align=\"left\" width=\"90%\">\r\n" + 
                " <B>Lomp; Gary</B> (Centerpot, NY)<B>, Ozluturk; Fatih</B> (Port Washington, NY)<B>, Kowalski; John</B> (Hempstead, NY) </TD> </TR>\r\n" + 
                "<TR> <TH scope=\"row\" valign=\"top\" align=\"left\" width=\"10%\">Assignee:</TH>\r\n" + 
                "<TD align=\"left\" width=\"90%\">\r\n" + 
                "\r\n" + 
                "<B>Interdigital Technology Corporation</B>\r\n" + 
                " (Wilmington, \r\n" + 
                "DE)\r\n" + 
                "<BR>\r\n" + 
                "\r\n" + 
                "</TD>\r\n" + 
                "</TR>\r\n" + 
                "       <TR><TH scope=\"row\" valign=\"top\" align=\"left\" width=\"10%\" nowrap>Family ID:\r\n" + 
                "       </TD><TD align=\"left\" width=\"90%\">\r\n" + 
                "       <b>21692981\r\n" + 
                "</b></TD></TR>\r\n" + 
                "       <TR><TH scope=\"row\" valign=\"top\" align=\"left\" width=\"10%\" nowrap>Appl. No.:\r\n" + 
                "       </TH><TD align=\"left\" width=\"90%\">\r\n" + 
                "       <b> 08/669,770</b></TD></TR>\r\n" + 
                "       <TR><TH scope=\"row\" valign=\"top\" align=\"left\" width=\"10%\">Filed:\r\n" + 
                "       </TH><TD align=\"left\" width=\"90%\">\r\n" + 
                "       <b>June 27, 1996</b></TD></TR>\r\n" + 
                "     </TABLE>\r\n" + 
                "     <HR>\r\n" + 
                "<p> <TABLE width=\"100%\"> <TR><TD valign=\"top\" align=\"left\" width=\"30%\"><b>Current U.S. Class:</b></TD> <TD valign=\"top\" align=\"right\" width=\"70%\"><b>375/130</b>; 375/E1.003; 375/E1.004; 375/E1.006; 375/E1.009; 375/E1.012; 375/E1.016; 375/E1.018; 375/E1.032 </TD></TR> \r\n" + 
                "       <TR><TD valign=\"top\" align=\"left\" width=\"30%\"><b>Current CPC Class: </b></TD>\r\n" + 
                "       <TD valign=\"top\" align=\"right\" width=\"70%\">H04B 1/707&nbsp(20130101); H04B 1/7075&nbsp(20130101); H04B 1/70753&nbsp(20130101); H04B 1/70754&nbsp(20130101); H04B 1/70755&nbsp(20130101); H04B 1/70758&nbsp(20130101); H04B 1/708&nbsp(20130101); H04B 1/7085&nbsp(20130101); H04B 1/709&nbsp(20130101); H04B 1/7093&nbsp(20130101); H04B 1/711&nbsp(20130101); H04B 7/2637&nbsp(20130101); H04J 13/00&nbsp(20130101); H04J 13/10&nbsp(20130101); H04J 13/107&nbsp(20130101); H04L 1/004&nbsp(20130101); H04L 1/0042&nbsp(20130101); H04L 1/0059&nbsp(20130101); H04L 25/0212&nbsp(20130101); H04L 27/206&nbsp(20130101); H04L 27/2332&nbsp(20130101); H04W 52/04&nbsp(20130101); H04W 52/08&nbsp(20130101); H04W 52/143&nbsp(20130101); H04W 52/24&nbsp(20130101); H04W 52/241&nbsp(20130101); H04W 52/245&nbsp(20130101); H04W 52/262&nbsp(20130101); H04W 52/322&nbsp(20130101); H04W 52/325&nbsp(20130101); H04W 52/343&nbsp(20130101); H04W 52/346&nbsp(20130101); H04W 52/36&nbsp(20130101); H04W 52/50&nbsp(20130101); H04W 52/52&nbsp(20130101); H04W 52/54&nbsp(20130101); G06F 13/374&nbsp(20130101); H04B 7/2628&nbsp(20130101); H04L 5/1446&nbsp(20130101); H04N 1/00912&nbsp(20130101); H04N 1/3333&nbsp(20130101); H03H 17/0226&nbsp(20130101); H04B 1/7115&nbsp(20130101); H04B 1/712&nbsp(20130101); H04B 7/264&nbsp(20130101); H04B 2201/70701&nbsp(20130101); H04B 2201/70702&nbsp(20130101); H04B 2201/7071&nbsp(20130101); H04J 13/004&nbsp(20130101); H04J 13/0048&nbsp(20130101); H04J 13/0077&nbsp(20130101); H04J 13/12&nbsp(20130101); H04J 2013/0037&nbsp(20130101); H04L 1/0001&nbsp(20130101); H04L 1/0054&nbsp(20130101); H04L 2027/003&nbsp(20130101); H04L 2027/0053&nbsp(20130101); H04W 52/146&nbsp(20130101); H04W 52/247&nbsp(20130101); H04W 52/26&nbsp(20130101); H04W 52/44&nbsp(20130101); H04W 52/60&nbsp(20130101); Y02B 60/50&nbsp(20130101); Y02B 60/1228&nbsp(20130101); H03H 17/06&nbsp(20130101); H04B 1/7077&nbsp(20130101); H04B 2201/70703&nbsp(20130101); H04B 2201/70707&nbsp(20130101); H04J 13/16&nbsp(20130101); H04L 1/0047&nbsp(20130101); H04N 2201/3335&nbsp(20130101); H04W 52/367&nbsp(20130101)</TD></TR>\r\n" + 
                "         <TR><TD valign=\"top\" align=\"left\" width=\"30%\"><b>Current International Class: </b></TD>\r\n" + 
                "         <TD valign=\"top\" align=\"right\" width=\"70%\">H04B 1/707&nbsp(20060101); H04L 25/02&nbsp(20060101); H04B 7/26&nbsp(20060101); H04J 13/00&nbsp(20060101); H04L 27/20&nbsp(20060101); H04L 27/233&nbsp(20060101); H04B 7/005&nbsp(20060101); H04L 1/00&nbsp(20060101); H04L 27/00&nbsp(20060101); H04B 001/69&nbsp(); H04B 007/005&nbsp()</TD></TR>\r\n" + 
                "       <TR><TD valign=\"top\" align=\"left\" width=\"30%\"><b>Field of Search: </b></TD>\r\n" + 
                "       <TD align=\"right\" valign=\"top\" width=\"70%\">\r\n" + 
                "       \r\n" + 
                "\r\n" + 
                "\r\n" + 
                "\r\n" + 
                "\r\n" + 
                " ;375/200,205,225,358,202\r\n" + 
                "       </TD></TR>\r\n" + 
                "     </TABLE>\r\n" + 
                "<HR><CENTER><b>References Cited  <A href=\"/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2Fsearch-adv.htm&r=0&f=S&l=50&d=PALL&Query=ref/5991329\">[Referenced By]</A></b></CENTER>       <HR>\r\n" + 
                "       <CENTER><b>U.S. Patent Documents</b></CENTER>\r\n" + 
                "<TABLE width=\"100%\"> <TR><TH scope=\"col\" width=\"33%\"></TH> <TH scope=\"col\" width=\"33%\"></TH> <TH scope=\"col\" width=\"34%\"></TH></TR> <TR> <TD align=\"left\">\r\n" + 
                "<a href=\"/netacgi/nph-Parser?Sect2=PTO1&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-bool.html&r=1&f=G&l=50&d=PALL&RefSrch=yes&Query=PN%2F5459759\">5459759</a></TD><TD align =left>\r\n" + 
                "October 1995</TD><TD align=left>\r\n" + 
                "Schilling</TD></TR><TR><TD align=left>\r\n" + 
                "<a href=\"/netacgi/nph-Parser?Sect2=PTO1&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-bool.html&r=1&f=G&l=50&d=PALL&RefSrch=yes&Query=PN%2F5657343\">5657343</a></TD><TD align =left>\r\n" + 
                "August 1997</TD><TD align=left>\r\n" + 
                "Schilling</TD></TR><TR><TD align=left>\r\n" + 
                "\r\n" + 
                "</TD>\r\n" + 
                "</TR> </TABLE>\r\n" + 
                "       <i>Primary Examiner:</i>  Ghebretinsae; Temesghen\r\n" + 
                "<BR>\r\n" + 
                "       <i>Attorney, Agent or Firm:</i> <coma>Volpe and Koenig, P.C.\r\n" + 
                "<BR>\r\n" + 
                "       <HR>\r\n" + 
                "       <CENTER><b><i>Parent Case Text</b></i></CENTER>\r\n" + 
                "       <HR>\r\n" + 
                "       <BR><BR>This application claims the benefit of U.S. Provisional application\r\n" + 
                "     60/000,775 filed June 30, 1995.\r\n" + 
                "         <HR>\r\n" + 
                "<CENTER><b><i>Claims</b></i></CENTER> <HR> <BR><BR>The invention claimed is: <BR><BR>1.  A system for adaptive power control of a second communication station's transmitter operating in a cellular-communications network using spread-spectrum modulation,\r\n" + 
                "the system comprising:\r\n" + 
                "<BR><BR>a communication station for receiving spread-spectrum signals transmitted from a second communication station through a communication channel;\r\n" + 
                "<BR><BR>said communication station including:\r\n" + 
                "<BR><BR>an antenna for receiving spread-spectrum signals;\r\n" + 
                "<BR><BR>at least one circuit for decoding spread-spectrum signals to receive a specific spread-spectrum signal associated with a unique code transmitted from said second station;\r\n" + 
                "<BR><BR>means for measuring a signal power of said received specific spread-spectrum signal;\r\n" + 
                "<BR><BR>means for measuring noise power within said channel;\r\n" + 
                "<BR><BR>means for measuring an average received total power within said channel;\r\n" + 
                "<BR><BR>first comparing means for comparing said signal power, said noise power and said average total power;\r\n" + 
                "<BR><BR>means for generating an error signal based on said first comparison;  and\r\n" + 
                "<BR><BR>a transmitter for transmitting spread-spectrum signals including said error signal to said second station;  and\r\n" + 
                "<BR><BR>said second communication station including:\r\n" + 
                "<BR><BR>an antenna for receiving spread-spectrum signals;\r\n" + 
                "<BR><BR>at least one detector for detecting said error signal;\r\n" + 
                "<BR><BR>transmit power adjustment means for adjusting a second station's transmitter power level in response to said error signal;  and\r\n" + 
                "<BR><BR>said second station's transmitter for transmitting said specific spread-spectrum signal within said channel to said communication station.\r\n" + 
                "<BR><BR>2.  The system according to claim 1 further comprising a second comparing means for comparing said noise power with a required signal to noise ratio.\r\n" + 
                "<BR><BR>3.  The system according to claim 2 wherein said second comparing means comprises a multiplier for multiplying said noise power to one plus said required signal to noise ratio.\r\n" + 
                "<BR><BR>4.  The system according to claim 2 further comprising a subtractor for subtracting an output of said second comparison from said signal power.\r\n" + 
                "<BR><BR>5.  The system according to claim 4 wherein said first comparing means comprises a combiner for combining a result of said subtractor with said average total power.\r\n" + 
                "<BR><BR>6.  The system according to claim 1, wherein said communication station is a base station communicating with a plurality of subscriber units and said second communication station is one of said plurality of subscriber units.\r\n" + 
                "<BR><BR>7.  The system according to claim 1, wherein said communication station is a subscriber unit and said second communication station is a base station communicating with a plurality of subscriber units.\r\n" + 
                "<BR><BR>8.  The system according to claim 7, said second communication station for receiving spread-spectrum signals transmitted from said communication station through a second communication channel;\r\n" + 
                "<BR><BR>said communication station further including:\r\n" + 
                "<BR><BR>at least one detector for detecting a second error signal;  and\r\n" + 
                "<BR><BR>transmit power adjustment means for adjusting a communication station's transmitter power level in response to said second error signal;  and\r\n" + 
                "<BR><BR>said second communication station further including:\r\n" + 
                "<BR><BR>at least one circuit for decoding spread-spectrum signals to receive a second specific spread-spectrum signal associated with a unique code transmitted from said communication station;\r\n" + 
                "<BR><BR>means for measuring a signal power of said second received specific spread-spectrum signal;\r\n" + 
                "<BR><BR>means for measuring a noise power within said second channel;\r\n" + 
                "<BR><BR>means for measuring an average received total power within said second channel;\r\n" + 
                "<BR><BR>third comparing means for comparing said second signal power, said second channel noise power and said second channel average total power;  and\r\n" + 
                "<BR><BR>means for generating the second error signal based on said third comparison;  and\r\n" + 
                "<BR><BR>wherein said communication station's transmitter transmits said second specific spread-spectrum signal.\r\n" + 
                "<BR><BR>9.  A method for adaptive-power control of a second communication station's transmitter for use in a cellular-communications network using spread-spectrum modulation wherein a second communication station transmits spread-spectrum signals within\r\n" + 
                "a communication channel which are received by a communication station, said method comprising the steps of:\r\n" + 
                "<BR><BR>receiving spread-spectrum signals within said communication channel at said communication station;\r\n" + 
                "<BR><BR>decoding said spread-spectrum signals to receive a specific spread-spectrum signal associated with a unique code from said second station;\r\n" + 
                "<BR><BR>measuring a signal power of said received specific spread-spectrum signal;\r\n" + 
                "<BR><BR>measuring a noise power and an average received total power within said communication channel;\r\n" + 
                "<BR><BR>comparing said signal power, said noise power and said average total power;\r\n" + 
                "<BR><BR>generating an error signal based on said comparison;\r\n" + 
                "<BR><BR>transmitting said error signal to said second station;\r\n" + 
                "<BR><BR>receiving said error signal at said second station;  and\r\n" + 
                "<BR><BR>adjusting a second communication station's transmitter power level in response to said error signal.\r\n" + 
                "<BR><BR>10.  The method according to claim 9 further comprising comparing said noise power with a required signal to noise ratio.\r\n" + 
                "<BR><BR>11.  The method according to claim 10 wherein comparing said noise power with a required signal to noise ratio is by multiplying said noise power to one plus said required signal to noise ratio.\r\n" + 
                "<BR><BR>12.  The method according to claim 10 further comprising subtracting a result of said noise power and required signal to noise ratio comparison from said signal power and wherein comparing said signal power, said noise power and said average\r\n" + 
                "total power is by combining a result of said subtraction with said average total power.\r\n" + 
                "<BR><BR>13.  A communication station for use in a system for adaptive power control of a second communication station's transmitter operating in a cellular-communications network using spread-spectrum modulation wherein a second station transmits\r\n" + 
                "spread-spectrum signals within a communication channel which are received by the communication station, the communication station comprising:\r\n" + 
                "<BR><BR>an antennae for receiving spread-spectrum signals;\r\n" + 
                "<BR><BR>at least one circuit for decoding spread-spectrum signals to receive a specific spread-spectrum signal associated with a unique code transmitted from said second station;\r\n" + 
                "<BR><BR>means for measuring a signal power of said received specific spread-spectrum signal;\r\n" + 
                "<BR><BR>means for measuring a noise power within said channel;\r\n" + 
                "<BR><BR>means for measuring an average received total power;\r\n" + 
                "<BR><BR>first comparing means for comparing said signal power, said noise power and said average total power;\r\n" + 
                "<BR><BR>means for generating an error signal for use in adjusting a second station's transmitter power level based on said comparison;  and\r\n" + 
                "<BR><BR>a transmitter for transmitting spread-spectrum signals including said error signal to said second station;  and\r\n" + 
                "<BR><BR>wherein said second station's transmitter power level is adjusted in response to detecting said error signal within said communication station's transmitted signals.\r\n" + 
                "<BR><BR>14.  The communication station of claim 13 further comprising:\r\n" + 
                "<BR><BR>at least one detector for detecting a second error signal;\r\n" + 
                "<BR><BR>transmit power adjustment means for adjusting a communication station's transmitter power level in response to said second error signal;  and\r\n" + 
                "<BR><BR>wherein said second station transmits said second error signal for adjusting said communication station's transmitter power level.\r\n" + 
                "<BR><BR>15.  A system for automatic maintenance power control (MPC) for maintaining the initial transmit power of a second communication station's transmitter, operating in a cellular-communications network using spread-spectrum modulation, the system\r\n" + 
                "comprising:\r\n" + 
                "<BR><BR>a communication station for receiving spread-spectrum signals transmitted from a second communication station through a communication channel;\r\n" + 
                "<BR><BR>said communication station including:\r\n" + 
                "<BR><BR>an antenna for receiving spread-spectrum signals;\r\n" + 
                "<BR><BR>at least one circuit for decoding spread-spectrum signals to receive a channel information signal transmitted from said second station;\r\n" + 
                "<BR><BR>means for measuring a signal power of said received channel information signal;\r\n" + 
                "<BR><BR>means for measuring a noise power within said channel;\r\n" + 
                "<BR><BR>means for measuring an average received total power within said channel;\r\n" + 
                "<BR><BR>first comparing means for comparing said signal power, said noise power and said average total power;\r\n" + 
                "<BR><BR>means for generating a channel error signal based on said first comparison;  and\r\n" + 
                "<BR><BR>a transmitter for transmitting spread-spectrum signals including said channel error signal to said second station;  and\r\n" + 
                "<BR><BR>said second communication station including:\r\n" + 
                "<BR><BR>an antennae for receiving spread-spectrum signals;\r\n" + 
                "<BR><BR>at least one detector for detecting said channel error signal;\r\n" + 
                "<BR><BR>transmit power adjustment means for adjusting a second station's transmitter power level in response to said channel error signal;  and\r\n" + 
                "<BR><BR>said second station's transmitter for occasionally transmitting said channel information signal to said communication station while inactive.\r\n" + 
                "<BR><BR>16.  The system according to claim 15 further comprising a second comparing means for comparing said noise power with a required signal to noise ratio.\r\n" + 
                "<BR><BR>17.  The system according to claim 16 wherein said second comparing means comprises a multiplier for multiplying said noise power to one plus said required signal to noise ratio.\r\n" + 
                "<BR><BR>18.  The system according to claim 16 further comprising a subtractor for subtracting an output of said second comparison from said signal power.\r\n" + 
                "<BR><BR>19.  The system according to claim 18 wherein said first comparing means comprises a combiner for combining a result of said subtractor with said average total power.\r\n" + 
                "<BR><BR>20.  The system according to claim 15, wherein said communication station is a base station communicating with a plurality of subscriber units and said second communication station is one of said plurality of subscriber units.\r\n" + 
                "<BR><BR>21.  A method for automatic maintenance power control (MPC) for maintaining the initial transmit power of a second communication station's transmitter for use in a cellular-communications network using spread-spectrum modulation wherein a second\r\n" + 
                "communication station transmits spread-spectrum signals within a communication channel which are received by a communication station, said method comprising the steps of:\r\n" + 
                "<BR><BR>occasionally transmitting by said second communication station while inactive using spread spectrum modulation a channel information signal to said communication station;\r\n" + 
                "<BR><BR>receiving spread-spectrum signals within said communication channel at said communication station;\r\n" + 
                "<BR><BR>decoding said spread-spectrum signals to receive said channel information signal associated with a unique code from said second station;\r\n" + 
                "<BR><BR>measuring a signal power of said received channel information signal;\r\n" + 
                "<BR><BR>measuring a noise power and an average received total power within said channel;\r\n" + 
                "<BR><BR>comparing said signal power, said noise power and said average total power;\r\n" + 
                "<BR><BR>generating a channel error signal based on said comparison;\r\n" + 
                "<BR><BR>transmitting said channel error signal to said second station;\r\n" + 
                "<BR><BR>receiving said channel error signal at said second station;  and\r\n" + 
                "<BR><BR>adjusting a second communication station's transmitter power level in response to said channel error signal.\r\n" + 
                "<BR><BR>22.  The method according to claim 21 further comprising comparing said noise power with a required signal to noise ratio.\r\n" + 
                "<BR><BR>23.  The method according to claim 22 wherein comparing said noise power with a required signal to noise ratio is by multiplying said noise power to one plus said required signal to noise ratio.\r\n" + 
                "<BR><BR>24.  The method according to claim 22 further comprising subtracting a result of said noise power and required signal to noise ratio comparison from said signal power and wherein comparing said signal power, said noise power and said average\r\n" + 
                "total power is by combining a result of said subtractor with said average total power. <HR> <CENTER><b><i>Description</b></i></CENTER> <HR> <BR><BR>BACKGROUND OF THE INVENTION\r\n" + 
                "<BR><BR>Providing quality telecommunication services to user groups which are classified as remote such as rural telephone systems and telephone systems in developing countries, has proved to be a challenge over recent years.  These needs have been\r\n" + 
                "partially satisfied by wireless radio services, such as fixed or mobile frequency division multiplex (FDM), frequency division multiple access (FDMA), time division multiplex (TDM), time division multiple access (TDMA) systems, combination frequency and\r\n" + 
                "time division systems (FD/TDMA), and other land mobile radio systems.  Usually, these remote services are faced with more potential users than can be supported simultaneously by their frequency or spectral bandwidth capacity.\r\n" + 
                "<BR><BR>Recognizing these limitations, recent advances in wireless communications have used spread spectrum modulation techniques to provide simultaneous communication by multiple users through a single communications channel.  Spread spectrum modulation\r\n" + 
                "refers to modulating a information signal with a spreading code signal: the spreading code signal being generated by a code generator where the period Tc of the spreading code is substantially less than the period of the information data bit or symbol\r\n" + 
                "signal.  The code may modulate the carrier frequency upon which the information has been sent, called frequency-hopped spreading, or may directly modulate the signal by multiplying the spreading code with the information data signal, called\r\n" + 
                "direct-sequence spreading (DS).  Spread-spectrum modulation produces a signal having a bandwidth that is substantially greater than that required to transmit the information signal.  Synchronous reception and despreading of the signal at the receiver\r\n" + 
                "demodulator recovers the original information.  The synchronous demodulator uses a reference signal to synchronize the despreading circuits to the input spread-spectrum modulated signal to recover the carrier and information signals.  The reference\r\n" + 
                "signal can be a spreading code which is not modulated by an information signal.  Such use of a synchronous spread-spectrum modulation and demodulation for wireless communication is described in U.S.  Pat.  No. 5,228,056 entitled SYNCHRONOUS\r\n" + 
                "SPREAD-SPECTRUM COMMUNICATIONS SYSTEM AND METHOD by Donald L. Schilling, which is incorporated herein by reference.\r\n" + 
                "<BR><BR>Spread-spectrum modulation in wireless networks offers many advantages because multiple users may use the same frequency band with minimal interference to each user's receiver.  In addition, spread spectrum modulation reduces effects from other\r\n" + 
                "sources of interference.  Also, synchronous spread-spectrum modulation and demodulation techniques may be expanded by providing multiple message channels for a user, each spread with a different spreading code, while still transmitting only a single\r\n" + 
                "reference signal to the user.  Such use of multiple message In channels modulated by a family of spreading codes synchronized to a pilot spreading code for wireless communication is described in U.S.  Pat.  No. 5,166,951 entitled HIGH CAPACITY\r\n" + 
                "SPREAD-SPECTRUM CHANNEL by Donald L. Schilling, which is incorporated herein by reference.\r\n" + 
                "<BR><BR>Another problem associated with multiple access, spread-spectrum communication systems is the need to reduce the total transmitted power of users in the system, since users may have limited available power.  An associated problem requiring power\r\n" + 
                "control in spread-spectrum systems is related to the inherent characteristic of spread-spectrum systems that one user's spread-spectrum signal is received by another user as noise with a certain power level.  Consequently, users transmitting with high\r\n" + 
                "levels of signal power may interfere with other users' reception.  Also, if a user moves relative to another user's geographic location, signal fading and distortion require that the users adjust their transmit power level to maintain a particular signal\r\n" + 
                "quality, and to maintain the power that the base station receives from all users.  Finally, because it is possible for the spread-spectrum system to have more remote users than can be supported simultaneously, the power control system should also employ\r\n" + 
                "a capacity management method which rejects additional users when the maximum system power level is reached.\r\n" + 
                "<BR><BR>Prior spread-spectrum systems have employed a base station that measures a received signal and sends an adaptive power control (APC) signal to the remote users.  Remote users include a transmitter with an automatic gain control (AGC) circuit\r\n" + 
                "which responds to the APC signal.  In such systems the base station monitors to the overall system power or the power received from each user, and sets the APC signal accordingly.  Such a spread-spectrum power control system and method is described in\r\n" + 
                "U.S.  Pat.  No. 5,299.226 entitled ADAPTIVE POWER CONTROL FOR A SPREAD SPECTRUM COMMUNICATION SYSTEM AND METHOD, and U.S.  Pat.  No. 5,093.840 entitled ADAPTIVE POWER CONTROL FOR A SPREAD SPECTRUM TRANSMITTER, both by Donald L. Schilling and incorporated\r\n" + 
                "herein by reference.  This open loop system performance may be improved by including a measurement of the signal power received by the remote user from the base station, and transmitting an APC signal back to the base station to effectuate a closed loop\r\n" + 
                "power control method.  Such closed loop power control is described, for 2) example, in U.S.  Pat.  No. 5,107,225 entitled HIGH DYNAMIC RANGE CLOSED LOOP AUTOMATIC GAIN CONTROL CIRCUIT to Charles E. Wheatley, III et al. and incorporated herein by\r\n" + 
                "reference.\r\n" + 
                "<BR><BR>These power control systems, however, exhibit several disadvantages.  First, the base station must perform complex power control algorithms, increasing the amount of processing in the base station.  Second, the system actually experiences several\r\n" + 
                "types of power variation: variation in the noise power caused by changing numbers of users and variations in the received signal power of a particular bearer channel.  These variations occur with different frequency, so simple power control algorithms\r\n" + 
                "can be optimized only to one of the two types of variation.  Finally, these power algorithms tend to drive the overall system power to a relatively high level.  Consequently, there is a need for a spread-spectrum power control method that rapidly\r\n" + 
                "responds to changes in bearer channel power levels, while simultaneously making adjustments to all users' transmit power in response to changes in the number of users.  Also, there is a need for an improved spread-spectrum communication system employing\r\n" + 
                "a closed loop power control system which minimizes the system's overall power requirements while maintaining a sufficient BER at the individual remote receivers.  In addition, such a system should control the initial transmit power level of a remote user\r\n" + 
                "and manage total system capacity.\r\n" + 
                "<BR><BR>SUMMARY OF THE INVENTION\r\n" + 
                "<BR><BR>The present invention includes a system and method for closed loop automatic power control (APC) for a base radio carrier station (RCS) and a group of subscriber units (SUs) of a spread-spectrum communication system.  The SUs transmit\r\n" + 
                "spread-spectrum signals, the RCS acquires the spread-spectrum signals, and the RCS detects the received power level of the spread-spectrum signals plus any interfering signal including noise.  The APC system includes the RCS and a plurality of SUs,\r\n" + 
                "wherein the RCS transmits a plurality of forward channel information signals to the SUs as a plurality of forward channel spread-spectrum signals having a respective forward transmit power level, and each SU transmits to the base station at least one\r\n" + 
                "reverse spread-spectrum signal having a respective reverse transmit power level and at least one reverse channel spread-spectrum signal includes a reverse channel information signal.\r\n" + 
                "<BR><BR>The APC includes an automatic forward power control (AFPC) system, and an automatic reverse power control (ARPC) system.  The AFPC has the steps of each SU measuring a forward signal-to-noise ratio of the respective forward channel information\r\n" + 
                "signal, generating a respective forward channel error signal which includes a measure of the forward error between the respective forward signal-to-noise ratio and a pre-determined signal-to-noise value.  The forward channel error signal also includes a\r\n" + 
                "measure of the uncorrelated noise in the channel.  The respective forward channel error signal is transmitted by the SU as part of a respective reverse channel information signal.  The RCS includes a plural number of AFPC receivers for receiving the\r\n" + 
                "reverse channel information signals and extracting the forward channel error signals from the respective reverse channel information signals.  The RCS also adjusts the respective forward transmit power level of each one of the respective forward\r\n" + 
                "spread-spectrum signals responsive to the respective forward error signal.\r\n" + 
                "<BR><BR>The portion of the ARPC system in the RCS measures a reverse signal-to-noise ratio of each of the respective reverse channel information signals, generates a respective reverse channel error signal which includes a measure of the error between\r\n" + 
                "the respective reverse channel signal-to-noise ratio and a respective pre-determined signal-to-noise value.  The reverse channel error signal also includes a measure of the uncorrelated noise in the channel.  The RCU transmits the respective reverse\r\n" + 
                "channel error signal as a part of a respective forward channel information signal.  Each SU includes an ARPC receiver which receives the forward channel information signal, extracts the respective reverse error signal from the forward to channel\r\n" + 
                "information signal, and adjusts the reverse transmit power level of the respective reverse spread-spectrum signal responsive to the respective reverse error signal. <BR><BR>BRIEF DESCRIPTION OF THE DRAWINGS\r\n" + 
                "<BR><BR>FIG. 1 is a block diagram of a code division multiple access communication system according to the present invention.\r\n" + 
                "<BR><BR>FIG. 2 is a flow-chart diagram of an exemplary maintenance power control algorithm of the present invention.\r\n" + 
                "<BR><BR>FIG. 3 is a flow-chart diagram of an exemplary automatic forward power control algorithm of the present invention.\r\n" + 
                "<BR><BR>FIG. 4 is a flow-chart diagram of an exemplary automatic reverse power control algorithm of the present invention.\r\n" + 
                "<BR><BR>FIG. 5 is a block diagram of an exemplary closed loop power control system of the present invention when the bearer channel is established.\r\n" + 
                "<BR><BR>FIG. 6 is a block diagram of an exemplary closed loop power control system of the present invention during the process of establishing the bearer channel. <BR><BR>DESCRIPTION OF THE EXEMPLARY EMBODIMENT\r\n" + 
                "<BR><BR>The system of the present invention provides local-loop telephone service using radio link between one or more base stations and multiple remote subscriber units.  In the exemplary embodiment, one radio link is described for a base station\r\n" + 
                "communicating with a fixed subscriber unit (FSU), but the system is equally applicable to systems including multiple base stations with radio links to both FSUs and Mobile Subscriber Units (MSUs).  Consequently, the remote subscriber units are referred\r\n" + 
                "to herein as Subscriber Units (SUs).\r\n" + 
                "<BR><BR>Referring to FIG. 1, Base Station (BS) 101 provides call connection to a local exchange (LE) 103 or any other telephone network switching interface, and includes a Radio Carrier Station (RCS) 104.  One or more RCSs 104, 105, 110 connect to a\r\n" + 
                "Radio Distribution Unit (RDU) 102 through links 131, 132, 137, 138, 139, and RDU 102 interfaces with LE 103 by transmitting and receiving call set-up, control, and information signals through telco links 141, 142, 150.  SUs 116, 119 communicate with the\r\n" + 
                "RCS 104 through RF links 161, 162, 163, 164, 165.  Alternatively, another embodiment of the invention includes several SUs and a \"master\" SU with functionality similar to the RCS.  Such an embodiment may or may not have connection to a local telephone\r\n" + 
                "network.\r\n" + 
                "<BR><BR>Although the described embodiment uses different spread-spectrum bandwidths centered around a carrier for the transmit and receive spread-spectrum channels, the present method is readily extended to systems using multiple spread-spectrum\r\n" + 
                "bandwidths for the transmit channels and multiple spread-spectrum bandwidths for the receive channels.  Alternatively, because spread-spectrum communication systems have the inherent feature that one user's transmission appears as noise to another user's\r\n" + 
                "despreading receiver, an embodiment can employ the same spread-spectrum channel for both the transmit and receive path channels.  In other words, Uplink and Downlink transmissions can occupy the same frequency band.  An embodiment of the invention may\r\n" + 
                "also employ multiple spread spectrum channels which need not be adjacent in frequency.  In this embodiment, any channel may be used for Uplink.  Downlink or Uplink and Downlink transmission.  In the exemplary embodiment, the spread binary symbol\r\n" + 
                "information is transmitted over the radio links 161 to 165 using Quadrature Phase Shift Keying (QPSK) modulation with Nyquist Pulse Shaping, although other modulation techniques may be used, including, but not limited to, Offset QPSK (OQPSK).  Minimum\r\n" + 
                "Shift Keying (MSK), M-ary Phase Shift Keying (MPSK) and Gaussian Phase Shift Keying (GPSK).\r\n" + 
                "<BR><BR>The CDMA demodulator in either the RCS or the SU despreads the received signal with appropriate processing to combat or exploit multipath propagation effects.  Parameters (concerning the received power level are used to generate the Automatic\r\n" + 
                "Power Control (APC) information which, in turn, is transmitted to the other end.  The APC information is used to control transmit power of the automatic forward power control (AFPC) and automatic reverse power control (ARPC) links.  In addition, each RCS\r\n" + 
                "104, 105 and 110 can perform Maintenance Power Control (MPC), in a manner similar to APC, to adjust the initial transmit power of each SU 111, 112, 115, 117 and 118.  Demodulation is coherent where the pilot signal provides the phase reference.\r\n" + 
                "<BR><BR>The transmit power levels of the radio interface between RCS 104 and SUs 111, 112, 115, 117 and 118 are controlled using two different closed loop power control algorithms.  The Automatic Forward Power Control (AFPC) determines the Downlink\r\n" + 
                "transmit power level, and the Automatic Reverse Power Control (ARPC) determines the Uplink transmit power level.  The logical control channel by which SU 111 and RCS 104, for example, transfer power control information operates at least a 16 kHz update\r\n" + 
                "rate.  Other embodiments may use a faster 32 kHz update rate.  These algorithms ensure that the transmit power of a user maintains an acceptable Bit-Error Rate (BER), maintains the system power at a minimum to conserve power, and maintains the power\r\n" + 
                "level of all SUs 111, 112, 115, 117 and 118.  as received by RCS 104, at a nearly equal level.\r\n" + 
                "<BR><BR>In addition, the system includes an optional maintenance power algorithm that is used during the inactive mode of a SU.  When SU 111 is inactive or powered-down to conserve power, the unit may occasionally activate itself and adjust its initial\r\n" + 
                "transmit power level setting in response to a maintenance power control signal from RCS 104.  The maintenance power signal is determined by the RCS 104 by measuring the received power level of SU 111 and present system power level and calculating the\r\n" + 
                "necessary initial transmit power.  The method shortens the channel acquisition time of SU 111 when it is turned on to begin a communication.  The method also prevents the transmit power level of SU 111 from becoming too high and interfering with other\r\n" + 
                "channels during the initial transmission before the closed loop power control adjusts the transmit power to a level appropriate for the other message traffic in the channel.\r\n" + 
                "<BR><BR>The RCS 104 obtains synchronization of its clock from an interface line such as, but not limited to, E1, T1, or HDSL interfaces.  Each RCS can also generate its own internal clock signal from an oscillator which may be regulated by a Global\r\n" + 
                "Positioning System (GPS) receiver.  The RCS 104 generates a Global Pilot Code for a channel having a spreading code but no data modulation, which can be acquired by remote SUs 111 through 118.  All transmission channels of the RCS are synchronous with\r\n" + 
                "the Pilot channel, and spreading code phases of code generators (not shown) used for Logical communication channels within RCS 104 are also synchronous with the Pilot channel's spreading code phase.  Similarly, SUs 111 through 118 which receive the\r\n" + 
                "Global Pilot Code of RCS 104 synchronize the spreading and de-spreading code phases of the code generators (not shown) of the SUs to the Global Pilot Code.\r\n" + 
                "<BR><BR>Logical Communication Channels\r\n" + 
                "<BR><BR>A `channel` of the prior art is usually regarded as a communications path that is part of an interface and that can be distinguished from other paths of the interface without regard to its content.  In the case of CDMA, however, separate\r\n" + 
                "communications pat-is are distinguished only by their content.  The term `logical channel` is used to distinguish the separate data streams, which are logically equivalent to channels in the conventional sense.  All logical channels and sub-channels of\r\n" + 
                "the present invention are mapped to a common 64 kilo-symbols per second (ksym/s) QPSK stream.  Some channels are synchronized to associated pilot codes which are generated and perform a similar function to the system Global Pilot Code.  The system pilot\r\n" + 
                "signals are not, however, considered logical channels.\r\n" + 
                "<BR><BR>Several logical communication channels are used over the RF communication link between the RCS and SU.  Each logical communication channel either has a fixed, pre-determined spreading code or a dynamically assigned spreading code.  For both\r\n" + 
                "pre-determined and assigned codes, the code phase is synchronous with the Pilot Code.  Logical communication channels are divided into two groups: the Global Channel (GC) group and the Assigned Channel (AC) group.  The GC group includes channels which\r\n" + 
                "are either transmitted from the base station RCS to all the remote SUs or from any SU to the RCS of the base station regardless of the SU's identity.  These channels typically contain information of a given type for all users.  These channels include the\r\n" + 
                "channels used by the SUs to gain system access.  Channels in the Assigned Channels (AC) group are those channels dedicated to communication between the RCS and a particular SU.\r\n" + 
                "<BR><BR>POWER CONTROL\r\n" + 
                "<BR><BR>General\r\n" + 
                "<BR><BR>The power control feature of the present invention is used to minimize the transmit power used between an RCS and any SUs with which it is in communication.  The power control subfeature that updates transmit power during bearer channel\r\n" + 
                "connection is defined as automatic power control (APC).  APC data is transferred from the RCS to an SU on the forward APC channel and from an SU to the RCS on the reverse APC channel.  When there is no active data link between the two, the maintenance\r\n" + 
                "power control subfeature (MPC) controls the transmit to power of the SU.\r\n" + 
                "<BR><BR>Transmit power levels of forward and reverse assigned channels and reverse global channels are controlled by the APC algorithm to maintain sufficient signal power to interference noise power ratio (SIR) on those channels, and to stabilize and\r\n" + 
                "minimize system output power.  The present invention uses a closed loop power control system in which a receiver controls its associated transmitter to incrementally raise or lower its transmit power.  This control is conveyed to the associated\r\n" + 
                "transmitter via the power control signal on the APC channel.  The receiver makes the decision to increase or decrease the transmitter's power based on two error signals.  One error signal is an indication of the difference between the measured and\r\n" + 
                "required despread signal powers, and the other error signal is an indication of the average received total power.\r\n" + 
                "<BR><BR>As used in the described embodiment of the invention, the term near-end power control is used to refer to adjusting the transmitter's output power in accordance with the APC signal received on the APC channel from the other end.  This means the\r\n" + 
                "reverse power control for the SU and forward power control for the RCS; and the term Jar-end APC is used to refer to forward power control for the SU and reverse power control for the RCS (adjusting the transmit power of the unit at the opposite end of\r\n" + 
                "the channel).\r\n" + 
                "<BR><BR>In order to conserve power, the SU modem terminates transmission and powers-down while waiting for a call, defined as the sleep phase.  Sleep phase is terminated by an awaken signal from the SU controller.  Responsive to this signal, the SU modem\r\n" + 
                "acquisition circuit automatically enters the reacquisition phase, and begins the process of acquiring the downlink pilot, as described below.\r\n" + 
                "<BR><BR>Closed Loop Power Control Algorithms\r\n" + 
                "<BR><BR>The near-end power control includes two steps: first, set the initial transmit power, second, continually adjust transmit power according to information received from the far-end using APC.\r\n" + 
                "<BR><BR>For the SU, initial transmit power is set to a minimum value and then ramped up, for example, at a rate of 1 dB/ms until either a ramp-up timer expires (not shown) or the RCS changes the corresponding traffic light value on the FBCH to \"red\"\r\n" + 
                "indicating the RCS has locked to the SU's short pilot signal (SAXPT).  Expiration of the timer causes the SAXPT transmission to be shut down, unless the traffic light value is set to red first, in which case the SU continues to ramp-up transmit power but\r\n" + 
                "at a much lower rate than before the \"red\" signal was detected.\r\n" + 
                "<BR><BR>The initial power ramp-up method is described in a U.S.  patent application entitled A METHOD OF CONTROLLING INITIAL POWER RAMP-UP IN CDMA SYSTEMS BY USING SHORT CODES, filed on even date herewith.  which is hereby incorporated by reference.\r\n" + 
                "<BR><BR>For the RCS, initial transmit power is set at a fixed value, corresponding to the minimum value necessary for reliable operation as determined experimentally for the service type and the current number of system users.  Global channels, such as\r\n" + 
                "the Global Pilot or, the fast broadcast channel (FBCH), are always transmitted at the fixed initial power, whereas traffic channels are switched to APC.\r\n" + 
                "<BR><BR>The APC signal is transmitted as one bit signals on the APC channel.  The one-bit signal represents a command to increase (signal is logic-high) or decrease (signal is logic-low) the associated transmit power.  In the described embodiment, the 64\r\n" + 
                "kbps APC data stream is not encoded or interleaved.\r\n" + 
                "<BR><BR>Far-end power control consists of the near-end transmitting power control information for the far-end to use in adjusting its transmit power.\r\n" + 
                "<BR><BR>The APC algorithm causes the RCS or the SU to transmit +1 if the following inequality holds, otherwise -1 (logic-low).\r\n" + 
                "<BR><BR>Here the error signal e.sub.1 is calculated as\r\n" + 
                "<BR><BR>where P.sub.d is the despread signal plus noise power, P.sub.N is the despread noise power, and SNR.sub.REF is the desired despread signal to noise ratio for the particular service type; and\r\n" + 
                "<BR><BR>where Pr is a measure of the received power and Po is the automatic gain control (AGC) circuit set point.  The weights .alpha..sub.1 and .alpha..sub.2 in equation (30) are chosen for each service type and for the APC update rate.\r\n" + 
                "<BR><BR>Maintenance Power Control\r\n" + 
                "<BR><BR>During the sleep phase of the SU, the interference noise power of the CDMA RF channel changes.  As an alternative to the initial power ramp-up method described above, the present invention may include a maintenance power control feature (MPC)\r\n" + 
                "which periodically adjusts the SU's initial transmit power with respect to the interference noise power of the CDMA channel.  The MPC is the process whereby the transmit power level of an SU is maintained within close proximity of the minimum level\r\n" + 
                "required for the RCS to detect the SU's signal.  The MPC process compensates for low frequency changes in the required SU transmit power.\r\n" + 
                "<BR><BR>The maintenance control feature uses two global channels: one is called the status channel (STCH) on reverse link, and the other is called the check-up channel (CUCH) on forward link.  The signals transmitted on these channels carry no data and\r\n" + 
                "they are generated the same way the short codes used in initial power ramp-up are generated.  The STCH and CUCH codes are generated from a \"reserved\" branch of the global code generator.\r\n" + 
                "<BR><BR>The MPC process is as follows.  At random intervals, the SU sends a symbol length spreading code periodically for 3 ms on the status channel (STCH).  If the RCS detects the sequence, it replies by sending a symbol length code sequence within the\r\n" + 
                "next 3 ms on the check-up channel (CUCH).  When the SU detects the response from the RCS, it reduces its transmit power by a particular step size.  If the SU does not detect any response from the RCS within the 3 ms period, it increases its transmit\r\n" + 
                "power by the step size.  Using this method, the RCS response is transmitted at a power level that is enough to maintain a 0.99 detection probability at all SU's.\r\n" + 
                "<BR><BR>The rate of change of traffic load and the number of active users is related to the total interference noise power of the CDMA channel.  The update rate and step size of the maintenance power update signal for the present invention is determined\r\n" + 
                "by using queuing theory methods well known in the art of communication theory, such as outlined in \"Fundamentals of Digital Switching\" (Plenum-New York) edited by McDonald and incorporated herein by reference.  By modeling the call origination process as\r\n" + 
                "an exponential random variable with mean 6.0 mins, numerical computation shows the maintenance power level of a SU should be updated once every 10 seconds or less to be able to follow the changes in interference level using 0.5 dB step size.  Modeling\r\n" + 
                "the call origination process as a Poisson random variable with exponential interarrival times, arrival rate of 2.times.10.sup.-4 per second per user, service rate of 1/360 per second, and the total subscriber population is 600 in the RCS service area\r\n" + 
                "also yields by numerical computation that an update rate of once every 10 seconds is sufficient when 0.5 dB step size is used.\r\n" + 
                "<BR><BR>Maintenance power adjustment is performed periodically by the SU which changes from sleep phase to awake phase and performs the MPC process.  Consequently, the process for the MPC feature is shown in FIG. 2 and is as follows: First, at step 201,\r\n" + 
                "signals are exchanged between the SU and the RCS maintaining a transmit power level that is close to the required level for detection: the SU periodically sends a symbol length spreading code in the STCH, and the RCS sends periodically a symbol length\r\n" + 
                "spreading code in the CUCH as response.\r\n" + 
                "<BR><BR>Next, at step 202, if the SU receives a response within 3 ms after the STCH message it sent, it decreases its transmit power by a particular step size at step 203; but if the SU does not receive a response within 3 ms after the STCH message, it\r\n" + 
                "increases its transmit power by the same step size at step 204.\r\n" + 
                "<BR><BR>The SU waits, at step 205, for a period of time before sending another STCH message, this time period is determined by a random process which averages 10 seconds.\r\n" + 
                "<BR><BR>Thus, the transmit power of the STCH messages from the SU is adjusted based on the RCS response periodically, and the transmit power of the CUCH messages from the RCS is fixed.\r\n" + 
                "<BR><BR>Mapping of Power Control Signal to Logical Channels For APC\r\n" + 
                "<BR><BR>Power control signals are mapped to specified Logical Channels for controlling transmit power levels of forward and reverse assigned channels.  Reverse global channels are also controlled by the APC algorithm to maintain sufficient signal power\r\n" + 
                "to interference noise power ratio (SIR) on those reverse channels, and to stabilize and minimize system output power.  The present invention uses a closed loop power control method in which a receiver periodically decides to incrementally raise or lower\r\n" + 
                "the output power of the transmitter at the other end.  The method also conveys that decision back to the respective transmitter.\r\n" + 
                "<BR><BR> TABLE 1  ______________________________________ APC Signal Channel Assigmnents  Link  Channels and  Call/Connection  Power Control Method  Signals Status Initial Value  Continuous  ______________________________________ Reverse link  Being\r\n" + 
                "Established  as determined by  APC bits in  AXCH power ramping  forward APC  AXPT channel  Reverse link  In-Progress level established  APC bits in  APC, OW, during call set-up  forward APC  TRCH, channel  pilot signal  Forward link  In-Progress fixed\r\n" + 
                "value APC bits in  APC, OW, reverse APC  TRCH channel  ______________________________________\r\n" + 
                "<BR><BR>Forward and reverse links are independently controlled.  For a call/connection in process, forward link traffic channel (TRCH) APC, and Order Wire (OW) power is controlled by the APC bits transmitted on the reverse APC channel.  During the\r\n" + 
                "call/connection establishment process, reverse link access channel (AXCH) power is also controlled by the APC bits transmitted on the forward APC channel.  Table 11 summarizes the specific power control methods for the controlled channels.\r\n" + 
                "<BR><BR>The required SIRs of the assigned channels TRCH, APC and OW and reverse assigned pilot signal for any particular SU are fixed in proportion to each other and these channels are subject to nearly identical fading, therfore, they are power\r\n" + 
                "controlled together.\r\n" + 
                "<BR><BR>Automatic Forward Power Control\r\n" + 
                "<BR><BR>The AFPC system attempts to maintain the minimum required SIR on the forward channels during a call/connection.  The AFPC recursive process shown in FIG. 3 consists of the steps of having an SU form the two error signals e.sub.1 and e.sub.2 in\r\n" + 
                "step 301 where\r\n" + 
                "<BR><BR>and P.sub.d is the despread signal plus noise power, P.sub.N is the despread noise power, SNR.sub.REF is the required signal to noise ratio for the service type, P.sub.r is a measure of the total received power, and P.sub.o is the AGC set point. \r\n" + 
                "Next, the SU modem forms the combined error signal .alpha..sub.1 e.sub.1 +.alpha..sub.2 e.sub.2 in step 302.  Here, the weights .alpha..sub.1 and .alpha..sub.2 are chosen for each service type and APC update rate.  In step 303, the SU hard limits the\r\n" + 
                "combined error signal and forms a single APC bit.  The SU transmits the APC bit to the RCS in step 304 and RCS modem receives the bit in step 305.  The RCS increases or decreases its transmit power to the SU in step 306 and the algorithm repeats starting\r\n" + 
                "from step 301.\r\n" + 
                "<BR><BR>Automatic Reverse Power Control\r\n" + 
                "<BR><BR>The ARPC system maintains the minimum required SIR on the reverse channels to minimize the total system reverse output power, during both call/connection establishment and while the call/connection is in progress.  The ARPC recursive process\r\n" + 
                "shown in FIG. 4 begins at step 401 where the RCS modem forms the two error signals e.sub.1 and e.sub.2 in step 401 where\r\n" + 
                "<BR><BR>SIR and Multiple Channel Types\r\n" + 
                "<BR><BR>The required SIR for channels on a link is a function of channel format (e.g. TRCH, OW).  service type (e.g. ISDN B, 32 kb/s ADPCM POTS).  and the number of symbols over which data bits are distributed (e.g. two 64 kb/s symbols are integrated to\r\n" + 
                "form a single 32 kb/s ADPCM POTS symbol).  Despreader output power corresponding to the required SIR for each channel and service type is predetermined.  While a call/connection is in progress, several user CDMA logical channels are concurrently active;\r\n" + 
                "each of these channels transfers a symbol every symbol period.  The SIR of the symbol from the nominally highest SIR channel is measured, compared to a threshold and used to determine the APC step up/down decision each symbol period.  Table 2 indicates\r\n" + 
                "the symbol (and threshold) used for the APC computation by service and call type.\r\n" + 
                "<BR><BR>APC Parameters\r\n" + 
                "<BR><BR>APC information is always conveyed as a single bit of information, and the APC Data Rate is equivalent to the APC Update Rate.  The APC update rate is 64 kb/s. This rate is high enough to accommodate expected Rayleigh and Doppler fades, and allow\r\n" + 
                "for a relatively high (.about.0.2) Bit Error Rate (BER) in the Uplink and Downlink APC channels, which minimizes capacity devoted to the APC.\r\n" + 
                "<BR><BR>The power step up/down indicated by an APC bit is nominally between 0.1 and 0.01 dB.  The dynamic range for power control is 70 dB on the reverse link and 12 dB on the forward link for the exemplary embodiment of the present system.  and P.sub.d\r\n" + 
                "is the despread signal plus noise power, P.sub.N is the despread noise power.  SNR.sub.REF is the reference signal to noise ratio for the service type, P.sub.rt is a measure of the average total power received by the RCS, and P.sub.o is the AGC set\r\n" + 
                "point.  The RCS modem forms the combined error signal .alpha..sub.1 e.sub.1 +.alpha..sub.2 e.sub.2 in step 402 and hard limits this error signal to determine a single APC bit in step 403.  The RCS transmits the APC bit to the SU in step 404, and the bit\r\n" + 
                "is received by the SU in step 405.  Finally, SU adjusts its transmit power according to the received APC bit in step 406, and the process repeats starting from step 401.\r\n" + 
                "<BR><BR> TABLE 2  ______________________________________ Symbols/Thresholds Used for APC Computation  Call/Connection  Symbol (and Threshold)  Service or Call Type  Status Used for APC Decision  ______________________________________ Don't care Being\r\n" + 
                "Established  AXCH  ISDN D SU In-Progress one 1/64-KBPS symbol  from TRCH (ISDN-D)  ISDN IB + D SU  In-Progress TRCH (ISDN-B)  ISDN 2B + D SU  In-Progress TRCH (one ISDN-B)  POTS SU (64 KBPS  In-Progress one 1/64-KBPS symbol  PCM) from TRCH, use 64  KBPS\r\n" + 
                "PCM threshold  POTS SU (32 KBPS  In-Progress one 1/64-KBPS symbol  ADPCM) from TRCH, use 32  KBPS ADPCM threshold  Silent Maintenance  In-Progress OW (continuous during a  Call (any SU) maintenance call)  ______________________________________\r\n" + 
                "<BR><BR>An Alternative Embodiment for Multiplexing APC Information\r\n" + 
                "<BR><BR>The dedicated APC and OW logical channels described previously can also be multiplexed together in one logical channel.  The APC information is transmitted at 64 kb/s. continuously whereas the OW information occurs in data bursts.  The\r\n" + 
                "alternative multiplexed logical channel includes the unencoded, non-interleaved 64 kb/s. APC information on, for example, the In-phase channel and the OW information on the quadrature channel of the QPSK signal.\r\n" + 
                "<BR><BR>Closed Loop Power Control Implementation\r\n" + 
                "<BR><BR>The closed loop power control during a call connection responds to two different variations in overall system power.  First, the system responds to local behavior such as changes in power level of an SU, and second, the system responds to changes\r\n" + 
                "in the power level of the entire group of active users in the system.\r\n" + 
                "<BR><BR>The Power Control system of the exemplary embodiment of the present invention is shown in FIG. 5.  As shown, the circuitry used to adjust the transmitted power hi similar for the RCS (shown as the RCS power control module 501) and SU (shown as\r\n" + 
                "the SU power control module 502).  Beginning with the RCS power control module 501, the reverse link RF channel signal is received at the RF antenna 590 and demodulated to produce the reverse CDMA signal RMCH which is applied to the variable gain\r\n" + 
                "amplifier (VGA1) 510.  The output signal of VGA1 510 is provided to the Automatic Gain Control (AGC) Circuit 511 which produces a variable gain amplifier control signal into the VGA1 510.  This signal maintains the level or the output signal of VGA1 510\r\n" + 
                "at a near constant value.  The output signal of VGA1 is despread by the despread-demultiplexer (demux) 512 which produces a despread user message signal MS and a forward APC bit.  The forward APC bit is applied to the integrator 513 to produce the\r\n" + 
                "Forward APC control signal.  The Forward APC control signal controls the Forward Link VGA2 514 and maintains the Forward Link RF channel signal at a minimum level necessary for communication.\r\n" + 
                "<BR><BR>The signal power of the despread user message signal MS of the RCS power module 501 is measured by the power measurement circuit 515 to produce a signal power indication.  The output of the VGA1 is also despread by the AUX despreader 581 which\r\n" + 
                "despreads the signal by using an uncorrelated spreading code, and hence obtains a despread noise signal.  The power measurement taken at power measurement device 582 of this signal is multiplied at multiplier 583 by 1 plus the required signal to noise\r\n" + 
                "ratio (SNR.sub.R) to form the threshold signal S1.  The difference between the despread signal power and the threshold value S1 is produced by the subtracter 516.  This difference is the error signal ES1 which is an error signal relating to the\r\n" + 
                "particular SU transmit power level.  Similarly the control signal for the VGA1 510 is applied to the rate scaling circuit 517 to reduce the rate of the control signal for VGA1 510.  The output signal of scaling circuit 517 is a scaled system power level\r\n" + 
                "signal SP1.  The Threshold Compute logic 518 computes the System Signal Threshold SST value from the RCS user channel power data signal (RCSUSR).  The complement of the Scaled system power level signal, SP1, and the System Signal Power Threshold value\r\n" + 
                "SST are applied to the adder 519 which produces second error signal ES2.  This error signal is related to the system transmit power level of all active SUs.  The input Error signals ES1 and ES2 are combined in the combiner 520 produce a combined error\r\n" + 
                "signal input to the delta modulator (DM1) 521, and the output signal of the DM1 is the reverse APC bit stream signal, having bits of value +1 or -1, which for the present invention is transmitted as a 64kb/sec signal.\r\n" + 
                "<BR><BR>The Reverse APC bit is applied to the spreading circuit 522.  and the output signal of the spreading circuit 522 is the spread-spectrum forward APC message signal.  Forward OW and Traffic signals are also provided to spreading circuits 523, 524,\r\n" + 
                "producing forward traffic message signals 1, 2, .  . . N. The power level of the forward APC signal, the forward OW, and traffic message signals are adjusted by the respective amplifiers 525, 526 and 527 to produce the power level adjusted forward APC,\r\n" + 
                "OW, and TRCH channels signals.  These signals are combined by the adder 528 and applied to the VAG2 514, which produces forward link RF channel signal.  The forward link RF channel signal is transmitted by transmitter 591.\r\n" + 
                "<BR><BR>The forward link RF channel signal including the spread forward APC signal is received by the RF antenna 592 of the SU, and demodulated to produce the forward CDMA signal FMCH.  This signal is provided to the variable gain amplifier (VGA3) 540. \r\n" + 
                "The output signal of VGA3 is applied to the Automatic Gain Control Circuit (AGC) 541 which produces a variable gain amplifier control signal to VGA3 540.  This signal maintains the level of the output signal of VGA3 at a near constant level.  The output\r\n" + 
                "signal of VAG3 540 is despread by the despread demux 542, which produces a despread user message signal SUMS and a reverse APC bit.  The reverse APC bit is applied to the integrator 543 which produces the Reverse APC control signal.  This reverse APC\r\n" + 
                "control signal is provided to the Reverse APC VGA4 544 to maintain the Reverse link RF channel signal at a minimum power level.\r\n" + 
                "<BR><BR>The despread user message signal SUMS is also applied to the power measurement circuit 545 producing a power measurement signal which is added to the complement of threshold value S2 in the adder 546 to produce error signal ES3.  The signal ES3\r\n" + 
                "is an error signal relating to the RCS transmit power level for the particular SU.  To obtain threshold S2, the despread noise power indication at measure power device 586 from the AUX despreader 585 is multiplied at multiplier 587 by 1 plus the desired\r\n" + 
                "signal lo noise ratio SNR.sub.R.  The AUX despreader 585 despreads the input data using an uncorrelated spreading code, hence its output is an indication of the despread noise power.\r\n" + 
                "<BR><BR>Similarly, the control signal for the VGA3 is applied to the rate scaling circuit 570 to reduce the rate of the control signal for VGA3 in order to produce a scaled received power level RP1 (see FIG. 5).  The threshold compute 598 circuit\r\n" + 
                "computes the received signal threshold RST from SU measured power signal SUUSR.  The complement of the scaled received power level RP1 and the received signal threshold RST are applied to the adder which produces error signal ES4.  This error is related\r\n" + 
                "to the RCS transmit power to all other SUs.  The input error signals ES3 and ES4 are combined in the combiner 599 and input to the delta modulator DM2 547, and the output signal of DM2 547 is the forward APC bit stream signal, with bits having value of\r\n" + 
                "value +1 or -1.  In the exemplary embodiment of the present invention this signal is transmitted as a 64kb/sec signal.\r\n" + 
                "<BR><BR>The Forward APC bit stream signal is applied to the spreading circuit 2948.  to produce the output reverse spread-spectrum APC signal.  Reverse OW and Traffic signals are also input to spreading circuits 549, 550, producing reverse OW and traffic\r\n" + 
                "message signals 1, 2 .  . . N. and the reverse pilot is generated by the reverse pilot generator 551.  The power level of the reverse APC message signal.  reverse OW message signal, reverse pilot, and the reverse traffic message signals are adjusted by\r\n" + 
                "amplifiers 552, 553, 554, 555 to produce the signals which are combined by the adder 556 and input to the reverse APC VGA4 544.  It is this VGA4 544 which produces the reverse link RF channel signal.  The reverse link RF channel signal is transmitted by\r\n" + 
                "transmitter 593.\r\n" + 
                "<BR><BR>During the call connection and bearer channel establishment process, the closed loop power control of the present invention is modified, and is shown in FIG. 6.  As shown, the circuits used to adjust the transmitted power are different for the\r\n" + 
                "RCS, shown as the Initial RCS power control module 601; and for the SU, shown as the Initial SU power control module 602.  Beginning with the Initial RCS power control module 601, the reverse link RF channel signal is received at the RF antenna 640 and\r\n" + 
                "demodulated producing the reverse CDMA signal IRMCH which is received by the first variable gain amplifier (VGA 1) 603.  The output signal of VGA1 is detected by the Automatic Gain Control Circuit (AGC1) 604 which provides a variable gain amplifier\r\n" + 
                "control signal to VGA1 603 to maintain the level of the output signal of VAG1 at a near constant value.  The output signal of VGA1 is despread by the despread demultiplexer 605.  which produces a despread user message signal IMS.  The Forward APC control\r\n" + 
                "signal, ISET, is set to a fixed value, and is applied to the Forward Link Variable Gain Amplifier (VGA2) 606 to set the Forward Link RF channel signal at a predetermined level.\r\n" + 
                "<BR><BR>The signal power of the despread user message signal IMS of the Initial RCS power module 601 is measured by the power measure circuit 607, and the output power measurement is subtracted from a threshold value S3 in the subtracter 608 to produce\r\n" + 
                "error signal ES5.  which is an error signal relating to the transmit power level of a particular SU.  The threshold S3 is calculated by multiplying at multiplier 652 the despread power measurement at measure power device 651 obtained from the AUX\r\n" + 
                "despreader 650 by 1 plus the desired signal to noise ratio SNR.  The AUX despreader 650 despreads the signal using an uncorrelated spreading code, hence its output signal is an indication of despread noise power.  Similarly, the VGA1 control signal is\r\n" + 
                "applied to the rate scaling circuit 609 to reduce the rate of the VGA1 control signal in order to produce a scaled system power level signal SP2.  The threshold computation logic 610 determines an Initial System Signal Threshold value (ISST) computed\r\n" + 
                "from the user channel power data signal (IRCSUSR).  The complement of the scaled system power level signal SP2 and the (ISST) are provided to the adder 611 which produces a second error signal ES6, which is an error signal relating to the system transmit\r\n" + 
                "power level of all active SUs.  The value of ISST is the desired transmit power for a system having the particular configuration.  The input Error signals ES5 and ES6 are combined in the combiner 612 produce a combined error signal input to the delta\r\n" + 
                "modulator (DM3) 613.  DM3 produces the initial reverse APC bit stream signal, having bits of value +1 or -1, which for the present invention is transmitted as a 64kb/sec signal.\r\n" + 
                "<BR><BR>The Reverse APC bit stream signal is applied to the spreading circuit 614.  to produce the initial spread-spectrum forward APC signal.  The control channel (CTCH) information is spread by the spreader 616 to form the spread CTCH message signal. \r\n" + 
                "The spread APC and CTCH signals are scaled by the amplifiers 615 and 617 and combined by the combiner 618.  The combined signal is appled to VAG2 606.  which produces the forward link RF channel signal.  The forward link RF channel signal is transmitted\r\n" + 
                "by transmitter 641.\r\n" + 
                "<BR><BR>The forward link RF channel signal including the spread forward APC signal is received by the RF antenna 642 of the SU and demodulated to produce the initial forward CDMA signal (IFMCH) which is applied to the variable gain amplifier (VGA3) 620. \r\n" + 
                "The output signal of VGA3 is detected by the Automatic Gain Control Circuit (AGC2) 621 which produces a variable gain amplifier control signal for the VGA3 620.  This signal maintains the output power level of the VGA3 620 at a near constant value.  The\r\n" + 
                "output signal of VAG3 is despread by the despread demultiplexer 622 which produces an initial reverse APC bit that is dependent on the output level of VGA3.  The reverse APC bit is processed by the integrator 623 to produce the Reverse APC control\r\n" + 
                "signal.  The Reverse APC control signal is provided to the Reverse APC VGA4 624 to maintain Reverse link RF channel signal at a defined power level the reverse link RF channel signal is transmitted by transmitter 643.\r\n" + 
                "<BR><BR>The global channel AXCH signal is spread by the spreading circuits 625 to provide the spread AXCH channel signal.  The reverse pilot generator 626 provides a reverse pilot signal, and the signal power of AXCH and the reverse pilot signal are\r\n" + 
                "adjusted by the respective amplifiers 627 and 628.  The spread AXCH channel signal and the reverse pilot signal are added by the adder 629 to produce reverse link CDMA signal.  The reverse link CDMA signal is received by the reverse APC VGA4 624, which\r\n" + 
                "produces the reverse link RF channel signal output to the RF transmitter.\r\n" + 
                "<BR><BR>System Capacity Management\r\n" + 
                "<BR><BR>The system capacity management algorithm of the present invention optimizes the maximum user capacity for an RCS area, called a cell.  When the SU comes within a certain value of maximum transmit power, the SU sends an alarm message to the RCS. \r\n" + 
                "The RCS sets the traffic lights which control access to the system, to \"red\" which, as previously described, is a flag that inhibits access by the SU's.  This condition remains in effect until the alarming SU terminates its call, or until the transmit\r\n" + 
                "power of the alarming SU, measured at the SU, is a value less than the maximum transmit power.  When multiple SUs send alarm messages, the condition remains in effect until either all calls from alarming SUs terminate, or until the transmit power of the\r\n" + 
                "alarming SU, measured at the SU, is a value less than the maximum transmit power.  An alternative embodiment measures the bit error rate measurements from the Forward Error Correction (FEC) decoder, and holds the RCS traffic lights at \"red\" until the bit\r\n" + 
                "error rate is less than a predetermined value.\r\n" + 
                "<BR><BR>The blocking strategy of the present invention includes a method which uses the power control information transmitted from the RCS to an SU, and the received power measurements at the RCS.  The RCS measures its transmit power level, detects that\r\n" + 
                "a maximum value is reached, and determines when to block new users.  An SU preparing to enter the system blocks itself if the SU reaches the maximum transmit power before successful completion of a bearer channel assignment.\r\n" + 
                "<BR><BR>Each additional user in the system has the effect of increasing the noise level for all other users, which decreases the signal to noise ratio (SNR) that each user experiences.  The power control algorithm maintains a desired SNR for each user. \r\n" + 
                "Therefore, in the absence of any other limitations, addition of a new user into the system has only a transient effect and the desired SNR is regained.\r\n" + 
                "<BR><BR>The transmit power measurement at the RCS is done by measuring either the root mean square (rms) value of the baseband combined signal or by measuring the transmit power of the RF signal and feeding it back to digital control circuits.  The\r\n" + 
                "transmit power measurement may also be made by the SUs to determine if the unit has reached its maximum transmit power.  The SU transmit power level is determined by measuring the control signal of the RF amplifier, and scaling the value based on the\r\n" + 
                "service type, such as plain old telephone service (POTS), FAX, or integrated services digital network (ISDN).\r\n" + 
                "<BR><BR>The information that an SU has reached the maximum power is transmitted to the RCS by the SU in a message on the Assigned Channels.  The RCS also determines the condition by measuring reverse APC changes because, if the RCS sends APC messages to\r\n" + 
                "the SU to increase SU transmit power, and the SU transmit power measured at the RCS is not increased, the SU has reached the maximum transmit power.\r\n" + 
                "<BR><BR>The RCS does not use traffic lights to block new users who have finished ramping-up using the short codes.  These users are blocked by denying them the dial tone and letting them time out.  The RCS sends all 1's (go down commands) on the APC\r\n" + 
                "Channel to make the SU lower its transmit power.  The RCS also sends either no CTCH message or a message with an invalid address which would force the FSU to abandon the access procedure and start over.  The SU does not start the acquisition process\r\n" + 
                "immediately because the traffic lights are red.\r\n" + 
                "<BR><BR>When the RCS reaches its transmit power limit, it enforces blocking in the same manner as when an SU reaches its transmit power limit.  The RCS turns off all the traffic lights on the FBCH, starts sending all I APC bits (go down commands) to\r\n" + 
                "those users who have completed their short code ramp-up but have not yet been given dial tone, and either sends no CTCH message to these users or sends messages with invalid addresses to force them to abandon the access process.\r\n" + 
                "<BR><BR>The self blocking algorithm of the SU is as follows.  When the SU starts transmitting the AXCH, the APC starts its power control operation using the AXCH and the SU transmit power increases.  While the transmit power is increasing under the\r\n" + 
                "control of the APC, it is monitored by the SU controller.  If the transmit power limit is reached, the SU abandons the access procedure and starts over.\r\n" + 
                "<BR><BR>Although the invention has been described in terms of an exemplary embodiment, it is understood by those skilled in the art that the invention may be practiced with modifications to the embodiment that are within the scope of the invention as\r\n" + 
                "defined by the following claims:\r\n" + 
                "<BR><BR><CENTER><b>* * * * *</b></CENTER>\r\n" + 
                "<HR>\r\n" + 
                "   <CENTER>\r\n" + 
                "   <a href=http://pdfpiw.uspto.gov/.piw?Docid=05991329&homeurl=http%3A%2F%2Fpatft.uspto.gov%2Fnetacgi%2Fnph-Parser%3FSect1%3DPTO2%2526Sect2%3DHITOFF%2526u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%2526r%3D1%2526p%3D1%2526f%3DG%2526l%3D50%2526d%3DPTXT%2526S1%3D5991329.PN.%2526OS%3DPN%2F5991329%2526RS%3DPN%2F5991329&PageNum=&Rtype=&SectionNum=&idkey=NONE&Input=View+first+page><img src=\"/netaicon/PTO/image.gif\" alt=\"[Image]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "   <TABLE>\r\n" + 
                "   <TR><TD align=\"center\"><A href=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/ShowShoppingCart?backUrl1=http%3A//patft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%26r%3D1%26p%3D1%26f%3DG%26l%3D50%26d%3DPTXT%26S1%3D5991329.PN.%26OS%3DPN%2F5991329&backLabel1=Back%20to%20Document%3A%205991329\"><IMG border=\"0\" src=\"/netaicon/PTO/cart.gif\" border=\"0\"\r\n" + 
                " valign=\"middle\" alt=\"[View Shopping Cart]\"></A>\r\n" + 
                "   <A href=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/AddToShoppingCart?docNumber=5991329&backUrl1=http%3A//patft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.htm%26r%3D1%26p%3D1%26f%3DG%26l%3D50%26d%3DPTXT%26S1%3D5991329.PN.%26OS%3DPN%2F5991329&backLabel1=Back%20to%20Document%3A%205991329\">\r\n" + 
                "   <IMG border=\"0\" src=\"/netaicon/PTO/order.gif\" valign=\"middle\" alt=\"[Add to Shopping Cart]\"></A>\r\n" + 
                "   </TD></TR>\r\n" + 
                "   <TR><TD align=\"center\">\r\n" + 
                "   <A href=\"#top\"><IMG valign=\"middle\" src=\"/netaicon/PTO/top.gif\" border=\"0\" alt=\"[Top]\"></A>\r\n" + 
                "   </TD></TR>\r\n" + 
                "   </TABLE>\r\n" + 
                "   <A name=\"bottom\"></A>\r\n" + 
                "   <A href=\"/netahtml/PTO/index.html\"><IMG src=\"/netaicon/PTO/home.gif\" alt=\"[Home]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "   <A href=\"/netahtml/PTO/search-bool.html\"><IMG src=\"/netaicon/PTO/boolean.gif\" alt=\"[Boolean Search]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "   <A href=\"/netahtml/PTO/search-adv.htm\"><IMG border=\"0\" src=\"/netaicon/PTO/manual.gif\" alt=\"[Manual Search]\" valign=\"middle\"></A>\r\n" + 
                "   <A href=\"/netahtml/PTO/srchnum.htm\"><IMG src=\"/netaicon/PTO/number.gif\" alt=\"[Number Search]\" border=\"0\" valign=\"middle\"></A>\r\n" + 
                "   <A href=\"/netahtml/PTO/help/help.htm\"><IMG border=\"0\" src=\"/netaicon/PTO/help.gif\" alt=\"[Help]\" valign=\"middle\"></A>\r\n" + 
                "   </CENTER>\r\n" + 
                "</BODY>\r\n" + 
                "</HTML>";
        
        UsptoIssuePatent patent = tool.parseHtml(html);
        
        GsonBuilder builder = new GsonBuilder();
        builder.setDateFormat("yyyy-MM-dd");
        Gson gson = builder.create();
         
        String json = gson.toJson(patent); 
        
        System.out.println(json);
    }
    
}
