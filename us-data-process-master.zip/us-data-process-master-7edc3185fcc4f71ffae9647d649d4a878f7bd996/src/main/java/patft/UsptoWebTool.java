package patft;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

public abstract class UsptoWebTool extends PatentWebTool {

    private static final DateFormat[] DFS = new DateFormat[] { new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH),
            new SimpleDateFormat("MMM yyyy", Locale.ENGLISH), new SimpleDateFormat("MMM., yyyy", Locale.ENGLISH),
            new SimpleDateFormat("MMM , yyyy", Locale.ENGLISH), new SimpleDateFormat(", yyyy", Locale.ENGLISH), };

    public UsptoWebTool() {
        super();
    }

    /**
     * 負責以各式日期格式解析傳入之字串
     * 
     * @param dateStr
     *            日期字串
     * @return java.util.Date 解析之Date物件
     * @throws ParseException
     */
    public static Date parseDate(String dateStr) throws ParseException {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }

        Date formatDate = null;
        for (int i = 0; i < DFS.length; i++) {
            try {
                formatDate = DFS[i].parse(dateStr);
                return formatDate;
            } catch (ParseException ignored) {
                return null;
            }
        }
        throw new ParseException("All date formatters failed to parse [" + dateStr + "]", 0);
    }
}
