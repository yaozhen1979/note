package patft.number;

import java.util.regex.Pattern;

import patft.vo.patent.PatentConstant;
import patft.vo.patent.PoConstant;

public class SipoNumberUtil extends CommonPoNumberUtil {
    private static Pattern applicationNoPattern = Pattern.compile("[0-9]{6,}\\.[A-Z0-9]", Pattern.CASE_INSENSITIVE);

    public static Integer getApplicationType(String applicationNo) {
        int flag = 0;
        if ("2".equals(applicationNo.substring(0, 1))) {
            flag = Integer.parseInt(applicationNo.substring(4, 5));
        } else if ("8".equals(applicationNo.substring(0, 1)) || "9".equals(applicationNo.substring(0, 1))
                || "00".equals(applicationNo.substring(0, 2)) || "01".equals(applicationNo.substring(0, 2))
                || "02".equals(applicationNo.substring(0, 2)) || "03".equals(applicationNo.substring(0, 2))
                || "04".equals(applicationNo.substring(0, 2))) {
            flag = Integer.parseInt(applicationNo.substring(2, 3));
        }

        if (flag > 0) {
            switch (flag) {
            case 1:
            case 8:
                return PoConstant.PATENT_APP_TYPE_UTILITY;
            case 2:
            case 9:
                return PoConstant.PATENT_APP_TYPE_MODEL;
            case 3:
                return PoConstant.PATENT_APP_TYPE_DESIGN;
            default:
            }
        }
        
        return null;
    }

    public static Integer getAppTypeByPatentNo(String patentNo) {
        patentNo = patentNo.trim().toUpperCase().replace("CN", "");
        
        int flag = 0;
        if ("8".equals(patentNo.substring(0, 1))) {
            flag = Integer.parseInt(patentNo.substring(2, 3));
        } else {
            flag = Integer.parseInt(patentNo.substring(0, 1));
        }
        
        if (flag > 0) {
            switch (flag) {
            case 1:
                return PoConstant.PATENT_APP_TYPE_UTILITY;
            case 2:
                return PoConstant.PATENT_APP_TYPE_MODEL;
            case 3:
                return PoConstant.PATENT_APP_TYPE_DESIGN;
            default:
            }
        }
        
        return null;
    }

    public static String getPatentStateByPatentNo(String patentNo, String kindCode) {
        Integer flag = getAppTypeByPatentNo(patentNo);
        if (flag == null || patentNo == null) {
            return null;
        }

        if (PoConstant.PATENT_APP_TYPE_UTILITY == flag) {
            if (kindCode == null || kindCode.length() == 0) {
                return "";
            }
            return ("A".equalsIgnoreCase(kindCode)) ? PatentConstant.PATENT_STATE_PUBLICATION
                    : PatentConstant.PATENT_STATE_ISSUE;
        } else {
            return PatentConstant.PATENT_STATE_ISSUE;
        }
    }

    public static String normalizeAppNo(String appNo) {
        if (appNo == null || (appNo.length() != 9 && appNo.length() != 13)) {
            return appNo;
        }
        return appNo.substring(0, appNo.length() - 1) + "." + appNo.substring(appNo.length() - 1);
    }

//    static String formatApplicationNo(String applicationNo) {
//        if (applicationNo != null) {
//            int idx = applicationNo.indexOf(".");
//            if (idx > 0) {
//                applicationNo = new String(applicationNo.substring(0, idx));
//            }
//        }
//        return applicationNo;
//    }

    static Boolean isApplicationNo(String applicationNo) {
        return applicationNo != null && applicationNoPattern.matcher(applicationNo).matches();
    }

}
