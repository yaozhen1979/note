package patft.number;

import java.text.DecimalFormat;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

public class UsptoNumberUtil extends CommonPoNumberUtil {

    private static Pattern patentPattern = Pattern.compile(
            "\\p{Digit}{1,7}" 
//            + "|" 
//            + "US\\p{Digit}{1,7}" 
            + "|" 
            + "D\\p{Digit}{1,6}"
            + "|"
            + "PP\\p{Digit}{1,5}" 
            + "|" 
            + "RE\\p{Digit}{1,5}" 
            + "|" 
            + "RX\\p{Digit}{1,5}" 
            + "|"
            + "AI\\p{Digit}{1,5}" 
            + "|" 
            + "T\\p{Digit}{1,6}"
            + "|"
            + "H\\p{Digit}{1,6}", Pattern.CASE_INSENSITIVE);

    private static Pattern publicationPattern = Pattern.compile(
            "\\p{Digit}{11}" 
//            + "|"
//            + "US\\p{Digit}{10}" 
            + "|"
            + "\\p{Digit}{4}/\\p{Digit}{7}");

    private static Pattern applicationPattern = Pattern.compile(
            "\\p{Digit}{8}" 
            + "|"
            + "\\p{Digit}{2}/\\p{Digit}{6}"
            + "|"
            + "D\\p{Digit}{6}"
            + "|"
            + "D/\\p{Digit}{6}");

    private static Pattern pctPattern = Pattern.compile(
            "PCT/\\p{Alpha}{2}\\p{Digit}{2}/\\p{Digit}{5}");

    private static Pattern usPatentPattern = Pattern.compile(
            "US"
            + "|"
            + "\\p{Digit}{2}");

    public static boolean isPCTNumber(String no) {
        if (no == null) {
            return false;
        }
        return pctPattern.matcher(no.replaceAll(",", "")).matches();
    }

    public static boolean isApplicationNumber(String no) {
        if (no == null) {
            return false;
        }
        return applicationPattern.matcher(no.replaceAll(",", "")).matches();
    }

    public static boolean isPatentNumber(String no) {
        if (no == null) {
            return false;
        }
        return patentPattern.matcher(no.replaceAll(",", "")).matches();
    }

    public static boolean isPublicationNumber(String no) {
        if (no == null) {
            return false;
        }
        return publicationPattern.matcher(no).matches();
    }

    public static boolean isUsPatent(String no) {
        if (no == null) {
            return false;
        }
        String countryCode = no.replaceAll(",", "").substring(0, 2);
        return usPatentPattern.matcher(countryCode).matches();
    }

    public static String formatNo(String no) {
        String patentNo = formatWithComma(no).replaceAll(",", "");
        return patentNo;
    }

    /**
     * ���F�[�W comma ���~�]�|�⤣�� 7 �U�r������ "0"
     * 
     * @param no
     * @return
     */
    public static String formatWithComma(String no) {

        if (StringUtils.isBlank(no)) {
            return no;
        }

        if (isPublicationNumber(no)) {
            return no;
        }
        no = no.toUpperCase().replaceAll(",", "");

        if (StringUtils.isNumeric(no)) {
            DecimalFormat format = new DecimalFormat("0,000,000");
            no = format.format(Integer.parseInt(no));
        } else {
            if (no.startsWith("D")) {
                DecimalFormat format = new DecimalFormat("000,000");
                no = "D" + format.format(Integer.parseInt(no.substring(1)));
            } else if (no.startsWith("PP")) {
                DecimalFormat format = new DecimalFormat("00,000");
                no = "PP" + format.format(Integer.parseInt(no.substring(2)));
            } else if (no.startsWith("RE")) {
                DecimalFormat format = new DecimalFormat("00,000");
                no = "RE" + format.format(Integer.parseInt(no.substring(2)));
            } else if (no.startsWith("T")) {
                DecimalFormat format = new DecimalFormat("000,000");
                no = "T" + format.format(Integer.parseInt(no.substring(1)));
            } else if (no.startsWith("H")) {
                DecimalFormat format = new DecimalFormat("000,000");
                no = "H" + format.format(Integer.parseInt(no.substring(1)));
            } else if (no.startsWith("RX")) {
                DecimalFormat format = new DecimalFormat("00,000");
                no = "RX" + format.format(Integer.parseInt(no.substring(2)));
            } else if (no.startsWith("AI")) {
                DecimalFormat format = new DecimalFormat("00,000");
                no = "AI" + format.format(Integer.parseInt(no.substring(2)));
            }
        }
        return no;
    }

    public static String normalizeAppNo(String appNo) {
        if (appNo != null) {
            if (appNo.startsWith("D")) {
                appNo = appNo.replaceFirst("D", "29");
            }
            appNo = appNo.replaceAll("\\,", "");
        }
        return appNo;
    }

    public static String parseAppSerialNo(String rawAppNo) {
        String serialNo = null;
        if (rawAppNo != null) {
            serialNo = StringUtils.substringAfter(rawAppNo, "/");
            serialNo = PoNumberUtil.formatNumber(serialNo);
        }
        return serialNo;
    }

    public static String parseAppSerialCode(String rawAppNo) {
        String serialCode = null;
        if (rawAppNo != null) {
            serialCode = StringUtils.substringBefore(rawAppNo, "/");
            serialCode = PoNumberUtil.formatNumber(serialCode);
        }
        return serialCode;
    }
}
