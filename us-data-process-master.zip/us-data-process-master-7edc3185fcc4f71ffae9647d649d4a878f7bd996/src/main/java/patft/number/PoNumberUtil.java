package patft.number;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import patft.country.CountryCode;
import patft.country.CountryUtil;
import patft.vo.tuple.Tuple3;

public class PoNumberUtil {

    private static Pattern numberKindPattern = Pattern.compile("^(.+?)([a-zA-Z][0-9]?)?$");
    private static Pattern rawNumberReplacePattern = Pattern.compile("[^a-zA-Z0-9]");


    public static Tuple3<String, String, String> splitCountryNumberKind(String no) {
        String country = null;
        String kind = null;
        if (no != null) {
            country = CountryUtil.parseCountryCodeFromNo(no);
            if (country != null) {
                no = no.substring(country.length());
            }
            Matcher matcher = numberKindPattern.matcher(no);
            if (matcher.find()) {
                no = matcher.group(1);
                kind = matcher.group(2);
            }
        }
        if (CountryCode.CN.equalsIgnoreCase(country) && kind != null && kind.length() == 1
                && ".".equals(no.substring(no.length() - 1))) {
            no = no + kind;
            kind = null;
        }
        return new Tuple3<String, String, String>(country, no, kind);
    }

    public static String formatNumber(String no) {
        if (no != null) {
            return rawNumberReplacePattern.matcher(no).replaceAll("");
        } else {
            return no;
        }
    }

//    public static String formatApplicationNo(String countryCode, String applicationNo) {
//        if (CountryCode.CN.equalsIgnoreCase(countryCode)) {
//            applicationNo = SipoNumberUtil.formatApplicationNo(applicationNo);
//        }
//        return applicationNo;
//    }

    public static Boolean isCnApplicationNo(String countryCode, String applicationNo) {
        if (CountryCode.CN.equalsIgnoreCase(countryCode)) {
            return SipoNumberUtil.isApplicationNo(applicationNo);
        } else {
            return false;
        }
    }

//    public static Boolean isIdentityByApplicationNo(Patent patent) {
//        return CountryCode.CN.equalsIgnoreCase(patent.getCountryCode());
//    }
}
