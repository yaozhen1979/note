package patft.number;

import patft.country.CountryUtil;

class CommonPoNumberUtil {

    protected static String trimCountry(String countryCode, String patentNo) {
        if (countryCode == null || countryCode.length() == 0 || patentNo == null || patentNo.length() == 0) {
            return patentNo;
        }
        while (patentNo.indexOf(countryCode) == 0) {
            patentNo = patentNo.substring(countryCode.length());
        }
        return patentNo;
    }

    protected static String trimKindCode(String patentNo, String kindCode) {
        if (patentNo == null || patentNo.length() == 0 || kindCode == null || kindCode.length() == 0) {
            return patentNo;
        }
        while (patentNo.lastIndexOf(kindCode) == (patentNo.length() - kindCode.length())) {
            patentNo = patentNo.substring(0, patentNo.length() - kindCode.length());
        }
        return patentNo;
    }

    public static String parseCountryCodeFromNumber(String no) {
        if (no != null && no.length() >= 2) {
            String countryCode = no.substring(0, 2);
            if (CountryUtil.isCountryCode(countryCode)) {
                return countryCode;
            }
        }
        return null;
    }
}
