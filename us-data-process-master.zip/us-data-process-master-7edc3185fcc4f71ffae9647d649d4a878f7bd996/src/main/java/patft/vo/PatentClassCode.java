package patft.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class PatentClassCode implements Serializable {
    private static final long serialVersionUID = -6198109779301619531L;

    private int pos;
    private int type;
    private String classNo;
    private String classId;
    private String version;
    private boolean main;

    public int getPos() {
        return pos;
    }
    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public String getClassNo() {
        return classNo;
    }
    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }

    public String getClassId() {
        return classId;
    }
    public void setClassId(String classId) {
        this.classId = classId;
    }

    public boolean equals(Object target) {
        if (target instanceof PatentClassCode) {
            PatentClassCode t = (PatentClassCode) target;
            return new EqualsBuilder().append(this.type, t.type).append(this.pos, t.pos).isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.type).append(this.pos).toHashCode();
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) {
        this.version = version;
    }
    public boolean isMain() {
        return main;
    }
    public void setMain(boolean main) {
        this.main = main;
    }
}
