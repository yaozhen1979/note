package patft.vo.patent;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import patft.util.DateUtil;

public abstract class AbstractPatentInfo implements Serializable {
    private static final long serialVersionUID = 6587970261035360023L;

    private String countryCode;
    private String kindCode;
    private String patentNo;
    private String fullPatentNo;

    private String issueNo;
    private String publicationNo;
    private String applicationNo;
    private String rawAppNo;

    private Date issueDate;
    private Date publicationDate;
    private Date applicationDate;

    private Integer patentYear;
    private Integer issueYear;
    private Integer publicationYear;
    private Integer appYear;

    private Integer applicationType;

    private String title;
    private String titles;
    private String abstracts;
    private String state;

    private List<Inventor> inventors;
    private List<Assignee> assignees;
    private List<Assignee> currentAssignees;

    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getKindCode() {
        return kindCode;
    }
    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public String getPatentNo() {
        return patentNo;
    }
    public void setPatentNo(String patentNo) {
        this.patentNo = patentNo;
    }

    public String getFullPatentNo() {
        if (fullPatentNo == null) {
            String no = patentNo;
            if (no == null) {
                no = issueNo;
            }
            if (no == null) {
                no = publicationNo;
            }
            if (no == null) {
                no = applicationNo;
            }
            if (no != null) {
                fullPatentNo = countryCode + no;
            }
        }
        return fullPatentNo;
    }

    public String getIssueNo() {
        return issueNo;
    }
    public void setIssueNo(String issueNo) {
        this.issueNo = issueNo;
    }

    public String getPublicationNo() {
        return publicationNo;
    }
    public void setPublicationNo(String publicationNo) {
        this.publicationNo = publicationNo;
    }

    public String getApplicationNo() {
        return applicationNo;
    }
    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getRawAppNo() {
        return rawAppNo;
    }
    public void setRawAppNo(String rawAppNo) {
        this.rawAppNo = rawAppNo;
    }

    public Date getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
        this.issueYear = DateUtil.getYearInteger(issueDate);
        initPatentYear();
    }

    public Date getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
        this.publicationYear = DateUtil.getYearInteger(publicationDate);
        initPatentYear();
    }

    public Date getApplicationDate() {
        return applicationDate;
    }
    public void setApplicationDate(Date applicationDate) {
        this.applicationDate = applicationDate;
        this.appYear = DateUtil.getYearInteger(applicationDate);
    }

    public Integer getPatentYear() {
        return patentYear;
    }
    public void setPatentYear(Integer patentYear) {
        this.patentYear = patentYear;
    }
    private void initPatentYear() {
        if (this.issueDate != null) {
            this.patentYear = DateUtil.getYearInteger(issueDate);
        } else if (this.publicationDate != null) {
            this.patentYear = DateUtil.getYearInteger(publicationDate);
        }
    }

    public Integer getIssueYear() {
        return issueYear;
    }
    public void setIssueYear(Integer issueYear) {
        this.issueYear = issueYear;
    }

    public Integer getPublicationYear() {
        return publicationYear;
    }
    public void setPublicationYear(Integer publicationYear) {
        this.publicationYear = publicationYear;
    }

    public Integer getAppYear() {
        return appYear;
    }
    public void setAppYear(Integer appYear) {
        this.appYear = appYear;
    }

    public Integer getApplicationType() {
        return applicationType;
    }
    public void setApplicationType(Integer applicationType) {
        this.applicationType = applicationType;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitles() {
        return titles;
    }
    public void setTitles(String titles) {
        this.titles = titles;
    }
    
    public String getAbstracts() {
        return abstracts;
    }
    public void setAbstracts(String abstracts) {
        this.abstracts = abstracts;
    }
    
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }

    public List<Inventor> getInventors() {
        return inventors;
    }
    public void setInventors(List<Inventor> inventors) {
        this.inventors = inventors;
    }

    public List<Assignee> getAssignees() {
        return assignees;
    }
    public void setAssignees(List<Assignee> assignees) {
        this.assignees = assignees;
    }

    public List<Assignee> getCurrentAssignees() {
        return currentAssignees;
    }
    public void setCurrentAssignees(List<Assignee> currentAssignees) {
        this.currentAssignees = currentAssignees;
    }
}
