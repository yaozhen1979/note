package patft.vo.patent;

import java.util.Date;
import java.util.List;
import java.util.Set;

import patft.vo.PatentClassCode;
import patft.vo.PatentClassCodeAppend;

public abstract class PoPatentInfo extends PoPatent {
    private static final long serialVersionUID = 8639981342704822342L;

    private String abstractt;
    private String claims;
    private String description;
    private String seriesCode;
    private String correspondenceNameAndAddress;
    private String summaryInvention;
    private String fieldOfSearch;
    private String notice;
    private String primaryExaminer;
    private String assistantExaminer;

    private List<String> attorneyAgentOrFirms;
    private String attorneyAgent;

    private String parentCaseText;
    private String earliestPublicationNo;
    private Date earliestPublicationDate;
    private String governmentInterest;
    private Date pctField;
    private String pctNo;
    private String pctPubNo;
    private Date pctPubDate;
    private Date d102e;
    private Date d371;
    private Date d371c124;

    //SIPO
    private String divParentNo;
    private String internationalPublish;
    private Date nationalEntryDate;
    private String mainClaim;

    //TIPO
    private String gazetteVolume; 
    private String loc;
    private String title2ndLang;
    private String certificationNo;

    //kangarooPatent
    private Date certificatedDate;
    private String masterIPC;
    private String masterLOC;
    private String patentType;

    private Set<PatentClassCode> patentClassCodes;
    private Set<PatentClassCodeAppend> patentClassCodeAppends;
    private Set<PatentPriority> patentPrioritys;

    private List<Inventor> inventors;
    private List<Assignee> assignees;
    private List<Assignee> currentAssignees;

    private List<ForeignAppPriorityData> foreignAppPriorityDatas;

    private List<RefPatent> refPatents;
    private List<RefByPatent> refByPatents;
    private List<RefOtherDoc> refOtherDocs;

    // for excel epxort only USPTO issued patent
    private String currentAssigneeStr;

//    @Override
//    public final void setCode(Integer code) {
//        if (code != null && !code.equals(getCode())) {
//            throw new RuntimeException("inconsistent code:" + code + "\n discriminator-value:" + getCode());
//        }
//    }

    @Override
    public final void setSourceType(String sourceType) {
        if (sourceType != null && !sourceType.equals(getSourceType())) {
            throw new RuntimeException("inconsistent code:" + sourceType + "\n discriminator-value:" + getSourceType());
        }
    }

    public String getAbstractt() {
        return abstractt;
    }
    public void setAbstractt(String abstractt) {
        this.abstractt = abstractt;
    }

    public String getClaims() {
        return claims;
    }
    public void setClaims(String claims) {
        this.claims = claims;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getSeriesCode() {
        return seriesCode;
    }
    public void setSeriesCode(String seriesCode) {
        this.seriesCode = seriesCode;
    }

    public String getCorrespondenceNameAndAddress() {
        return correspondenceNameAndAddress;
    }
    public void setCorrespondenceNameAndAddress(String correspondenceNameAndAddress) {
        this.correspondenceNameAndAddress = correspondenceNameAndAddress;
    }

    public String getSummaryInvention() {
        return summaryInvention;
    }
    public void setSummaryInvention(String summaryInvention) {
        this.summaryInvention = summaryInvention;
    }

    public String getFieldOfSearch() {
        return fieldOfSearch;
    }
    public void setFieldOfSearch(String fieldOfSearch) {
        this.fieldOfSearch = fieldOfSearch;
    }

    public String getNotice() {
        return notice;
    }
    public void setNotice(String notice) {
        this.notice = notice;
    }

    public String getPrimaryExaminer() {
        return primaryExaminer;
    }
    public void setPrimaryExaminer(String primaryExaminer) {
        this.primaryExaminer = primaryExaminer;
    }

    public String getAssistantExaminer() {
        return assistantExaminer;
    }
    public void setAssistantExaminer(String assistantExaminer) {
        this.assistantExaminer = assistantExaminer;
    }

    public List<String> getAttorneyAgentOrFirms() {
        return attorneyAgentOrFirms;
    }
    public void setAttorneyAgentOrFirms(List<String> attorneyAgentOrFirms) {
        this.attorneyAgentOrFirms = attorneyAgentOrFirms;
    }

    public String getAttorneyAgent() {
        return attorneyAgent;
    }
    public void setAttorneyAgent(String attorneyAgent) {
        this.attorneyAgent = attorneyAgent;
    }

    public String getParentCaseText() {
        return parentCaseText;
    }
    public void setParentCaseText(String parentCaseText) {
        this.parentCaseText = parentCaseText;
    }

    public String getEarliestPublicationNo() {
        return earliestPublicationNo;
    }
    public void setEarliestPublicationNo(String earliestPublicationNo) {
        this.earliestPublicationNo = earliestPublicationNo;
    }

    public Date getEarliestPublicationDate() {
        return earliestPublicationDate;
    }
    public void setEarliestPublicationDate(Date earliestPublicationDate) {
        this.earliestPublicationDate = earliestPublicationDate;
    }

    public String getGovernmentInterest() {
        return governmentInterest;
    }
    public void setGovernmentInterest(String governmentInterest) {
        this.governmentInterest = governmentInterest;
    }

    public Date getPctField() {
        return pctField;
    }
    public void setPctField(Date pctField) {
        this.pctField = pctField;
    }

    public String getPctNo() {
        return pctNo;
    }
    public void setPctNo(String pctNo) {
        this.pctNo = pctNo;
    }

    public String getPctPubNo() {
        return pctPubNo;
    }
    public void setPctPubNo(String pctPubNo) {
        this.pctPubNo = pctPubNo;
    }

    public Date getPctPubDate() {
        return pctPubDate;
    }
    public void setPctPubDate(Date pctPubDate) {
        this.pctPubDate = pctPubDate;
    }

    public Date getD102e() {
        return d102e;
    }
    public void setD102e(Date d102e) {
        this.d102e = d102e;
    }

    public Date getD371() {
        return d371;
    }
    public void setD371(Date d371) {
        this.d371 = d371;
    }

    public Date getD371c124() {
        return d371c124;
    }
    public void setD371c124(Date d371c124) {
        this.d371c124 = d371c124;
    }

    //SIPO
    public String getDivParentNo() {
        return divParentNo;
    }
    public void setDivParentNo(String divParentNo) {
        this.divParentNo = divParentNo;
    }

    public String getInternationalPublish() {
        return internationalPublish;
    }
    public void setInternationalPublish(String internationalPublish) {
        this.internationalPublish = internationalPublish;
    }

    public Date getNationalEntryDate() {
        return nationalEntryDate;
    }
    public void setNationalEntryDate(Date nationalEntryDate) {
        this.nationalEntryDate = nationalEntryDate;
    }

    public String getMainClaim() {
        return mainClaim;
    }
    public void setMainClaim(String mainClaim) {
        this.mainClaim = mainClaim;
    }

    //TIPO
    public String getGazetteVolume() {
        return gazetteVolume;
    }
    public void setGazetteVolume(String gazetteVolume) {
        this.gazetteVolume = gazetteVolume;
    }

    public String getLoc() {
        return loc;
    }
    public void setLoc(String loc) {
        this.loc = loc;
    }

    public String getTitle2ndLang() {
        return title2ndLang;
    }
    public void setTitle2ndLang(String title2ndLang) {
        this.title2ndLang = title2ndLang;
    }

    public String getCertificationNo() {
        return certificationNo;
    }
    public void setCertificationNo(String certificationNo) {
        this.certificationNo = certificationNo;
    }

    public Date getCertificatedDate() {
        return certificatedDate;
    }
    public void setCertificatedDate(Date certificatedDate) {
        this.certificatedDate = certificatedDate;
    }

    public String getMasterIPC() {
        return masterIPC;
    }
    public void setMasterIPC(String masterIPC) {
        this.masterIPC = masterIPC;
    }

    public String getMasterLOC() {
        return masterLOC;
    }
    public void setMasterLOC(String masterLOC) {
        this.masterLOC = masterLOC;
    }

    public String getPatentType() {
        return patentType;
    }
    public void setPatentType(String patentType) {
        this.patentType = patentType;
    }

    public Set<PatentClassCode> getPatentClassCodes() {
        return patentClassCodes;
    }
    public void setPatentClassCodes(Set<PatentClassCode> patentClassCodes) {
        this.patentClassCodes = patentClassCodes;
    }

    public Set<PatentClassCodeAppend> getPatentClassCodeAppends() {
        return patentClassCodeAppends;
    }
    public void setPatentClassCodeAppends(Set<PatentClassCodeAppend> patentClassCodeAppends) {
        this.patentClassCodeAppends = patentClassCodeAppends;
    }

    public Set<PatentPriority> getPatentPrioritys() {
        return patentPrioritys;
    }
    public void setPatentPrioritys(Set<PatentPriority> patentPrioritys) {
        this.patentPrioritys = patentPrioritys;
    }

    public List<Inventor> getInventors() {
        return inventors;
    }
    public void setInventors(List<Inventor> inventors) {
        this.inventors = inventors;
    }

    public List<Assignee> getAssignees() {
        return assignees;
    }
    public void setAssignees(List<Assignee> assignees) {
        this.assignees = assignees;
    }

    public List<Assignee> getCurrentAssignees() {
        return currentAssignees;
    }
    public void setCurrentAssignees(List<Assignee> currentAssignees) {
        this.currentAssignees = currentAssignees;
    }

    public List<ForeignAppPriorityData> getForeignAppPriorityDatas() {
        return foreignAppPriorityDatas;
    }
    public void setForeignAppPriorityDatas(List<ForeignAppPriorityData> foreignAppPriorityDatas) {
        this.foreignAppPriorityDatas = foreignAppPriorityDatas;
    }

    public List<RefPatent> getRefPatents() {
        return refPatents;
    }
    public void setRefPatents(List<RefPatent> referencePatents) {
        this.refPatents = referencePatents;
    }

    public List<RefByPatent> getRefByPatents() {
        return refByPatents;
    }
    public void setRefByPatents(List<RefByPatent> referencedByPatents) {
        this.refByPatents = referencedByPatents;
    }

    public List<RefOtherDoc> getRefOtherDocs() {
        return refOtherDocs;
    }
    public void setRefOtherDocs(List<RefOtherDoc> referenceOtherDocuments) {
        this.refOtherDocs = referenceOtherDocuments;
    }

    public String getCurrentAssigneeStr() {
        return currentAssigneeStr;
    }
    public void setCurrentAssigneeStr(String currentAssigneeStr) {
        this.currentAssigneeStr = currentAssigneeStr;
    }
}
