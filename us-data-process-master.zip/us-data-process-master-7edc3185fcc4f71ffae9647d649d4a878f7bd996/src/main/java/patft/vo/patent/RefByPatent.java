package patft.vo.patent;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class RefByPatent implements Serializable {
    private static final long serialVersionUID = 1865599064464775621L;

    private String refby;
    private String countryCode;
    private String kindCode;
    
    public String getRefby() {
        return refby;
    }
    public void setRefby(String refby) {
        this.refby = refby;
    }
    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    public String getKindCode() {
        return kindCode;
    }
    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }
    
    public boolean equals(Object target) {
        if (target instanceof RefByPatent) {
            RefByPatent t = (RefByPatent) target;
            return new EqualsBuilder().append(this.refby, t.refby)
                .append(this.countryCode, t.countryCode)
                .append(this.kindCode, t.kindCode)
                .isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.refby)
            .append(this.countryCode)
            .append(this.kindCode)
            .toHashCode();
    }
    
}
