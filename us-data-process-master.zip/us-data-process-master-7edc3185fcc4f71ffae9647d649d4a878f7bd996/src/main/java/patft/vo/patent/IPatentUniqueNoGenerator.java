package patft.vo.patent;

public interface IPatentUniqueNoGenerator {
    String generateUniqueNo();
}
