package patft.vo.patent;

public class PatentJsonInfo extends AbstractPatent {
    private static final long serialVersionUID = 8262495668656232953L;

    private String poPatentJson;
    private String patentInfoJson;

    public String getPoPatentJson() {
        return poPatentJson;
    }
    public void setPoPatentJson(String poPatentJson) {
        this.poPatentJson = poPatentJson;
    }

    public String getPatentInfoJson() {
        return patentInfoJson;
    }
    public void setPatentInfoJson(String patentInfoJson) {
        this.patentInfoJson = patentInfoJson;
    }
}
