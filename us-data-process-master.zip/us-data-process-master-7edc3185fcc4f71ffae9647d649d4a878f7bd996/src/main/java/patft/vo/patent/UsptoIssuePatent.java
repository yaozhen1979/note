package patft.vo.patent;

public class UsptoIssuePatent extends UsptoPatent {
    private static final long serialVersionUID = -7362361367439458998L;

//    public static final int CODE = UsPatentConstant.PATENT_CODE_USPTO_ISSUE;
    public static final String SOURCE_TYPE = PoConstant.SOURCE_TYPE_USPTO_ISSUE;

//    @Override
//    public Integer getCode() {
//        return CODE;
//    }

    @Override
    public String getSourceType() {
        return SOURCE_TYPE;
    }
}
