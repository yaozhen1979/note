package patft.vo.patent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public abstract class PatentSource implements Serializable {
    private static final long serialVersionUID = -4249723759998443508L;

    private static String uspto = "USPTO";
    private static String epo = "EPO";
    private static String sipo = "SIPO";
    private static String tipo = "TIPO";

    private static String inhouse = "INHOUSE";

    private static String number = "NUMBER";
    private static String family = "FAMILY";

    private static Map<String, PatentSource> patentSourceMap = new HashMap<String, PatentSource>();

    private String patentSource;


    private PatentSource(String patentSource) {
        this.patentSource = patentSource;
        patentSourceMap.put(patentSource, this);
    }

    public String getAlias() {
        return patentSource;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        PatentSource object = (PatentSource) obj;
        EqualsBuilder eb = new EqualsBuilder();
        eb.append(this.patentSource, object.patentSource);
        return eb.isEquals();
    }

    @Override
    public int hashCode() {
        HashCodeBuilder hcb = new HashCodeBuilder();
        hcb.append(this.patentSource);
        return hcb.toHashCode();
    }

    @Override
    public String toString() {
        return this.patentSource;
    }

    /**
     * @param patentSource
     * @return PatentSource
     */
    public static PatentSource getPatentSource(String patentSource) {
        return patentSourceMap.get(patentSource);
    }

    public static final PatentSource USPTO = new PatentSource(uspto) {
        private static final long serialVersionUID = 2058590390854470845L;
    };

    public static final PatentSource EPO = new PatentSource(epo) {
        private static final long serialVersionUID = 239221178112501113L;
    };

    public static final PatentSource SIPO = new PatentSource(sipo) {
        private static final long serialVersionUID = -4061693024807491907L;
    };

    public static final PatentSource TIPO = new PatentSource(tipo) {
        private static final long serialVersionUID = 7970538270240066345L;
    };

    public static final PatentSource INHOUSE = new PatentSource(inhouse) {
        private static final long serialVersionUID = -2615197561833271793L;
    };

    public static final PatentSource NUMBER = new PatentSource(number) {
        private static final long serialVersionUID = 7433240435293255873L;
    };

    public static final PatentSource FAMILY = new PatentSource(family) {
        private static final long serialVersionUID = 6971550307606675411L;
    };
}
