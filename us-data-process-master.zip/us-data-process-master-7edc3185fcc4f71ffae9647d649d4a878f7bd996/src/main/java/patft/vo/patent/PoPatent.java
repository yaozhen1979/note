package patft.vo.patent;

import java.io.Serializable;
import java.util.Date;

import patft.util.DateUtil;

public abstract class PoPatent implements Serializable {
    private static final long serialVersionUID = -2612149461601726395L;

    private Long patentId;
    private String uniqueNo;
    private Long kangarooPatentId;
    private String patentCloudId;
    private String patentCloudPto;

    private String fullPatentNo;
    private String countryCode;
    private String patentNo;

    private String issueNo;
    private String publicationNo;
    private String applicationNo;
    private String rawAppNo;
    private String epoAppNo;
    private String kindCode;

    private Date issueDate;
    private Date publicationDate;
    private Date applicationDate;
    private Integer patentYear;
    private Integer appYear;

    private String title;
    private Integer applicationType;
    private String state;
    private String status;
    private String statusDesc;
    private Date statusDate;
    private Date expiredDate;
    private String feeStatus;
    private String familyId;

    private String patentOffice;
    private Date createdDate;

    private Long patIdenId;
    private Integer patIdenSeq;

//    public abstract Integer getCode();
//    public abstract void setCode(Integer code);

    public abstract String getSourceType();
    public abstract void setSourceType(String sourceType);

    public abstract Integer getSource();

    public Long getPatentId() {
        return patentId;
    }
    public void setPatentId(Long patentId) {
        this.patentId = patentId;
    }

    public String getUniqueNo() {
        return uniqueNo;
    }
    public void setUniqueNo(String uniqueNo) {
        this.uniqueNo = uniqueNo;
    }

    public Long getKangarooPatentId() {
        return kangarooPatentId;
    }
    public void setKangarooPatentId(Long kangarooPatentId) {
        this.kangarooPatentId = kangarooPatentId;
    }

    public String getPatentCloudId() {
        return patentCloudId;
    }
    public void setPatentCloudId(String patentCloudId) {
        this.patentCloudId = patentCloudId;
    }

    public String getPatentCloudPto() {
        return patentCloudPto;
    }
    public void setPatentCloudPto(String patentCloudPto) {
        this.patentCloudPto = patentCloudPto;
    }

    public String getFullPatentNo() {
        if (fullPatentNo == null) {
            String no = patentNo;
            if (no == null) {
                no = issueNo;
            }
            if (no == null) {
                no = publicationNo;
            }
            if (countryCode == null) {
                return no;
            } else {
                fullPatentNo = countryCode + no;
            }
        }
        return fullPatentNo;
    }

    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPatentNo() {
        return patentNo;
    }
    public void setPatentNo(String patentNo) {
        this.patentNo = patentNo;
    }

    public String getIssueNo() {
        return issueNo;
    }
    public void setIssueNo(String issueNo) {
        this.issueNo = issueNo;
    }

    public String getPublicationNo() {
        return publicationNo;
    }
    public void setPublicationNo(String publicationNo) {
        this.publicationNo = publicationNo;
    }

    public String getApplicationNo() {
        return applicationNo;
    }
    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getRawAppNo() {
        return rawAppNo;
    }
    public void setRawAppNo(String rawAppNo) {
        this.rawAppNo = rawAppNo;
    }

    public String getEpoAppNo() {
        return epoAppNo;
    }
    public void setEpoAppNo(String epoAppNo) {
        this.epoAppNo = epoAppNo;
    }

    public String getKindCode() {
        return kindCode;
    }
    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public Date getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
        initPatentYear();
    }

    public Date getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
        initPatentYear();
    }

    public Date getApplicationDate() {
        return applicationDate;
    }
    public void setApplicationDate(Date applicationDate) {
        this.applicationDate = applicationDate;
        this.appYear = DateUtil.getYearInteger(applicationDate);
    }

    public Integer getPatentYear() {
        return patentYear;
    }
    public void setPatentYear(Integer patentYear) {
        this.patentYear = patentYear;
    }
    private void initPatentYear() {
        if (this.issueDate != null) {
            this.patentYear = DateUtil.getYearInteger(issueDate);
        } else if (this.publicationDate != null) {
            this.patentYear = DateUtil.getYearInteger(publicationDate);
        }
    }

    public Integer getAppYear() {
        return appYear;
    }
    public void setAppYear(Integer appYear) {
        this.appYear = appYear;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getApplicationType() {
        return applicationType;
    }
    public void setApplicationType(Integer applicationType) {
        this.applicationType = applicationType;
    }

    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusDesc() {
        return statusDesc;
    }
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public Date getStatusDate() {
        return statusDate;
    }
    public void setStatusDate(Date statusDate) {
        this.statusDate = statusDate;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }
    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public String getFeeStatus() {
        return feeStatus;
    }
    public void setFeeStatus(String feeStatus) {
        this.feeStatus = feeStatus;
    }

    public String getFamilyId() {
        return familyId;
    }
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    public String getPatentOffice() {
        return patentOffice;
    }
    public void setPatentOffice(String patentOffice) {
        this.patentOffice = patentOffice;
    }

    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getPatIdenId() {
        return patIdenId;
    }
    public void setPatIdenId(Long patIdenId) {
        this.patIdenId = patIdenId;
    }

    public Integer getPatIdenSeq() {
        return patIdenSeq;
    }
    public void setPatIdenSeq(Integer patIdenSeq) {
        this.patIdenSeq = patIdenSeq;
    }
}
