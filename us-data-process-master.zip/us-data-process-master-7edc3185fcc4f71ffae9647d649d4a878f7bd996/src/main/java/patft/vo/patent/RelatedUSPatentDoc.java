package patft.vo.patent;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * 某個 uspto issued patent 在 uspto 網站所列出的的 Related U.S. Patent
 * Documents <a
 * href="http://patft.uspto.gov/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=/netahtml/search-bool.html&r=12&f=G&l=50&co1=AND&d=ptxt&s1=re38$.WKU.&OS=PN/re38$&RS=PN/re38$">
 * 請參考 </a>
 */
public class RelatedUSPatentDoc implements Serializable {
    private static final long serialVersionUID = 3170302366513748108L;

    private String reissue;
    private String patentNo;
    private String applicationNo;
    private Date filingDate;
    private Date issueDate;

    public String getReissue() {
        return reissue;
    }

    public void setReissue(String reissue) {
        this.reissue = reissue;
    }

    /**
     * @return Returns the applicationNo.
     */
    public String getApplicationNo() {
        return applicationNo;
    }

    /**
     * @param applicationNo The applicationNo to set.
     */
    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    /**
     * @return Returns the field.
     */
    public Date getFilingDate() {
        return filingDate;
    }

    /**
     * @param field The field to set.
     */
    public void setFilingDate(Date filingDate) {
        this.filingDate = filingDate;
    }

    /**
     * @return Returns the issueDate.
     */
    public Date getIssueDate() {
        return issueDate;
    }

    /**
     * @param issueDate The issueDate to set.
     */
    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    /**
     * @return Returns the patentNo.
     */
    public String getPatentNo() {
        return patentNo;
    }

    /**
     * @param patentNo The patentNo to set.
     */
    public void setPatentNo(String no) {
        this.patentNo = no;
    }

    public boolean equals(Object target) {
        if (target instanceof RelatedUSPatentDoc) {
            RelatedUSPatentDoc t = (RelatedUSPatentDoc) target;
            return new EqualsBuilder().append(this.filingDate, t.filingDate)
                .append(this.patentNo, t.patentNo)
                .append(this.applicationNo, t.applicationNo)
                .append(this.issueDate, t.issueDate)
                .isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.patentNo)
            .append(this.applicationNo)
            .append(this.issueDate)
            .append(this.filingDate)
            .toHashCode();
    }
}
