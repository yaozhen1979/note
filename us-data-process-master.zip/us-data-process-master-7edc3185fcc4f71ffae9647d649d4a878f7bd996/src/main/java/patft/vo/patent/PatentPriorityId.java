package patft.vo.patent;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class PatentPriorityId implements Serializable {
    private static final long serialVersionUID = -2837225181852660940L;

    private String countryCode;
    private String patentNo;
    private String prioCountryCode;
    private String prioPatentNo;

    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPatentNo() {
        return patentNo;
    }
    public void setPatentNo(String patentNo) {
        this.patentNo = patentNo;
    }

    public String getPrioCountryCode() {
        return prioCountryCode;
    }
    public void setPrioCountryCode(String prioCountryCode) {
        this.prioCountryCode = prioCountryCode;
    }

    public String getPrioPatentNo() {
        return prioPatentNo;
    }
    public void setPrioPatentNo(String prioPatentNo) {
        this.prioPatentNo = prioPatentNo;
    }

    public String getPrioFullPatentNo() {
        if (prioCountryCode == null) {
            return prioPatentNo;
        } else if (prioPatentNo == null) {
            return prioCountryCode;
        } else {
            return prioCountryCode + prioPatentNo;
        }
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof PatentPriorityId)) {
            return false;
        }
        PatentPriorityId o = (PatentPriorityId) obj;
        return new EqualsBuilder()
            .append(this.countryCode, o.getCountryCode())
            .append(this.patentNo, o.getPatentNo())
            .append(this.prioCountryCode, o.getPrioCountryCode())
            .append(this.prioPatentNo, o.getPrioPatentNo())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(this.countryCode)
            .append(this.patentNo)
            .append(this.prioCountryCode)
            .append(this.prioPatentNo)
            .toHashCode();
    }
}
