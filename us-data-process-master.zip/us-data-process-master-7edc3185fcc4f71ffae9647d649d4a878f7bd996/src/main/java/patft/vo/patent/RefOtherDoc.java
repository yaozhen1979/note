package patft.vo.patent;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * USPTO patent 中 "Other Reference" 的 entity
 * 我們把一個 Other Reference 當作一篇論文看待.
 */
public class RefOtherDoc implements Serializable {
    private static final long serialVersionUID = 911925718630321206L;

//    private static final DocumentBrief UNCHECKED_BTIEF = new DocumentBrief(false, false);

    private String description;
//    private DocumentBrief documentBrief = UNCHECKED_BTIEF;

    public RefOtherDoc() {
    }

//    /**
//     * @return 一個代表論文的物件
//     */
//    public DocumentBrief getDocumentBrief() {
//        return documentBrief;
//    }

//    /**
//     * @param documentBrief 一個代表論文的物件
//     */
//    public void setDocumentBrief(DocumentBrief documentBrief) {
//        this.documentBrief = documentBrief;
//    }

    /**
     * @return uspto "other references" 傳入的描述
     */
    public String getDescription() {
        return description;
    }

    private void setDescription(String desc) {
        this.description = desc;
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return this.description;
    }

    /**
     * Constructor. 傳入 uspto "other references" 傳入的描述
     * @param description  description from uspto
     */
    public RefOtherDoc(String description) {
        super();
        this.description = description;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object target) {
        if (target instanceof RefOtherDoc) {
            RefOtherDoc t = (RefOtherDoc) target;
//            return new EqualsBuilder().append(this.description, t.description)
//                    .append(this.documentBrief, t.documentBrief).isEquals();
            return new EqualsBuilder().append(this.description, t.description).isEquals();
        } else {
            return false;
        }
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
//        return new HashCodeBuilder().append(this.description).append(
//            this.documentBrief).toHashCode();
        return new HashCodeBuilder().append(this.description).toHashCode();
    }

//    /**
//     * @return 作者
//     */
//    public String getAuthors() {
//        return documentBrief.getAuthors();
//    }
//
//    /**
//     * @return 期刊名稱
//     */
//    public String getJournalName() {
//        return documentBrief.getJournalName();
//    }
//
//    /**
//     * @return 論文的 URL
//     */
//    public String getLink() {
//        return documentBrief.getLink();
//    }
//
//
//    /**
//     * @return 標題
//     */
//    public String getTitle() {
//        return documentBrief.getTitle();
//    }
//
//    /**
//     * @return 該筆論文的年份
//     */
//    public String getYear() {
//        return documentBrief.getYear();
//    }
//
//    /**
//     * @return 是否有在 internet 上面找過
//     */
//    public boolean isChecked() {
//        return documentBrief.isChecked();
//    }
//
//    /**
//     * @return 是否有在 internet 上面找到
//     */
//    public boolean isFound() {
//        return documentBrief.isFound();
//    }
//
//    public String getGoogleScholarUrl() {
//        String urlPrefix = "http://scholar.google.com/scholar?hl=en&btnG=Search&as_sdt=1%2C5&as_sdtp=on&q=";
//        if (description == null) {
//            return null;
//        }
//        String title = StringUtils.substringBetween(description.trim(), "\"", "\"");
//        if (title != null && title.length() > 0) {
//            return urlPrefix + title.replaceAll(" ", "+");
//        } else {
//            return urlPrefix + description.trim().replaceAll(" ", "+");
//        }
//    }
}
