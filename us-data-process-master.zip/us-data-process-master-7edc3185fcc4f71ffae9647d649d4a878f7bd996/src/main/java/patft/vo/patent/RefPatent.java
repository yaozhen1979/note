package patft.vo.patent;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class RefPatent implements Serializable {
    private static final long serialVersionUID = 1204695045393178377L;

    private String patentNo;
    private String dateOfPatent;
    private String primaryInventor;
    private String countryCode;
    private String kindCode;
    
    public String getKindCode() {
        return kindCode;
    }

    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getDateOfPatent() {
        return dateOfPatent;
    }

    public void setDateOfPatent(String dateOfPatent) {
        this.dateOfPatent = dateOfPatent;
    }

    public String getPatentNo() {
        return patentNo;
    }

    public void setPatentNo(String patentNo) {
        this.patentNo = patentNo;
    }

    public String getPrimaryInventor() {
        return primaryInventor;
    }

    public void setPrimaryInventor(String primaryInventor) {
        this.primaryInventor = primaryInventor;
    }

    public boolean equals(Object target) {
        if (target instanceof RefPatent) {
            RefPatent t = (RefPatent) target;
            return new EqualsBuilder().append(this.patentNo, t.patentNo)
                .append(this.dateOfPatent, t.dateOfPatent)
                .append(this.primaryInventor, t.primaryInventor)
                .append(this.countryCode, t.countryCode)
                .append(this.kindCode, t.kindCode)
                .isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.patentNo)
            .append(this.dateOfPatent)
            .append(this.primaryInventor)
            .append(this.countryCode)
            .append(this.kindCode)
            .toHashCode();
    }
}
