package patft.vo.patent;

public abstract class PoConstant extends PatentConstant {

    //USPTO
    public static final String PATENT_OFFICE_USPTO = PatentSource.USPTO.toString();

    //EPO
    public static final String PATENT_OFFICE_EPO = PatentSource.EPO.toString();

    //SIPO
    public static final String PATENT_OFFICE_SIPO = PatentSource.SIPO.toString();

    //TIPO
    public static final String PATENT_OFFICE_TIPO = PatentSource.TIPO.toString();
}
