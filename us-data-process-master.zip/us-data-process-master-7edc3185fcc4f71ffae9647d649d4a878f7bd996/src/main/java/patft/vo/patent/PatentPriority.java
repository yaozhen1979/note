package patft.vo.patent;

import java.io.Serializable;
import java.util.Date;

public class PatentPriority implements Serializable {
    private static final long serialVersionUID = -6645146957882733250L;

    private PatentPriorityId id;

    private String kindCode;
    private Long patentId;
    private String prioKindCode;
    private Date prioDate;

    private Date createdDate;
    private Date modifiedDate;

    public PatentPriorityId getId() {
        return id;
    }
    public void setId(PatentPriorityId id) {
        this.id = id;
    }

    public String getKindCode() {
        return kindCode;
    }
    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public Long getPatentId() {
        return patentId;
    }
    public void setPatentId(Long patentId) {
        this.patentId = patentId;
    }

    public String getPrioKindCode() {
        return prioKindCode;
    }
    public void setPrioKindCode(String prioKindCode) {
        this.prioKindCode = prioKindCode;
    }

    public Date getPrioDate() {
        return prioDate;
    }
    public void setPrioDate(Date prioDate) {
        this.prioDate = prioDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getPrioFullPatentNo() {
        if (id != null) {
            return id.getPrioFullPatentNo();
        } else {
            return null;
        }
    }
}
