package patft.vo.patent;

import java.util.Date;

public abstract class AbstractPatent extends AbstractPatentInfo implements IPatent {
    private static final long serialVersionUID = -4248943881118011897L;

    private String id;

    private String pto;
    private String patentCloudId;
    private String ptopid;
    private String appNumberGroup;
    private String familyIdGroup;

    private Integer source = SOURCE_MONGODB;
    private int updateFlag = UPDATE_FLAG_ADD;

    private String patAppId;
    private Integer patAppIdSeq;
    private String uniqueNo;
    private String sourceType = SOURCE_TYPE_PATENTCLOUD;

    private Date createdDateTime;
    private Date modifiedDateTime;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getPto() {
        return pto;
    }
    public void setPto(String pto) {
        this.pto = pto;
    }

    public String getPatentCloudId() {
        return patentCloudId;
    }
    public void setPatentCloudId(String patentCloudId) {
        this.patentCloudId = patentCloudId;
    }

    public String getPtopid() {
        return ptopid;
    }
    public void setPtopid(String ptopid) {
        this.ptopid = ptopid;
    }
    public String getAppNumberGroup() {
        return appNumberGroup;
    }
    public void setAppNumberGroup(String appNumberGroup) {
        this.appNumberGroup = appNumberGroup;
    }

    public String getFamilyIdGroup() {
        return familyIdGroup;
    }
    public void setFamilyIdGroup(String familyIdGroup) {
        this.familyIdGroup = familyIdGroup;
    }

    public Integer getSource() {
        return source;
    }
    public void setSource(Integer source) {
        this.source = source;
    }

    public int getUpdateFlag() {
        return updateFlag;
    }
    public void setUpdateFlag(int updateFlag) {
        this.updateFlag = updateFlag;
    }

    public String getPatAppId() {
        return patAppId;
    }
    public void setPatAppId(String patAppId) {
        this.patAppId = patAppId;
    }

    public Integer getPatAppIdSeq() {
        return patAppIdSeq;
    }
    public void setPatAppIdSeq(Integer patAppIdSeq) {
        this.patAppIdSeq = patAppIdSeq;
    }

    public String getUniqueNo() {
        return uniqueNo;
    }
    public void setUniqueNo(String uniqueNo) {
        this.uniqueNo = uniqueNo;
    }

    public String getSourceType() {
        return sourceType;
    }
    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public Date getModifiedDateTime() {
        return modifiedDateTime;
    }
    public void setModifiedDateTime(Date modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }
    
    public String getPtoPid() {
        return pto + "." + patentCloudId;
    }
    
}
