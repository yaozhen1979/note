package patft.vo.patent;

public class UsptoPublicationPatent extends UsptoPatent {
    private static final long serialVersionUID = 3290352316281840788L;
    //    public static final int CODE = UsPatentConstant.PATENT_CODE_USPTO_PUBLICATION;
    public static final String SOURCE_TYPE = PoConstant.SOURCE_TYPE_USPTO_PUBLICATION;

//    @Override
//    public Integer getCode() {
//        return CODE;
//    }
    @Override
    public String getSourceType() {
        return SOURCE_TYPE;
    }
}
