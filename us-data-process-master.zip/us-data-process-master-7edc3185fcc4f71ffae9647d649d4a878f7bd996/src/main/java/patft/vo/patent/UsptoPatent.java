package patft.vo.patent;

import java.util.List;

public abstract class UsptoPatent extends PoPatentInfo implements IPatentUniqueNoGenerator {
    private static final long serialVersionUID = -6986504827251018358L;

    public static final String PATENT_OFFICE = PoConstant.PATENT_OFFICE_USPTO;
    public static final Integer SOURCE = PoConstant.SOURCE_USPTO;

    private List<RelatedUSPatentDoc> relatedUSPatentDocs;

    @Override
    public String getPatentOffice() {
        return PATENT_OFFICE;
    }

    @Override
    public Integer getSource() {
        return SOURCE;
    }

    public List<RelatedUSPatentDoc> getRelatedUSPatentDocs() {
        return relatedUSPatentDocs;
    }
    public void setRelatedUSPatentDocs(List<RelatedUSPatentDoc> relatedUSPatentDocs) {
        this.relatedUSPatentDocs = relatedUSPatentDocs;
    }

    @Override
    public String generateUniqueNo() {
        StringBuffer uniqueNo = new StringBuffer();

        String countryCode = super.getCountryCode();
        String applicationNo = super.getApplicationNo();
        Integer appYear = super.getAppYear();

        if (applicationNo != null) {
            applicationNo = applicationNo.replaceAll("[\\/\\,]", "");
            if (applicationNo.length() == 7) {
                if (applicationNo.startsWith("D")) {
                    applicationNo = applicationNo.replaceFirst("D", "29");
                }
            }
        }

        if (appYear != null && appYear.intValue() > 1000 && applicationNo != null && applicationNo.length() == 8) {
            uniqueNo.append(countryCode);
            uniqueNo.append(String.format("%04d", appYear.intValue()));
            uniqueNo.append(applicationNo);
        } else if (super.getEpoAppNo() != null) {
            String epoAppNo = super.getEpoAppNo();
            if (epoAppNo.length() == 12) {
                uniqueNo.append(countryCode);
                uniqueNo.append(epoAppNo);
            } else if (epoAppNo.length() == 11) {
                uniqueNo.append(countryCode);
                uniqueNo.append(epoAppNo.substring(0, 4));
                uniqueNo.append("00");
                uniqueNo.append(epoAppNo.substring(epoAppNo.length() - 6));
            }
        } else {
            uniqueNo.append(countryCode);
            uniqueNo.append("_");
            uniqueNo.append(super.getPatentNo());
        }

        return uniqueNo.toString();
    }
}
