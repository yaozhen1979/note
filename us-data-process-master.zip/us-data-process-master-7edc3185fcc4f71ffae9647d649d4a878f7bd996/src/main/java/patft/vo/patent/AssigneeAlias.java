package patft.vo.patent;

// Generated 2014/6/5 �W�� 09:22:03 by Hibernate Tools 3.4.0.CR1

import java.util.Date;

public class AssigneeAlias implements java.io.Serializable {
    private static final long serialVersionUID = 4420031168682863345L;

    private String id;

    private String alias;

    private Date createdDateTime;

    private Date modifiedDateTime;

    private String creatorId;

    private String modifierId;

    private String isManual;

    private String scopeId;

    public AssigneeAlias() {
    }

    public AssigneeAlias(String id, String isManual) {
        this.id = id;
        this.isManual = isManual;
    }

    public AssigneeAlias(String id, String alias, Date createdDateTime, Date modifiedDateTime, String creatorId,
            String modifierId, String isManual, String scopeId) {
        this.id = id;
        this.alias = alias;
        this.createdDateTime = createdDateTime;
        this.modifiedDateTime = modifiedDateTime;
        this.creatorId = creatorId;
        this.modifierId = modifierId;
        this.isManual = isManual;
        this.scopeId = scopeId;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAlias() {
        return this.alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Date getCreatedDateTime() {
        return this.createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public Date getModifiedDateTime() {
        return this.modifiedDateTime;
    }

    public void setModifiedDateTime(Date modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }

    public String getCreatorId() {
        return this.creatorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }

    public String getModifierId() {
        return this.modifierId;
    }

    public void setModifierId(String modifierId) {
        this.modifierId = modifierId;
    }

    public String getIsManual() {
        return this.isManual;
    }

    public void setIsManual(String isManual) {
        this.isManual = isManual;
    }

    public String getScopeId() {
        return this.scopeId;
    }

    public void setScopeId(String scopeId) {
        this.scopeId = scopeId;
    }

}
