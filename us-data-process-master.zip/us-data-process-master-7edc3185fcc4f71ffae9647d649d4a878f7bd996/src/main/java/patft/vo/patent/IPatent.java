package patft.vo.patent;

public interface IPatent {

    int UPDATE_FLAG_ADD = 0;        //剛加入
    int UPDATE_FLAG_TO_UPDATE = 1;  //待更新
    int UPDATE_FLAG_UPDATED = 2;    //已更新
    int UPDATE_FLAG_PTO = 3;        //官網
    int UPDATE_FLAG_DELETE = 4;     //已刪除
    int UPDATE_FLAG_CONFIRM = 5;    //判讀後應該要存在

    int SOURCE_MONGODB = 0;
    int SOURCE_USPTO = 1;
    int SOURCE_EPO = 2;
    int SOURCE_SIPO = 3;
    int SOURCE_TIPO = 4;

    String SOURCE_TYPE_PATENTCLOUD = "PC";
    String SOURCE_TYPE_USPTO_ISSUE = "USPTO_PAT";
    String SOURCE_TYPE_USPTO_PUBLICATION = "USPTO_APP";
    String SOURCE_TYPE_EPO = "EPO";
    String SOURCE_TYPE_SIPO = "SIPO";
    String SOURCE_TYPE_TIPO = "TIPO";

    String APPID_PREFIX_PATENTOFFICE = "PO";
    String APPID_PREFIX_PATENTCLOUD = "PC";

    String PATENT_STATE_ISSUE = "I";
    String PATENT_STATE_PUBLICATION = "P";

    //for patentcloud patentinfo2
    Integer PUBLICATION = new Integer(1);
    Integer ISSUED = new Integer(2);

}
