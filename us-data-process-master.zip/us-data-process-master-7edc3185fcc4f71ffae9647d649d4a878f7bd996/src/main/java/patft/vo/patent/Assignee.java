package patft.vo.patent;

// Generated 2014/6/5 �W�� 09:22:03 by Hibernate Tools 3.4.0.CR1

public class Assignee implements java.io.Serializable {
    private static final long serialVersionUID = 8822134086732961827L;

    private String id;

    private String name;

    private String address;

    private String country;
    
    private String state;

    private String patentAssigneeId;

    private String dummyPatentId;

    private AssigneeAlias assigneeAlias;

    private String dummyCurAssPatId;

    public Assignee() {
    }

    public Assignee(String id) {
        this.id = id;
    }

    public Assignee(String id, String name, String address, String country, String patentAssigneeId,
            String dummyPatentId) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.country = country;
        this.patentAssigneeId = patentAssigneeId;
        this.dummyPatentId = dummyPatentId;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPatentAssigneeId() {
        return this.patentAssigneeId;
    }

    public void setPatentAssigneeId(String patentAssigneeId) {
        this.patentAssigneeId = patentAssigneeId;
    }

    public String getDummyPatentId() {
        return this.dummyPatentId;
    }

    public void setDummyPatentId(String dummyPatentId) {
        this.dummyPatentId = dummyPatentId;
    }

    public AssigneeAlias getAssigneeAlias() {
        return assigneeAlias;
    }

    public void setAssigneeAlias(AssigneeAlias assigneeAlias) {
        this.assigneeAlias = assigneeAlias;
    }

    public String getDummyCurAssPatId() {
        return dummyCurAssPatId;
    }

    public void setDummyCurAssPatId(String dummyCurAssPatId) {
        this.dummyCurAssPatId = dummyCurAssPatId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}
