package patft.vo.patent;

import java.util.Arrays;
import java.util.List;

public abstract class PatentConstant implements IPatent {

    public static final List<Integer> VALID_PATENT_FLAG = Arrays.asList(new Integer[] {
            UPDATE_FLAG_ADD,
            UPDATE_FLAG_TO_UPDATE,
            UPDATE_FLAG_UPDATED,
            UPDATE_FLAG_PTO,
            UPDATE_FLAG_CONFIRM});

    public static final int PATENT_APP_TYPE_UTILITY = 1;
    public static final int PATENT_APP_TYPE_REISSUE = 2;
    public static final int PATENT_APP_TYPE_DESIGN = 4;
    public static final int PATENT_APP_TYPE_DEFENSIVE_PUBLICATION = 5;
    public static final int PATENT_APP_TYPE_PLANT = 6;
    public static final int PATENT_APP_TYPE_STATUTORY_INVENTION_REGISTRATION = 7;
    public static final int PATENT_APP_TYPE_MODEL = 8;
}
