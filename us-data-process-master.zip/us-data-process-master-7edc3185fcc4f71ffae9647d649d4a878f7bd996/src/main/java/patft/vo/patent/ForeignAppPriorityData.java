package patft.vo.patent;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 *  某個 Uspto Published Applications 在 uspto 網站所列出的的 Foreign Application Data
 *  <a href="http://appft1.uspto.gov/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-bool.html&r=22&f=G&l=50&co1=AND&d=PG01&s1=lcd&OS=lcd&RS=lcd">
 *  請參考
 *  </a>
 **/
public class ForeignAppPriorityData implements Serializable {
    private static final long serialVersionUID = -4074554528295193376L;

    private Date date;
    private String countryCode;
    private String applicationNo;

    /**
     * @param date
     * @param code
     * @param applicationNo
     */
    public ForeignAppPriorityData(Date date, String countryCode, String applicationNo) {
        super();
        this.date = date;
        this.countryCode = countryCode;
        this.applicationNo = applicationNo;
    }

    /**
     * 
     */
    public ForeignAppPriorityData() {

        // TODO Auto-generated constructor stub
    }

    /**
     * @return Returns the applicationNo.
     */
    public String getApplicationNo() {
        return applicationNo;
    }

    /**
     * @param applicationNo The applicationNo to set.
     */
    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    /**
     * @return Returns the countryCode.
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * @param countryCode The countryCode to set.
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * @return Returns the date.
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date The date to set.
     */
    public void setDate(Date date) {
        this.date = date;
    }

    public boolean equals(Object target) {
        if (target instanceof ForeignAppPriorityData) {
            ForeignAppPriorityData t = (ForeignAppPriorityData) target;
            return new EqualsBuilder().append(this.getApplicationNo(),
                    t.getApplicationNo()).append(this.getCountryCode(), t.getCountryCode())
                    .append(this.getDate(), t.getDate()).isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.getApplicationNo()).append(
                this.getCountryCode()).append(this.getDate()).toHashCode();
    }
}
