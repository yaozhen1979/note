package patft.vo;

import java.util.LinkedList;
import java.util.List;

public abstract class PatentClassCodeConstant {
    public static final int CLASSIFICATION_IPC = 1;
    public static final int CLASSIFICATION_IPC8 = 2;
    public static final int CLASSIFICATION_LOC = 3;
    public static final int CLASSIFICATION_CPC = 4;

    public static final int CLASSIFICATION_UPC = 10;
    public static final int CLASSIFICATION_UPC_AT_PUBLICATION = 11;

    public static final int CLASSIFICATION_ECLA = 20;
    
    public static final int CLASSIFICATION_DESIGNCODE = 50;
    
    public static final int CLASSIFICATION_FI = 60;
    public static final int CLASSIFICATION_FTERM = 61;
    public static final int CLASSIFICATION_DTERM = 62;


    public static final int CLASS_APPEND = -1000;
    private static List<Integer> classTypeList = new LinkedList<Integer>();

    static {
        classTypeList.add(CLASSIFICATION_IPC);
        classTypeList.add(CLASSIFICATION_IPC8);
        classTypeList.add(CLASSIFICATION_LOC);
        classTypeList.add(CLASSIFICATION_CPC);

        classTypeList.add(CLASSIFICATION_UPC);
        classTypeList.add(CLASSIFICATION_UPC_AT_PUBLICATION);

        classTypeList.add(CLASSIFICATION_ECLA);

        classTypeList.add(CLASSIFICATION_DESIGNCODE);

        classTypeList.add(CLASSIFICATION_FI);
        classTypeList.add(CLASSIFICATION_FTERM);
        classTypeList.add(CLASSIFICATION_DTERM);
    }

    public static List<Integer> getClassTypeList() {
        return classTypeList;
    }
}
