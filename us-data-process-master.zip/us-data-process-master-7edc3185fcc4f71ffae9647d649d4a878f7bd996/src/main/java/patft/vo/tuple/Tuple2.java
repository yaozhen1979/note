package patft.vo.tuple;

import java.io.Serializable;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple2<A, B> implements Serializable, Comparable<Object> {
    private static final long serialVersionUID = 8527201478880205077L;

    public final A col1;
    public final B col2;

    public Tuple2(A a, B b) {
        col1 = a;
        col2 = b;
    }

    public final A getCol1() {
        return col1;
    }

    public final B getCol2() {
        return col2;
    }

    public int compareTo(Object obj) {
        Tuple2 object = (Tuple2) obj;
        return new CompareToBuilder()
                .append(this.col1, object.col1)
                .append(this.col2, object.col2)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple2 object = (Tuple2) obj;
        return new EqualsBuilder()
                .append(this.col1, object.col1)
                .append(this.col2, object.col2)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .append(this.col1)
                .append(this.col2)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .append("col1", this.col1)
                .append("col2", this.col2)
                .toString();
    }
}
