package patft.vo.tuple;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple7<A, B, C, D, E, F, G> extends Tuple6<A, B, C, D, E, F> {
    private static final long serialVersionUID = -733199586935484784L;

    public final G col7;

    public Tuple7(A a, B b, C c, D d, E e, F f, G g) {
        super(a, b, c, d, e, f);
        col7 = g;
    }

    public final G getCol7() {
        return col7;
    }

    public int compareTo(Object obj) {
        Tuple7 object = (Tuple7) obj;
        return new CompareToBuilder()
                .appendSuper(super.compareTo(obj))
                .append(this.col7, object.col7)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple7 object = (Tuple7) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(this.col7, object.col7)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(this.col7)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("col7", this.col7)
                .toString();
    }
}
