package patft.vo.tuple;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple3<A, B, C> extends Tuple2<A, B> {
    private static final long serialVersionUID = 5221070477648922496L;

    public final C col3;

    public Tuple3(A a, B b, C c) {
        super(a, b);
        col3 = c;
    }

    public final C getCol3() {
        return col3;
    }

    public int compareTo(Object obj) {
        Tuple3 object = (Tuple3) obj;
        return new CompareToBuilder()
                .appendSuper(super.compareTo(obj))
                .append(this.col3, object.col3)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple3 object = (Tuple3) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(this.col3, object.col3)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(this.col3)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("col3", this.col3)
                .toString();
    }
}
