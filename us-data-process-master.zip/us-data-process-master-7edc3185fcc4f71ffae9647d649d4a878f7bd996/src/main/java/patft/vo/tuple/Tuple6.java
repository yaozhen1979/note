package patft.vo.tuple;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple6<A, B, C, D, E, F> extends Tuple5<A, B, C, D, E> {
    private static final long serialVersionUID = 2646657394202960229L;

    public final F col6;

    public Tuple6(A a, B b, C c, D d, E e, F f) {
        super(a, b, c, d, e);
        col6 = f;
    }

    public final F getCol6() {
        return col6;
    }

    public int compareTo(Object obj) {
        Tuple6 object = (Tuple6) obj;
        return new CompareToBuilder()
                .appendSuper(super.compareTo(obj))
                .append(this.col6, object.col6)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple6 object = (Tuple6) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(this.col6, object.col6)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(this.col6)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("col6", this.col6)
                .toString();
    }
}
