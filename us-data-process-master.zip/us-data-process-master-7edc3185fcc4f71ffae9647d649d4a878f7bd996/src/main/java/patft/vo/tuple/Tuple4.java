package patft.vo.tuple;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple4<A, B, C, D> extends Tuple3<A, B, C> {
    private static final long serialVersionUID = 1469151484961853024L;

    public final D col4;

    public Tuple4(A a, B b, C c, D d) {
        super(a, b, c);
        col4 = d;
    }

    public final D getCol4() {
        return col4;
    }

    public int compareTo(Object obj) {
        Tuple4 object = (Tuple4) obj;
        return new CompareToBuilder()
                .appendSuper(super.compareTo(obj))
                .append(this.col4, object.col4)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple4 object = (Tuple4) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(this.col4, object.col4)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(this.col4)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("col4", this.col4)
                .toString();
    }
}
