package patft.vo.tuple;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Tuple5<A, B, C, D, E> extends Tuple4<A, B, C, D> {
    private static final long serialVersionUID = 2228004502917070671L;

    public final E col5;

    public Tuple5(A a, B b, C c, D d, E e) {
        super(a, b, c, d);
        col5 = e;
    }

    public final E getCol5() {
        return col5;
    }

    public int compareTo(Object obj) {
        Tuple5 object = (Tuple5) obj;
        return new CompareToBuilder()
                .appendSuper(super.compareTo(obj))
                .append(this.col5, object.col5)
                .toComparison();
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Tuple5 object = (Tuple5) obj;
        return new EqualsBuilder()
                .appendSuper(super.equals(obj))
                .append(this.col5, object.col5)
                .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(this.col5)
                .toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("col5", this.col5)
                .toString();
    }
}
