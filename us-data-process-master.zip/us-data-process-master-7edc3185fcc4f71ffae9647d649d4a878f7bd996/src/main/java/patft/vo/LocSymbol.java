package patft.vo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LocSymbol extends Symbol {
    private static final long serialVersionUID = 6765304789140499287L;

    private static Pattern symbolPattern = Pattern
            .compile("^[D]?([0-9]{2})[-]?([0-9]{2,}).*$"); //[D]? --> for USPTO

    private String rawSymbol;

    public LocSymbol(String symbolClass, String symbolSubclass) {
        super(symbolClass, symbolSubclass, null, null, null);
    }


    public String getRawSymbol() {
        return rawSymbol;
    }
    public String getSymbolClass() {
        return col1;
    }
    public String getSymbolSubclass() {
        return col2;
    }

    public static LocSymbol createSymbol(String rawSymbol) {
        if (rawSymbol == null || rawSymbol.length() == 0) {
            return null;
        }
        rawSymbol = rawSymbol.toUpperCase().trim();
        Matcher matcher = symbolPattern.matcher(rawSymbol);
        if (matcher.matches()) {
            String symbolClass = matcher.group(1);
            String symbolSubclass = matcher.group(2);

            if (symbolSubclass.length() > 2) {
                return null;
            }
            LocSymbol symbol = new LocSymbol(symbolClass, symbolSubclass);
            symbol.rawSymbol = rawSymbol;
            return symbol;
        }
        return null;
    }

    @Override
    protected String generateSymbol(Symbol symbol) {
        if (symbol == null) {
            return null;
        }
        String symbolClass = symbol.col1;
        String symbolSubclass = symbol.col2;

        StringBuffer sb = new StringBuffer();
        if (symbolClass != null && symbolClass.length() > 0 && symbolSubclass != null && symbolSubclass.length() > 0) {
            sb.append(symbolClass);
            sb.append("-");
            sb.append(symbolSubclass);
        }

        if (sb.length() > 0) {
            return sb.toString();
        } else {
            return null;
        }
    }

    @Override
    protected String generateSymbolId(Symbol symbol) {
        return generateSymbol(symbol);
    }
}
