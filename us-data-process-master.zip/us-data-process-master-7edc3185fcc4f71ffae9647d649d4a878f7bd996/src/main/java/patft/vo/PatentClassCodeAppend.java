package patft.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class PatentClassCodeAppend implements Serializable {
    private static final long serialVersionUID = 2099488683375496812L;

    private int type;
    private String classNo;

    public String getClassNo() {
        return classNo;
    }
    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }

    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public boolean equals(Object target) {
        if (target instanceof PatentClassCodeAppend) {
            PatentClassCodeAppend t = (PatentClassCodeAppend) target;
            return new EqualsBuilder().append(this.type, t.type).isEquals();
        } else {
            return false;
        }
    }

    public int hashCode() {
        return new HashCodeBuilder().append(this.type).toHashCode();
    }
}
