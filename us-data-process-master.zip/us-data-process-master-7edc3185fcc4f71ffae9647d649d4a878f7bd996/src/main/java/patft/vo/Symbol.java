package patft.vo;

import patft.vo.tuple.Tuple5;

abstract class Symbol extends Tuple5<String, String, String, String, String> {
    private static final long serialVersionUID = 2796952786163801882L;

    private String symbol;
    private String symbolId;

    protected abstract String generateSymbol(Symbol symbol0);
    protected abstract String generateSymbolId(Symbol symbol0);

    protected Symbol(String col1, String col2, String col3, String col4, String col5) {
        super(col1, col2, col3, col4, col5);
        symbol = generateSymbol(this);
        symbolId = generateSymbolId(this);
    }

    public String getSymbol() {
        return symbol;
    }
    public String getSymbolId() {
        return symbolId;
    }
}
