package patft.vo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EclaSymbol extends AbstractIpcSymbol {
    private static final long serialVersionUID = -7078388724274019993L;

    private static Pattern symbolPattern = Pattern
            .compile("^([A-Z])([0-9]{2})([A-Z])[^A-Z0-9]?([0-9]+)/([0-9]{2,}[A-Z0-9]*).*$");

    private String rawSymbol;

    public EclaSymbol(String symbolSection, String symbolClass, String symbolSubclass, String symbolMaingroup,
            String symbolSubgroup) {
        super(symbolSection, symbolClass, symbolSubclass, symbolMaingroup, symbolSubgroup);
    }


    public String getRawSymbol() {
        return rawSymbol;
    }

    public static EclaSymbol createSymbol(String rawSymbol) {
        if (rawSymbol == null || rawSymbol.length() == 0) {
            return null;
        }
        rawSymbol = rawSymbol.toUpperCase().trim();
        Matcher matcher = symbolPattern.matcher(rawSymbol);
        if (matcher.matches()) {
            String symbolSection = matcher.group(1);
            String symbolClass = matcher.group(2);
            String symbolSubclass = matcher.group(3);
            String symbolMaingroup = matcher.group(4);
            String symbolSubgroup = matcher.group(5);

            symbolMaingroup = new Integer(symbolMaingroup).toString();

            EclaSymbol symbol = new EclaSymbol(symbolSection, symbolClass, symbolSubclass, symbolMaingroup,
                    symbolSubgroup);
            symbol.rawSymbol = rawSymbol;
            return symbol;
        }
        return null;
    }

    @Override
    protected String generateSymbolId(Symbol symbol) {
        if (symbol == null) {
            return null;
        }
        String symbolSection = symbol.col1;
        String symbolClass = symbol.col2;
        String symbolSubclass = symbol.col3;
        String symbolMaingroup = symbol.col4;
        String symbolSubgroup = symbol.col5;

        StringBuffer sb = new StringBuffer();
        if (symbolSection != null && symbolSection.length() > 0) {
            sb.append(symbolSection);
        }
        if (sb.length() > 0 && symbolClass != null && symbolClass.length() > 0) {
            sb.append(symbolClass);
        }
        if (sb.length() > 0 && symbolSubclass != null && symbolSubclass.length() > 0) {
            sb.append(symbolSubclass);
        }
        if (sb.length() > 0 && symbolMaingroup != null && symbolMaingroup.length() > 0 && symbolSubgroup != null && symbolSubgroup.length() > 0) {
            for (int i = 0; i < (4 - symbolMaingroup.length()); i++) {
                sb.append("0");
            }
            sb.append(symbolMaingroup);
            sb.append(symbolSubgroup);
            for (int i = 0; i < (6 - symbolSubgroup.length()); i++) {
                if (i == 0) {
                    sb.append("-");
                } else {
                    sb.append("0");
                }
            }
        }

        if (sb.length() > 0) {
            return sb.toString();
        } else {
            return null;
        }
    }
}
