package patft.vo;

abstract class AbstractIpcSymbol extends Symbol {
    private static final long serialVersionUID = 7946839855781279750L;

    protected AbstractIpcSymbol(String symbolSection, String symbolClass, String symbolSubclass,
            String symbolMaingroup, String symbolSubgroup) {
        super(symbolSection, symbolClass, symbolSubclass, symbolMaingroup, symbolSubgroup);
    }

    public String getSymbolSection() {
        return col1;
    }
    public String getSymbolClass() {
        return col2;
    }
    public String getSymbolSubclass() {
        return col3;
    }
    public String getSymbolMaingroup() {
        return col4;
    }
    public String getSymbolSubgroup() {
        return col5;
    }

    @Override
    protected String generateSymbol(Symbol symbol) {
        if (symbol == null) {
            return null;
        }
        String symbolSection = symbol.col1;
        String symbolClass = symbol.col2;
        String symbolSubclass = symbol.col3;
        String symbolMaingroup = symbol.col4;
        String symbolSubgroup = symbol.col5;

        StringBuffer sb = new StringBuffer();
        if (symbolSection != null && symbolSection.length() > 0) {
            sb.append(symbolSection);
        }
        if (sb.length() > 0 && symbolClass != null && symbolClass.length() > 0) {
            sb.append(symbolClass);
        }
        if (sb.length() > 0 && symbolSubclass != null && symbolSubclass.length() > 0) {
            sb.append(symbolSubclass);
        }
        if (sb.length() > 0 && symbolMaingroup != null && symbolMaingroup.length() > 0 && symbolSubgroup != null && symbolSubgroup.length() > 0) {
            sb.append(" ");
            sb.append(symbolMaingroup);
            sb.append("/");
            sb.append(symbolSubgroup);
        }

        if (sb.length() > 0) {
            return sb.toString();
        } else {
            return null;
        }
    }
}
