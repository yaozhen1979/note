package patft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import patft.vo.patent.UsptoPublicationPatent;

public class AppftParser {

    public static void main(String[] args) throws Exception {
        UsptoAppFTWebTool tool = new UsptoAppFTWebTool();
        
        String html = "\r\n" + 
                "<HTML>\r\n" + 
                "<HEAD>\r\n" + 
                "<STYLE TYPE=\"text/css\">\r\n" + 
                "    PRE { font-family: \"Times New Roman\"; font-size: 12pt; }\r\n" + 
                "</STYLE>\r\n" + 
                "<BASE TARGET=\"_top\">\r\n" + 
                "<TITLE>United States Patent Application: 0020002715</TITLE></HEAD>\r\n" + 
                "<BODY BGCOLOR=\"#FFFFFF\">\r\n" + 
                "<a name=\"top\"></a>\r\n" + 
                "<center>\r\n" + 
                "<IMG SRC=\"/netaicon1/PTO/AppFThdr.gif\">\r\n" + 
                "</center>\r\n" + 
                "<center>\r\n" + 
                "<A HREF=\"/netahtml/PTO/help/help.html\"><IMG BORDER=\"0\" WIDTH=\"63\" HEIGHT=\"24\"  align=middle SRC=\"/netaicon1/PTO/help.gif\" ALT=\"[Help]\"></A>\r\n" + 
                "<a href=\"/netahtml/PTO/index.html\"><img src=\"/netaicon1/PTO/home.gif\" alt=\"[Home]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<a href=\"/netahtml/PTO/search-bool.html\"><img src=\"/netaicon1/PTO/boolean.gif\" alt=\"[Boolean Search]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<A HREF=\"/netahtml/PTO/search-adv.html\"><IMG WIDTH=\"63\" HEIGHT=\"24\" BORDER=\"0\" SRC=\"/netaicon1/PTO/manual.gif\" ALT=\"[Manual]\" align=middle></A>\r\n" + 
                "<a href=\"/netahtml/PTO/srchnum.html\"><img src=\"/netaicon1/PTO/number.gif\" alt=\"[Number Search]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<A HREF=\"http://www.uspto.gov/go/ptdl/\">\r\n" + 
                "<IMG width=63 height=24 border=0 SRC=\"/netaicon1/PTO/ptdl.gif\" ALT=\"[PTDLs]\" align=middle></A>\r\n" + 
                "</center>\r\n" + 
                "<center><A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=15&f=S&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&Query=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/hitlist.gif border=0 ALT=[CURR_LIST]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=2&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=15&f=S&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&Query=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/nextlist.gif border=0 ALT=[NEXT_LIST]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=14&f=G&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&OS=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/prevdoc.gif border=0 ALT=[PREV_DOC]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=16&f=G&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&OS=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/nextdoc.gif border=0 ALT=[NEXT_DOC]></A>\r\n" + 
                "<a href=\"#bottom\"><img src=\"/netaicon1/PTO/bottom.gif\" align=middle border=0></A>\r\n" + 
                "<br><A HREF=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/ShowShoppingCart?backUrl1=http%3A//appft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26p%3D1%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%26r%3D15%26f%3DG%26l%3D50%26d%3DPG01%26S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%26OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002&backLabel1=Back%20to%20Published%20Application%20Number%3A%2020020002715\">\r\n" + 
                "<img border=0 src=\"/netaicon1/PTO/cart.gif\" border=0 alt=\"[Shopping Cart]\"></A>\r\n" + 
                "<A HREF=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/AddToShoppingCart?docNumber=US20020002715&backUrl1=http%3A//appft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26p%3D1%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%26r%3D15%26f%3DG%26l%3D50%26d%3DPG01%26S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%26OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002&backLabel1=Back%20to%20Published%20Application%20Number%3A%2020020002715\">\r\n" + 
                "<img border=0 src=\"/netaicon1/PTO/order.gif\" alt=\"[Order Copy]\"></A>\r\n" + 
                "</center>\r\n" + 
                "<CENTER>\r\n" + 
                "<a href=http://pdfaiw.uspto.gov/.aiw?Docid=20020002715&homeurl=http%3A%2F%2Fappft.uspto.gov%2Fnetacgi%2Fnph-Parser%3FSect1%3DPTO2%2526Sect2%3DHITOFF%2526p%3D1%2526u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%2526r%3D15%2526f%3DG%2526l%3D50%2526d%3DPG01%2526S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%2526OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002%2526RS%3DPD%2F20020101-%3C20020107&PageNum=&Rtype=&SectionNum=&idkey=5ABB28D0C4DD\r\n" + 
                "><img src=\"/netaicon1/PTO/image.gif\" alt=\"[Image]\" border=\"0\" width=\"63\" height=\"24\" align=\"middle\"></A>\r\n" + 
                "</CENTER>\r\n" + 
                "<p>\r\n" + 
                "<TABLE border=0>\r\n" + 
                "<TR><TD VALIGN=TOP ALIGN=LEFT width=40>\r\n" + 
                "&nbsp;\r\n" + 
                "</TD>\r\n" + 
                "<TD VALIGN=TOP ALIGN=LEFT width=40>\r\n" + 
                "&nbsp;\r\n" + 
                "</TD>\r\n" + 
                "<TD VALIGN=TOP ALIGN=RIGHT WIDTH=50>\r\n" + 
                "</TD><TD ALIGN=RIGHT VALIGN=BOTTOM WIDTH=500><FONT SIZE=-1>( <STRONG>15</STRONG></FONT> <FONT SIZE=-2>of</FONT> <STRONG><FONT SIZE=-1>2728</STRONG> )</FONT></TD></TR></TABLE>\r\n" + 
                "<HR>\r\n" + 
                "<TABLE WIDTH=\"100%\">\r\n" + 
                "<TR>    <TD ALIGN=\"LEFT\" WIDTH=\"50%\"><B>United States Patent Application</B></TD>\r\n" + 
                "    <TD ALIGN=\"RIGHT\" WIDTH=\"50%\"><B>20020002715\r\n" + 
                "</B></TD>\r\n" + 
                "</TR>\r\n" + 
                "   <TR><TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"50%\"><B>Kind Code</B>\r\n" + 
                "   </TD><TD ALIGN=\"RIGHT\" WIDTH=\"50%\">\r\n" + 
                "   <B>A1\r\n" + 
                "</B></TD></TR>\r\n" + 
                "<TR><TD ALIGN=\"LEFT\" WIDTH=\"50%\"><b>\r\n" + 
                "   \r\n" + 
                "Meyer, Knut\r\n" + 
                "; &nbsp et al.</B>\r\n" + 
                "</TD><TD ALIGN=\"RIGHT\" WIDTH=\"50%\"> <B>\r\n" + 
                "January 3, 2002\r\n" + 
                "</B></TD>\r\n" + 
                "</TR>\r\n" + 
                "</TABLE><HR>\r\n" + 
                "<font size=\"+1\"> High level production of p-hydroxybenzoic acid in green plants\r\n" + 
                "</font><BR>\r\n" + 
                "   <BR><CENTER><B>Abstract</B></CENTER>\r\n" + 
                "   <P>\r\n" + 
                "The invention relates to high-level production of pHBA in green plants\r\n" + 
                "     using a unique expression cassette. The latter comprises a chorismate\r\n" + 
                "     pyruvate lyase (CPL) coding sequence operably linked to a suitable\r\n" + 
                "     promoter capable of driving protein expression in higher plants.\r\n" + 
                "     Additionally, the CPL cassette comprises a sequence encoding a\r\n" + 
                "     chloroplast transit peptide, its natural cleavage site, and a small\r\n" + 
                "     portion of the transit peptide donor protein fused to the N-terminus of\r\n" + 
                "     CPL. The chloroplast targeting sequence targets the foreign protein to\r\n" + 
                "     the chloroplast compartment and aids in its uptake into the organelle.\r\n" + 
                "     The cleavage site is unique to the transit peptide, and cleavage of the\r\n" + 
                "     chimeric protein encoded by the cassette at this site releases a novel\r\n" + 
                "     polypeptide that has full enzyme activity, comprising the mature CPL\r\n" + 
                "     enzyme and a small portion of the transit peptide donor.\r\n" + 
                "</P>\r\n" + 
                "   <HR>\r\n" + 
                "<TABLE WIDTH=\"100%\">\r\n" + 
                "<TR> <TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\">Inventors:</TD>\r\n" + 
                "<TD ALIGN=\"LEFT\" WIDTH=\"90%\">\r\n" + 
                " <B>Meyer, Knut</B>; <I>(Wilmington, DE)</I>\r\n" + 
                "<B>; Viitanen, Paul V.</B>; <I>(West Chester, PA)</I>\r\n" + 
                "<B>; Van Dyk, Drew E.</B>; <I>(Wilmington, DE)</I>\r\n" + 
                "\r\n" + 
                "</TD>\r\n" + 
                "</TR>   <TR><TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\">Correspondence Address:\r\n" + 
                "   </TD><TD ALIGN=\"LEFT\" WIDTH=\"90%\">\r\n" + 
                "   <B><PRE>    E I DU PONT DE NEMOURS AND COMPANY\r\n" + 
                "    LEGAL DEPARTMENT - PATENTS\r\n" + 
                "    1007 MARKET STREET\r\n" + 
                "    WILMINGTON\r\n" + 
                "    DE\r\n" + 
                "    19898\r\n" + 
                "    US\r\n" + 
                "</PRE></B>\r\n" + 
                "   </TD></TR>\r\n" + 
                "   <TR><TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\" NOWRAP>Family ID:\r\n" + 
                "   </TD><TD ALIGN=\"LEFT\" WIDTH=\"90%\">\r\n" + 
                "   <B>22780587\r\n" + 
                "</B></TD></TR>\r\n" + 
                "   <TR><TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\" NOWRAP>Appl. No.:\r\n" + 
                "   </TD><TD ALIGN=\"LEFT\" WIDTH=\"90%\">\r\n" + 
                "   <B> 09/855341\r\n" + 
                "</B></TD></TR>\r\n" + 
                "   <TR><TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\">Filed:\r\n" + 
                "   </TD><TD ALIGN=\"LEFT\" WIDTH=\"90%\">\r\n" + 
                "   <B>May 15, 2001</B></TD></TR>\r\n" + 
                "</TABLE>\r\n" + 
                "<HR> <CENTER><B>Related U.S. Patent Documents</B></CENTER> <HR> <TABLE WIDTH=\"100%\"> <TR><TH scope=\"col\" WIDTH=\"7%\"></TH><TH scope=\"col\"></TH><TH scope=\"col\"></TH><TH scope=\"col\"></TH><TD></TD></TR> <TR><TD align=\"left\">\r\n" + 
                "</TD><TH scope='col' align=center><B><U>Application Number</U></B></TH><TH scope='col' align=center><B><U>Filing Date</U></B></TH><TH scope='col' align=center><B><U>Patent Number</U></B></TH><TD</TD></TR><TR><TD align=center> </TD><TD align=center>60209854</TD><TD align=center>Jun 2, 2000</TD><TD align=center></TD><TD</TD></TR><TR><TD align=center> \r\n" + 
                "</TD>\r\n" + 
                "</TR> </TABLE>     <HR>\r\n" + 
                "<p>\r\n" + 
                "<TABLE border=0 WIDTH=\"100%\">\r\n" + 
                "   <TR><TD VALIGN=TOP ALIGN=\"LEFT\" WIDTH=\"40%\"><B>Current U.S. Class:</B></TD>\r\n" + 
                "   <TD VALIGN=TOP ALIGN=\"RIGHT\" WIDTH=\"60%\"><B>800/288</B>    ; 435/69.7; 435/69.8; 800/278; 800/298   </TD></TR>   \r\n" + 
                "   <TR><TD VALIGN=TOP ALIGN=\"LEFT\" WIDTH=\"40%\"><B>Current CPC Class: </B></TD>\r\n" + 
                "   <TD VALIGN=TOP ALIGN=\"RIGHT\" WIDTH=\"60%\">C07K 2319/00 20130101; C12N 9/88 20130101; C12N 15/8243 20130101</TD></TR>\r\n" + 
                "   <TR><TD VALIGN=TOP ALIGN=\"LEFT\" WIDTH=\"40%\"><B>Class at Publication:</B></TD>\r\n" + 
                "   <TD VALIGN=TOP ALIGN=\"RIGHT\" WIDTH=\"60%\"><B>800/288</B>    ; 800/278; 800/298; 435/69.7; 435/69.8   </TD></TR>   \r\n" + 
                "   <TR><TD VALIGN=TOP ALIGN=\"LEFT\" WIDTH=\"40%\"><B>International Class: </B></TD>\r\n" + 
                "   <TD VALIGN=TOP ALIGN=\"RIGHT\" WIDTH=\"60%\">C12N 015/62; A01H 005/00; C12N 015/82</TD></TR>\r\n" + 
                "</TABLE>\r\n" + 
                "       <HR>\r\n" + 
                "       <CENTER><B><I>Claims</B></I></CENTER>\r\n" + 
                "       <HR>\r\n" + 
                "       <BR><BR>What is claimed is:\r\n" + 
                "<BR><BR>1. A method for the production of para-hydroxy benzoic acid in a green\r\n" + 
                "     plant comprising: a) providing a green plant having an endogenous source\r\n" + 
                "     of chorismate and containing a chorismate pyruvate lyase expression\r\n" + 
                "     cassette having the following structure: P-T-C-D-CPL wherein: P is a\r\n" + 
                "     promoter suitable for driving the expression of a chorismate pyruvate\r\n" + 
                "     lyase gene; T is a nucleic acid molecule encoding a rubisco chloroplast\r\n" + 
                "     transit peptide; C a nucleic acid molecule encoding a Rubisco chloroplast\r\n" + 
                "     transit peptide cleavage site; D is a nucleic acid molecule encoding from\r\n" + 
                "     about 4 to about 20 contiguous amino acids of the N-terminal portion of a\r\n" + 
                "     Rubisco chloroplast transit peptide donor polypeptide; and CPL is a\r\n" + 
                "     nucleic acid molecule encoding a mature chorismate pyruvate lyase\r\n" + 
                "     protein; wherein each of P, T, C, D, and CPL are operably linked such\r\n" + 
                "     that expression of the cassette results in translation of a chimeric\r\n" + 
                "     protein comprising a chloroplast targeting sequence fused to the\r\n" + 
                "     N-terminus of the mature chorismate pyruvate lyase protein; b) growing\r\n" + 
                "     said plant under conditions whereby the chimeric protein is expressed and\r\n" + 
                "     translocated to the chloroplast for the conversion of chorismate to\r\n" + 
                "     para-hydroxy benzoic acid glucoside and para-hydroxy benzoic acid\r\n" + 
                "     derivatives; c) recovering para-hydroxy benzoic acid and para-hydroxy\r\n" + 
                "     benzoic acid derivatives from the plant; and d) processing said the\r\n" + 
                "     para-hydroxy benzoic acid glucoside and para-hydroxy benzoic acid\r\n" + 
                "     derivatives to free para-hydroxy benzoic acid.\r\n" + 
                "<BR><BR>2. A method according to claim 1 wherein the Rubisco transit peptide is\r\n" + 
                "     derived from a plant selected from the group consisting of: soybean,\r\n" + 
                "     rapeseed, sunflower, cotton, corn, tobacco, alfalfa, wheat, barley, oats,\r\n" + 
                "     sorghum, rice, Arabidopsis, sugar beet, sugar cane, canola, millet,\r\n" + 
                "     beans, peas, rye, flax, and forage grasses.\r\n" + 
                "<BR><BR>3. A method according to claim 1 wherein the promoter is selected from the\r\n" + 
                "     group consisting of the 35S promoter, the nopaline synthase promoter, the\r\n" + 
                "     octopine synthase promoter, cauliflower mosaic virus promoter, the\r\n" + 
                "     ribulose-1,5-bisphosphate carboxylase promoter and the promoter of the\r\n" + 
                "     chlorophyll a/b binding protein.\r\n" + 
                "<BR><BR>4. A method according to claim 1 wherein the chorismate pyruvate lyase\r\n" + 
                "     enzyme is encoded by the nucleic acid sequence as set forth in SEQ ID\r\n" + 
                "     NO:3.\r\n" + 
                "<BR><BR>5. A method according to claim 1 wherein the chimeric protein comprising a\r\n" + 
                "     chloroplast targeting sequence fused to the N-terminus of the mature\r\n" + 
                "     chorismate pyruvate lyase protein has the amino acid sequence as set\r\n" + 
                "     forth in SEQ ID NO:8.\r\n" + 
                "<BR><BR>6. A method according to claim 5 wherein the chimeric protein comprising a\r\n" + 
                "     chloroplast targeting sequence fused to the N-terminus of the mature\r\n" + 
                "     chorismate pyruvate lyase protein is processed to the amino acid sequence\r\n" + 
                "     as set forth in SEQ ID NO:16.\r\n" + 
                "<BR><BR>7. A method according to claim 1 wherein the pHBA glucoside is produced at\r\n" + 
                "     a concentration of a least 2% para-hydroxy benzoic acid glucoside per dry\r\n" + 
                "     weight of plant biomass.\r\n" + 
                "<BR><BR>8. A method according to claim 1 wherein the para-hydroxy benzoic acid\r\n" + 
                "     glucoside is produced at a concentration of at least 10% para-hydroxy\r\n" + 
                "     benzoic acid glucoside per dry weight of plant biomass.\r\n" + 
                "<BR><BR>9. A method according to claim 1 wherein the green plant containing a\r\n" + 
                "     chorismate pyruvate lyase expression cassette is selected from the group\r\n" + 
                "     consisting of soybean, rapeseed, sunflower, cotton, corn, tobacco,\r\n" + 
                "     alfalfa, wheat, barley, oats, sorghum, rice, Arabidopsis, sugar beet,\r\n" + 
                "     sugar cane, canola, millet, beans, peas, rye, flax, and forage grasses.\r\n" + 
                "<BR><BR>10. A method according to claim 1 wherein the para-hydroxy benzoic acid is\r\n" + 
                "     produced at a concentration of greater than 4.5% pHBA per dry weight of\r\n" + 
                "     plant biomass.\r\n" + 
                "<BR><BR>11. A chorismate pyruvate lyase expression cassette comprising a chimeric\r\n" + 
                "     gene having a nucleic acid molecule encoding a ribulose-1,5-bisphosphate\r\n" + 
                "     carboxylase small subunit chloroplast targeting sequence having an amino\r\n" + 
                "     acid sequence as set forth in SEQ ID NO: 15 operably linked to a nucleic\r\n" + 
                "     acid molecule encoding a chorismate pyruvate lyase enzyme having the\r\n" + 
                "     amino acid sequence as set forth in SEQ ID NO:4.\r\n" + 
                "<BR><BR>12. A chorismate pyruvate lyase expression cassette according to claim 11\r\n" + 
                "     wherein the chimeric gene encodes a polypeptide as set for the in SEQ ID\r\n" + 
                "     NO:8.\r\n" + 
                "<BR><BR>13. A plant comprising the CPL expression cassette of claim 11.\r\n" + 
                "<BR><BR>14. The plant according to claim 13 selected from the group consisting of\r\n" + 
                "     soybean, rapeseed, sunflower, cotton, corn, tobacco, alfalfa, wheat,\r\n" + 
                "     barley, oats, sorghum, rice, Arabidopsis, sugar beet, sugar cane, canola,\r\n" + 
                "     millet, beans, peas, rye, flax, and forage grasses.\r\n" + 
                "<BR><BR>15. A chimeric protein comprising a chloroplast targeting sequence fused\r\n" + 
                "     to the N-terminus of the mature chorismate pyruvate lyase protein having\r\n" + 
                "     the amino acid sequence as set forth in SEQ ID NO:8.\r\n" + 
                "<BR><BR>16. An isolated nucleic acid fragment encoding a chimeric protein\r\n" + 
                "     comprising a chloroplast targeting sequence fused to the N-terminus of\r\n" + 
                "     the mature CPL protein has the amino acid sequence as set forth in SEQ ID\r\n" + 
                "     NO: 15.\r\n" + 
                "<BR><BR>17. An isolated nucleic acid fragment of claim 16 having the sequence as\r\n" + 
                "     set forth in SEQ ID NO:7.\r\n" + 
                "<BR><BR>18. The chloroplast cleavage product of claim 15 having the amino acid\r\n" + 
                "     sequence as set forth in SEQ ID NO: 16.\r\n" + 
                "<BR><BR>19. A nucleic acid fragment encoding the processed protein of claim 18.\r\n" + 
                "     <HR>\r\n" + 
                "     <CENTER><B><I>Description</B></I></CENTER>\r\n" + 
                "     <HR>\r\n" + 
                "       <BR><BR>[0001] This application claims the benefit of U.S. Provisional Application\r\n" + 
                "     No. 60/209,854, filed Jun. 2, 2000.\r\n" + 
                "       <BR><BR>FIELD OF THE INVENTION\r\n" + 
                "<BR><BR>[0002] The invention relates to the field of plant gene expression and\r\n" + 
                "     molecular biology and microbiology. More specifically, a method is\r\n" + 
                "     presented for the production of p-hydroxybenzoic acid (PHBA) in green\r\n" + 
                "     plants which relies on the expression of a unique expression cassette\r\n" + 
                "     comprising a gene encoding chorismate pyruvate lyase operably linked to a\r\n" + 
                "     specific chloroplast targeting sequence.\r\n" + 
                "<BR><BR>BACKGROUND OF THE INVENTION\r\n" + 
                "<BR><BR>[0003] p-Hydroxybenzoic acid (pHBA) is the major monomeric component\r\n" + 
                "     (.about.65% by weight) of Zenite.TM., a Liquid Crystal Polymer (LCP).\r\n" + 
                "     LCP's have superior properties over conventional resins such as high\r\n" + 
                "     strength/stiffness, low melt viscosity, excellent environmental\r\n" + 
                "     resistance, property retention at elevated temperatures, and low gas\r\n" + 
                "     permeability. However, current synthetic methods for the synthesis of\r\n" + 
                "     pHBA (Kolbe-Schmitt reaction (Kolbe and Lautemann, Ann. 113:125 (1869)),\r\n" + 
                "     are prohibitively expensive, and an inexpensive route to LCP monomers\r\n" + 
                "     would open up many new applications for their use in the automotive,\r\n" + 
                "     electrical, and other industries. Biological production offers one\r\n" + 
                "     potential, less expensive route to pHBA production.\r\n" + 
                "<BR><BR>[0004] pHBA has been produced in microbial systems. For example, JP\r\n" + 
                "     06078780 teaches pHBA preparation by culturing benzoic acid in the\r\n" + 
                "     presence of microorganisms (preferably Aspergillus) that oxidize benzoic\r\n" + 
                "     acid to pHBA. Additionally, strains of Enterobacter with the ability to\r\n" + 
                "     convert p-cresol to pHBA have been isolated from soil (JP 05328981).\r\n" + 
                "     Further, JP 05336980 and JP 05336979 disclose isolated strains of\r\n" + 
                "     Pseudomonas putida with the ability to produce pHBA fromp-cresol.\r\n" + 
                "     Similarly, commonly owned WO 9856920 teaches a method for the production\r\n" + 
                "     of pHBA from toluene using a Pseudomonas mendocina mutant lacking the\r\n" + 
                "     ability to express para-hydroxybenzoate hydroxylase (pHBH). Finally, U.S.\r\n" + 
                "     Pat. No. 6,030,819 teaches the production of pHBA in genetically\r\n" + 
                "     engineered E. coli expressing the chorismate pyruvate lyase (CPL) gene.\r\n" + 
                "<BR><BR>[0005] In spite of these successes the ability to produce commercially\r\n" + 
                "     useful quantities of pHBA in microbial platforms is hampered by the use\r\n" + 
                "     of toxic starting materials and limited biomass. A method for pHBA\r\n" + 
                "     production that overcomes these problems is needed.\r\n" + 
                "<BR><BR>[0006] Coincidentally, pHBA is naturally occurring in nearly all plants,\r\n" + 
                "     animals, and, microorganisms, albeit in miniscule quantities. In many\r\n" + 
                "     bacteria, the generation of pHBA occurs by way of chorismate, an\r\n" + 
                "     important branchpoint intermediate in the synthesis of numerous aromatic\r\n" + 
                "     compounds, including phenylalanine, tyrosine, p-aminobenzoic acid, and\r\n" + 
                "     ubiquinone. In E. coli, chorismate itself undergoes five different\r\n" + 
                "     enzymatic reactions to yield five different products, and the enzyme that\r\n" + 
                "     is ultimately responsible for the synthesis of pHBA is chorismate\r\n" + 
                "     pyruvate lyase, which is known as CPL. The latter is the product of the\r\n" + 
                "     E. coil ubiC gene, which was independently cloned by two different groups\r\n" + 
                "     (Siebert et al., FEBS Lett 307:347-350 (1992); Nichlols et al., J.\r\n" + 
                "     Bacteriol 174:5309-5316 (1992)). The enzyme is a 19 kDa monomeric protein\r\n" + 
                "     with no known co-factors or energy requirements. Through elimination of\r\n" + 
                "     the C.sub.3 enolpyruvyl side chain of its sole substrate, CPL catalyzes\r\n" + 
                "     the direct conversion of 1 mol of chorismate to 1 mol of pyruvate and 1\r\n" + 
                "     mol of pHBA. Recombinant CPL has been overexpressed in E. coli, purified\r\n" + 
                "     to homogeneity, and partially characterized both biochemically and\r\n" + 
                "     kinetically (Siebert et al., Microbiology 140:897-904; Nichlols et al.,\r\n" + 
                "     J. Bacteriol 174:5309-5316 (1992)). In addition a detailed mechanism for\r\n" + 
                "     the CPL enzyme reaction has also been proposed (Walsh et al., Chem Rev.\r\n" + 
                "     90:1105-1129).\r\n" + 
                "<BR><BR>[0007] In plants pHBA has been found in carrot tissue (Schnitzler et al.,\r\n" + 
                "     Planta, 188, 594, (1992)), in a variety of grasses and crop plants (Lydon\r\n" + 
                "     et al., (J. Agric. Food. Chem., 36, 813, (1988), in the lignin of poplar\r\n" + 
                "     trees (Terashima et al., Phytochemistry, 14, 1991, (1972); and in a\r\n" + 
                "     number of other plant tissues (Billek et al., Oesterr. Chem., 67, 401,\r\n" + 
                "     (1966). The fact that plants possess all of the necessary enzymatic\r\n" + 
                "     machinery to synthesize pHBA suggests that they may be a useful platform\r\n" + 
                "     for the production of this monomer. For example, as a renewable resource\r\n" + 
                "     a plant platform would require far less energy and material consumption\r\n" + 
                "     than either petrochemical or microbial methods. Similarly, a plant\r\n" + 
                "     platform represents a far greater available biomass for monomer\r\n" + 
                "     production than a microbial system. Finally, the natural presence of pHBA\r\n" + 
                "     in plants suggests that host toxicity as a result of overproduction of\r\n" + 
                "     the compound might not be a problem. Nevertheless, in spite of the\r\n" + 
                "     obvious benefits of using plants as a means to produce pHBA, high level\r\n" + 
                "     production of the monomer has been elusive.\r\n" + 
                "<BR><BR>[0008] One difficulty to be overcome lies in the metabolic fate of\r\n" + 
                "     chorismate in plant tissues. Indeed, the production of pHBA from\r\n" + 
                "     chorismate is vastly more complicated in higher plants than microbes,\r\n" + 
                "     since the former lack an enzyme that is functionally equivalent to CPL.\r\n" + 
                "     For example, the biosynthetic pathway leading to pHBA in Lithospermum\r\n" + 
                "     erythrorhizon is thought to consist of up to 10 successive reactions\r\n" + 
                "     (Loscher and Heide, Plant Physiol. 106:271-279 (1992)), presumably all\r\n" + 
                "     catalyzed by different enzymes. Moreover, most of the enzymes that\r\n" + 
                "     catalyze these reactions have not been identified, nor have their genes\r\n" + 
                "     been cloned. Even less information is available on how pHBA is\r\n" + 
                "     synthesized in other plant species. To further complicate matters, those\r\n" + 
                "     enzymes that are known to participate in plant pHBA production span two\r\n" + 
                "     different pathways, that are differentially regulated and located in\r\n" + 
                "     different cellular compartments. Thus, chorismate is an intermediate of\r\n" + 
                "     the shikimate pathway which is largely confined to chloroplasts and other\r\n" + 
                "     types of plastids (Siebert et al., Plant Physiol. 112:811-819 (1996))\r\n" + 
                "     Sommer et al., Plant Cell Physiol. 39(11):1240-1244 (1998)), while all of\r\n" + 
                "     the intermediates downstream from phenylalanine belong to the\r\n" + 
                "     phenylpropanoid pathway which takes place in both the cytosol and\r\n" + 
                "     endoplasmic reticulum.\r\n" + 
                "<BR><BR>[0009] Despite the lack of understanding of how plants normally synthesize\r\n" + 
                "     pHBA and the enzymes that are involved in this process, transgenic plants\r\n" + 
                "     that accumulate significantly higher levels of pHBA than wildtype plants\r\n" + 
                "     have been described. For example, Kazufumi Yazaki, (Baiosaiensu to\r\n" + 
                "     Indasutori (1998), 56(9), 621-622) discusses the introduction of the CPL\r\n" + 
                "     encoding gene into tobacco for the production of pHBA in amounts\r\n" + 
                "     sufficient to confer insect resistance. Similarly, Siebert et al., (Plant\r\n" + 
                "     Physiol. 112:811-819 (1996)) have demonstrated that tobacco plants\r\n" + 
                "     (Nicotiana tabacum) transformed with a constitutively expressed\r\n" + 
                "     chloroplast-targeted version of E. coli CPL (referred to as \"TP-UbiC\")\r\n" + 
                "     have elevated levels of pHBA that are at least three orders of magnitude\r\n" + 
                "     greater than wildtype plants (WO 96/00788 granting as DE 4423022).\r\n" + 
                "     Interestingly, the genetically modified tobacco plants contained only\r\n" + 
                "     trace amounts of free pHBA. Instead, virtually all of the compound\r\n" + 
                "     (.about.98%) was converted to two glucose conjugates, a phenolic\r\n" + 
                "     glucoside and an ester glucoside, that were present in a ratio of about\r\n" + 
                "     3:1 (Siebert et al., Plant Physiol 112:811-819 (1996); Li et al., Plant\r\n" + 
                "     Cell Physiol. 38(7):844-850 (1997)). Both glucose conjugates were\r\n" + 
                "     1-.alpha.-D-glucosides, with a single glucose residue covalently attached\r\n" + 
                "     to the hydroxyl or carboxyl group of pHBA. The best transgenic plant that\r\n" + 
                "     was identified in this study had a total pHBA glucoside content of 0.52%\r\n" + 
                "     of dry weight, when leaf tissue was analyzed. Correcting for the\r\n" + 
                "     associated glucose residue, the actual amount of pHBA that was produced\r\n" + 
                "     in the transgenic tobacco plants was only about half of this value.\r\n" + 
                "<BR><BR>[0010] In more recent studies, the same artificial fusion protein was\r\n" + 
                "     expressed in transformed tobacco cell cultures using both a constitutive\r\n" + 
                "     promoter (Sommer et al., Plant Cell Physiol. 39(11):1240-1244 (1998)) and\r\n" + 
                "     an inducible promoter (Sommer et al., Plant Cell Reports 17:891-896\r\n" + 
                "     (1998)). While the accumulation of pHBA glucosides was slightly higher\r\n" + 
                "     than the original study with whole plants, in neither case did the levels\r\n" + 
                "     exceed 0.7% of dry weight. In contrast, when TP-UbiC was examined in\r\n" + 
                "     hairy root cultures of Lithospermum erythrorhizon (Sommer et al., Plant\r\n" + 
                "     Molecular Biology 39:683-693 (1999)) the pHBA glucoside content reached\r\n" + 
                "     levels as high as 0.8% of dry weight, after correcting for the endogenous\r\n" + 
                "     levels in the untransformed control cultures.\r\n" + 
                "<BR><BR>[0011] Although these studies demonstrate the feasibilility of using\r\n" + 
                "     genetic engineering to increase the level of pHBA in higher plants, the\r\n" + 
                "     TP-UbiC artificial fusion protein described above is unable to generate\r\n" + 
                "     the compound in commercially useful quantities. Such an effort will\r\n" + 
                "     require increasing the pHBA content of an agronomically suitable plant to\r\n" + 
                "     levels that are 10- to 20-fold higher than those previously reported.\r\n" + 
                "     Thus, one or more modifications of the present systems are needed to\r\n" + 
                "     achieve these levels. Since chorismate, the substrate for CPL, is\r\n" + 
                "     synthesised in plastids, one potential area for improvement may lie in\r\n" + 
                "     the design of a better chloroplast targeting sequence to achieve higher\r\n" + 
                "     levels of enzyme activity in the cellular compartment of interest.\r\n" + 
                "     Indeed, that there is a positive correlation between CPL enzyme activity\r\n" + 
                "     and accumulation of pHBA glucosides is apparent in several of the studies\r\n" + 
                "     noted above (Siebert et al., Plant Physiol. 112:811-819 (1996); Sommer et\r\n" + 
                "     al., Plant Cell Physiol. 39(11):1240-1244 (1998); Sommer et al Plant Cell\r\n" + 
                "     Reports 17:891-896 (1998)). Furthermore, in none of these studies is\r\n" + 
                "     there any evidence to suggest that the systems were saturated with CPL\r\n" + 
                "     enzyme activity using the TP-UbiC artificial fusion protein.\r\n" + 
                "<BR><BR>[0012] It is well known that most naturally occurring chloroplast proteins\r\n" + 
                "     are nuclear-encoded and synthesized as larger molecular weight precursors\r\n" + 
                "     with a cleavable N-terminal polypeptide extension called a transit\r\n" + 
                "     peptide. It is also generally accepted that the latter contains all of\r\n" + 
                "     the information that is necessary for translocation into the chloroplast.\r\n" + 
                "     Although the mechanistic details of protein import remain to be\r\n" + 
                "     elucidated, several important facts have emerged: (a) precursor uptake\r\n" + 
                "     occurs post-translationally (Chua and Schmidt, Proc Natl. Acad. Sci.\r\n" + 
                "     75:6110-6114 (1978); Highfield and Ellis, Nature 271:420-424 (1978)) and\r\n" + 
                "     is mediated by proteinacious receptors that exist in the chloroplast\r\n" + 
                "     envelope membranes (Cline et al., J. Biol. Chem. 260:3691-3696 (1985)));\r\n" + 
                "     (b) ATP-hydrolysis is the sole driving force for translocation (Grossman\r\n" + 
                "     et al., Nature 285:625-628 (1980); Cline et al., J. Biol. Chem.\r\n" + 
                "     260:3691-3696 (1985)); (c) fusion of a transit peptide to a foreign\r\n" + 
                "     protein is at times, but not always, sufficient to trigger uptake into\r\n" + 
                "     chloroplasts, both in vivo ((Van den Broeck et al., Nature 313:358-362\r\n" + 
                "     (1985)); Schreier et al., EMBO J. 4:25-32 (1985)) and in vitro Wasmann et\r\n" + 
                "     al., Mol. Gen. Genet. 205:446-453 (1986)); and finally, (d) following\r\n" + 
                "     chloroplast import, the transit peptide is proteolytically removed from\r\n" + 
                "     the precursor protein to give rise to the \"mature\" polypeptide. Although\r\n" + 
                "     the complete sequence of thousands of transit peptides are now known, the\r\n" + 
                "     manipulation of these sequences to achieve optimal targeting and\r\n" + 
                "     expression of foreign proteins in the chloroplast compartment of plants\r\n" + 
                "     is still a matter of trial and error. It is well settled however, that\r\n" + 
                "     simply attaching a transit peptide to a foreign protein does not\r\n" + 
                "     necessarily guarantee that it will be efficiently taken up by\r\n" + 
                "     chloroplasts or properly processed. Even when the same targeting sequence\r\n" + 
                "     is fused to different proteins, the results are completely unpredictable\r\n" + 
                "     (Lubben et al., The Plant Cell 1:1223-1230 (1989)), and the different\r\n" + 
                "     passenger proteins are transported with different efficiencies. The\r\n" + 
                "     reasons for this are not clear, however it has been suggested that\r\n" + 
                "     chloroplast uptake and removal of the transit peptide are somehow\r\n" + 
                "     coupled, and that certain artificial fusion proteins are either not\r\n" + 
                "     processed or processed ineffectively. For example, it has been shown that\r\n" + 
                "     even very subtle changes in the vicinity of the natural cleavage site of\r\n" + 
                "     the Rubisco small subunit precursor can lead to aberrant processing\r\n" + 
                "     (Robinson and Ellis, Eur. J. Biochem. 142:342-346 (1984); Robinson and\r\n" + 
                "     Ellis, Eur. J. Biochem. 152:67-73 (1985)) and diminished chloroplast\r\n" + 
                "     uptake (Wasmann et al., J. Biol. Chem. 263:617-619 (1988)).\r\n" + 
                "<BR><BR>[0013] Some degree of improvement has been achieved in this area by\r\n" + 
                "     including in the chloroplast targeting sequence not only the transit\r\n" + 
                "     peptide and the scissile bond, but also a small portion of the mature\r\n" + 
                "     N-terminus of the transit peptide donor. Indeed, this approach has worked\r\n" + 
                "     both in vivo and in vitro ((Van den Broeck et al., Nature 313:358-362\r\n" + 
                "     (1985); Schreier et al., EMBO J. 4:25-32 (1985); Wasmann et al., Mol.\r\n" + 
                "     Gen. Genet. 205:446-453 (1986); Herrera-Estrella et al., EP 0189707; U.S.\r\n" + 
                "     Pat. No. 5,728,925; U.S. Pat. No. 5,717,084) for another bacterial\r\n" + 
                "     protein, namely, neomycin phosphotransferase II (NPT-II). Thus, a\r\n" + 
                "     chimeric protein consisting of the transit peptide of the Rubisco small\r\n" + 
                "     subunit precursor plus the first 22 residues of mature Rubisco fused to\r\n" + 
                "     the N-terminus of NPT-II was taken up by chloroplasts much better than a\r\n" + 
                "     similar construct that only contained the transit peptide and scissile\r\n" + 
                "     bond. This strategy is not foolproof however, and is still associated\r\n" + 
                "     with a high degree of unpredictability that is inextricably linked to the\r\n" + 
                "     passenger protein. This is most readily seen in the literature attempts\r\n" + 
                "     to target CPL to chloroplasts. For example Sommer et al., Plant Cell\r\n" + 
                "     Physiol. 39(11):1240-1244 (1998)) describes an analogous artificial\r\n" + 
                "     fusion protein comprising the CPL gene product fused at its N-terminus to\r\n" + 
                "     the transit peptide and first 21 amino acid residues of the Rubisco small\r\n" + 
                "     subunit (e.g., \"TP21UbiC\"). While it was anticipated that this\r\n" + 
                "     modification would improve chloroplast uptake and processing, the cells\r\n" + 
                "     that contained the original construct, TP-UbiC, had much higher levels of\r\n" + 
                "     both CPL enzyme activity and pHBA glucosides. Thus, application of the\r\n" + 
                "     teaching of Wasmann et al., (Mol. Gen. Genet. 205:446-453 (1986)) had a\r\n" + 
                "     detrimental effect on a different protein.\r\n" + 
                "<BR><BR>[0014] The problem to be solved therefore is to provide a method for the\r\n" + 
                "     production of pHBA in plants at commercially useful levels taking\r\n" + 
                "     advantage of the chemical reaction that is catalyzed by the bacterial\r\n" + 
                "     protein CPL. This is a particularly ambitious goal since on top of all of\r\n" + 
                "     the complications noted above it is clear from the literature that\r\n" + 
                "     certain N-terminal modifications of E. coli CPL can result in a\r\n" + 
                "     substantial loss of enzyme activity (Siebert et al., Plant Physiol.\r\n" + 
                "     112:811-819 (1996). Consequently, it is not only essential to identify an\r\n" + 
                "     artificial fusion protein that is efficiently imported into chloroplasts,\r\n" + 
                "     but one that is also proteolytically processed to yield either unmodified\r\n" + 
                "     CPL or a CPL variant with an N-terminal extension that doesn't interfere\r\n" + 
                "     with enzyme activity. The solution to this problem is not taught in the\r\n" + 
                "     art. Applicant has solved the stated problem by creating a novel\r\n" + 
                "     artificial fusion protein that enables the expression of sufficiently\r\n" + 
                "     high levels of CPL enzyme activity in chloroplasts to accumulate\r\n" + 
                "     commercially useful levels of pHBA.\r\n" + 
                "<BR><BR>SUMMARY OF THE INVENTION\r\n" + 
                "<BR><BR>[0015] The present invention provides a method for the production of pHBA\r\n" + 
                "     in a green plant comprising:\r\n" + 
                "<BR><BR>[0016] a) providing a green plant having an endogenous source of\r\n" + 
                "     chorismate and containing a chorismate pyruvate lyase expression cassette\r\n" + 
                "     having the following structure:\r\n" + 
                "<BR><BR>P-T-C-D-CPL\r\n" + 
                "<BR><BR>[0017] wherein:\r\n" + 
                "<BR><BR>[0018] P is a promoter suitable for driving the expression of a chorismate\r\n" + 
                "     pyruvate lyase gene;\r\n" + 
                "<BR><BR>[0019] T is a nucleic acid molecule encoding a rubisco chloroplast transit\r\n" + 
                "     peptide;\r\n" + 
                "<BR><BR>[0020] C a nucleic acid molecule encoding a Rubisco chloroplast transit\r\n" + 
                "     peptide cleavage site;\r\n" + 
                "<BR><BR>[0021] D is a nucleic acid molecule encoding from about 4 to about 20\r\n" + 
                "     contiguous amino acids of the N-terminal portion of a Rubisco chloroplast\r\n" + 
                "     transit peptide donor polypeptide;\r\n" + 
                "<BR><BR>[0022] and\r\n" + 
                "<BR><BR>[0023] CPL is a nucleic acid molecule encoding a mature chorismate\r\n" + 
                "     pyruvate lyase protein;\r\n" + 
                "<BR><BR>[0024] wherein each of P, T, C, D, and CPL are operably linked such that\r\n" + 
                "     expression of the cassette results in translation of a chimeric protein\r\n" + 
                "     comprising a chloroplast targeting sequence fused to the N-terminus of\r\n" + 
                "     the mature chorismate pyruvate lyase protein;\r\n" + 
                "<BR><BR>[0025] b) growing said plant under conditions whereby the chimeric protein\r\n" + 
                "     is expressed and translocated to the chloroplast for the conversion of\r\n" + 
                "     chorismate to para-hydroxy benzoic acid glucoside and para-hydroxy\r\n" + 
                "     benzoic acid derivatives;\r\n" + 
                "<BR><BR>[0026] c) recovering para-hydroxy benzoic acid and para-hydroxy benzoic\r\n" + 
                "     acid derivatives from the plant; and\r\n" + 
                "<BR><BR>[0027] d) processing said the para-hydroxy benzoic acid glucoside and\r\n" + 
                "     para-hydroxy benzoic acid derivatives to free para-hydroxy benzoic acid.\r\n" + 
                "<BR><BR>[0028] Specifically, the present method produces para-hydroxy benzoic acid\r\n" + 
                "     glucosides in plants at a concentration of greater than 2% of the dry\r\n" + 
                "     weight of the plant biomass and preferably at a concentration of greater\r\n" + 
                "     than 10%.\r\n" + 
                "<BR><BR>[0029] Additionally the invention provides a chorismate pyruvate lyase\r\n" + 
                "     expression cassette comprising: a chimeric gene having a nucleic acid\r\n" + 
                "     molecule encoding a ribulose-1,5-bisphosphate carboxylase small subunit\r\n" + 
                "     derived chloroplast targeting sequence having an amino acid sequence as\r\n" + 
                "     set forth in SEQ ID NO:15 operably linked to a nucleic acid molecule\r\n" + 
                "     encoding a chorismate pyruvate lyase enzyme having the amino acid\r\n" + 
                "     sequence as set forth in SEQ ID NO:4.\r\n" + 
                "       <BR><BR>BRIEF DESCRIPTION OF THE DRAWINGS SEQUENCE DESCRIPTIONS\r\n" + 
                "<BR><BR>[0030] FIG. 1 shows a primary amino acid sequence alignment of two\r\n" + 
                "     different chloroplast-targeted versions of CPL. Both are artificial\r\n" + 
                "     fusion proteins. The one in line 3 corresponds to TP-UbiC which was used\r\n" + 
                "     in previous studies (Siebert et al., Plant Physiol. 112:811-819 (1996)\r\n" + 
                "     Sommer et al., Plant Cell Physiol. 39(11):1240-1244 (1998); Sommer et\r\n" + 
                "     al., Plant Cell Reports 17:891-896 (1998); Sommer et al., Plant Molecular\r\n" + 
                "     Biology 39:683-693 (1999)), while the one in line 2 corresponds to TP-CPL\r\n" + 
                "     which was developed in the present work. E. coli CPL (line 4) and the\r\n" + 
                "     tomato Rubisco small subunit precursor for rbcS2 (line 1) are also\r\n" + 
                "     included in the alignment. Amino acid residues corresponding to the\r\n" + 
                "     \"mature\" Rubisco small subunit are indicated in bold. The N-terminal\r\n" + 
                "     chloroplast transit peptide of the Rubisco small subunit precursor is\r\n" + 
                "     indicated in plain text. The primary amino acid sequence of E. coli CPL\r\n" + 
                "     is indicated in italics. The arrow indicates the highly conserved Cys-Met\r\n" + 
                "     junction (Mazur et al., Nuc Acids Res. 13:2373-2386 (1985); Berry-Lowe et\r\n" + 
                "     al., J. Mol. and Appl. Gen. 1, 483-498 (1982)) where transit peptide\r\n" + 
                "     cleavage normally occurs to give rise to the mature Rubisco small\r\n" + 
                "     subunit.\r\n" + 
                "<BR><BR>[0031] FIG. 2 shows a schematic representation (circle diagram) of the\r\n" + 
                "     intermediate plasmid, \"TP-CPL-pML63\", and relevant restriction sites.\r\n" + 
                "<BR><BR>[0032] FIG. 3 shows a schematic representation (circle diagram) of the\r\n" + 
                "     binary vector plant expression construct, \"TP-CPL-pZBL 1\", that was used\r\n" + 
                "     for transformation of tobacco and arabidopsis after introduction into\r\n" + 
                "     Agrobacterium.\r\n" + 
                "<BR><BR>[0033] FIG. 4 shows a representative HPLC tracing of leaf tissue extract\r\n" + 
                "     prepared from a transgenic tobacco plant expressing TP-CPL (Transformant\r\n" + 
                "     #5) compared to a wildtype plant.\r\n" + 
                "<BR><BR>[0034] FIG. 5 shows the total pHBA-glucoside content of 15 different\r\n" + 
                "     transgenic tobacco plants expressing TP-CPL. The analysis was conducted\r\n" + 
                "     on fresh leaf material that was obtained 5 weeks after the primary\r\n" + 
                "     transformants were transferred to soil.\r\n" + 
                "<BR><BR>[0035] FIG. 6 shows the age-dependent accumulation of total pHBA\r\n" + 
                "     glucosides in transgenic tobacco plants expressing TP-CPL. The analysis\r\n" + 
                "     was conducted on leaf tissue that was obtained from primary transformants\r\n" + 
                "     at various stages of development. Total pHBA glucosides are expressed as\r\n" + 
                "     a percentage of dry weight.\r\n" + 
                "<BR><BR>[0036] FIG. 7 shows a Western blot of wildtype (lane 9) and transgenic\r\n" + 
                "     tobacco plants expressing TP-CPL (lanes 1-7). The analysis was conducted\r\n" + 
                "     on leaf tissue that was obtained from 5-week-old primary transformants.\r\n" + 
                "     Lane 8 contains 20 ng of purified recombinant ATP-CPL (e.g., the\r\n" + 
                "     predicted chloroplast cleavage product of TP-CPL). Following SDS-PAGE,\r\n" + 
                "     proteins were transferred to nitrocellulose and probed with a 1:200\r\n" + 
                "     dilution of anti-CPL antisera.\r\n" + 
                "       <BR><BR>[0037] The invention can be more fully understood from the following\r\n" + 
                "     detailed description and the accompanying sequence descriptions which\r\n" + 
                "     form a part of this application.\r\n" + 
                "<BR><BR>[0038] Applicant(s) have provided 16 sequences in conformity with 37\r\n" + 
                "     C.F.R. 1.821-1.825 (\"Requirements for Patent Applications Containing\r\n" + 
                "     Nucleotide Sequences and/or Amino Acid Sequence Disclosures--the Sequence\r\n" + 
                "     Rules\") and consistent with World Intellectual Property Organization\r\n" + 
                "     (WIPO) Standard ST.25 (1998) and the sequence listing requirements of the\r\n" + 
                "     EPO and PCT (Rules 5.2 and 49.5(a-bis), and Section 208 and Annex C of\r\n" + 
                "     the Adminstrative Instructions). The symbols and format used for\r\n" + 
                "     nucleotide and amino acid sequence data comply with the rules set forth\r\n" + 
                "     in 37 C.F.R. .sctn.1.822.\r\n" + 
                "<BR><BR>[0039] SEQ ID NO: 1 is the 5' primer useful for introducing E. coli CPL,\r\n" + 
                "     having Genbank accession No. M96268, into the E. coli expression vector,\r\n" + 
                "     pET-24a (+) (Novagen).\r\n" + 
                "<BR><BR>[0040] SEQ ID NO:2 is the 3' primer useful for introducing E. coli CPL,\r\n" + 
                "     having Genbank accession No. M96268, into the E. coli expression vector,\r\n" + 
                "     pET-24a (+) (Novagen).\r\n" + 
                "<BR><BR>[0041] SEQ ID NO:3 is the nucleotide sequence of the ORF of E. coli CPL,\r\n" + 
                "     having Genbank accession No. M96268, in the E. coli expression vector,\r\n" + 
                "     pET-24a (+) (Novagen).\r\n" + 
                "<BR><BR>[0042] SEQ ID NO:4 is the primary amino acid sequence of the ORF of E.\r\n" + 
                "     coli CPL, having Genbank accession No. M96268, in the E. coli expression\r\n" + 
                "     vector, pET-24a (+) (Novagen).\r\n" + 
                "<BR><BR>[0043] SEQ ID NO:5 is the 5' primer useful for the amplification of the\r\n" + 
                "     chloroplast targeting sequence of the tomato Rubisco small subunit\r\n" + 
                "     precursor, for expression of TP-CPL in E. coli.\r\n" + 
                "<BR><BR>[0044] SEQ ID NO:6 is the 3' primer useful for the amplification of the\r\n" + 
                "     chloroplast targeting sequence of the tomato Rubisco small subunit\r\n" + 
                "     precursor, for expression of TP-CPL in E. coli.\r\n" + 
                "<BR><BR>[0045] SEQ ID NO:7 is the nucleotide sequence of the ORF of the\r\n" + 
                "     chloroplast-targeted CPL fusion protein (TP-CPL) in the E. coli\r\n" + 
                "     expression vector, pET-24a (+) Novagen).\r\n" + 
                "<BR><BR>[0046] SEQ ID NO:8 is the primary amino acid sequence of the ORF of the\r\n" + 
                "     chloroplast-targeted CPL fusion protein (TP-CPL) in the E. coli\r\n" + 
                "     expression vector, pET-24a (+) (Novagen).\r\n" + 
                "<BR><BR>[0047] SEQ ID NO:9 is the 5' primer useful for the amplification of the\r\n" + 
                "     predicted chloroplast cleavage product of TP-CPL (ATP-CPL), and its\r\n" + 
                "     insertion into the E. coli expression vector, pET-24d (+) (Novagen).\r\n" + 
                "<BR><BR>[0048] SEQ ID NO: 10 is the 3' primer useful for the amplification of the\r\n" + 
                "     predicted chloroplast cleavage product of TP-CPL (ATP-CPL), and its\r\n" + 
                "     insertion into the E. coli expression vector, pET-24d (+) (Novagen).\r\n" + 
                "<BR><BR>[0049] SEQ ID NO:11 is the 5' primer useful for amplification and\r\n" + 
                "     modification of TP-CPL, without changing its primary amino acid sequence,\r\n" + 
                "     for insertion into the in vitro transcription/translation vector,\r\n" + 
                "     pCITE4a(+) (Novagen).\r\n" + 
                "<BR><BR>[0050] SEQ ID NO:12 is the 3' primer useful for amplification and\r\n" + 
                "     modification of TP-CPL, without changing its primary amino acid sequence,\r\n" + 
                "     for insertion into the in vitro transcription/translation vector,\r\n" + 
                "     pCITE4a(+) (Novagen).\r\n" + 
                "<BR><BR>[0051] SEQ ID NO: 13 is the 5' primer useful for the amplification of a\r\n" + 
                "     truncated version of the 3' NOS terminator sequence using plasmid pMH40\r\n" + 
                "     as a template.\r\n" + 
                "<BR><BR>[0052] SEQ ID NO:14 is the 3' primer useful for the amplification of a\r\n" + 
                "     truncated version of the 3' NOS terminator sequence using plasmid pMH40\r\n" + 
                "     as a template.\r\n" + 
                "<BR><BR>[0053] SEQ ID NO:15 is the chloroplast-targeting sequence derived from the\r\n" + 
                "     tomato ribulose-1,5-bisphosphate carboxylase small subunit.\r\n" + 
                "<BR><BR>[0054] SEQ ID NO: 16 is the processed chloroplast-targeted CPL fusion\r\n" + 
                "     protein (TP-CPL).\r\n" + 
                "<BR><BR>DETAILED DESCRIPTION OF THE INVENTION\r\n" + 
                "<BR><BR>[0055] The present invention provides methods for the high level of\r\n" + 
                "     production of para-hydroxy benzoic acid (PHBA) in green plants at\r\n" + 
                "     commercially useful levels. pHBA is useful as a monomer in liquid\r\n" + 
                "     crystalline polymers which have application in the automotive,\r\n" + 
                "     electrical, and other industries.\r\n" + 
                "<BR><BR>[0056] The method relies on the effective expression of a gene encoding a\r\n" + 
                "     modified version of the enzyme chorismate pyruvate lyase (CPL) which\r\n" + 
                "     catalyzes the direct conversion of 1 mol of chorismate to 1 mol of\r\n" + 
                "     pyruvate and 1 mol of pHBA. The CPL variant is introduced into a green\r\n" + 
                "     plant in the form of an expression cassette which comprises the CPL\r\n" + 
                "     coding sequence operably linked to a suitable promoter capable of driving\r\n" + 
                "     protein expression in plants. Additionally the expression cassette\r\n" + 
                "     contains a DNA fragment that is situated directly upstream and contiguous\r\n" + 
                "     to the CPL coding sequence which encodes a chloroplast transit peptide,\r\n" + 
                "     its natural cleavage site, and a small portion of the transit peptide\r\n" + 
                "     donor polypeptide. The transit peptide functions to target the chimeric\r\n" + 
                "     protein encoded by the expression cassette to the chloroplast and enables\r\n" + 
                "     its uptake into the organelle that is responsible for the synthesis of\r\n" + 
                "     chorismate, the substrate of CPL that is converted to pHBA. The cleavage\r\n" + 
                "     site is unique to the original transit peptide donor and cleavage of the\r\n" + 
                "     artificial protein encoded by this cassette at this site liberates a\r\n" + 
                "     novel polypeptide comprising the mature CPL enzyme that contains at its\r\n" + 
                "     N-terminus a small portion of the transit peptide donor.\r\n" + 
                "<BR><BR>[0057] In this disclosure, a number of terms and abbreviations are used.\r\n" + 
                "     The following definitions are provided.\r\n" + 
                "<BR><BR>[0058] \"Polymerase chain reaction\" is abbreviated PCR.\r\n" + 
                "<BR><BR>[0059] \"Chorismate Pyruvate Lyase\" is abbreviated CPL and refers to a gene\r\n" + 
                "     encoding an enzyme which catalyzes the conversion of chorismate to\r\n" + 
                "     pyruvate and pHBA.\r\n" + 
                "<BR><BR>[0060] \"Para-hydroxybenzoic acid\" or \"P-hydroxybenzoic acid\" is\r\n" + 
                "     abbreviated pHBA.\r\n" + 
                "<BR><BR>[0061] The term \"P-hydroxybenzoic acid glucoside\" or \"pHBA glucoside\"\r\n" + 
                "     refers to a conjugate comprising pHBA and a glucose molecule.\r\n" + 
                "<BR><BR>[0062] The term \"pHBA derivative\" refers to any conjugate of pHBA that may\r\n" + 
                "     be formed in a plant as the result of the catalytic activity of the CPL\r\n" + 
                "     enzyme.\r\n" + 
                "<BR><BR>[0063] The term \"transit peptide\" or \"chloroplast transit peptide\" will be\r\n" + 
                "     abbreviated \"TP\" and refers to the N-terminal portion of a chloroplast\r\n" + 
                "     precursor protein that directs the latter into chloroplasts and is\r\n" + 
                "     subsequently cleaved off by the chloroplast processing protease.\r\n" + 
                "<BR><BR>[0064] The term \"chloroplast-targeting sequence\" refers to any polypeptide\r\n" + 
                "     extention that is attached to the N-terminus of a foreign protein for the\r\n" + 
                "     purpose of translocation into the chloroplast. In the case of a naturally\r\n" + 
                "     occuring chloroplast precursor protein, the transit peptide is considered\r\n" + 
                "     to be the chloroplast-targeting sequence, although optimal uptake and\r\n" + 
                "     proteolytic processing may depend in part on portions of the \"mature\"\r\n" + 
                "     chloroplast protein.\r\n" + 
                "<BR><BR>[0065] The term \"transit peptide donor sequence\" refers to that portion of\r\n" + 
                "     the chloroplast-targeting sequence that is derived from the \"mature\"\r\n" + 
                "     portion of the choroplast precursor protein. The transit peptide donor\r\n" + 
                "     sequence is always downstream and immediately adjacent to the transit\r\n" + 
                "     peptide cleavage site that separates the transit peptide from the mature\r\n" + 
                "     chloroplast protein.\r\n" + 
                "<BR><BR>[0066] The term \"chloroplast processing protease\" refers to a protease\r\n" + 
                "     enzyme capable of cleaving the scissile bond between the transit peptide\r\n" + 
                "     and the mature chloroplast protein.\r\n" + 
                "<BR><BR>[0067] The term \"transit peptide cleavage site\" refers to a site between\r\n" + 
                "     two amino acids in a chloroplast-targeting sequence at which the\r\n" + 
                "     chloroplast processing protease acts.\r\n" + 
                "<BR><BR>[0068] As used herein, an \"isolated nucleic acid fragment\" is a polymer of\r\n" + 
                "     RNA or DNA that is single- or double-stranded, optionally containing\r\n" + 
                "     synthetic, non-natural or altered nucleotide bases. An isolated nucleic\r\n" + 
                "     acid fragment in the form of a polymer of DNA may be comprised of one or\r\n" + 
                "     more segments of cDNA, genomic DNA or synthetic DNA.\r\n" + 
                "<BR><BR>[0069] \"Gene\" refers to a nucleic acid fragment that expresses a specific\r\n" + 
                "     protein, including regulatory sequences preceding (5' non-coding\r\n" + 
                "     sequences) and following (3' non-coding sequences) the coding sequence.\r\n" + 
                "     \"Native gene\" refers to a gene as found in nature with its own regulatory\r\n" + 
                "     sequences \"Chimeric gene\" refers to any gene that is not a native gene,\r\n" + 
                "     comprising regulatory and coding sequences that are not found together in\r\n" + 
                "     nature. Accordingly, a chimeric gene may comprise regulatory sequences\r\n" + 
                "     and coding sequences that are derived from different sources, or\r\n" + 
                "     regulatory sequences and coding sequences derived from the same source,\r\n" + 
                "     but arranged in a manner different than that found in nature. \"Endogenous\r\n" + 
                "     gene\" refers to a native gene in its natural location in the genome of an\r\n" + 
                "     organism. A \"foreign\" gene refers to a gene not normally found in the\r\n" + 
                "     host organism, but that is introduced into the host organism by gene\r\n" + 
                "     transfer. Foreign genes can comprise native genes inserted into a\r\n" + 
                "     non-native organism, or chimeric genes. A \"transgene\" is a gene that has\r\n" + 
                "     been introduced into the genome by a transformation procedure.\r\n" + 
                "<BR><BR>[0070] \"Synthetic genes\" can be assembled from oligonucleotide building\r\n" + 
                "     blocks that are chemically synthesized using procedures known to those\r\n" + 
                "     skilled in the art. These building blocks are ligated and annealed to\r\n" + 
                "     form gene segments which are then enzymatically assembled to construct\r\n" + 
                "     the entire gene. \"Chemically synthesized\", as related to a sequence of\r\n" + 
                "     DNA, means that the component nucleotides were assembled in vitro. Manual\r\n" + 
                "     chemical synthesis of DNA may be accomplished using well established\r\n" + 
                "     procedures, or automated chemical synthesis can be performed using one of\r\n" + 
                "     a number of commercially available machines. Accordingly, the genes can\r\n" + 
                "     be tailored for optimal gene expression based on optimization of\r\n" + 
                "     nucleotide sequence to reflect the codon bias of the host cell. The\r\n" + 
                "     skilled artisan appreciates the likelihood of successful gene expression\r\n" + 
                "     if codon usage is biased towards those codons favored by the host.\r\n" + 
                "     Determination of preferred codons can be based on a survey of genes\r\n" + 
                "     derived from the host cell where sequence information is available.\r\n" + 
                "<BR><BR>[0071] \"Coding sequence\" refers to a DNA sequence that codes for a\r\n" + 
                "     specific amino acid sequence. \"Suitable regulatory sequences\" refer to\r\n" + 
                "     nucleotide sequences located upstream (5' non-coding sequences), within,\r\n" + 
                "     or downstream (3' non-coding sequences) of a coding sequence, and which\r\n" + 
                "     influence the transcription, RNA processing or stability, or translation\r\n" + 
                "     of the associated coding sequence. Regulatory sequences may include\r\n" + 
                "     promoters, translation leader sequences, introns, polyadenylation\r\n" + 
                "     recognition sequences, RNA processing site, effector binding site and\r\n" + 
                "     stem-loop structure.\r\n" + 
                "<BR><BR>[0072] \"Promoter\" refers to a nucleotide sequence capable of controlling\r\n" + 
                "     the expression of a coding sequence or functional RNA. In general, a\r\n" + 
                "     coding sequence is located 3' to a promoter sequence. The promoter\r\n" + 
                "     sequence consists of proximal and more distal upstream elements, the\r\n" + 
                "     latter elements often referred to as enhancers. Accordingly, an\r\n" + 
                "     \"enhancer\" is a nucleotide sequence which can stimulate promoter activity\r\n" + 
                "     and may be an innate element of the promoter or a heterologous element\r\n" + 
                "     inserted to enhance the level or tissue-specificity of a promoter.\r\n" + 
                "     Promoters may be derived in their entirety from a native gene, or be\r\n" + 
                "     composed of different elements derived from different promoters found in\r\n" + 
                "     nature, or even comprise synthetic nucleotide segments. It is understood\r\n" + 
                "     by those skilled in the art that different promoters may direct the\r\n" + 
                "     expression of a gene in different tissues or cell types, or at different\r\n" + 
                "     stages of development, or in response to different environmental\r\n" + 
                "     conditions. Promoters which cause a nucleic acid fragment to be expressed\r\n" + 
                "     in most cell types at most times are commonly referred to as\r\n" + 
                "     \"constitutive promoters\". New promoters of various types useful in plant\r\n" + 
                "     cells are constantly being discovered; numerous examples may be found in\r\n" + 
                "     the compilation by Okamuro and Goldberg (1989) Biochemistry of Plants\r\n" + 
                "     15:1-82. It is further recognized that since in most cases the exact\r\n" + 
                "     boundaries of regulatory sequences have not been completely defined,\r\n" + 
                "     nucleic acid fragments of different lengths may have identical promoter\r\n" + 
                "     activity.\r\n" + 
                "<BR><BR>[0073] The \"3' non-coding sequences\" refer to DNA sequences located\r\n" + 
                "     downstream of a coding sequence and include polyadenylation recognition\r\n" + 
                "     sequences and other sequences encoding regulatory signals capable of\r\n" + 
                "     affecting mRNA processing or gene expression. The polyadenylation signal\r\n" + 
                "     is usually characterized by affecting the addition of polyadenylic acid\r\n" + 
                "     tracts to the 3' end of the mRNA precursor.\r\n" + 
                "<BR><BR>[0074] The term \"operably linked\" refers to the association of nucleic\r\n" + 
                "     acid sequences on a single nucleic acid fragment so that the function of\r\n" + 
                "     one is affected by the other. For example, a promoter is operably linked\r\n" + 
                "     with a coding sequence when it is capable of affecting the expression of\r\n" + 
                "     that coding sequence (i.e., that the coding sequence is under the\r\n" + 
                "     transcriptional control of the promoter). Coding sequences can be\r\n" + 
                "     operably linked to regulatory sequences in sense or antisense\r\n" + 
                "     orientation.\r\n" + 
                "<BR><BR>[0075] The term \"expression\", as used herein, refers to the transcription\r\n" + 
                "     and stable accumulation of sense (mRNA) or antisense RNA derived from the\r\n" + 
                "     nucleic acid fragment of the invention. Expression may also refer to\r\n" + 
                "     translation of mRNA into a polypeptide.\r\n" + 
                "<BR><BR>[0076] \"Mature\" protein refers to a post-translationally processed\r\n" + 
                "     polypeptide; i.e., one from which any pre- or propeptides present in the\r\n" + 
                "     primary translation product have been removed. \"Precursor\" protein refers\r\n" + 
                "     to the primary product of translation of mRNA; i.e., with pre- and\r\n" + 
                "     propeptides still present. Pre- and propeptides may be but are not\r\n" + 
                "     limited to intracellular localization signals.\r\n" + 
                "<BR><BR>[0077] \"Transformation\" refers to the transfer of a nucleic acid fragment\r\n" + 
                "     into the genome of a host organism, resulting in genetically stable\r\n" + 
                "     inheritance. Host organisms containing the transformed nucleic acid\r\n" + 
                "     fragments are referred to as \"transgenic\" or \"recombinant\" or\r\n" + 
                "     \"transformed\" organisms.\r\n" + 
                "<BR><BR>[0078] The terms \"plasmid\", \"vector\" and \"cassette\" refer to an extra\r\n" + 
                "     chromosomal element often carrying genes which are not part of the\r\n" + 
                "     central metabolism of the cell, and usually in the form of circular\r\n" + 
                "     double-stranded DNA molecules. Such elements may be autonomously\r\n" + 
                "     replicating sequences, genome integrating sequences, phage or nucleotide\r\n" + 
                "     sequences, linear or circular, of a single- or double-stranded DNA or\r\n" + 
                "     RNA, derived from any source, in which a number of nucleotide sequences\r\n" + 
                "     have been joined or recombined into a unique construction which is\r\n" + 
                "     capable of introducing a promoter fragment and DNA sequence for a\r\n" + 
                "     selected gene product along with appropriate 3' untranslated sequence\r\n" + 
                "     into a cell. \"Transformation cassette\" refers to a specific vector\r\n" + 
                "     containing a foreign gene and having elements in addition to the foreign\r\n" + 
                "     gene that facilitate transformation of a particular host cell.\r\n" + 
                "     \"Expression cassette\" refers to a specific vector containing a foreign\r\n" + 
                "     gene and having elements in addition to the foreign gene that allow for\r\n" + 
                "     enhanced expression of that gene in a foreign host.\r\n" + 
                "<BR><BR>[0079] Standard recombinant DNA and molecular cloning techniques used here\r\n" + 
                "     are well known in the art and are described by Sambrook, J., Fritsch, E.\r\n" + 
                "     F. and Maniatis, T., Molecular Cloning: A Laboratory Manual, Second\r\n" + 
                "     Edition, Cold Spring Harbor Laboratory Press, Cold Spring Harbor, N.Y.\r\n" + 
                "     (1989) (hereinafter \"Maniatis\"); and by Silhavy, T. J., Bennan, M. L. and\r\n" + 
                "     Enquist, L. W., Experiments with Gene Fusions, Cold Spring Harbor\r\n" + 
                "     Laboratory Cold Press Spring Harbor, N.Y. (1984); and by Ausubel, F. M.\r\n" + 
                "     et al., Current Protocols in Molecular Biology, published by Greene\r\n" + 
                "     Publishing Assoc. and Wiley-Interscience (1987).\r\n" + 
                "<BR><BR>[0080] CPL Expression Cassette\r\n" + 
                "<BR><BR>[0081] The present invention provides an expression cassette useful for\r\n" + 
                "     the expression of a fully-active, modified version of chorismate pyruvate\r\n" + 
                "     lyase (CPL) and the targeting of that polypeptide to the chloroplasts of\r\n" + 
                "     the host plant. Typically the expression cassette will comprise (1) the\r\n" + 
                "     cloned CPL gene under the transcriptional control of 5' and 3' regulatory\r\n" + 
                "     sequences and (2) a dominant selectable marker. The present expression\r\n" + 
                "     cassette may also contain, a promoter regulatory region (e.g., one\r\n" + 
                "     conferring inducible or constitutive, environmentally- or\r\n" + 
                "     developmentally-regulated, or cell- or tissue-specific/selective\r\n" + 
                "     expression), a transcription initiation start site, a ribosome binding\r\n" + 
                "     site, an RNA processing signal, a transcription termination site, and/or\r\n" + 
                "     a polyadenylation signal. In a preferred embodiment the instant cassette\r\n" + 
                "     will additionally contain sequences encoding a transit peptide as well as\r\n" + 
                "     sequences encoding a portion of the transit peptide donor which contains\r\n" + 
                "     a transit peptide cleavage site that is amenable to processing by the\r\n" + 
                "     host plant cell chloroplast processing protease. Optionally the instant\r\n" + 
                "     cassette may also comprise one or more introns in order to facilitate CPL\r\n" + 
                "     expression.\r\n" + 
                "<BR><BR>[0082] The CPL gene encodes an enzyme which converts 1 mol of chorismate\r\n" + 
                "     to 1 mol of pyruvate and 1 mol of pHBA. The most well characterized CPL\r\n" + 
                "     gene has been isolated from E. coli and bears the GenBank accession\r\n" + 
                "     number M96268.\r\n" + 
                "<BR><BR>[0083] Promoters useful for driving the instant CPL gene are numerous and\r\n" + 
                "     well known in the art. Suitable promoters will be those that operate in\r\n" + 
                "     plants and generally will be derived from the plant host in which the CPL\r\n" + 
                "     expression cassette resides. Any combination of any promoter and any\r\n" + 
                "     terminator capable of inducing expression of the CPL gene may be used in\r\n" + 
                "     the present cassette. Some suitable examples of promoters and terminators\r\n" + 
                "     include those from nopaline synthase (nos), octopine synthase (ocs) and\r\n" + 
                "     cauliflower mosaic virus (CaMV) genes. One type of efficient plant\r\n" + 
                "     promoter that may be used is a high level plant promoter. Such promoters,\r\n" + 
                "     in operable linkage with the genetic sequences of the present invention\r\n" + 
                "     should be capable of promoting expression of the present gene product.\r\n" + 
                "     High level plant promoters that may be used in this invention include the\r\n" + 
                "     promoter of the small subunit (ss) of the ribulose-1,5-bisphosphate\r\n" + 
                "     carboxylase for example from soybean (Berry-Lowe et al., J. Molecular and\r\n" + 
                "     App. Gen., 1:483-498 1982)), and the promoter of the chlorophyll a/b\r\n" + 
                "     binding protein. These two promoters are known to be light-induced in\r\n" + 
                "     plant cells (See, for example, Genetic Engineering of Plants, an\r\n" + 
                "     Agricultural Perspective, A. Cashmore, Plenum, New York (1983), pages\r\n" + 
                "     29-38; Coruzzi, G. et al., The Journal of Biological Chemistry, 258:1399\r\n" + 
                "     (1983), and Dunsmuir, P. et al., Journal of Molecular and Applied\r\n" + 
                "     Genetics, 2:285 (1983)).\r\n" + 
                "<BR><BR>[0084] In the present invention where polypeptide expression is desired,\r\n" + 
                "     it is generally desirable to include a polyadenylation region at the\r\n" + 
                "     3'-end of a CPL coding region. The polyadenylation region can be derived\r\n" + 
                "     a variety of plant genes, or from T-DNA. The 3' end sequence to be added\r\n" + 
                "     can be derived from, for example, the nopaline synthase or octopine\r\n" + 
                "     synthase genes, or alternatively from another plant gene, or less\r\n" + 
                "     preferably from any other eukaryotic gene.\r\n" + 
                "<BR><BR>[0085] An intron sequence can be added to the 5' untranslated region or\r\n" + 
                "     the coding sequence of the partial coding sequence to increase the amount\r\n" + 
                "     of the mature message that accumulates in the cytosol. Inclusion of a\r\n" + 
                "     spliceable intron in the transcription unit in both plant and animal\r\n" + 
                "     expression constructs has been shown to increase gene expression at both\r\n" + 
                "     the mRNA and protein levels up to 1000-fold. Buchman and Berg, Mol. Cell\r\n" + 
                "     Biol. 8:4395-4405 (1988); Callis et al., Genes Dev. 1:1183-1200 (1987).\r\n" + 
                "     Such intron enhancement of gene expression is typically greatest when\r\n" + 
                "     placed near the 5' end of the transcription unit. Use of maize introns\r\n" + 
                "     Adh1-S intron 1, 2, and 6, the Bronze-1 intron are known in the art. See\r\n" + 
                "     generally, The Maize Handbook, Chapter 116, Freeling and Walbot, Eds.,\r\n" + 
                "     Springer, N.Y. (1994).\r\n" + 
                "<BR><BR>[0086] In a preferred embodiment it will be useful to direct the CPL\r\n" + 
                "     protein to the chloroplast and other plastids. Typically this is effected\r\n" + 
                "     by the introduction of a chloroplast transit peptide which targets the\r\n" + 
                "     expressed protein to plastids and also facilitates its translocation into\r\n" + 
                "     the organelle. A number of chloroplast transit peptides are known and\r\n" + 
                "     could be used in the present expression cassette, including but not\r\n" + 
                "     limited to those derived from Pisum (Esutorera et al., JP 1986224990;\r\n" + 
                "     E00977), carrot (Luo et al, Plant Mol. Biol., 33 (4), 709-722\r\n" + 
                "     (1997;Z33383), Nicotiana (Bowler et al., EP 0359617; A09029), Oryza (de\r\n" + 
                "     Pater et al., Plant Mol. Biol., 15 (3), 399-406 (1990); X51911, as well\r\n" + 
                "     as synthetic sequences such as those provided in Herrera-Estrella et al.,\r\n" + 
                "     EP 0189707; U.S. Pat. No. 5,728,925; U.S. Pat. No. 5,717,084 (A10396 and\r\n" + 
                "     A10398). Preferred in the present invention is the chloroplast transit\r\n" + 
                "     peptide of the ribulose-1,5-bisphosphate carboxylase (Rubisco) small\r\n" + 
                "     subunit precursor protein isolated from any plant. The Rubisco small\r\n" + 
                "     subunit is well characterized from a variety of plants and the transit\r\n" + 
                "     peptide from any of them will be suitable for use in the present\r\n" + 
                "     invention. See for example Physcomitrella (Quatrano et al., AW599738);\r\n" + 
                "     Lotus (Poulsen et al., AW428760); Citrullus (J. S. Shin, AI563240);\r\n" + 
                "     Nicotiana (Appleby et al., Heredity (1997), 79(6), 557-563); alfalfa\r\n" + 
                "     (Khoudi et al., Gene (1997), 197(1/2), 343-351); potato and tomato (Fritz\r\n" + 
                "     et al., Gene (1993), 137(2), 271-4); wheat (Galili et al., Theor. Appl.\r\n" + 
                "     Genet. (1991), 81(1), 98-104); and rice (Xie et al., Sci. Sin., Ser. B\r\n" + 
                "     (Engl. Ed.) (1987), 30(7), 706-19). For example, transit peptides may be\r\n" + 
                "     derived from the Rubisco small subunit isolated from plants including but\r\n" + 
                "     not limited to, soybean, rapeseed, sunflower, cotton, corn, tobacco,\r\n" + 
                "     alfalfa, wheat, barley, oats, sorghum, rice, Arabidopsis, sugar beet,\r\n" + 
                "     sugar cane, canola, millet, beans, peas, rye, flax, and forage grasses.\r\n" + 
                "     Preferred for use in the present invention is the tomato Rubisco small\r\n" + 
                "     subunit precursor protein.\r\n" + 
                "<BR><BR>[0087] Chloroplast targeting sequences not only target the desired protein\r\n" + 
                "     to the chloroplast but also facilitates its translocation into the\r\n" + 
                "     organelle. This is accompanied by the cleavage of the transit peptide\r\n" + 
                "     from the mature polypeptide or protein at the appropriate transit peptide\r\n" + 
                "     cleavage site by a chloroplast processing protease, native to the\r\n" + 
                "     chloroplast. Accordingly the present chloroplast targeting sequence\r\n" + 
                "     comprises a suitable cleavage site for the correct processing of the\r\n" + 
                "     pre-protein to an active mature polypeptide contained within the\r\n" + 
                "     chloroplast. Preferred in the present invention is the chloroplast\r\n" + 
                "     targeting sequence of the tomato Rubisco small subunit precursor protein\r\n" + 
                "     having a cleavage site between the naturally occurring Cys and Met\r\n" + 
                "     residues that separate the transit peptide from the mature polypeptide.\r\n" + 
                "<BR><BR>[0088] The functional CPL expression cassette is used to transform a\r\n" + 
                "     suitable plant host for the expression of CPL and the production of pHBA\r\n" + 
                "     glucoside in the chloroplast. Virtually any plant host that is capable of\r\n" + 
                "     supporting the expression of the CPL gene will be suitable, however crop\r\n" + 
                "     plants are preferred for their ease of harvesting and large biomass.\r\n" + 
                "     Suitable plant hosts will include but are not limited to both monocots\r\n" + 
                "     and dicots such as soybean, rapeseed (Brassica napus, B. campestris),\r\n" + 
                "     sunflower (Helianthus annus), cotton (Gossypium hirsutum), corn, tobacco\r\n" + 
                "     (Nicotiana tabacum), alfalfa (Medicago sativa), wheat (Triticum sp),\r\n" + 
                "     barley (Hordeum vulgare), oats (Avena sativa, L), sorghum (Sorghum\r\n" + 
                "     bicolor), rice (Oryza sativa), Arabidopsis, sugar beet, sugar cane,\r\n" + 
                "     canola, millet, beans, peas, rye, flax, and forage grasses.\r\n" + 
                "<BR><BR>[0089] A variety of techniques are available and known to those skilled in\r\n" + 
                "     the art for introduction of constructs into a plant cell host. These\r\n" + 
                "     techniques include transformation with DNA employing A. tumefaciens or A.\r\n" + 
                "     rhizogenes as the transforming agent, electroporation, particle\r\n" + 
                "     acceleration, etc. [See for example, EP 295959 and EP 138341]. One\r\n" + 
                "     suitable method involves the use of binary type vectors of Ti and Ri\r\n" + 
                "     plasmids of Agrobacterium spp. Ti-derived vectors transform a wide\r\n" + 
                "     variety of higher plants, including monocotyledonous and dicotyledonous\r\n" + 
                "     plants, such as soybean, cotton, rape, tobacco, and rice [Pacciotti et\r\n" + 
                "     al. (1985) Bio/Technology 3:241; Byrne et al., (1987) Plant Cell, Tissue\r\n" + 
                "     and Organ Culture 8:3; Sukhapinda et al., (1987) Plant Mol. Biol.\r\n" + 
                "     8:209-216; Lorz et al., (1985) Mol. Gen. Genet. 199:178; Potrykus (1985)\r\n" + 
                "     Mol. Gen. Genet. 199:183; Park et al., J. Plant Biol. (1995), 38(4),\r\n" + 
                "     365-71; Hiei et al., Plant J. (1994), 6:271-282]. The use of T-DNA to\r\n" + 
                "     transform plant cells has received extensive study and is amply described\r\n" + 
                "     [EP 120516; Hoekema, In: The Binary Plant Vector System, Offset-drukkerij\r\n" + 
                "     Kanters B.V.; Alblasserdam (1985), Chapter V, Knauf, et al., Genetic\r\n" + 
                "     Analysis of Host Range Expression by Agrobacterium In: Molecular Genetics\r\n" + 
                "     of the Bacteria-Plant Interaction, Puhler, A. ed., Springer-Verlag, New\r\n" + 
                "     York, 1983, p. 245; and An, et al., EMBO J. (1985) 4:277-284]. For\r\n" + 
                "     introduction into plants, the chimeric genes of the invention can be\r\n" + 
                "     inserted into binary vectors as described in the examples.\r\n" + 
                "<BR><BR>[0090] Other transformation methods are available to those skilled in the\r\n" + 
                "     art, such as direct uptake of foreign DNA constructs [see EP 295959],\r\n" + 
                "     techniques of electroporation [see Fromm et al. (1986) Nature (London)\r\n" + 
                "     319:791] or high-velocity ballistic bombardment with metal particles\r\n" + 
                "     coated with the nucleic acid constructs [see Kline et al. (1987) Nature\r\n" + 
                "     (London) 327:70, and see U.S. Pat. No. 4,945,050]. Once transformed, the\r\n" + 
                "     cells can be regenerated by those skilled in the art. Of particular\r\n" + 
                "     relevance are the recently described methods to transform foreign genes\r\n" + 
                "     into commercially important crops, such as rapeseed [see De Block et al.,\r\n" + 
                "     (1989) Plant Physiol. 91:694-701], sunflower [Everett et al., (1987)\r\n" + 
                "     Bio/Technology 5:1201], soybean [McCabe et al., (1988) Bio/Technology\r\n" + 
                "     6:923; Hinchee et al., (1988) Bio/Technology 6:915; Chee et al., (1989)\r\n" + 
                "     Plant Physiol. 91:1212-1218; Christou et al., (1989) Proc. Natl. Acad.\r\n" + 
                "     Sci USA 86:7500-7504; EP 301749], rice [Hiei et al., Plant J. (1994),\r\n" + 
                "     6:271-282], and corn [Gordon-Kamm et al., (1990) Plant Cell 2:603-618;\r\n" + 
                "     Fromm et al., (1990) Biotechnology 8:833-839].\r\n" + 
                "<BR><BR>[0091] Transgenic plant cells are then placed in an appropriate selective\r\n" + 
                "     medium for selection of transgenic cells which are then grown to callus.\r\n" + 
                "     Shoots are grown from callus and plantlets generated from the shoot by\r\n" + 
                "     growing in rooting medium. The various constructs normally will be joined\r\n" + 
                "     to a marker for selection in plant cells. Conveniently, the marker may be\r\n" + 
                "     resistance to a biocide (particularly an antibiotic such as kanamycin,\r\n" + 
                "     G418, bleomycin, hygromycin, chloramphenicol, herbicide, or the like).\r\n" + 
                "     The particular marker used will allow for selection of transformed cells\r\n" + 
                "     as compared to cells lacking the DNA which has been introduced.\r\n" + 
                "     Components of DNA constructs including transcription cassettes of this\r\n" + 
                "     invention may be prepared from sequences which are native (endogenous) or\r\n" + 
                "     foreign (exogenous) to the host. By \"foreign\" it is meant that the\r\n" + 
                "     sequence is not found in the wild-type host into which the construct is\r\n" + 
                "     introduced. Heterologous constructs will contain at least one region\r\n" + 
                "     which is not native to the gene from which the transcription-initiation-r-\r\n" + 
                "    egion is derived. To confirm the presence of the transgenes in transgenic\r\n" + 
                "     cells and plants, a Southern blot analysis can be performed using methods\r\n" + 
                "     known to those skilled in the art.\r\n" + 
                "<BR><BR>[0092] CPL Translocation into the Chloroplast and Subsequent Processing\r\n" + 
                "<BR><BR>[0093] The present invention relies on the novel manipulation of a\r\n" + 
                "     chloroplast targeting sequence to effect the translocation of the CPL\r\n" + 
                "     gene product into chloroplasts with sufficient enzyme activity to yield\r\n" + 
                "     commercially useful amounts of pHBA. Applicant has discovered that a key\r\n" + 
                "     aspect of the invention is the inclusion of not only a transit peptide,\r\n" + 
                "     but also a naturally occurring chloroplast cleavage site and a small\r\n" + 
                "     portion of the transit peptide donor's mature N-terminus. The rational\r\n" + 
                "     was to improve chloroplast uptake and processing of the foreign protein\r\n" + 
                "     to obtain higher rates of conversion of chorismate to pHBA. However,\r\n" + 
                "     following uptake into the organelle, the transit peptide is\r\n" + 
                "     proteolytically removed by a chloroplast processing enzyme to yield a CPL\r\n" + 
                "     variant that has a small polypeptide extension attached at its\r\n" + 
                "     N-terminus. Unexpectedly, these additional amino acid resides do not\r\n" + 
                "     interfere with CPL enzyme activity, and transformed plants expressing the\r\n" + 
                "     instant chimeric protein accumulate significantly greater amounts of pHBA\r\n" + 
                "     derivatives than have previously been reported. With regard to pHBA\r\n" + 
                "     production, the need for this type of specificity has not been\r\n" + 
                "     appreciated in the art.\r\n" + 
                "<BR><BR>[0094] The only reported instance of an attempt to express CPL in\r\n" + 
                "     chloroplasts of living plants is recited in Siebert et al., Plant\r\n" + 
                "     Physiol. 112:811-819 (1996). However, there are a number of important\r\n" + 
                "     differences between the instant chimeric protein (e.g., TP-CPL) and the\r\n" + 
                "     chloroplast-targeted version of E. coli CPL (e.g., TP-UbiC) recited in\r\n" + 
                "     Siebert et al., Supra. For example, the instant chimera includes a\r\n" + 
                "     chloroplast targeting sequence having a well-defined cleavage site for\r\n" + 
                "     the efficient removal of the transit peptide. Additionally, removal of\r\n" + 
                "     the transit peptide at this specific site results in the addition of 5\r\n" + 
                "     extra amino acids at the N-terminal region of the mature CPL polypeptide.\r\n" + 
                "     In contrast, TP-UbiC recited in Siebert et al., Supra lacks a\r\n" + 
                "     well-defined cleavage site and in addition contains a stretch of nine\r\n" + 
                "     amino acids that are inserted between the putative transit peptide\r\n" + 
                "     cleavage site and the initiator methionine residue of E. coli CPL. These\r\n" + 
                "     differences are further elucidated in FIG. 1.\r\n" + 
                "<BR><BR>[0095] FIG. 1 shows an amino acid sequence alignment of the tomato Rubisco\r\n" + 
                "     small subunit precursor complete with its transit peptide (line 1),\r\n" + 
                "     TP-CPL (line 2), TP-UbiC (line 3), and E. coli CPL (line 1). The instant\r\n" + 
                "     chimeric protein (line 2) consists of the chloroplast transit peptide of\r\n" + 
                "     the tomato Rubisco small subunit precursor (green residues) plus the\r\n" + 
                "     first four amino acid residues of \"mature\" Rubisco, fused to the\r\n" + 
                "     initiator Met residue of E. coli CPL. Thus, TP-CPL contains not only the\r\n" + 
                "     entire transit peptide, but also the highly conserved cleavage site where\r\n" + 
                "     transit peptide removal would normally occur (e.g. between the Cys and\r\n" + 
                "     Met residues as indicated by the arrow). Assuming that in the chloroplast\r\n" + 
                "     TP-CPL is also cleaved at this position, the resulting protein would be a\r\n" + 
                "     CPL variant with five additional amino acid residues at its N-terminus.\r\n" + 
                "     Applicant has expressed the predicted chloroplast cleavage product of\r\n" + 
                "     TP-CPL in E. coli, purified it to homogeneity, and shown it to be fully\r\n" + 
                "     functional with regard to enzyme activity. Applicant has also\r\n" + 
                "     demonstrated that proteolytic processing does occur at the Cys-Met\r\n" + 
                "     junction, by purifying the \"mature\" polypeptide from transgenic tobacco\r\n" + 
                "     plants that express the instant chimeric protein and subjecting its\r\n" + 
                "     N-terminus to Edman degradation.\r\n" + 
                "<BR><BR>[0096] In contrast, as shown in line 3 of FIG. 1, TP-UbiC, (Siebert et\r\n" + 
                "     al., Supra) does not contain the cleavage site where transit peptide\r\n" + 
                "     removal would normally occur for the Rubisco small subunit precursor or\r\n" + 
                "     any amino acid residues belonging to the mature Rubisco polypeptide\r\n" + 
                "     (Mazur et al., Nuc Acids Res. 13:2373-2386 (1985); Berry-Lowe et al., J.\r\n" + 
                "     Mol. and Appl. Gen. 1, 483-498 (1982)). Indeed, the Met residue that\r\n" + 
                "     constitutes part of the scissile bond that is highly conserved in most\r\n" + 
                "     plant species has been replaced with an Ala residue, which may or may not\r\n" + 
                "     be recognized by the chloroplast processing enzyme. Additionally TP-UbiC,\r\n" + 
                "     contains a stretch of nine additional amino acid residues (indicated in\r\n" + 
                "     black letters) that are juxtapositioned between the Cys residue of the\r\n" + 
                "     putative cleavage site and the initiator Met residue of E. coli CPL (FIG.\r\n" + 
                "     1). These extra amino acids were introduced as a cloning artifact in the\r\n" + 
                "     construction of the TP-UbiC artificial fusion protein (Siebert et al,\r\n" + 
                "     Supra), and their potential detrimental effect on chloroplast import\r\n" + 
                "     and/or proteolytic processing was not explored. Regardless, even if\r\n" + 
                "     cleavage of the transit peptide were to occur at the Cys-Ala junction as\r\n" + 
                "     suggested, the resulting \"mature\" protein would contain nine extra amino\r\n" + 
                "     acid residues at its N-terminus that could potentially have a detrimental\r\n" + 
                "     effect on CPL enzyme activity (c.f. Table I, lines 2 and 4 of Siebert et\r\n" + 
                "     al, Supra).\r\n" + 
                "<BR><BR>EXAMPLES\r\n" + 
                "<BR><BR>[0097] The present invention is further defined in the following Examples.\r\n" + 
                "     It should be understood that these Examples, while indicating preferred\r\n" + 
                "     embodiments of the invention, are given by way of illustration only. From\r\n" + 
                "     the above discussion and these Examples, one skilled in the art can\r\n" + 
                "     ascertain the essential characteristics of this invention, and without\r\n" + 
                "     departing from the spirit and scope thereof, can make various changes and\r\n" + 
                "     modifications of the invention to adapt it to various usages and\r\n" + 
                "     conditions.\r\n" + 
                "<BR><BR>[0098] General Methods\r\n" + 
                "<BR><BR>[0099] Standard recombinant DNA and molecular cloning techniques used in\r\n" + 
                "     the Examples are well known in the art and are described by Sambrook, J.,\r\n" + 
                "     Fritsch, E. F. and Maniatis, T. Molecular Cloning: A Laboratory Manual;\r\n" + 
                "     Cold Spring Harbor Laboratory Press: Cold Spring Harbor, (1989)\r\n" + 
                "     (Maniatis) and by T. J. Silhavy, M. L. Bennan, and L. W. Enquist,\r\n" + 
                "     Experiments with Gene Fusions, Cold Spring Harbor Laboratory, Cold Spring\r\n" + 
                "     Harbor, N.Y. (1984) and by Ausubel, F. M. et al., Current Protocols in\r\n" + 
                "     Molecular Biology, pub. by Greene Publishing Assoc. and\r\n" + 
                "     Wiley-Interscience (1987).\r\n" + 
                "<BR><BR>[0100] Materials and methods suitable for the maintenance and growth of\r\n" + 
                "     bacterial cultures are well known in the art. Techniques suitable for use\r\n" + 
                "     in the following examples may be found as set out in Manual of Methods\r\n" + 
                "     for General Bacteriology (Phillipp Gerhardt, R. G. E. Murray, Ralph N.\r\n" + 
                "     Costilow, Eugene W. Nester, Willis A. Wood, Noel R. Krieg and G. Briggs\r\n" + 
                "     Phillips, eds), American Society for Microbiology, Washington, DC (1994))\r\n" + 
                "     or by Thomas D. Brock in Biotechnology: A Textbook of Industrial\r\n" + 
                "     Microbiology, Second Edition, Sinauer Associates, Inc., Sunderland, Mass.\r\n" + 
                "     (1989). All reagents, restriction enzymes and materials used for the\r\n" + 
                "     growth and maintenance of bacterial cells were obtained from Aldrich\r\n" + 
                "     Chemicals (Milwaukee, Wis.), DIFCO Laboratories (Detroit, Mich.),\r\n" + 
                "     GIBCO/BRL (Gaithersburg, Md.), or Sigma Chemical Company (St. Louis, Mo.)\r\n" + 
                "     unless otherwise specified.\r\n" + 
                "<BR><BR>[0101] Manipulations of genetic sequences were accomplished using the\r\n" + 
                "     suite of programs available from the Genetics Computer Group Inc.\r\n" + 
                "     (Wisconsin Package Version 9.0, Genetics Computer Group (GCG), Madison,\r\n" + 
                "     Wis.). Where the GCG program \"Pileup\" was used the gap creation default\r\n" + 
                "     value of 12, and the gap extension default value of 4 were used. Where\r\n" + 
                "     the CGC \"Gap\" or \"Bestfit\" programs were used the default gap creation\r\n" + 
                "     penalty of 50 and the default gap extension penalty of 3 were used. In\r\n" + 
                "     any case where GCG program parameters were not prompted for, in these or\r\n" + 
                "     any other GCG program, default values were used.\r\n" + 
                "<BR><BR>[0102] The meaning of abbreviations is as follows: \"h\" means hour(s),\r\n" + 
                "     \"min\" means minute(s), \"sec\" means second(s), \"d\" means day(s), \"mL\"\r\n" + 
                "     means milliliters, \"L\" means liters.\r\n" + 
                "<BR><BR>EXAMPLE 1\r\n" + 
                "<BR><BR>PCR-Cloning of E. coli CPL\r\n" + 
                "<BR><BR>[0103] Two PCR primers were used to amplify the E. coli ubiC gene from\r\n" + 
                "     genomic DNA, while adding unique restriction sites to its flanking\r\n" + 
                "     regions for subsequent ligation into a high copy number plasmid. This\r\n" + 
                "     gene codes for chorismate pyruvate lyase, which is referred to below as\r\n" + 
                "     CPL. The primers used for this purpose were based on the published DNA\r\n" + 
                "     sequences of the E. coli ubic gene (GenBank accession number M96268) and\r\n" + 
                "     consisted of the following nucleotides:\r\n" + 
                "<BR><BR>[0104] Primer 1--(SEQ ID NO:1):\r\n" + 
                "<BR><BR>[0105] 5'-CTA CTC ATT Tca tat gTC ACA CCC CGC GTT AA-3'\r\n" + 
                "<BR><BR>[0106] Primer 2--(SEQ ID NO:2):\r\n" + 
                "<BR><BR>[0107] 5'-CAT CTT ACT aga tct TTA GTA CAA CGG TGA CGC C-3'\r\n" + 
                "<BR><BR>[0108] The underlined bases hybridize to the target gene, while lower case\r\n" + 
                "     letters indicate the restriction sites (NdeI or BgIII) that were added to\r\n" + 
                "     the ends of the PCR primers.\r\n" + 
                "<BR><BR>[0109] Amplification of the E. coli ubic gene was achieved using Primers 1\r\n" + 
                "     and 2, and genomic DNA from E. coli strain W3110 (Campbell et al., Proc.\r\n" + 
                "     Natl. Acad. Sci. 75:2276-2284 (1978)). Primer 1 hybridizes at the start\r\n" + 
                "     of the gene and introduces a NdeI site at the protein's initiation codon,\r\n" + 
                "     while Primer 2 hybridizes at the opposite end and provides a BgIII site\r\n" + 
                "     just past the termination codon. The 100 .mu.l PCR reactions contained\r\n" + 
                "     .about.100 ng of genomic DNA and both primers at a final concentration of\r\n" + 
                "     0.5 .mu.M. The other reaction components were provided by the GeneAmp PCR\r\n" + 
                "     Reagent Kit (Perkin Elmer), according to the manufacturer's protocol.\r\n" + 
                "     Amplification was carried out in a DNA Thermocycler 480 (Perkin Elmer)\r\n" + 
                "     for 22 cycles, each comprising 1 min at 94.degree. C., 1 min at\r\n" + 
                "     55.degree. C., and 1 min at 72.degree. C. Following the last cycle, there\r\n" + 
                "     was a 7-min extension period at 72.degree. C.\r\n" + 
                "<BR><BR>[0110] The PCR product was cut with NdeI and BgIII, and the resulting\r\n" + 
                "     fragment was ligated into the E. coli expression vector, pET-24a (+)\r\n" + 
                "     (Novagen) that had been digested with NdeI and BamHI. The ligation\r\n" + 
                "     reaction mixture was used to transform E. coli DH1OB electocompetent\r\n" + 
                "     cells (GibcoBRL) using a BTX Transfector 100 (Biotechnologies and\r\n" + 
                "     Experimental Research Inc.) according to the manufacturer's protocol;\r\n" + 
                "     growth was selected on LB media that contained kanamycin (50 .mu.g/ml).\r\n" + 
                "     Transformants that contained plasmids with a CPL insert were identified\r\n" + 
                "     through PCR reactions, using primers 1 and 2 and individual resuspended\r\n" + 
                "     colonies as the source of template; from hereon, this technique is simply\r\n" + 
                "     referred to as \"colony PCR\". Plasmid DNA was isolated from a\r\n" + 
                "     representative colony that yielded a PCR product of the correct size, and\r\n" + 
                "     the entire insert corresponding to the CPL was sequenced completely to\r\n" + 
                "     check for PCR errors; none were found. The plasmid that was selected for\r\n" + 
                "     further manipulation is referred to below as \"pET24a-CPL\". The nucleotide\r\n" + 
                "     sequence of the ORF for CPL in the pET24a E. coli expression construct\r\n" + 
                "     and its predicted primary amino acid sequence are set forth in SEQ ID\r\n" + 
                "     NO:3 and SEQ ID NO:4, respectively. Note that the coding region is\r\n" + 
                "     identical to the ORF that is given in GenBank accession number M96268.\r\n" + 
                "<BR><BR>EXAMPLE 2\r\n" + 
                "<BR><BR>Overexpression, Purification, and Characterization of Recombinant E. coli\r\n" + 
                "     CPL\r\n" + 
                "<BR><BR>[0111] To generate sufficient quantities of CPL for enzyme\r\n" + 
                "     characterization and antibody production, pET24a-CPL was introduced into\r\n" + 
                "     E. coli BL21(DE3). This was done by electroporation using a BTX\r\n" + 
                "     Transfector 100 (Biotechnologies and Experimental Research Inc.)\r\n" + 
                "     according to the manufacturer's protocol. Growth was selected on LB media\r\n" + 
                "     that contained kanamycin (50 .mu.g/ml) and a single colony was selected\r\n" + 
                "     for further manipulation. For production of recombinant protein, the\r\n" + 
                "     plasmid-bearing strain was grown in liquid culture at 30.degree. C. in\r\n" + 
                "     the media described above, and the cells were induced with 0.15 mM IPTG\r\n" + 
                "     at an A.sub.600 nm of .about.0.8. Following a 4.5-hr induction period\r\n" + 
                "     under the same growth conditions, the cells were harvested by\r\n" + 
                "     centrifugation and stored at -80.degree. C. for subsequent use.\r\n" + 
                "     Subsequent steps were at 0-4.degree. C.\r\n" + 
                "<BR><BR>[0112] Frozen cell pellets were resuspended in .about.3 volumes of 0.1 M\r\n" + 
                "     Tris-HCl (pH 7.7), 5 mM MgSO.sub.4, 1 mM dithiothreitol, 0.03 mg/ml Dnase\r\n" + 
                "     I, 0.5 mM phenylmethanesulfonyl fluoride, and passed twice through a\r\n" + 
                "     French pressure cell at 20,000 psi. Debris was removed by centrifugation\r\n" + 
                "     (43,0000.times. g, 1 h), and the cell-free extract, containing .about.30\r\n" + 
                "     mg of protein/mL, was supplemented with glycerol (5%) and stored at\r\n" + 
                "     -80.degree. C. for subsequent use. Protein concentration was determined\r\n" + 
                "     by the method of Lowry et al. (Lowry et al., J. Biol Chem. 193:265-275\r\n" + 
                "     (1951)), using BSA as a standard. SDS-PAGE analysis of the cell-free\r\n" + 
                "     extract revealed that the recombinant protein was well expressed in E.\r\n" + 
                "     coli BL21(DE3) under the growth conditions described, at levels exceeding\r\n" + 
                "     15% of the total soluble protein. However, only about 25% of the\r\n" + 
                "     recombinant protein was recovered in the soluble fraction of the French\r\n" + 
                "     press extract and this material was used for purification as described\r\n" + 
                "     below.\r\n" + 
                "<BR><BR>[0113] The first step in the purification entailed anion exchange\r\n" + 
                "     chromatography. An aliquot (1.0 mL) of the E. coli cell-free extract\r\n" + 
                "     containing recombinant CPL was rapidly thawed to room temperature,\r\n" + 
                "     diluted 1:1 with deionized water, and filtered through a 0.2 .mu.m\r\n" + 
                "     Acrodisc filter (Gelman Sciences, Cat. No. 4192). The entire sample was\r\n" + 
                "     applied to a Mono Q HR 5/5 column (Pharmacia Biotech Inc), that was\r\n" + 
                "     developed at 25.degree. C. with Buffer Q (50 mM Tris-HCl, pH 7.7, 10 mM\r\n" + 
                "     sodium sulfite, 1 mM EDTA) at a flow rate of 1 ml/min. Under these\r\n" + 
                "     conditions, recombinant CPL does not adsorb to the anion exchange resin\r\n" + 
                "     and elutes from the column isocratically during the first few minutes of\r\n" + 
                "     the run. The column flow-through was collected in a single tube,\r\n" + 
                "     supplemented with 5% (w/v) glycerol, and concentrated to a final volume\r\n" + 
                "     of 450 .mu.L in a Centricon-10 (Amicon Inc.) at 4.degree. C. Following\r\n" + 
                "     this simple procedure, the recombinant protein was .about.90% pure as\r\n" + 
                "     judged by SDS-PAGE (Laemmli U., Nature 227:680-685 (1970)) and Coomassie\r\n" + 
                "     Blue staining. In the next step, 200 .mu.L of the concentrated sample was\r\n" + 
                "     applied to a 7.5.times.600 mm TSK G3000SW gel filtration column (TOSOH\r\n" + 
                "     Corp.) that was preequilibrated with Buffer Q containing 0.3 M NaCl. The\r\n" + 
                "     column was developed at a flow rate of 1.0 mL/min (25.degree. C.), and\r\n" + 
                "     highly purified recombinant CPL eluted between 19.7-21 min. The latter\r\n" + 
                "     was kept on ice while the remaining half of the sample was processed in\r\n" + 
                "     an identical manner. The peak fractions from the two gel filtration\r\n" + 
                "     columns were pooled, supplemented with glycerol (5%), concentrated to\r\n" + 
                "     .about.12 mg of protein/mL, and stored at -80.degree. C. for subsequent\r\n" + 
                "     use. The yield of purified protein was .about.3.7 mg, corresponding to\r\n" + 
                "     about 12% of the total protein present in the cell-free extract. Visual\r\n" + 
                "     inspection of overloaded Coomassie-stained gels indicated the final\r\n" + 
                "     preparation of recombinant protein was &gt;98% pure.\r\n" + 
                "<BR><BR>[0114] Purified recombinant CPL was subjected to Edman degradation, which\r\n" + 
                "     revealed that the protein's initiator Met residue is removed in E. coli.\r\n" + 
                "     Apart from this minor posttranslational modification, however, the first\r\n" + 
                "     13 amino acids of recombinant CPL were identical to residues 2-14 of the\r\n" + 
                "     protein that is shown in SEQ ID NO:4 (e.g., ORF of the authentic E. coil\r\n" + 
                "     protein). The protomer molecular mass of purified recombinant CPL was\r\n" + 
                "     18644.6 daltons as determined by electrospray ionization mass\r\n" + 
                "     spectrometry. This value is in excellent agreement with the molecular\r\n" + 
                "     mass that is predicted from the DNA sequence (18645.49 daltons) if the\r\n" + 
                "     initiator Met residue is not included. Based on these observations, it is\r\n" + 
                "     reasonable to conclude that the initiator Met residue is also cleaved off\r\n" + 
                "     of the native E. coli protein, since the nucleotide sequence of the\r\n" + 
                "     latter is identical to recombinant CPL.\r\n" + 
                "<BR><BR>[0115] A continuous spectrophotometric assay was developed to assess the\r\n" + 
                "     catalytic activity of the purified recombinant protein. The assay is\r\n" + 
                "     based on the increase in absorbance at 246 nm that accompanies the\r\n" + 
                "     conversion of chorismate to pHBA as result of the formation of the\r\n" + 
                "     aromatic ring of the latter. Initial rates of product formation were\r\n" + 
                "     measured at 25.degree. C. in a quartz cuvette that contained 90 mM\r\n" + 
                "     Tris-HCl (pH 7.6), 0.2 M NaCl, 100 .mu.M barium chorismate (Sigma), and\r\n" + 
                "     various amounts of purified recombinant CPL; reactions were initiated\r\n" + 
                "     with enzyme. Product formation was calculated from the change in\r\n" + 
                "     absorbance using an extinction coefficient of 11,220 M-1 for pHBA at 246\r\n" + 
                "     nm. The latter was determined under identical conditions at\r\n" + 
                "     concentrations of pHBA ranging from 5 .mu.M-100 .mu.M; the absorbance of\r\n" + 
                "     light was directly proportional to pHBA concentration. Based on the above\r\n" + 
                "     assay, the turnover number for purified recombinant CPL at 25.degree. C.\r\n" + 
                "     was .about.36 min.sup.-1. Two other preparations of the same recombinant\r\n" + 
                "     protein, purified on a much larger scale, yielded slightly higher\r\n" + 
                "     turnover numbers under the same conditions (e.g., 41 min.sup.-1 and 42\r\n" + 
                "     min.sup.-1). The only value that is available in the literature for this\r\n" + 
                "     enzyme is 49 min.sup.-1 (Nichols et al., J. Bacteriol. 174:5309-5316\r\n" + 
                "     (1992)), but the assay was conducted at 37.degree. C. Assuming that the\r\n" + 
                "     CPL enzyme reaction is characterized by a Q10 (temperature coefficient)\r\n" + 
                "     of at least 2, these observations indicate that the purified recombinant\r\n" + 
                "     protein described above is fully active.\r\n" + 
                "<BR><BR>EXAMPLE 3\r\n" + 
                "<BR><BR>Construction of a Chloroplast-targeted Version of CPL: TP-CPL\r\n" + 
                "<BR><BR>[0116] Chorismate, the physiological substrate of CPL, is an important\r\n" + 
                "     branchpoint intermediate for the synthesis of numerous aromatic\r\n" + 
                "     compounds, including the amino acids phenylalanine and tyrosine. In\r\n" + 
                "     plants, chorismate is formed in the shikimate pathway which is localized\r\n" + 
                "     in chloroplasts and other types of plastids (Siebert et al., Plant\r\n" + 
                "     Physiol. 112:811-819 (1996)). It was therefore essential to provide CPL\r\n" + 
                "     with an N-terminal chloroplast targeting sequence that would efficiently\r\n" + 
                "     direct the foreign protein to chloroplasts, the site of chorismate\r\n" + 
                "     production. This was accomplished by constructing a chimeric protein that\r\n" + 
                "     consists of a chloroplast targeting sequence that is derived from the\r\n" + 
                "     tomato Rubisco small subunit precursor protein fused to the initiator Met\r\n" + 
                "     residue of CPL; the resulting fusion protein is referred to below as\r\n" + 
                "     \"TP-CPL\". To generate a DNA fragment corresponding to the transit peptide\r\n" + 
                "     of the Rubisco small subunit and first four amino acid residues of\r\n" + 
                "     \"mature\" Rubisco, PCR was employed. The target for amplification was the\r\n" + 
                "     plasmid pTSSl-91-(#2)-IBI (Siebert et al., Plant Physiol. 112:811-819\r\n" + 
                "     (1996)), which contains a full-length cDNA clone of the tomato Rubisco\r\n" + 
                "     small subunit precursor for rbcS2 (Sugita et al., Mol Gen Genet.\r\n" + 
                "     209:247-256 (1987); Siebert et al., Plant Physiol. 112:811-819 (1996)).\r\n" + 
                "     The following primers were used this reaction:\r\n" + 
                "<BR><BR>[0117] Primer 3\r\n" + 
                "<BR><BR>[0118] 5'-CTA CTC ACT TAG ATC Tcc atg gCT TCC TCT GTC ATT TCT-3' (SEQ ID\r\n" + 
                "     NO:5)\r\n" + 
                "<BR><BR>[0119] Primer 4\r\n" + 
                "<BR><BR>[0120] 5'-CAT CTT ACT cat atg CCA CAC CTG CAT GCA GC-3' (SEQ ID NO:6)\r\n" + 
                "<BR><BR>[0121] The underlined portion of Primer 3 hybridizes to the first 21\r\n" + 
                "     nucleotides of the Rubisco small subunit precursor and introduces an NcoI\r\n" + 
                "     site (lower case letters) at the initiator Met residue at the start of\r\n" + 
                "     the chloroplast targeting sequence. As indicated, this primer also\r\n" + 
                "     contains a BgIII site (bold letters) at its 5' end, that is just upstream\r\n" + 
                "     from the NcoI site. Primer 4 hybridizes at the other end of the\r\n" + 
                "     chloroplast targeting sequence to nucleotides 167-184 of the ORF of the\r\n" + 
                "     Rubisco small subunit precursor. A unique NdeI site was engineered into\r\n" + 
                "     this primer (lower case letters) to allow attachment of the PCR fragment\r\n" + 
                "     containing the chloroplast targeting sequence to the NdeI site that is\r\n" + 
                "     situated at the start codon of CPL in the pET-24a expression construct.\r\n" + 
                "     The 100-.mu.l PCR reaction contained .about.75 ng of pTSS 1-91-(#2)-IBI\r\n" + 
                "     and Primers 3 and 4 both at a final concentration of .about.0.9 .mu.M.\r\n" + 
                "     Amplification was carried out in a DNA Thermocycler 480 (Perkin Elmer)\r\n" + 
                "     for 25 cycles, each comprising 1 min at 94.degree. C., 1 min at\r\n" + 
                "     55.degree. C., and 1 min at 72.degree. C.; the last cycle was followed by\r\n" + 
                "     a 7-min extension period at 72.degree. C. The PCR product was digested\r\n" + 
                "     with BgIII and NdeI, and ligated into pET24a-CPL that had been cleaved\r\n" + 
                "     with the same restriction enzymes to remove a small DNA fragment (106 bp)\r\n" + 
                "     that contained only vector sequence, including the T7 promoter. The\r\n" + 
                "     ligation reaction mixture was introduced into E. coli DH10B using\r\n" + 
                "     electroporation, and growth was selected on LB media with kanamycin (50\r\n" + 
                "     .mu.g/ml). Transformants harboring plasmids with the inserted chloroplast\r\n" + 
                "     targeting sequence were identified by colony PCR using Primers 2 and 3. A\r\n" + 
                "     representative plasmid yielding a PCR product of the correct size was\r\n" + 
                "     selected for further manipulation; this plasmid is referred to below as\r\n" + 
                "     \"pET24a-TP-CPL\". To confirm the absence of PCR errors, the region of the\r\n" + 
                "     plasmid corresponding to the amplified chloroplast targeting sequence was\r\n" + 
                "     sequenced completely using custom designed primers. The nucleotide\r\n" + 
                "     sequence of the ORF for TP-CPL and its predicted primary amino acid\r\n" + 
                "     sequence are set forth in SEQ ID NO:7 and SEQ ID NO:8, respectively.\r\n" + 
                "<BR><BR>EXAMPLE 4\r\n" + 
                "<BR><BR>The Predicted Chloroplast Cleavage Product of TP-CPL is Fully Active\r\n" + 
                "<BR><BR>[0122] A DNA fragment corresponding to the amino acid sequence of the\r\n" + 
                "     predicted chloroplast cleavage product of TP-CPL (e.g., MQVWH-CPL) was\r\n" + 
                "     generated by PCR using the insert in plasmid pet24a-TP-CPL as a template.\r\n" + 
                "     The following primers were used for this reaction:\r\n" + 
                "<BR><BR>[0123] Primer 5\r\n" + 
                "<BR><BR>[0124] 5'-CTA CTC ATT Tga aga cTG CAT GCA GGT GTG GCA T-3' (SEQ ID NO:9):\r\n" + 
                "<BR><BR>[0125] Primer 6\r\n" + 
                "<BR><BR>[0126] 5'-CAT CTT ACT gtc gac TTT AGT ACA ACG GTG ACG C-3' (SEQ ID NO: I0)\r\n" + 
                "<BR><BR>[0127] The underlined portion of Primer 5 binds at the 5' end of the\r\n" + 
                "     TP-CPL gene insert and introduces a unique BBSI site (lower case letters)\r\n" + 
                "     just upstream from the starting Met residue of the predicted chloroplast\r\n" + 
                "     cleavage product (henceforth referred to as \"ATP-CPL\"). Primer 6\r\n" + 
                "     hybridizes at the opposite end of the gene insert and provides a unique\r\n" + 
                "     SalI site (lower case letters) just past the termination codon. The PCR\r\n" + 
                "     product was cut with BBSI (which leaves an NcoI-compatible \"sticky end\")\r\n" + 
                "     and SalI, and the resulting fragment was ligated into the E. coli\r\n" + 
                "     expression vector, pET-24d (+) (Novagen) that was digested with NcoI and\r\n" + 
                "     SalI. The ligation reaction mixture was used to transform E. coli DH10B\r\n" + 
                "     electro-competent cells (GibcoBRL) using a BTX Transfector 100\r\n" + 
                "     (Biotechnologies and Experimental Research Inc.) according to the\r\n" + 
                "     manufacturer's protocol; growth was selected on LB media that contained\r\n" + 
                "     kanamycin (50 .mu.g/ml). Transformants that contained plasmids with a\r\n" + 
                "     ATP-CPL insert were identified by colony PCR, using appropriate primers.\r\n" + 
                "     A representative plasmid (e.g., pET24a-ATP-CPL) was isolated from a\r\n" + 
                "     colony that yielded a PCR product of the correct size, and the insert\r\n" + 
                "     corresponding to the ATP-CPL was completely sequenced to confirm the\r\n" + 
                "     absence of PCR errors.\r\n" + 
                "<BR><BR>[0128] To express the recombinant protein for purification and kinetic\r\n" + 
                "     analysis, pET24a-ATP-CPL was introduced into E. coli BL21 (DE3) using\r\n" + 
                "     electroporation. The transformed cells were plated on LB media with\r\n" + 
                "     kanamycin (50 .mu.g/ml), and a representative colony was selected for\r\n" + 
                "     further manipulation. A 300-ml culture was grown at 30.degree. C. in the\r\n" + 
                "     media described above, and IPTG was added to a final concentration of\r\n" + 
                "     0.15 mM at an A.sub.600 nm of 0.8. Following a 4.5-hr induction period\r\n" + 
                "     under the same conditions, the cells were harvested by centrifugation and\r\n" + 
                "     stored at -80.degree. C. Subsequent steps were at 0-4.degree. C., unless\r\n" + 
                "     otherwise specified.\r\n" + 
                "<BR><BR>[0129] The frozen cell pellet was resuspended in 2.5 ml of a solution\r\n" + 
                "     containing 0.1 M Tris-HCl (pH 7.7), 5 mM MgSO.sub.4, 1 mM dithiothreitol,\r\n" + 
                "     0.03 mg/ml Dnase I, 0.5 mM phenylmethanesulfonyl fluoride, and passed\r\n" + 
                "     twice through a French pressure cell at 20,000 psi. The cell-free extract\r\n" + 
                "     was subjected to centrifugation (43,000.times. g, 25 min), and the\r\n" + 
                "     supernatant (4.5 ml) was carefully removed, supplemented with 5% glycerol\r\n" + 
                "     and stored at -80.degree. C. for subsequent use. The purification\r\n" + 
                "     protocol for ATP-CPL was essentially identical to that described for\r\n" + 
                "     unmodified, recombinant E. coli CPL. Briefly, the entire sample above was\r\n" + 
                "     thawed and concentrated to a final volume of 2.5 ml using a Centriprep-10\r\n" + 
                "     (Amicon Inc). The sample was then exchanged into Buffer Q using a PD-10\r\n" + 
                "     gel filtration column (Pharmacia Biotech Inc) that was preequilibrated\r\n" + 
                "     with Buffer Q, according to the manufacturer's protocol. The volume was\r\n" + 
                "     reduced to 2 ml in a Centriprep-10, and the entire sample was loaded onto\r\n" + 
                "     a Mono Q HR 10/10 column (Pharmacia Biotech Inc), that was developed at 4\r\n" + 
                "     ml/min (25.degree. C.) with Buffer Q. The material eluting between 2-3\r\n" + 
                "     minutes was collected, and glycerol was added to a final concentration of\r\n" + 
                "     5% (v/v). The sample was concentrated to 200 11 in a Centricon-10 (Amicon\r\n" + 
                "     Inc), and applied to a 7.5.times.600 mm TSK G3000SW gel filtration column\r\n" + 
                "     (TOSOH Corp.). The column was developed at 1 ml/min with Buffer Q\r\n" + 
                "     containing 0.3 M NaCl (25.degree. C.), and recombinant .DELTA.TP-CPL\r\n" + 
                "     eluted between 20.7-22 min. The fraction containing the purified\r\n" + 
                "     recombinant protein was supplemented with 5% glycerol, concentrated to\r\n" + 
                "     .about.0.7 mg of protein per ml, and stored at -80.degree. C. for\r\n" + 
                "     subsequent use.\r\n" + 
                "<BR><BR>[0130] The enzymatic activity of purified, recombinant ATP-CPL was\r\n" + 
                "     determined at 25.degree. C., using the spectrophotometric assay that was\r\n" + 
                "     described in Example 2. Under these conditions, the turnover number was\r\n" + 
                "     40.7 min-1. This value is virtually identical to that obtained with\r\n" + 
                "     purified, recombinant, E. coli CPL without an N-terminal extension (e.g.\r\n" + 
                "     36-42 min.sup.-1). This observation clearly demonstrates that the 5 extra\r\n" + 
                "     amino acid residues that are fused to the N-terminus of .DELTA.TP-CPL do\r\n" + 
                "     not compromise enzyme activity, and further suggests that the predicted\r\n" + 
                "     chloroplast cleavage product of TP-CPL is probably fully active.\r\n" + 
                "<BR><BR>EXAMPLE 5\r\n" + 
                "<BR><BR>In Vitro Protein Import: TP-CPL is Imported into Isolated Chloroplasts\r\n" + 
                "<BR><BR>[0131] Before introducing TP-CPL into higher plants it was important to\r\n" + 
                "     show that it could be taken up by chloroplasts. This was done by\r\n" + 
                "     synthesizing a radioactive version of the artificial fusion protein and\r\n" + 
                "     subjecting it to classical chloroplast protein import experiments. The\r\n" + 
                "     first step was to generate a DNA construct that could be used to\r\n" + 
                "     radiolabel the protein with [.sup.35S]methionine for transport\r\n" + 
                "     experiments. To do this, the sequence encoding TP-CPL was modified for\r\n" + 
                "     insertion into the MscI and BgIII sites of the in vitro\r\n" + 
                "     transcription/translation vector, pCITE4a(+) (Novagen) using Primers 7\r\n" + 
                "     and 8, and the insert in plasmid pet24A-TP-CPL as a template for\r\n" + 
                "     PCR-amplification.\r\n" + 
                "<BR><BR>[0132] Primer 7\r\n" + 
                "<BR><BR>[0133] 5'-CTA CTC ATT tgg cca GCT CTG TCA TTT CTT CAG CAG C-3' (SEQ ID\r\n" + 
                "     NO:11)\r\n" + 
                "<BR><BR>[0134] Primer 8\r\n" + 
                "<BR><BR>[0135] 5'-CAT CTT ACT aga tct TTA GTA CAA CGG TGA C-3' (SEQ ID NO:12)\r\n" + 
                "<BR><BR>[0136] Primer 7 hybridizes to a stretch of nucleotides just past the start\r\n" + 
                "     codon of TP-CPL (underlined region), and incorporates a unique MscI site\r\n" + 
                "     (indicated by lower case letters) at the initiator Met residue. Primer 8\r\n" + 
                "     binds at the other end of the gene insert and introduces a unique BgIII\r\n" + 
                "     site immediately after the stop codon. Neither primer introduces any\r\n" + 
                "     amino acid changes in the artificial fusion protein. The resulting PCR\r\n" + 
                "     fragment was digested with MscI and BgIII, and ligated into pCITE4a(+)\r\n" + 
                "     that was cut with MscI and BamHI; BgIII and BamHi generate compatible\r\n" + 
                "     \"sticky ends\". The ligation reaction mixture was introduced into E. coli\r\n" + 
                "     DH1 OB using electroporation, and the transformed cells were plated on LB\r\n" + 
                "     media that contained ampicillin (100 .mu.g/ml). A representative colony\r\n" + 
                "     harboring a plasmid with the correct insert (identified by colony PCR,\r\n" + 
                "     using appropriate primers) was selected for further manipulation. The\r\n" + 
                "     plasmid DNA was sequenced completely to confirm the absence of PCR\r\n" + 
                "     errors.\r\n" + 
                "<BR><BR>[0137] Next, the plasmid construct described above was subjected to in\r\n" + 
                "     vitro transcription/translation using [.sup.35S]methionine and the\r\n" + 
                "     \"Single Tube Protein System 2, T7\" kit (Novagen), according to the\r\n" + 
                "     vendor's protocol. Reactions were terminated with 2.times. import buffer\r\n" + 
                "     containing 60 mM unlabeled methionine (Viitanen et al., J. Biol. Chem.\r\n" + 
                "     263:15000-15007 (1988)). Chloroplast were isolated from 14-day-old pea\r\n" + 
                "     seedlings (Pisum sativum) and subjected to in vitro import assays\r\n" + 
                "     (Viitanen et al., J. Biol. Chem. 263:15000-15007 (1988)) using\r\n" + 
                "     radiolabeled TP-CPL. Protease post-treatment was used to distinguish\r\n" + 
                "     between bound and imported polypeptides (Cline et al., J. Biol. Chem.\r\n" + 
                "     260:3691-3696 (1985)). Intact plastids were then repurified by\r\n" + 
                "     centrifugation through Percoll cushions, resupended in 150 .mu.l of\r\n" + 
                "     2.times. gel sample buffer, and analyzed by SDS-PAGE/fluorography as\r\n" + 
                "     previously described (Viitanen et al., J. Biol. Chem. 263:15000-15007\r\n" + 
                "     (1988)).\r\n" + 
                "<BR><BR>[0138] In vitro transcription/translation of TP-CPL resulted in the\r\n" + 
                "     synthesis of a radioactive polypeptide with an apparent molecular mass of\r\n" + 
                "     .about.25 kDa (based on migration during SDS-PAGE (Laemmli, U. K., Nature\r\n" + 
                "     227:680-685 (1970)), consistent with the value predicted from its DNA\r\n" + 
                "     sequence (25188 Da). In the presence of ATP, this polypeptide was taken\r\n" + 
                "     up by chloroplasts and processed to a smaller size, which appeared to\r\n" + 
                "     co-migrate with Coomassie-stained purified, recombinant .DELTA.TP-CPL\r\n" + 
                "     (e.g. the predicted chloroplast cleavage product of TP-CPL). Classical\r\n" + 
                "     protease protection experiments established that the radioactive\r\n" + 
                "     polypeptide that was recovered with intact chloroplasts following import\r\n" + 
                "     assays had actually been internalized.\r\n" + 
                "<BR><BR>[0139] In contrast, when chloroplasts were incubated under conditions that\r\n" + 
                "     do support protein import (e.g., in the dark, without ATP), uptake and\r\n" + 
                "     processing of TP-CPL were not observed. Under non-energized conditions,\r\n" + 
                "     the only radioactive band recovered with intact plastids was the\r\n" + 
                "     full-length fusion protein, TP-CPL. Moreover, the radioactive band\r\n" + 
                "     corresponding to the latter completely disappeared after treatment with\r\n" + 
                "     protease, demonstrating that it had not been imported but was merely\r\n" + 
                "     bound to the outer chloroplast membrane. Taken together, these results\r\n" + 
                "     clearly demonstrate that the chloroplast targeting sequence that is\r\n" + 
                "     attached to the N-terminus of TP-CPL, is able to direct the artificial\r\n" + 
                "     fusion protein to chloroplasts, and after uptake into the organelle,\r\n" + 
                "     proteolytic processing occurs in the expected manner.\r\n" + 
                "<BR><BR>EXAMPLE 6\r\n" + 
                "<BR><BR>Construction of the Expression Plasmid Used for Tobacco and Arabidopsis\r\n" + 
                "     Transformation\r\n" + 
                "<BR><BR>[0140] Having established that TP-CPL is efficiently taken up by\r\n" + 
                "     chloroplasts (Example 5) and cleaved to a novel protein with high CPL\r\n" + 
                "     activity (Example 4) it was decided to introduce it into plants. To\r\n" + 
                "     generate a construct that could be used for constitutive expression in\r\n" + 
                "     tobacco and arabidopsis, the DNA fragment corresponding to the\r\n" + 
                "     full-length TP-CPL fusion protein was subcloned into a modified version\r\n" + 
                "     of plasmid pML63. The latter was derived from pML40, which contains the\r\n" + 
                "     following genetic elements: a CaMV 35S promoter, a cab leader sequence,\r\n" + 
                "     the uidA coding region, and the NOS polyadenylation signal sequence.\r\n" + 
                "     Briefly, the CaMV 35S promoter is a 1.3 kb DNA fragment that extends 8\r\n" + 
                "     base pairs past the transcription start site (Odell et al., (1985) Nature\r\n" + 
                "     303:810-812). Operably linked to its 3' end is the cab leader sequence, a\r\n" + 
                "     60 bp untranslated double-stranded piece of DNA that was obtained from\r\n" + 
                "     the chlorophyll a/b binding protein gene 22L (Harpster et al. (1988) Mol.\r\n" + 
                "     Gen. Genet. 212:182-190). Fused to the 3' end of the cab leader is the\r\n" + 
                "     uidA gene (Jefferson et al. (1987) EMBO J. 6:3901) that encodes the\r\n" + 
                "     protein .beta.-glucuronidase (e.g., \"GUS\"). Finally, attached to 3' end\r\n" + 
                "     of the GUS gene is an 800 bp DNA fragment containing the polyadenylation\r\n" + 
                "     signal sequence from the nopaline synthase (e.g. \"NOS\") gene (Depicker et\r\n" + 
                "     al. (1982) J. Mol. Appl. Genet. 1:561-564). These DNA fragments, together\r\n" + 
                "     comprising a 35S-GUS chimeric gene, were inserted by standard cloning\r\n" + 
                "     techniques into the vector pGEM9Zf (-) (Promega; Madison Wis.) to yield\r\n" + 
                "     plasmid pMH40.\r\n" + 
                "<BR><BR>[0141] Plasmid pML63, which is basically the same as pMH40 but has a\r\n" + 
                "     truncated version of the 3' NOS terminator sequence, was generated in the\r\n" + 
                "     following manner. First, pMH40 was digested with Sal I and the two\r\n" + 
                "     resulting DNA fragments of 4.03 kb and 2.9 kb were re-ligated to yield a\r\n" + 
                "     plasmid with the 35S promoter/cab22 leader/GUS gene/3' NOS terminator\r\n" + 
                "     cassette in the opposite orientation. The resulting construct was then\r\n" + 
                "     digested with Asp718 I and Hind III to release a 770 bp fragment that\r\n" + 
                "     contained the 3' NOS terminator sequence. The latter was discarded and\r\n" + 
                "     replaced with a shorter version that was generated by PCR using pMH40 as\r\n" + 
                "     a template and Primers 9 and 10.\r\n" + 
                "<BR><BR>[0142] Primer 9:\r\n" + 
                "<BR><BR>[0143] 5'-CCC GGG GGT ACC TAA AGA AGG AGT GCG TCG AAG-3' (SEQ ID NO:13):\r\n" + 
                "<BR><BR>[0144] Primer 10:\r\n" + 
                "<BR><BR>[0145] 5'-GAT ATC AAG CTT TCT AGA GTC GAC ATC GAT CTA GTA ACA TAG ATG A 3'\r\n" + 
                "     (SEQ ID NO: 14):\r\n" + 
                "<BR><BR>[0146] The PCR product was digested with Hind III and Asp718 I to yield a\r\n" + 
                "     298 bp fragment that contains 279 bp of the 3' NOS terminator sequence,\r\n" + 
                "     starting at nucleotide 1277 (the TAA stop codon) and ending at nucleotide\r\n" + 
                "     1556 of the published sequence (Depicker et al., J. Mol Appl Genet (1982)\r\n" + 
                "     1:561-574). Ligation of this PCR fragment into pML3 yielded the plasmid\r\n" + 
                "     pML63.\r\n" + 
                "<BR><BR>[0147] As indicated above, pML63 contains the GUS coding region under the\r\n" + 
                "     control of the 35S promoter and a truncated version of the 3' NOS\r\n" + 
                "     terminator. It therefore contains all of the transcriptional information\r\n" + 
                "     that is necessary for the constitutive expression of GUS in plants. To\r\n" + 
                "     generate an analogous construct for TP-CPL, plasmid pML63 was digested\r\n" + 
                "     with Nco I and EcoRI. This manipulation releases only the GUS gene\r\n" + 
                "     insert, leaving the regulatory flanking sequences and the rest of the\r\n" + 
                "     vector intact. Plasmid pet24a-TP-CPL was also treated with NcoI and\r\n" + 
                "     EcoRI, which liberates the entire coding region of the TP-CPL fusion\r\n" + 
                "     protein. The small DNA fragment (693 bp) corresponding to the latter was\r\n" + 
                "     purified by agarose gel electrophoresis and subjected to a standard\r\n" + 
                "     ligation reaction with the large vector fragment (4.63 bp) that was\r\n" + 
                "     obtained from cutting pML63 with Nco I and Eco RI. The ligation reaction\r\n" + 
                "     mixture was introduced into E. coli DH10B using electroporation, and\r\n" + 
                "     growth was selected on LB media that contained ampicillin (100 .mu.g/ml).\r\n" + 
                "     Transformants harboring plasmids with the inserted TP-CPL coding sequence\r\n" + 
                "     were identified by colony PCR using Primers 2 and 3. A representative\r\n" + 
                "     plasmid that yielded a PCR product of the correct size was selected for\r\n" + 
                "     further manipulation. A schematic representation of the final construct,\r\n" + 
                "     referred to below as \"TP-CPL-pML63\", is shown in FIG. 2.\r\n" + 
                "<BR><BR>[0148] The binary vector that was used for Agrobacterium-mediated, leaf\r\n" + 
                "     disc transformation of tobacco was the plasmid pZBL1 which was deposited\r\n" + 
                "     with the ATCC on June 24, 1997 and bears the accession number 209128.\r\n" + 
                "     PZBL1 contains the origin of replication from pBR322, the bacterial nptl\r\n" + 
                "     kanamycin resistance gene, the replication and stability regions of the\r\n" + 
                "     Pseudomonas aeruginosa plasmid pVS1 (Itoh et al, 1984), T-DNA borders\r\n" + 
                "     described by van den Elzen et al., 1985 wherein the OCS enhancer\r\n" + 
                "     (extending from -320 to -116 of the OCS promoter (Greve et al., 1983, J.\r\n" + 
                "     Mol. Appl. Genet. 1:499-511)) that is part of the right border fragment\r\n" + 
                "     is removed, and a NOS/P-nptII-OCS 3' gene to serve as a kanamycin\r\n" + 
                "     resistant plant selection marker. For expression of TP-CPL, plasmid pZBL\r\n" + 
                "     1 was digested with Sal I which cuts at a unique site between the right\r\n" + 
                "     and left borders that is ideally situated for the insertion of foreign\r\n" + 
                "     genes and stable integration into the plant genome. To minimize the\r\n" + 
                "     possibility of re-ligation without an insert, the cut vector was\r\n" + 
                "     dephosphorylated using Calf Intestinal Alkaline Phosphatase (GibcoBRL)\r\n" + 
                "     according by the manufacturer's recommendations. To obtain the fragment\r\n" + 
                "     that would be inserted into the binary vector, plasmid TP-CPL-pML63 was\r\n" + 
                "     also digested with Sal I. This treatment releases the entire\r\n" + 
                "     transcriptional unit for the TP-CPL fusion gene (e.g., 35S promoter/cab22\r\n" + 
                "     leader/TP-CPL/3' NOS terminator) as a 2.4 kb DNA fragment. The latter was\r\n" + 
                "     purified by agarose gel electrophoresis and subjected to a standard\r\n" + 
                "     ligation reaction with the dephosphorylated 11.0 kb fragment that was\r\n" + 
                "     obtained from pZBL1 as described above. The ligation reaction mixture was\r\n" + 
                "     introduced into E. coli DH10B using electroporation, and growth was\r\n" + 
                "     selected on LB media with kanamycin (50 .mu.g/ml). Transformants\r\n" + 
                "     harboring plasmids with the TP-CPL fusion gene were identified by colony\r\n" + 
                "     PCR using Primers 2 and 3, and the orientation of the insert was\r\n" + 
                "     determined by restriction digestion analysis using Kpn I. In the plasmid\r\n" + 
                "     that was selected for further manipulation, referred to below as\r\n" + 
                "     \"TP-CPL-pZBL1\", the start codon for TP-CPL is adjacent to the right\r\n" + 
                "     border fragment of the T-DNA as shown schematically in FIG. 3. As\r\n" + 
                "     described below, this expression construct was used for the\r\n" + 
                "     transformation of tobacco and arabidopis for overproduction of pHBA.\r\n" + 
                "<BR><BR>EXAMPLE 7\r\n" + 
                "<BR><BR>Generation of Transgenic Tobacco Plants\r\n" + 
                "<BR><BR>[0149] Plasmid TP-CPL-pZBL 1 was introduced into Agrobacterium tumefaciens\r\n" + 
                "     strain LBA4404 (Hoekema et al., Nature 303:179-180 (1983) using the\r\n" + 
                "     freeze-thaw transformation procedure (Holsters et al, Mol. Gen. Genet.\r\n" + 
                "     163:181-187). The cells were plated at 28.degree. C. on YEP media (10 g\r\n" + 
                "     Tryptone, 10 g Yeast Extract, and 5 g NaCl per liter) that also contained\r\n" + 
                "     kanamycin (1000 .mu.g/ml) and rifampicin (20 .mu.g/ml). Colonies\r\n" + 
                "     harboring the binary construct were identified by PCR using appropriate\r\n" + 
                "     primers.\r\n" + 
                "<BR><BR>[0150] Potted tobacco plants (Nicotiana tabacum cv. Xanthi) for leaf disk\r\n" + 
                "     infections were grown in a growth chamber maintained for a 14 hr,\r\n" + 
                "     21.degree. C. day, 10 hr, 18.degree. C. night cycle, with approximately\r\n" + 
                "     80% relative humidity, under mixed cool white fluorescent and\r\n" + 
                "     incandescent lights. Agrobacterium-mediated, leaf disk transformations\r\n" + 
                "     were performed essentially as described by De Blaere et al., Meth.\r\n" + 
                "     Enzymol. 153:277-292) with the following modifications. Leaf disks, 8 mm\r\n" + 
                "     in diameter, were prepared from whole leaves using a sterile paper punch\r\n" + 
                "     and plants that were 4-6 weeks old. Leaf disks were inoculated by\r\n" + 
                "     submerging them for 30 mins in concentrated solution of Agrobacterium\r\n" + 
                "     harboring TP-CPL-pZBL1 resuspended to an OD600 of .about.Z in Murashige\r\n" + 
                "     Minamal Organics media. Inoculated leaf disks were placed directly on\r\n" + 
                "     media, that contained (per liter) 30 g of sucrose, 1 mg of\r\n" + 
                "     6-benzylaminopurine (BAP), 0.1 mg of napthaleneacetic acid, 8 g of agar,\r\n" + 
                "     and 1 package of Murashige's Minimal Organics Medium that was obtained\r\n" + 
                "     from GibcoBRL (cat. #23118-029). After incubation for 3 days at\r\n" + 
                "     28.degree. C. in the light, leaf disks were transferred to fresh media of\r\n" + 
                "     the same composition that also contained kanamycin (300 .mu.g/ml) and\r\n" + 
                "     cefotaxime (500 .mu.g/ml) to select for the growth of transformed tobacco\r\n" + 
                "     cells and eliminate residual Agrobacterium. Leaf disks were incubated\r\n" + 
                "     under the growth conditions described above for 3 weeks and were then\r\n" + 
                "     transferred at 3-week intervals to fresh media of the same composition\r\n" + 
                "     until optimal shoot size was obtained for root induction. Shoots were\r\n" + 
                "     rooted on media containing (per liter) 1 package of Murashige's Minimal\r\n" + 
                "     Organics Medium, 8 g of agar, and 10 g of sucrose. Approximately 4 weeks\r\n" + 
                "     later, the plants were transferred to soil and allowed to grow to\r\n" + 
                "     maturity in a growth chamber under the conditions described above.\r\n" + 
                "<BR><BR>EXAMPLE 8\r\n" + 
                "<BR><BR>Chemical Synthesis of pHBA Glucoside Standards\r\n" + 
                "<BR><BR>[0151] To synthesize the pHBA ester glucoside, 110 mmol of\r\n" + 
                "     4-hydroxybenzoic acid was combined with 55 mmol bis(tributyltin)oxide in\r\n" + 
                "     1 L benzene. The mixture was heated to reflux for 16 h under an\r\n" + 
                "     atmosphere of nitrogen with an azeotrope apparatus in place. The benzene\r\n" + 
                "     was removed under reduced pressure to yield a clear oil which is\r\n" + 
                "     predominantly the 4-hydroxybenzoic tributyltin ester (Ogawa et al.,\r\n" + 
                "     (1982) Tetrahedron 36:2641-2648). Next, 25 mmol of acetobromo-a-D-glucose\r\n" + 
                "     in 1.2 L of 1,2-dichloroethane was added to 25 mmol of the\r\n" + 
                "     4-hydroxybenzoic tributyltin ester intermediate, and this was followed by\r\n" + 
                "     the addition of 12.5 mmol of tetrabutylammonium bromide. The mixture was\r\n" + 
                "     heated to reflux under a nitrogen atmosphere for 3 h, and progress of the\r\n" + 
                "     reaction was monitored by TLC with detection by charring with sulfuric\r\n" + 
                "     acid. The solvent was removed under reduced pressure, and the acetyl\r\n" + 
                "     protected pHBA ester glucoside was purified on silica gel, using a 1:1\r\n" + 
                "     mixture of ethyl acetate and hexane for elution. The acetyl protecting\r\n" + 
                "     groups were then selectively saponified for 3 h with 1 equivalent of\r\n" + 
                "     potassium carbonate in a 10% solution of methanol in water. The solvent\r\n" + 
                "     was removed under reduced pressure and the pHBA ester glucoside was\r\n" + 
                "     cleanly triturated with methanol. The latter was removed by filtration,\r\n" + 
                "     and the resulting white powder exhibited a melting point of\r\n" + 
                "     209-210.degree. C. The chemical structure of the pHBA ester glucoside was\r\n" + 
                "     confirmed by .sup.1H NMR.\r\n" + 
                "<BR><BR>[0152] For synthesis of the pHBA acyl glucoside, 16.4 mmol of methyl\r\n" + 
                "     4-hydroxybenzoate and 14.6 mmol of acetobromo-a-D-glucose were dissolved\r\n" + 
                "     in 7.0 ml of anhydrous pyridine, and this was followed by the addition of\r\n" + 
                "     23.3 mmol of 99.99% silver oxide. The reaction was stirred, under a\r\n" + 
                "     nitrogen atmosphere, for 3 h at room temperature. The insoluble silver\r\n" + 
                "     salts were then collected by filtration, washed with pyridine, and the\r\n" + 
                "     combined filtrate and washings were concentrated under reduced pressure\r\n" + 
                "     and poured into a mixture of ice cold water. The dark brown solid was\r\n" + 
                "     collected, rinsed with water, and dissolved in a 1:1 mixture of\r\n" + 
                "     chloroform and methylene chloride which was subsequently dried using\r\n" + 
                "     sodium carbonate as a drying agent. The solution was filtered through\r\n" + 
                "     celite and the solvents were removed under reduced pressure. The hydroxy\r\n" + 
                "     linked methyl benzoate, acetyl protected glycoside (Durkee et al., (1979)\r\n" + 
                "     Carbohydrate Research 77:252-254) was then purified using silica gel\r\n" + 
                "     chromatography; the 35 column was eluted with a 1:2 mixture of ethyl\r\n" + 
                "     acetate and hexane. The purified compound was dissolved in 40 ml of\r\n" + 
                "     methanol and 1.5 mmol of sodium methoxide was added. After 4.5 h, the\r\n" + 
                "     solution had turned yellow and the solvent was removed under reduced\r\n" + 
                "     pressure; the resulting residue was dissolved in 25 ml of water. The\r\n" + 
                "     solution was concentrated to .about.5 mls and allowed to crystallize to\r\n" + 
                "     yield the hydroxy linked methylbenzoate glycoside; the crystals were\r\n" + 
                "     collected and dried under high vacuum. To selectively saponify the methyl\r\n" + 
                "     ester group, 2.5 mnmol of the hydroxy linked methylbenzoate glycoside was\r\n" + 
                "     dissolved in 25 ml water and 2.5 ml of 1 M NaOH was added. After stirring\r\n" + 
                "     overnight at room temperature, the solution was neutralized, concentrated\r\n" + 
                "     to .about.5 ml, and allowed to crystallize to yield the desired pHBA acyl\r\n" + 
                "     glucoside. The melting point of this compound was found to be\r\n" + 
                "     108-110.degree. C., and its chemical structure was confirmed by .sup.1H\r\n" + 
                "     NMR.\r\n" + 
                "<BR><BR>EXAMPLE 9\r\n" + 
                "<BR><BR>Preparation of Tobacco Leaf Samples for Analysis of pHBA Glucosides\r\n" + 
                "<BR><BR>[0153] Healthy leaves, measuring .about.15 cm along the midvein, were\r\n" + 
                "     selected for from the top third of the tobacco plant stem. The tissue\r\n" + 
                "     (100 mg fresh weight) was rapidly removed with scissors from the distal\r\n" + 
                "     {fraction (1/3)} portion of the leaf and placed in a Biopulverizer H Tube\r\n" + 
                "     (cat. no. 6570-201 or 6540-401) that contained a ceramic bead; both of\r\n" + 
                "     the latter were obtained from BIO 101 (Joshua Way, Vista, Calif.).\r\n" + 
                "     Following the addition of 1 ml of methanol, the tubes were capped and\r\n" + 
                "     mechanically agitated for 40 s using a Savant FastPrep FP120 tissue\r\n" + 
                "     disruption apparatus that was operating at a speed of 5 m/s. Next, the\r\n" + 
                "     tubes were placed on a rotary shaker and vigorously agitated at 400 rpm\r\n" + 
                "     for 1 h at room temperature. The extract was clarified by centrifugation\r\n" + 
                "     (10,000.times. g, 10 mins) using a conventional tabletop microfuge, and\r\n" + 
                "     the supernatant which contained both pHBA glucosides was carefully\r\n" + 
                "     removed to an empty tube. The remaining insoluble leaf material was\r\n" + 
                "     re-extracted with 0.5 ml of methanol for 30 min at room temperature using\r\n" + 
                "     the rotary shaker and the conditions described above. The supernatant\r\n" + 
                "     resulting from the second extraction was combined with the first, and the\r\n" + 
                "     samples were stored at -20.degree. C. for subsequent processing. The\r\n" + 
                "     volume of methanol that was added to each sample of leaf material and the\r\n" + 
                "     final volume that was recovered after extraction and centrifugation were\r\n" + 
                "     determined gravimetrically using an analytical balance and the density of\r\n" + 
                "     methanol to convert mass to volume.\r\n" + 
                "<BR><BR>[0154] Further processing of the samples for HPLC analysis was as follows.\r\n" + 
                "     Unless otherwise stated, all steps were conducted at room temperature. An\r\n" + 
                "     aliquot of the methanol extract was transferred to a microfuge tube, and\r\n" + 
                "     its exact volume was determined as described above. The solvent was\r\n" + 
                "     removed under vacuum in a Speed-Vac (Savant Instruments) with the heat\r\n" + 
                "     setting on and the sample was taken to complete dryness. The dry residue\r\n" + 
                "     was dissolved in 100 .mu.l of 0.2 N HCl and 0.7 mL water-saturated\r\n" + 
                "     diethyl ether was added. After vigorous vortex mixing and centrifugation,\r\n" + 
                "     the ether phase was carefully removed and discarded, and the sample was\r\n" + 
                "     re-extracted with ether as described above. An aliquot of the remaining\r\n" + 
                "     aqueous phase (50 .mu.l) was then filtered through a 0.22 um cellulose\r\n" + 
                "     acetate filter (Costar EZ-spin) and injected onto a Vydac 218TP54 PROTEIN\r\n" + 
                "     AND PEPTIDE C18 column that was pre-equilibrated at 1 ml/min with 90%\r\n" + 
                "     Buffer A (0.1% formic acid in water) and 10% Buffer B (methanol). Upon\r\n" + 
                "     sample injection, the column was developed with a linear gradient that\r\n" + 
                "     was generated over 20 min period to a final concentration of 50% Buffer\r\n" + 
                "     B. The flow rate was 1 ml/min. Elution of the phenolic and ester pHBA\r\n" + 
                "     glucosides was monitored spectrophotometrically at 254 nm. FIG. 4 shows\r\n" + 
                "     representative HPLC tracings of a tobacco plant expressing TP-CPL\r\n" + 
                "     (Transformant #5) and a wildtype plant.\r\n" + 
                "<BR><BR>[0155] Authentic pHBA glucoside standards (see above) were used to\r\n" + 
                "     calibrate the HPLC runs for retention times, and extinction coefficients\r\n" + 
                "     for both compounds were accurately determined under the HPLC conditions\r\n" + 
                "     employed. Thus, peak areas were integrated using the software provided\r\n" + 
                "     with the H/P Chemstation, and the values obtained with known amounts of\r\n" + 
                "     the appropriate standards were used to quantitate micrograms of pHBA\r\n" + 
                "     glucosides per injection. After accounting for dilution and the fraction\r\n" + 
                "     of the original methanol extract that was injected on the column, the\r\n" + 
                "     numbers were corrected to reflect total recovery from the leaf sample\r\n" + 
                "     analyzed. This, coupled with an individual measurement of the dry weight\r\n" + 
                "     of the plant tissue analyzed (e.g. obtained from the same plant, on the\r\n" + 
                "     same day), enabled the expression of pHBA-glucosides as a percentage dry\r\n" + 
                "     weight.\r\n" + 
                "<BR><BR>EXAMPLE 10\r\n" + 
                "<BR><BR>Segregation of Kanamycin-resistance in the First Self-crossed Filial\r\n" + 
                "     Generation\r\n" + 
                "<BR><BR>[0156] Seeds from primary tobacco Transformant #34 that resulted from\r\n" + 
                "     self-crossing were surface sterilized by immersion in a 10% bleach\r\n" + 
                "     solution [Clorox.RTM. containing 5.25% Na(OCl).sub.2] that also contained\r\n" + 
                "     0.1% SDS for 30 min at room temperature with gentle agitation. The\r\n" + 
                "     germination frequency of 200 seeds without antibiotic selection was\r\n" + 
                "     97.5%. In contrast, of the 500 seeds that were plated on germination\r\n" + 
                "     media that also contained kanamycin (300 .mu.g/ml), approximately 20%\r\n" + 
                "     displayed the recessive phenotype (e.g., the ratio of kanamycin sensitive\r\n" + 
                "     seeds to kanamycin resistant seeds was 1:4). Since the segregation ratio\r\n" + 
                "     for Transformant #34 is very close to the theoretical ratio of 1:3 for a\r\n" + 
                "     monogenic dominant trait (e.g., as opposed to a 1:16 ratio that is\r\n" + 
                "     characteristic of a double-loci event), it may be concluded that the\r\n" + 
                "     selectable marker and TP-CPL gene expression construct were stably\r\n" + 
                "     integrated into the genome at a single loci.\r\n" + 
                "<BR><BR>EXAMPLE 11\r\n" + 
                "<BR><BR>Determination of CPL Enzyme Activity in Tobacco Leaf Extracts\r\n" + 
                "<BR><BR>[0157] Leaf tissue extracts from wildtype and transgenic tobacco plants\r\n" + 
                "     were prepared and assayed for CPL enzyme activity as previously described\r\n" + 
                "     (Siebert et al., Plant Physiol. 112:811-819 (1996)) with minor\r\n" + 
                "     modifications. Leaf samples (2 g wet weight) were homogenized in an\r\n" + 
                "     ice-cold mortar with 2.6 ml of a solution containing 50 mM Tris-HCl (pH\r\n" + 
                "     7.5), 0.1% P-mercaptoethanol, 1 mM EDTA, 1 mM phenylmethanesulfonyl\r\n" + 
                "     fluoride, and 75 mg/ml polyvinylpoly-pyrrolidone. Unless otherwise\r\n" + 
                "     indicated, all subsequent steps were conducted at 0-4.degree. C.\r\n" + 
                "     Following low-speed centrifugation to remove insoluble material, the\r\n" + 
                "     sample was buffer exchanged into 50 mM Tris-HCL (pH 8.0), 10 mM EDTA, and\r\n" + 
                "     200 mM NaCl, using a PD-10 gel filtration column (Pharmacia Biotech Inc)\r\n" + 
                "     according to the manufacturer's recommendations. Protein concentration\r\n" + 
                "     was determined using the Bio-Rad (Bradford) protein assay.\r\n" + 
                "<BR><BR>[0158] CPL enzyme assays were conducted as follows. The basic reaction\r\n" + 
                "     mixture (final volume, 500 .mu.l) contained 50 mM Tris pH 8.0 (at\r\n" + 
                "     37.degree. C.), 10 mM EDTA, 200 mM NaCl, and 150 .mu.M of purified barium\r\n" + 
                "     chorismate (Siebert et al. Microbiology 140:897-904 (1994)). Following a\r\n" + 
                "     5-min incubation period at 37.degree. C., reactions were initiated with\r\n" + 
                "     tobacco leaf extract that contained 50 .mu.g of protein. Reactions were\r\n" + 
                "     terminated after 2 min at 37.degree. C. with 0.3 ml of 0.75 M sodium\r\n" + 
                "     acetate (pH 4), and the amount of pHBA that was produced in the reaction\r\n" + 
                "     was determined. To monitor the recovery of product, each tube received\r\n" + 
                "     9,500 dpm of [1.sup.4C] -labeled pHBA (55 mCi/mmol) as an internal\r\n" + 
                "     standard. The mixtures were extracted with 1 ml of H.sub.2O-saturated\r\n" + 
                "     ethyl acetate, and the organic phase was collected and taken to dryness.\r\n" + 
                "     The amount of pHBA was then quantitatively determined by reverse phase\r\n" + 
                "     HPLC, using the exact same column and conditions that were described in\r\n" + 
                "     Example 9. The peak corresponding to pHBA was collected and the amount of\r\n" + 
                "     radioactivity was determined by liquid scintillation counting. Values\r\n" + 
                "     reported below for CPL enzyme activity are expressed as pkats per mg\r\n" + 
                "     protein, and have been corrected for recovery of the internal standard\r\n" + 
                "     and the small amount of pHBA that is generated from chorismate through\r\n" + 
                "     spontaneous decomposition (Siebert et al., Plant Physiol. 112:811-819\r\n" + 
                "     (1996)).\r\n" + 
                "<BR><BR>EXAMPLE 12\r\n" + 
                "<BR><BR>Analysis of Transgenic Tobacco Plants Expressing TP-CPL\r\n" + 
                "<BR><BR>[0159] As described above, TP-CPL was introduced into tobacco (Nicotiana\r\n" + 
                "     tabacum) using agrobacterium-mediated, leaf disc transformation to\r\n" + 
                "     determine its influence on the accumulation of pHBA glucosides. That this\r\n" + 
                "     artificial fusion protein is indeed superior to other\r\n" + 
                "     chloroplast-targeted versions of E. coi CPL that have previously been\r\n" + 
                "     used to elevate pHBA levels in plants (Siebert et al., Plant Physiol.\r\n" + 
                "     112:811-819 (1996); Sommer et al., Plant Cell Reports 17:891-896 (1998)),\r\n" + 
                "     is apparent from the data shown in FIG. 5. This analysis was conducted on\r\n" + 
                "     leaf tissue that was obtained from 15 tobacco plants (primary\r\n" + 
                "     transformants) that resulted from different transformation events. Note\r\n" + 
                "     that the samples were taken only 5 weeks after the plants had been\r\n" + 
                "     transferred to soil. As anticipated, the primary transformants exhibited\r\n" + 
                "     various levels of pHBA glucosides, ranging from 0-2.3% of the total dry\r\n" + 
                "     weight. This type of variation is typically observed in nearly all plant\r\n" + 
                "     transformation experiments, and presumably reflects different levels of\r\n" + 
                "     gene expression that result from so-called \"positional\" effects (e.g.,\r\n" + 
                "     stable integration of the trait gene at different locations in the\r\n" + 
                "     genome) and transgene copy number. That a similar phenomena also occurred\r\n" + 
                "     in the present study is supported by Western blot analysis of the tobacco\r\n" + 
                "     transformants using antisera directed against purified recombinant E.\r\n" + 
                "     coli CPL. For example, although the majority of the plants (e.g.,\r\n" + 
                "     {fraction (14/15)}) had immunologically detectable levels of the foreign\r\n" + 
                "     protein, there was considerable variation in the levels of expression.\r\n" + 
                "     Generally speaking, however, there was a positive correlation between the\r\n" + 
                "     strength of the Western signal and the accumulation of pHBA glucosides,\r\n" + 
                "     consistent with previous observations (Siebert et al., Plant Physiol.\r\n" + 
                "     112:811-819 (1996)); Sommer et al., Plant Cell Physiol. 39(11):1240-1244\r\n" + 
                "     (1998); Sommer et al., Plant Cell Reports 17:891-896 (1998)).\r\n" + 
                "<BR><BR>[0160] Based on dry weight, the average pHBA glucoside content of the\r\n" + 
                "     5-week-old tobacco plants was 1.12% (+/-0.186%), where the number in\r\n" + 
                "     parenthesis is the standard error of the mean. More important, in only\r\n" + 
                "     three of the primary transformants (#13, #19, and #37) was the level of\r\n" + 
                "     pHBA glucosides lower than 0.52%, which was the highest level that was\r\n" + 
                "     obtained in a similar study with the TP-UbiC artificial fusion protein\r\n" + 
                "     (Siebert et al., Plant Physiol. 112:811-819 (1996). Furthermore, the\r\n" + 
                "     three best plants in the present study (#8, #34, and #39) had pHBA\r\n" + 
                "     glucoside contents that were at least 2% of dry weight.\r\n" + 
                "<BR><BR>[0161] To examine the stability of the desired phenotype, three of the\r\n" + 
                "     transgenic tobacco plants (#4, #5, and #34) were monitored over an\r\n" + 
                "     extended period of time, up to the stage of seed formation. It was\r\n" + 
                "     possible that the plants might not be able to maintain such high levels\r\n" + 
                "     of pHBA glucosides as they continued to develop. However, as shown in\r\n" + 
                "     FIG. 6, this was not the case. As the plants grew older, their leaf\r\n" + 
                "     content of pHBA glucosides increased dramatically. For example, in\r\n" + 
                "     Transformant #5, the total pHBA glucoside levels were 0.5%, 1.6%, 7.2%,\r\n" + 
                "     and 10% of the total dry weight, when samples were analyzed 1, 5, 11, and\r\n" + 
                "     13 weeks after transferring the plant to soil. The 13-week value\r\n" + 
                "     represents a nearly 20-fold increase over the results obtained with\r\n" + 
                "     TP-UbiC, and corresponds to a pHBA content of 4.5% after correcting for\r\n" + 
                "     the mass of the associated glucose molecule. Despite these very high\r\n" + 
                "     levels of the secondary metabolite, the transgenic tobacco plants seemed\r\n" + 
                "     perfectly normal and were morphologically indistinguishable from wildtype\r\n" + 
                "     plants.\r\n" + 
                "<BR><BR>[0162] To follow the fate of the foreign gene and the associated phenotype\r\n" + 
                "     of pHBA accumulation into the next generation, Transformant #34 was\r\n" + 
                "     selected for further analysis. As a 13-week-old primary transformant, the\r\n" + 
                "     pHBA glucoside content of this plant was 8% of the total dry weight (FIG.\r\n" + 
                "     6). As described in Example 10, when seeds obtained by self-pollination\r\n" + 
                "     were germinated in the presence of kanamycin and examined for segregation\r\n" + 
                "     of the antibiotic-resistant phenotype, a ratio of 1 (sensitive) to 4\r\n" + 
                "     (resistant) was observed. This suggests that integration of the\r\n" + 
                "     selectable marker and TP-CPL had occurred at a single location in the\r\n" + 
                "     genome, as opposed to a double-loci event that that would have resulted a\r\n" + 
                "     kanamycin-resistance segregation ratio of 1:15. Theoretically, the\r\n" + 
                "     kanamycin-resistant plants consist of two populations, heterozygotes and\r\n" + 
                "     homozygotes, present in a ratio of 2:1. Assuming the absence of\r\n" + 
                "     co-suppression, the homozygous plants would be expected to have twice as\r\n" + 
                "     much CPL enzyme activity as the heterozygous plants, and perhaps\r\n" + 
                "     accumulate even higher levels of pHBA glucosides. To address this issue,\r\n" + 
                "     5 of the kanamycin-resistant seedlings (referred to below as #34 A-34 E)\r\n" + 
                "     were grown to mature plants and analyzed for CPL enzyme activity and pHBA\r\n" + 
                "     glucosides. The plants were 15-weeks-old at the time the samples were\r\n" + 
                "     taken, and the results of this study are shown in Table I below.\r\n" + 
                "<BR><BR>1TABLE I\r\n" + 
                "     Plant 34 CPL Enzyme Activity Total\r\n" + 
                "     pHBA-glucosides\r\n" + 
                "     Sibling (pkat/mg protein) (percent of dry weight)\r\n" + 
                "     34A 927 4.8\r\n" + 
                "     34B 991 5.9\r\n" + 
                "     34C 1048 5.0\r\n" + 
                "     34D 784 5.0\r\n" + 
                "     34E 356 3.2\r\n" + 
                "<BR><BR>[0163] As anticipated, all of the seedlings that were kanamycin-resistant\r\n" + 
                "     also exhibited CPL enzyme activity and accumulated pHBA glucosides. Thus,\r\n" + 
                "     the gene for the artificial fusion protein, TP-CPL, was stably passed on\r\n" + 
                "     to the next generation. Although the number of plants that was examined\r\n" + 
                "     is small, there appeared to be two different populations. The CPL enzyme\r\n" + 
                "     activities for four of the offspring (e.g., #34A-34D) were very similar,\r\n" + 
                "     ranging from 784-1,048 pkats per mg of protein. Note that the average CPL\r\n" + 
                "     activity for this group (e.g., 938 pkat/mg) is about 4.5-times higher\r\n" + 
                "     than the best value that was obtained with TP-UbiC when living tobacco\r\n" + 
                "     plants were examined (Siebert et al., Plant Physiol. 112:811-819 (1996)).\r\n" + 
                "     The same four siblings also had comparable levels of pHBA glucosides. The\r\n" + 
                "     average value was .about.5.2% of dry weight, and the numbers were closely\r\n" + 
                "     clustered (e.g., 4.8%-5.9%).\r\n" + 
                "<BR><BR>[0164] In contrast, one of the plants (e.g., #34E) had much lower levels\r\n" + 
                "     of CPL enzyme activity and pHBA glucosides. While it is tempting to\r\n" + 
                "     speculate that this sibling is a heterozygote and the other four plants\r\n" + 
                "     are homozygotes, it is still too premature to draw this conclusion.\r\n" + 
                "     First, based on the segregation pattern that was obtained for the\r\n" + 
                "     kanamycin-resistant phenotype, only one third of the plants would be\r\n" + 
                "     expected to be homozygous, not the observed 80% of the population.\r\n" + 
                "     Second, it is conceivable that the homozygous state with twice as many\r\n" + 
                "     copies of the trait gene could lead to co-suppression, resulting in\r\n" + 
                "     paradoxically low levels of CPL enzyme activity and pHBA glucosides.\r\n" + 
                "     Experiments are currently under way to try to resolve this issue.\r\n" + 
                "     Regardless, it is interesting to note that the accumulation of pHBA\r\n" + 
                "     glucosides in the second generation plants was not quite as high as it\r\n" + 
                "     was in the primary transformant.\r\n" + 
                "<BR><BR>EXAMPLE 13\r\n" + 
                "<BR><BR>Proteolytic Processing of TP-CPL Occurs at the Predicted Cleavage Site In\r\n" + 
                "     Vivo\r\n" + 
                "<BR><BR>[0165] As shown in FIG. 7, whole leaf extracts of transgenic tobacco\r\n" + 
                "     plants expressing the artificial fusion protein, TP-CPL, contain only a\r\n" + 
                "     single polypeptide that cross-reacts with antisera directed against\r\n" + 
                "     purified recombinant E. coli CPL. Moreover, the size of the\r\n" + 
                "     cross-reacting polypeptide, which is not present in wildtype plants, is\r\n" + 
                "     much smaller than the original fusion protein that was introduced into\r\n" + 
                "     tobacco, as determined by SDS-PAGE. In fact, it appears to co-migrate\r\n" + 
                "     precisely with purified recombinant .DELTA.TP-CPL , the predicted\r\n" + 
                "     chloroplast cleavage product of TP-CPL (Example 4) and the radioactive\r\n" + 
                "     band that is observed after in vitro chloroplast import experiments\r\n" + 
                "     (Example 5). Nevertheless, to provide an unequivocal demonstration that\r\n" + 
                "     the removal of the chloroplast targeting sequence from the artificial\r\n" + 
                "     fusion protein does occur at the predicted cleavage site in vivo, the\r\n" + 
                "     protein was purified from leaf tissue obtained from tobacco Transformant\r\n" + 
                "     #34 and its N-terminal amino acid residues were determined by Edman\r\n" + 
                "     degradation.\r\n" + 
                "<BR><BR>[0166] Leaf tissue (6.9 g wet weight) was homogenized in a mortar and\r\n" + 
                "     pestle with an ice-cold solution containing 50 mM Tris-HCl (pH 7.5), 1 mM\r\n" + 
                "     EDTA, 0.1% .beta.-mercaptoethanol, 1 mM phenylmethanesulfonyl fluoride,\r\n" + 
                "     and 75 mg/ml polyvinylpolypyrrolidone (grind buffer). Unless otherwise\r\n" + 
                "     specified, all subsequent steps were conducted at 0-4.degree. C. The leaf\r\n" + 
                "     extract was centrifuged for 30 min (40,000.times. g) to remove insoluble\r\n" + 
                "     material, and the resulting supernatant was supplemented with solid\r\n" + 
                "     (NH.sub.4).sub.2SO.sub.4 to final concentration of 80% (w/v). The\r\n" + 
                "     solution was gently stirred for 30 min, and was then centrifuged for 10\r\n" + 
                "     min at 20,000.times. g to precipitate the majority of proteins. The\r\n" + 
                "     supernatant was discarded, and the resulting pellet was resuspendend in\r\n" + 
                "     2.0 ml of grind buffer without polyvinylpolypyrrolidone that was\r\n" + 
                "     supplemented with 8% (v/v) glycerol, at a protein concentration of 14.3\r\n" + 
                "     mg per ml, as determined by the Bio-Rad (Bradford) protein assay.\r\n" + 
                "<BR><BR>[0167] An aliquot of the above sample (0.5 ml) was then exchanged into\r\n" + 
                "     Buffer Q (Example 2), using a PD-10 gel filtration column (Pharmacia\r\n" + 
                "     Biotech Inc). After the sample had completely entered the resin, the\r\n" + 
                "     column was washed once with 2.2 ml of Buffer Q and the eluent was\r\n" + 
                "     discarded. The material eluting in the void volume was then collected,\r\n" + 
                "     after the addition of another 1.1 ml of the same buffer. The entire\r\n" + 
                "     sample was then applied to a MonoQ HR5/5 column that was equilibrated at\r\n" + 
                "     room temperature with Buffer Q. The column was developed with the same\r\n" + 
                "     buffer at a flow rate of 1.0 ml/min, and fractions (1.0 ml each) were\r\n" + 
                "     collected from the time of sample injection. Fractions containing the\r\n" + 
                "     chloroplast cleavage product of TP-CPL were identified by Western blot\r\n" + 
                "     analysis, using antisera directed against purified recombinant E. coli\r\n" + 
                "     CPL. Virtually all of the cross-reacting material eluted in fractions #3\r\n" + 
                "     and #4, and as before the only species that was detected with the\r\n" + 
                "     antisera co-migrated with purified, recombinant .DELTA.TP-CPL. Column\r\n" + 
                "     fractions #3 and #4 were pooled, supplemented with 7.5% glycerol, 0.3 M\r\n" + 
                "     NaCl and 0.01% Tween 20 (Bio-Rad cat. # 170-6531), and concentrated to a\r\n" + 
                "     final volume of about 200 .mu.l using a Centricon 10 (Amicon). The entire\r\n" + 
                "     sample was then applied to a 7.5.times.600 mm TSK G3000SW gel filtration\r\n" + 
                "     column (TOSOH Corp.) that was pre-equilibrated at room temperature with\r\n" + 
                "     50 mM Tris-HCL (pH 7.2), 0.3 M NaCl, and 0.01% Tween 20. The column was\r\n" + 
                "     developed at 1.0 ml/min (25.degree. C.) with the same buffer, and\r\n" + 
                "     fractions eluting between 21.5-23 min, which contained the authentic\r\n" + 
                "     TP-CPL chloroplast cleavage product, were pooled together and\r\n" + 
                "     concentrated to a final volume of 55 .mu.l using Microcon 10 (Amicon).\r\n" + 
                "     The concentrated material was diluted 1:1 with sample buffer, and\r\n" + 
                "     analyzed by SDS-PAGE to assess the degree of purification. Although a\r\n" + 
                "     number of other bands were also evident in the Coomassie blue-stained\r\n" + 
                "     gel, the TP-CPL chloroplast cleavage product was a major protein species,\r\n" + 
                "     well separated from other contaminants. N-terminal analysis of the\r\n" + 
                "     polypeptide corresponding to this band (following electophoretic transfer\r\n" + 
                "     to a polyvinylidene difluoride membrane and 6 cycles of Edman\r\n" + 
                "     degradation) confirmed that proteolytic processing of the artificial\r\n" + 
                "     fusion protein had occurred at the predicted cleavage site; e.g., at the\r\n" + 
                "     Cys-Met junction indicated in FIG. 1. From this observation and the\r\n" + 
                "     enzyme activity data presented in Example 4, it may be concluded that the\r\n" + 
                "     polypeptide that is responsible for the conversion of chorismate to pHBA\r\n" + 
                "     in chloroplasts of tobacco plants expressing TP-CPL, is a fully-active\r\n" + 
                "     CPL variant with 5 additional amino acid residues attached to its\r\n" + 
                "     N-terminus.\r\n" + 
                "<BR><BR>EXAMPLE 14\r\n" + 
                "<BR><BR>Generation and Analysis of Transgenic Arabidopsis Plants Expressing TP-CPL\r\n" + 
                "<BR><BR>[0168] The artificial fusion protein, TP-CPL, was introduced into\r\n" + 
                "     arabidopsis and pHBA glucoside levels were determined. The binary vector\r\n" + 
                "     carrying the CaMV35S-CPL expression cassette (e.g., TP-CPL-pZBL1) was\r\n" + 
                "     transformed into Agrobacterium tumefaciens strain C58 C1 Rif (also known\r\n" + 
                "     as strain GV3101), carrying the disarmed Ti (virulence) plasmid pMP90\r\n" + 
                "     (Koncz, C. and Schell, J. (1986) Mol. Gen. Genet. 204:383-396) by\r\n" + 
                "     electroporation, using available protocols (Meyer et al. (1994) Science\r\n" + 
                "     264:1452-1455). The MP90 strain carrying the binary vector with the CPL\r\n" + 
                "     expression construct was used to transform Arabidopsis thaliana plants of\r\n" + 
                "     the ecotype Columbia with wild type, fah1-2 (Chapple et al., Plant Cell\r\n" + 
                "     4:1413-1424 (1992)), sng1-1 (Lorenzen et al., Plant Physiology\r\n" + 
                "     112:1625-1630 (1996)) genetic backgrounds using a published protocol of\r\n" + 
                "     the vacuum infiltration technique (Clough S. J., Bent A. F. (1998) Plant\r\n" + 
                "     J. 16(6):735-43). Transgenic seedlings were identified under sterile\r\n" + 
                "     conditions on standard plant growth media using kanamycin (50 .mu.g/ml)\r\n" + 
                "     for selection. Kanamycin resistant seedlings were transferred to soil and\r\n" + 
                "     cultivated under a 12-hour light/12-hour dark photoperiod at 100 E\r\n" + 
                "     m.sup.-2s.sup.-1 at 18.degree. C. (dark) and 21.degree. C. (light) in a\r\n" + 
                "     soil/perlite mixture. Through this procedure, a population of 301 primary\r\n" + 
                "     transformants derived from independent transformation events was\r\n" + 
                "     generated. Six weeks after transfer to soil, the transgenic arabidopsis\r\n" + 
                "     plants were analyzed for pHBA glucosides using reverse phase HPLC as\r\n" + 
                "     described below.\r\n" + 
                "<BR><BR>[0169] Fresh cut leaf material was homogenized in 50% MeOH (5 .mu.l per mg\r\n" + 
                "     wet weight), and the resulting extracts were clarified by low-speed\r\n" + 
                "     centrifugation. An aliquot of the leaf extract was then applied to a\r\n" + 
                "     Nova-Pak C18 column (60 angstrom pore size, 4 .mu.m particle size) using\r\n" + 
                "     a gradient of acetonitrile (6%-48%) that contained 1.5% phosphoric acid.\r\n" + 
                "     The pHBA phenolic and ester glucosides were detected by UV absorption at\r\n" + 
                "     254 nm, and quantitated using extinction coefficients that were obtained\r\n" + 
                "     from authentic chemical standards (cf. Example 8). Of the 272 transgenic\r\n" + 
                "     arabidopsis plants that were analyzed, 239 (or .about.88%) contained\r\n" + 
                "     detectable levels of both glucose conjugates, and these were present in\r\n" + 
                "     about equal amounts. The total pHBA glucoside content of the best\r\n" + 
                "     overproducer was 10.73% of dry weight, which is very similar to the\r\n" + 
                "     highest levels that were observed with tobacco using the same construct.\r\n" + 
                "     The mean value for the entire population of transgenic arabidopsis plants\r\n" + 
                "     was 3.35% (+/-0.13%); the number in parenthesis is the standard error of\r\n" + 
                "     the mean.\r\n" + 
                "<BR><BR>[0170] Taken together, these results clearly demonstrates that the instant\r\n" + 
                "     chimeric protein, TP-CPL, is able to generate high levels of pHBA\r\n" + 
                "     glucosides not only in tobacco, but in other plant species as well.\r\n" + 
                "       <p>\r\n" + 
                "       \r\n" + 
                "\r\n" + 
                "       Sequence CWU \r\n" + 
                "1\r\n" + 
                "       <BR><BR>1\r\n" + 
                "<BR><BR>16 1 32 DNA Artificial Sequence Description of Artificial SequencePRIMER\r\n" + 
                "     1 ctactcattt catatgtcac accccgcgtt aa\r\n" + 
                "     32 2 34 DNA Artificial Sequence Description of Artificial SequencePRIMER\r\n" + 
                "     2 catcttacta gatctttagt acaacggtga cgcc\r\n" + 
                "     34 3 495 DNA Unknown Organism Description of Unknown OrganismE. coli  3\r\n" + 
                "     atgtcacacc ccgcgttaac gcaactgcgt gcgctgcgct attgtaaaga gatccctgcc     60\r\n" + 
                "     ctggatccgc aactgctcga ctggctgttg ctggaggatt ccatgacaaa acgttttgaa    120\r\n" + 
                "     cagcagggaa aaacggtaag cgtgacgatg atccgcgaag ggtttgtcga gcagaatgaa    180\r\n" + 
                "     atccccgaag aactgccgct gctgccgaaa gagtctcgtt actggttacg tgaaattttg    240\r\n" + 
                "     ttatgtgccg atggtgaacc gtggcttgcc ggtcgtaccg tcgttcctgt gtcaacgtta    300\r\n" + 
                "     agcgggccgg agctggcgtt acaaaaattg ggtaaaacgc cgttaggacg ctatctgttc    360\r\n" + 
                "     acatcatcga cattaacccg ggactttatt gagataggcc gtgatgccgg gctgtggggg    420\r\n" + 
                "     cgacgttccc gcctgcgatt aagcggtaaa ccgctgttgc taacagaact gtttttaccg    480\r\n" + 
                "     gcgtcaccgt tgtac                                                     495\r\n" + 
                "     4 165 PRT Unknown Organism Description of Unknown OrganismE. coli  4 Met\r\n" + 
                "     Ser His Pro Ala Leu Thr Gln Leu Arg Ala Leu Arg Tyr Cys Lys   1\r\n" + 
                "         5                  10                  15 Glu Ile Pro Ala Leu Asp Pro\r\n" + 
                "     Gln Leu Leu Asp Trp Leu Leu Leu Glu              20                  25\r\n" + 
                "                    30 Asp Ser Met Thr Lys Arg Phe Glu Gln Gln Gly Lys Thr Val\r\n" + 
                "     Ser Val          35                  40                  45 Thr Met Ile\r\n" + 
                "     Arg Glu Gly Phe Val Glu Gln Asn Glu Ile Pro Glu Glu      50\r\n" + 
                "        55                  60 Leu Pro Leu Leu Pro Lys Glu Ser Arg Tyr Trp Leu\r\n" + 
                "     Arg Glu Ile Leu  65                  70                  75\r\n" + 
                "        80 Leu Cys Ala Asp Gly Glu Pro Trp Leu Ala Gly Arg Thr Val Val Pro\r\n" + 
                "                  85                  90                  95 Val Ser Thr Leu\r\n" + 
                "     Ser Gly Pro Glu Leu Ala Leu Gln Lys Leu Gly Lys             100\r\n" + 
                "           105                 110 Thr Pro Leu Gly Arg Tyr Leu Phe Thr Ser Ser\r\n" + 
                "     Thr Leu Thr Arg Asp         115                 120                 125\r\n" + 
                "     Phe Ile Glu Ile Gly Arg Asp Ala Gly Leu Trp Gly Arg Arg Ser Arg     130\r\n" + 
                "                   135                 140 Leu Arg Leu Ser Gly Lys Pro Leu Leu\r\n" + 
                "     Leu Thr Glu Leu Phe Leu Pro 145                 150                 155\r\n" + 
                "                   160 Ala Ser Pro Leu Tyr                 165 5 39 DNA\r\n" + 
                "     Artificial Sequence Description of Artificial Sequenceprimer  5\r\n" + 
                "     ctactcactt agatctccat ggcttcctct gtcatttct                            39\r\n" + 
                "     6 32 DNA Artificial Sequence Description of Artificial Sequenceprimer  6\r\n" + 
                "     catcttactc atatgccaca cctgcatgca gc                                   32\r\n" + 
                "     7 684 DNA Artificial Sequence Description of Artificial Sequencesynthetic\r\n" + 
                "           CPL  7 atggcttcct ctgtcatttc ttcagcagct gttgccacac gcagcaatgt\r\n" + 
                "     tacacaagct     60 agcatggttg cacctttcac tggtctcaaa tcttcagcca ctttccctgt\r\n" + 
                "     tacaaagaag    120 caaaaccttg acatcacttc cattgctagc aatggtggaa gagttagctg\r\n" + 
                "     catgcaggtg    180 tggcatatgt cacaccccgc gttaacgcaa ctgcgtgcgc tgcgctattg\r\n" + 
                "     taaagagatc    240 cctgccctgg atccgcaact gctcgactgg ctgttgctgg aggattccat\r\n" + 
                "     gacaaaacgt    300 tttgaacagc agggaaaaac ggtaagcgtg acgatgatcc gcgaagggtt\r\n" + 
                "     tgtcgagcag    360 aatgaaatcc ccgaagaact gccgctgctg ccgaaagagt ctcgttactg\r\n" + 
                "     gttacgtgaa    420 attttgttat gtgccgatgg tgaaccgtgg cttgccggtc gtaccgtcgt\r\n" + 
                "     tcctgtgtca    480 acgttaagcg ggccggagct ggcgttacaa aaattgggta aaacgccgtt\r\n" + 
                "     aggacgctat    540 ctgttcacat catcgacatt aacccgggac tttattgaga taggccgtga\r\n" + 
                "     tgccgggctg    600 tgggggcgac gttcccgcct gcgattaagc ggtaaaccgc tgttgctaac\r\n" + 
                "     agaactgttt    660 ttaccggcgt caccgttgta ctaa\r\n" + 
                "                  684 8 227 PRT Artificial Sequence Description of Artificial\r\n" + 
                "     Sequencesynthetic       CPL  8 Met ala Ser Ser Val Ile Ser Ser Ala Ala\r\n" + 
                "     Val Ala Thr Arg Ser Asn   1               5                  10\r\n" + 
                "            15 Val Thr Gln Ala Ser Met Val Ala Pro Phe Thr Gly Leu Lys Ser Ser\r\n" + 
                "                  20                  25                  30 Ala Thr Phe Pro\r\n" + 
                "     Val Thr Lys Lys Gln Asn Leu Asp Ile Thr Ser Ile          35\r\n" + 
                "        40                  45 Ala Ser Asn Gly Gly Arg Val Ser Cys Met Gln Val\r\n" + 
                "     Trp His Met Ser      50                  55                  60 His Pro\r\n" + 
                "     Ala Leu Thr Gln Leu Arg Ala Leu Arg Tyr Cys Lys Glu Ile  65\r\n" + 
                "        70                  75                  80 Pro Ala Leu Asp Pro Gln Leu\r\n" + 
                "     Leu Asp Trp Leu Leu Leu Glu Asp Ser                  85\r\n" + 
                "     90                  95 Met Thr Lys Arg Phe Glu Gln Gln Gly Lys Thr Val\r\n" + 
                "     Ser Val Thr Met             100                 105                 110\r\n" + 
                "     Ile Arg Glu Gly Phe Val Glu Gln Asn Glu Ile Pro Glu Glu Leu Pro\r\n" + 
                "     115                 120                 125 Leu Leu Pro Lys Glu Ser Arg\r\n" + 
                "     Tyr Trp Leu Arg Glu Ile Leu Leu Cys     130                 135\r\n" + 
                "           140 Ala Asp Gly Glu Pro Trp Leu Ala Gly Arg Thr Val Val Pro Val Ser\r\n" + 
                "     145                 150                 155                 160 Thr Leu\r\n" + 
                "     Ser Gly Pro Glu Leu Ala Leu Gln Lys Leu Gly Lys Thr Pro\r\n" + 
                "     165                 170                 175 Leu Gly Arg Tyr Leu Phe Thr\r\n" + 
                "     Ser Ser Thr Leu Thr Arg Asp Phe Ile             180                 185\r\n" + 
                "                   190 Glu Ile Gly Arg Asp Ala Gly Leu Trp Gly Arg Arg Ser Arg\r\n" + 
                "     Leu Arg         195                 200                 205 Leu Ser Gly\r\n" + 
                "     Lys Pro Leu Leu Leu Thr Glu Leu Phe Leu Pro Ala Ser     210\r\n" + 
                "       215                 220 Pro Leu Tyr 225 9 34 DNA Artificial Sequence\r\n" + 
                "     Description of Artificial Sequenceprimer  9 ctactcattt gaagactgca\r\n" + 
                "     tgcaggtgtg gcat                                 34 10 34 DNA Artificial\r\n" + 
                "     Sequence Description of Artificial Sequenceprimer  10 catcttactg\r\n" + 
                "     tcgactttag tacaacggtg acgc                                 34 11 37 DNA\r\n" + 
                "     Artificial Sequence Description of Artificial Sequenceprimer  11\r\n" + 
                "     ctactcattt ggccagctct gtcatttctt cagcagc                              37\r\n" + 
                "     12 31 DNA Artificial Sequence Description of Artificial Sequenceprimer\r\n" + 
                "     12 catcttacta gatctttagt acaacggtga c\r\n" + 
                "     31 13 33 DNA Artificial Sequence Description of Artificial Sequenceprimer\r\n" + 
                "      13 cccgggggta cctaaagaag gagtgcgtcg aag\r\n" + 
                "     33 14 46 DNA Artificial Sequence Description of Artificial Sequenceprimer\r\n" + 
                "      14 gatatcaagc tttctagagt cgacatcgat ctagtaacat agatga\r\n" + 
                "     46 15 62 PRT Artificial Sequence Description of Artificial\r\n" + 
                "     Sequencesynthetic       CPL  15 Met Ala Ser Ser Val Ile Ser Ser Ala Ala\r\n" + 
                "     Val Ala Thr Arg Ser Asn   1               5                  10\r\n" + 
                "            15 Val Thr Gln Ala Ser Met Val Ala Pro Phe Thr Gly Leu Lys Ser Ser\r\n" + 
                "                  20                  25                  30 Ala Thr Phe Pro\r\n" + 
                "     Val Thr Lys Lys Gln Asn Leu Asp Ile Thr Ser Ile          35\r\n" + 
                "        40                  45 Ala Ser Asn Gly Gly Arg Val Ser Cys Met Gln Val\r\n" + 
                "     Trp His      50                  55                  60 16 170 PRT\r\n" + 
                "     Artificial Sequence Description of Artificial Sequencesynthetic       CPL\r\n" + 
                "      16 Met Gln Val Trp His Met Ser His Pro Ala Leu Thr Gln Leu Arg Ala   1\r\n" + 
                "                 5                  10                  15 Leu Arg Tyr Cys Lys\r\n" + 
                "     Glu Ile Pro Ala Leu Asp Pro Gln Leu Leu Asp              20\r\n" + 
                "        25                  30 Trp Leu Leu Leu Glu Asp Ser Met Thr Lys Arg Phe\r\n" + 
                "     Glu Gln Gln Gly          35                  40                  45 Lys\r\n" + 
                "     Thr Val Ser Val Thr Met Ile Arg Glu Gly Phe Val Glu Gln Asn      50\r\n" + 
                "                55                  60 Glu Ile Pro Glu Glu Leu Pro Leu Leu Pro\r\n" + 
                "     Lys Glu Ser Arg Tyr Trp  65                  70                  75\r\n" + 
                "                80 Leu Arg Glu Ile Leu Leu Cys Ala Asp Gly Glu Pro Trp Leu Ala\r\n" + 
                "     Gly                  85                  90                  95 Arg Thr\r\n" + 
                "     Val Val Pro Val Ser Thr Leu Ser Gly Pro Glu Leu Ala Leu             100\r\n" + 
                "                   105                 110 Gln Lys Leu Gly Lys Thr Pro Leu Gly\r\n" + 
                "     Arg Tyr Leu Phe Thr Ser Ser         115                 120\r\n" + 
                "       125 Thr Leu Thr Arg Asp Phe Ile Glu Ile Gly Arg Asp Ala Gly Leu Trp\r\n" + 
                "     130                 135                 140 Gly Arg Arg Ser Arg Leu Arg\r\n" + 
                "     Leu Ser Gly Lys Pro Leu Leu Leu Thr 145                 150\r\n" + 
                "       155                 160 Glu Leu Phe Leu Pro Ala Ser Pro Leu Tyr\r\n" + 
                "             165                 170\r\n" + 
                "<BR><BR><CENTER><B>* * * * *</B></CENTER>\r\n" + 
                "<HR><CENTER>\r\n" + 
                "<a href=http://pdfaiw.uspto.gov/.aiw?Docid=20020002715&homeurl=http%3A%2F%2Fappft.uspto.gov%2Fnetacgi%2Fnph-Parser%3FSect1%3DPTO2%2526Sect2%3DHITOFF%2526p%3D1%2526u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%2526r%3D15%2526f%3DG%2526l%3D50%2526d%3DPG01%2526S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%2526OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002%2526RS%3DPD%2F20020101-%3C20020107&PageNum=&Rtype=&SectionNum=&idkey=5ABB28D0C4DD\r\n" + 
                "><img src=\"/netaicon1/PTO/image.gif\" alt=\"[Image]\" border=\"0\" width=\"63\" height=\"24\" align=\"middle\"></A>\r\n" + 
                "</CENTER>\r\n" + 
                "<center>\r\n" + 
                "<A HREF=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/AddToShoppingCart?docNumber=US20020002715&backUrl1=http%3A//appft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26p%3D1%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%26r%3D15%26f%3DG%26l%3D50%26d%3DPG01%26S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%26OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002&backLabel1=Back%20to%20Published%20Application%20Number%3A%2020020002715\">\r\n" + 
                "<img border=0 src=\"/netaicon1/PTO/order.gif\" alt=\"[Order Copy]\"></A>\r\n" + 
                "<A HREF=\"http://ebiz1.uspto.gov/vision-service/ShoppingCart_P/ShowShoppingCart?backUrl1=http%3A//appft.uspto.gov/netacgi/nph-Parser?Sect1%3DPTO2%26Sect2%3DHITOFF%26p%3D1%26u%3D%25252Fnetahtml%25252FPTO%25252Fsearch-adv.html%26r%3D15%26f%3DG%26l%3D50%26d%3DPG01%26S1%3D%252540PD%25253E%25253D20020101%25253C%25253D20020107%26OS%3Dpd%2F1%2F1%2F2002-%3C1%2F7%2F2002&backLabel1=Back%20to%20Published%20Application%20Number%3A%2020020002715\">\r\n" + 
                "<img border=0 src=\"/netaicon1/PTO/cart.gif\" border=0 alt=\"Shopping Cart\"]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=15&f=S&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&Query=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/hitlist.gif border=0 ALT=[CURR_LIST]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=2&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=15&f=S&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&Query=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/nextlist.gif border=0 ALT=[NEXT_LIST]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=14&f=G&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&OS=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/prevdoc.gif border=0 ALT=[PREV_DOC]></A>\r\n" + 
                "<A  HREF=/netacgi/nph-Parser?Sect1=PTO2&Sect2=HITOFF&p=1&u=%2Fnetahtml%2FPTO%2Fsearch-adv.html&r=16&f=G&l=50&d=PG01&S1=%40PD%3E%3D20020101%3C%3D20020107&OS=pd/1/1/2002-&gt;1/7/2002><IMG ALIGN=MIDDLE SRC=/netaicon1/PTO/nextdoc.gif border=0 ALT=[NEXT_DOC]></A>\r\n" + 
                "<a href=\"#top\"><img align=middle src=\"/netaicon1/PTO/top.gif\" border=0></a>\r\n" + 
                "</center>\r\n" + 
                "<a name=\"bottom\"></a>\r\n" + 
                "<center>\r\n" + 
                "<A HREF=\"/netahtml/PTO/help/help.html\"><IMG BORDER=\"0\" WIDTH=\"63\" HEIGHT=\"24\" SRC=\"/netaicon1/PTO/help.gif\" ALT=\"[Help]\" align=middle></A>\r\n" + 
                "<a href=\"/netahtml/PTO/index.html\"><img src=\"/netaicon1/PTO/home.gif\" alt=\"[Home]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<a href=\"/netahtml/PTO/search-bool.html\"><img src=\"/netaicon1/PTO/boolean.gif\" alt=\"[Boolean Search]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<A HREF=\"/netahtml/PTO/search-adv.html\"><IMG WIDTH=\"63\" HEIGHT=\"24\" BORDER=\"0\" SRC=\"/netaicon1/PTO/manual.gif\" ALT=\"[Manual]\" align=middle></A>\r\n" + 
                "<a href=\"/netahtml/PTO/srchnum.html\"><img src=\"/netaicon1/PTO/number.gif\" alt=\"[Number Search]\" border=\"0\" width=\"63\" height=\"24\" align=middle></a>\r\n" + 
                "<A HREF=\"http://www.uspto.gov/go/ptdl/\">\r\n" + 
                "<IMG width=63 height=24 border=0 SRC=\"/netaicon1/PTO/ptdl.gif\" ALT=\"[PTDLs]\" align=middle></A>\r\n" + 
                "</center></BODY>\r\n" + 
                "</HTML>";
        
        UsptoPublicationPatent patent = tool.parseHtml(html);
        
        GsonBuilder builder = new GsonBuilder();
        builder.setDateFormat("yyyy-MM-dd");
        Gson gson = builder.create();
         
        String json = gson.toJson(patent); 
        
        System.out.println(json);
    }
    
}
