package patft.util;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * 負責解析HTML特殊字元
 */
public class UsptoStringUtils {
    public static String unescapeHtml(String s) {
        if (s == null) {
            return null;
        }
        s = s.replaceAll("\\&;", "\\&amp;;");
        s = s.replaceAll("(\\&[^\\s;]+)(\\s)", "$1;$2");
        return StringEscapeUtils.unescapeHtml(s);
    }
}
