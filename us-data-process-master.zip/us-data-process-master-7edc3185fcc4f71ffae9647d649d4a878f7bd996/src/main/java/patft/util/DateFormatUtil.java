package patft.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DateFormatUtil {
    private static Log log = LogFactory.getLog(DateFormatUtil.class);

    public static String formatDate(DateFormat dateFormat, Date date) {
        if (date == null) {
            return "";
        }

        if (dateFormat == null) {
            return date.toString();
        }

        return dateFormat.format(date);
    }

    public static String formatDate(String pattern, Date date) {
        if (date == null) {
            return "";
        }

        DateFormat dateFormat = null;
        try {
            dateFormat = new SimpleDateFormat(pattern);
        } catch (Exception e) {
            log.error("pattern:" + pattern + "\n" + e.getMessage(), e);
        }
        return formatDate(dateFormat, date);
    }

    /**
     * for jsp
     */
    public static DateFormat getDateFormatYYYYMMDDHHMISS() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    }

    public static DateFormat getDateFormatYYYYMMDDHHMI() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm");
    }

    public static DateFormat getDateFormatYYYYMMDD() {
        return new SimpleDateFormat("yyyy/MM/dd");
    }

    public static DateFormat getDateFormatYYYY() {
        return new SimpleDateFormat("yyyy");
    }
    
    public static String formatYYYYMMDDHHMISSZ(Date date) {
        return formatDate("yyyy/MM/dd HH:mm:ss Z", date);
    }

    public static String formatYYYYMMDDHHMISS(Date date) {
        return formatDate(getDateFormatYYYYMMDDHHMISS(), date);
    }

    public static String formatYYYYMMDDHHMIZ(Date date) {
        return formatDate("yyyy/MM/dd HH:mm Z", date);
    }

    public static String formatYYYYMMDDHHMI(Date date) {
        return formatDate(getDateFormatYYYYMMDDHHMI(), date);
    }

    public static String formatYYYYMMDD(Date date) {
        return formatDate(getDateFormatYYYYMMDD(), date);
    }

    public static String formatYYYY(Date date) {
        return formatDate(getDateFormatYYYY(), date);
    }
}
