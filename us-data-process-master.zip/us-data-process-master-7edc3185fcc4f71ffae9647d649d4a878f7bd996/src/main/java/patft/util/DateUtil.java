package patft.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static int getThisYear() {
        return getYearInt(new Date());
    }

    public static int getYearInt(Date date) {
        Integer year = getYearInteger(date);
        if (year != null) {
            return year;
        } else {
            return 0;
        }
    }

    public static Integer getYearInteger(Date date) {
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar.get(Calendar.YEAR);
        } else {
            return null;
        }
    }

    public static String getYearString(Date date) {
        if (date != null) {
            return DateFormatUtil.formatYYYY(date);
        } else {
            return null;
        }
    }
    
    public static int getYearMonInt(Date date) {
        Integer yearMon = getYearMonInteger(date);
        if (yearMon != null) {
            return yearMon;
        } else {
            return 0;
        }
    }

    public static Integer getYearMonInteger(Date date) {
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH) + 1; // Note: zero based!
            return year * 100 + month;
        } else {
            return null;
        }
    }
}
