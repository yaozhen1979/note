package patft.util;

import org.apache.commons.lang.StringEscapeUtils;

public abstract class WebToolUtil {

    public static String trimHtmlTag(String html) {
        if (html != null) {
            html = html.replaceAll("<[^>]+?>", "");
        }
        return html;
    }

    public static String trimHtmlSpace(String html) {
        if (html != null) {
            html = html.replaceAll("&nbsp;", " ");
        }
        return html;
    }

    public static String trimCrlf(String html) {
        if (html != null) {
            html = html.replaceAll("[\t\r\n]", " ");
        }
        return html;
    }

    public static String trimSpace(String html) {
        if (html != null) {
            html = html.replaceAll(" {2,}", " ").trim();
        }
        return html;
    }

    public static String unescapeHtml(String html) {
        if (html != null) {
            html = StringEscapeUtils.unescapeHtml(html);
        }
        return html;
    }
}
