package patft;

import java.io.Serializable;

import patft.exception.GeneralRuntimeException;
import patft.vo.patent.IPatentUniqueNoGenerator;
import patft.vo.patent.PoPatent;

public class PatentUniqueNo implements Serializable {
    private static final long serialVersionUID = -532671606065301250L;

    protected String uniqueNo;

    protected PatentUniqueNo() {
    }

    public String getUniqueNo() {
        return uniqueNo;
    }

    public static PatentUniqueNo createPatentUniqueNo(PoPatent poPatent) {
        if (poPatent == null) {
            throw new GeneralRuntimeException("poPatent == null");
        }

        PatentUniqueNo patentUniqueNo = null;
        if (IPatentUniqueNoGenerator.class.isInstance(poPatent)) {
            patentUniqueNo = new PatentUniqueNo();
            patentUniqueNo.uniqueNo = IPatentUniqueNoGenerator.class.cast(poPatent).generateUniqueNo();
        }

        if (patentUniqueNo != null && patentUniqueNo.getUniqueNo() != null && patentUniqueNo.getUniqueNo().length() > 0) {
            return patentUniqueNo;
        }

        throw new GeneralRuntimeException("createPatentUniqueNo fail : countryCode=" + poPatent.getCountryCode()
                + ",applicationNo=" + poPatent.getApplicationNo() + ",appYear=" + poPatent.getAppYear()
                + ",sourceType=" + poPatent.getSourceType());
    }
}
