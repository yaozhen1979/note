package patft.exception;

import org.apache.commons.lang.exception.NestableRuntimeException;

public class GeneralRuntimeException extends NestableRuntimeException {
    private static final long serialVersionUID = -602650581492518738L;

    private String messageI18nKey;

    public GeneralRuntimeException() {
        super();
    }

    public GeneralRuntimeException(String message) {
        super(message);
    }

    public GeneralRuntimeException(Throwable throwable) {
        super(throwable);
    }

    public GeneralRuntimeException(String message, Throwable throwable) {
        super(message, throwable);
    }

    public String getMessageI18nKey() {
        return messageI18nKey;
    }
    public void setMessageI18nKey(String messageI18nKey) {
        this.messageI18nKey = messageI18nKey;
    }
}
