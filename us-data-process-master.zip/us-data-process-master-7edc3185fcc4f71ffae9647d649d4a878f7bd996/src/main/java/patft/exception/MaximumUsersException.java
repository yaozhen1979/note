package patft.exception;

import org.apache.commons.lang.exception.NestableException;

public class MaximumUsersException extends NestableException {
    private static final long serialVersionUID = 5137965622659969856L;

    public MaximumUsersException(String message) {
        super(message);
    }

    public MaximumUsersException() {
        super();
    }

    public MaximumUsersException(Throwable arg0) {
        super(arg0);
    }

    public MaximumUsersException(String message, Throwable arg1) {
        super(message, arg1);
    }
}
