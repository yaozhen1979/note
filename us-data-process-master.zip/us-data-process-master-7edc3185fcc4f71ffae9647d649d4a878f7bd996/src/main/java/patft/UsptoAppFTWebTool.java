package patft;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.regexp.RESyntaxException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import patft.country.CountryCode;
import patft.exception.GeneralRuntimeException;
import patft.exception.MaximumUsersException;
import patft.number.PoNumberUtil;
import patft.number.UsptoNumberUtil;
import patft.util.UsptoStringUtils;
import patft.vo.PatentClassCode;
import patft.vo.PatentClassCodeConstant;
import patft.vo.patent.Assignee;
import patft.vo.patent.ForeignAppPriorityData;
import patft.vo.patent.Inventor;
import patft.vo.patent.PatentConstant;
import patft.vo.patent.RelatedUSPatentDoc;
import patft.vo.patent.UsptoPublicationPatent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 提供 <a href="http://www.uspto.gov/patft/index.html"> Uspto</a>網站 Published
 * Applications (AppFT)搜尋及下載 patent 的功能。
 */
public class UsptoAppFTWebTool extends UsptoWebTool {
    private static Logger log = LoggerFactory.getLogger(UsptoAppFTWebTool.class);

    public UsptoAppFTWebTool() {
    }
    
    /**
     * @param documentNo
     * @return
     */
    private static String getDownloadUrl(String documentNo) {
        String url = "http://appft1.uspto.gov/netacgi/nph-Parser?Sect1=PTO1&Sect2=HITOFF&d=PG01&p=1&u=%2Fnetahtml%2FPTO%2Fsrchnum.html&r=1&f=G&l=1&"
            + "s1=%22"
            + documentNo
            + "%22.PGNR.";
        return url;
    }

    public UsptoPublicationPatent parseHtml(String html2)
        throws RESyntaxException, ParseException, IOException {

        String html = html2.replaceAll("\r", "");

        UsptoPublicationPatent patent = new UsptoPublicationPatent();

        patent.setState(PatentConstant.PATENT_STATE_PUBLICATION);
        patent.setCountryCode(CountryCode.US);

        Map<String, String> map = parseDocNoKindcodePublishDate(html);
        String publicationNo = map.get("docNo");
        publicationNo = PoNumberUtil.formatNumber(publicationNo);

        patent.setPatentNo(publicationNo);
        patent.setPublicationNo(publicationNo);
        Date publicationDate = new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH).parse(map.get("publicationDate"));
        patent.setPublicationDate(publicationDate);
        
        if (map.get("kindcode") != null) {
            patent.setKindCode(map.get("kindcode"));
        }
        
        String titleStr = parseTitle(html);
        if (titleStr.contains("TEXT NOT AVAILABLE")) {
            
            // 20010003111 此筆資料只有documentNo, kindcode, publicationDate
            // 且 title 文字為 TEXT NOT AVAILABLE
            throw new GeneralRuntimeException("TEXT NOT AVAILABLE");
        } else {
            patent.setTitle(UsptoStringUtils.unescapeHtml(parseTitle(html)));
        }
        
        /*
         * Inventors:
         * Assignee:
         * Family ID:
         * Serial No.:
         * Series Code:
         * Filed:
         * Correspondence Address:
         */
        Map<String, String> rowMap = parseRow(html);
        //Inventors
        patent.setInventors(parseInventor(rowMap));
        //Assignee
        patent.setAssignees(parseAssignee(rowMap));
        //Family ID
        patent.setFamilyId(parseFamilyId(rowMap));

        //Appl. No.
        String rawAppNo = parseApplicationNo(rowMap);
        if (rawAppNo == null || rawAppNo.length() == 0) {
            String seriesCode = parseSeriesCode(rowMap);
            String serialNo = parseSerialNo(rowMap);
            StringBuffer sb = new StringBuffer();
            if (seriesCode != null) {
                sb.append(seriesCode);
            }
            sb.append("/");
            if (serialNo != null) {
                sb.append(serialNo);
            }
            rawAppNo = sb.toString(); 
        }
        patent.setRawAppNo(rawAppNo);
        String applicationNo = UsptoNumberUtil.normalizeAppNo(rawAppNo);
        patent.setApplicationNo(applicationNo);

        //Filed
        patent.setApplicationDate(parseField(rowMap));
        //Correspondence Address
        patent.setCorrespondenceNameAndAddress(parseCorrespondenceAddress(rowMap));

        patent.setAbstractt(UsptoStringUtils.unescapeHtml(parseAbstract(html)));

        patent.setRelatedUSPatentDocs(parseRelatedUSPatentDocuments(html));
        patent.setForeignAppPriorityDatas(parseForeignApplicationDatas(html));

        List<PatentClassCode> upcList = parseCurrentUsClass(html);
        List<PatentClassCode> ipcList = parseClass(PatentClassCodeConstant.CLASSIFICATION_IPC, html);
        List<PatentClassCode> cpcList = parseClass(PatentClassCodeConstant.CLASSIFICATION_CPC, html);
        List<PatentClassCode> usClassAtPubList = parseUsClassAtPublication(html);
        patent.setPatentClassCodes(generatePatentClassCodeSet(upcList, ipcList, usClassAtPubList, cpcList));
        patent.setPatentClassCodeAppends(generatePatentClassCodeAppendSet(upcList, ipcList, usClassAtPubList, cpcList));

        patent.setClaims(parseClaims(html));
        patent.setDescription(parseDescription(html));

        return patent;
    }
    
    private Map<String, String> parseDocNoKindcodePublishDate(String html) {
        
        Map<String, String> map = new HashMap<String, String>();
        String[] fieldArry = Pattern.compile("<table width=\"100%\">", Pattern.CASE_INSENSITIVE).split(html);
        if (fieldArry.length == 1) {
            return null;
        }
        
        String s = fieldArry[1];
        s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(s)[0];
        
        Document doc = Jsoup.parse("<TABLE>" + s + "</TABLE>");
        Elements trs = doc.select("tr");
        
        // documentNo
        Elements firstTds = trs.get(0).select("td");
        if (firstTds.get(0).text().trim().contains("United States Patent Application")) {
            map.put("docNo", firstTds.get(1).text().trim());
        }
        // kindcode
        Elements secondTds = trs.get(1).select("td");
        if (secondTds.get(0).text().trim().contains("Kind Code")) {
            map.put("kindcode", secondTds.get(1).text().trim());
        }
        
        Elements thirdTds = trs.get(2).select("td");
        map.put("publicationDate", thirdTds.get(1).text().trim());
        
        return map;
    }

    private Map<String, String> parseRow(String html) {
        String[] rows = html.replaceAll("(\r\n|\n)", "").split("(?i)<TR> *<T[DH][^<>]* VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\"[^<>]*>");
        if (rows == null || rows.length < 2) {
            return null;
        }
        Map<String, String> map = new HashMap<String, String>();
        for (int i = 1; i < rows.length; i++) {
            String row = rows[i];
            row = row.split("(?i)</TD> *\n? *</TR>")[0];
            row = row.replaceAll("\n", " ").replaceAll(" {2,}", " ");
            String[] ary = row.split("(?i)</T[DH]> *<TD ALIGN=\"LEFT\" WIDTH=\"\\d+%\">");
            map.put(ary[0].trim(), ary[1].trim());
        }
        return map;
    }

    private String getRowValue(Map<String, String> rowMap, String key) {
        if (rowMap.containsKey(key)) {
            return rowMap.get(key);
        } else {
            for (String rowRey : rowMap.keySet()) {
                if (rowRey.indexOf(key) >= 0) {
                    return rowMap.get(rowRey);
                }
            }
            return null;
        }
    }

    private List<Inventor> parseInventor(Map<String, String> rowMap) {
        List<Inventor> inventorList = new ArrayList<Inventor>();

        String s = getRowValue(rowMap, "Inventors:");
        
        Pattern pattern = Pattern.compile("<B>;* *([^<>]*)</B>;* *<I>\\(([^<>]*)\\)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(s);
        while (matcher.find()) {
            String name = matcher.group(1).trim();
            String address = matcher.group(2).trim();
            Inventor inventor = new Inventor();
            inventor.setName(name);
            inventor.setAddress(address);
            inventorList.add(inventor);
        }
        return inventorList;
    }

    private List<Assignee> parseAssignee(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Assignee:");

        if (s != null) {
            String[] blocks = s.split("(?i)<BR> *<BR>");
            List<Assignee> assigneeList = new ArrayList<Assignee>();
            for (String block : blocks) {
                String name = null;
                String address = null;
                
                int idx = block.replace("<br>", "<BR>").indexOf("<BR>");
                if (idx >= 0) {
                    name = block.substring(0, idx).replaceAll("<[^<>]*>", " ").replaceAll(" {2,}", " ").trim();
                    address = block.substring(idx).replaceAll("<[^<>]*>", " ").replaceAll(" {2,}", " ").trim();
                    // 20040200294 這篇怪怪的,沒有assignee name,but 有地址
                    if (name.indexOf("1F, No. 3, Lane 99, Pu-Ding Road") >= 0) {
                        address = name;
                        name = "";
                    }
                } else {
                    name = block.replaceAll("<[^<>]*>", " ").replaceAll(" {2,}", " ").trim();
                    address = "";
                }
                Assignee assignee = new Assignee();
                assignee.setName(name);
                assignee.setAddress(address);
                assigneeList.add(assignee);
            }
            return assigneeList;

        } else {
            return null;
        }
    }
    
    private String parseFamilyId(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Family ID:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private String parseApplicationNo(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Appl. No.:");
        if (s != null) {
            s = s.replaceAll("(?i)<B>|</B>", "").trim();
        }
        return s;
    }

    private String parseSerialNo(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Serial No.:");
        if (s != null) {
            s = s.replaceAll("(?i)<B>|</B>", "").trim();
        }
        return s;
    }

    private String parseSeriesCode(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Series Code:");
        if (s != null) {
            s = s.replaceAll("(?i)<B>|</B>", "").trim();
        }
        return s;
    }

    private Date parseField(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "Filed:");
        s = s.replaceAll("(?i)<B>|</B>", "").trim();
        Date field = parseDate(s);
        if (isLessThan1790(field)) {
            field = null;
        }
        return field;
    }

    private String parseCorrespondenceAddress(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Correspondence Address:");
        if (s != null) {
            s = s.replaceAll("(?i)</?B>|</?PRE>", "").trim();
        }
        return s;
    }

    private String parseTitle(String html) {
        String s = StringUtils.substringBetween(html, "<font size=\"+1\">", "</font>");
        if (s != null) {
            s = s.replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        }
        return s;
    }

    private String parseAbstract(String html) {
        String[] ary = Pattern.compile("<b>Abstract</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        s = s.replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        return s;
    }
    
    private List<RelatedUSPatentDoc> parseRelatedUSPatentDocuments(String html) {
        // 先取出 Related U.S. Patent Documents 的區塊
        String[] ary = Pattern.compile("<b>Related U.S. Patent Documents</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        String[] rows = Pattern.compile("</TR>", Pattern.CASE_INSENSITIVE).split(s);
        if (rows == null || rows.length < 3) {
            return null;
        }

        List<RelatedUSPatentDoc> relatedList = null;

        for (int i = 2; i < rows.length; i++) {
            String[] cols = Pattern.compile("</TH>|</TD>", Pattern.CASE_INSENSITIVE).split(rows[i]);
            if (cols == null || cols.length < 5) {
                continue;
            }
            for (int j = 0; j < cols.length; j++) {
                cols[j] = cols[j].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            }

            String reissue = cols[0];
            String applicationNo = cols[1];
            String patentNo = cols[3];

            Date filingDate = null;
            try {
                filingDate = parseDate(cols[2]);
            } catch (ParseException e) {
                log.error(e.getMessage(), e);
            }

            Date issueDate = null;
            try {
                issueDate = parseDate(cols[4]);
            } catch (ParseException e) {
                log.error(e.getMessage(), e);
            }

            if (applicationNo != null && applicationNo.indexOf("Truncated") >= 0) {
                continue;
            }

            RelatedUSPatentDoc doc = new RelatedUSPatentDoc();
            if (reissue != null && reissue.indexOf("Reissue") >= 0) {
                doc.setReissue("1");
            }
            doc.setApplicationNo(applicationNo);
            doc.setFilingDate(filingDate);
            doc.setPatentNo(patentNo);
            doc.setIssueDate(issueDate);

            if (relatedList == null) {
                relatedList = new ArrayList<RelatedUSPatentDoc>();
            }
            relatedList.add(doc);
        }

        return relatedList;
    }

    private List<ForeignAppPriorityData> parseForeignApplicationDatas(String html) throws RESyntaxException,
            ParseException {
        
        String[] ary = Pattern.compile("<I>Foreign Application Data</I>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        
        String[] fieldArry = Pattern.compile("<table width=\"100%\">", Pattern.CASE_INSENSITIVE).split(ary[1]);
        if (fieldArry.length == 1) {
            return null;
        }
        
        String s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(fieldArry[1])[0];
        Document doc = Jsoup.parse("<TABLE>" + s + "</TABLE>");
        Elements trs = doc.select("tr");
        
        List<ForeignAppPriorityData> priorityList = new ArrayList<ForeignAppPriorityData>();        
        ForeignAppPriorityData foreignApplicationData = null;
        for (int i=1; i<trs.size(); i++) {
            foreignApplicationData = new ForeignAppPriorityData();
            Elements tds = trs.get(i).select("td");
            //
            String dateStr = tds.get(0).text().trim();
            try {
                // foreignApplicationData 的 date欄位會出現 No Date Available 文字, pn : 20010000007
                foreignApplicationData.setDate(new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH).parse(dateStr));
            } catch (ParseException pe) {
                log.error(pe.getMessage());
            }
            
            // 會出現只有appDate,及appNumber兩個欄位且appNumber誤植到country
            String countryCode = null;
            String applicationNo = null;
            if (tds.size() == 3) {
                countryCode = tds.get(1).text().trim();
                applicationNo = tds.get(2).text().trim();
            } else if (tds.size() == 2) {
                if (tds.get(1).text().trim().length() == 2) {
                    countryCode = tds.get(1).text().trim();
                } else {
                    applicationNo = tds.get(1).text().trim();
                }
            }
            
            // 出現 Truncated Field -- See Image for remainder 則排除 
            if (countryCode != null && !StringUtils.contains(countryCode, "Truncated Field -- See Image for remainder")) {
                foreignApplicationData.setCountryCode(countryCode);
            }
            // 出現 Truncated Field -- See Image for remainder 則排除
            if (applicationNo != null && !StringUtils.contains(countryCode, "Truncated Field -- See Image for remainder")) {
                foreignApplicationData.setApplicationNo(applicationNo);
            }
            
            if (foreignApplicationData.getDate() != null || StringUtils.isNotBlank(foreignApplicationData.getCountryCode()) 
                    || StringUtils.isNotBlank(foreignApplicationData.getApplicationNo())) {
                priorityList.add(foreignApplicationData);
            }
            
        }
        
        if (priorityList.size() > 0) {
            return priorityList;
        } else {
            return null;
        }
        
    }
    
    private List<PatentClassCode> parseCurrentUsClass(String html)
            throws RESyntaxException, IOException {

        List<PatentClassCode> patentClassCodes = new ArrayList<PatentClassCode>();

        String[] fieldArry = Pattern.compile("Current U.S. Class:", Pattern.CASE_INSENSITIVE)
                .split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return patentClassCodes;
        }
        // 因為在abstract中也出現"Current U.S. Class: ", 故取最後一個, ex:20020160857
        String s = fieldArry[fieldArry.length - 1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];

        if (s != null) {
            // s = Pattern.compile("<[^<>]*>",
            // Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("");
            // s = s.replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            String[] nos = split(s, ";");

            int pos = 0;
            for (String classNo : nos) {
                if (classNo == null) {
                    continue;
                }
                PatentClassCode patentClassCode = new PatentClassCode();
                classNo = classNo.replaceAll("/000|/00|/0", "/");
                // 粗體為主USPC
                if (classNo.contains("<b>")) {
                    patentClassCode.setMain(true);
                }
                classNo = Pattern.compile("<[^<>]*>", Pattern.CASE_INSENSITIVE).matcher(classNo).replaceAll("");
                classNo = classNo.trim();
                if (classNo.length() == 0) {
                    continue;
                }

                patentClassCode.setType(PatentClassCodeConstant.CLASSIFICATION_UPC);
                patentClassCode.setPos(pos++);
                patentClassCode.setClassNo(classNo);

                patentClassCodes.add(patentClassCode);
            }
        }
        return patentClassCodes;
    }
    
    private List<PatentClassCode> parseClass(int type, String html) {
        List<PatentClassCode> patentClassCodes = new ArrayList<PatentClassCode>();

        String field = "International Class:";
        if (type == PatentClassCodeConstant.CLASSIFICATION_CPC) {
            field = "Current CPC Class:";
        }
        
        String[] fieldArry = Pattern.compile(field, Pattern.CASE_INSENSITIVE).split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return patentClassCodes;
        }
        String s = fieldArry[1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];

        if (s != null) {
            s = s.replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            String[] nos = split(s, ";");

            int pos = 0;
            for (String classNo : nos) {
                if (classNo == null) {
                    continue;
                }

                Pattern pattern = Pattern.compile(".* (\\d{8})$");
                Matcher matcher = pattern.matcher(classNo);
                String version = "";
                if (matcher.find()) {
                    version = matcher.group(1).trim();
                }
                
                // 把 H04N 7/10 20060101 H04N007/10 2006... 之後的都濾掉 過濾掉
                classNo = classNo.split(" \\d{6}")[0];
                classNo = classNo.trim();
                if (classNo.length() == 0) {
                    continue;
                }

                PatentClassCode patentClassCode = new PatentClassCode();

                patentClassCode.setVersion(version);
                patentClassCode.setType(type);
                patentClassCode.setPos(pos++);
                patentClassCode.setClassNo(classNo);

                patentClassCodes.add(patentClassCode);
            }
        }
        return patentClassCodes;
    }

    private List<PatentClassCode> parseUsClassAtPublication(String html) {
        List<PatentClassCode> patentClassCodes = new ArrayList<PatentClassCode>();

        String[] fieldArry = Pattern.compile("Class at Publication:", Pattern.CASE_INSENSITIVE)
                .split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return patentClassCodes;
        }
        
        String s = fieldArry[1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];

        if (s != null) {
            s = s.replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            String[] nos = split(s, ";");

            int pos = 0;
            for (String classNo : nos) {
                PatentClassCode patentClassCode = new PatentClassCode();

                if (classNo == null) {
                    continue;
                }
                if (classNo.replace("<b>", "<B>").contains("<B>")) {
                    patentClassCode.setMain(true);
                }
                classNo = classNo.replaceAll("<[^<>]*>", "").trim();
                if (classNo.length() == 0) {
                    continue;
                }

                patentClassCode.setType(PatentClassCodeConstant.CLASSIFICATION_UPC_AT_PUBLICATION);
                patentClassCode.setPos(pos++);
                patentClassCode.setClassNo(classNo);

                patentClassCodes.add(patentClassCode);
            }
        }
        return patentClassCodes;
    }

    private String parseClaims(String html) {
        String separator = "Claims</I></B>";
        html = html.replace("</i>", "</I>").replace("</b>", "</B>").replace("<hr>", "<HR>").replaceAll("(\r\n|\n)", "");
        if (html.indexOf(separator) > 0) {
            String s = StringUtils.substringAfter(html, separator).split("<HR>")[1];
            s = s.trim();
            return s;
        } else {
            return null;
        }
    }

    private String parseDescription(String html) {
        
        html = html.replaceAll("(\r\n|\n)", "");
        String[] fieldArry = Pattern.compile("Description</I></B>", Pattern.CASE_INSENSITIVE)
                .split(html);
        if (fieldArry.length == 1) {
            return null;
        }
        
        String[] fieldArry1 = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE)
                .split(fieldArry[1]);
        if (fieldArry1.length == 1) {
            return null;
        }
        
        String[] fieldArry2 = Pattern.compile("<CENTER>\\s*<B>\\* \\* \\* \\* \\*</B>", Pattern.CASE_INSENSITIVE)
                .split(fieldArry1[1]);
        
        if (fieldArry2.length == 1) {
            return null;
        }
        
        return fieldArry2[0].trim();
        
    }

    private String parseKindCode(String html) {
        String temp = StringUtils.substringBetween(
            html,
            "<B>Kind Code</B>",
            "</TD></TR>");
        return StringUtils.substringBetween(temp, "<B>", "\n");
    }

    /**
     * @param html
     * @throws MaximumUsersException
     */
    public static void checkHtml(String html) throws MaximumUsersException {
        if (html.startsWith("Error #2012")) { // 讀取時發生人數過多
            String message = StringUtils.substringBetween(html, "<H4>", "</H4>");
            throw new MaximumUsersException(message);
        }

    }

    private String[] split(String s1, String s2) {
        String[] s = s1.split(s2);
        for (int i = 0; i < s.length; i++) {
            s[i] = s[i].replaceAll("\n", "").trim();
        }
        return s;
    }
}
