package patft.country;

import java.util.ArrayList;
import java.util.List;

class CountryList implements CountryCode {

    protected static final List<String> EPO_COUNTRY_CODE = new ArrayList<String>();
    protected static final List<String> ALL_COUNTRY_CODE = new ArrayList<String>();

    static {
        EPO_COUNTRY_CODE.add(AL);
        EPO_COUNTRY_CODE.add(AT);
        EPO_COUNTRY_CODE.add(BE);
        EPO_COUNTRY_CODE.add(BG);
        EPO_COUNTRY_CODE.add(CH);
        EPO_COUNTRY_CODE.add(CY);
        EPO_COUNTRY_CODE.add(CZ);
        EPO_COUNTRY_CODE.add(DE);
        EPO_COUNTRY_CODE.add(DK);
        EPO_COUNTRY_CODE.add(EE);
        EPO_COUNTRY_CODE.add(ES);
        EPO_COUNTRY_CODE.add(FI);
        EPO_COUNTRY_CODE.add(FR);
        EPO_COUNTRY_CODE.add(GB);
        EPO_COUNTRY_CODE.add(GR);
        EPO_COUNTRY_CODE.add(HR);
        EPO_COUNTRY_CODE.add(HU);
        EPO_COUNTRY_CODE.add(IE);
        EPO_COUNTRY_CODE.add(IS);
        EPO_COUNTRY_CODE.add(IT);
        EPO_COUNTRY_CODE.add(LI);
        EPO_COUNTRY_CODE.add(LT);
        EPO_COUNTRY_CODE.add(LU);
        EPO_COUNTRY_CODE.add(LV);
        EPO_COUNTRY_CODE.add(MC);
        EPO_COUNTRY_CODE.add(MK);
        EPO_COUNTRY_CODE.add(MT);
        EPO_COUNTRY_CODE.add(NL);
        EPO_COUNTRY_CODE.add(NO);
        EPO_COUNTRY_CODE.add(PL);
        EPO_COUNTRY_CODE.add(PT);
        EPO_COUNTRY_CODE.add(RO);
        EPO_COUNTRY_CODE.add(RS);
        EPO_COUNTRY_CODE.add(SE);
        EPO_COUNTRY_CODE.add(SI);
        EPO_COUNTRY_CODE.add(SK);
        EPO_COUNTRY_CODE.add(SM);
        EPO_COUNTRY_CODE.add(TR);

        ALL_COUNTRY_CODE.addAll(EPO_COUNTRY_CODE);
        //
        ALL_COUNTRY_CODE.add(US);
        ALL_COUNTRY_CODE.add(EP);
        ALL_COUNTRY_CODE.add(CN);
        ALL_COUNTRY_CODE.add(TW);
        ALL_COUNTRY_CODE.add(KR);
        ALL_COUNTRY_CODE.add(JP);
        //
        ALL_COUNTRY_CODE.add(AP);
        ALL_COUNTRY_CODE.add(AR);
        ALL_COUNTRY_CODE.add(AU);
        ALL_COUNTRY_CODE.add(BA);
        ALL_COUNTRY_CODE.add(BR);
        ALL_COUNTRY_CODE.add(BY);
        ALL_COUNTRY_CODE.add(CA);
        ALL_COUNTRY_CODE.add(CL);
        ALL_COUNTRY_CODE.add(CO);
        ALL_COUNTRY_CODE.add(CR);
        ALL_COUNTRY_CODE.add(CS);
        ALL_COUNTRY_CODE.add(CU);
        ALL_COUNTRY_CODE.add(DD);
        ALL_COUNTRY_CODE.add(DO);
        ALL_COUNTRY_CODE.add(DZ);
        ALL_COUNTRY_CODE.add(EA);
        ALL_COUNTRY_CODE.add(EC);
        ALL_COUNTRY_CODE.add(EG);
        ALL_COUNTRY_CODE.add(GC);
        ALL_COUNTRY_CODE.add(GE);
        ALL_COUNTRY_CODE.add(GT);
        ALL_COUNTRY_CODE.add(HK);
        ALL_COUNTRY_CODE.add(IB);
        ALL_COUNTRY_CODE.add(ID);
        ALL_COUNTRY_CODE.add(IL);
        ALL_COUNTRY_CODE.add(IN);
        ALL_COUNTRY_CODE.add(KE);
        ALL_COUNTRY_CODE.add(KP);
        ALL_COUNTRY_CODE.add(MA);
        ALL_COUNTRY_CODE.add(MD);
        ALL_COUNTRY_CODE.add(MW);
        ALL_COUNTRY_CODE.add(MX);
        ALL_COUNTRY_CODE.add(MY);
        ALL_COUNTRY_CODE.add(NI);
        ALL_COUNTRY_CODE.add(NZ);
        ALL_COUNTRY_CODE.add(OA);
        ALL_COUNTRY_CODE.add(PA);
        ALL_COUNTRY_CODE.add(PE);
        ALL_COUNTRY_CODE.add(PH);
        ALL_COUNTRY_CODE.add(RU);
        ALL_COUNTRY_CODE.add(SG);
        ALL_COUNTRY_CODE.add(SU);
        ALL_COUNTRY_CODE.add(SV);
        ALL_COUNTRY_CODE.add(TJ);
        ALL_COUNTRY_CODE.add(UA);
        ALL_COUNTRY_CODE.add(UY);
        ALL_COUNTRY_CODE.add(YU);
        ALL_COUNTRY_CODE.add(WO);
        ALL_COUNTRY_CODE.add(ZA);
        ALL_COUNTRY_CODE.add(ZM);
        ALL_COUNTRY_CODE.add(ZW);
    }

}
