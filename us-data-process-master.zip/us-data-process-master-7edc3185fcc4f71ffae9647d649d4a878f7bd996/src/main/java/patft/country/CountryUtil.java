package patft.country;

import java.util.Iterator;

import patft.exception.GeneralRuntimeException;

public abstract class CountryUtil {

    public static boolean isEpoCountry(String countryCode) {
        if (countryCode != null) {
            countryCode = countryCode.toUpperCase();
        }
        return CountryList.EPO_COUNTRY_CODE.contains(countryCode);
    }

    public static boolean isCountryCode(String countryCode) {
        if (countryCode != null) {
            countryCode = countryCode.toUpperCase();
        }
        return CountryList.ALL_COUNTRY_CODE.contains(countryCode);
    }

    public static Iterator<String> allCountryCodeIterator() {
        return CountryList.ALL_COUNTRY_CODE.iterator();
    }

    public static String getCountryCode(String country) {
        String countryCode = country;
        if (countryCode != null) {
            countryCode = countryCode.toUpperCase();
        }
        countryCode = CountryMap.COUNTRY_MAP.get(countryCode);
        if (countryCode == null && country != null && country.length() > 0) {
            throw new GeneralRuntimeException("undefined country : " + country);
        }
        return countryCode;
    }

    public static String parseCountryCodeFromNo(String no) {
        if (no != null) {
            no = no.trim().toUpperCase();
            Iterator<String> iterator = CountryUtil.allCountryCodeIterator();
            while (iterator.hasNext()) {
                String countryCode = iterator.next();
                if (no.indexOf(countryCode) == 0) {
                    return countryCode;
                }
            }
        }
        return null;
    }
}
