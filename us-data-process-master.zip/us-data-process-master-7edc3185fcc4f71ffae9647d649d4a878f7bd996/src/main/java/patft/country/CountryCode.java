package patft.country;

public interface CountryCode {
    String COMMON = "COMMON";

    String US = "US";
    String EP = "EP";
    String CN = "CN";
    String TW = "TW";
    String KR = "KR";
    String JP = "JP";

    /*
     * EpoCountryCode
     */
    String AL = "AL";
    String AT = "AT";
    String BE = "BE";
    String BG = "BG";
    String CH = "CH";
    String CY = "CY";
    String CZ = "CZ";
    String DE = "DE";
    String DK = "DK";
    String EE = "EE";
    String ES = "ES";
    String FI = "FI";
    String FR = "FR";
    String GB = "GB";
    String GR = "GR";
    String HR = "HR";
    String HU = "HU";
    String IE = "IE";
    String IS = "IS";
    String IT = "IT";
    String LI = "LI";
    String LT = "LT";
    String LU = "LU";
    String LV = "LV";
    String MC = "MC";
    String MK = "MK";
    String MT = "MT";
    String NL = "NL";
    String NO = "NO";
    String PL = "PL";
    String PT = "PT";
    String RO = "RO";
    String RS = "RS";
    String SE = "SE";
    String SI = "SI";
    String SK = "SK";
    String SM = "SM";
    String TR = "TR";

    /*
     * AllCountryCode
     */
    String AP = "AP";
    String AR = "AR";
    String AU = "AU";
    String BA = "BA";
    String BR = "BR";
    String BY = "BY";
    String CA = "CA";
    String CL = "CL";
    String CO = "CO";
    String CR = "CR";
    String CS = "CS";
    String CU = "CU";
    String DD = "DD";
    String DO = "DO";
    String DZ = "DZ";
    String EA = "EA";
    String EC = "EC";
    String EG = "EG";
    String GC = "GC";
    String GE = "GE";
    String GT = "GT";
    String HK = "HK";
    String IB = "IB";
    String ID = "ID";
    String IL = "IL";
    String IN = "IN";
    String KE = "KE";
    String KP = "KP";
    String MA = "MA";
    String MD = "MD";
    String MW = "MW";
    String MX = "MX";
    String MY = "MY";
    String NI = "NI";
    String NZ = "NZ";
    String OA = "OA";
    String PA = "PA";
    String PE = "PE";
    String PH = "PH";
    String RU = "RU";
    String SG = "SG";
    String SU = "SU";
    String SV = "SV";
    String TJ = "TJ";
    String UA = "UA";
    String UY = "UY";
    String YU = "YU";
    String WO = "WO";
    String ZA = "ZA";
    String ZM = "ZM";
    String ZW = "ZW";
}
