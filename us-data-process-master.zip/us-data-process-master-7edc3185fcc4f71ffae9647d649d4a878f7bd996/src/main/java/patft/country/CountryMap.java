package patft.country;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class CountryMap {

    protected static final Map<String, String> COUNTRY_MAP = new HashMap<String, String>();

    // 美國 \u7f8e\u570b
    private static String zhTWUS = new String(new char[] { '\u7f8e', '\u570b' });

    // 中國 \u4e2d\u570b
    private static String zhTWCN = new String(new char[] { '\u4e2d', '\u570b' });

    // 台灣 \u53f0\u7063
    private static String zhTWTW = new String(new char[] { '\u53f0', '\u7063' });

    // 韓國 \u97d3\u570b
    private static String zhTWKR = new String(new char[] { '\u97d3', '\u570b' });

    // 日本 \u65e5\u672c
    private static String zhTWJP = new String(new char[] { '\u65e5', '\u672c' });

    static {
        COUNTRY_MAP.put(zhTWUS, CountryCode.US);
        COUNTRY_MAP.put(zhTWCN, CountryCode.CN);
        COUNTRY_MAP.put(zhTWTW, CountryCode.TW);
        COUNTRY_MAP.put(zhTWKR, CountryCode.KR);
        COUNTRY_MAP.put(zhTWJP, CountryCode.JP);

        Iterator<String> iterator = CountryUtil.allCountryCodeIterator();
        while (iterator.hasNext()) {
            String countryCode = iterator.next();
            COUNTRY_MAP.put(countryCode, countryCode);
        }
    }
}
