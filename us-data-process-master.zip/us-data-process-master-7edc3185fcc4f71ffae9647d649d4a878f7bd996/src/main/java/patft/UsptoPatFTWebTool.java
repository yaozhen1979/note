package patft;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import patft.country.CountryCode;
import patft.exception.GeneralRuntimeException;
import patft.exception.MaximumUsersException;
import patft.number.PoNumberUtil;
import patft.number.UsptoNumberUtil;
import patft.util.UsptoStringUtils;
import patft.vo.PatentClassCode;
import patft.vo.PatentClassCodeConstant;
import patft.vo.patent.Assignee;
import patft.vo.patent.ForeignAppPriorityData;
import patft.vo.patent.Inventor;
import patft.vo.patent.PatentConstant;
import patft.vo.patent.RefOtherDoc;
import patft.vo.patent.RefPatent;
import patft.vo.patent.RelatedUSPatentDoc;
import patft.vo.patent.UsptoIssuePatent;

/**
 * 提供 <a href="http://www.uspto.gov/patft/index.html"> Uspto</a>網站 Issued
 * Patents (PatFT)搜尋及下載 patent 的功能。
 */
public class UsptoPatFTWebTool extends UsptoWebTool {
    private static Logger log = LoggerFactory.getLogger(UsptoPatFTWebTool.class);

    public UsptoPatFTWebTool() {
        super();
    }

    /**
     * 檢查 Uspto 是有丟出使用者過多的訊息,若有,則 throw MaximumUsersException
     *
     * @param html
     * @throws MaximumUsersException
     */
    private static void checkMaximumUsers(String html)
        throws MaximumUsersException {
        if (html.startsWith("Error #2012")) { // 讀取時發生人數過多
            String message = StringUtils.substringBetween(html, "<H4>", "</H4>");
            log.error(message);
            throw new MaximumUsersException(message);
        }
    }

    /**
     * 一般來說 patent 都是只有一個，不過有特例，例如 PP3,824，這時就需要多一個 record 的參數了。
     *
     * @param patentNo patent no
     * @param record 第幾筆
     * @return
     */
    private static String getDownloadUrl(String patentNo, int record) {
        String url = "http://patft.uspto.gov/netacgi/nph-Parser?"
            + "Sect2=PTO1&"
            + "Sect2=HITOFF&"
            + "p=1&u=%2Fnetahtml%2Fsearch-bool.html&"
            + "r="
            + record
            + "&f=G&"
            + "l=50&"
            + "d=PALL&"
            + "RefSrch=yes&"
            + "Query=PN%2F"
            + patentNo;
        return url;
    }

    /**
     * @param patentNo Patent Number
     * @return
     */
    private static String getDownloadUrl(String patentNo) {
        return getDownloadUrl(patentNo, 1);
    }

//    private String getPatentNoByUrl(String url) {
//        // 單筆 url 與 search 的單筆 url 不一樣，這裡並沒有完全處理完畢單筆 search 只是讓他不會爛掉而已
//        String patentNo = StringUtils.substringAfterLast(url, "Query=PN%2F");
//
//        if (StringUtils.isBlank(patentNo)) {
//            patentNo = StringUtils.substringAfterLast(url, "PN/");
//        }
//
//        return patentNo;
//    }

    public UsptoIssuePatent parseHtml(String html)
        throws RESyntaxException, IOException, ParseException,
        MaximumUsersException {
        
        checkMaximumUsers(html);
        
        UsptoIssuePatent patent = null;
        if (html.indexOf("Full text is not available for this patent") != -1) {
            patent = parseTextIsNotAvailablePatent(html);
        } else {
            patent = parseTextAvailableHtml(html);
        }
        
        if (patent.getIssueNo() == null || patent.getTitle() == null) {
            throw new GeneralRuntimeException("error parse title or no");
        }
        return patent;
    }

    private UsptoIssuePatent parseTextIsNotAvailablePatent(String html2)
        throws RESyntaxException, IOException,
        ParseException {
        String html = html2.replaceAll("\r", "");

        UsptoIssuePatent patent = new UsptoIssuePatent();

        patent.setState(PatentConstant.PATENT_STATE_ISSUE);
        patent.setCountryCode(CountryCode.US);

        Object[] issueNoDate = parseIssueNoDate(html);
        if (issueNoDate == null) {
            throw new GeneralRuntimeException("issue no or issue date errors");
        }
        String issueNo = (String) issueNoDate[0];
        Date issueDate = (Date) issueNoDate[1];

        issueNo = PoNumberUtil.formatNumber(issueNo);

        patent.setPatentNo(issueNo);
        patent.setIssueNo(issueNo);

        patent.setIssueDate(issueDate);

        List<PatentClassCode> upcList = parseCurrentUsClass(html, issueNo);
        List<PatentClassCode> ipcList = parseInternationalClass(html, issueNo);
        List<PatentClassCode> cpcList = parseClass(PatentClassCodeConstant.CLASSIFICATION_CPC, html);

        patent.setPatentClassCodes(generatePatentClassCodeSet(upcList, ipcList, cpcList));
        patent.setPatentClassCodeAppends(generatePatentClassCodeAppendSet(upcList, ipcList, cpcList));

        String title = "";
        if (upcList != null) {
            for (PatentClassCode ups : upcList) {
                title = title + ups.getClassNo() + " ";
            }
        }

        patent.setTitle(title);
        
//        StringBuffer summary = new StringBuffer();
//        summary.append("Patent No:" + CountryCode.US + patent.getIssueNo() + "\n");
//        if (patent.getAssignees() != null && !patent.getAssignees().isEmpty()) {
//            summary.append("Assignee:");
//            summary.append(StringUtils.join(patent.getAssignees().iterator(), ";"));
//            summary.append("\n");
//        }
//        if (patent.getAbstractt() != null) {
//            summary.append(patent.getAbstractt());
//        }
//        patent.setSummary(summary.toString());
//
//        PatentBriefInfo patentBriefInfo = new PatentBriefInfo();
//        patentBriefInfo.setPatentNo(patent.getPatentNo());
//        patentBriefInfo.setCountryCode(CountryCode.US);
//        patentBriefInfo.setState(PatentBriefInfo.PATENT_STATE_ISSUED);
//        patentBriefInfo.setPatentDocument(patent);
//        patent.setPatentBriefInfo(patentBriefInfo);

        return patent;
    }

    private UsptoIssuePatent parseTextAvailableHtml(String html2)
        throws ParseException, RESyntaxException, IOException {
    
        String html = html2.replaceAll("\r", "");

        UsptoIssuePatent patent = new UsptoIssuePatent();

        patent.setState(PatentConstant.PATENT_STATE_ISSUE);
        patent.setCountryCode(CountryCode.US);

        Object[] issueNoDate = parseIssueNoDate(html);
        if (issueNoDate == null) {
            throw new GeneralRuntimeException("issue no or issue date errors");
        }
        String issueNo = (String) issueNoDate[0];
        Date issueDate = (Date) issueNoDate[1];

        issueNo = PoNumberUtil.formatNumber(issueNo);

        patent.setPatentNo(issueNo);
        patent.setIssueNo(issueNo);
        patent.setIssueDate(issueDate);

        /*
         * Inventors:
         * Assignee:
         * Notice:
         * Family ID:
         * Appl. No.:
         * Filed:
         * PCT Filed:
         * PCT No.:
         * 371(c)(1),(2),(4) Date:
         * 371 Date:
         * 102(e) Date:
         * PCT Pub. No.:
         * PCT Pub. Date:
         */
        Map<String, String> rowMap = parseRow(html);
        //Inventors
        patent.setInventors(parseInventor(rowMap));
        //Assignee
        patent.setAssignees(parseAssignee(rowMap));
        //Notice
        patent.setNotice(parseNotice(rowMap));
        //Family ID
        patent.setFamilyId(parseFamilyId(rowMap));
        //Appl. No.
        String rawAppNo = parseApplicationNo(rowMap);
        /*
         * applicationNo
         */
        String applicationNo = UsptoNumberUtil.normalizeAppNo(rawAppNo);
        patent.setRawAppNo(rawAppNo);
        patent.setApplicationNo(applicationNo);
        //Filed
        patent.setApplicationDate(parseField(rowMap));
        //PCT Filed
        patent.setPctField(parsePctField(rowMap));
        //PCT No.
        patent.setPctNo(parsePctNo(rowMap));
        //371(c)(1),(2),(4) Date
        patent.setD371c124(parseD371c124(rowMap));
        //371 Date
        patent.setD371(parseD371(rowMap));
        //102(e) Date
        patent.setD102e(parseD102e(rowMap));
        //PCT Pub. No.
        patent.setPctPubNo(parsePctPubNo(rowMap));
        //PCT Pub. Date
        patent.setPctPubDate(parsePctPubDate(rowMap));

        patent.setTitle(UsptoStringUtils.unescapeHtml(parseTitle(html)));
        patent.setAbstractt(UsptoStringUtils.unescapeHtml(parseAbstract(html)));

        patent.setRelatedUSPatentDocs(parseRelatedUSPatentDocuments(html));
        patent.setForeignAppPriorityDatas(parseForeignApplicationPriorityDatas(html));

        List<PatentClassCode> upcList = parseCurrentUsClass(html, issueNo);
        List<PatentClassCode> ipcList = parseInternationalClass(html, issueNo);
        List<PatentClassCode> cpcList = parseClass(PatentClassCodeConstant.CLASSIFICATION_CPC, html);

        patent.setPatentClassCodes(generatePatentClassCodeSet(upcList, ipcList, cpcList));
        patent.setPatentClassCodeAppends(generatePatentClassCodeAppendSet(upcList, ipcList, cpcList));

        patent.setFieldOfSearch(parseFieldOfSearch(html));
        patent.setRefPatents(parseReferencePatent(html));
        patent.setRefOtherDocs(parseReferencesOtherDocuments(html));

        patent.setPrimaryExaminer(parsePrimaryExaminer(html));
        patent.setAssistantExaminer(parseAssistantExaminer(html));
        patent.setAttorneyAgentOrFirms(parseAttorneyAgentOrFirm(html));

        patent.setParentCaseText(parseParentCaseText(html));
        patent.setGovernmentInterest(parseGovernmentInterest(html));
        patent.setClaims(parseClaims(html));
        patent.setDescription(parseDescription(html));
        patent.setSummaryInvention(UsptoStringUtils.unescapeHtml(parseSummaryInvention(html)));

        return patent;
    }

    private Object[] parseIssueNoDate(String html) throws ParseException {
        String[] fieldArry = Pattern.compile("<b>United States Patent *</b></TD>", Pattern.CASE_INSENSITIVE).split(html);
        if (fieldArry.length == 1) {
            return null;
        }
        String s = fieldArry[1];
        s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(s)[0];
        String[] ary = Pattern.compile("</TD>", Pattern.CASE_INSENSITIVE).split(s);

        String no = ary[0].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim()
                .replaceAll(",", "");
        // ex:4,000,332 這種patent的issue date 前面會有星星符號
        String dateStr = ary[2].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").replace("*", "").trim();

        if (dateStr != null && dateStr.length() == 0) {
            ary = Pattern.compile("<b>Issue Date:</b></TD>", Pattern.CASE_INSENSITIVE).split(html);
            if (ary.length > 1) {
                s = ary[1];
                s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(s)[0];
                ary = Pattern.compile("</TD>", Pattern.CASE_INSENSITIVE).split(s);
                dateStr = ary[0].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            }
        }

        Date date = null;
        if (dateStr != null) {
            date = parseDate(dateStr);
        }
        return new Object[] { no, date };
    }

    private String parseIssueNo1(String html) throws RESyntaxException {
        RE re = new RE("United States Patent </B></TD>\\n\\t<TD ALIGN=\"RIGHT\" WIDTH=\"50%\"><B> <B><I>(.*)</I></B>");
        if (re.match(html)) {
            return re.getParen(1);
        }
        // start某些特殊狀況6,861,447
        String no = StringUtils.substringBetween(html, "<TITLE>United States Patent:", "</TITLE></HEAD>");
        if (no != null) {
            return no.trim();
        }
        // end某些特殊狀況6,861,447
        return null;
    }

    private Date parseIssueDate1(String html) throws RESyntaxException, ParseException {
        String issueDate = StringUtils
                .substringBetween(html, "<TD ALIGN=\"RIGHT\" WIDTH=\"50%\"> <B>\n", "\n</B></TD>");
        // parse image patent, ex:3515079
        if (issueDate == null) {
            issueDate = StringUtils.substringBetween(html, "<TD VALIGN=TOP ALIGN=\"RIGHT\" WIDTH=\"80%\"><B>",
                    "\n</B>\n</TD>");
        }
        if (issueDate != null && issueDate.indexOf("\n") != -1) {
            // ex:5,238,477 這種patent的issue date 前面會有星星符號
            issueDate = StringUtils.substringAfter(issueDate, "\n");
        }
        if (issueDate != null) {
            Date d = parseDate(issueDate.trim());
            return d;
        } else {
            return null;
        }
    }

    private Map<String, String> parseRow(String html) {
        
        String[] rows = html.replaceAll("(\r\n|\n)", "").split("(?i)<TR> *<TH scope=\"row\" [^<>]*>");
        if (rows == null || rows.length < 2) {
            rows = html.split("(?i)<TR> *<TD VALIGN=\"TOP\" ALIGN=\"LEFT\" WIDTH=\"10%\"[^<>]*>");
        }
        if (rows == null || rows.length < 2) {
            return null;
        }
        Map<String, String> map = new HashMap<String, String>();
        for (int i = 1; i < rows.length; i++) {
            String row = rows[i];
            row = row.split("(?i)</TD> *\n? *</TR>")[0];
            row = row.replaceAll("\n", " ").replaceAll(" {2,}", " ");
//            String[] ary = row.split("</T[DH]> *<TD ALIGN=\"LEFT\" WIDTH=\"\\d+%\">");
            String[] ary = Pattern.compile("(?i)</T[DH]> *<TD ALIGN=\"LEFT\" WIDTH=\"\\d+%\">", Pattern.CASE_INSENSITIVE)
                    .split(row);
            map.put(ary[0].trim(), ary[1].trim());
        }
        return map;
    }

    private String getRowValue(Map<String, String> rowMap, String key) {
        if (rowMap.containsKey(key)) {
            return rowMap.get(key);
        } else {
            for (String rowRey : rowMap.keySet()) {
                if (rowRey.indexOf(key) >= 0) {
                    return rowMap.get(rowRey);
                }
            }
            return null;
        }
    }

    private List<Inventor> parseInventor(Map<String, String> rowMap) {
        List<Inventor> inventorList = new ArrayList<Inventor>();

        String s = getRowValue(rowMap, "Inventors:");

        Pattern pattern = Pattern.compile("<B>,? *([^<>]*)</B> *\\(([^\\(\\)]*(\\([^\\(\\)]*\\)[^\\(\\)]*)*)\\)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(s);
        while (matcher.find()) {
            String name = matcher.group(1).trim();
            String address = matcher.group(2).trim();
            String country = null;
            String state = null;
            if (address != null) {
                Pattern pattern2 = Pattern.compile("(.*)<B>(.*)</B>", Pattern.CASE_INSENSITIVE);
                Matcher matcher2 = pattern2.matcher(address);
                if (matcher2.find()) {
                    String c = matcher2.group(2).trim();
                    if (c.length() == 2) {
                        country = c;
                    }
                } else if (!address.contains("<B>")){
                    String st = StringUtils.substringAfterLast(address, ",").trim();
                    if (st.length() == 2) {
                        state = st;
                        country = CountryCode.US;
                    }
                }
                address = address.replaceAll("(?i)</?B>", "");
            }
            Inventor inventor = new Inventor();
            inventor.setName(name);
            inventor.setAddress(address);
            inventor.setCountry(country);
            inventor.setState(state);
            inventorList.add(inventor);
        }
        return inventorList;
    }

    private List<Assignee> parseAssignee(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Assignee:");
        if (s != null) {
            //s = Pattern.compile("<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();

            String[] blocks = split(s, "(?i)<BR>");
            List<Assignee> assigneeList = new ArrayList<Assignee>();
            for (int i = 0; i < blocks.length; i++) {
                String name = StringUtils.substringBefore(blocks[i], "(");
                if (name != null) {
                    name = name.replaceAll("(?i)</?B>", "").trim();
                }
                String address = StringUtils.substringBetween(blocks[i], "(", ")");
                String country = null;
                String state = null;
                if (address != null) {
                    Pattern pattern2 = Pattern.compile("(?i)(.*)<B>(.*)</B>");
                    Matcher matcher2 = pattern2.matcher(address);
                    if (matcher2.find()) {
                        String c = matcher2.group(2).trim();
                        if (c.length() == 2) {
                            country = c;
                        }
                    } else if (!address.contains("(?i)<B>")){
                        String st = StringUtils.substringAfterLast(address, ",").trim();
                        if (st.length() == 2) {
                            state = st;
                            country = CountryCode.US;
                        }
                    }
                    address = address.replaceAll("(?i)</?B>", "").trim();
                }
                if (name != null && name.length() > 0) {
                    Assignee assignee = new Assignee();
                    assignee.setName(name);
                    assignee.setAddress(address);
                    assignee.setCountry(country);
                    assignee.setState(state);
                    assigneeList.add(assignee);
                }
            }
            return assigneeList;
        } else {
            return null;
        }
    }

    private String parseNotice(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Notice:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private String parseFamilyId(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Family ID:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private String parseApplicationNo(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "Appl. No.:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private Date parseField(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "Filed:");
        s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        Date field = parseDate(s);
        if (isLessThan1790(field)) {
            field = null;
        }
        return field;
    }

    private Date parsePctField(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "PCT Filed:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
            return parseDate(s);
        } else {
            return null;
        }
    }

    private String parsePctNo(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "PCT No.:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private Date parseD371c124(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "371(c)(1),(2),(4) Date:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
            return parseDate(s);
        } else {
            return null;
        }
    }

    private Date parseD371(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "371 Date:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
            return parseDate(s);
        } else {
            return null;
        }
    }

    private Date parseD102e(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "102(e) Date:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
            return parseDate(s);
        } else {
            return null;
        }
    }

    private String parsePctPubNo(Map<String, String> rowMap) {
        String s = getRowValue(rowMap, "PCT Pub. No.:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
        }
        return s;
    }

    private Date parsePctPubDate(Map<String, String> rowMap) throws ParseException {
        String s = getRowValue(rowMap, "PCT Pub. Date:");
        if (s != null) {
            s = Pattern.compile("(?i)<B>|</B>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("").trim();
            return parseDate(s);
        }
        return null;
    }

    private String parseTitle(String html) {
        // <font size="+1"> Electric control device for a camera </font>
        // $ refer to a group. $1 is the first group, $2 the second, etc.
        String s = html.replaceAll("(?i)([\\s\\S]*<FONT\\s*size=\"\\S1\">)([\\s\\S]*?)(</font>[\\s\\S]*)", "$2").trim();
        
        if (s != null) {
            s = s.replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        }
        
        return s;
    }

    private String parseAbstract(String html) {
        String[] ary = Pattern.compile("<b>Abstract</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        s = s.replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        return s;
    }

    private List<RelatedUSPatentDoc> parseRelatedUSPatentDocuments(String html) {
        // 先取出 Related U.S. Patent Documents 的區塊
        String[] ary = Pattern.compile("<b>Related U.S. Patent Documents</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        String[] rows = Pattern.compile("</TR>", Pattern.CASE_INSENSITIVE).split(s);
        if (rows == null || rows.length < 3) {
            return null;
        }

        List<RelatedUSPatentDoc> relatedList = null;

        for (int i = 2; i < rows.length; i++) {
            String[] cols = Pattern.compile("</TH>|</TD>", Pattern.CASE_INSENSITIVE).split(rows[i]);
            if (cols == null || cols.length < 5) {
                continue;
            }
            for (int j = 0; j < cols.length; j++) {
                cols[j] = cols[j].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            }

            String reissue = cols[0];
            String applicationNo = cols[1];
            String patentNo = cols[3];

            Date filingDate = null;
            try {
                filingDate = parseDate(cols[2]);
            } catch (ParseException e) {
                log.error(e.getMessage(), e);
            }

            Date issueDate = null;
            try {
                issueDate = parseDate(cols[4]);
            } catch (ParseException e) {
                log.error(e.getMessage(), e);
            }

            if (applicationNo != null && applicationNo.indexOf("Truncated") >= 0) {
                continue;
            }

            RelatedUSPatentDoc doc = new RelatedUSPatentDoc();
            if (reissue != null && reissue.indexOf("Reissue") >= 0) {
                doc.setReissue("1");
            }
            doc.setApplicationNo(applicationNo);
            doc.setFilingDate(filingDate);
            doc.setPatentNo(patentNo);
            doc.setIssueDate(issueDate);

            if (relatedList == null) {
                relatedList = new ArrayList<RelatedUSPatentDoc>();
            }
            relatedList.add(doc);
        }

        return relatedList;
    }

    private List<ForeignAppPriorityData> parseForeignApplicationPriorityDatas(String html) throws ParseException,
            RESyntaxException {
        // 先取出 Foreign Application Priority Data 的區塊
        String[] ary = Pattern.compile("<b>Foreign Application Priority Data</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        String[] rows = Pattern.compile("</TR>", Pattern.CASE_INSENSITIVE).split(s);
        if (rows == null || rows.length < 2) {
            return null;
        }

        List<ForeignAppPriorityData> priorityList = null;

        for (int i = 1; i < rows.length; i++) {
            String[] cols = Pattern.compile("</TH>|</TD>", Pattern.CASE_INSENSITIVE).split(rows[i]);
            if (cols == null || cols.length < 4) {
                continue;
            }
            for (int j = 0; j < cols.length; j++) {
                cols[j] = cols[j].replaceAll("<[^<>]*>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            }
            String dateCountry = cols[0];
            String no = cols[3];
            if (dateCountry.indexOf("[") > 0 && dateCountry.indexOf("]") > 0) {
                Date date = parseDate(dateCountry.substring(0, dateCountry.indexOf("[") - 1));
                String country = dateCountry.substring(dateCountry.indexOf("[") + 1, dateCountry.indexOf("]"));

                ForeignAppPriorityData foreignApplicationData = new ForeignAppPriorityData();
                foreignApplicationData.setDate(date);
                foreignApplicationData.setCountryCode(country);
                foreignApplicationData.setApplicationNo(no);

                if (priorityList == null) {
                    priorityList = new ArrayList<ForeignAppPriorityData>();
                }
                priorityList.add(foreignApplicationData);
            }  else if (dateCountry.indexOf("[") == 0 && dateCountry.indexOf("]") > 0){
                // 沒有 date 的情況
                String country = dateCountry.substring(dateCountry.indexOf("[") + 1, dateCountry.indexOf("]"));

                ForeignAppPriorityData foreignApplicationData = new ForeignAppPriorityData();
                foreignApplicationData.setDate(null);
                foreignApplicationData.setCountryCode(country);
                foreignApplicationData.setApplicationNo(no);

                if (priorityList == null) {
                    priorityList = new ArrayList<ForeignAppPriorityData>();
                }
                priorityList.add(foreignApplicationData);
            } else {
                // 有時候有奇怪的格式，沒有 code 的狀況下，就是這個沒有 "[JP]"
                throw new GeneralRuntimeException("(dateCountry.indexOf(\"[\") > 0 && dateCountry.indexOf(\"]\") > 0) = false");
            }
        }
        return priorityList;
    }

    private int parsePatentCount(String html) throws RESyntaxException {
        RE re = new RE(
            "<FONT SIZE=-2>of</FONT> <STRONG><FONT SIZE=-1>(\\d*)</STRONG>");
        if (re.match(html)) {
            return Integer.parseInt(re.getParen(1));
        } else {
            return 1;
        }
    }
    
    private List<PatentClassCode> parseCurrentUsClass(String html, String patentNo) throws RESyntaxException,
            IOException {

        List<PatentClassCode> patentClassCodes = new ArrayList<PatentClassCode>();

        String[] fieldArry = Pattern.compile("Current U.S. Class:", Pattern.CASE_INSENSITIVE).split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return patentClassCodes;
        }
        String s = fieldArry[1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];

        if (s != null) {
            //s = Pattern.compile("<[^<>]*>", Pattern.CASE_INSENSITIVE).matcher(s).replaceAll("");
//            s = s.replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            String[] nos = split(s, ";");

            int pos = 0;
            for (String classNo : nos) {
                if (classNo == null) {
                    continue;
                }
                PatentClassCode patentClassCode = new PatentClassCode();
                classNo = classNo.replaceAll("/000|/00|/0", "/");
                // 粗體為主USPC
                if (classNo.contains("<b>")) {
                    patentClassCode.setMain(true);
                }
                classNo = Pattern.compile("<[^<>]*>", Pattern.CASE_INSENSITIVE).matcher(classNo).replaceAll("");
                classNo = classNo.trim();
                if (classNo.length() == 0) {
                    continue;
                }
                
                patentClassCode.setType(PatentClassCodeConstant.CLASSIFICATION_UPC);
                patentClassCode.setPos(pos++);
                patentClassCode.setClassNo(classNo);

                patentClassCodes.add(patentClassCode);
            }
        }
        return patentClassCodes;
    }

    private List<PatentClassCode> parseInternationalClass(String html, String patentNo) {
        int type = PatentClassCodeConstant.CLASSIFICATION_IPC;
        if (patentNo != null && "D".equalsIgnoreCase(patentNo.substring(0, 1))) {
            type = PatentClassCodeConstant.CLASSIFICATION_LOC;
        }
        return parseClass(type, html);
    }
    
    private List<PatentClassCode> parseClass(int type, String html) {
        List<PatentClassCode> patentClassCodes = new ArrayList<PatentClassCode>();

        String field = "Current International Class:";
        if (type == PatentClassCodeConstant.CLASSIFICATION_CPC) {
            field = "Current CPC Class:";
        }
        
//        String s = StringUtils.substringBetween(html, field, "</TD></TR>");
        String[] fieldArry = Pattern.compile(field, Pattern.CASE_INSENSITIVE).split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return patentClassCodes;
        }
        String s = fieldArry[1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];
        
        if (s != null) {
            s = s.replaceAll("<[^<>]*>", "");
            s = s.replaceAll("&nbsp;|&nbsp|\n", " ").replaceAll(" {2,}", " ").trim();
            String[] blocks = split(s, ";");

            int pos = 0;
            for (String classNo : blocks) {
                if (classNo == null) {
                    continue;
                }
                // 把 G04B 25/00 (20060101) 中的日期 "(20060101)" 過濾掉
                String version = null;
                if (classNo.indexOf("(") != -1) {
                    version = StringUtils.substringBetween(classNo, "(", ")");
                    classNo = classNo.substring(0, classNo.indexOf("("));
                }
                classNo = classNo.trim();
                if (classNo.length() == 0) {
                    continue;
                }
                PatentClassCode patentClassCode = new PatentClassCode();

                patentClassCode.setType(type);
                patentClassCode.setPos(pos++);
                patentClassCode.setClassNo(classNo);
                patentClassCode.setVersion(version);
                setClassificationId(patentClassCode);

                patentClassCodes.add(patentClassCode);
            }
        }
        return patentClassCodes;
    }

    private String parseFieldOfSearch(String html) {
//        String s = StringUtils.substringBetween(html, "Field of Search:", "</TD></TR>");
        String[] fieldArry = Pattern.compile("Field of Search:", Pattern.CASE_INSENSITIVE).split(html.replaceAll("(\r\n|\n)", ""));
        if (fieldArry.length == 1) {
            return null;
        }
    
        String s = fieldArry[1];
        s = s.replaceAll(" {2,}", " ").trim();
        s = Pattern.compile("</TD>\\s*</TR>", Pattern.CASE_INSENSITIVE).split(s)[0];
        if (s != null) {
            s = s.replaceAll("<[^<>]*>", "");
            s = s.replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
            return s;
        } else {
            return null;
        }
    }

    private List<RefPatent> parseReferencesUsDocument(String html) {
        String[] ary = Pattern.compile("<b>U.S. Patent Documents</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary.length == 1) {
            return null;
        }
        String s = ary[1].replaceAll("(?i)([\\s\\S]*?</TABLE>)([\\s\\S]*)", "$1").trim();
        if (s == null) {
            return null;
        }
        
        List<RefPatent> refList = new ArrayList<RefPatent>();
        
        Document doc = Jsoup.parse(s);
        Elements rows = doc.select("tr");
        
        for (int i=1; i< rows.size(); i++) {
            Elements tds = rows.get(i).select("td");
            
            if (tds.size() != 3) {
                continue;
            }
            RefPatent refPatent = new RefPatent();
            //
            String patentNo = null;
            if (tds.get(0).select("a") != null) {
                patentNo = tds.get(0).select("a").html().trim();
            } else {
                patentNo = tds.get(0).html().trim();
            }
            if (StringUtils.isNotBlank(patentNo)) {
                refPatent.setPatentNo(patentNo.replaceAll("/", ""));
            }
            //
            String dateOfPatent = null;
            if (tds.get(1) != null) {
                dateOfPatent = tds.get(1).html().trim();
            }
            if (StringUtils.isNotBlank(dateOfPatent)) {
                refPatent.setDateOfPatent(dateOfPatent);
            }
            //
            String primaryInventor = null;
            if (tds.get(2) != null) {
                primaryInventor = tds.get(2).html().trim();
            }
            if (StringUtils.isNotBlank(primaryInventor)) {
                refPatent.setPrimaryInventor(primaryInventor);
            }
            refPatent.setCountryCode(CountryCode.US);
            refList.add(refPatent);
            
        }
        return refList;
    }

    private List<RefPatent> parseReferencesForeignDocuments(String html) {
        String s = StringUtils.substringBetween(html, "<b>Foreign Patent Documents</b>", "</TABLE>");
        if (s == null) {
            return null;
        }
        String[] blocks = s.split("</TD></TR><TR><TD align=left>");

        List<RefPatent> refList = new ArrayList<RefPatent>();

        for (int i = 0; i < blocks.length; i++) {
            String block = blocks[i];
            block = block.replaceAll("</?CENTER>|</?TABLE[^<>]*>|</?T[RH][^<>]*>|<TD ALIGN[^<>]*>", "");
            block = block.replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();

            String[] fields = block.split("</TD><TD></TD><TD align=left>");

            if (fields.length == 3) {
                RefPatent refPatent = new RefPatent();
                if (fields[0] != null) {
                    refPatent.setPatentNo(fields[0].replaceAll("<[^<>]+>", "").replaceAll(" {2,}", " ").trim());
                }
                if (fields[1] != null) {
                    refPatent.setDateOfPatent(fields[1].trim());
                }
                if (fields[2] != null) {
                    refPatent.setCountryCode(fields[2].trim());
                }
                refList.add(refPatent);
            }
        }
        return refList;
    }

    private List<RefPatent> parseReferencePatent(String html) throws RESyntaxException {
        List<RefPatent> refPatentlist = new ArrayList<RefPatent>();

        List<RefPatent> referenceUsPatent = parseReferencesUsDocument(html);
        if (referenceUsPatent != null) {
            refPatentlist.addAll(referenceUsPatent);
        }

        List<RefPatent> referenceForeignPatent = parseReferencesForeignDocuments(html);
        if (referenceForeignPatent != null) {
            refPatentlist.addAll(referenceForeignPatent);
        }
        return refPatentlist;
    }

    private List<RefOtherDoc> parseReferencesOtherDocuments(String html) {
        // 先取出 Other References 的區塊
        String[] ary = Pattern.compile("<b>Other References</b>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("</TABLE>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];

        if (s != null) {
            String[] blocks = Pattern.compile("<BR>", Pattern.CASE_INSENSITIVE).split(s);
            List<RefOtherDoc> refList = new ArrayList<RefOtherDoc>();
            for (int i = 0; i < blocks.length; i++) {
                String block = blocks[i];
                block = block.replaceAll("<[^<>]+>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
                if (block.length() > 0) {
                    RefOtherDoc referenceOtherDocument = new RefOtherDoc(block);
                    refList.add(referenceOtherDocument);
                }
            }
            return refList;
        } else {
            return null;
        }
    }

    private String parsePrimaryExaminer(String html) {
        String[] ary = Pattern.compile("<i>Primary Examiner:</i>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<BR>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        s = s.replaceAll("<[^<>]+>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        return s;
    }

    private String parseAssistantExaminer(String html) {
        String[] ary = Pattern.compile("<i>Assistant Examiner:</i>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<BR>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        s = s.replaceAll("<[^<>]+>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        return s;
    }

    private List<String> parseAttorneyAgentOrFirm(String html) {
        String[] ary = Pattern.compile("<i>Attorney, Agent or Firm:</i>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<BR>", Pattern.CASE_INSENSITIVE).split(ary[1])[0];
        s = s.replaceAll("<[^<>]+>", "").replaceAll(" {2,}", " ").trim();
        String[] atts = s.split("\n");
        List<String> list = new ArrayList<String>();
        for (String a : atts) {
            list.add(a.trim());
        }
        return list;
    }

    private String parseParentCaseText(String html) {
        String[] ary = Pattern.compile("<[bi]>Parent Case Text</[bi]>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[1];
        s = s.replaceAll("<[^<>]+>", "").replaceAll("\n", " ").replaceAll(" {2,}", " ").trim();
        return s;
    }

    private String parseGovernmentInterest(String html) {
        String[] ary = Pattern.compile("<[bi]>Government Interests</[bi]>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[1];
        return s;
    }

    private String parseClaims(String html) {
        String[] ary = Pattern.compile("<[bi]>Claims</[bi]>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[1];
        return s;
    }

    private String parseDescription(String html) {
        String[] ary = Pattern.compile("<[bi]>Description</[bi]>", Pattern.CASE_INSENSITIVE).split(html);
        if (ary == null || ary.length != 2) {
            return null;
        }
        String s = Pattern.compile("<HR>", Pattern.CASE_INSENSITIVE).split(ary[1])[1];
        s = Pattern.compile("<CENTER><B>\\* \\* \\* \\* \\*</B>", Pattern.CASE_INSENSITIVE).split(s)[0];
        return s;
    }

    private String parseSummaryInvention(String html) {
        String[] starts = {
                "<BR><BR>SUMMARY OF THE INVENTION",
                "<BR><BR>SUMARY OF THE INVENTION",
                "<BR><BR>SUMMARY",
                "SUMMARY OF THE INVENTION",
                "<BR><BR>DISCLOSURE OF INVENTION",
                "<BR><BR>DISCLOSURE OF THE INVENTION",
                "<BR><BR>BRIEF DESCRIPTION OF THE INVENTION",
                "<BR><BR>    SUMMARY OF THE INVENTION",
                "<BR><BR>    SUMARY OF THE INVENTION",
                "<BR><BR>    SUMMARY",
                "<BR><BR>    DISCLOSURE OF INVENTION",
                "<BR><BR>    DISCLOSURE OF THE INVENTION",
                "<BR><BR>    BRIEF DESCRIPTION OF THE INVENTION" };

        String[] ends = {
                "<BR><BR>BRIEF DESCRIPTION OF THE DRAWINGS",
                "<BR><BR>DESCRIPTION OF THE DRAWINGS",
                "<BR><BR>BRIEF DESCRIPTION OF DRAWING",
                "<BR><BR>BRIEF DESCRIPTION OF THE SEVERAL VIEWS OF THE DRAWING",
                "<BR><BR>BRIEF DESCRIPTION OF DRAWINGS",
                "<BR><BR>    BRIEF DESCRIPTION OF DRAWINGS",
                "OF DRAWINGS",
                "OF THE DRAWING",
                "<BR><BR>    BRIEF DESCRIPTION OF THE DRAWINGS",
                "<BR><BR>    DESCRIPTION OF THE DRAWINGS",
                "<BR><BR>    BRIEF DESCRIPTION OF DRAWING",
                "<BR><BR>    BRIEF DESCRIPTION OF THE SEVERAL VIEWS OF THE DRAWING",
                "<BR><BR>    BRIEF DESCRIPTION OF DRAWINGS",
                "OF DRAWINGS",
                "OF THE DRAWING" };

        String summaryInvention = null;
        boolean match = false;
        for (int j = 0; j < starts.length && !match; j++) {
            for (int k = 0; k < ends.length && !match; k++) {
                summaryInvention = StringUtils.substringBetween(html, starts[j], ends[k]);
                if (summaryInvention != null) {
                    match = true;
                }
            }
        }
        if (summaryInvention == null) {
            return summaryInvention;
        } else {
            return summaryInvention.replaceAll("\n", "").replaceAll("<BR>", "\n");
        }
    }

    private String[] split(String s1, String s2) {
        String[] s = s1.split(s2);
        for (int i = 0; i < s.length; i++) {
            s[i] = s[i].replaceAll("\n", "").trim();
        }
        return s;
    }
}
