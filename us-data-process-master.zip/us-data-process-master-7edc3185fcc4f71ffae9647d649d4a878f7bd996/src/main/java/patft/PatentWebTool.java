package patft;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import patft.util.WebToolUtil;
import patft.vo.EclaSymbol;
import patft.vo.IpcSymbol;
import patft.vo.LocSymbol;
import patft.vo.PatentClassCode;
import patft.vo.PatentClassCodeAppend;
import patft.vo.PatentClassCodeConstant;

public abstract class PatentWebTool {

    public PatentWebTool() {
        super();
    }

    public Set<PatentClassCode> convertClassificationToSet2(Map<Integer, Collection> patentClassMap) {
        if (patentClassMap == null) {
            return null;
        }
        Set<PatentClassCode> patentClassificationSet = new LinkedHashSet<PatentClassCode>();
        PatentClassCode patentClassification = null;
        Collection<PatentClassCode> patentClassificationColl = null;

        List<Integer> classTypeList = PatentClassCodeConstant.getClassTypeList();

        for (int i = 0; i < classTypeList.size(); i++) {
            patentClassificationColl = patentClassMap.get(classTypeList.get(i));
            if (patentClassificationColl != null) {
                for (Iterator<PatentClassCode> it = patentClassificationColl.iterator(); it.hasNext();) {
                    patentClassification = it.next();
                    patentClassificationSet.add(patentClassification);
                }
            }
        }
        return patentClassificationSet;
    }

    public Set<PatentClassCodeAppend> convertClassificationAppendToSet2(Map<Integer, Collection> patentClassMap) {
        if (patentClassMap == null) {
            return null;
        }
        Set<PatentClassCodeAppend> patentClassificationSet = new LinkedHashSet<PatentClassCodeAppend>();
        PatentClassCodeAppend patentClassificationAppend = null;
        Collection<PatentClassCodeAppend> patentClassificationAppendColl = null;

        List<Integer> classTypeList = PatentClassCodeConstant.getClassTypeList();

        for (int i = 0; i < classTypeList.size(); i++) {
            patentClassificationAppendColl = patentClassMap.get(classTypeList.get(i) + PatentClassCodeConstant.CLASS_APPEND);
            if (patentClassificationAppendColl != null) {
                for (Iterator<PatentClassCodeAppend> it = patentClassificationAppendColl.iterator(); it.hasNext();) {
                    patentClassificationAppend = it.next();
                    patentClassificationSet.add(patentClassificationAppend);
                }
            }
        }

        return patentClassificationSet;
    }

    public static boolean isLessThan1790(Date date) {
        boolean isLessThan1790 = false;
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            int year = calendar.get(Calendar.YEAR);
            if (year < 1790) {
                isLessThan1790 = true;
            }
        }
        return isLessThan1790;
    }

    public static Set<PatentClassCode> generatePatentClassCodeSet(Collection<PatentClassCode>... collections) {
        Set<PatentClassCode> patentClassCodeSet = new LinkedHashSet<PatentClassCode>();
        if (collections != null) {
            for (Collection<PatentClassCode> collection : collections) {
                if (collection != null) {
                    for (PatentClassCode patentClassCode : collection) {
                        patentClassCodeSet.add(patentClassCode);
                    }
                }
            }
        }
        return patentClassCodeSet;
    }

    public static Set<PatentClassCodeAppend> generatePatentClassCodeAppendSet(Collection<PatentClassCode>... collections) {
        Set<PatentClassCodeAppend> patentClassCodeAppendSet = new LinkedHashSet<PatentClassCodeAppend>();
        if (collections != null) {
            for (Collection<PatentClassCode> collection : collections) {
                if (collection != null) {
                    Map<Integer, StringBuffer> appendMap = new LinkedHashMap<Integer, StringBuffer>();
                    for (PatentClassCode patentClassCode : collection) {
                        int type = patentClassCode.getType();
                        String classNo = patentClassCode.getClassNo();

                        StringBuffer append = appendMap.get(type);
                        if (append == null) {
                            append = new StringBuffer();
                            appendMap.put(type, append);
                        }
                        if (classNo != null) {
                            classNo = classNo.trim();
                            if (classNo.length() > 0) {
                                if (append.length() > 0) {
                                    append.append(";");
                                }
                                append.append(classNo);
                            }
                        }
                    }
                    Set<Integer> types = appendMap.keySet();
                    for (Integer type : types) {
                        StringBuffer append = appendMap.get(type);
                        if (append != null && append.length() > 0) {
                            PatentClassCodeAppend patentClassCodeAppend = new PatentClassCodeAppend();
                            patentClassCodeAppend.setType(type);
                            patentClassCodeAppend.setClassNo(append.toString());
                            patentClassCodeAppendSet.add(patentClassCodeAppend);
                        }
                    }
                }
            }
        }
        return patentClassCodeAppendSet;
    }

    protected void setClassificationId(PatentClassCode patentClassCode) {
        if (patentClassCode == null) {
            return;
        }
        switch (patentClassCode.getType()) {
        case PatentClassCodeConstant.CLASSIFICATION_IPC:
        case PatentClassCodeConstant.CLASSIFICATION_IPC8:
        case PatentClassCodeConstant.CLASSIFICATION_CPC:
            IpcSymbol ipcSymbol = IpcSymbol.createSymbol(patentClassCode.getClassNo());
            if (ipcSymbol != null) {
                patentClassCode.setClassId(ipcSymbol.getSymbolId());
            }
            break;
        case PatentClassCodeConstant.CLASSIFICATION_ECLA:
            EclaSymbol eclaSymbol = EclaSymbol.createSymbol(patentClassCode.getClassNo());
            if (eclaSymbol != null) {
                patentClassCode.setClassId(eclaSymbol.getSymbolId());
            }
            break;
        case PatentClassCodeConstant.CLASSIFICATION_LOC:
            LocSymbol locSymbol = LocSymbol.createSymbol(patentClassCode.getClassNo());
            if (locSymbol != null) {
                patentClassCode.setClassId(locSymbol.getSymbolId());
            }
            break;
        default:
        }
    }

    /*
     * trim
     */
    protected String trimHtmlTag(String html) {
        return WebToolUtil.trimHtmlTag(html);
    }
    protected String trimHtmlSpace(String html) {
        return WebToolUtil.trimHtmlSpace(html);
    }
    protected String trimCrlf(String html) {
        return WebToolUtil.trimCrlf(html);
    }
    protected String trimSpace(String html) {
        return WebToolUtil.trimSpace(html);
    }

    /*
     * unescapeHtml
     */
    protected String unescapeHtml(String html) {
        return WebToolUtil.unescapeHtml(html);
    }

  // public Element getXmlElement(Element element, String elementName) throws
  // IOException, ParseException,
  // RowDataGetException, EspacenetWebServiceException {
  // Element xmlElement = null;
  // try {
  // xmlElement = element.element(elementName);
  // if(xmlElement == null) {
  // if (element.element("ERRORS") != null
  // && element.element("ERRORS").element("ERROR") != null) {
  // throw new EspacenetWebServiceException(element
  // .element("ERRORS").element("ERROR").elementText(
  // "simple_message"));
  // } else if (element.element("ERRORS") != null) {
  // throw new EspacenetWebServiceException();
  // }
  //                
  // throw new RowDataGetException(elementName + " null");
  // }
  // } catch (Exception e) {
  // throw new RowDataGetException(e.getMessage());
  // }
  // return xmlElement;
  // }
}
