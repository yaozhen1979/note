
---------------------------------------------------------- create schema

CREATE SCHEMA part
  AUTHORIZATION postgres;

GRANT ALL ON SCHEMA part TO postgres;
GRANT ALL ON SCHEMA part TO patentdata;
COMMENT ON SCHEMA part
  IS 'partition table schema';

---------------------------------------------------------- pat_data

create table part.pat_data_other (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_other_pkey PRIMARY KEY (pat_id),
  check (country IN ('AP', 'AT'))
) inherits (pat_data);

create table part.pat_data_de (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_de_pkey PRIMARY KEY (pat_id),
  check (country = 'DE')
) inherits (pat_data);

create table part.pat_data_us (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_us_pkey PRIMARY KEY (pat_id),
  check (country = 'US')
) inherits (pat_data);

create table part.pat_data_wo (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_wo_pkey PRIMARY KEY (pat_id),
  check (country = 'WO')
) inherits (pat_data);

create table part.pat_data_jp (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_jp_pkey PRIMARY KEY (pat_id),
  check (country = 'JP')
) inherits (pat_data);

create table part.pat_data_ep (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_ep_pkey PRIMARY KEY (pat_id),
  check (country = 'EP')
) inherits (pat_data);

create table part.pat_data_tw (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_tw_pkey PRIMARY KEY (pat_id),
  check (country = 'TW')
) inherits (pat_data);

create table part.pat_data_kr (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_kr_pkey PRIMARY KEY (pat_id),
  check (country = 'KR')
) inherits (pat_data);

create table part.pat_data_cn (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_cn_pkey PRIMARY KEY (pat_id),
  check (country = 'CN')
) inherits (pat_data);

create table part.pat_data_in (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_in_pkey PRIMARY KEY (pat_id),
  check (country = 'IN')
) inherits (pat_data);

---------------------------------

--------------------------------- app_data

create table part.app_data_us (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_us_pkey PRIMARY KEY (app_id),
  check (country = 'US')
) inherits (app_data);

--
create table part.app_data_wo (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_wo_pkey PRIMARY KEY (app_id),
  check (country = 'WO')
) inherits (app_data);

create table part.app_data_jp (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_jp_pkey PRIMARY KEY (app_id),
  check (country = 'JP')
) inherits (app_data);

create table part.app_data_tw (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_tw_pkey PRIMARY KEY (app_id),
  check (country = 'TW')
) inherits (app_data);

create table part.app_data_ep (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_ep_pkey PRIMARY KEY (app_id),
  check (country = 'EP')
) inherits (app_data);

create table part.app_data_kr (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_kr_pkey PRIMARY KEY (app_id),
  check (country = 'KR')
) inherits (app_data);

create table part.app_data_cn (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_cn_pkey PRIMARY KEY (app_id),
  check (country = 'CN')
) inherits (app_data);

create table part.app_data_in (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_in_pkey PRIMARY KEY (app_id),
  check (country = 'IN')
) inherits (app_data);

create table part.app_data_de (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_de_pkey PRIMARY KEY (app_id),
  check (country = 'DE')
) inherits (app_data);

create table part.app_data_other (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_other_pkey PRIMARY KEY (app_id),
  check (country IN ('AP', 'AT'))
) inherits (app_data);

----------------------------------- pat_data_title table

DROP TABLE IF EXISTS part.pat_data_title_us;

create table part.pat_data_title_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_us_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'US')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_wo;

create table part.pat_data_title_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_wo_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'WO')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_jp;

create table part.pat_data_title_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_jp_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'JP')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_ep;

create table part.pat_data_title_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_ep_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'EP')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_cn;

create table part.pat_data_title_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_cn_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'CN')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_tw;

create table part.pat_data_title_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_tw_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'TW')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_kr;

create table part.pat_data_title_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_kr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'KR')
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_other;

create table part.pat_data_title_other (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_de_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) in ('AP', 'AT') )
) inherits (pat_data_title);

DROP TABLE IF EXISTS part.pat_data_title_de;

create table part.pat_data_title_de (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_de_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'DE')
) inherits (pat_data_title);

----------------------------------- pat_data_brief table
--
DROP TABLE IF EXISTS part.pat_data_brief_us;

create table part.pat_data_brief_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_us_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'US')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_wo;

create table part.pat_data_brief_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_wo_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'WO')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_jp;

create table part.pat_data_brief_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_jp_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'JP')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_ep;

create table part.pat_data_brief_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_ep_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'EP')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_tw;

create table part.pat_data_brief_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_tw_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'TW')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_kr;

create table part.pat_data_brief_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_kr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'KR')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_cn;

create table part.pat_data_brief_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_cn_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'CN')
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_other;

create table part.pat_data_brief_other (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_other_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) in ('AP', 'AT') )
) inherits (pat_data_brief);

--
DROP TABLE IF EXISTS part.pat_data_brief_de;

create table part.pat_data_brief_de (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_brief_de_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'DE')
) inherits (pat_data_brief);

----------------------------------- pat_data_desc table

--
DROP TABLE IF EXISTS part.pat_data_desc_us;

create table part.pat_data_desc_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_us_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'US')
) inherits (pat_data_desc);

--
DROP TABLE IF EXISTS part.pat_data_desc_wo;

create table part.pat_data_desc_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_wo_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'WO')
) inherits (pat_data_desc);

--
DROP TABLE IF EXISTS part.pat_data_desc_jp;

create table part.pat_data_desc_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_jp_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'JP')
) inherits (pat_data_desc);

--
DROP TABLE IF EXISTS part.pat_data_desc_ep;

create table part.pat_data_desc_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_ep_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'EP')
) inherits (pat_data_desc);

--
DROP TABLE IF EXISTS part.pat_data_desc_cn;

create table part.pat_data_desc_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_cn_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'CN')
) inherits (pat_data_desc);


--
DROP TABLE IF EXISTS part.pat_data_desc_kr;

create table part.pat_data_desc_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_kr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'KR')
) inherits (pat_data_desc);

--
DROP TABLE IF EXISTS part.pat_data_desc_tw;

create table part.pat_data_desc_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_desc_tw_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'TW')
) inherits (pat_data_desc);


----------------------------------- pat_data_claim table

DROP TABLE IF EXISTS part.pat_data_claims_us;

create table part.pat_data_claims_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_us_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'US')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_cn;

create table part.pat_data_claim_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_cn_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'CN')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_jp;

create table part.pat_data_claims_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_jp_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'JP')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_wo;

create table part.pat_data_claims_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_wo_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'WO')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_ep;

create table part.pat_data_claims_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_ep_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'EP')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_kr;

create table part.pat_data_claims_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_kr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'KR')
) inherits (pat_data_claims);

DROP TABLE IF EXISTS part.pat_data_claims_tw;

create table part.pat_data_claims_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_claims_tw_pkey PRIMARY KEY (pat_id, source_id, lang),
  check (substr(pat_id, 1, 2) = 'TW')
) inherits (pat_data_claims);

----------------------------------- shadow table

CREATE TABLE part.pat_data_shadow (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_shadow_pkey PRIMARY KEY (pat_id)
)
WITH (
  OIDS=FALSE
);


CREATE TABLE part.app_data_shadow (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_shadow_pkey PRIMARY KEY (app_id)
)
WITH (
  OIDS=FALSE
);

----------------------------------- create trigger

----------------------------------- pat_data_claims trigger


CREATE OR REPLACE FUNCTION pat_data_claims_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
        INSERT INTO part.pat_data_claims_us VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
        INSERT INTO part.pat_data_claims_wo VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
        INSERT INTO part.pat_data_claims_jp VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
        INSERT INTO part.pat_data_claims_cn VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
        INSERT INTO part.pat_data_claims_ep VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
        INSERT INTO part.pat_data_claims_tw VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
        INSERT INTO part.pat_data_claims_kr VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_claims_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_pat_data_claims_trigger
    BEFORE INSERT ON pat_data_claims
    FOR EACH ROW EXECUTE PROCEDURE pat_data_claims_insert_trigger();

----------------------------------- pat_data_desc trigger

CREATE OR REPLACE FUNCTION pat_data_desc_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
        INSERT INTO part.pat_data_desc_us VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
        INSERT INTO part.pat_data_desc_wo VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
        INSERT INTO part.pat_data_desc_jp VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
        INSERT INTO part.pat_data_desc_cn VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
        INSERT INTO part.pat_data_desc_ep VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
        INSERT INTO part.pat_data_desc_tw VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
        INSERT INTO part.pat_data_desc_kr VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_desc_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_pat_data_desc_trigger
    BEFORE INSERT ON pat_data_desc
    FOR EACH ROW EXECUTE PROCEDURE pat_data_desc_insert_trigger();

----------------------------------- pat_data_brief trigger

CREATE OR REPLACE FUNCTION pat_data_brief_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
        INSERT INTO part.pat_data_brief_us VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
        INSERT INTO part.pat_data_brief_wo VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
        INSERT INTO part.pat_data_brief_jp VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
        INSERT INTO part.pat_data_brief_cn VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
        INSERT INTO part.pat_data_brief_ep VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
        INSERT INTO part.pat_data_brief_tw VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
        INSERT INTO part.pat_data_brief_kr VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) in ('AP', 'AT') ) THEN
        INSERT INTO part.pat_data_brief_other VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'DE' ) THEN
        INSERT INTO part.pat_data_brief_de VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_brief_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_pat_data_brief_trigger
    BEFORE INSERT ON pat_data_brief
    FOR EACH ROW EXECUTE PROCEDURE pat_data_brief_insert_trigger();

----------------------------------- pat_data_title trigger

CREATE OR REPLACE FUNCTION pat_data_title_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
        INSERT INTO part.pat_data_title_us VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
        INSERT INTO part.pat_data_title_wo VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
        INSERT INTO part.pat_data_title_jp VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
        INSERT INTO part.pat_data_title_cn VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
        INSERT INTO part.pat_data_title_ep VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
        INSERT INTO part.pat_data_title_tw VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
        INSERT INTO part.pat_data_title_kr VALUES (NEW.*);
	ELSIF ( substr(NEW.pat_id, 1, 2) in ('AP', 'AT') ) THEN
        INSERT INTO part.pat_data_title_other VALUES (NEW.*);
    ELSIF ( substr(NEW.pat_id, 1, 2) = 'DE' ) THEN
        INSERT INTO part.pat_data_title_de VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_title_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_pat_data_title_trigger
    BEFORE INSERT ON pat_data_title
    FOR EACH ROW EXECUTE PROCEDURE pat_data_title_insert_trigger();

----------------------------------- pat_data trigger
--- insert function

CREATE OR REPLACE FUNCTION pat_data_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( NEW.country = 'US' ) THEN
        INSERT INTO part.pat_data_us VALUES (NEW.*);
    ELSIF ( NEW.country = 'JP' ) THEN
        INSERT INTO part.pat_data_jp VALUES (NEW.*);
    ELSIF ( NEW.country = 'WO' ) THEN
        INSERT INTO part.pat_data_wo VALUES (NEW.*);
    ELSIF ( NEW.country = 'EP' ) THEN
        INSERT INTO part.pat_data_ep VALUES (NEW.*);
    ELSIF ( NEW.country = 'TW' ) THEN
        INSERT INTO part.pat_data_tw VALUES (NEW.*);
    ELSIF ( NEW.country = 'CN' ) THEN
        INSERT INTO part.pat_data_cn VALUES (NEW.*);
	ELSIF ( NEW.country = 'IN' ) THEN
        INSERT INTO part.pat_data_in VALUES (NEW.*);
    ELSIF ( NEW.country in ('AP', 'AT') ) THEN
        INSERT INTO part.pat_data_other VALUES (NEW.*);
    ELSIF ( NEW.country in ('DE') ) THEN
        INSERT INTO part.pat_data_de VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_pat_data_trigger
    BEFORE INSERT ON pat_data
    FOR EACH ROW EXECUTE PROCEDURE pat_data_insert_trigger();

---------------------------------- app_data trigger  

CREATE OR REPLACE FUNCTION app_data_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF ( NEW.country = 'US' ) THEN
        INSERT INTO part.app_data_us VALUES (NEW.*);
    ELSIF ( NEW.country = 'JP' ) THEN
        INSERT INTO part.app_data_jp VALUES (NEW.*);
    ELSIF ( NEW.country = 'WO' ) THEN
        INSERT INTO part.app_data_wo VALUES (NEW.*);
    ELSIF ( NEW.country = 'EP' ) THEN
        INSERT INTO part.app_data_ep VALUES (NEW.*);
    ELSIF ( NEW.country = 'TW' ) THEN
        INSERT INTO part.app_data_tw VALUES (NEW.*);
    ELSIF ( NEW.country = 'CN' ) THEN
        INSERT INTO part.app_data_cn VALUES (NEW.*);
	ELSIF ( NEW.country = 'KR' ) THEN
        INSERT INTO part.app_data_kr VALUES (NEW.*);
    ELSIF ( NEW.country = 'IN' ) THEN
        INSERT INTO part.app_data_in VALUES (NEW.*);
    ELSIF ( NEW.country = 'DE' ) THEN
        INSERT INTO part.app_data_de VALUES (NEW.*);
    ELSIF ( NEW.country in ('AP', 'AT') ) THEN
        INSERT INTO part.app_data_other VALUES (NEW.*);
    ELSE
        RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_insert_trigger() function!';
    END IF;
	
    RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger

CREATE TRIGGER insert_app_data_trigger
    BEFORE INSERT ON app_data
    FOR EACH ROW EXECUTE PROCEDURE app_data_insert_trigger();

----------------------------------- CREATE RULE


CREATE RULE "pat_data_rule" AS ON INSERT
TO public.pat_data
DO INSERT INTO part.pat_data_shadow VALUES (
  NEW.pat_id
);

CREATE RULE "app_data_rule" AS ON INSERT
TO public.app_data
DO INSERT INTO part.app_data_shadow VALUES (
  NEW.app_id
);


