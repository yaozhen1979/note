----------------------------------- person_data table

DROP TABLE IF EXISTS part.person_data_cn;

create table part.person_data_cn (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_cn_pkey PRIMARY KEY (person_id),
  check ( country = 'CN')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_ep;

create table part.person_data_ep (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_ep_pkey PRIMARY KEY (person_id),
  check ( country = 'EP')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_in;

create table part.person_data_in (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_in_pkey PRIMARY KEY (person_id),
  check ( country = 'IN')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_jp;

create table part.person_data_jp (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_jp_pkey PRIMARY KEY (person_id),
  check ( country = 'JP')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_kr;

create table part.person_data_kr (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_kr_pkey PRIMARY KEY (person_id),
  check ( country = 'KR')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_tw;

create table part.person_data_tw (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_tw_pkey PRIMARY KEY (person_id),
  check ( country = 'TW')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_us;

create table part.person_data_us (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_us_pkey PRIMARY KEY (person_id),
  check ( country = 'US')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_wo;

create table part.person_data_wo (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_wo_pkey PRIMARY KEY (person_id),
  check ( country = 'WO')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_at;

create table part.person_data_at (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_at_pkey PRIMARY KEY (person_id),
  check ( country = 'AT')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_au;

create table part.person_data_au (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_au_pkey PRIMARY KEY (person_id),
  check ( country = 'AU')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_ca;

create table part.person_data_ca (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_ca_pkey PRIMARY KEY (person_id),
  check ( country = 'CA')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_de;

create table part.person_data_de (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_de_pkey PRIMARY KEY (person_id),
  check ( country = 'DE')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_es;

create table part.person_data_es (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_es_pkey PRIMARY KEY (person_id),
  check ( country = 'ES')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_fr;

create table part.person_data_fr (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_fr_pkey PRIMARY KEY (person_id),
  check ( country = 'FR')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_gb;

create table part.person_data_gb (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_gb_pkey PRIMARY KEY (person_id),
  check ( country = 'GB')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_it;

create table part.person_data_it (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_it_pkey PRIMARY KEY (person_id),
  check ( country = 'IT')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_ru;

create table part.person_data_ru (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_ru_pkey PRIMARY KEY (person_id),
  check ( country = 'RU')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_su;

create table part.person_data_su (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_su_pkey PRIMARY KEY (person_id),
  check ( country = 'SU')
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_other_a;

create table part.person_data_other_a (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_other_a_pkey PRIMARY KEY (person_id),
  check ( country in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 
  'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) 
) inherits (person_data);
        
DROP TABLE IF EXISTS part.person_data_other_b;

create table part.person_data_other_b (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_other_b_pkey PRIMARY KEY (person_id),
  check ( country in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 
  'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
  'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') )
) inherits (person_data);

-- person_data_other_c 為無法判別的國家資料
DROP TABLE IF EXISTS part.person_data_other_c;

create table part.person_data_other_c (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_other_c_pkey PRIMARY KEY (person_id)
) inherits (person_data);



---------------------------- person_data trigger

CREATE OR REPLACE FUNCTION person_data_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( NEW.country = 'US' ) THEN
    INSERT INTO part.person_data_us VALUES (NEW.*);
  ELSIF ( NEW.country = 'WO' ) THEN
    INSERT INTO part.person_data_wo VALUES (NEW.*);
  ELSIF ( NEW.country = 'JP' ) THEN
    INSERT INTO part.person_data_jp VALUES (NEW.*);
  ELSIF ( NEW.country = 'CN' ) THEN
    INSERT INTO part.person_data_cn VALUES (NEW.*);
  ELSIF ( NEW.country = 'EP' ) THEN
    INSERT INTO part.person_data_ep VALUES (NEW.*);
  ELSIF ( NEW.country = 'TW' ) THEN
    INSERT INTO part.person_data_tw VALUES (NEW.*);
  ELSIF ( NEW.country = 'KR' ) THEN
    INSERT INTO part.person_data_kr VALUES (NEW.*);
  ELSIF ( NEW.country = 'IN' ) THEN
    INSERT INTO part.person_data_in VALUES (NEW.*);
  ELSIF ( NEW.country = 'AT' ) THEN
    INSERT INTO part.person_data_at VALUES (NEW.*);
  ELSIF ( NEW.country = 'AU' ) THEN
    INSERT INTO part.person_data_au VALUES (NEW.*);
  ELSIF ( NEW.country = 'CA' ) THEN
    INSERT INTO part.person_data_ca VALUES (NEW.*);
  ELSIF ( NEW.country = 'DE' ) THEN
    INSERT INTO part.person_data_de VALUES (NEW.*);
  ELSIF ( NEW.country = 'ES' ) THEN
    INSERT INTO part.person_data_es VALUES (NEW.*);
  ELSIF ( NEW.country = 'FR' ) THEN
    INSERT INTO part.person_data_fr VALUES (NEW.*);
  ELSIF ( NEW.country = 'GB' ) THEN
    INSERT INTO part.person_data_gb VALUES (NEW.*);
  ELSIF ( NEW.country = 'IT' ) THEN
    INSERT INTO part.person_data_it VALUES (NEW.*);
  ELSIF ( NEW.country = 'RU' ) THEN
    INSERT INTO part.person_data_ru VALUES (NEW.*);
  ELSIF ( NEW.country = 'SU' ) THEN
    INSERT INTO part.person_data_su VALUES (NEW.*);
  ELSIF ( NEW.country in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO part.person_data_other_a VALUES (NEW.*);
  ELSIF ( NEW.country in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO part.person_data_other_b VALUES (NEW.*);
  ELSE
    INSERT INTO part.person_data_other_c VALUES (NEW.*);
  END IF;
    
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_person_data_trigger on person_data;

CREATE TRIGGER insert_person_data_trigger
  BEFORE INSERT ON person_data
  FOR EACH ROW EXECUTE PROCEDURE person_data_insert_trigger();
