---------------------------- pat_raw_docdb part table

DROP TABLE IF EXISTS part.pat_raw_docdb_cn;

create table part.pat_raw_docdb_cn (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_cn_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'CN')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_ep;

create table part.pat_raw_docdb_ep (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_ep_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'EP')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_in;

create table part.pat_raw_docdb_in (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_in_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'IN')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_jp;

create table part.pat_raw_docdb_jp (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_jp_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'JP')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_kr;

create table part.pat_raw_docdb_kr (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_kr_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'KR')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_tw;

create table part.pat_raw_docdb_tw (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_tw_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'TW')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_us;

create table part.pat_raw_docdb_us (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_us_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'US')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_wo;

create table part.pat_raw_docdb_wo (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_wo_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'WO')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_at;

create table part.pat_raw_docdb_at (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_at_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'AT')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_au;

create table part.pat_raw_docdb_au (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_au_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'AU')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_ca;

create table part.pat_raw_docdb_ca (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_ca_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'CA')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_de;

create table part.pat_raw_docdb_de (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_de_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'DE')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_es;

create table part.pat_raw_docdb_es (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_es_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'ES')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_fr;

create table part.pat_raw_docdb_fr (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_fr_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'FR')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_gb;

create table part.pat_raw_docdb_gb (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_gb_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'GB')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_it;

create table part.pat_raw_docdb_it (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_it_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'IT')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_ru;

create table part.pat_raw_docdb_ru (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_ru_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'RU')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_su;

create table part.pat_raw_docdb_su (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_su_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) = 'SU')
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_other_a;

create table part.pat_raw_docdb_other_a (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_other_a_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ'
, 'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) 
) inherits (pat_raw_docdb);
        
DROP TABLE IF EXISTS part.pat_raw_docdb_other_b;

create table part.pat_raw_docdb_other_b (
  raw_id character varying NOT NULL,
  CONSTRAINT pat_raw_docdb_other_b_pkey PRIMARY KEY (raw_id),
  check ( substr(pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN'
, 'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 'SE', 'SG', 'SI', 'SK', 'SM', 'S
V', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) 
) inherits (pat_raw_docdb);
        
---------------------------- pat_raw_docdb trigger

CREATE OR REPLACE FUNCTION pat_raw_docdb_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
    INSERT INTO part.pat_raw_docdb_us VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
    INSERT INTO part.pat_raw_docdb_wo VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
    INSERT INTO part.pat_raw_docdb_jp VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
    INSERT INTO part.pat_raw_docdb_cn VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
    INSERT INTO part.pat_raw_docdb_ep VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
    INSERT INTO part.pat_raw_docdb_tw VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
    INSERT INTO part.pat_raw_docdb_kr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IN' ) THEN
    INSERT INTO part.pat_raw_docdb_in VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AT' ) THEN
    INSERT INTO part.pat_raw_docdb_at VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AU' ) THEN
    INSERT INTO part.pat_raw_docdb_au VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CA' ) THEN
    INSERT INTO part.pat_raw_docdb_ca VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'DE' ) THEN
    INSERT INTO part.pat_raw_docdb_de VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'ES' ) THEN
    INSERT INTO part.pat_raw_docdb_es VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'FR' ) THEN
    INSERT INTO part.pat_raw_docdb_fr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'GB' ) THEN
    INSERT INTO part.pat_raw_docdb_gb VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IT' ) THEN
    INSERT INTO part.pat_raw_docdb_it VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'RU' ) THEN
    INSERT INTO part.pat_raw_docdb_ru VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'SU' ) THEN
    INSERT INTO part.pat_raw_docdb_su VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO part.pat_raw_docdb_other_a VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO part.pat_raw_docdb_other_b VALUES (NEW.*);
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the pat_raw_docdb_insert_trigger() function!';
  END IF;
    
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_pat_raw_docdb_trigger on pat_raw_docdb;

CREATE TRIGGER insert_pat_raw_docdb_trigger
  BEFORE INSERT ON pat_raw_docdb
  FOR EACH ROW EXECUTE PROCEDURE pat_raw_docdb_insert_trigger();
        
