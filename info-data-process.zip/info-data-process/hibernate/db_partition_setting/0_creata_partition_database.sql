--
CREATE ROLE patentdata LOGIN
  PASSWORD 'patentdata'
  SUPERUSER INHERIT CREATEDB CREATEROLE NOREPLICATION;

--
CREATE ROLE dataprocess LOGIN
  ENCRYPTED PASSWORD 'dataprocess'
  SUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION;

-- DROP DATABASE patentdata;

CREATE DATABASE patent_partition
  WITH OWNER = patentdata
       ENCODING = 'UTF8'
       TEMPLATE = template0
       TABLESPACE = pg_default
       LC_COLLATE = 'C'
       LC_CTYPE = 'C'
       CONNECTION LIMIT = -1;