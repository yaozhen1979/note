--------------------------------------- insert source_data 

INSERT INTO source_data (
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA01',
  'USPTO全文,mongo:PatentMarshallUS',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data (
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA02',
  'USPTO全文欄位定期更新-CPC:CPC_yyyymm',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA03',
  'USPTO全文欄位定期更新-USPC:USPCAppl_yyyymm',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USB01',
  'USPTO Assignment DB',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USC01',
  'USPTO PAIR',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'CNA01',
  'CN OpenData',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'WOA01',
  'WO全文',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'DOCA01',
  'DOCDB摘要',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'JPA01',
  'JPO全文',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
)
VALUES
(
  'EPA01',
  'EP全文',
  TIMESTAMP '2016-03-09 09:45:11.762',
  TIMESTAMP '2016-03-09 09:45:11.762'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
)
VALUES
(
  'TWA01',
  'TW全文',
  TIMESTAMP '2016-03-09 09:45:43.623',
  TIMESTAMP '2016-03-09 09:45:43.623'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
)
VALUES
(
  'KRA01',
  'KR全文',
  TIMESTAMP '2016-03-09 09:45:58.937',
  TIMESTAMP '2016-03-09 09:45:58.937'
);

COMMIT;
