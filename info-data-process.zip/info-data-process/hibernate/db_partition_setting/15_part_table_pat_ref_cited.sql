---------------------------- pat_ref_cited part table

DROP TABLE IF EXISTS part.pat_ref_cited_cn;

create table part.pat_ref_cited_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_cn_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'CN')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_ep;

create table part.pat_ref_cited_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_ep_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'EP')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_in;

create table part.pat_ref_cited_in (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_in_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'IN')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_jp;

create table part.pat_ref_cited_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_jp_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'JP')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_kr;

create table part.pat_ref_cited_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_kr_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'KR')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_tw;

create table part.pat_ref_cited_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_tw_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'TW')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_us;

create table part.pat_ref_cited_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_us_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'US')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_wo;

create table part.pat_ref_cited_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_wo_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'WO')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_at;

create table part.pat_ref_cited_at (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_at_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'AT')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_au;

create table part.pat_ref_cited_au (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_au_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'AU')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_ca;

create table part.pat_ref_cited_ca (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_ca_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'CA')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_de;

create table part.pat_ref_cited_de (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_de_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'DE')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_es;

create table part.pat_ref_cited_es (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_es_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'ES')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_fr;

create table part.pat_ref_cited_fr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_fr_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'FR')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_gb;

create table part.pat_ref_cited_gb (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_gb_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'GB')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_it;

create table part.pat_ref_cited_it (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_it_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'IT')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_ru;

create table part.pat_ref_cited_ru (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_ru_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'RU')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_su;

create table part.pat_ref_cited_su (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_su_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) = 'SU')
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_other_a;

create table part.pat_ref_cited_other_a (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_other_a_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 
  'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) 
) inherits (pat_ref_cited);
        
DROP TABLE IF EXISTS part.pat_ref_cited_other_b;

create table part.pat_ref_cited_other_b (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_other_b_pkey PRIMARY KEY (pat_id, source_id, item),
  check ( substr(pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 
  'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 'SE', 'SG', 
  'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') )
) inherits (pat_ref_cited);
        
---------------------------- pat_ref_cited trigger

CREATE OR REPLACE FUNCTION pat_ref_cited_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
    INSERT INTO part.pat_ref_cited_us VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
    INSERT INTO part.pat_ref_cited_wo VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
    INSERT INTO part.pat_ref_cited_jp VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
    INSERT INTO part.pat_ref_cited_cn VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
    INSERT INTO part.pat_ref_cited_ep VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
    INSERT INTO part.pat_ref_cited_tw VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
    INSERT INTO part.pat_ref_cited_kr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IN' ) THEN
    INSERT INTO part.pat_ref_cited_in VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AT' ) THEN
    INSERT INTO part.pat_ref_cited_at VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AU' ) THEN
    INSERT INTO part.pat_ref_cited_au VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CA' ) THEN
    INSERT INTO part.pat_ref_cited_ca VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'DE' ) THEN
    INSERT INTO part.pat_ref_cited_de VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'ES' ) THEN
    INSERT INTO part.pat_ref_cited_es VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'FR' ) THEN
    INSERT INTO part.pat_ref_cited_fr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'GB' ) THEN
    INSERT INTO part.pat_ref_cited_gb VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IT' ) THEN
    INSERT INTO part.pat_ref_cited_it VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'RU' ) THEN
    INSERT INTO part.pat_ref_cited_ru VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'SU' ) THEN
    INSERT INTO part.pat_ref_cited_su VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO part.pat_ref_cited_other_a VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO part.pat_ref_cited_other_b VALUES (NEW.*);
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the pat_ref_cited_insert_trigger() function!';
  END IF;
    
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_pat_ref_cited_trigger on pat_ref_cited;

CREATE TRIGGER insert_pat_ref_cited_trigger
  BEFORE INSERT ON pat_ref_cited
  FOR EACH ROW EXECUTE PROCEDURE pat_ref_cited_insert_trigger();
  
  
--------------------------------------------------- trigger for deleting

---------------------------- pat_ref_cited delete trigger
-- ref: http://stackoverflow.com/questions/10687582/postgresql-trigger-not-working-neither-before-nor-after-delete

CREATE OR REPLACE FUNCTION part.pat_ref_cited_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( substr(OLD.pat_id, 1, 2) = 'US' ) THEN
    DELETE FROM part.pat_ref_cited_us WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'WO' ) THEN
    DELETE FROM part.pat_ref_cited_wo WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'JP' ) THEN
    DELETE FROM part.pat_ref_cited_jp WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'CN' ) THEN
    DELETE FROM part.pat_ref_cited_cn WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'EP' ) THEN
    DELETE FROM part.pat_ref_cited_ep WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'TW' ) THEN
    DELETE FROM part.pat_ref_cited_tw WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'KR' ) THEN
    DELETE FROM part.pat_ref_cited_kr WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'IN' ) THEN
    DELETE FROM part.pat_ref_cited_in WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'AT' ) THEN
    DELETE FROM part.pat_ref_cited_at WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'AU' ) THEN
    DELETE FROM part.pat_ref_cited_au WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'CA' ) THEN
    DELETE FROM part.pat_ref_cited_ca WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'DE' ) THEN
    DELETE FROM part.pat_ref_cited_de WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'ES' ) THEN
    DELETE FROM part.pat_ref_cited_es WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'FR' ) THEN
    DELETE FROM part.pat_ref_cited_fr WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'GB' ) THEN
    DELETE FROM part.pat_ref_cited_gb WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'IT' ) THEN
    DELETE FROM part.pat_ref_cited_it WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'RU' ) THEN
    DELETE FROM part.pat_ref_cited_ru WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) = 'SU' ) THEN
    DELETE FROM part.pat_ref_cited_su WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    DELETE FROM part.pat_ref_cited_other_a WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSIF ( substr(OLD.pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    DELETE FROM part.pat_ref_cited_other_b WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the pat_ref_cited_delete_trigger() function!';
  END IF;
    
  RETURN OLD;
END;
$$
LANGUAGE plpgsql;

-- delete trigger 

DROP TRIGGER IF EXISTS delete_pat_ref_cited_trigger on part.pat_ref_cited_shadow;

CREATE TRIGGER delete_pat_ref_cited_trigger
  BEFORE DELETE ON part.pat_ref_cited_shadow
  FOR EACH ROW EXECUTE PROCEDURE part.pat_ref_cited_delete_trigger();
        
