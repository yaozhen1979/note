--
CREATE ROLE patentdata LOGIN
  PASSWORD 'patentdata'
  SUPERUSER INHERIT CREATEDB CREATEROLE NOREPLICATION;


-- DROP DATABASE patentdata;

CREATE DATABASE patentdata
  WITH OWNER = patentdata
       ENCODING = 'UTF8'
       TEMPLATE = template0
       TABLESPACE = pg_default
       LC_COLLATE = 'C'
       LC_CTYPE = 'C'
       CONNECTION LIMIT = -1;