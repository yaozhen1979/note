--------------------------------------- insert source_data 

INSERT INTO source_data (
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA01',
  'USPTO全文,mongo:PatentMarshallUS',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data (
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA02',
  'USPTO全文欄位定期更新-CPC:CPC_yyyymm',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USA03',
  'USPTO全文欄位定期更新-USPC:USPCAppl_yyyymm',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USB01',
  'USPTO Assignment DB',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'USC01',
  'USPTO PAIR',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'CNA01',
  'CN OpenData',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'WOA01',
  'WO全文',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'DOCA01',
  'DOCDB摘要',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

INSERT INTO source_data
(
  source_id,
  remark,
  create_date,
  last_upd_date
) VALUES (
  'JPA01',
  'JPO全文',
  TIMESTAMP '2016-01-20 13:34:45.005',
  TIMESTAMP '2016-01-20 13:34:45.005'
);

COMMIT;
