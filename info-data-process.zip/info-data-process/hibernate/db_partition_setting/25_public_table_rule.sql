----------------------------------- app_data rule

CREATE RULE "app_data_rule" AS ON INSERT
TO public.app_data
DO INSERT INTO part.app_data_shadow VALUES (
  NEW.app_id
);


----------------------------------------- pat_data rule

CREATE RULE "pat_data_rule" AS ON INSERT
TO public.pat_data
DO INSERT INTO part.pat_data_shadow VALUES (
  NEW.pat_id
);


----------------------------------- person_data rule

CREATE RULE "person_data_rule" AS ON INSERT
TO public.person_data
DO INSERT INTO part.person_data_shadow VALUES (
  NEW.person_id
);

----------------------------------- pat_ref_cited rule

CREATE RULE "pat_ref_cited_rule" AS ON INSERT
TO public.pat_ref_cited
DO INSERT INTO part.pat_ref_cited_shadow VALUES (
  NEW.pat_id,
  NEW.source_id,
  NEW.item
);

----------------------------------- pat_ref_cited delete rule

CREATE OR REPLACE RULE pat_ref_cited_del_rule AS ON DELETE TO pat_ref_cited 
    DO INSTEAD 
	DELETE FROM part.pat_ref_cited_shadow
      WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;


----------------------------------- pat_ref_cited_npl rule

CREATE RULE "pat_ref_cited_npl_rule" AS ON INSERT
TO public.pat_ref_cited_npl
DO INSERT INTO part.pat_ref_cited_npl_shadow VALUES (
  NEW.pat_id,
  NEW.source_id,
  NEW.item
);

----------------------------------- pat_ref_cited_npl delete rule

CREATE OR REPLACE RULE pat_ref_cited_npl_del_rule AS ON DELETE TO pat_ref_cited_npl
    DO INSTEAD 
	DELETE FROM part.pat_ref_cited_npl_shadow
      WHERE pat_id = OLD.pat_id AND source_id = OLD.source_id;



