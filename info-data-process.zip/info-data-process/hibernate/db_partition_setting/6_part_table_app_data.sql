----------------------------------- app_data table

DROP TABLE IF EXISTS part.app_data_cn;

create table part.app_data_cn (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_cn_pkey PRIMARY KEY (app_id),
  check ( country = 'CN')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_ep;

create table part.app_data_ep (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_ep_pkey PRIMARY KEY (app_id),
  check ( country = 'EP')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_in;

create table part.app_data_in (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_in_pkey PRIMARY KEY (app_id),
  check ( country = 'IN')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_jp;

create table part.app_data_jp (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_jp_pkey PRIMARY KEY (app_id),
  check ( country = 'JP')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_kr;

create table part.app_data_kr (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_kr_pkey PRIMARY KEY (app_id),
  check ( country = 'KR')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_tw;

create table part.app_data_tw (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_tw_pkey PRIMARY KEY (app_id),
  check ( country = 'TW')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_us;

create table part.app_data_us (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_us_pkey PRIMARY KEY (app_id),
  check ( country = 'US')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_wo;

create table part.app_data_wo (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_wo_pkey PRIMARY KEY (app_id),
  check ( country = 'WO')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_at;

create table part.app_data_at (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_at_pkey PRIMARY KEY (app_id),
  check ( country = 'AT')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_au;

create table part.app_data_au (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_au_pkey PRIMARY KEY (app_id),
  check ( country = 'AU')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_ca;

create table part.app_data_ca (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_ca_pkey PRIMARY KEY (app_id),
  check ( country = 'CA')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_de;

create table part.app_data_de (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_de_pkey PRIMARY KEY (app_id),
  check ( country = 'DE')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_es;

create table part.app_data_es (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_es_pkey PRIMARY KEY (app_id),
  check ( country = 'ES')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_fr;

create table part.app_data_fr (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_fr_pkey PRIMARY KEY (app_id),
  check ( country = 'FR')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_gb;

create table part.app_data_gb (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_gb_pkey PRIMARY KEY (app_id),
  check ( country = 'GB')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_it;

create table part.app_data_it (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_it_pkey PRIMARY KEY (app_id),
  check ( country = 'IT')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_ru;

create table part.app_data_ru (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_ru_pkey PRIMARY KEY (app_id),
  check ( country = 'RU')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_su;

create table part.app_data_su (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_su_pkey PRIMARY KEY (app_id),
  check ( country = 'SU')
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_other_a;

create table part.app_data_other_a (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_other_a_pkey PRIMARY KEY (app_id),
  check ( country in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 
  'CZ', 'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) 
) inherits (app_data);
        
DROP TABLE IF EXISTS part.app_data_other_b;

create table part.app_data_other_b (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_other_b_pkey PRIMARY KEY (app_id),
  check ( country in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 
  'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 
  'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') )
) inherits (app_data);



---------------------------- app_data trigger

CREATE OR REPLACE FUNCTION app_data_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( NEW.country = 'US' ) THEN
    INSERT INTO part.app_data_us VALUES (NEW.*);
  ELSIF ( NEW.country = 'WO' ) THEN
    INSERT INTO part.app_data_wo VALUES (NEW.*);
  ELSIF ( NEW.country = 'JP' ) THEN
    INSERT INTO part.app_data_jp VALUES (NEW.*);
  ELSIF ( NEW.country = 'CN' ) THEN
    INSERT INTO part.app_data_cn VALUES (NEW.*);
  ELSIF ( NEW.country = 'EP' ) THEN
    INSERT INTO part.app_data_ep VALUES (NEW.*);
  ELSIF ( NEW.country = 'TW' ) THEN
    INSERT INTO part.app_data_tw VALUES (NEW.*);
  ELSIF ( NEW.country = 'KR' ) THEN
    INSERT INTO part.app_data_kr VALUES (NEW.*);
  ELSIF ( NEW.country = 'IN' ) THEN
    INSERT INTO part.app_data_in VALUES (NEW.*);
  ELSIF ( NEW.country = 'AT' ) THEN
    INSERT INTO part.app_data_at VALUES (NEW.*);
  ELSIF ( NEW.country = 'AU' ) THEN
    INSERT INTO part.app_data_au VALUES (NEW.*);
  ELSIF ( NEW.country = 'CA' ) THEN
    INSERT INTO part.app_data_ca VALUES (NEW.*);
  ELSIF ( NEW.country = 'DE' ) THEN
    INSERT INTO part.app_data_de VALUES (NEW.*);
  ELSIF ( NEW.country = 'ES' ) THEN
    INSERT INTO part.app_data_es VALUES (NEW.*);
  ELSIF ( NEW.country = 'FR' ) THEN
    INSERT INTO part.app_data_fr VALUES (NEW.*);
  ELSIF ( NEW.country = 'GB' ) THEN
    INSERT INTO part.app_data_gb VALUES (NEW.*);
  ELSIF ( NEW.country = 'IT' ) THEN
    INSERT INTO part.app_data_it VALUES (NEW.*);
  ELSIF ( NEW.country = 'RU' ) THEN
    INSERT INTO part.app_data_ru VALUES (NEW.*);
  ELSIF ( NEW.country = 'SU' ) THEN
    INSERT INTO part.app_data_su VALUES (NEW.*);
  ELSIF ( NEW.country in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO part.app_data_other_a VALUES (NEW.*);
  ELSIF ( NEW.country in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO part.app_data_other_b VALUES (NEW.*);
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the app_data_insert_trigger() function!';
  END IF;
    
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_app_data_trigger on app_data;

CREATE TRIGGER insert_app_data_trigger
  BEFORE INSERT ON app_data
  FOR EACH ROW EXECUTE PROCEDURE app_data_insert_trigger();
