----------------------------------- app_data shadow table

DROP TABLE IF EXISTS part.app_data_shadow;

CREATE TABLE part.app_data_shadow (
  app_id character varying(50) NOT NULL,
  CONSTRAINT app_data_shadow_pkey PRIMARY KEY (app_id)
)
WITH (
  OIDS=FALSE
);


----------------------------------------- pat_data shadow table

DROP TABLE IF EXISTS part.pat_data_shadow;

CREATE TABLE part.pat_data_shadow (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT pat_data_shadow_pkey PRIMARY KEY (pat_id)
)
WITH (
  OIDS=FALSE
);

----------------------------------- person_data shadow table

DROP TABLE IF EXISTS part.person_data_shadow;

CREATE TABLE part.person_data_shadow (
  person_id uuid NOT NULL,
  CONSTRAINT person_data_pkey PRIMARY KEY (person_id)
)
WITH (
  OIDS=FALSE
);

----------------------------------- pat_ref_cited shadow table

DROP TABLE IF EXISTS part.pat_ref_cited_shadow;

CREATE TABLE part.pat_ref_cited_shadow (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_pkey PRIMARY KEY (pat_id, source_id, item)
)
WITH (
  OIDS=FALSE
);

----------------------------------- pat_ref_cited_npl shadow table

DROP TABLE IF EXISTS part.pat_ref_cited_npl_shadow;

CREATE TABLE part.pat_ref_cited_npl_shadow (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT pat_ref_cited_npl_pkey PRIMARY KEY (pat_id, source_id, item)
)
WITH (
  OIDS=FALSE
);

