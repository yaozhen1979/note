---------------------------- pat_data_title part table

DROP TABLE IF EXISTS part.pat_data_title_cn;

create table part.pat_data_title_cn (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_cn_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'CN')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_ep;

create table part.pat_data_title_ep (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_ep_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'EP')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_in;

create table part.pat_data_title_in (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_in_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'IN')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_jp;

create table part.pat_data_title_jp (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_jp_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'JP')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_kr;

create table part.pat_data_title_kr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_kr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'KR')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_tw;

create table part.pat_data_title_tw (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_tw_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'TW')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_us;

create table part.pat_data_title_us (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_us_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'US')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_wo;

create table part.pat_data_title_wo (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_wo_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'WO')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_at;

create table part.pat_data_title_at (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_at_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'AT')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_au;

create table part.pat_data_title_au (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_au_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'AU')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_ca;

create table part.pat_data_title_ca (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_ca_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'CA')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_de;

create table part.pat_data_title_de (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_de_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'DE')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_es;

create table part.pat_data_title_es (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_es_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'ES')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_fr;

create table part.pat_data_title_fr (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_fr_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'FR')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_gb;

create table part.pat_data_title_gb (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_gb_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'GB')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_it;

create table part.pat_data_title_it (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_it_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'IT')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_ru;

create table part.pat_data_title_ru (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_ru_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'RU')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_su;

create table part.pat_data_title_su (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_su_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) = 'SU')
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_other_a;

create table part.pat_data_title_other_a (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_other_a_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 
  'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) 
) inherits (pat_data_title);
        
DROP TABLE IF EXISTS part.pat_data_title_other_b;

create table part.pat_data_title_other_b (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT pat_data_title_other_b_pkey PRIMARY KEY (pat_id, source_id, lang),
  check ( substr(pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 
  'MN', 'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 
  'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') )
) inherits (pat_data_title);
        
---------------------------- pat_data_title trigger

CREATE OR REPLACE FUNCTION pat_data_title_insert_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF ( substr(NEW.pat_id, 1, 2) = 'US' ) THEN
    INSERT INTO part.pat_data_title_us VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'WO' ) THEN
    INSERT INTO part.pat_data_title_wo VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'JP' ) THEN
    INSERT INTO part.pat_data_title_jp VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CN' ) THEN
    INSERT INTO part.pat_data_title_cn VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'EP' ) THEN
    INSERT INTO part.pat_data_title_ep VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'TW' ) THEN
    INSERT INTO part.pat_data_title_tw VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'KR' ) THEN
    INSERT INTO part.pat_data_title_kr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IN' ) THEN
    INSERT INTO part.pat_data_title_in VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AT' ) THEN
    INSERT INTO part.pat_data_title_at VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'AU' ) THEN
    INSERT INTO part.pat_data_title_au VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'CA' ) THEN
    INSERT INTO part.pat_data_title_ca VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'DE' ) THEN
    INSERT INTO part.pat_data_title_de VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'ES' ) THEN
    INSERT INTO part.pat_data_title_es VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'FR' ) THEN
    INSERT INTO part.pat_data_title_fr VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'GB' ) THEN
    INSERT INTO part.pat_data_title_gb VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'IT' ) THEN
    INSERT INTO part.pat_data_title_it VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'RU' ) THEN
    INSERT INTO part.pat_data_title_ru VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) = 'SU' ) THEN
    INSERT INTO part.pat_data_title_su VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO part.pat_data_title_other_a VALUES (NEW.*);
  ELSIF ( substr(NEW.pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'UY', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO part.pat_data_title_other_b VALUES (NEW.*);
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the pat_data_title_insert_trigger() function!';
  END IF;
    
  RETURN NULL;
END;
$$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_pat_data_title_trigger on pat_data_title;

CREATE TRIGGER insert_pat_data_title_trigger
  BEFORE INSERT ON pat_data_title
  FOR EACH ROW EXECUTE PROCEDURE pat_data_title_insert_trigger();
        
