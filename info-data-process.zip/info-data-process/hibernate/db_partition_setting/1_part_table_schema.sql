CREATE SCHEMA part
  AUTHORIZATION postgres;

GRANT ALL ON SCHEMA part TO postgres;
GRANT ALL ON SCHEMA part TO patentdata;
COMMENT ON SCHEMA part
  IS 'partition table schema';
  