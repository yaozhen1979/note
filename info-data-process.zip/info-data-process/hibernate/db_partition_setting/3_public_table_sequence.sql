-------------------------------------------- db sequence

DROP SEQUENCE IF EXISTS seq_change_log_id;

CREATE SEQUENCE seq_change_log_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_event_record_id;
	   
CREATE SEQUENCE seq_event_record_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_log_id;
	   
CREATE SEQUENCE seq_log_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_person_lang_id;
	   
CREATE SEQUENCE seq_person_lang_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_ptopid_mapping_id;
	   
CREATE SEQUENCE seq_ptopid_mapping_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_data_import_id;

CREATE SEQUENCE seq_data_import_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

DROP SEQUENCE IF EXISTS seq_solr_build_id;
	   
CREATE SEQUENCE seq_solr_build_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;
	   
DROP SEQUENCE IF EXISTS seq_memo_id;
	   
CREATE SEQUENCE seq_memo_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

COMMIT;
