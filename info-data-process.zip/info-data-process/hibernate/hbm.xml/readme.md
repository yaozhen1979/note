[pat_ref_related_child]該table所產生出來的hbm.xml所建出來的model class [PatRefRelatedChild.java], 對應到[pat_ref_related_parent]時,
會出現

    Caused by: java.lang.RuntimeException: Configuratio error = Mixing nullable and non nullable columns in a property is not allowed
    
所以要在 [PatRefRelatedChild.hbm.xml]中修正, [<column name="parent_item" not-null="true" />], 並再重新generate model class.
    
