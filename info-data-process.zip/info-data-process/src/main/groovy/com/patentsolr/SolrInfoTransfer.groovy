package com.patentsolr

import java.lang.reflect.Field
import java.text.SimpleDateFormat

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.jongo.MongoCollection
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.mongodb.DBCollection
import com.patentdata.common.Constants
import com.patentdata.common.PatTypeEnum
import com.patentdata.helper.AppDataHelper
import com.patentdata.helper.PatClsCpcHelper
import com.patentdata.helper.PatClsCsetHelper
import com.patentdata.helper.PatClsEclaHelper
import com.patentdata.helper.PatClsIpcHelper
import com.patentdata.helper.PatClsLocHelper
import com.patentdata.helper.PatClsUspcHelper
import com.patentdata.helper.PatDataBriefHelper
import com.patentdata.helper.PatDataClaimsHelper
import com.patentdata.helper.PatDataDescHelper
import com.patentdata.helper.PatDataTitleHelper
import com.patentdata.helper.PatPersonAgentHelper
import com.patentdata.helper.PatPersonApplicantHelper
import com.patentdata.helper.PatPersonAssigneeHelper
import com.patentdata.helper.PatPersonExaminerHelper
import com.patentdata.helper.PatPersonInventorHelper
import com.patentdata.helper.PatPtopidMappingHelper
import com.patentdata.helper.PatRefCitedHelper
import com.patentdata.helper.PatRefCitedNplHelper
import com.patentdata.helper.PatRefPctHelper
import com.patentdata.helper.PatRefPriorityHelper
import com.patentdata.helper.PatRefRelatedParentHelper
import com.patentdata.helper.PersonDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsEcla
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsLoc
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatData
import com.patentdata.model.PatPtopidMapping
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PersonData
import com.patentdata.util.CountryUtil
import com.patentdata.util.DateUtil
import com.patentdata.util.JSONUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatClsUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.SolrNumberUtil
import com.patentsolr.assignment.AssignmentFinder
import com.patentsolr.assignment.AssignmentRecord
import com.patentsolr.litigation.CourtAbbrFinder
import com.patentsolr.litigation.DocketCase
import com.patentsolr.litigation.Firm
import com.patentsolr.litigation.Party
import com.patentsolr.model.SolrPatentInfo
import com.patentsolr.model.classification.IpcInfo
import com.patentsolr.model.integration.Event
import com.patentsolr.model.integration.IntegrationUS

/**
 * 
 * @author mikelin
 *
 */
public class SolrInfoTransfer {
    
    private static Logger logger = LoggerFactory.getLogger(SolrInfoTransfer.class);
    
    private static boolean mongoInit = false;
    private static DBCollection cpcColl = null;
    private static DBCollection uspcApplColl = null;
    private static DBCollection uspcPatColl = null;
    private static MongoCollection litigationColl = null;
    private static MongoCollection integrationUSColl = null;

    public static SolrPatentInfo transfer2SolrPatentInfo(PatData patData) {
        
        if (!mongoInit && patData.country == "US") {
            // USPTO
            def client = MongoUtil.connectByConfig("US");
            cpcColl = client.getDB("USPTO").getCollection("CPC_201510");
            uspcApplColl = client.getDB("USPTO").getCollection("USPC_Appl_201506");
            uspcPatColl = client.getDB("USPTO").getCollection("USPC_Pat_201506");
            
            // IntegrationUS
            integrationUSColl = MongoUtil.getIntegrationUSColl();
            // LitigationDN
            litigationColl = MongoUtil.getLitigationDNColl();
            
            logger.debug("loading court abbr...");
            CourtAbbrFinder.load();
            logger.debug("loading court abbr finish.");
            
            mongoInit = true;
        }
        
        SolrPatentInfo solrInfo = new SolrPatentInfo();
        solrInfo.solrIndexTime = new Date();
        // pat_Data
        transPatData(patData, solrInfo);
        
        // PtoidMapping
        transferPtoidMapping(patData, solrInfo);
        
        // appData
        transAppData(patData, solrInfo);
        
        IntegrationUS integrationUS = integrationUSColl.findOne("{ fullText: true, _id: #}", solrInfo.patentNumber).as(IntegrationUS.class);
        
        // patclscpc  (包含 cset)
        transferPatClsCpc(patData, solrInfo);
        
        // patclsipc  (包含 ipcr)
        transferPatClsIpc(patData, solrInfo);
        
        // patclsuspc
        transferPatClsUspc(patData, solrInfo);
        
        // patclsloc
        transferPatClsLoc(patData, solrInfo);
        
        // TODO : pat_cls_di
        transferPatClsDi();
        
        // TODO : pat_cls_dterm
        transferPatClsDTerm();
        
        // pat_cls_ecla
        transferPatClsEcla(patData, solrInfo);
        
        // TODO : pat_cls_fi
        transferPatClsFi();
        
        // TODO : pat_cls_fterm
        transferPatClsFTerm();
        
        // pat_data_title
        transferPatDataTitle(patData, solrInfo);
        
        // pat_data_brief
        transferPatDataBrief(patData, solrInfo);
        
        // pat_data_claims
        transferPatDataClaims(patData, solrInfo);
        
        // pat_data_desc
        transferPatDataDesc(patData, solrInfo);
        
        // pat_ref_cited
        transferPatRefCited(patData, solrInfo);
        
        // PAT_REF_CITED_NPL (otherReferences)
        transferPatRefCitedNpl(patData, solrInfo);
        
        // pat_ref_priority
        transferPatRefPriority(patData, solrInfo);
        
        // pat_person_agent
        transferPatPersonAgent(patData, solrInfo);
        
        // pat_person_inventor
        transferPatPersonInventor(patData, solrInfo);
        
        // TODO: pat_person_applicant => 可有可無 ??? 
        transferPatPersonApplicant(patData, solrInfo);
        
        // pat_person_assignee
        transferPatPersonAssignee(patData, solrInfo);
        
        // examinerMasters / examinerSlaves
        transferPatPersonExaminer(patData, solrInfo);
        
        // PAT_REF_PCT
        transferPatRefPct(patData, solrInfo);
        
        // pat_ref_related_parent
        transferPatRefRelatedParent(patData, solrInfo);
        
        if (patData.country == "US") {
            // LitigationDN
            transferLitigationDN(patData, solrInfo, integrationUS);
            // Assignment
            transferAssignment(patData, solrInfo, integrationUS);
        }
        
        return solrInfo;
    }
    
    
    /**
     * Assignment US
     * @param patData
     * @param solrInfo
     * @param integrationUS
     */
    private static void transferAssignment(PatData patData, SolrPatentInfo solrInfo, IntegrationUS integrationUS) {
        //assignment 處理
        List<AssignmentRecord> assignments = AssignmentFinder.queryByAppNumber(integrationUS.appNumber);
        List<String> assignors = new ArrayList<String>();
        List<String> assignees = new ArrayList<String>();
        List<Date> assigneeDates = new ArrayList<Date>();
        Set<String> assigneeRecnos = new HashSet<String>();
        List<String> licensors = new ArrayList<String>();
        List<String> licensees = new ArrayList<String>();
        List<Date> licenseeDates = new ArrayList<Date>();
        Set<String> licenseeRecnos = new HashSet<String>();
        List<String> mortgageCreditors = new ArrayList<String>();
        List<String> mortgageApplicants = new ArrayList<String>();
        List<Date> mortgageApplicantDates = new ArrayList<Date>();
        Set<String> mortgageApplicantRecnos = new HashSet<String>();
        for (AssignmentRecord ass : assignments) {
            switch((int)ass.conveyanceType) {
            case 0:
            case 1:
            case 3:
            case 4:
                if (ass.iNtoCORP == 1) {
                    continue;
                }
                if (!assignors.contains(ass.assignorName)) {
                    assignors.add(ass.assignorName);
                }
                if (!assignees.contains(ass.assigneeName)) {
                    assignees.add(ass.assigneeName);
                }
                assigneeDates.add(ass.executionDate);
                assigneeRecnos.add(ass.reelframeNo);
                break;
            case -2:
                if (!licensors.contains(ass.assignorName)) {
                    licensors.add(ass.assignorName);
                }
                if (!licensees.contains(ass.assigneeName)) {
                    licensees.add(ass.assigneeName);
                }
                licenseeDates.add(ass.executionDate);
                licenseeRecnos.add(ass.reelframeNo);
                break;
            case -3:
                if (!mortgageCreditors.contains(ass.assignorName)) {
                    mortgageCreditors.add(ass.assignorName);
                }
                if (!mortgageApplicants.contains(ass.assigneeName)) {
                    mortgageApplicants.add(ass.assigneeName);
                }
                mortgageApplicantDates.add(ass.executionDate);
                mortgageApplicantRecnos.add(ass.reelframeNo);
                break;
            }
        }
        if (assigneeRecnos.size() > 0) {
            solrInfo.assignmentAssignors = assignors;
            solrInfo.assignmentAssignees = assignees;
            solrInfo.assignmentAssigneeCount = assigneeRecnos.size();
            solrInfo.assignmentAssigneeDates = assigneeDates;
        }
        if (licenseeRecnos.size() > 0) {
            solrInfo.assignmentLicensors = licensors;
            solrInfo.assignmentLicensees = licensees;
            solrInfo.assignmentLicenseeCount = licenseeRecnos.size();
            solrInfo.assignmentLicenseeDates = licenseeDates;
        }
        if (mortgageApplicantRecnos.size() > 0) {
            solrInfo.assignmentMortgageCreditors = mortgageCreditors;
            solrInfo.assignmentMortgageApplicants = mortgageApplicants;
            solrInfo.assignmentMortgageApplicantCount = mortgageApplicantRecnos.size();
            solrInfo.assignmentMortgageApplicantDates = mortgageApplicantDates;
        }
    }
    /** LitigationDN US
     * @param patData
     * @param solrInfo
     */
    private static void transferLitigationDN(PatData patData, SolrPatentInfo solrInfo, IntegrationUS integrationUS) {
        
        //訴訟處理
        if (integrationUS.litigationDN) {
            List<Event> cases = integrationUS.relations.litigationDN;
            
            List<String> litigationCaseTypes = new ArrayList<>();
            List<String> litigationCaseNumbers = new ArrayList<>();
            List<String> litigationCaseNames = new ArrayList<>();
            List<String> litigationCaseStatus = new ArrayList<>();
            List<String> litigationCounts = new ArrayList<>();
            List<String> litigationPleading = [];
            List<String> litigationPleadingType = new ArrayList<>();
            List<Date> litigationFilingDates = new ArrayList<>();
            List<String> litigationPlaintiffs = new ArrayList<>();
            List<String> litigationDefendants = new ArrayList<>();
            List<String> litigationPlaintiffFirms = new ArrayList<>();
            List<String> litigationDefendantFirms = new ArrayList<>();
            List<String> litigationPatentValidity = new ArrayList<>();
            List<String> litigationPatentInfringement = new ArrayList<>();
            List<String> litigationContents = new ArrayList<>();
            
            for (Event dnEvent : cases) {
                
                DocketCase docketCase = litigationColl.findOne(new ObjectId(dnEvent.id)).as(DocketCase.class);
                if (docketCase.court.equals("Federal Circuit")) {
                    addUnique(litigationCaseTypes, "CAFC");
                } else if (docketCase.court.equals("US.District Courts")) {
                    addUnique(litigationCaseTypes, "DC");   //TODO check
                } else if (docketCase.court.equals("International Trade Commission")) {
                    addUnique(litigationCaseTypes, "ITC");
                } else if (docketCase.court.equals("Patent Trial and Appeal Board")) {
                    addUnique(litigationCaseTypes, "PTAB");
                }
                addUnique(litigationPleading, docketCase.pleadings);
                for (String p : docketCase.pleadings) {
                    addUnique(litigationPleadingType, getPleadingType(p));
                }
                addUnique(litigationCaseStatus, docketCase.caseStatus);
                if ("Y".equals(docketCase.patentInfringementInvaild)) {
                    addUnique(litigationPatentInfringement, "Y");
                }
                if ("Y".equals(docketCase.patentInfringementNotInvaild)) {
                    addUnique(litigationPatentInfringement, "N");
                }
                if ("Y".equals(docketCase.patentValidityInvaild)) {
                    addUnique(litigationPatentValidity, "Y");
                }
                if ("Y".equals(docketCase.patentValidityNotInvaild)) {
                    addUnique(litigationPatentValidity, "N");
                }
                addUnique(litigationCaseNames, docketCase.caseName);
                addUnique(litigationCounts, docketCase.courtAbbr);
                addUnique(litigationCounts, CourtAbbrFinder.getCourtName(docketCase.courtAbbr));
                addUnique(litigationCaseNumbers, docketCase.caseNumber);
                addUnique(litigationFilingDates, docketCase.caseFilingDate);
                //原告被告處理
                for (Party p : docketCase.parties) {
                    for (String role : p.roles) {
                        if (plaintiffRoleSet.contains(role)) {
                            addUnique(litigationPlaintiffs, p.name);
                            for (Firm f : p.firms) {
                                if (StringUtils.isNotBlank(f.name)) {
                                    addUnique(litigationPlaintiffFirms, f.name);
                                }
                            }
                        }
                        if (defendantRoleSet.contains(role)) {
                            addUnique(litigationDefendants, p.name);
                            for (Firm f : p.firms) {
                                if (StringUtils.isNotBlank(f.name)) {
                                    addUnique(litigationDefendantFirms, f.name);
                                }
                            }
                        }
                    }
                }
                
                litigationContents.add(JSONUtil.object2Json(docketCase));
            }
            solrInfo.litigationCaseTypes = litigationCaseTypes;
            solrInfo.litigationCaseNumbers = litigationCaseNumbers;
            solrInfo.litigationCaseNames = litigationCaseNames;
            solrInfo.litigationCaseStatus = litigationCaseStatus;
            solrInfo.litigationCounts = litigationCounts;
            solrInfo.litigationPleading = litigationPleading;
            solrInfo.litigationPleadingType = litigationPleadingType;
            solrInfo.litigationFilingDates = litigationFilingDates;
            solrInfo.litigationPlaintiffs = litigationPlaintiffs;
            solrInfo.litigationDefendants = litigationDefendants;
            solrInfo.litigationPlaintiffFirms = litigationPlaintiffFirms;
            solrInfo.litigationDefendantFirms = litigationDefendantFirms;
            solrInfo.litigationPatentValidity = litigationPatentValidity;
            solrInfo.litigationPatentInfringement = litigationPatentInfringement;
            solrInfo.litigationContents = litigationContents;
            solrInfo.litigationTotalCount = cases.size();
        }
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatRefRelatedParent(PatData patData, SolrPatentInfo solrInfo) {
        List<PatRefRelatedParent> patRefRelatedParentList = PatRefRelatedParentHelper.findByCondition(patData.patId, patData.defaultSourceId);
        
        if (patRefRelatedParentList == null || patRefRelatedParentList.size() == 0) {
            return;
        }
        
        patRefRelatedParentList.eachWithIndex {patRefRelatedParent, index ->
            def data = [:];
            data << [country : patRefRelatedParent.appCountry?:""];
            data << [appNumber : patRefRelatedParent.appNo?:""];
            data << [rawAppNumber : patRefRelatedParent.rawAppNo?:""];
            data << [appDate : patRefRelatedParent.appDate?:""];
            data << [patentNumber : patRefRelatedParent.docNo?:""];
            data << [rawDocNumber : patRefRelatedParent.rawDocNo?:""];
            data << [relatedType : patRefRelatedParent.relatedType?:""];
            
            String relatedParentStr = JSONUtil.mapToJSONString(data);
            solrInfo.relatedPatents.add(relatedParentStr);
            if (patRefRelatedParent.relatedType == 6) {
                solrInfo.appNumberGroup = patRefRelatedParent.appCountry + patRefRelatedParent.appNo
            }
        }
        
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatRefPct(PatData patData, SolrPatentInfo solrInfo) {
        
        List<PatRefPct> patRefPctList = PatRefPctHelper.findByPatId(patData.patId);
        
        if (patRefPctList == null || patRefPctList.size() == 0) {
            return;
        }
        
        patRefPctList.eachWithIndex {patRefPct, index ->

            // WO 不刷以下欄位
            if (solrInfo.country != "WO") {
                // pctAppNumber
                solrInfo.pctAppNumber = patRefPct.appNo;
                SolrNumberUtil.getPctAppNumberAll(patData, solrInfo);
                
                // pctOpenNumber
                solrInfo.pctOpenNumber = patRefPct.publicNo;
                SolrNumberUtil.getPctOpenNumberAll(patData, solrInfo);
                
                // pctAppDate
                fillDate(patRefPct.appDate, solrInfo, "pctApp");
                // pctOpenDate
                fillDate(patRefPct.publicDate, solrInfo, "pctOpen");
            }
            
        }
    }
    
    /**
     * 
     * @param personData
     * @param sequence
     * @return
     */
    private static String solrPersonDataStr(PersonData personData, int sequence) {
        def dataMap = [:]
        dataMap << [name: personData.personName]
        if (!!personData.country && personData.country.trim() != "") {
            dataMap << [country: personData.country]
        }
        if (!!personData.address && personData.address.trim() != "") {
            dataMap << [address: personData.address]
        }
        if (sequence >= 0) {
            dataMap << [sequence : sequence + 1]
        }
        
        return JSONUtil.mapToJSONString(dataMap)
    }   // end solrPersonDataStr
    
    /**
     * isOriginPTO的docdb[docdbInventors][docdbInventorsFacetname]不做
     *
     * @author tonykuo
     * @param patData
     * @param solrInfo
     */
    private static void transferPatPersonApplicant(PatData patData, SolrPatentInfo solrInfo) {
        
        ArrayList<String> applicants = new ArrayList<>();
        ArrayList<String> applicantsName = new ArrayList<>();
        ArrayList<String> applicantsAddress = new ArrayList<>();      // useless
        ArrayList<String> applicantsCountry = new ArrayList<>();      // useless
        ArrayList<String> applicantsFacetname = new ArrayList<>();
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatPersonApplicantHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList && dataList.size() > 0) {
            
            dataList.eachWithIndex { uuid, index ->
                //
                PersonData personData = PersonDataHelper.findByPersonId(uuid)
                // inventor data
                String applicantStr = solrPersonDataStr(personData, index);
                if (JSONUtil.isJSONValid(applicantStr)) {
                    applicants.add(applicantStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, applicants json format error...");
                }
                // inventorsName
                String applicantNameStr = JSONUtil.mapToJSONString(["origin": personData.personName] )
                if (JSONUtil.isJSONValid(applicantNameStr)) {
                    applicantsName.add(applicantNameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, applicantsName json format error...");
                }
                //
                String applicantFacetnameStr = JSONUtil.mapToJSONString(["origin": personData.personFacet])
                if (JSONUtil.isJSONValid(applicantFacetnameStr)) {
                    applicantsFacetname.add(applicantFacetnameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, applicantsFacetname json format error...");
                }
                
            }   // end dataList.eachWithIndex
            
            solrInfo.applicants = applicants;
            solrInfo.applicantsName = applicantsName;
            solrInfo.applicantsFacetname = applicantsFacetname;
            
        }   // end if (dataList.size() > 0)
        
    }   // end transferPatPersonApplicant
    
    /**
     * @author tonykuo
     * @param patData
     * @param solrInfo
     */
    private static void transferPatPersonExaminer(PatData patData, SolrPatentInfo solrInfo) {
        
        ArrayList<String> examinerMasters = new ArrayList<>();
        ArrayList<String> examinerMastersName = new ArrayList<>();
        ArrayList<String> examinerMastersAddress = new ArrayList<>();
        ArrayList<String> examinerMastersCountry = new ArrayList<>();       // useless
        ArrayList<String> examinerMastersFacetname = new ArrayList<>();     // useless
        ArrayList<String> examinerSlaves = new ArrayList<>();
        ArrayList<String> examinerSlavesName = new ArrayList<>();
        ArrayList<String> examinerSlavesAddress = new ArrayList<>();        // useless
        ArrayList<String> examinerSlavesCountry = new ArrayList<>();        // useless
        ArrayList<String> examinerSlavesFacetname = new ArrayList<>();
        
        List dataList = PatPersonExaminerHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList && dataList.size() > 0) {
            
            dataList.eachWithIndex { uuid, index ->
                //
                PersonData personData = PersonDataHelper.findByPersonId(uuid)
                String examinerStr = solrPersonDataStr(personData, -1);
                String examinerNameStr = JSONUtil.mapToJSONString(["origin": personData.personName])
                String examinerFacetnameStr = JSONUtil.mapToJSONString(["origin": personData.personFacet])
                //
                if (index == 0) {
                    //
                    if (JSONUtil.isJSONValid(examinerStr)) {
                        examinerMasters.add(examinerStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerMaster json format error...");
                    }
                    //
                    if (JSONUtil.isJSONValid(examinerNameStr)) {
                        examinerMastersName.add(examinerNameStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerMastersName json format error...");
                    }
                    //
                    if (JSONUtil.isJSONValid(examinerFacetnameStr)) {
                        examinerMastersFacetname.add(examinerFacetnameStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerMastersFacetname json format error...");
                    }
                    
                } else {
                    //
                    if (JSONUtil.isJSONValid(examinerStr)) {
                        examinerSlaves.add(examinerStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerSlaves json format error...");
                    }
                    //
                    if (JSONUtil.isJSONValid(examinerNameStr)) {
                        examinerSlavesName.add(examinerNameStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerSlavesName json format error...");
                    }
                    //
                    if (JSONUtil.isJSONValid(examinerFacetnameStr)) {
                        examinerSlavesFacetname.add(examinerFacetnameStr);
                    } else {
                        throw new Exception("pat_id = ${patData.patId}, examinerSlavesFacetname json format error...");
                    }
                    
                }   // end if (index == 0)
                
            }   // end dataList.eachWithIndex
            
            solrInfo.examinerMasters = examinerMasters;
            solrInfo.examinerMastersName = examinerMastersName;
            solrInfo.examinerMastersFacetname = examinerMastersFacetname;
            
            if (examinerSlaves.size > 0) {
                solrInfo.examinerSlaves = examinerSlaves;
            }
            if (examinerSlavesName.size > 0) {
                solrInfo.examinerSlavesName = examinerSlavesName;
            }
            if (examinerSlavesFacetname.size > 0) {
                solrInfo.examinerSlavesFacetname = examinerSlavesFacetname;
            }
            
        }   // end if (!!dataList && dataList.size() > 0)
        
    }   // end transferPatPersonExaminer
    
    /**
     * @author tonykuo
     * @param patData
     * @param solrInfo
     */
    private static void transferPatPersonAgent(PatData patData, SolrPatentInfo solrInfo) {
        
        ArrayList<String> agents = new ArrayList<>();
        ArrayList<String> agentsName = new ArrayList<>();
        ArrayList<String> agentsAddress = new ArrayList<>();     // useless
        ArrayList<String> agentsCountry = new ArrayList<>();     // useless
        ArrayList<String> agentsFacetname = new ArrayList<>();
        
        List dataList = PatPersonAgentHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList && dataList.size() > 0) {
            
            dataList.eachWithIndex { uuid, index ->
                //
                PersonData personData = PersonDataHelper.findByPersonId(uuid)
                // agent data
                String agentStr = solrPersonDataStr(personData, -1);
                if (JSONUtil.isJSONValid(agentStr)) {
                    agents.add(agentStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, agent json format error...");
                }
                // agent name
                String agentNameStr = JSONUtil.mapToJSONString(["origin": personData.personName] )
                if (JSONUtil.isJSONValid(agentNameStr)) {
                    agentsName.add(agentNameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, agentsName json format error...");
                }
                //
                String agentFacetnameStr = JSONUtil.mapToJSONString(["origin": personData.personFacet])
                if (JSONUtil.isJSONValid(agentFacetnameStr)) {
                    agentsFacetname.add(agentFacetnameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, agentsFacetname json format error...");
                }
                
            }   // end dataList.eachWithIndex
            
            solrInfo.agents = agents;
            solrInfo.agentsName = agentsName;
            solrInfo.agentsFacetname = agentsFacetname;
            
        }   // end if (dataList.size() > 0)
        
    }   // end transferPatPersonAgent
    
    /**
     * isOriginPTO的docdb[docdbInventors][docdbInventorsFacetname]不做
     * 
     * @author tonykuo
     * @param patData
     * @param solrInfo
     */
    private static void transferPatPersonInventor(PatData patData, SolrPatentInfo solrInfo) {
        
        ArrayList<String> inventors = new ArrayList<>();
        ArrayList<String> inventorsName = new ArrayList<>();
        ArrayList<String> inventorsAddress = new ArrayList<>();      // useless
        ArrayList<String> inventorsCountry = new ArrayList<>();      // useless
        ArrayList<String> inventorsFacetname = new ArrayList<>();
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatPersonInventorHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList && dataList.size() > 0) {
            
            dataList.eachWithIndex { uuid, index ->
                //
                PersonData personData = PersonDataHelper.findByPersonId(uuid)
                // inventor data
                String inventorStr = solrPersonDataStr(personData, index);
                if (JSONUtil.isJSONValid(inventorStr)) {
                    inventors.add(inventorStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, inventors json format error...");
                }
                // inventorsName
                String inventorNameStr = JSONUtil.mapToJSONString(["origin": personData.personName] )
                if (JSONUtil.isJSONValid(inventorNameStr)) {
                    inventorsName.add(inventorNameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, inventorsName json format error...");
                }
                //
                String inventorFacetnameStr = JSONUtil.mapToJSONString(["origin": personData.personFacet])
                if (JSONUtil.isJSONValid(inventorFacetnameStr)) {
                    inventorsFacetname.add(inventorFacetnameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, inventorsFacetname json format error...");
                }
                
            }   // end dataList.eachWithIndex
            
            solrInfo.inventors = inventors;
            solrInfo.inventorsName = inventorsName;
            solrInfo.inventorsFacetname = inventorsFacetname;
            // solr docdb data
            if (isOriginPTO == false) {
                solrInfo.docdbInventors = inventors;
                solrInfo.docdbInventorsFacetname = inventorsFacetname;
            }
            
        }   // end if (dataList.size() > 0)
        
    }   // end transferPatPersonInventor
    
    /**
     * isOriginPTO的docdb[docdbAssignees][docdbAssigneesFacetname]不做
     * 
     * @author tonykuo
     * @param patData
     * @param solrInfo
     */
    private static void transferPatPersonAssignee(PatData patData, SolrPatentInfo solrInfo) {
        
        ArrayList<String> assignees = new ArrayList<String>();
        ArrayList<String> assigneesName = new ArrayList<>();
        ArrayList<String> assigneesAddress = new ArrayList<>();    // useless
        ArrayList<String> assigneesCountry = new ArrayList<>();    // useless
        ArrayList<String> assigneesFacetname = new ArrayList<>();
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = null;
        
        if (isOriginPTO) {
            dataList = PatPersonAssigneeHelper.nativeQueryByPatId(patData.patId)
        } else {
            // docdb的applicant轉為assignees (現有規則, 新版有需要做此轉換 ???)
            dataList = PatPersonApplicantHelper.nativeQueryByPatId(patData.patId)
        }
        
        if (!!dataList && dataList.size() > 0) {
            
            dataList.eachWithIndex { uuid, index ->
                
                PersonData personData = PersonDataHelper.findByPersonId(uuid)
                
                // assignee data 
                String assignStr = solrPersonDataStr(personData, index);
                if (JSONUtil.isJSONValid(assignStr)) {
                    assignees.add(assignStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, assignees json format error...");
                }
                
                // assigneesName
                String assignNameStr = JSONUtil.mapToJSONString(["origin": personData.personName] )
                if (JSONUtil.isJSONValid(assignNameStr)) {
                    assigneesName.add(assignNameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, assigneesName json format error...");
                }
                
                // assigneesFacetname
                String assigneeFacetnameStr = JSONUtil.mapToJSONString(["origin": personData.personFacet])
                if (JSONUtil.isJSONValid(assigneeFacetnameStr)) {
                    assigneesFacetname.add(assigneeFacetnameStr);
                } else {
                    throw new Exception("pat_id = ${patData.patId}, assigneesFacetname json format error...");
                }
                
            }   // end dataList.eachWithIndex
            
            solrInfo.assignees = assignees;
            solrInfo.assigneesName = assigneesName;
            solrInfo.assigneesFacetname = assigneesFacetname;
            
            // solr docdb data
            if (isOriginPTO == false) {
                solrInfo.docdbAssignees = assignees;
                solrInfo.docdbaAssigneesFacetname = assigneesFacetname;
            }
            
        }   // end if (dataList.size() > 0)
        
    }   // end transferPatPersonAssignee
    
    /**
     * 
     * @param patData
     * @param solrInfo
     */
    private static void transferPatDataTitle(PatData patData, SolrPatentInfo solrInfo) {
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatDataTitleHelper.nativeQueryByPatId(patData.patId)
        
        String titleJSONStr = JSONUtil.toJSONString(dataList, isOriginPTO);
        
        if (JSONUtil.isJSONValid(titleJSONStr)) {
            solrInfo.title = titleJSONStr;
        } else {
            throw new Exception("pat_id = ${patData.patId}, tilte json format error...");
        }
        
    }   // end transferPatDataTitle
    
    /**
     *
     * @param patData
     * @param solrInfo
     */
    private static void transferPatDataBrief(PatData patData, SolrPatentInfo solrInfo) {
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatDataBriefHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList &&  dataList.size() > 0) {
            String briefJSONStr = JSONUtil.toJSONString(dataList, isOriginPTO);
            
            if (JSONUtil.isJSONValid(briefJSONStr)) {
                solrInfo.brief = briefJSONStr;
            } else {
                throw new Exception("pat_id = ${patData.patId}, brief json format error...");
            }
        }
        
    }   // end transferPatDataBrief
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatDataClaims(PatData patData, SolrPatentInfo solrInfo) {
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatDataClaimsHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList &&  dataList.size() > 0) {
            String claimsJSONStr = JSONUtil.toJSONString(dataList, isOriginPTO);
            
            if (JSONUtil.isJSONValid(claimsJSONStr)) {
                solrInfo.claim = claimsJSONStr;
            } else {
                throw new Exception("pat_id = ${patData.patId}, claims json format error...");
            }
        }
        
    }   // end of transferPatDataClaims
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatDataDesc(PatData patData, SolrPatentInfo solrInfo) {
        
        boolean isOriginPTO = CountryUtil.isOriginPTO(patData.country);
        
        List dataList = PatDataDescHelper.nativeQueryByPatId(patData.patId)
        
        if (!!dataList &&  dataList.size() > 0) {
            String descJSONStr = JSONUtil.toJSONString(dataList, isOriginPTO);
            
            if (JSONUtil.isJSONValid(descJSONStr)) {
                solrInfo.description = descJSONStr;
            } else {
                throw new Exception("pat_id = ${patData.patId}, description json format error...");
            }
        }
        
    }   // end of transferPatDataDesc
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatRefCited(PatData patData, SolrPatentInfo solrInfo) {
        List<PatRefCited> patRefCitedList = PatRefCitedHelper.findByCondition(patData.patId, patData.defaultSourceId);
        
        if (patRefCitedList == null || patRefCitedList.size() == 0) {
            return;
        }
        
        patRefCitedList.eachWithIndex {patRefCited, index ->
            String patNo = "";
            if (patRefCited.country == "US") {
                patNo = PatNumberUtil.getPatentNumberUS(patRefCited.docNo);
            } else {
                // TODO : 其他國別
                patNo = patRefCited.rawDocNo;
            }
            addUnique(solrInfo.citedPatentsNumberAll, patNo);
            solrInfo.citedPatents.add(JSONUtil.citedPatentsToJSONString(patRefCited.country, patNo));
        }
        
    }   // end of transferPatRefCited
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatRefCitedNpl(PatData patData, SolrPatentInfo solrInfo) {
        
        List<PatRefCitedNpl> patRefCitedNplList = PatRefCitedNplHelper.findByCondition(patData.patId, patData.defaultSourceId);
        
        if (patRefCitedNplList == null || patRefCitedNplList.size() == 0) {
            return;
        }
        
        patRefCitedNplList.eachWithIndex {npl, index ->
            solrInfo.otherReferences.add(npl.nplText + " cited by other .");
        }
        
    }   // end of transferPatRefCitedNpl
    
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatRefPriority(PatData patData, SolrPatentInfo solrInfo) {
        
        List<PatRefPriority> patRefPriorityList = PatRefPriorityHelper.findByCondition(patData.patId, patData.defaultSourceId);
        
        if (patRefPriorityList == null || patRefPriorityList.size() == 0) {
            return;
        }
        
        String appNo = "";
        patRefPriorityList.eachWithIndex {patRefPriority, index ->
            if (patRefPriority.country == "US") {
                if (!!patRefPriority.appNo) {
                    appNo = patRefPriority.appNo;
                } else {
                    appNo = PatNumberUtil.getAppNoUS(patRefPriority.rawAppNo);
                }
            } else {
                // TODO : 其他國別
                appNo = patRefPriority.rawAppNo;
            }
            addUnique(solrInfo.priorityPatentsNumberAll, appNo);
            solrInfo.priorityPatents.add(JSONUtil.priorityPatentsToJSONString(patRefPriority.country, appNo));
            
        }
    }   // end of transferPatRefPriority
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPtoidMapping(PatData patData, SolrPatentInfo solrInfo) {
        
        PatPtopidMapping patPtopidMapping = PatPtopidMappingHelper.findByPatId(patData.patId);
        
        solrInfo.id = patPtopidMapping.ptopidId;
        // 若default_source_id="DOCA01"，則寫入DOCDB,若default_source_id!="DOCA01"，pat_data.country進行轉換
        if (patData.defaultSourceId == Constants.SOURCE_ID_DOCDB_BRIEF) {
            solrInfo.pto = "DOCDB"
        } else {
            solrInfo.pto = CountryUtil.findPtoByCountry(patData.country);
        }
        solrInfo.ptopid = solrInfo.pto + "." + solrInfo.id;
    } // end of transferPtoidMapping

    /**
     * @param patData
     * @param solrInfo
     */
    public static void transPatData(PatData patData, SolrPatentInfo solrInfo) {
        solrInfo.country = patData.country;
        
        if (patData.kindCode != "--") {
            solrInfo.kindcode = patData.kindCode.toUpperCase();
        }
        
        solrInfo.patid = patData.patId;
        solrInfo.type = findPatType(patData.country, patData.patType);
        solrInfo.typeCode = patData.patType;
        solrInfo.truncate = patData.truncateFlag == 1 ?: false;
        // doDate
        fillDate(patData.docDate, solrInfo, "do");
        
        // patentNumber
        solrInfo.patentNumber = PatNumberUtil.getMappingPatentNumber(patData.stat, patData.docNo, patData.country, patData.kindCode);
        // patentNumberAll, openNumberAll, decisionNumberAll
        SolrNumberUtil.getPublicationNumberAll(patData, solrInfo);
        
        if (patData.stat == 1) {
            fillDate(patData.docDate, solrInfo, "open");
            solrInfo.openNumber = patData.docNo;
        } else if (patData.stat == 2) {
            fillDate(patData.docDate, solrInfo, "decision");
            solrInfo.decisionNumber = patData.docNo;
        }
        
        if(patData.stat != 3) {
            solrInfo.stats = new Integer[1];
            solrInfo.stats[0] = patData.stat;
        } else {
            solrInfo.stats = new Integer[2];
            solrInfo.stats[0] = 1;
            solrInfo.stats[0] = 2;
        }
        
        // TODO: 還有DOCDB來的familyId
        if (!!patData.familyId) {
            solrInfo.familyId = patData.familyId as int;
        }
        
        // 圖檔欄位
        solrInfo.filePageClaim = patData.pageNoOfClaim;
        solrInfo.filePageDesc = patData.pageNoOfDesc;
        solrInfo.filePageFig = patData.pageNoOfFirstImg;
        // TODO: 無此欄位 solrInfo.filePageFirst = patData.filePageFirst;
        solrInfo.filePageNumber = patData.totalPages;
        // TODO: solrInfo.gazettePageNumber = patData.gazettePageNumber;
        solrInfo.clipPageNumber = patData.sizeOfClips;
        solrInfo.figurePageNumber = patData.pageNoOfFigure;
        solrInfo.firstImagePageFlag = (patData.firstImgFlag == 1) ? true : false;
        
        if (!!patData.examAppDate) {
            fillDate(patData.examAppDate, solrInfo, "exam");
        }
        
        if (!!patData.registrationNo) {
            solrInfo.certificateNumber = patData.registrationNo;
        }
        
        if (!!patData.registrationDate) {
            fillDate(patData.registrationDate, solrInfo, "certificate");
        }
        
    } // end of transPatData
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transAppData(PatData patData, SolrPatentInfo solrInfo) {
        
        AppData appData = AppDataHelper.findByAppId(patData.appId, patData.country);
        solrInfo.appNumber = appData.appNo;
        
        fillDate(appData.appDate, solrInfo, "app");
        // 若存在pat_ref_related_parent.related_type=6之資料，appNumberGroup會被覆蓋
        solrInfo.appNumberGroup = patData.country + appData.appNo;
        // appNumberAll
        SolrNumberUtil.getAppNumberAll(patData, solrInfo);
        
    } // end of transAppData
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatClsIpc(PatData patData, SolrPatentInfo solrInfo) {
        
        // ipc & ipcr 
        List<PatClsIpc> patClsIpcList = PatClsIpcHelper.findByCondition(patData.patId, patData.defaultSourceId);
        
        if (patClsIpcList == null || patClsIpcList.size() == 0) {
            return;
        }
        
        List<IpcInfo> ipcInfoList = new ArrayList<>();
        patClsIpcList.eachWithIndex {ipc, index ->
            genCpcIpcFileds(solrInfo, ipc.rawMainFlag, ipc.ipcText, "IPC", ipcInfoList);
        } // end of loop patClsIpcList
        
        // 如果是ipcr狀況,就不會有main_flag=1,就以patClsIpcList第一筆為mainIPC
        if (!solrInfo.mainIPC) {
            solrInfo.mainIPC = patClsIpcList.get(0).ipcText;
            solrInfo.mainIPCNormal = ipcInfoList.get(0).ipcNormal;
            solrInfo.mainIPCClass = ipcInfoList.get(0).clazz;
            solrInfo.mainIPCSubClass = ipcInfoList.get(0).subClazz;
            solrInfo.mainIPCGroup = ipcInfoList.get(0).group;
            solrInfo.mainIPCSubGroup = ipcInfoList.get(0).subGroup;
        }
        
    } // end of transferPatClsIpc
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatClsCpc(PatData patData, SolrPatentInfo solrInfo) {
        
        def updateCpc = null;
        
        // TODO: 目前只有 us有cpc的更新資料
        if (patData.country == "US") {
            updateCpc = cpcColl.findOne([_id:solrInfo.patentNumber]);
        }

        if (!!updateCpc) {

            String mainCpc = null;
            ArrayList<String> cpcs = new ArrayList<String>();

            def bag = updateCpc."data"."CPCClassificationBag";

            if (!!bag && !!bag."MainCPC" && !!bag."MainCPC"."CPCClassification") {
                def ct = bag."MainCPC"."CPCClassification"
                mainCpc = ct."CPCSection" + ct."Class" + ct."Subclass" + " " + ct."MainGroup" + "/" + ct."Subgroup";
            }
            if (!!bag."FurtherCPC") {
                def fu = bag."FurtherCPC";
                if (!!fu."CPCClassification") {
                    fu."CPCClassification".each {ct ->
                        String c = ct."CPCSection" + ct."Class" + ct."Subclass" + " " + ct."MainGroup" + "/" + ct."Subgroup";
                        addUnique(cpcs, c);
                    }
                }
                // TODO: cset沒有實例, 等找到再補
                if (!!fu."COCCombinationSet") {
                    fu."COCCombinationSet".each {cSet->
                        cSet."CPCCombinationRank".each {cRank ->
                            def ct = cRank."CPCClassification"
                            String c = ct."CPCSection" + ct."Class" + ct."Subclass" + " " + ct."MainGroup" + "/" + ct."Subgroup";
                            addUnique(cpcs, c);
                        }
                    }
                }
            }

            if (!!mainCpc) {
                genCpcIpcFileds(solrInfo, Constants.CLS_CPC_MAIN_FLAG_YES, mainCpc, "CPC", null);
            }

            cpcs.each {cpc ->
                genCpcIpcFileds(solrInfo, Constants.CLS_CPC_MAIN_FLAG_NO, cpc, "CPC", null);
            }

        } else {
            // pat_cls_cpc
            List<PatClsCpc> patClsCpcList = PatClsCpcHelper.findByCondition(patData.patId, patData.defaultSourceId);

            patClsCpcList.eachWithIndex {cpc, index ->
                genCpcIpcFileds(solrInfo, cpc.rawMainFlag, cpc.cpcText, "CPC", null);
            } // end of loop patClsCpcList

            // pat_cls_cset
            List<PatClsCset> patClsCsetList = PatClsCsetHelper.findByCondition(patData.patId, patData.defaultSourceId);
            patClsCsetList.eachWithIndex {cset, index ->
                genCpcIpcFileds(solrInfo, Constants.CLS_CPC_MAIN_FLAG_NO, cset.cpcText, "CPC", null);
            } // end of loop patClsCsetList

        }

    } // end of transferPatClsCpc
    
    /**
     * @param solrInfo
     * @param rawMainFlag
     * @param mainCls
     * @param clsType
     */
    private static void genCpcIpcFileds(SolrPatentInfo solrInfo, int rawMainFlag, String clsText, String clsType, List<IpcInfo> ipcInfoList) {
        
        IpcInfo ipcInfo = PatClsUtil.normalizeIPCAndCPCSolr(clsText, clsType);
        
        if (clsType == "CPC") {
            if (rawMainFlag == Constants.CLS_CPC_MAIN_FLAG_YES) {
                solrInfo.mainCPC = clsText;
                solrInfo.mainCPCNormal = ipcInfo.ipcNormal;
                solrInfo.mainCPCClass = ipcInfo.clazz;
                solrInfo.mainCPCSubClass = ipcInfo.subClazz;
                solrInfo.mainCPCGroup = ipcInfo.group;
                solrInfo.mainCPCSubGroup = ipcInfo.subGroup;
            }
            solrInfo.cpcs.add(clsText);
            solrInfo.cpcsNormal.add(ipcInfo.ipcNormal);
            solrInfo.cpcsClass.add(ipcInfo.clazz);
            solrInfo.cpcsSubClass.add(ipcInfo.subClazz);
            solrInfo.cpcsGroup.add(ipcInfo.group);
            solrInfo.cpcsSubGroup.add(ipcInfo.subGroup);
             
        } else if (clsType == "IPC") {
        
            if (rawMainFlag == Constants.CLS_IPC_MAIN_FLAG_YES) {
                solrInfo.mainIPC = clsText;
                solrInfo.mainIPCNormal = ipcInfo.ipcNormal;
                solrInfo.mainIPCClass = ipcInfo.clazz;
                solrInfo.mainIPCSubClass = ipcInfo.subClazz;
                solrInfo.mainIPCGroup = ipcInfo.group;
                solrInfo.mainIPCSubGroup = ipcInfo.subGroup;
            }
            solrInfo.ipcs.add(clsText);
            solrInfo.ipcsNormal.add(ipcInfo.ipcNormal);
            solrInfo.ipcsClass.add(ipcInfo.clazz);
            solrInfo.ipcsSubClass.add(ipcInfo.subClazz);
            solrInfo.ipcsGroup.add(ipcInfo.group);
            solrInfo.ipcsSubGroup.add(ipcInfo.subGroup);
            
            ipcInfoList.add(ipcInfo);
        }
    }  // end of genCpcIpcFileds
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatClsUspc(PatData patData, SolrPatentInfo solrInfo) {
        
        def updateUspc = null;
        
        // TODO: 目前只有 us有uspc的更新資料
        if (patData.country == "US") {
            if (patData.stat == 1) {
                updateUspc = uspcApplColl.findOne([_id:solrInfo.patentNumber]);
            } else {
                updateUspc = uspcPatColl.findOne([_id:solrInfo.patentNumber]);
            }
        }

        if (!!updateUspc) {

            ArrayList<String> uspcs = new ArrayList<>();
            if (!!updateUspc."mainUspc") {    //USPC 更新後，可能沒有 main uspc
                String uspcNormal = PatClsUtil.uspcNormal(updateUspc."mainUspc");
                solrInfo.mainUSPC = uspcNormal;
                solrInfo.uspcs.add(uspcNormal);
            } else {
                solrInfo.mainUSPC = null;
            }
            if (!!updateUspc."uspcs") {
                for (String u : updateUspc."uspcs") {
                    solrInfo.uspcs.add(PatClsUtil.uspcNormal(u));
                }
            }
            
        } else {
        
            List<PatClsUspc> patClsUspcList = PatClsUspcHelper.findByCondition(patData.patId, patData.defaultSourceId);

            patClsUspcList.eachWithIndex {uspc, index ->
                if (uspc.rawMainFlag == Constants.CLS_USPC_MAIN_FLAG_YES) {
                    solrInfo.mainUSPC = uspc.uspcText.trim();
                }
                solrInfo.uspcs.add(uspc.uspcText.trim());
            } // end of loop patClsUspcList
        }
        
    } // end of transferPatClsUspc
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatClsLoc(PatData patData, SolrPatentInfo solrInfo) {
        
        List<PatClsLoc> patClsLocList = PatClsLocHelper.findByCondition(patData.patId, patData.defaultSourceId);
        patClsLocList.eachWithIndex {loc, index ->
            if (loc.rawMainFlag == Constants.CLS_LOC_MAIN_FLAG_YES) {
                solrInfo.mainLOC = loc.locText;
                solrInfo.mainLOCClass = solrInfo.mainLOC[0..1];
            }
            solrInfo.locs.add(loc.locText);
            solrInfo.locsClass.add(loc.locText[0..1]);
        } // end of patClsLocList
        
    } // end of transferPatClsLoc
    
    // TODO:
    private static void transferPatClsDi() {
        // do something...
    }
    
    // TODO:
    private static void transferPatClsDTerm() {
        // do something...
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    private static void transferPatClsEcla(PatData patData, SolrPatentInfo solrInfo) {
        List<PatClsEcla> patClsEclaList = PatClsEclaHelper.findByCondition(patData.patId)
        patClsEclaList.each{patClsEcla ->
            solrInfo.eclas.add(patClsEcla.eclaText);
        }
    }
    
    // TODO:
    private static void transferPatClsFi() {
        // do something...
    }
    
    // TODO:
    private static void transferPatClsFTerm() {
        // do something...
    }
    
    /**
     * @param date
     * @param solr
     * @param solrFieldName
     */
    private static void fillDate(Date date, SolrPatentInfo solr, String solrFieldName) {
        if (date == null) {
            return;
        }

        try {
            Field fdate = solr.getClass().getField(solrFieldName + "Date");
            SimpleDateFormat fmtDate = new SimpleDateFormat("yyyy-MM-dd");
            fdate.set(solr, DateUtil.parseDate(fmtDate.format(date)));

            Field fdateYear = solr.getClass().getField(solrFieldName + "Year");
            SimpleDateFormat fmtYear = new SimpleDateFormat("yyyy");
            fdateYear.set(solr, Integer.parseInt(fmtYear.format(date)));

            Field fdateYearMon = solr.getClass().getField(solrFieldName + "Yearmon");
            SimpleDateFormat fmtYearMon = new SimpleDateFormat("yyyyMM");
            fdateYearMon.set(solr, Integer.parseInt(fmtYearMon.format(date)));
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
        
    } // end of fillDate
    
    /**
     * @param country
     * @param patTypeCode
     * @return
     */
    private static String findPatType(String country, int patTypeCode) {
        String patType = "";
        switch (country) {
            case "US":
                patType = PatTypeEnum.US.findPatTypeName(patTypeCode);
                break;
            case "TW":
                // TODO: patType = "TIPO";
                break;
            case "CN":
                patType = PatTypeEnum.CN.findPatTypeName(patTypeCode);
                break;
            case "JP":
                // TODO: patType = "JPO";
                break;
            case "KR":
                // TODO: patType = "KIPO";
                break;
            case "EP":
                // TODO: patType = "EPO";
                break;
            case "WO":
                patType = Constants.PAT_TYPE_PLANT_NAME_WO
                break;
            // TODO: IN
            /*
            case "IN":
                pto = "IN";
                break;
            */
            default:
                patType = PatTypeEnum.DOCDB.findPatTypeName(patTypeCode);
                break;
        } // end of switch
        
        if (!patType) {
            throw new Exception("patType code error!");
        }
        
        return patType;
    } // end of findPatType
    
    
    private static <T> void addUnique(List<T> list, T val) {
        if (!list.contains(val)) {
            list.add(val);
        }
    }

    private static <T> void addUnique(List<T> list, List<T> vals) {
        for (T v : vals) {
            addUnique(list, v);
        }
    }
    
    private static Set<String> plaintiffRoleSet = new HashSet<String>() {{
        add("AMICUSCURIAE");
        add("ANCILLARY RESPONDENT");
        add("APPELLEE");
        add("COMPLAINANT");
        add("CONSOL COUNTER PLAINTIFF");
        add("CONSOLIDATED CROSSCLAIMANT");
        add("CONSOLIDATED PLAINTIFF");
        add("CONSOLIDATED THIRD PARTY PLAINTIFF");
        add("COUNTER CLAIMANT APPELLANT");
        add("COUNTER DEFENDANT");
        add("COUNTERCLAIM DEFENDANT APPELLEE");
        add("COUNTERCLAIM DEFENDANT CROSS APPELLANT");
        add("PATENT OWNER");
        add("PETITIONER APPELLANT");
        add("PLAINTIFF");
        add("PLAINTIFF APPELLANT");
        add("PLAINTIFF APPELLEE");
        add("PLAINTIFF CROSS APPELLANT");
        add("PLAINTIFF PETITIONER");
        add("PLAINTIFF RESPONDENT");
        add("PLAINTIFF SECONDARYENTITY");
        add("REAL PARTY IN INTEREST PLAINTIFF");
        add("RELATOR");
        add("THIRD PARTY DEFENDANT APPELLANT");
        add("THIRD PARTY DEFENDANT CROSS APPELLANT");
    }};

    private static Set<String> defendantRoleSet = new HashSet<String>() {{
        add("AMICUS");
        add("ANCILLARY REQUESTER");
        add("APPELLANT");
        add("CONSOLIDATED CLAIMANT");
        add("CONSOLIDATED COUNTER CLAIMANT");
        add("CONSOLIDATED COUNTER DEFENDANT");
        add("CONSOLIDATED CROSSDEFENDANT");
        add("CONSOLIDATED DEFENDANT");
        add("CONSOLIDATED THIRD PARTY DEFENDANT");
        add("COUNTER CLAIMANT");
        add("COUNTER CLAIMANT APPELLEE");
        add("COUNTER CLAIMANT CROSS APPELLANT");
        add("COUNTERCLAIM DEFENDANT");
        add("COUNTERCLAIM DEFENDANT APPELLANT");
        add("CREDITOR");
        add("CROSS APPELLANT");
        add("CROSSCLAIMANT");
        add("CROSSDEFENDANT");
        add("DEBTOR");
        add("DEFENDANT");
        add("DEFENDANT APPELLANT");
        add("DEFENDANT APPELLEE");
        add("DEFENDANT CROSS APPELLANT");
        add("DEFENDANT PETITIONER");
        add("DEFENDANT RESPONDENT");
        add("GARNISHEE");
        add("INTERVENOR APPELLEE");
        add("INTERVENOR DEFENDANT");
        add("MOVANT APPELLEE");
        add("MOVANT CROSS APPELLANT");
        add("NONPARTY APPELLANT");
        add("PETITIONER");
        add("PETITIONER APPELLEE");
        add("REAL PARTY IN INTEREST DEFENDANT");
        add("REQUESTER");
        add("RESPONDENT APPELLANT");
        add("RESPONDENT APPELLEE");
        add("THIRD PARTY DEFENDANT APPELLEE");
        add("THIRD PARTY PLAINTIFF");
        add("THIRD PARTY PLAINTIFF APPELLANT");
        add("THIRD PARTY PLAINTIFF APPELLEE");
        add("THIRD PARTY PLAINTIFF CROSS APPELLANT");
    }};

    private static String getPleadingType(String p) {
        p = p.toLowerCase();
        if (p.contains("infringement")) {
            return "Infringement";
        } else if (p.contains("declaratory judgement")) {
            return "DJ";
        } else if (p.contains("enforcement")) {
            return "Enforcement";
        } else if (p.contains("review") || p.equalsIgnoreCase("Covered Business Method")) {
            return "Review";
        } else {
            return "Others";
        }
    }
    
}
