package com.patentsolr

import com.patentdata.util.DateUtil

class CliExecutor {
    
    public 
    
    static main(args) {
        
        // args = ["-b", "20160307", "-e", "20160309"];

        def cli = new CliBuilder(usage: 'USPatDataProcess.groovy -[hbe]');
        
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;

        def dateBegin = DateUtil.parseDate(beginDate);
        def dateEnd = DateUtil.parseDate(endDate);

        // def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];
        def query = ['startDate' : dateBegin, 'endDate' : dateEnd, 'country' : "US"];

        // def query = ['pat_id' : "US00009249021"];
        
        println "query = ${query}"
        
        // new IndexMaker().process(query);
        
    }

}
