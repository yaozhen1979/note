package com.patentsolr

import org.apache.solr.client.solrj.impl.ConcurrentUpdateSolrClient
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.patentdata.helper.PatDataHelper
import com.patentdata.model.PatData
import com.patentdata.util.DateUtil
import com.patentdata.util.PropertiesUtil
import com.patentdata.util.RestTimeProcess
import com.patentsolr.model.SolrPatentInfo

public class IndexMaker {

    private static Logger logger = LoggerFactory.getLogger(IndexMaker.class);

    private ConcurrentUpdateSolrClient solrindex1;
    private ConcurrentUpdateSolrClient solrindex2;
    private static int sizeOfBulk = 100;

    /**
     * @param queryMap
     */
    public void process(Map queryMap) {

        List<PatData> patDataList = new ArrayList<>();
        //                patDataList.add(PatDataHelper.findByPatId("US00009249021"));
        //        patDataList.add(PatDataHelper.findByPatId("US0000D500410"));  // assigneer
        //        patDataList.add(PatDataHelper.findByPatId("US00009237737"));
        //        patDataList.add(PatDataHelper.findByPatId("US0000PP15460"));
        //        patDataList.add(PatDataHelper.findByPatId("US20050000040"));
        //        patDataList.add(PatDataHelper.findByPatId("US00009265231"));
        //        patDataList.add(PatDataHelper.findByPatId("US00006846039")); // otherref
        //        patDataList.add(PatDataHelper.findByPatId("US00006840989"));    // PAT_REF_CITED, pat_ref_priority
        //        patDataList.add(PatDataHelper.findByPatId("US20050065046"));    // pat_ref_priority
        //        patDataList.add(PatDataHelper.findByPatId("US20050003496"));
        //        patDataList.add(PatDataHelper.findByPatId("US20050000020")); // uspc update
        //        patDataList.add(PatDataHelper.findByPatId("US00006836912"));   // PAT_REF_PCT
        //        patDataList.add(PatDataHelper.findByPatId("US00007226155"));   // pat_ref_related_parent
        //                patDataList.add(PatDataHelper.findByPatId("US00003956499"));    // LitigationDN
        patDataList.add(PatDataHelper.findByPatId("US00008944289"));    // Assignment


        def dateBegin = DateUtil.parseDate(queryMap.startDate);
        def dateEnd = DateUtil.parseDate(queryMap.endDate);

        //        List<PatData> patDataList = PatDataHelper.queryByDocDateRange(dateBegin, dateEnd, queryMap.country);

        String solrUrl1 = PropertiesUtil.getSolrUrl(queryMap.location, 1, queryMap.core);
        String solrUrl2 = PropertiesUtil.getSolrUrl(queryMap.location, 2, queryMap.core);
        solrindex1 = new ConcurrentUpdateSolrClient(solrUrl1, sizeOfBulk, 2);
        solrindex2 = new ConcurrentUpdateSolrClient(solrUrl2, sizeOfBulk, 2);

        RestTimeProcess rtp = new RestTimeProcess(patDataList.size(), "country[$queryMap.core], doc_date[$queryMap.startDate~$queryMap.endDate]");

        for (int i=0; i < patDataList.size(); i++) {

            PatData patData = patDataList.get(i);
            try {
                SolrPatentInfo solrInfo = SolrInfoTransfer.transfer2SolrPatentInfo(patData);

                //            logger.info(solrInfo.toString());
                if (solrInfo.stats[0] == 1) {
                    solrindex1.addBean(solrInfo);
                } else {
                    solrindex2.addBean(solrInfo);
                }

                if (i % sizeOfBulk == 0) {
                    logger.info("start commit");
                    long time1 = System.currentTimeMillis();
                    solrindex1.commit();
                    solrindex2.commit();
                    long time2 = System.currentTimeMillis();
                    logger.info("end commit, total time: " + (time2 - time1)/1000);
                }
                
                rtp.process();

            } catch (Exception ex) {
                logger.error("patId $patData.patId error !");
                throw ex;
            }

        }

        solrindex1.commit();
        solrindex2.commit();
        solrindex1.close();
        solrindex2.close();

        logger.debug("finish");
    }

    public static void main(String[] args) throws Exception {

        // 測試使用
        //        args = ["", "20050101", "-e", "20050131", "-c" : "us"];

        def cli = new CliBuilder(usage: 'IndexMaker.groovy -[hbekl]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
            k longOpt: 'patId',      args: 1, argName: 'pat id',     'Id Value'
            l longOpt: 'location',   args: 1, argName: 'nh or sz',   'Location'
            c longOpt: 'core name',   args: 1, argName: 'core name', 'Core name'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;

        def query = ['startDate' : beginDate, 'endDate' : endDate, "key" : options.k, "location" : options.l, "core" : options.c];

        new IndexMaker().process(query);

        logger.info("finished...");
    }
}
