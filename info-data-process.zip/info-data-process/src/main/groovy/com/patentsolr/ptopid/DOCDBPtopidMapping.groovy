package com.patentsolr.ptopid

import com.patentdata.model.PatData
import com.patentdata.model.PatPtopidMapping
import com.gmongo.GMongoClient;
import com.mongodb.DB;
import com.patentdata.helper.PatDataHelper
import com.patentdata.service.PatPtopidMappingService
import com.patentdata.util.MongoUtil
import com.patentdata.util.RestTimeProcess;
import com.patentdata.util.DateUtil

class DOCDBPtopidMapping {
    
    static main(args) {

        GMongoClient dbClient = MongoUtil.connectByConfig("DOCDB");
        DB patentInfoDOCDB = dbClient.getDB("PatentInfoDOCDB");
        def collection = patentInfoDOCDB.PatentInfoDOCDB;

        PatPtopidMappingService patPtopidMappingService = new PatPtopidMappingService();
        
        // NOTE: AT 完成: 不過太慢了 = =
        // NOTE: AU finished => ["1911-10-10", 1230];  // AU 應該是全部都找不到資料..., why ???
        // NOTE: BR finished
        String mappingCC = "BR";
        // List<PatData> patDataList = PatDataHelper.queryByCountry(mappingCC);
        // List<PatData> patDataList = PatDataHelper.queryByPatId("AT139816-T-19960715");
        //
        
        // 找出每一期的docdbDodate和相關筆數
        // List docDateList = PatDataHelper.nativeQueryByCountry(mappingCC);
        List docDateList = getDocdbDoDateList_8();
        // List docDateList = [] << ["1921-11-10", 216];

        docDateList.each { it ->
            
            println "docDate = ${it[0]}, count = ${it[1]}"
            
            String docDate = it[0] as String
            int count = it[1] as int
            List patDataList = PatDataHelper.queryByDocDate(docDate, mappingCC);

            RestTimeProcess rtp = new RestTimeProcess(count, "");

            patDataList.each { patData ->

                // println "finding data..."
                String cc = patData.country
                String patentNumber = patData.rawDocNo
                String kindcode = patData.kindCode
                String doDate = patData.docDate.toString()

                // println "pat_id = ${patData.patId}, country = ${cc}, patentNumber = ${patentNumber}, kindcode = ${kindcode}, doDate = ${doDate}"

                // DBCursor queryCursor = marshallCol.find(queryMap.query).limit(0).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
                def queryMap = [country: cc, patentNumber: patentNumber, kindcode: kindcode, doDate: DateUtil.parseDate(doDate)]
                def queryMappingData = collection.findOne(queryMap)

                if (!!queryMappingData) {
                    // println "data exists..."
                    PatPtopidMapping patPtopidMapping = new PatPtopidMapping();
                    patPtopidMapping.patData = patData;
                    patPtopidMapping.ptopidId = queryMappingData._id.toString();
                    // println "queryMappingData._id = ${queryMappingData._id.toString()}"

                    patPtopidMappingService.saveOrUpdatePatPtopidMapping(patPtopidMapping);

                } else {
                    println "queryMap = ${queryMap}, data does not exist..."
                }

                rtp.process();

            }   // end patDataList.each

        }    // end docDateList.each


        println "finished..."

    }   // end main
    
//    /**
//     * TODO
//     * 
//     * @return
//     */
//    private static List getDocdbDoDateList_1() {
//        
//        List docDateList = [];
//        
//        docDateList << ["1911-10-10", 1230];  // AU 應該是全部都找不到資料..., why ???
//        
//        return docDateList;
//    }
    
    /**
     *  finished:
     */
    private static List getDocdbDoDateList_8() {
        
        List docDateList = []
        
//        docDateList << ["2011-07-05", 488];
//        docDateList << ["2011-07-12", 671];
//        docDateList << ["2011-07-19", 517];
//        docDateList << ["2011-07-26", 685];
//        docDateList << ["2011-08-02", 559];
//        docDateList << ["2011-08-09", 656];
//        docDateList << ["2011-08-16", 474];
//        docDateList << ["2011-08-23", 856];
//        docDateList << ["2011-08-30", 572];
//        docDateList << ["2011-09-06", 681];
//        docDateList << ["2011-09-13", 477];
//        docDateList << ["2011-09-20", 442];
//        docDateList << ["2011-09-27", 291];
//        docDateList << ["2011-10-04", 415];
//        docDateList << ["2011-10-11", 318];
//        docDateList << ["2011-10-18", 517];
//        docDateList << ["2011-10-25", 294];
//        docDateList << ["2011-11-01", 503];
//        docDateList << ["2011-11-08", 301];
//        docDateList << ["2011-11-16", 452];
//        docDateList << ["2011-11-22", 267];
//        docDateList << ["2011-11-29", 524];
//        docDateList << ["2011-12-06", 403];
//        docDateList << ["2011-12-13", 417];
//        docDateList << ["2011-12-20", 451];
//        docDateList << ["2011-12-27", 298];
//        docDateList << ["2012-01-03", 209];
//        docDateList << ["2012-01-10", 432];
//        docDateList << ["2012-01-17", 357];
//        docDateList << ["2012-01-24", 325];
//        docDateList << ["2012-01-31", 97];
//        docDateList << ["2012-02-07", 244];
//        docDateList << ["2012-02-14", 115];
//        docDateList << ["2012-02-22", 293];
//        docDateList << ["2012-02-28", 218];
//        docDateList << ["2012-03-06", 250];
//        docDateList << ["2012-03-13", 281];
//        docDateList << ["2012-03-20", 267];
//        docDateList << ["2012-03-27", 238];
//        docDateList << ["2012-04-03", 147];
//        docDateList << ["2012-04-10", 205];
//        docDateList << ["2012-04-17", 387];
//        docDateList << ["2012-04-24", 122];
//        docDateList << ["2012-05-02", 202];
//        docDateList << ["2012-05-08", 49];
//        docDateList << ["2012-05-15", 226];
//        docDateList << ["2012-05-22", 120];
//        docDateList << ["2012-05-29", 244];
//        docDateList << ["2012-06-05", 130];
//        docDateList << ["2012-06-12", 226];
//        docDateList << ["2012-06-19", 89];
//        docDateList << ["2012-06-26", 215];
//        docDateList << ["2012-07-03", 153];
//        docDateList << ["2012-07-10", 160];
//        docDateList << ["2012-07-17", 105];
//        docDateList << ["2012-07-24", 225];
//        docDateList << ["2012-07-31", 111];
//        docDateList << ["2012-08-07", 208];
//        docDateList << ["2012-08-14", 59];
//        docDateList << ["2012-08-21", 254];
//        docDateList << ["2012-08-28", 103];
//        docDateList << ["2012-09-04", 385];
//        docDateList << ["2012-09-11", 83];
//        docDateList << ["2012-09-18", 225];
//        docDateList << ["2012-09-25", 106];
//        docDateList << ["2012-10-02", 359];
//        docDateList << ["2012-10-09", 134];
//        docDateList << ["2012-10-16", 241];
//        docDateList << ["2012-10-23", 188];
//        docDateList << ["2012-10-30", 320];
//        docDateList << ["2012-11-06", 234];
//        docDateList << ["2012-11-13", 1];
//        docDateList << ["2012-11-20", 196];
//        docDateList << ["2012-11-27", 325];
//        docDateList << ["2012-12-04", 247];
//        docDateList << ["2012-12-11", 398];
//        docDateList << ["2012-12-18", 213];
//        docDateList << ["2012-12-25", 687];
//        docDateList << ["2012-12-26", 2];
//        docDateList << ["2013-01-01", 325];
//        docDateList << ["2013-01-08", 416];
//        docDateList << ["2013-01-15", 270];
//        docDateList << ["2013-01-22", 393];
//        docDateList << ["2013-01-29", 158];
//        docDateList << ["2013-02-05", 265];
//        docDateList << ["2013-02-13", 282];
//        docDateList << ["2013-02-19", 556];
//        docDateList << ["2013-02-26", 301];
//        docDateList << ["2013-03-05", 334];
//        docDateList << ["2013-03-12", 251];
//        docDateList << ["2013-03-19", 293];
//        docDateList << ["2013-03-26", 295];
//        docDateList << ["2013-04-02", 402];
//        docDateList << ["2013-04-09", 289];
//        docDateList << ["2013-04-16", 274];
//        docDateList << ["2013-04-24", 411];
//        docDateList << ["2013-04-30", 240];
//        docDateList << ["2013-05-07", 291];
//        docDateList << ["2013-05-14", 224];
//        docDateList << ["2013-05-21", 315];
//        docDateList << ["2013-05-28", 310];
//        docDateList << ["2013-06-04", 427];
//        docDateList << ["2013-06-11", 415];
//        docDateList << ["2013-06-18", 446];
//        docDateList << ["2013-06-25", 435];
//        docDateList << ["2013-07-02", 438];
//        docDateList << ["2013-07-09", 339];
//        docDateList << ["2013-07-16", 413];
//        docDateList << ["2013-07-23", 388];
//        docDateList << ["2013-07-30", 442];
//        docDateList << ["2013-08-06", 492];
//        docDateList << ["2013-08-13", 459];
//        docDateList << ["2013-08-20", 70];
//        docDateList << ["2013-08-27", 79];
//        docDateList << ["2013-09-03", 206];
//        docDateList << ["2013-09-10", 207];
//        docDateList << ["2013-09-17", 389];
//        docDateList << ["2013-09-24", 344];
//        docDateList << ["2013-10-01", 329];
//        docDateList << ["2013-10-08", 415];
//        docDateList << ["2013-10-15", 497];
//        docDateList << ["2013-10-22", 605];
//        docDateList << ["2013-10-29", 699];
//        docDateList << ["2013-11-05", 472];
//        docDateList << ["2013-11-12", 652];
//        docDateList << ["2013-11-19", 591];
//        docDateList << ["2013-11-26", 585];
//        docDateList << ["2013-12-03", 444];
//        docDateList << ["2013-12-10", 295];
//        docDateList << ["2013-12-17", 505];
//        docDateList << ["2013-12-24", 481];
//        docDateList << ["2013-12-31", 230];
//        docDateList << ["2014-01-07", 273];
//        docDateList << ["2014-01-14", 201];
//        docDateList << ["2014-01-21", 185];
//        docDateList << ["2014-01-28", 218];
//        docDateList << ["2014-02-04", 445];
//        docDateList << ["2014-02-11", 312];
//        docDateList << ["2014-02-18", 292];
//        docDateList << ["2014-02-25", 335];
//        docDateList << ["2014-03-04", 307];
//        docDateList << ["2014-03-11", 295];
//        docDateList << ["2014-03-18", 441];
//        docDateList << ["2014-03-25", 325];
//        docDateList << ["2014-04-01", 204];
//        docDateList << ["2014-04-08", 325];
//        docDateList << ["2014-04-15", 354];
//        docDateList << ["2014-04-22", 397];
//        docDateList << ["2014-04-29", 417];
//        docDateList << ["2014-05-06", 507];
//        docDateList << ["2014-05-13", 384];
//        docDateList << ["2014-05-20", 470];
//        docDateList << ["2014-05-27", 827];
//        docDateList << ["2014-06-03", 1008];
//        docDateList << ["2014-06-10", 647];
//        docDateList << ["2014-06-17", 547];
//        docDateList << ["2014-06-24", 427];
//        docDateList << ["2014-07-01", 367];
//        docDateList << ["2014-07-08", 249];
//        docDateList << ["2014-07-15", 289];
//        docDateList << ["2014-07-22", 269];
//        docDateList << ["2014-07-29", 236];
//        docDateList << ["2014-08-05", 333];
//        docDateList << ["2014-08-12", 279];
//        docDateList << ["2014-08-19", 484];
//        docDateList << ["2014-08-26", 600];
//        docDateList << ["2014-09-02", 505];
//        docDateList << ["2014-09-09", 574];
//        docDateList << ["2014-09-16", 685];
//        docDateList << ["2014-09-23", 545];
        docDateList << ["2014-09-30", 412];
        docDateList << ["2014-10-07", 801];
        docDateList << ["2014-10-14", 788];
        docDateList << ["2014-10-21", 704];
        docDateList << ["2014-10-29", 752];
        docDateList << ["2014-11-04", 628];
        docDateList << ["2014-11-11", 521];
        docDateList << ["2014-11-18", 642];
        docDateList << ["2014-11-25", 612];
        docDateList << ["2014-12-02", 502];
        docDateList << ["2014-12-09", 506];
        docDateList << ["2014-12-16", 356];
        docDateList << ["2014-12-23", 834];
        docDateList << ["2014-12-30", 633];
        docDateList << ["2015-01-06", 635];
        docDateList << ["2015-01-13", 237];
        docDateList << ["2015-01-20", 313];
        docDateList << ["2015-01-27", 444];
        docDateList << ["2015-02-03", 523];
        docDateList << ["2015-02-10", 316];
        docDateList << ["2015-02-18", 418];
        docDateList << ["2015-02-24", 292];
        docDateList << ["2015-03-03", 261];
        docDateList << ["2015-03-10", 215];
        docDateList << ["2015-03-17", 392];
        docDateList << ["2015-03-24", 377];
        docDateList << ["2015-03-31", 562];
        docDateList << ["2015-04-07", 429];
        docDateList << ["2015-04-14", 389];
        docDateList << ["2015-04-22", 314];
        docDateList << ["2015-05-05", 493];
        docDateList << ["2015-05-12", 276];
        docDateList << ["2015-05-19", 305];
        docDateList << ["2015-05-26", 421];
        docDateList << ["2015-06-02", 355];
        docDateList << ["2015-06-09", 314];
        docDateList << ["2015-06-16", 2138];
        docDateList << ["2015-06-23", 1150];
        docDateList << ["2015-06-30", 1124];
        docDateList << ["2015-07-07", 836];
        docDateList << ["2015-07-14", 1298];
        docDateList << ["2015-07-21", 893];
        docDateList << ["2015-07-28", 1062];
        docDateList << ["2015-08-04", 947];
        docDateList << ["2015-08-11", 907];
        docDateList << ["2015-08-18", 840];
        docDateList << ["2015-08-25", 1057];
        docDateList << ["2015-09-01", 813];
        docDateList << ["2015-09-08", 849];
        docDateList << ["2015-09-15", 997];
        docDateList << ["2015-09-22", 855];
        docDateList << ["2015-09-29", 780];
        docDateList << ["2015-10-06", 1228];
        docDateList << ["2015-10-13", 1057];
        docDateList << ["2015-10-18", 1];
        docDateList << ["2015-10-20", 1105];
        docDateList << ["2015-10-27", 855];
        docDateList << ["2015-11-03", 927];
        docDateList << ["2015-11-10", 985];
        docDateList << ["2015-11-17", 803];
        docDateList << ["2015-11-24", 798];
        docDateList << ["2015-12-01", 1224];
        docDateList << ["2015-12-08", 941];
        docDateList << ["2015-12-15", 1049];
        docDateList << ["2015-12-22", 788];
        docDateList << ["2015-12-29", 903];
        docDateList << ["2016-01-05", 732];
        docDateList << ["2016-01-12", 547];
        docDateList << ["2016-01-19", 398];
        docDateList << ["2016-01-26", 750];
        docDateList << ["2016-02-02", 169];
        docDateList << ["2016-02-10", 718];
        docDateList << ["2016-02-16", 1069];
        
        return docDateList;
    }
    
}
