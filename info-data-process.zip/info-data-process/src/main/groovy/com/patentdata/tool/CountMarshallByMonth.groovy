package com.patentdata.tool

import com.patentdata.helper.PatDataHelper
import com.patentdata.helper.PatDataLogHelper
import com.patentdata.util.DateUtil
import com.patentdata.util.MongoUtil

public class CountMarshallByMonth {

    public static void main(args) {
        new CountMarshallByMonth().calc();
    }
    
    public calc() {
        
        def client = MongoUtil.connectByConfig("US");
        // marshall
        def marshallCol = client.getDB("PatentMarshallUS").getCollection("PatentMarshallUS");
        def client2x = MongoUtil.connect121DB();
        def oldInfoCol = client2x.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO");
        
        (1979..1979).each {year ->
            (6..6).each {month ->
                def beginDate = year + "" + sprintf('%02d', month) + "01";
                def doYearMon = year + "" + sprintf('%02d', month);
                def endDate = "";
                if (month == 12) {
                    endDate = (year+1) + "0101";
                } else {
                    endDate = year + "" + sprintf('%02d', month+1) + "01";
                }

                def queryMap = ["beginDate" : beginDate, "endDate" : endDate];
//                println "search range $queryMap"

                def dateBegin = DateUtil.parseDate(queryMap.beginDate);
                def dateEnd = DateUtil.parseDate(queryMap.endDate);

                def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];
                
                def cntPata = PatDataHelper.queryByDocDateRange(dateBegin, dateEnd-1, "US").size();
                
                def cntPataLog = PatDataLogHelper.queryByDocDateRange(dateBegin, dateEnd-1, "US").size();
                
                def marshallCnt = marshallCol.count(query);
                
                def oldCnt = oldInfoCol.count(query);
                
                println "YearMonth : " + doYearMon + ", oldMongoCnt : " + oldCnt + ", marshallCnt : " + marshallCnt + ", cntPata: " + cntPata + ", cntPataLog: " + cntPataLog;
                
            }
        }
        
    }
}
