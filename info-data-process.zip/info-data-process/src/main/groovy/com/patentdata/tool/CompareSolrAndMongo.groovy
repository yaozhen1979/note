package com.patentdata.tool

import groovy.json.JsonSlurper

import com.patentdata.util.DateUtil
import com.patentdata.util.MongoUtil

public class CompareSolrAndMongo {

    public static void main(String[] args) {
        new CompareSolrAndMongo().compare();
    }
    
    public void compare() {
        def client2x = MongoUtil.connect121DB();
        def oldInfoCol = client2x.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO");
        
        (2010..2010).each {year ->
            (1..12).each {month ->
                def beginDate = year + "" + sprintf('%02d', month) + "01";
                def doYearMon = year + "" + sprintf('%02d', month);
                def endDate = "";
                if (month == 12) {
                    endDate = (year+1) + "0101";
                } else {
                    endDate = year + "" + sprintf('%02d', month+1) + "01";
                }

                def queryMap = ["beginDate" : beginDate, "endDate" : endDate];

                def dateBegin = DateUtil.parseDate(queryMap.beginDate);
                def dateEnd = DateUtil.parseDate(queryMap.endDate);

                def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];
                
                def mongoDoYearmonCnt = oldInfoCol.count(query);
                
                // query solr By doYearmon
                def solrIssueDoYearmonCnt = solrIssue("doYearmon: ${doYearMon}").response.numFound;
                def solrPublicDoYearmonCnt = solrPublic("doYearmon: ${doYearMon}").response.numFound;
                
                def solrDoYearmonCnt = solrIssueDoYearmonCnt + solrPublicDoYearmonCnt;
                
                if (mongoDoYearmonCnt-solrDoYearmonCnt != 0) {
                    
                    // findDodateList
                    List<Date> doDateList = oldInfoCol.distinct("doDate", query);
                    
                    doDateList.each {doDate ->
                        String formatDateStr = doDate.format('yyyy-MM-dd');
                        
                        def doDateMongoCnt = oldInfoCol.count(["doDate" : doDate]);
                        
                        String solrQuery = "doDate: \"" + formatDateStr + "T00:00:00Z\"";
                        
                        def solrIssueDodateCnt = solrIssue(solrQuery).response.numFound;
                        def solrPublicDodateCnt = solrPublic(solrQuery).response.numFound;
                        
                        def solrDodateCnt = solrIssueDodateCnt + solrPublicDodateCnt;
                        
                        if (doDateMongoCnt - solrDodateCnt != 0) {
                            println "doDate: ${formatDateStr}, doDateMongoCnt: $doDateMongoCnt, doDateSolrCnt: $solrDodateCnt , Not Match!"
                            
                            def oldPatNoList = oldInfoCol.find(["doDate" : doDate],[patentNumber:1, stat:1]);
                            
                            def diffByDate = doDateMongoCnt - solrDodateCnt;
                            
                            def cnt = 0;
                            try {
                                oldPatNoList.each {
                                    def stat = it."stat";
                                    String patNo = it."patentNumber";
                                    
                                    def solrc;
                                    if (stat == 1) {
                                        solrc = solrPublic("patentNumber: ${patNo}").response.numFound;
                                    }
                                    
                                    if (stat == 2) {
                                        solrc = solrIssue("patentNumber: ${patNo}").response.numFound;
                                    }
                                    
                                    if(solrc == 0) {
                                        cnt++;
                                        println "doDate : " + formatDateStr + ", patNo: " + patNo + ", stat:" + stat;
                                    }
                                    
                                    if (cnt - diffByDate == 0) {
                                        throw new Exception("break");
                                    }
    
                                } // end of loop oldPatNoList
                            } catch (Exception ex) {
                                // break of loop
                            }
                        } // end of if doDateMongoCnt - solrDodateCnt != 0
                        
                    } // end of loop doDateList
                }
                
            }
        }
        
        println "Compare finish~!"
    }
    
    public Object solrIssue(String querystr) {
        
        String url = "http://10.60.90.163/solr/usIssue"
        return solr(querystr, url);
    }
    
    public Object solrPublic(String querystr) {
        String url = "http://10.60.90.163/solr/usPublication"
        return solr(querystr, url);
    }
    
    public Object solr(querystr, url) {
        def query = java.net.URLEncoder.encode(querystr);
        def xml = (url +"/select?q=${query}&wt=json&indent=true&rows=0").toURL().text
        def jsonSlurper = new JsonSlurper();
        def object = jsonSlurper.parseText(xml)
        return object;
    }
    
}
