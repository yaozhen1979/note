package com.patentdata.tool

import java.text.SimpleDateFormat

import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.patentdata.util.DateUtil
import com.patentdata.util.MongoUtil

/**
 * 比較 121 mongodb US 跟 101 marashalldb US 差異
 * @author mikelin
 *
 */
public class CompareTwoMongoDB {
    
    File out = new File("logs/CompareTwoMongoDB.txt");
    def ln = System.getProperty('line.separator');

    public void compare() {

        def client2x = MongoUtil.connect121DB();
        def oldInfoCol = client2x.getDB("PatentRawUSPTO").getCollection("PatentRawUSPTO");

        def client = MongoUtil.connectByConfig("US");
        // marshall
        def marshallCol = client.getDB("PatentRawUSPTO").getCollection("PatentRawUSPTO");

        (2015..2015).each {year ->
            (1..12).each {month ->
                
                def beginDate = year + "" + sprintf('%02d', month) + "01";
                
                def endDate = "";
                if (month == 12) {
                    endDate = (year+1) + "0101";
                } else {
                    endDate = year + "" + sprintf('%02d', month+1) + "01";
                }

                def queryMap = ["beginDate" : beginDate, "endDate" : endDate];
                println "search range $queryMap"

                def dateBegin = DateUtil.parseDate(queryMap.beginDate);
                def dateEnd = DateUtil.parseDate(queryMap.endDate);

                def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];

                List<Date> doDateList = oldInfoCol.distinct("doDate", query);

                doDateList.each {doDate ->
                    
                    def oldCnt = oldInfoCol.count(["doDate" : doDate]);
                    def marshallCnt = marshallCol.count(["doDate" : doDate]);

                    def diffByDate = oldCnt - marshallCnt;
                    
                    if (diffByDate != 0) {
                        println "doDate: " + doDate.getDateString() + ", old count: " + oldCnt + ", marshallCnt : " + marshallCnt + ", diff : " + diffByDate;
                        def oldPatNoList = oldInfoCol.find(["doDate" : doDate],[patentNumber:1]);

                        def cnt = 0;
                        try {
                            oldPatNoList.each {

                                it."patentNumber".replaceAll(/US0{2,4}([A-Z0-9]*)/) {full , no ->
                                    
                                    if(marshallCol.count(["_id" : no]) == 0) {
                                        cnt++;
                                        println "doDate : " + doDate.getDateString() + ", patNo: " + no;
                                        out << doDate.getDateString() + ";" + no << ln;
                                    }
                                }
                                
                                if (cnt - diffByDate == 0) {
                                    throw new Exception("break");
                                }

                            } // end of loop oldPatNoList
                        } catch (Exception ex) {
                            // break of loop
                        }

                    } // end of diffByDate != 0
                    
                } // end of loop doDateList
                
            } // end of loop month
            
        }  // end of loop year

    }

    public static void main(args) {
        new CompareTwoMongoDB().compare();
    }

}
