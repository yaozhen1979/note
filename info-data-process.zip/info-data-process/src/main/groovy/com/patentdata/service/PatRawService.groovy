package com.patentdata.service

import com.patentdata.common.Constants
import com.patentdata.helper.PatRawHelper
import com.patentdata.model.PatRawDocdb
import com.patentdata.model.PatRawEp
import com.patentdata.model.PatRawJp
import com.patentdata.model.PatRawUs
import com.patentdata.model.PatRawWo

class PatRawService extends BaseService {

    public void saveOrUpdatePatRawUs(PatRawUs patRawUs) {
        
        PatRawUs oldPatRawUs = PatRawHelper.findByPK(PatRawUs.class, patRawUs.rawId);
        
        if (oldPatRawUs != null) {
            patRawUs.createDate = oldPatRawUs.createDate;
            update(patRawUs);
        } else {
            save(patRawUs);
        }
        
    }

    public void saveOrUpdatePatRawJp(PatRawJp patRawJp) {
        
        PatRawJp oldPatRawJp = PatRawHelper.findByPK(PatRawJp.class, patRawJp.rawId);
        
        if (oldPatRawJp != null) {
            patRawJp.createDate = oldPatRawJp.createDate;
            update(patRawJp);
        } else {
            save(patRawJp);
        }
        
    }
    
    public void saveOrUpdatePatRawWo(PatRawWo patRawWo) {
        
        PatRawWo oldPatRawWo = PatRawHelper.findByPK(PatRawWo.class, patRawWo.rawId);
        
        if (oldPatRawWo != null) {
            patRawWo.createDate = oldPatRawWo.createDate;
            update(patRawWo);
        } else {
            save(patRawWo);
        }
        
    }

    /**
     * 重複資料, 單純更新即可, 
     * 新增資料, 要確認是否為最新的一筆.
     * 
     * NOTE: 該method有副作用, 因為有回傳值PatRawDocdb, y主要是為了取得[lastestFlag]來判斷是否要執行[PatRef]有關的table操作.
     * 
     * @param patRawDocdb
     */
    public PatRawDocdb saveOrUpdatePatRawDocdb(PatRawDocdb patRawDocdb) {
        
        PatRawDocdb oldPatRawDocdb = PatRawHelper.findByRawId(patRawDocdb.rawId, patRawDocdb.patId);
        
        // replicated data process
        if (oldPatRawDocdb != null) {
            patRawDocdb.lastestFlag = oldPatRawDocdb.lastestFlag
            patRawDocdb.createDate = oldPatRawDocdb.createDate;
            merge(patRawDocdb);
        } else {
            
            // new data process => 查詢是否已有以存在的資料
            List<PatRawDocdb> patRawDocdbList = PatRawHelper.queryByPatId(patRawDocdb.patId)
            
            /*
             * patRawDocdbList.size() = 0, 表示為該筆[docdb.pat_id]為第一次新增
             * patRawDocdbList.size() > 0, 為Amend Data
             */
            if (patRawDocdbList.size() > 0) {
                
                // 依資料[lastExchangeDate]進行排序
                Date lastSortData = patRawDocdbList.sort {a, b -> a.lastExchangeDate.compareTo(b.lastExchangeDate)}[-1].lastExchangeDate;
                
                /*
                 * 如新增資料的[lastExchangeDate]大於原有資料的[lastExchangeDate],
                 * 則更新全部原有資料中的[lastestFlag = 0]
                 * 新增資料[lastestFlag = 1]
                 * 
                 */
                if (patRawDocdb.lastExchangeDate.compareTo(lastSortData) > 0) {
                    patRawDocdb.lastestFlag = Constants.DOCDB_LASTEST_FLAG_YES
                    for (PatRawDocdb originData : patRawDocdbList) {
                        originData.lastestFlag = Constants.DOCDB_LASTEST_FLAG_NO;
                        update(originData);
                    }
                } else {
                    patRawDocdb.lastestFlag = Constants.DOCDB_LASTEST_FLAG_NO;
                }
                
            } else {
                patRawDocdb.lastestFlag = Constants.DOCDB_LASTEST_FLAG_YES;
            }   // end if (patRawDocdbList.size() > 1)
            
            save(patRawDocdb);
            
        }   // end if (oldPatRawDocdb != null) 
        
        return patRawDocdb;
        
    }  // end saveOrUpdatePatRawDocdb
    
    public void saveOrUpdatePatRawEp(PatRawEp patRawEp) {
        
        PatRawEp oldPatRawEp = PatRawHelper.findByPK(PatRawEp.class, patRawEp.rawId);
        
        if (oldPatRawEp != null) {
            patRawEp.createDate = oldPatRawEp.createDate;
            update(patRawEp);
        } else {
            save(patRawEp);
        }
        
    }
}
