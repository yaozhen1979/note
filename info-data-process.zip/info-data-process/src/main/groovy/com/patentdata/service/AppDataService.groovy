package com.patentdata.service;

import com.patentdata.helper.AppDataHelper;
import com.patentdata.model.AppData;

public class AppDataService extends BaseService {

    public void saveOrUpdateAppData(AppData appData) {

        if (log.isDebugEnabled()) {
            log.debug("appId = " + appData.getAppId());
        }
        
        AppData oldAppData = AppDataHelper.findByAppId(appData.getAppId(), appData.country);
        
        if (oldAppData != null) {
            // update
            appData.setCreateDate(oldAppData.getCreateDate());
            merge(appData);
        } else {
            // insert
            save(appData);
        }
        
    }   // end saveOrUpdateAppData
    
}   // end AppDataService
