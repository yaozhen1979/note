package com.patentdata.service

import java.util.Date;

import com.patentdata.helper.PatDataMemoHelper
import com.patentdata.helper.SequenceHelper
import com.patentdata.model.PatData
import com.patentdata.model.PatDataMemo
import com.patentdata.model.SourceData

class PatDataMemoService extends BaseService {

    public void savePatDataMemo(String patId, String sourceId, int memoType){
        
        if(!PatDataMemoHelper.findByCondition(patId, memoType)){
            
            PatDataMemo patDataMemo = new PatDataMemo(
                    SequenceHelper.getSeqDataMemoIdNextVal(),
                    new PatData(),
                    new SourceData(),
                    memoType,
                    new Date()
                    )
            
            patDataMemo.sourceData.sourceId = sourceId
            patDataMemo.patData.patId = patId
            persist(patDataMemo);
        }
    }


    public void savePatDataMemo(PatDataMemo patDataMemo){

        if(!!patDataMemo && !PatDataMemoHelper.findByCondition(patDataMemo.patData.patId, patDataMemo.memoType)){
            patDataMemo.memoId = SequenceHelper.getSeqDataMemoIdNextVal()
            persist(patDataMemo);
        }
    }
}
