package com.patentdata.service

import com.patentdata.helper.PatClsCpcHelper
import com.patentdata.helper.PatClsCsetHelper
import com.patentdata.helper.PatClsEclaHelper
import com.patentdata.helper.PatClsFiHelper
import com.patentdata.helper.PatClsFieldOfSearchHelper
import com.patentdata.helper.PatClsFtermHelper
import com.patentdata.helper.PatClsIpcHelper
import com.patentdata.helper.PatClsLocHelper
import com.patentdata.helper.PatClsUspcHelper
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsEcla
import com.patentdata.model.PatClsFi
import com.patentdata.model.PatClsFieldOfSearch
import com.patentdata.model.PatClsFterm
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsLoc
import com.patentdata.model.PatClsUspc

/**
 * @author mikelin
 *
 */
class PatClsService extends BaseService {

    /**
     * @param patClsFiList
     */
    public void saveOrUpdatePatClsFi(List<PatClsFi> patClsFiList) {
        
        // log.debug("patClsCpcList size = " + patClsCpcList.size());
        
        for (PatClsFi patClsFi : patClsFiList) {
            PatClsFi oldPatClsFi = PatClsFiHelper.findByPK(PatClsFi.class, patClsFi.getId());
            if (oldPatClsFi != null) {
                patClsFi.createDate = oldPatClsFi.createDate
                merge(patClsFi);
            } else {
                save(patClsFi);
            }
        }
    }

    /**
     * @param patClsFtermList
     */
    public void saveOrUpdatePatClsFterm(List<PatClsFterm> patClsFtermList) {
        
        // log.debug("patClsCpcList size = " + patClsCpcList.size());
        
        for (PatClsFterm patClsFterm : patClsFtermList) {
            PatClsFterm oldPatClsFterm = PatClsFtermHelper.findByPK(PatClsFterm.class, patClsFterm.getId());
            if (oldPatClsFterm != null) {
                patClsFterm.createDate = oldPatClsFterm.createDate
                merge(patClsFterm);
            } else {
                save(patClsFterm);
            }
        }
    }

    /**
     * @param patClsCpcList
     */
    public void saveOrUpdatePatClsCpc(List<PatClsCpc> patClsCpcList) {
        
        // log.debug("patClsCpcList size = " + patClsCpcList.size());
        
        for (PatClsCpc patClsCpc : patClsCpcList) {
            PatClsCpc oldPatClsCpc = PatClsCpcHelper.findByPK(patClsCpc.getId());
            if (oldPatClsCpc != null) {
                patClsCpc.createDate = oldPatClsCpc.createDate
                merge(patClsCpc);
            } else {
                save(patClsCpc);
            }
        }
        
    }

    /**
     * @param patClsIpcList
     */
    public void saveOrUpdatePatClsIpc(List<PatClsIpc> patClsIpcList) {
        
        // log.debug("patClsIpcList size = " + patClsIpcList.size());
        
        for (PatClsIpc patClsIpc : patClsIpcList) {
            PatClsIpc oldPatClsIpc = PatClsIpcHelper.findByPK(patClsIpc.getId());
            if (oldPatClsIpc != null) {
                patClsIpc.createDate = oldPatClsIpc.createDate
                merge(patClsIpc);
            } else {
                save(patClsIpc);
            }
        }
        
    }
    
    
    /**
     * @param patClsLocList
     */
    public void saveOrUpdatePatClsLoc(List<PatClsLoc> patClsLocList) {
        
        // log.debug("patClsLocList size = " + patClsLocList.size());
        
        for (PatClsLoc patClsLoc : patClsLocList) {
            PatClsLoc oldPatClsLoc = PatClsLocHelper.findByPK(PatClsLoc.class, patClsLoc.getId());
            if (oldPatClsLoc != null) {
                patClsLoc.createDate = oldPatClsLoc.createDate
                merge(patClsLoc);
            } else {
                save(patClsLoc);
            }
        }
        
    }
    
    /**
     * @param patClsUspcList
     */
    public void saveOrUpdatePatClsUspc(List<PatClsUspc> patClsUspcList) {
        
        // log.debug("patClsUspcList size = " + patClsUspcList.size());
        
        for (PatClsUspc patClsUspc : patClsUspcList) {
            PatClsUspc oldPatClsUspc = PatClsUspcHelper.findByPK(patClsUspc.getId());
            if (oldPatClsUspc != null) {
                patClsUspc.createDate = oldPatClsUspc.createDate
                merge(patClsUspc);
            } else {
                save(patClsUspc);
            }
        }
        
    }   // end saveOrUpdatePatClsUspc
    
    /**
     * @param patClsCsetList
     */
    public void saveOrUpdatePatClsCset(List<PatClsCset> patClsCsetList) {
        
        // log.debug("patClsCsetList size = " + patClsCsetList.size());
        
        for (PatClsCset patClsCset : patClsCsetList) {
            PatClsCset oldPatClsCset = PatClsCsetHelper.findByPK(patClsCset.getId());
            if (oldPatClsCset != null) {
                patClsCset.createDate = oldPatClsCset.createDate
                merge(patClsCset);
            } else {
                save(patClsCset);
            }
        }
        
    }   // end saveOrUpdatePatClsCset
    
    /**
     * @param patClsFieldOfSearchList
     */
    public void saveOrUpdatePatClsFieldOfSearch(List<PatClsFieldOfSearch> patClsFieldOfSearchList) {
        
        // log.debug("patClsFieldOfSearchList size = " + patClsFieldOfSearchList.size());
        
        for (PatClsFieldOfSearch patClsFieldOfSearch : patClsFieldOfSearchList) {
            PatClsFieldOfSearch oldPatClsFieldOfSearch = PatClsFieldOfSearchHelper.findByPK(PatClsFieldOfSearch.class, patClsFieldOfSearch.getId());
            if (oldPatClsFieldOfSearch != null) {
                oldPatClsFieldOfSearch.createDate = oldPatClsFieldOfSearch.createDate
                merge(patClsFieldOfSearch);
            } else {
                save(patClsFieldOfSearch);
            }
        }
        
    }   // end saveOrUpdatePatClsFieldOfSearch

    /**
     * @param patClsEcla
     */
    public void saveOrUpdatePatClsEcla(List<PatClsEcla> patClsEclaList) {
        
        for (PatClsEcla patClsEcla : patClsEclaList) {
            PatClsEcla oldPatClsEcla = PatClsEclaHelper.findByPK(PatClsEcla.class, patClsEcla.getId());
            if (oldPatClsEcla != null) {
                patClsEcla.createDate = oldPatClsEcla.createDate
                merge(patClsEcla);
            } else {
                save(patClsEcla);
            }
        }
        
    }
    
}
