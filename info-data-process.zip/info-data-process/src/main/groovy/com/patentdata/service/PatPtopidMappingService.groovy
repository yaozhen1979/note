package com.patentdata.service

import com.patentdata.helper.PatPtopidMappingHelper
import com.patentdata.helper.SequenceHelper
import com.patentdata.model.PatPtopidMapping

class PatPtopidMappingService extends BaseService {

    public void saveOrUpdatePatPtopidMapping(PatPtopidMapping patPtopidMapping) {
        
        List<PatPtopidMapping> oldPatPtopidMappingList = PatPtopidMappingHelper.queryByCondition(patPtopidMapping.patData.patId, patPtopidMapping.ptopidId);
        
        if (log.isDebugEnabled()) {
            log.debug("oldPatPtopidMappingList size " + oldPatPtopidMappingList.size());
        }
        // 已存在的 mapping 資料不存
        if (oldPatPtopidMappingList.size() == 0) {
            patPtopidMapping.ptopidMappingId = SequenceHelper.getSeqPtopidMappingIdNextVal();
            save(patPtopidMapping);
        }
        
        // TODO: 各個PTO狀況是否相同
        if (oldPatPtopidMappingList.size() > 1) {
            throw new Exception("oldPatPtopidMappingList size larger than 1");
        }
        
    }   // end saveOrUpdatePatPtopidMapping
}
