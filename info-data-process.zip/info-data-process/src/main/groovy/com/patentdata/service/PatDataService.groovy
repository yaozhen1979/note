package com.patentdata.service;

import org.hibernate.Query
import org.hibernate.Session

import com.patentdata.common.Constants
import com.patentdata.helper.PatDataBriefHelper
import com.patentdata.helper.PatDataClaimsHelper
import com.patentdata.helper.PatDataDescHelper
import com.patentdata.helper.PatDataHelper
import com.patentdata.helper.PatDataTitleHelper
import com.patentdata.helper.PatEventRecordHelper
import com.patentdata.helper.SequenceHelper
import com.patentdata.model.PatData
import com.patentdata.model.PatDataAmend
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatEventRecord
import com.patentdata.model.PatEventRecordChangeLog
import com.patentdata.model.SourceData
import com.patentdata.util.HibernateUtil

public class PatDataService extends BaseService {
    /**
     * 
     * @param patData
     */
    public void saveOrUpdatePatData(PatData patData) {
        
        if (log.isDebugEnabled()) {
            log.debug("patId = " + patData.getPatId());
        }
        
        Integer eventType = null;
        
        PatData oldPatData = PatDataHelper.findByPK(PatData.class, patData.patId)
        
        if (oldPatData != null) {
            patData.createDate = oldPatData.createDate
            // docdb 如果已經刷進來,familyId, docdbFlag就以舊的為主
            if (oldPatData.docdbFlag == Constants.DOCDB_FLAG_YES && oldPatData.docdbFlag != patData.docdbFlag) {
                patData.familyId = oldPatData.familyId;
                patData.docdbFlag = oldPatData.docdbFlag;
            }
            
            eventType = Constants.EVENT_TYPE_UPDATE;
            merge(patData);
        } else {
            save(patData);
            eventType = Constants.EVENT_TYPE_CREATE;
        }
        
        // event record save...
        PatEventRecord patEventRecord = new PatEventRecord();
        patEventRecord.recordId = SequenceHelper.getSeqEventRecordIdNextVal();
        patEventRecord.patData = patData;
        SourceData sourceData = new SourceData();
        sourceData.sourceId = patData.defaultSourceId;
        patEventRecord.sourceData = sourceData;
        patEventRecord.eventType = eventType;
        patEventRecord.remark = '';
        patEventRecord.eventDate = new Date();
        
        if (eventType == Constants.EVENT_TYPE_UPDATE) {
            // hard code => patEventRecord.patItem = 2...
            if (!!PatEventRecordHelper.findByPatItem(patData.patId)) {
                patEventRecord.patItem = PatEventRecordHelper.findByPatItem(patData.patId) + 1;
            } else {
                patEventRecord.patItem = 2;
            }
            
        } else {
            patEventRecord.patItem = 1;
        }
        
        save(patEventRecord);
    }

    public void saveOrUpdatePatAmendJP (List<PatDataAmend> patDataAmendList) {
        for (PatDataAmend patDataAmend : patDataAmendList) {
            removeAmendData(patDataAmend.getId().getPatId(), patDataAmend.getId().getSourceId(), patDataAmend.getId().getAmendDate(), patDataAmend.getId().getItem())
            PatDataAmend oldPatDataDesc = PatDataDescHelper.findByPK(PatDataAmend.class, patDataAmend.getId());
            save(patDataAmend);
        }
    }

    private void removeAmendData(String patId, String sourceId, Date amendDate, int item) {
        Session session = HibernateUtil.currentSession();
        Query deleteQuery = session.createSQLQuery("delete from pat_data_amend where pat_id = :patId and source_id = :sourceId and amend_date = :amendDate and item = :item");
        deleteQuery.setString("patId", patId);
        deleteQuery.setString("sourceId", sourceId);
        deleteQuery.setDate("amendDate", amendDate);
        deleteQuery.setInteger("item", item);
        if (!!patId && !!sourceId && !!amendDate && !!item) {
            int deleteCount = deleteQuery.executeUpdate();
            log.debug("PatDataAmend deleteCount = ${deleteCount}");
            session.flush();
        } else {
            log.debug("patId, sourceId, amendDate ir item is empty");
        }
    }

    /**
     *
     * @param patData
     */
    public void saveOrUpdatePatDataJP(PatData patData) {
        
        if (log.isDebugEnabled()) {
            log.debug("patId = " + patData.getPatId());
        }
        PatData oldPatData = PatDataHelper.findByPK(PatData.class, patData.patId)
        Integer eventType = null;
        if (oldPatData != null) {
            patData.createDate = oldPatData.createDate
            if (oldPatData.docdbFlag == com.patentdata.common.Constants.DOCDB_FLAG_YES) {
                patData.familyId = oldPatData.familyId;
                patData.docdbFlag = oldPatData.docdbFlag;
            }
            // TODO: event record
            merge(patData)
            eventType = com.patentdata.common.Constants.EVENT_TYPE_UPDATE;
        } else {
            save(patData)
            eventType = com.patentdata.common.Constants.EVENT_TYPE_CREATE;
        }
        // event record save...
        PatEventRecord patEventRecord = new PatEventRecord();
        patEventRecord.recordId = SequenceHelper.getSeqEventRecordIdNextVal();
        patEventRecord.patData = patData;
        SourceData sourceData = new SourceData();
        sourceData.sourceId = com.patentdata.common.Constants.SOURCE_ID_JP_XXX;
        patEventRecord.sourceData = sourceData;
        patEventRecord.eventType = eventType;
        patEventRecord.remark = '';
        patEventRecord.eventDate = new Date();
        if (eventType == com.patentdata.common.Constants.EVENT_TYPE_UPDATE) {
            // hard code => patEventRecord.patItem = 2...
            if (!!PatEventRecordHelper.findByPatItem(patData.patId)) {
                patEventRecord.patItem = PatEventRecordHelper.findByPatItem(patData.patId) + 1;
            } else {
                patEventRecord.patItem = 2;
            }
        } else {
            patEventRecord.patItem = 1;
        }
        save(patEventRecord);
    }

    /**
     *
     * @param patDataTitleList
     */
    public void saveOrUpdatePatDataTitle(List<PatDataTitle> patDataTitleList) {
        
        // log.debug("patDataTitleList size = " + patDataTitleList.size());
        
        for (PatDataTitle patDataTitle : patDataTitleList) {
            PatDataTitle oldPatDataTitle = PatDataTitleHelper.findByPK(patDataTitle.getId())
            if (oldPatDataTitle != null) {
                patDataTitle.createDate = oldPatDataTitle.createDate
                merge(patDataTitle)
            } else {
                save(patDataTitle)
            }
        }
        
    }   // end saveOrUpdatePatDataTitle
    
    /**
     *
     * @param patDataBriefList
     */
    public void saveOrUpdatePatDataBrief(List<PatDataBrief> patDataBriefList) {
        
        // log.debug("patDataBriefList size = " + patDataBriefList.size());
        
        for (PatDataBrief patDataBrief : patDataBriefList) {
            PatDataBrief oldPatDataBrief = PatDataBriefHelper.findByPK(patDataBrief.getId())
            if (oldPatDataBrief != null) {
                patDataBrief.createDate = oldPatDataBrief.createDate
                merge(patDataBrief)
            } else {
                save(patDataBrief)
            }
        }
        
    }   // end saveOrUpdatePatDataBrief
    
    /**
     * 
     * @param patDataBriefList
     */
    public void saveOrUpdatePatDataClaims(List<PatDataClaims> patDataClaimsList) {
        
        // log.debug("patDataClaimsList size = " + patDataClaimsList.size());
        
        for (PatDataClaims patDataClaims : patDataClaimsList) {
            PatDataClaims oldPatDataClaims = PatDataClaimsHelper.findByPK(PatDataClaims.class, patDataClaims.getId());
            if (oldPatDataClaims != null) {
                patDataClaims.createDate = oldPatDataClaims.createDate
                merge(patDataClaims);
            } else {
                save(patDataClaims);
            }
        }
        
    }   // end saveOrUpdatePatDataClaims
    
    /**
     * 
     * @param patDataDescList
     */
    public void saveOrUpdatePatDataDesc(List<PatDataDesc> patDataDescList) {
        
        // log.debug("patDataDescList size = " + patDataDescList.size());
        
        for (PatDataDesc patDataDesc : patDataDescList) {
            PatDataDesc oldPatDataDesc = PatDataDescHelper.findByPK(PatDataDesc.class, patDataDesc.getId());
            if (oldPatDataDesc != null) {
                patDataDesc.createDate = oldPatDataDesc.createDate
                merge(patDataDesc);
            } else {
                save(patDataDesc);
            }
        }
        
    }   // end saveOrUpdatePatDataDesc
    
    /**
     * 整合處理 PatDataTitle, PatDataBrief
     * 
     * @param patDataTitleList
     * @param patDataBriefList
     */
    public void saveOrUpdatePatDataInfo(List<PatDataTitle> patDataTitleList, List<PatDataBrief> patDataBriefList) {
        
        if (patDataTitleList != null) {
            saveOrUpdatePatDataTitle(patDataTitleList);
        }
        
        if (patDataBriefList != null) {
            saveOrUpdatePatDataBrief(patDataBriefList);
        }
        
    }   // end saveOrUpdatePatDataInfo
    
    /**
     * For DOCDB PatData
     * 
     * @param patData
     */
    public void saveOrUpdatePatDataDOCDB(PatData patData, int lastestFlag) {
        
        log.debug("patId = " + patData.getPatId());
        
        Integer eventType = null;
        
        PatData oldPatData = PatDataHelper.findByPatId(patData.patId)
        
        if (oldPatData != null) {
            
            if (patData.deleteFlag == Constants.DELETE_FLAG_YES) {
                //
                log.debug("pat_id = ${patData.patId}, deleteFlag = true");
                oldPatData.familyId = patData.familyId;
                oldPatData.lastUpdDate = new Date();
                oldPatData.deleteFlag = Constants.DELETE_FLAG_YES;
                oldPatData.withdrawFlag = Constants.WITHDRAW_FLAG_TRUE;
                merge(oldPatData)
            } else {
                /*
                 *  如果可以patId查出PatData, 且default_sourceId != SOURCE_ID_DOCDB_BRIEF,
                 *  即代表即有PTO已先完成insert data動作, 所以只要更新familyId, docdbFlag, lastUpDate.
                 *
                 *  否則, 就只是單純更新Docdb的資料而已.
                 *
                 */
                if (oldPatData.defaultSourceId != Constants.SOURCE_ID_DOCDB_BRIEF) {
                    oldPatData.familyId = patData.familyId;
                    oldPatData.docdbFlag = Constants.DOCDB_FLAG_YES;
                    oldPatData.lastUpdDate = new Date();
                    merge(oldPatData)
                } else {
                    patData.createDate = oldPatData.createDate
                    merge(patData)
                }
            
            }   // end if (patData.deleteFlag == Constants.DELETE_FLAG_YES)
            
            eventType = Constants.EVENT_TYPE_UPDATE;
            
        } else {
            save(patData)
            eventType = Constants.EVENT_TYPE_CREATE;
        }
        
        // event record save... 
        PatEventRecord patEventRecord = new PatEventRecord();
        patEventRecord.recordId = SequenceHelper.getSeqEventRecordIdNextVal();
        patEventRecord.patData = patData;
        SourceData sourceData = new SourceData();
        sourceData.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patEventRecord.sourceData = sourceData;
        patEventRecord.eventType = eventType;
        patEventRecord.remark = '';
        patEventRecord.eventDate = new Date();
        
        if (eventType == Constants.EVENT_TYPE_UPDATE) {
            // hard code => patEventRecord.patItem = 2... 
            if (!!PatEventRecordHelper.findByPatItem(patData.patId)) {
                patEventRecord.patItem = PatEventRecordHelper.findByPatItem(patData.patId) + 1;
            } else {
                patEventRecord.patItem = 2;
            }
            
        } else {
            patEventRecord.patItem = 1;
        }
        
        save(patEventRecord);
        //
        if (lastestFlag == Constants.DOCDB_LASTEST_FLAG_YES 
            && eventType == Constants.EVENT_TYPE_UPDATE 
            && oldPatData.familyId != patData.familyId) {
            
            log.info("patData.patId = ${patData.patId}, familyId amend..., ${oldPatData.familyId} to ${patData.familyId}");
            //
            PatEventRecordChangeLog patEventRecordChangeLog = new PatEventRecordChangeLog();
            patEventRecordChangeLog.patEventRecord = patEventRecord;
            patEventRecordChangeLog.logId = SequenceHelper.getSeqChangeLogIdNextVal();
            patEventRecordChangeLog.changeColName = "familyId";
            patEventRecordChangeLog.curVal = oldPatData.familyId;
            patEventRecordChangeLog.changeVal = patData.familyId;
            patEventRecordChangeLog.createDate = new Date();
            save(patEventRecordChangeLog);
        }
    }   // end saveOrUpdatePatDataDOCDB
    
}
