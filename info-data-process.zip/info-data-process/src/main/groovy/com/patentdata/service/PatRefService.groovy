package com.patentdata.service;

import org.hibernate.Query
import org.hibernate.Session

import com.patentdata.helper.PatRefPctHelper
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedCls
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefCitedNplCls
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefRelatedChild
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.util.HibernateUtil

public class PatRefService extends BaseService {

    /**
     * 專利資料引證檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證資料,若資料源有更新,則pat_ref_cited_cls,pat_ref_cited全部刪除再重新新增
     * @param patRefCitedList
     * @param patId
     * @param sourceId
     */
    public void savePatRefCited(List<PatRefCited> patRefCitedList, String patId, String sourceId) {

        // log.debug("current patRefCitedList size = " + patRefCitedList.size());

        removeRefData("PAT_REF_CITED", patId, sourceId);

        for (PatRefCited patRefCited : patRefCitedList) {
            // log.debug "patRefCited = ${patRefCited}"
            persist(patRefCited);
        }

    }

    /**
     * 專利資料引證分類檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證分類資料,若資料源有更新,則全部刪除再重新新增
     * @param patRefCitedClsList
     * @param patId
     * @param sourceId
     */
    public void savePatRefCitedCls(List<PatRefCitedCls> patRefCitedClsList, String patId, String sourceId) {

        // log.debug("current patRefCitedClsList size = " + patRefCitedClsList.size());

        removeRefData("PAT_REF_CITED_CLS", patId, sourceId);

        for (PatRefCitedCls patRefCitedCls : patRefCitedClsList) {
            persist(patRefCitedCls);
        }

    }

    /**
     * 因為有FK的問題，所以寫入跟新增要照以下順序
     * 移除順序 1.PatRefCitedCls 2.PatRefCited
     * 寫入順序 1.PatRefCited 2.PatRefCitedCls
     * @param patRefCitedList
     * @param patRefCitedClsList
     * @param patId
     * @param sourceId
     */
    public void savePatRefCitedAndCls(List<PatRefCited> patRefCitedList, List<PatRefCitedCls> patRefCitedClsList, String patId, String sourceId) {

        removeRefData("PAT_REF_CITED_CLS", patId, sourceId);
        removeRefData("PAT_REF_CITED", patId, sourceId);

        for (PatRefCited patRefCited : patRefCitedList) {
            persist(patRefCited);
        }

        for (PatRefCitedCls patRefCitedCls : patRefCitedClsList) {
            persist(patRefCitedCls);
        }

    }

    /**
     * 非專利資料引證檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證資料,若資料源有更新,則pat_ref_cited_npl_cls,pat_ref_cited_npl全部刪除再重新新
     * @param patRefCitedNplList
     * @param patId
     * @param sourceId
     */
    public void savePatRefCitedNpl(List<PatRefCitedNpl> patRefCitedNplList, String patId, String sourceId) {

        // log.debug("current patRefCitedNplList size = " + patRefCitedNplList.size());

        removeRefData("PAT_REF_CITED_NPL", patId, sourceId);

        for (PatRefCitedNpl patRefCitedNpl : patRefCitedNplList) {
            // log.debug "patRefCitedNpl = ${patRefCitedNpl}"
            persist(patRefCitedNpl);
        }

    }

    /**
     * 非專利資料引證分類檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證分類資料,若資料源有更新,則全部刪除再重新新增
     * @param patRefCitedNplClsList
     * @param patId
     * @param sourceId
     */
    public void savePatRefCitedNplCls(List<PatRefCitedNplCls> patRefCitedNplClsList, String patId, String sourceId) {

        // log.debug("current patRefCitedNplClsList size = " + patRefCitedNplClsList.size());

        removeRefData("PAT_REF_CITED_NPL_CLS", patId, sourceId);

        for (PatRefCitedNplCls patRefCitedNplCls : patRefCitedNplClsList) {
            persist(patRefCitedNplCls);
        }

    }

    /**
     * 專利資料國外優先權資料,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份國外優先權,若資料源有更新,則pat_ref_priority全部刪除再重新新增
     * @param patRefPriorityList
     * @param patId
     * @param sourceId
     */
    public void savePatRefPriority(List<PatRefPriority> patRefPriorityList, String patId, String sourceId) {

        // log.debug("current patRefPriorityList size = " + patRefPriorityList.size());

        removeRefData("PAT_REF_PRIORITY", patId, sourceId);

        for (PatRefPriority patRefPriority : patRefPriorityList) {
            persist(patRefPriority);
        }

    }

    public void savePatRefRelatedParent(List<PatRefRelatedParent> patRefRelatedParentList, String patId, String sourceId) {

        // log.debug("current patRefPriorityList size = " + patRefPriorityList.size());

        removeRefData("pat_ref_related_parent", patId, sourceId);

        for (PatRefRelatedParent patRefRelatedParent : patRefRelatedParentList) {
            persist(patRefRelatedParent);
        }

    }

    /**
     * @param patRefRelatedParentList
     * @param patRefRelatedChildList
     * @param patId
     * @param sourceId
     */
    public void savePatRefRelatedParentChild(List<PatRefRelatedParent> patRefRelatedParentList
            , List<PatRefRelatedChild> patRefRelatedChildList, String patId, String sourceId) {

        log.debug("current patRefRelatedParentList size = " + patRefRelatedParentList.size());
        log.debug("current patRefRelatedChildList size = " + patRefRelatedChildList.size());

        removeRefData("pat_ref_related_child", patId, sourceId);
        removeRefData("pat_ref_related_parent", patId, sourceId);

        for (PatRefRelatedParent patRefRelatedParent : patRefRelatedParentList) {
            persist(patRefRelatedParent);
        }

        for (PatRefRelatedChild patRefRelatedChild : patRefRelatedChildList) {
            persist(patRefRelatedChild);
        }

    }

    /**
     * 
     * @param tableName => table name, 而非class name.
     * @param patId
     * @param sourceId
     */
    private void removeRefData(String tableName, String patId, String sourceId) {

        Session session = HibernateUtil.currentSession();
        String cc = patId.substring(0, 2)

        Query deleteQuery = session.createSQLQuery("delete from ${tableName} where substr(pat_id, 1, 2) = :cc and pat_id = :patId and source_id = :sourceId");
        deleteQuery.setString("cc", cc);
        deleteQuery.setString("patId", patId);
        deleteQuery.setString("sourceId", sourceId);

        if (!!patId && !!sourceId) {
            int deleteCount = deleteQuery.executeUpdate();
            log.debug("PatRefCited deleteCount = ${deleteCount}");
            session.flush();
        } else {
            log.debug("patId or sourceId is empty");
        }

    }

    /**
     * @param patRefPct
     */
    public void savePatRefPct(PatRefPct patRefPct) {

        if (log.isDebugEnabled()) {
            log.debug("patId = " + patRefPct.getPatId());
        }

        PatRefPct oldPatRefPct = PatRefPctHelper.findByPK(PatRefPct.class, patRefPct.getPatId());

        if (oldPatRefPct != null) {
            patRefPct.createDate = oldPatRefPct.createDate
            update(patRefPct)
        } else {
            save(patRefPct)
        }
    }

    /**
     * 
     * @param patRefCitedList
     * @param session
     */
    private void updateRefData(List<PatRefCited> patRefCitedList, Session session) {

        for (int i = 0; i < patRefCitedList.size(); i++) {
            PatRefCited cited = patRefCitedList[i];
            String cc = cited.id.patId.substring(0, 2);
            Query updateQuery = session.createSQLQuery("update public.pat_ref_cited set doc_no= :docNo where substr(pat_id, 1, 2) = :cc and pat_id= :patId and source_id= :sourceId and item= :item");
            updateQuery.setString("cc", cc);
            updateQuery.setString("patId", cited.id.patId);
            updateQuery.setString("sourceId", cited.id.sourceId);
            updateQuery.setInteger("item", cited.id.item);
            updateQuery.setString("docNo", cited.docNo);
            int updateCount = updateQuery.executeUpdate();
            log.debug("PatRefCited updateCount = ${updateCount}");
        }
    }
}