package com.patentdata.service

import com.patentdata.common.Constants
import com.patentdata.helper.SequenceHelper
import com.patentdata.model.PatData
import com.patentdata.model.PatDataLog

public class PatDataLogService extends BaseService {

    /**
     * @param patData
     * @param logType
     * @param logCode
     * @param msg
     * @param rawId
     */
    public void writeError(PatData patData, int logType, String logCode, String msg, String rawId) {
        
        writeError(patData.country, patData.rawDocNo, patData.docNo, patData.docDate
            , logType, logCode, msg, rawId, patData);
    }
    
    /**
     * @param country
     * @param rawDocNo
     * @param docNo
     * @param docDate
     * @param logType
     * @param logCode
     * @param msg
     * @param rawId
     * @param patData
     */
    public void writeError(String country, String rawDocNo, String docNo, Date docDate, int logType, String logCode, String msg, String rawId, PatData patData) {
        
        PatDataLog log = new PatDataLog();
        
        log.logId = SequenceHelper.getSeqPatDataLogIdNextVal();
        log.country = country;
        log.rawDocNo = rawDocNo;
        log.docNo = docNo;
        log.docDate = docDate;
        log.logType = logType;
        log.logCode = logCode;
        log.patData = patData;
        log.msg = msg;
        log.flag = 0;
        log.rawId = rawId;
        log.logDate = new Date();
        
        save(log);
    }
    
    public void writeErrorMessage(String rawId, String country, String msg) {
        PatDataLog log = new PatDataLog();
        
        log.logId = SequenceHelper.getSeqPatDataLogIdNextVal();
        log.country = country;
        log.rawDocNo = log.docNo = rawId;        
        log.logType = Constants.LOG_TYPE_ERROR
        log.logCode = 'DA-00';
        log.msg = msg;
        log.flag = 0;
        log.rawId = rawId;
        log.logDate = new Date();
        
        save(log);
    }
    
}
