package com.patentdata.service

import com.patentdata.helper.PatPersonInventorHelper
import com.patentdata.helper.PatPersonAgentHelper
import com.patentdata.helper.PatPersonApplicantHelper
import com.patentdata.helper.PatPersonAssigneeHelper
import com.patentdata.helper.PatPersonCorrespondenceAddrHelper
import com.patentdata.helper.PatPersonExaminerHelper
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonAssignee
import com.patentdata.model.PatPersonCorrespondenceAddr
import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PersonData

class PersonDataServices extends BaseService {

    /**
     * 
     * @param personDatas
     * @param patPersonApplicants
     * @param patPersonInventors
     * @param patPersonAgents
     * @param patPersonAssignees
     * @param patPersonExaminers
     * @param patPersonCorrespondenceAddrs
     */
    public void saveOrUpdate(List<PersonData> personDatas, List<PatPersonApplicant> patPersonApplicants
        , List<PatPersonInventor> patPersonInventors, List<PatPersonAgent> patPersonAgents
        , List<PatPersonAssignee> patPersonAssignees, List<PatPersonExaminer> patPersonExaminers
        , List<PatPersonCorrespondenceAddr> patPersonCorrespondenceAddrs) {

        if (personDatas.size() > 0) {
            for (PersonData personData: personDatas) {
                save(personData);
            }
        }

        for (PatPersonApplicant applicant : patPersonApplicants) {
            PatPersonApplicant oldPatPersonApplicant = PatPersonApplicantHelper.findByPK(applicant.id);
            if (oldPatPersonApplicant != null) {
                applicant.createDate = oldPatPersonApplicant.createDate;
                merge(applicant);
            } else {
                saveOrUpdate(applicant);
            }
        }
        
        for (PatPersonInventor inventor : patPersonInventors) {
            PatPersonInventor oldPatPersonInventor = PatPersonInventorHelper.findByPK(inventor.id);
            if (oldPatPersonInventor != null) {
                inventor.createDate = oldPatPersonInventor.createDate;
                merge(inventor);
            } else {
                saveOrUpdate(inventor);
            }
        }
        
        for (PatPersonAgent agent : patPersonAgents) {
            PatPersonAgent oldPatPersonAgent = PatPersonAgentHelper.findByPK(agent.id);
            if (oldPatPersonAgent != null) {
                agent.createDate = oldPatPersonAgent.createDate;
                merge(agent);
            } else {
                saveOrUpdate(agent);
            }
        }
        
        for (PatPersonExaminer examiner : patPersonExaminers) {
            // TODO: test case ???
            PatPersonExaminer oldPatPersonExaminer = PatPersonExaminerHelper.findByPK(examiner.id);
            if (oldPatPersonExaminer != null) {
                examiner.createDate = oldPatPersonExaminer.createDate;
                merge(examiner);
            } else {
                saveOrUpdate(examiner);
            }
        }
        
        for (PatPersonAssignee assignee : patPersonAssignees) {
            // TODO: test case ???
            PatPersonAssignee oldPatPersonAssignee = PatPersonAssigneeHelper.findByPK(assignee.id);
            if (oldPatPersonAssignee != null) {
                assignee.createDate = oldPatPersonAssignee.createDate;
                merge(assignee);
            } else {
                saveOrUpdate(assignee);
            }
        }
        
        for (PatPersonCorrespondenceAddr correspondenceAddr : patPersonCorrespondenceAddrs) {
            // TODO: test case ???
            PatPersonCorrespondenceAddr oldPatPersonCorrespondenceAddr = 
            PatPersonCorrespondenceAddrHelper.findByPK(PatPersonCorrespondenceAddr.class, correspondenceAddr.id);
            
            if (oldPatPersonCorrespondenceAddr != null) {
                correspondenceAddr.createDate = oldPatPersonCorrespondenceAddr.createDate;
                merge(correspondenceAddr);
            } else {
                saveOrUpdate(correspondenceAddr);
            }
        }
    }
}
