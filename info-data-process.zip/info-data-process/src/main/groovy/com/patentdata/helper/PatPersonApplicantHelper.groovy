package com.patentdata.helper;

import java.util.List;
import org.hibernate.SQLQuery
import org.hibernate.Session
import org.hibernate.type.StringType

import com.patentdata.model.PatPersonApplicant;
import com.patentdata.model.PatPersonApplicantId;
import com.patentdata.util.QueryBuilder;

import com.patentdata.util.HibernateUtil;

public class PatPersonApplicantHelper {

    public static PatPersonApplicant findById(PatPersonApplicantId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatPersonApplicant");
        queryBuilder.eq("pat_id", id.getPatId());
        queryBuilder.eq("source_id", id.getSourceId());
        queryBuilder.eq("item", id.getItem());
        
        if (queryBuilder.query().size() == 0) {
            return null;
        } else {
            return (PatPersonApplicant) queryBuilder.query().get(0);
        }
        
    }
    
    public static PatPersonApplicant findByPK(PatPersonApplicantId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatPersonApplicant");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.sourceId);
        queryBuilder.eq("item", id.getItem());
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * native query, 無法使用ORM Data
     * 
     * note: 因為hibernate mapping中對於postgresql uuid會有問題, 所以強制指定型態為String type.
     * 
     * @param patId
     * @return
     */
    public static List nativeQueryByPatId(String patId) {
        
        Session session = HibernateUtil.currentSession()
        String sql = "select person_id from pat_person_applicant where substr(pat_id, 1, 2) = :cc and pat_id = :pat_id order by item";
        SQLQuery query = session.createSQLQuery(sql);
        query.setString("cc", patId.trim().substring(0, 2));
        query.setString("pat_id", patId);
        query.addScalar("person_id", new StringType());
        List queryList = query.list()
        
        if (!!queryList) {
            return queryList;
        } else {
            return null;
        }
        
    }
    
}
