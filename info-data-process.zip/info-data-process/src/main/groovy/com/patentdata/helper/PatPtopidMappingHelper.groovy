package com.patentdata.helper;

import java.util.List;

import com.patentdata.model.PatPtopidMapping;
import com.patentdata.util.QueryBuilder;

public class PatPtopidMappingHelper extends BaseHelper {

    public static List<PatPtopidMapping> queryByCondition(String patId, String ptoPidId) {
        QueryBuilder queryBuilder = new QueryBuilder("PatPtopidMapping");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("ptopid_id", ptoPidId);
        return queryBuilder.query();
    }
    
    public static PatPtopidMapping findByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatPtopidMapping");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        
        List queryList = queryBuilder.query()
                
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
    }
    
}
