package com.patentdata.helper

import org.hibernate.SQLQuery
import org.hibernate.Session
import org.hibernate.type.StringType

import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonExaminerId
import com.patentdata.util.HibernateUtil
import com.patentdata.util.QueryBuilder

public class PatPersonExaminerHelper {
    
    /**
     * @param id
     * @return
     */
    public static PatPersonExaminer findByPK(PatPersonExaminerId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatPersonExaminer");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.getSourceId());
        queryBuilder.eq("item", id.getItem());
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * native query, 無法使用ORM Data
     *
     * note: 因為hibernate mapping中對於postgresql uuid會有問題, 所以強制指定型態為String type.
     *
     * @param patId
     * @return
     */
    public static List nativeQueryByPatId(String patId) {
        
        Session session = HibernateUtil.currentSession();
        String sql = "select person_id from pat_person_examiner where substr(pat_id, 1, 2) = :cc and pat_id = :pat_id order by examiner_type";
        SQLQuery query = session.createSQLQuery(sql);
        query.setString("cc", patId.trim().substring(0, 2));
        query.setString("pat_id", patId);
        query.addScalar("person_id", new StringType());
        List queryList = query.list()
        
        if (!!queryList) {
            return queryList;
        } else {
            return null;
        }
        
    }
    
}
