package com.patentdata.helper;

import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.util.QueryBuilder

public class PatDataTitleHelper {
    
    public static PatDataTitle findByPK(PatDataTitleId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatDataTitle");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.sourceId);
        queryBuilder.eq("lang", id.lang);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * native query, 無法使用ORM Data
     * 
     * @param patId
     * @return
     */
    public static List nativeQueryByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("select * from pat_data_title");
        queryBuilder.setNativeSQL(true)
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList;
        } else {
            return null;
        }
        
    }
    
}
