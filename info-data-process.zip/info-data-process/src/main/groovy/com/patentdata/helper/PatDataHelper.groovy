package com.patentdata.helper

import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.DateUtils
import org.hibernate.SQLQuery
import org.hibernate.Session

import com.patentdata.model.PatData
import com.patentdata.util.HibernateUtil
import com.patentdata.util.QueryBuilder
import com.patentdata.util.DateUtil

public class PatDataHelper extends BaseHelper<PatData> {
    
    /**
     * 
     * @param patId
     * @return
     */
    public static PatData findByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", patId.substring(0, 2));
        queryBuilder.eq("patId", patId);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
    }
    
    /**
     * 
     * @param patId
     * @return
     */
    public static List<PatData> queryByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", patId.substring(0, 2));
        queryBuilder.eq("patId", patId);
        
        return queryBuilder.query()
    }
    
    /**
     * @deprecated 
     * @param patId
     * @return
     */
    public static List<PatData> queryNativeSQLByCondition(String patId) {
        QueryBuilder queryBuilder = new QueryBuilder("select * from Pat_Data");
        queryBuilder.setNativeSQL(true);
        queryBuilder.eq("country", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        return queryBuilder.query();
    }
    
    /**
     * @param startDate
     * @param endDate
     * @param country
     * @return
     */
    public static List<PatData> queryByLastUpdDateRange(Date startDate, Date endDate, String country) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", country);
        if (!!startDate && !!endDate) {
            queryBuilder.between("last_upd_date", startDate, endDate);
        }
        
        return queryBuilder.query();
    }
    
    /**
     * @param startDate
     * @param endDate
     * @param country
     * @return
     */
    public static List<PatData> queryByDocDateRange(Date startDate, Date endDate, String country) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", country);
        if (!!startDate && !!endDate) {
            queryBuilder.between("doc_date", startDate, endDate);
        }
        
        return queryBuilder.query();
    }
    
    /**
     * 提供給[pat_ref_cited]查詢
     * 
     * @param country
     * @param docNo
     * @param kindCode
     * @return
     */
    public static List<PatData> queryByCondition(String country, String docNo, String kindCode) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("docNo", docNo);
        
        if (StringUtils.isNoneBlank(kindCode)) {
            queryBuilder.eq("kindCode", kindCode);
        }
        
        return queryBuilder.query();
    }
	
	/**
	 * @deprecated 查詢速度太慢
	 * 
	 * @param country
	 * @return
	 */
	public static List<PatData> queryByCountry(String country) {
		QueryBuilder queryBuilder = new QueryBuilder("PatData");
		queryBuilder.eq("country", country);
		return queryBuilder.query();
	}
    
    /**
     * 提供給[pat_ref_cited]查詢
     *
     * @param country
     * @param docNo
     * @param kindCode
     * @return
     */
    public static List<PatData> queryByCondition(String country, String docNo, String kindCode, Date docDate) {
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("docNo", docNo);
        
        if (docDate != null) {
            queryBuilder.between("docDate", docDate, DateUtils.addYears(docDate, 1));
        }
        
        if (StringUtils.isNoneBlank(kindCode)) {
            queryBuilder.eq("kindCode", kindCode);
        }
        
        return queryBuilder.query();
    }
    
    /**
     * 提供給[pat_ref_cited]查詢
     *
     * @param country
     * @param docNo
     * @param docDate
     * @return
     */
    public static List<PatData> queryByCondition(String country, String docNo, Date docDate) {
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("docNo", docNo);
        queryBuilder.eq("docDate", docDate);
        
        return queryBuilder.query();
    }
    
    /**
     * @deprecated
     * 
     * @param patId
     * @return
     */
    public static int count(String patId) {
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        return queryBuilder.queryCount();
    }
    
    /**
     * 
     * @param cc
     * @return
     */
    public static List nativeQueryByCountry(String cc) {
        
        String sql = '''
            select A.doc_date, count(A.pat_id)
            from (select distinct doc_date, pat_id, country  from pat_data where country = :cc order by doc_date ) A
            group by a.doc_date
        '''
        
        Session session = HibernateUtil.currentSession()
        SQLQuery query = session.createSQLQuery(sql);
        query.setString("cc", cc);
        List queryList = query.list()
        
        if (!!queryList) {
            return queryList;
        } else {
            return null;
        }
    }
    
    public static List queryByDocDate(String docDate, String cc) {
        QueryBuilder queryBuilder = new QueryBuilder("PatData");
        queryBuilder.eq("country", cc);
        queryBuilder.eq("docDate", DateUtil.parseDate(docDate));
        return queryBuilder.query();
    }
    
    /**
     * 
     * @param docDate
     * @param cc
     * @return
     */
    public static List<Object> nativeQueryByDocDate(String docDate, String cc) {
        Session session = HibernateUtil.currentSession();
        SQLQuery query = session.createSQLQuery("select pat_id, default_source_id from pat_data where substr(pat_id,1,2) = :cc and doc_date = Date(:docDate)")
        query.setString("cc", cc);
        query.setString("docDate", docDate);
        return query.list();
    }
    
}
