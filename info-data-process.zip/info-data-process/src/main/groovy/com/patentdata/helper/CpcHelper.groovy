package com.patentdata.helper

import com.patentdata.model.Cpc
import com.patentdata.util.QueryBuilder

public class CpcHelper {

    public static Cpc findById(String id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("Cpc");
        queryBuilder.eq("id", id);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
    }
    
    public static void main(String[] args) {
        
        Cpc cpc = findById("A01H0005100000");
        
        println "cpc  : $cpc"
        
    }
}
