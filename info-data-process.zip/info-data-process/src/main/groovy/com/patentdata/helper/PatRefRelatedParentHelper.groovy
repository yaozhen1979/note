package com.patentdata.helper

import com.patentdata.model.PatRefRelatedParent
import com.patentdata.util.QueryBuilder

class PatRefRelatedParentHelper {

    /**
     * @param patId
     * @param sourceId
     * @return
     */
    public static List<PatRefRelatedParent> findByCondition(String patId, String sourceId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatRefRelatedParent");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("source_id", sourceId);
        queryBuilder.order("item");
        
        List queryList = queryBuilder.query();
        
        if (!!queryList && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
    }
}
