package com.patentdata.helper

import java.util.List;

import com.patentdata.model.PatClsEcla
import com.patentdata.util.QueryBuilder;

public class PatClsEclaHelper extends BaseHelper {

    public static List<PatClsEcla> findByCondition(String patId){
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsEcla");
        queryBuilder.eq("pat_id", patId);
        
        List queryList = queryBuilder.query();        
        if (queryList != null && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }        
    }
}
