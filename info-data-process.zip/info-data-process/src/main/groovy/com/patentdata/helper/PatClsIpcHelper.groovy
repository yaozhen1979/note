package com.patentdata.helper

import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.util.QueryBuilder

public class PatClsIpcHelper {
    
    public static PatClsIpc findByPK(PatClsIpcId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsIpc");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.sourceId);
        queryBuilder.eq("ipc_type", id.ipcType);
        queryBuilder.eq("item", id.item);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * @param patId
     * @param sourceId
     * @return
     */
    public static List<PatClsIpc> findByCondition(String patId, String sourceId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsIpc");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("source_id", sourceId);
        queryBuilder.order("ipc_type, item");
        
        List queryList = queryBuilder.query()
        
        if (!!queryList && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
    }

}
