package com.patentdata.helper;

import com.patentdata.util.HibernateUtil;

import com.patentdata.model.PatEventRecord;
import com.patentdata.util.QueryBuilder;
import org.hibernate.Query
import org.hibernate.Session

public class PatEventRecordHelper extends BaseHelper<PatEventRecord> {
    
    /**
     * select pat_item from pat_event_record where pat_id = 'DE10103150-B4-20151210' order by pat_item limit 1
     * 
     * @param patId
     * @return
     */
    public static Integer findByPatItem(String patId) {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select PAT_ITEM from PAT_EVENT_RECORD where pat_id = :patId order by PAT_ITEM desc limit 1");
        query.setString("patId", patId);
        
        return query.uniqueResult()
    }
    
}
