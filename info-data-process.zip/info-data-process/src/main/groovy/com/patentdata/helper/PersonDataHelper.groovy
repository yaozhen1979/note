package com.patentdata.helper;

import java.util.List;
import org.hibernate.Query
import org.hibernate.SQLQuery
import org.hibernate.Session

import com.patentdata.model.PersonData;
import com.patentdata.util.QueryBuilder;
import com.patentdata.util.HibernateUtil;

public class PersonDataHelper extends BaseHelper {
    
    /**
     * @deprecated
     * 
     * 以 personFacet 查詢 PersonData
     * @param personFacet
     * @return
     */
    @Deprecated
    public static PersonData findByPersonFacet(String personFacet) {
        QueryBuilder queryBuilder = new QueryBuilder("PersonData");
        queryBuilder.eq("person_facet", personFacet);
        
        if (queryBuilder.query().size() == 0) {
            return null;
        } else {
            return (PersonData) queryBuilder.query().get(0);
        }
    }
    
    /**
     * @deprecated
     * 
     * personFacet 是否存在 :<BR>
     * 1. DB 中是否存在 <BR>
     * 2. personDataList 中是否存在
     * @param personData
     * @param personDataList
     * @return
     */
    @Deprecated
    public static PersonData findExistsPersonDataByPersonFacet(String personFacet, List<PersonData> personDataList) {
        
        PersonData existsData = findByPersonFacet(personFacet);
        
        // DB有查到就直接回傳
        if (existsData != null) {
            return existsData;
        }
        
        // DB沒有，personDataList 為空(第一次進來)
        if (personDataList.size() == 0) {
            return null;
        }
        
        // 排除同一個transaction中, 重複的PersonData 
        for (PersonData data : personDataList) {
            if (data.getPersonFacet().equals(personFacet)) {
                return data;
            }
        }
        
        return null;
    }
    
    /**
     * 
     * @param personFacet
     * @param country
     * @return
     */
    public static PersonData findByPersonFacet(String personFacet, String country) {
        
        String sql = "";
        Session session = HibernateUtil.currentSession()
        
        // NOTE: 2016-04-07, 強制country = null.
        if (org.apache.commons.lang3.StringUtils.isBlank(country)) {
            country = null;
        }
        
        if (country != null) {
            sql = "select * from person_data where person_facet = :person_facet and country = :country";
        } else {
            sql = "select * from person_data where person_facet = :person_facet and country is null";
        }
        
        SQLQuery query = session.createSQLQuery(sql);
        query.setString("person_facet", personFacet);
        
        if (country != null) {
            query.setString("country", country);
        }
        
        query.addEntity(PersonData.class);
        List queryList = query.list();
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * 代入 person_data 中的 country
     * 
     * @param personFacet
     * @param country
     * @param personDataList
     * @return
     */
    public static PersonData findExistsPersonDataByPersonFacet(String personFacet, String country, List<PersonData> personDataList) {
        
        PersonData existsData = findByPersonFacet(personFacet, country);
        
        // DB有查到就直接回傳
        if (existsData != null) {
            return existsData;
        }
        
        // DB沒有，personDataList 為空(第一次進來)
        if (personDataList.size() == 0) {
            return null;
        }
        
        // 排除同一個transaction中, 重複的PersonData 
        for (PersonData data : personDataList) {
            if (data.getPersonFacet().equals(personFacet)) {
                return data;
            }
        }
        
        return null;
    }
    
    public static PersonData findByPersonId(String personId) {
        
        Session session = HibernateUtil.currentSession()
        String sql = "from PersonData where personId = :personId";
        Query query = session.createQuery(sql);
        query.setParameter("personId", UUID.fromString(personId), new org.hibernate.type.PostgresUUIDType());
        
        List queryList = query.list()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
}