package com.patentdata.helper

import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatClsUspcId
import com.patentdata.util.QueryBuilder

public class PatClsUspcHelper {
    
    public static PatClsUspc findByPK(PatClsUspcId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsUspc");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.sourceId);
        queryBuilder.eq("item", id.item);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * @param patId
     * @param sourceId
     * @return
     */
    public static List<PatClsUspc> findByCondition(String patId, String sourceId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsUspc");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("source_id", sourceId);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
    }
    
}
