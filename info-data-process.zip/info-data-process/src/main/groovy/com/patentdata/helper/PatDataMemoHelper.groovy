package com.patentdata.helper

import com.patentdata.model.PatDataMemo
import com.patentdata.util.QueryBuilder

class PatDataMemoHelper {

    public static PatDataMemo findByCondition(String patId, int memoType){
        QueryBuilder queryBuilder = new QueryBuilder("PatDataMemo");
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("memo_type", memoType);
        
        List queryList = queryBuilder.query()
        
        return (!!queryList)? queryList.get(0): null
    }
    
}
