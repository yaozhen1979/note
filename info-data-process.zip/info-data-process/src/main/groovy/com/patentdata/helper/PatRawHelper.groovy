package com.patentdata.helper;

import java.util.List;

import com.patentdata.model.PatRawDocdb;
import com.patentdata.util.QueryBuilder;

/**
 * queryBuilder.eq("substr(patId, 1, 2)", patId.substring(0, 2)), 為一定要帶入的查詢條件
 * 
 * @author tonykuo
 *
 */
public class PatRawHelper extends BaseHelper {
    
    /**
     * 
     * @param rawId
     * @param patId
     * @return
     */
    public static PatRawDocdb findByRawId(String rawId, String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatRawDocdb");
        queryBuilder.eq("substr(patId, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("rawId", rawId);
        
        List queryList = queryBuilder.query();
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }

    }
    
    /**
     * 
     * @param patId
     * @return
     */
    public static PatRawDocdb findByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatRawDocdb");
        queryBuilder.eq("substr(patId, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("patId", patId);
        
        List queryList = queryBuilder.query();
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }

    }
    
    /**
     * 
     * @param patId
     * @return
     */
    public static List<PatRawDocdb> queryByPatId(String patId) {
        QueryBuilder queryBuilder = new QueryBuilder("PatRawDocdb");
        queryBuilder.eq("patId", patId);
        return queryBuilder.query();
    }
    
}
