package com.patentdata.helper

import com.patentdata.model.PatDataLog
import com.patentdata.util.QueryBuilder

public class PatDataLogHelper {

    public static List<PatDataLog> queryByDocDateRange(Date startDate, Date endDate, String country) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatDataLog");
        queryBuilder.eq("country", country);
        if (!!startDate && !!endDate) {
            queryBuilder.between("doc_date", startDate, endDate);
        }
        
        return queryBuilder.query();
    }
    
}
