package com.patentdata.helper;

import java.util.Date;
import java.util.List;

import com.patentdata.model.AppData;
import com.patentdata.util.QueryBuilder;

public class AppDataHelper extends BaseHelper {
    
    /**
     *
     * @param appId
     * @param country
     * @return
     */
    public static AppData findByAppId(String appId, String country) {
        
        QueryBuilder queryBuilder = new QueryBuilder("AppData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("appId", appId);
        
        List queryList = queryBuilder.query();
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * 提供給[pat_ref_priority]查詢
     *
     * @param country
     * @param docNo
     * @param kindCode
     * @return
     */
    public static List<AppData> queryByCondition(String country, String appNo, Date appDate) {
        QueryBuilder queryBuilder = new QueryBuilder("AppData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("appNo", appNo);
        queryBuilder.eq("appDate", appDate);
        return queryBuilder.query();
    }

    public static List<AppData> queryByCondition(String country, String appNo) {
        QueryBuilder queryBuilder = new QueryBuilder("AppData");
        queryBuilder.eq("country", country);
        queryBuilder.eq("appNo", appNo);
        return queryBuilder.query();
    }
}
