package com.patentdata.helper

import java.util.List;

import com.patentdata.model.PatClsCpc;
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsCsetId
import com.patentdata.util.QueryBuilder

public class PatClsCsetHelper {
    
    public static PatClsCset findByPK(PatClsCsetId id) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsCset");
        queryBuilder.eq("substr(pat_id, 1, 2)", id.patId.substring(0, 2));
        queryBuilder.eq("pat_id", id.patId);
        queryBuilder.eq("source_id", id.sourceId);
        queryBuilder.eq("group_no", id.groupNo);
        queryBuilder.eq("item", id.item);
        
        List queryList = queryBuilder.query()
        
        if (!!queryList) {
            return queryList.get(0);
        } else {
            return null;
        }
        
    }
    
    /**
     * @param patId
     * @param sourceId
     * @return
     */
    public static List<PatClsCset> findByCondition(String patId, String sourceId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsCset");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("source_id", sourceId);
        queryBuilder.order("item");
        
        List queryList = queryBuilder.query();
        
        if (!!queryList && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
    }
    
}
