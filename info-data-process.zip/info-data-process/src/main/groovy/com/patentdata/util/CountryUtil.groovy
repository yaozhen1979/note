package com.patentdata.util

import org.apache.commons.lang3.StringUtils

/**
 * docdb country list
 * 
 * @author tonykuo
 *
 */
public class CountryUtil {
    
    /**
     * PCT Applicant’s Guide – International Phase – Annex K (27 February 2015)
     * Country Names and Two-Letter Codes
     */
    public final static Map<String,String> countryCodes = new HashMap<String,String>(
        [
            "AD" : "Andorra",
            "AE" : "United Arab Emirates",
            "AF" : "Afghanistan",
            "AG" : "Antigua andBarbuda",
            "AI" : "Anguilla",
            "AL" : "Albania",
            "AM" : "Armenia",
            "AO" : "Angola",
            "AP" : "African Regional Intellectual Property Organization (ARIPO)",
            "AR" : "Argentina",
            "AT" : "Austria",
            "AU" : "Australia",
            "AW" : "Aruba",
            "AZ" : "Azerbaijan",
            "BA" : "Bosnia and Herzegovina",
            "BB" : "Barbados",
            "BD" : "Bangladesh",
            "BE" : "Belgium",
            "BF" : "Burkina Faso",
            "BG" : "Bulgaria",
            "BH" : "Bahrain",
            "BI" : "Burundi",
            "BJ" : "Benin",
            "BM" : "Bermuda",
            "BN" : "Brunei Darussalam",
            "BO" : "Bolivia, Plurinational State of",
            "BQ" : "Bonaire, Sint Eustatius and Saba",
            "BR" : "Brazil",
            "BS" : "Bahamas",
            "BT" : "Bhutan",
            "BV" : "BouvetIsland",
            "BW" : "Botswana",
            "BX" : "Benelux Office for Intellectual Property (BOIP)",
            "BY" : "Belarus",
            "BZ" : "Belize",
            "CA" : "Canada",
            "CD" : "Democratic Republic of the Congo",
            "CF" : "Central African Republic",
            "CG" : "Congo",
            "CH" : "Switzerland",
            "CI" : "Côte d’Ivoire",
            "CK" : "Cook Islands",
            "CL" : "Chile",
            "CM" : "Cameroon",
            "CN" : "China",
            "CO" : "Colombia",
            "CR" : "Costa Rica",
            "CU" : "Cuba",
            "CV" : "CaboVerde",
            "CW" : "Curaçao",
            "CY" : "Cyprus",
            "CZ" : "Czech Republic",
            "DE" : "Germany",
            "DJ" : "Djibouti",
            "DK" : "Denmark",
            "DM" : "Dominica",
            "DO" : "Dominican Republic",
            "DZ" : "Algeria",
            "EA" : "Eurasian Patent Organization (EAPO)",
            "EC" : "Ecuador",
            "EE" : "Estonia",
            "EG" : "Egypt",
            "EH" : "Western Sahara",
            "EM" : "Office for Harmonization in the Internal Market (Trademarks and Designs) (OHIM)",
            "EP" : "European Patent Office (EPO)",
            "ER" : "Eritrea",
            "ES" : "Spain",
            "ET" : "Ethiopia",
            "FI" : "Finland",
            "FJ" : "Fiji",
            "FK" : "Falkland Islands (Malvinas)",
            "FO" : "FaroeIslands",
            "FR" : "France",
            "GA" : "Gabon",
            "GB" : "United Kingdom",
            "GC" : "Patent Office of the Cooperation Council for the Arab States of the Gulf (GCC)",
            "GD" : "Grenada",
            "GE" : "Georgia",
            "GG" : "Guernsey",
            "GH" : "Ghana",
            "GI" : "Gibraltar",
            "GL" : "Greenland",
            "GM" : "Gambia",
            "GN" : "Guinea",
            "GQ" : "Equatorial Guinea",
            "GR" : "Greece",
            "GS" : "South Georgia and the South Sandwich Islands",
            "GT" : "Guatemala",
            "GW" : "Guinea-Bissau",
            "GY" : "Guyana",
            "HK" : "The Hong Kong Special Administrative Region of the People’s Republic of China",
            "HN" : "Honduras",
            "HR" : "Croatia",
            "HT" : "Haiti",
            "HU" : "Hungary",
            "IB" : "International Bureau of the World Intellectual Property Organization (WIPO)",
            "ID" : "Indonesia",
            "IE" : "Ireland",
            "IL" : "Israel",
            "IM" : "Isle of Man",
            "IN" : "India",
            "IQ" : "Iraq",
            "IR" : "Iran (Islamic Republic of)",
            "IS" : "Iceland",
            "IT" : "Italy",
            "JE" : "Jersey",
            "JM" : "Jamaica",
            "JO" : "Jordan",
            "JP" : "Japan",
            "KE" : "Kenya",
            "KG" : "Kyrgyzstan",
            "KH" : "Cambodia",
            "KI" : "Kiribati",
            "KM" : "Comoros",
            "KN" : "Saint Kitts and Nevis",
            "KP" : "Democratic People’s Republic of Korea",
            "KR" : "Republic of Korea",
            "KW" : "Kuwait",
            "KY" : "Cayman Islands",
            "KZ" : "Kazakhstan",
            "LA" : "Lao People’s Democratic Republic",
            "LB" : "Lebanon",
            "LC" : "Saint Lucia",
            "LI" : "Liechtenstein",
            "LK" : "Sri Lanka",
            "LR" : "Liberia",
            "LS" : "Lesotho",
            "LT" : "Lithuania",
            "LU" : "Luxembourg",
            "LV" : "Latvia",
            "LY" : "Libya",
            "MA" : "Morocco",
            "MC" : "Monaco",
            "MD" : "Republic of Moldova",
            "ME" : "Montenegro",
            "MG" : "Madagascar",
            "MK" : "The former Yugoslav Republic of Macedonia",
            "ML" : "Mali",
            "MM" : "Myanmar",
            "MN" : "Mongolia",
            "MO" : "Macao",
            "MP" : "Northern Mariana Islands",
            "MR" : "Mauritania",
            "MS" : "Montserrat",
            "MT" : "Malta",
            "MU" : "Mauritius",
            "MV" : "Maldives",
            "MW" : "Malawi",
            "MX" : "Mexico",
            "MY" : "Malaysia",
            "MZ" : "Mozambique",
            "NA" : "Namibia",
            "NE" : "Niger",
            "NG" : "Nigeria",
            "NI" : "Nicaragua",
            "NL" : "Netherlands",
            "NO" : "Norway",
            "NP" : "Nepal",
            "NR" : "Nauru",
            "NZ" : "New Zealand",
            "OA" : "African Intellectual Property Organization (OAPI)",
            "OM" : "Oman",
            "PA" : "Panama",
            "PE" : "Peru",
            "PG" : "Papua New Guinea",
            "PH" : "Philippines",
            "PK" : "Pakistan",
            "PL" : "Poland",
            "PT" : "Portugal",
            "PW" : "Palau",
            "PY" : "Paraguay",
            "QA" : "Qatar",
            "QZ" : "Community Plant Variety Office (European Union) (CPVO)",
            "RO" : "Romania",
            "RS" : "Serbia",
            "RU" : "Russian Federation",
            "RW" : "Rwanda",
            "SA" : "Saudi Arabia",
            "SB" : "Solomon Islands",
            "SC" : "Seychelles",
            "SD" : "Sudan",
            "SE" : "Sweden",
            "SG" : "Singapore",
            "SH" : "Saint Helena, Ascension and Tristan da Cunha",
            "SI" : "Slovenia",
            "SK" : "Slovakia",
            "SL" : "Sierra Leone",
            "SM" : "San Marino",
            "SN" : "Senegal",
            "SO" : "Somalia",
            "SR" : "Suriname",
            "SS" : "South Sudan",
            "ST" : "Sao Tome and Principe",
            "SV" : "El Salvador",
            "SX" : "Sint Maarten (Dutch part)",
            "SY" : "SyrianArabRepublic",
            "SZ" : "Swaziland",
            "TC" : "Turks and CaicosIslands",
            "TD" : "Chad",
            "TG" : "Togo",
            "TH" : "Thailand",
            "TJ" : "Tajikistan",
            "TL" : "Timor–Leste",
            "TM" : "Turkmenistan",
            "TN" : "Tunisia",
            "TO" : "Tonga",
            "TR" : "Turkey",
            "TT" : "Trinidad and Tobago",
            "TV" : "Tuvalu",
            "TW" : "Taiwan, Province of China",
            "TZ" : "United Republic of Tanzania",
            "UA" : "Ukraine",
            "UG" : "Uganda",
            "US" : "United States of America",
            "UY" : "Uruguay",
            "UZ" : "Uzbekistan",
            "VA" : "HolySee",
            "VC" : "Saint Vincent and the Grenadines",
            "VE" : "Venezuela, Bolivarian Republic of",
            "VG" : "Virgin Islands (British)",
            "VN" : "Viet Nam",
            "VU" : "Vanuatu",
            "WO" : "World Intellectual Property Organization (WIPO) (International Bureau of)",
            "WS" : "Samoa",
            "XN" : "Nordic Patent Institute (NPI)",
            "XU" : "International Union for the Protection of New Varieties of Plants (UPOV)",
            "YE" : "Yemen",
            "ZA" : "South Africa",
            "ZM" : "Zambia",
            "ZW" : "Zimbabwe",
        ])
    
    public static Set<String> getCountryCodeSet(){
        return this.countryCodes.keySet()
    }
    
    public static boolean isExistCountryCode(String countryCode){
        return this.getCountryCodeSet().contains(countryCode)
    }
    
    /**
     * formulate country code with default value "" for codes missing in list    
     * @param countryCode
     * @return
     */
    public static String formalCountryCode(String countryCode){
        return (isExistCountryCode(countryCode))? countryCode:""
    }
    
    
    /**
     * 取得 Docdb 全部國家的 Country Code [包含即有PTO]
     * 
     * BA 不建
     * KG, KZ 不建
     * TT 不建
     * UZ 不建
     * 
     * @return
     */
    public static List<String> getDocdbCountryList() {
        
        def countryList = [
            "AM", "AP", "AR", "AT", "AU", 
            // "BA", 
            "BE", "BG", "BR", "BY",
            "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ",
            "DD", "DE", "DZ", "DK", "DO",
            "EA", "EC", "EE", "EG", "ES", "EP",
            "FI", "FR",
            "GB", "GC", "GE", "GR", "GT",
            "HK", "HN", "HR", "HU",
            "ID", "IE", "IL", "IN", "IS", "IT",
            "JO", "JP",
            "KE", 
            // "KG", 
            "KR", 
            // "KZ",
            "LT", "LU", "LV",
            "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
            "NI", "NL", "NO", "NZ",
            "OA",
            "PA", "PE", "PH", "PL", "PT",
            "RO", "RS", "RU",
            "SE", "SG", "SI", "SK", "SM", "SU", "SV",
            "TH", "TJ", "TN", "TR", 
            // "TT", 
            "TW",
            "UA", "US", "UY", 
            // "UZ",
            "VN",
            "WO",
            "YU",
            "ZA", "ZM", "ZW"
        ]
        
        // println "countryList = ${countryList.size()}"
        
        return countryList
    }
    
    /**
     * 取得即有 PTO Country Code
     * 
     * @return
     */
    public static List<String> getOriginPTOList() {
        
        def originPTOList = ["CN", "EP", "JP", "KR", "US", "TW", "WO"]
        
        return originPTOList
    }
    
    /**
     * 
     * @param country
     * @return
     */
    public static Boolean isOriginPTO(String country) {
        def originPTOList = ["CN", "EP", "JP", "KR", "US", "TW", "WO"]
        return originPTOList.contains(country.toUpperCase());
    }
    
    /**
     * 取得 Docdb 中其它國家的 Country Code.
     * 
     * @return
     */
    public static List<String> getOtherCountryList() {
        
        def docdbCountryList = getDocdbCountryList();
        
        def originPTOList = getOriginPTOList();
        
        return  docdbCountryList - originPTOList;
    }
    
    public static List<String> getTestCountryList() {
        
        def countryList = [
            "AP"
        ]
        
        // println "countryList = ${countryList.size()}"
        
        return countryList
    }
    
    /**
     * 依國家代碼查詢舊有 PTO 名稱
     * @param countryCode
     * @return
     */
    public static String findPtoByCountry(String countryCode) {
        
        String pto = "";
        switch (countryCode) {
            case "US":
                pto = "USPTO";
                break;
            case "TW":
                pto = "TIPO";
                break;
            case "CN":
                pto = "CNIPR";
                break;
            case "JP":
                pto = "JPO";
                break;
            case "KR":
                pto = "KIPO";
                break;
            case "EP":
                pto = "EPO";
                break;
            case "WO":
                pto = "WIPO";
                break;
            case "IN":
                pto = "IN";
                break;
            default:
                break;
        }
        
        if (!pto) {
            throw new Exception("country code error!");
        }
        
        return pto;
    }
    
    /**
     * @param country
     * @return
     */
    public static String transferCountryCodeUS(String country) {
        
        String cc = null;
        if (country.equalsIgnoreCase("unknown") || country.equalsIgnoreCase("omitted")) {
            cc = null;
        } else if (StringUtils.upperCase(country.replace(" ", "")) == "UNITEDSTATES" ||
                    StringUtils.upperCase(country.replace(" ", "")) == "USA") {
            cc = "US";
        } else if (StringUtils.upperCase(country.replace(" ", "")) == "EMX") {
            cc = "EM"
        } else if (StringUtils.isBlank(country) || country.length() == 2) {
            cc = country;
        } else {
            throw new Exception("country code error!");
        }
        
        return cc;
    }
    
}
