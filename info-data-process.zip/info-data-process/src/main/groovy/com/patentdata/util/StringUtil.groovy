package com.patentdata.util

import org.apache.commons.lang3.StringUtils

class StringUtil {
    
    /**
     * EX:
     * 
     * StringUtil.unwrap("\"test test \"xxx\" test test\"", "\"") = test test "xxx" test test
     * 
     * @param str
     * @param remove
     * @return
     */
    static String unwrap(String str, String remove) {
        
        String removeStartStr = StringUtils.removeStart(str, remove)
        String removeEndStr = StringUtils.removeEnd(removeStartStr, remove)
        
        return removeEndStr
    }
    
    /**
     * Left pad a String with a specified character.
     * Pad to a size of size.
     * 
     * StringUtils.leftPad(null, *, *)     = null
     * StringUtils.leftPad("", 3, 'z')     = "zzz"
     * StringUtils.leftPad("bat", 3, 'z')  = "bat"
     * StringUtils.leftPad("bat", 5, 'z')  = "zzbat"
     * StringUtils.leftPad("bat", 1, 'z')  = "bat"
     * StringUtils.leftPad("bat", -1, 'z') = "bat"
     *
     * @param str - the String to pad out, may be null
     * @param size - the size to pad to
     * @param padChar - the character to pad with
     * @return - left padded String or original String if no padding is necessary, null if null String input
     */
    static leftPad(def str, int size, def padChar) {
        return StringUtils.leftPad(str, size, padChar)
    }
    
    /**
     * Right pad a String with a specified character.
     * 
     * The String is padded to the size of size.
     * 
     * StringUtils.rightPad(null, *, *)     = null
     * StringUtils.rightPad("", 3, 'z')     = "zzz"
     * StringUtils.rightPad("bat", 3, 'z')  = "bat"
     * StringUtils.rightPad("bat", 5, 'z')  = "batzz"
     * StringUtils.rightPad("bat", 1, 'z')  = "bat"
     * StringUtils.rightPad("bat", -1, 'z') = "bat"
     * 
     * @param str - the String to pad out, may be null
     * @param size - the size to pad to
     * @param padChar - the character to pad with
     * @return - right padded String or original String if no padding is necessary, null if null String input
     */
    static rightPad(def str, int size, def padChar) {
        return StringUtils.rightPad(str, size, padChar)
    }
    
    /**
     * PersonFacet
     * 轉為小寫,濾掉空白及~!@#$%^&*()\\-_=+\\[{\\]};:'\",<.>/?
     * @param facetStr
     * @return
     */
    static String personFacetWrap(String facetStr) {
        if (!facetStr) {
            return null;
        }
        return facetStr.toLowerCase().replaceAll(/[\s`~!\\@#\$%^\*\&()\-_=\+{};:'\"<>\,\.\/\?\[\]\|]+/, "");
    }
    
    /**
     * convert html code to  normal Punctuation
     * @param str
     * @return
     */
    static String wrapHtmlCode(String str) {
        if (!str) {
            return null;
        }
        return str.replaceAll(/&amp;/, "&").replaceAll(/&quot;/,"\"").replaceAll(/&#039;/,"'").replaceAll(/&lt;/,"<").replaceAll(/&gt;/,">");
    }
    
    /**
     * e.printTraceStack to string
     * 
     * @param e
     * @return
     */
    static String stack2string(Exception e) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return "------\r\n" + sw.toString() + "------\r\n"
        } catch(Exception e2) {
            return "bad stack2string";
        }
    }
    
    /**
     * @param text
     * @return
     */
    static String thousandsSeparatorToString(String text) {
        
        StringBuffer sb = new StringBuffer();
        int cnt = 0;
        for (int i=text.length()-1; i>-1;i--) {
            sb.append(text[i]);
            cnt++;
            if (cnt%3 == 0 && cnt != text.length()) {
                sb.append(",");
            }
        }

        return sb.reverse().toString();
    }
    
}