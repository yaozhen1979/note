package com.patentdata.util

import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.mongodb.DBObject
import com.patentdata.common.CommonEnum
import com.patentdata.common.Constants
import com.patentdata.common.CommonEnum.COUNTRY
import com.patentdata.exception.JsonFormatException
import com.patentdata.helper.AppDataHelper
import com.patentdata.helper.PatDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatData
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedCls
import com.patentdata.model.PatRefCitedClsId
import com.patentdata.model.PatRefCitedId
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefCitedNplCls
import com.patentdata.model.PatRefCitedNplClsId
import com.patentdata.model.PatRefCitedNplId
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefPriorityId
import com.patentdata.model.PatRefRelatedChild
import com.patentdata.model.PatRefRelatedChildId
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PatRefRelatedParentId
import com.patentdata.process.EPPatDataProcess
import com.patentdata.service.PatRefService

/**
 * 處理[pat_ref_cited][pat_ref_cited_cls]等table.
 * 
 * @author tonykuo
 *
 */
class PatRefUtil {

    public static Logger logger = LoggerFactory.getLogger(PatRefUtil.class);
    /**
     * 
     * 
     * @param patData
     * @param refCited
     * @return
     * @throws Exception
     */
    public static PatRefCited getDocdbRefCited(PatData patData, DBObject refCited, int item) throws Exception {

        PatRefCited patRefCited = new PatRefCited();
        PatRefCitedId patRefCitedId = new PatRefCitedId();
        patRefCitedId.patId = patData.patId;
        patRefCitedId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patRefCitedId.item = item;
        patRefCited.id = patRefCitedId;

        // patRefCited.patData = patData;
        patRefCited.createDate = new Date();
        //
        patRefCited.rawDocNo = refCited."patcit"."document-id"."doc-number";

        if (!!refCited."patcit"."document-id"."country") {
            patRefCited.country = refCited."patcit"."document-id"."country";
        }

        // if (CountryUtil.isOriginPTO(patData.country)) {
        if (false) {
            // TODO: 原有PTO判斷 => 後補程式處理
            println "refCited = ${refCited}"
            throw new Exception("todo: pat_ref_cited docNo error");
        } else {
            patRefCited.docNo = refCited."patcit"."document-id"."doc-number";
        }

        if (!!refCited."patcit"."document-id"."kind") {
            patRefCited.kindCode = refCited."patcit"."document-id"."kind";
        }

        if (!!refCited."patcit"."document-id"."name") {
            patRefCited.inventorName = refCited."patcit"."document-id"."name"."value";
        }

        if (!!refCited."patcit"."document-id"."date") {
            patRefCited.docDate = DateUtil.parseDate(refCited."patcit"."document-id"."date" as String);
        }

        if (!!refCited."document-id") {
            throw new Exception("refCited.document-id error");
        }

        if (!!refCited."refno") {
            throw new Exception("refCited.refno error");
        }

        // patRefCited.appDate => docdb 找不有[application-date]的資料

        // 引證資料種類,0:無法確認, 1:cited by applicant, 2:cited by examiner
        patRefCited.citedByType = Constants.CITED_BY_TYPE_UNKNOW;

        // 引證資料是否存在於pat_data中,存在的話寫入pat_id,使用country,docnum,kind至pat_data查詢,寫入對應到的pat_id
        if (!!patRefCited.country && !!patRefCited.docNo && !!patRefCited.kindCode) {
            //
            // println "patRefCited.country = ${patRefCited.country}, patRefCited.docNo = ${patRefCited.docNo}, patRefCited.kindCode = ${patRefCited.kindCode}, patRefCited.docDate = ${patRefCited.docDate}"
            List<PatData> patDataList = PatDataHelper.queryByCondition(patRefCited.country, patRefCited.docNo, patRefCited.kindCode);
            if (!!patDataList) {
                if (patDataList.size() > 1) {
                    // NOTE: DOCDB-201511-004-DE-0053.xml/315073100, 該筆資料引證到[patRefCited.country = BE, patRefCited.docNo = 628506, patRefCited.kindCode = A, patRefCited.docDate = null]
                    //       但在目前的pat_data卻有二筆資料, 可以cited data因為沒有doDate, 所以無法得知是cited到那一筆.
                    // throw new Exception("cited data query over 1...");
                    logger.error "pat_id = ${patData.patId}, country = ${patData.country}, kindCode = ${patData.kindCode}, docDate = ${patData.docDate}, cited data query over 1..."
                }
                patRefCited.citedPatId = patDataList.get(0).patId;
            }

        }

        return patRefCited;

    }   // end getDocdbRefCited

    /**
     * 
     * @param patData
     * @param refCitedNpl
     * @return
     * @throws Exception
     */
    public static PatRefCitedNpl getDocdbRefCitedNpl(PatData patData, DBObject refCitedNpl, int item) throws Exception {

        PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
        PatRefCitedNplId patRefCitedNplId = new PatRefCitedNplId();
        //
        patRefCitedNplId.patId = patData.patId;
        patRefCitedNplId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patRefCitedNplId.item = item;
        patRefCitedNpl.id = patRefCitedNplId;

        // patRefCited.patData = patData;
        patRefCitedNpl.createDate = new Date();

        String nplJson = refCitedNpl."nplcit";
        if (JSONUtil.isJSONValid(nplJson)) {
            patRefCitedNpl.nplJson = nplJson;
        } else {
            throw new JsonFormatException("nplJson");
        }

        patRefCitedNpl.nplText = refCitedNpl."nplcit"."text";

        // 引證資料種類,0:無法確認, 1:cited by applicant, 2:cited by examiner
        patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_UNKNOW;

        return patRefCitedNpl;
    }

    /**
     * 
     * @param patData
     * @param refPriority
     * @return
     * @throws Exception
     */
    public static PatRefPriority getDocdbRefPriority(PatData patData, DBObject refPriority) throws Exception {

        PatRefPriority patRefPriority = new PatRefPriority();
        PatRefPriorityId patRefPriorityId = new PatRefPriorityId();
        //
        patRefPriorityId.patId = patData.patId;
        patRefPriorityId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patRefPriorityId.item = refPriority."sequence" as int;
        patRefPriority.id = patRefPriorityId;

        // patRefCited.patData = patData;
        patRefPriority.createDate = new Date();

        if (!!refPriority."document-id") {

            patRefPriority.rawAppNo = refPriority."document-id"."doc-number";

            // if (CountryUtil.isOriginPTO(patData.country)) {
            if (false) {
                // TODO: 原有PTO判斷 => 後補程式處理
                println "refPriority = ${refPriority}"
                throw new Exception("todo: pat_ref_priority docNo error");
            } else {
                patRefPriority.appNo = refPriority."document-id"."doc-number";
            }

            if (!!refPriority."document-id"."country") {
                patRefPriority.country = refPriority."document-id"."country"
            }

            if (!!refPriority."document-id"."date") {
                patRefPriority.appDate = DateUtil.parseDate(refPriority."document-id"."date" as String)
            }

            patRefPriority.priType = Constants.PRIORITY_TYPE_UNKNOW;

            // 優先權資料是否存在於app_data中, 存在的話寫入app_id, 使用country,app_no至app_data查詢, 寫入對應到的app_id
            if (!!patRefPriority.country && !!patRefPriority.appNo && !!patRefPriority.appDate) {

                // TODO: 加入即有PTO規則判斷 => 後補程式處理
                String country = patRefPriority.country;
                String appNo = patRefPriority.country + patRefPriority.appNo;
                Date appDate = patRefPriority.appDate

                /*
                 * 測試資料:
                 * String country = "DE";
                 * String appNo = "DE2001103150";
                 * Date appDate = DateUtil.parseDate("2001-01-24");
                 */
                List<AppData> appDataList = AppDataHelper.queryByCondition(country, appNo, appDate);
                if (!!appDataList) {
                    if (appDataList.size() > 1) {
                        throw new Exception("priority data query over 1...");
                    }
                    patRefPriority.appData = appDataList.get(0);
                }
            }

        }   // end if (!!refPriority."document-id")

        return patRefPriority;

    }   // end getDocdbRefPriority


    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static getPatRefCitedUS(DBObject biblio, PatData patData, Date now) {
        // patcit
        List<PatRefCited> patRefCitedList = new ArrayList<PatRefCited>();
        List<PatRefCitedCls> patRefCitedClsList = new ArrayList<PatRefCitedCls>();

        // nplcit
        List<PatRefCitedNpl> patRefCitedNplList = new ArrayList<PatRefCitedNpl>();
        List<PatRefCitedNplCls> patRefCitedNplClsList = new ArrayList<PatRefCitedNplCls>();

        def referencesCited = biblio."references-cited" ?: biblio."us-references-cited";
        if (!!referencesCited) {

            def citations = referencesCited."citation" ?: referencesCited."us-citation";

            if (!!citations) {

                int patcitItem = Constants.ZERO;
                int nplcitItem = Constants.ZERO;
                int patcitClsItem = Constants.ZERO;
                int nplcitClsItem = Constants.ZERO;
                int citationType = Constants.ZERO;

                citations.each {citation ->
                    PatRefCited patRefCited = null;
                    // patcit
                    if (!!citation?."patcit"?."document-id") {

                        citationType = Constants.CITATION_TYPE_PATCIT;

                        DBObject citedDoc = citation."patcit"."document-id";

                        PatRefCitedId id = new PatRefCitedId();
                        id.patId = patData.patId;
                        id.sourceId = patData.defaultSourceId;
                        id.item = ++patcitItem;

                        patRefCited = new PatRefCited();
                        patRefCited.id = id;

                        if (StringUtils.isBlank(citedDoc."country")) {
                            throw new Exception("error : citation doc country is null");
                        }

                        if (StringUtils.isBlank(citedDoc."doc-number")) {
                            throw new Exception("error : citation doc number is null");
                        }

                        patRefCited.country = citedDoc."country";
                        // 將raw_doc_no依據[號碼規則]進行格式化
                        patRefCited.rawDocNo = citedDoc."doc-number";
                        if (citedDoc."country" == "US") {
                            patRefCited.docNo = patRefCited.rawDocNo.replace("/", "");

                        } else {
                            // TODO:
                            patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, citedDoc."country");

                            if (StringUtils.isBlank(patRefCited.docNo)) {
                                throw new Exception("citedDoc country is not US");
                            }
                        }

                        String docDateStr = citedDoc?."date";
                        Date docDate = null;
                        if (!!docDateStr) {
                            String docDateStrReplaceLastZero = docDateStr.reverse().replaceFirst(/^0?(?!$)/, "1").reverse();
                            docDate = DateUtil.parseDate(docDateStrReplaceLastZero);
                        }

                        // cited_pat_id
                        // 引證資料是否存在於pat_data中,存在的話寫入pat_id,使用country,docnum,kind至pat_data查詢,寫入對應到的pat_id
                        List<PatData> citedPatDataList = PatDataHelper.queryByCondition(citedDoc."country", patRefCited.docNo, "", docDate);
                        if (!!citedPatDataList) {
                            if (citedPatDataList.size() == 1) {
                                patRefCited.citedPatId = citedPatDataList.get(0).patId;
                            } else {
                                //                                throw new Exception("cited data query over 1, patcitItem: $patcitItem");
                                println "無法判定citedPatId"
                            }
                        }

                        if (!!citedDoc."kind") {
                            patRefCited.kindCode = citedDoc."kind";
                        }

                        if (!!citedDoc."name") {
                            patRefCited.inventorName = citedDoc."name"."value";
                        }

                        // docDate
                        if (!!citedDoc."date") {
                            patRefCited.rawDocDate = citedDoc."date";
                            // 無 docDate 為無法轉換之日期格式則不放, ex:19140400
                            patRefCited.docDate = DateUtil.parseDate(citedDoc."date");
                        }
                        // patRefCited.appDate => 找不到有[application-date]的資料

                        // cited_by_type
                        patRefCited.citedByType = CommonEnum.CITEDBYTYPE.findCitedByTypeCode((!!citation."category")?citation."category"[0]:null);
                        patRefCited.createDate = now;

                        patRefCitedList.add(patRefCited);
                    } // end of if !!citation?."patcit"?."document-id"

                    // nplcit
                    if (!!citation?."nplcit"?."othercit") {

                        citationType = Constants.CITATION_TYPE_NPLCIT;

                        PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
                        patRefCitedNpl.citedByType = CommonEnum.CITEDBYTYPE.findCitedByTypeCode((!!citation."category")?citation."category"[0]:null);
                        // citation,nplcit之json內容
                        patRefCitedNpl.nplJson = citation."nplcit" as String;
                        // biblio
                        if (!!biblio."otherReferences"[nplcitItem]) {
                            patRefCitedNpl.nplText = biblio."otherReferences"[nplcitItem];
                        } else {
                            patRefCitedNpl.nplText = citation."nplcit"."othercit"."value"[0];
                        }

                        patRefCitedNpl.createDate = now;

                        PatRefCitedNplId id = new PatRefCitedNplId();
                        id.patId = patData.patId;
                        id.sourceId = patData.defaultSourceId;
                        id.item = ++nplcitItem;
                        patRefCitedNpl.id = id;

                        patRefCitedNplList.add(patRefCitedNpl);
                    } //end of !!citation."nplcit"

                    if (citationType == Constants.CITATION_TYPE_PATCIT) {
                        // patcit cls
                        if (!!citation."classification-national") {
                            PatRefCitedCls patRefCitedCls = new PatRefCitedCls();
                            PatRefCitedClsId id = new PatRefCitedClsId();
                            id.citedItem = patcitItem;
                            id.patId = patData.patId;
                            id.sourceId = patData.defaultSourceId;
                            id.item = ++patcitClsItem;
                            patRefCitedCls.id = id;
                            patRefCitedCls.createDate = now;

                            if (!!citation."classification-national"."country") {
                                if (citation."classification-national"."country" != "US") {
                                    throw new Exception("classification-national country is not US");
                                }
                                patRefCitedCls.classType = Constants.CLS_NAME_USPC;
                            } else {
                                throw new Exception("error : citation Uspc Country is null");
                            }

                            if (!!citation."classification-national"."main-classification") {
                                String uspcStr = citation."classification-national"."main-classification";
                                String uspcFormat = "";
                                try {
                                    uspcFormat = PatClsUtil.formatClsUspc(uspcStr);
                                } catch (Exception e) {
                                    logger.error("patcit cls format error : " + e);
                                }

                                patRefCitedCls.defectFlag = Constants.CLS_DEFECT_FLAG_FALSE;
                                if (!!uspcFormat) {
                                    patRefCitedCls.classText = uspcFormat;
                                } else {
                                    patRefCitedCls.classText = uspcStr;
                                    // TODO: unformat flag on
                                    patRefCitedCls.defectFlag = Constants.CLS_DEFECT_FLAG_TRUE;
                                }

                            } else {
                                throw new Exception("error : citation.classification-national.main-classification is null");
                            }

                            patRefCitedClsList.add(patRefCitedCls);
                        }

                    } else if (citationType == Constants.CITATION_TYPE_NPLCIT) {
                        // nplcit cls
                        if (!!citation?."classification-national") {

                            PatRefCitedNplCls patRefCitedNplCls = new PatRefCitedNplCls();
                            PatRefCitedNplClsId id = new PatRefCitedNplClsId();
                            id.citedItem = nplcitItem;
                            id.patId = patData.patId;
                            id.sourceId = patData.defaultSourceId;
                            id.item = ++nplcitClsItem;
                            patRefCitedNplCls.id = id;

                            if (!!citation."classification-national"?."country") {
                                if (citation."classification-national"."country" != "US") {
                                    throw new Exception("classification-national country is not US");
                                }
                                patRefCitedNplCls.classType = Constants.CLS_NAME_USPC;
                            } else {
                                throw new Exception("error : citation Uspc Country is null");
                            }

                            if (!!citation."classification-national"?."main-classification") {
                                String uspcStr = citation."classification-national"."main-classification";
                                String uspcFormat = "";
                                try {
                                    uspcFormat = PatClsUtil.formatClsUspc(uspcStr);
                                } catch (Exception e) {
                                    logger.error("nplcit cls format error : " + e);
                                }
                                // 無法format時，classText欄位放原始資料，並註記flag
                                patRefCitedNplCls.defectFlag = Constants.CLS_DEFECT_FLAG_FALSE;
                                if (!!uspcFormat) {
                                    patRefCitedNplCls.classText = uspcFormat;
                                } else {
                                    patRefCitedNplCls.classText = uspcStr;
                                    // TODO: unformat flag on
                                    patRefCitedNplCls.defectFlag = Constants.CLS_DEFECT_FLAG_TRUE;
                                }

                            } else {
                                throw new Exception("error : citation.classification-national.main-classification is null");
                            }
                            patRefCitedNplClsList.add(patRefCitedNplCls);
                        }

                    } else {
                        throw new Exception("citation type error");
                    }

                } // end of loop citations
            } // end of if citations
        } // end of if referencesCited

        return [patRefCitedList, patRefCitedClsList, patRefCitedNplList, patRefCitedNplClsList];

    }

    /**
     * @param root
     * @param patData
     * @param now
     * @return
     */
    public static List<PatRefCited> genPatRefCitedHTMLUS(def root, PatData patData, Date now) {

        List<PatRefCited> patRefCitedList = new ArrayList<>();
        if (!!root."refPatents") {
            root."refPatents".eachWithIndex {refPatent, item ->
                PatRefCited patRefCited = new PatRefCited();
                PatRefCitedId id = new PatRefCitedId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item + 1;
                patRefCited.id = id;

                if (StringUtils.isBlank(refPatent."countryCode")) {
                    throw new Exception("error : citation doc country is null");
                }

                if (StringUtils.isBlank(refPatent."patentNo")) {
                    throw new Exception("error : citation doc number is null");
                }

                patRefCited.citedByType = Constants.CITED_BY_TYPE_UNKNOW;
                patRefCited.createDate = now;

                if (!!refPatent."countryCode") {
                    patRefCited.country = refPatent."countryCode";
                }

                if (!!refPatent."primaryInventor") {
                    patRefCited.inventorName = refPatent."primaryInventor";
                }

                // 將raw_doc_no依據[號碼規則]進行格式化
                patRefCited.rawDocNo = refPatent."patentNo";
                if (refPatent."countryCode" == "US") {
                    patRefCited.docNo = patRefCited.rawDocNo.replace("/", "");

                } else {
                    // TODO:
                    patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, refPatent."countryCode");

                    if (StringUtils.isBlank(patRefCited.docNo)) {
                        throw new Exception("citedDoc country is not US");
                    }
                }

                if (!!refPatent."dateOfPatent") {
                    // docDate
                    patRefCited.rawDocDate = refPatent."dateOfPatent";
                    // 無 docDate 為無法轉換之日期格式則不放, ex:19140400
                    patRefCited.docDate = DateUtil.parseDate(refPatent."dateOfPatent");
                }

                patRefCitedList.add(patRefCited);
            }
        }

        return patRefCitedList;
    }

    /**
     * @param root
     * @param patData
     * @param now
     * @return
     */
    public static List<PatRefCitedNpl> genPatRefCitedNplHTMLUS(def root, PatData patData, Date now) {
        List<PatRefCitedNpl> patRefCitedNplList = new ArrayList<>();
        if (!!root."refOtherDocs") {

            root."refOtherDocs".eachWithIndex {refOtherDoc, item ->

                PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
                patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_UNKNOW;
                // citation,nplcit之json內容
                patRefCitedNpl.nplJson = refOtherDoc;
                patRefCitedNpl.nplText = refOtherDoc."description"
                patRefCitedNpl.createDate = now;

                PatRefCitedNplId id = new PatRefCitedNplId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item + 1;
                patRefCitedNpl.id = id;

                patRefCitedNplList.add(patRefCitedNpl);
            }
        }

        return patRefCitedNplList;
    }

    private static Map relatedTypeMap =
    [
        "addition"                          : Constants.RELATED_TYPE_CODE_ADDITION,
        "division"                          : Constants.RELATED_TYPE_CODE_DIVISION,
        "continuation"                      : Constants.RELATED_TYPE_CODE_CONTINUATION,
        "continuation-in-part"              : Constants.RELATED_TYPE_CODE_CONTINUATION_IN_PART,
        "continuing-reissue"                : Constants.RELATED_TYPE_CODE_CONTINUING_REISSUE,
        "reissue"                           : Constants.RELATED_TYPE_CODE_REISSUE,
        "us-divisional-reissue"             : Constants.RELATED_TYPE_CODE_US_DIVISIONAL_REISSUE,
        "reexamination"                     : Constants.RELATED_TYPE_CODE_REEXAMINATION,
        "us-reexamination-reissue-merger"   : Constants.RELATED_TYPE_CODE_US_REEXAMINATION_REISSUE_MERGER,
        "substitution"                      : Constants.RELATED_TYPE_CODE_SUBSTITUTION,
        "us-provisional-application"        : Constants.RELATED_TYPE_CODE_US_PROVISIONAL_APPLICATION,
        "utility-model-basis"               : Constants.RELATED_TYPE_CODE_UTILITY_MODEL_BASIS,
        "correction"                        : Constants.RELATED_TYPE_CODE_CORRECTION,
        "related-publication"               : Constants.RELATED_TYPE_CODE_RELATED_PUBLICATION,
        "a-371-of-international"            : Constants.RELATED_TYPE_CODE_A_371_OF_INTERNATIONAL,
        "related-grant"                     : Constants.RELATED_TYPE_CODE_RELATED_GRANT
    ];

    /**
     * @param relatedType
     * @return
     */
    public static Integer findRelatedTypeCode(String relatedType) {

        return relatedTypeMap.get(relatedType, Constants.RELATED_TYPE_CODE_UNKNOW);
    }

    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static getPatRefParentChildDataUS(DBObject biblio, PatData patData, Date now) {

        List<PatRefRelatedParent> patRefRelatedParentList = new ArrayList<>();
        List<PatRefRelatedChild> patRefRelatedChildList = new ArrayList<>();

        int relatedType = Constants.RELATED_TYPE_CODE_UNKNOW;
        int parentItem = Constants.ZERO;
        int childItem = Constants.ZERO;

        if (!!biblio."us-related-documents") {
            def relatedDocs = biblio."us-related-documents";

            relatedDocs.each {relatedDoc ->

                String k = relatedDoc.key;
                int relatedTypeCode = findRelatedTypeCode(k);

                if (k == "us-provisional-application") {
                    relatedDocs.get(k).each {
                        PatRefRelatedParent patRefRelatedParent = PatRefUtil.initPatRefRelatedParentUS(relatedTypeCode, ++parentItem, patData, now);
                        PatRefUtil.initRelatedParentAppFieldUS(patRefRelatedParent, it."document-id"[0]);
                        patRefRelatedParentList.add(patRefRelatedParent);
                    }
                } else if (k == "correction") {
                    // TODO: 13:correction<BR>
                    throw new Exception("relatedDocs.correction");
                    relatedDocs.get(k).each {
                        //
                        PatRefRelatedParent patRefRelatedParent = PatRefUtil.initPatRefRelatedParentUS(Constants.RELATED_TYPE_CODE_CORRECTION, ++parentItem, patData, now);
                        PatRefUtil.initRelatedParentAppFieldUS(patRefRelatedParent, it."document-corrected"."document-id"[0]);
                        patRefRelatedParentList.add(patRefRelatedParent);
                    }
                } else if (k == "related-publication") {
                    // 14:related-publication
                    relatedDocs.get(k).each {
                        //
                        PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent();
                        // PatRefRelatedParentId
                        PatRefRelatedParentId patRefRelatedParentId = new PatRefRelatedParentId();
                        patRefRelatedParentId.patId = patData.patId;
                        patRefRelatedParentId.sourceId = patData.defaultSourceId;
                        patRefRelatedParentId.item = ++parentItem;
                        patRefRelatedParent.id = patRefRelatedParentId;

                        patRefRelatedParent.createDate = now;
                        patRefRelatedParent.relatedType = Constants.RELATED_TYPE_CODE_RELATED_PUBLICATION;

                        def docMap = USPatDataUtil.parseDocumentDataUS(it."document-id"[0]);
                        patRefRelatedParent.rawDocNo = docMap.docNo;
                        if (docMap.country != "US") {
                            // TODO:
                            throw new Exception("patRefRelatedParent country is other country");
                        } else {
                            patRefRelatedParent.docNo = patRefRelatedParent.rawDocNo;
                        }
                        patRefRelatedParent.kindCode = docMap.kindCode;
                        patRefRelatedParent.rawDocDate = docMap.rawDate;
                        patRefRelatedParent.docDate = docMap.date;
                        patRefRelatedParent.docCountry = docMap.country;

                        List<PatData> patDataList = PatDataHelper.queryByCondition(docMap.country, patRefRelatedParent.docNo, patRefRelatedParent.kindCode);
                        if (!!patDataList) {
                            if (patDataList.size() > 1) {
                                throw new Exception("related-publication pat data query over 1...");
                            }
                            patRefRelatedParent.parentPatId = patDataList.get(0).patId;
                        }
                        patRefRelatedParentList.add(patRefRelatedParent);

                    } // end of loop related-publication
                } else {
                    relatedDocs.get(k).each {
                        (patRefRelatedParentList, patRefRelatedChildList, parentItem, childItem) = PatRefUtil.parseRelationDataUS(it
                                , relatedTypeCode, parentItem, childItem, patData, patRefRelatedParentList
                                , patRefRelatedChildList, now);
                    }
                }
            } // end of loop relatedDoc
        } // end of biblio.us-related-documents

        return [patRefRelatedParentList, patRefRelatedChildList];
    }


    /**
     * @param patRefRelatedParent
     * @param docElem
     * @return
     */
    public static initRelatedParentAppFieldUS(PatRefRelatedParent patRefRelatedParent, def docElem) {

        def docMap = USPatDataUtil.parseDocumentDataUS(docElem);

        patRefRelatedParent.rawAppNo = docMap.docNo;
        patRefRelatedParent.appCountry = docMap.country;

        // appNO
        if (patRefRelatedParent.rawAppNo =~ /\d{8}/ || patRefRelatedParent.rawAppNo =~ /D\d{6}/
        || patRefRelatedParent.rawAppNo =~ /[0-9]{2}\/[0-9]{3}\,?[0-9]{3}/) {

            patRefRelatedParent.appNo = PatNumberUtil.getAppNoUS(patRefRelatedParent.rawAppNo);
        } else if (patRefRelatedParent.rawAppNo =~ /(?i)PCT.*/){
            // TODO:
            patRefRelatedParent.appNo = patRefRelatedParent.rawAppNo;
        } else {
            patRefRelatedParent.appNo = patRefRelatedParent.rawAppNo;
            println "error : PatRefRelatedParent appNo does not format, rawAppNo : $patRefRelatedParent.rawAppNo, country: $docMap.country";
        }


        List<AppData> appDataList = AppDataHelper.queryByCondition(docMap.country, patRefRelatedParent.appNo);
        if (!!appDataList) {
            if (appDataList.size() > 1) {
                throw new Exception("PatRefRelatedParent AppData query over 1...");
            }
            patRefRelatedParent.parentAppId = appDataList.get(0).appId;
        }

        patRefRelatedParent.rawAppDate = docMap.rawDate;
        patRefRelatedParent.appDate = docMap.date;
    }

    /**
     * parse element relation <BR>
     * @param relation
     * @param relatedType
     * @param parentItem
     * @param childItem
     * @param patData
     * @param patRefRelatedParentList
     * @param patRefRelatedChildList
     * @return
     */
    public static parseRelationDataUS(DBObject relationParent, int relatedType, int parentItem, int childItem, PatData patData
            , List<PatRefRelatedParent> patRefRelatedParentList, List<PatRefRelatedChild> patRefRelatedChildList, Date now) {

        // 只要是 relation 一定有一個parent-doc and child-doc
        PatRefRelatedParent patRefRelatedParent = null;
        def relation = relationParent."relation";
        // parentDoc
        if (!!relation."parent-doc") {
            // init
            patRefRelatedParent = PatRefUtil.initPatRefRelatedParentUS(relatedType, ++parentItem, patData, now);
            PatRefUtil.initRelatedParentAppFieldUS(patRefRelatedParent, relation."parent-doc"."document-id");
            if (!!relation."parent-doc"."parent-status") {
                patRefRelatedParent.patStatus = relation."parent-doc"."parent-status"
            }

            // parent-grant-document
            if (!!relation."parent-doc"."parent-grant-document") {
                def parentGrantDocMap = USPatDataUtil.parseDocumentDataUS(relation."parent-doc"."parent-grant-document"."document-id"[0]);

                patRefRelatedParent.rawDocNo = parentGrantDocMap.docNo;
                if (parentGrantDocMap.country != "US") {
                    // TODO:
                    throw new Exception("parentGrantDoc country is other country");
                } else {
                    patRefRelatedParent.docNo = patRefRelatedParent.rawDocNo;
                }

                patRefRelatedParent.rawDocDate = parentGrantDocMap.rawDate;
                patRefRelatedParent.docDate = parentGrantDocMap.date;
                patRefRelatedParent.kindCode = parentGrantDocMap.kindCode;
                patRefRelatedParent.inventorName = parentGrantDocMap.name;
                patRefRelatedParent.docCountry = parentGrantDocMap.country;

                List<PatData> patDataList = PatDataHelper.queryByCondition(parentGrantDocMap.country, patRefRelatedParent.docNo, patRefRelatedParent.kindCode);
                if (!!patDataList) {
                    if (patDataList.size() > 1) {
                        throw new Exception("Related Parent data query over 1...");
                    }
                    patRefRelatedParent.parentPatId = patDataList.get(0).patId;
                }

            } // end of if parent-grant-document

            // parent-pct-document
            if (!!relation."parent-doc"."parent-pct-document") {
                def parentPctDocMap = USPatDataUtil.parseDocumentDataUS(relation."parent-doc"."parent-pct-document"."document-id"[0]);
                patRefRelatedParent.rawPctAppDate = parentPctDocMap.rawDate;
                patRefRelatedParent.pctAppDate = parentPctDocMap.date;
                patRefRelatedParent.rawPctAppNo = parentPctDocMap.docNo;
                // TODO:  pctAppNo 將raw_pct_app_no依據[號碼規則]進行格式化
                patRefRelatedParent.pctAppNo = "";

                List<AppData> pctAppDataList = AppDataHelper.queryByCondition(parentPctDocMap.country, patRefRelatedParent.appNo);
                if (!!pctAppDataList) {
                    if (pctAppDataList.size() > 1) {
                        throw new Exception("Related Parent data query over 1...");
                    }
                    patRefRelatedParent.pctAppId = pctAppDataList.get(0).appId;
                }
            } // end of if parent-pct-document

            patRefRelatedParentList.add(patRefRelatedParent);
        } // end of if parentDoc

        // child-doc
        if (!!relation."child-doc") {

            // init
            PatRefRelatedChild patRefRelatedChild = new PatRefRelatedChild();
            patRefRelatedChild.createDate = now;
            patRefRelatedChild.relatedType = relatedType;

            PatRefRelatedChildId patRefRelatedChildId = new PatRefRelatedChildId();
            patRefRelatedChildId.patId = patData.patId;
            patRefRelatedChildId.sourceId = patData.defaultSourceId;
            patRefRelatedChildId.item = ++childItem;
            patRefRelatedChild.id = patRefRelatedChildId;

            if (!!patRefRelatedParent) {
                patRefRelatedChild.parentItem = patRefRelatedParent.id.item;
            }

            def childDocMap = USPatDataUtil.parseDocumentDataUS(relation."child-doc"."document-id"[0]);

            patRefRelatedChild.rawAppDate = childDocMap.rawDate;
            patRefRelatedChild.appDate = childDocMap.date;
            patRefRelatedChild.rawAppNo = childDocMap.docNo;
            patRefRelatedChild.appCountry = childDocMap.county;

            // 將raw_app_no依據[號碼規則]進行格式化
            if (childDocMap.country != "US") {
                // TODO : other country appNo
                patRefRelatedChild.appNo = patRefRelatedChild.rawAppNo;
                println "error : patRefRelatedChild appNo does not format, rawAppNo : $patRefRelatedChild.rawAppNo, country: $childDocMap.country";
            } else {
                // appNO
                patRefRelatedChild.appNo = PatNumberUtil.getAppNoUS(patRefRelatedChild.rawAppNo);
            }

            List<AppData> childAppDataList = AppDataHelper.queryByCondition(childDocMap.country, patRefRelatedChild.appNo);
            if (!!childAppDataList) {
                if (childAppDataList.size() > 1) {
                    throw new Exception("Related Parent data query over 1...");
                }
                patRefRelatedChild.appData = childAppDataList.get(0);
            }

            patRefRelatedChildList.add(patRefRelatedChild);

        } // end of if child-doc

        return [patRefRelatedParentList, patRefRelatedChildList, parentItem, childItem];
    }

    /**
     * @param relatedType
     * @param parentItem
     * @param patData
     * @return
     */
    private static PatRefRelatedParent initPatRefRelatedParentUS(int relatedType, int parentItem, PatData patData, Date now) {

        PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent();
        patRefRelatedParent.createDate = now;
        patRefRelatedParent.relatedType = relatedType;

        PatRefRelatedParentId patRefRelatedParentId = new PatRefRelatedParentId();
        patRefRelatedParentId.patId = patData.patId;
        patRefRelatedParentId.sourceId = patData.defaultSourceId;
        patRefRelatedParentId.item = parentItem;
        patRefRelatedParent.id = patRefRelatedParentId;

        return patRefRelatedParent;
    }

    /**
     * 產生cited list,以便存入poatgresql
     * @param root
     * @param patData
     * @return
     */
    private static List<PatRefCited> genPatRefCitedEP(DBObject root, PatData patData) {
        List<PatRefCited> patRefCitedList = new ArrayList<PatRefCited>();
        int item = Constants.ZERO;
        if (!!root["SDOBI"]) {
            if (!!root["SDOBI"]["B500"]["B560"]) {
                if (!!root["SDOBI"]["B500"]["B560"]["B561"]) {
                    List citedList = root["SDOBI"]["B500"]["B560"]["B561"];
                    if (!!citedList && citedList.size() >= 1) {
                        citedList.each { cited ->
                            PatRefCited patRefCited = new PatRefCited();
                            if (cited.text.split("-").length > 2) {
                                cited.text.splitEachLine("-") { country, kindCode, docNo ->
                                    patRefCited.country = country;
                                    patRefCited.kindCode = kindCode;
                                    patRefCited.rawDocNo = docNo.replaceAll(" ", "");
                                    patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, country, null, patRefCited.kindCode, patRefCited.docDate);
                                }
                                patRefCited.createDate = patData.createDate;
                                patRefCited.citedByType = Constants.CITATION_TYPE_PATCIT;
                                List<PatData> patDataList = PatDataHelper.queryByCondition(patRefCited.country, patRefCited.docNo, patRefCited.kindCode);
                                if (!!patDataList) {
                                    if (patDataList.size() > 1) {
                                        throw new Exception("patData query more than one!");
                                    }
                                    patRefCited.citedPatId = patDataList[0].patId;
                                }
                                patRefCited.citedByType = Constants.CITED_BY_TYPE_UNKNOW;
                                PatRefCitedId id = new PatRefCitedId();
                                id.item = ++item;
                                id.patId = patData.patId;
                                id.sourceId = patData.defaultSourceId;
                                patRefCited.id = id;

                                patRefCitedList.add(patRefCited);
                            } // end if array length more than two
                        } // end patRefCitedList each loop
                    } // end patRefCiteList not null
                } // end if root["SDOBI"]["B500"]["B560"]["B561"]
            } // end patRefCitedList parent tag not null
        } else {
            if (!!root["bibliographic-data"]) {
                if (!!root["bibliographic-data"]["references-cited"]) {
                    if (!!root["bibliographic-data"]["references-cited"]["citation"]) {
                        List refCited = root["bibliographic-data"]["references-cited"]["citation"];
                        if (!!refCited && refCited.size() >=1) {
                            refCited.each { cited ->
                                PatRefCited patRefCited = new PatRefCited()
                                PatRefCitedId id = new PatRefCitedId();
                                if (!!cited["patcit"]) {
                                    patRefCited.citedByType = Constants.CITATION_TYPE_PATCIT;
                                    patRefCited.createDate = patData.createDate;
                                    int documentSize = cited["patcit"]["document-id"].size();
                                    cited["patcit"]["document-id"].each { document->
                                        if (documentSize == 1) {
                                            if (document["document-id-type"] == "docdb") {
                                                patRefCited.country = document["country"];
                                                patRefCited.kindCode = document["kind"];
                                                patRefCited.rawDocNo = document["doc-number"];
                                                patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, patRefCited.country,  null, patRefCited.kindCode, patRefCited.docDate);
                                            } else {
                                                patRefCited.rawDocNo = document["doc-number"];
                                                patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, COUNTRY.EP.getCountryName(),  null, patRefCited.kindCode, patRefCited.docDate);
                                            }
                                        } else {
                                            if (document["document-id-type"] == "docdb") {
                                                patRefCited.country = document["country"];
                                                patRefCited.kindCode = document["kind"];
                                                patRefCited.rawDocNo = document["doc-number"];
                                                patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, patRefCited.country,  null, patRefCited.kindCode, patRefCited.docDate);
                                            }
                                        }
                                    }
                                    id.patId = patData.patId;
                                    id.sourceId = patData.defaultSourceId;
                                    id.item = ++item;
                                    patRefCited.id = id;
                                    patRefCitedList.add(patRefCited);
                                } // end if cited["patcit"]
                            } // end refcited list each loop
                        } // end if refcited list not null
                    } //end if root["bibliographic-data"]["references-cited"]["citation"]
                } // end if root["bibliographic-data"]["references-cited"]
            } // end if root["bibliographic-data"]
        } // end if else EPD or OPS
        // 大部分為applicant附件資料 (EPD)
        if (!!root["ep-reference-list"]) {
            if (!!root["ep-reference-list"]["p"][1]["ul"][0]["li"]) {
                List citedList = root["ep-reference-list"]["p"][1]["ul"][0]["li"];
                citedList.each { cited ->
                    if (!!cited["patcit"]) {
                        PatRefCited patRefCited = new PatRefCited();
                        patRefCited.country = cited["patcit"][0]["document-id"]["country"];
                        // kindcode = "pct"
                        if (!!cited["patcit"][0]["document-id"]["kind"] && cited["patcit"][0]["document-id"]["kind"].size() <= 2) {
                            patRefCited.kindCode = cited["patcit"][0]["document-id"]["kind"];
                        } else {
                            patRefCited.kindCode = null;
                        }
                        patRefCited.rawDocNo = cited["patcit"][0]["document-id"]["doc-number"];
                        patRefCited.docNo = PatNumberUtil.formatDocNoByCountry(patRefCited.rawDocNo, patRefCited.country,  null, patRefCited.kindCode, patRefCited.docDate);
                        patRefCited.createDate = patData.createDate;
                        patRefCited.citedByType = Constants.CITATION_TYPE_PATCIT;
                        List<PatData> patDataList = PatDataHelper.queryByCondition(patRefCited.country, patRefCited.docNo, patRefCited.kindCode, null);
                        if (!!patDataList) {
                            if (patDataList.size() > 1) {
                                throw new Exception("patData query more than one!");
                            }
                            patRefCited.citedPatId = patDataList[0].patId;
                        }
                        patRefCited.citedByType = Constants.CITED_BY_TYPE_APPLICANT;
                        PatRefCitedId id = new PatRefCitedId();

                        id.item = ++item;
                        id.patId = patData.patId;
                        id.sourceId = patData.defaultSourceId;
                        patRefCited.id = id;
                        patRefCitedList.add(patRefCited);
                    } // end if cited["patcit"]
                } // end cited list each loop
            } // end if root["ep-reference-list"]["p"][1]["ul"][0]["li"]
        } // end if root["ep-reference-list"]
        return patRefCitedList;
    }

    /**
     * 產生citednpl list,以便postgresql存入
     * @param root
     * @param patData
     * @return
     */
    private static List<PatRefCitedNpl> genPatRefCitedNplEP(DBObject root, PatData patData) {
        List<PatRefCitedNpl> patRefCitedNplList = new ArrayList<PatRefCitedNpl>();
        int item = Constants.ZERO;
        if (!!root["SDOBI"]) {
            if (!!root["SDOBI"]["B500"]["B560"]) {
                if (!!root["SDOBI"]["B500"]["B560"]["B562"]) {
                    List citedNplList = root["SDOBI"]["B500"]["B560"]["B562"];
                    if (!!citedNplList  && citedNplList.size() >= 1) {
                        citedNplList.each { npl ->
                            PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
                            patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_UNKNOW;
                            patRefCitedNpl.createDate = patData.lastUpdDate;
                            patRefCitedNpl.nplJson = npl;
                            patRefCitedNpl.nplText = npl.text;

                            PatRefCitedNplId id = new PatRefCitedNplId();
                            id.patId = patData.patId;
                            id.item = ++item;
                            id.sourceId = patData.defaultSourceId;
                            patRefCitedNpl.id = id;

                            patRefCitedNplList.add(patRefCitedNpl);
                        } // end patRefCitedNplList each loop
                    } // end if patRefCitedNplList not null
                } // end if patRefCitedNpl tag not null
            } //end if patRefCitedNplList parent tag not null
        } else {
            if (!!root["bibliographic-data"]) {
                if (!!root["bibliographic-data"]["references-cited"]) {
                    if (!!root["bibliographic-data"]["references-cited"]["citation"]) {
                        List refCitedNpl = root["bibliographic-data"]["references-cited"]["citation"];
                        if (!!refCitedNpl && refCitedNpl.size() >=1 ) {
                            refCitedNpl.each { Map citedNpl ->
                                PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl()
                                PatRefCitedNplId id = new PatRefCitedNplId();
                                if (!!citedNpl["nplcit"]) {
                                    patRefCitedNpl.createDate = patData.lastUpdDate;
                                    patRefCitedNpl.nplText = citedNpl["nplcit"]["text"];
                                    patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_UNKNOW;

                                    id.patId = patData.patId;
                                    id.sourceId = patData.defaultSourceId;
                                    id.item = ++item;
                                    patRefCitedNpl.nplJson = citedNpl;
                                    patRefCitedNpl.id = id;

                                    patRefCitedNplList.add(patRefCitedNpl);
                                } // end citedNpl list each loop
                            } // end if citedNpl list not null
                        } // end if root["bibliographic-data"]["references-cited"]["citation"]
                    } // end if root["bibliographic-data"]["references-cited"]
                } // end if root["bibliographic-data"]["references-cited"]
            } // end if root["bibliographic-data"]
        } // end if else EPD or OPS
        if (!!root["ep-reference-list"]) {
            if (!!root["ep-reference-list"]["p"][1]["ul"][0]["li"]) {
                List citedList = root["ep-reference-list"]["p"][1]["ul"][0]["li"];
                citedList.each { cited ->
                    if (!!cited["nplcit"]) {
                        PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
                        if (cited["nplcit"][0]["article"]["atl"] != "") {
                            patRefCitedNpl.nplText = cited["nplcit"][0]["article"]["atl"];
                        } else if (!!cited["nplcit"][0]["article"]["serial"]) {
                            patRefCitedNpl.nplText = cited["nplcit"][0]["article"]["serial"]["sertitle"];
                        } else if (!!cited["nplcit"][0]["article"]["book"]["imprint"]) {
                            //                        The ALHOA System - Another Alternative for Computer Communications. 37, AFIPS Press, 1970, pages. 281 - 285
                            patRefCitedNpl.nplText = cited["nplcit"][0]["article"]["book"]["book-title"][0] + ". ";
                            if (!!cited["nplcit"][0]["article"]["book"]["vid"]) {
                                patRefCitedNpl.nplText += cited["nplcit"][0]["article"]["book"]["vid"] + ", ";
                            }
                            if (!!cited["nplcit"][0]["article"]["book"]["imprint"]["name"]["value"]) {
                                patRefCitedNpl.nplText += cited["nplcit"][0]["article"]["book"]["imprint"]["name"]["value"] + ", ";
                            }
                            if (!!cited["nplcit"][0]["article"]["book"]["imprint"]["pubdate"]) {
                                if (!!cited["nplcit"][0]["article"]["book"]["imprint"]["pubdate"][0]["sdate"]) {
                                    patRefCitedNpl.nplText += cited["nplcit"][0]["article"]["book"]["imprint"]["pubdate"][0]["sdate"][0][0..3] + ", ";
                                }
                            }
                            if (!!cited["nplcit"][0]["article"]["book"]["location"]) {
                                patRefCitedNpl.nplText +=  "pages. ";
                                if (!!cited["nplcit"][0]["article"]["book"]["location"][0]["pp"]) {
                                    if (!!cited["nplcit"][0]["article"]["book"]["location"][0]["pp"][0]["ppf"][0]) {
                                        patRefCitedNpl.nplText += cited["nplcit"][0]["article"]["book"]["location"][0]["pp"][0]["ppf"][0] + " - ";
                                    }
                                    if (!!cited["nplcit"][0]["article"]["book"]["location"][0]["pp"][0]["ppl"][0]) {
                                        patRefCitedNpl.nplText += cited["nplcit"][0]["article"]["book"]["location"][0]["pp"][0]["ppl"][0];
                                    }
                                }
                            }
                        } else if (!!cited["nplcit"][0]["article"]["book"]) {
                            patRefCitedNpl.nplText = cited["nplcit"][0]["article"]["book"]["book-title"][0] + ". ";
                        }
                        patRefCitedNpl.nplJson = cited["nplcit"][0]["article"];
                        patRefCitedNpl.createDate = patData.lastUpdDate;
                        patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_EXAMINER;
                        PatRefCitedNplId id = new PatRefCitedNplId();

                        id.item = ++item;
                        id.patId = patData.patId;
                        id.sourceId = patData.defaultSourceId;
                        patRefCitedNpl.id = id;

                        patRefCitedNplList.add(patRefCitedNpl);
                    } // end if cited["nplcit"]
                } // end citedNpl each loop
            } // end if root["ep-reference-list"]["p"][1]["ul"][0]["li"]
        } // end if root["ep-reference-list"]
        return patRefCitedNplList;
    }

    /**
     * 產生pct data,以便postgresql存入
     * @param root
     * @param patData
     * @return
     */
    private static PatRefPct genPatRefPctEP(DBObject root, PatData patData) {
        PatRefPct patRefPct;
        if (!!root["SDOBI"]) {
            if (!!root["SDOBI"]["B800"]) {
                if (!!root["SDOBI"]["B800"]["B860"]) {
                    DBObject pct = root["SDOBI"]["B800"]["B860"][0];
                    DBObject wo = null;
                    if (!!root["SDOBI"]["B800"]["B870"]) {
                        wo = root["SDOBI"]["B800"]["B870"][0];
                    }
                    if (!!pct) {
                        patRefPct = new PatRefPct();
                        patRefPct.patId = patData.patId;
                        patRefPct.rawAppNo = pct["B861"]["dnum"]["anum"];
                        patRefPct.appNo = PatNumberUtil.getAppNoWO(patRefPct.rawAppNo);
                        if (!patRefPct.appNo || patRefPct.appNo == "") {
                            throw new Exception("no wo application number match");
                        }
                        List<AppData> existsAppData = AppDataHelper.queryByCondition(COUNTRY.WO.getCountryName(), patRefPct.appNo);
                        if (!!existsAppData) {
                            if (existsAppData.size() > 1) {
                                throw new Exception("AppData query result more than one!")
                            }
                            patRefPct.appData = existsAppData[0];
                        }
                        patRefPct.rawAppDate = pct["B861"]["date"];
                        patRefPct.appDate = DateUtil.parseDate(patRefPct.rawAppDate);
                        if (!!wo && !wo["B871"]["dnum"]["pnum"].toString().contains("*")) {
                            patRefPct.rawPublicNo = wo["B871"]["dnum"]["pnum"];
                            patRefPct.publicNo = new EPPatDataProcess().genWoPublicNo(patRefPct.rawPublicNo);
                            patRefPct.rawPublicDate = wo["B871"]["date"];
                            patRefPct.publicDate = DateUtil.parseDate(patRefPct.rawPublicDate);
                            patRefPct.publicGazetteNo = wo["B871"]["bnum"];
                            List<PatData> existsPatData;
                            if (!!patRefPct.publicDate) {
                                existsPatData = PatDataHelper.queryByCondition(COUNTRY.WO.getCountryName(), patRefPct.publicNo, patRefPct.publicDate)
                            } else {
                                existsPatData = PatDataHelper.queryByCondition(COUNTRY.WO.getCountryName(), patRefPct.publicNo, null, patRefPct.publicDate)
                            }
                            if (!!existsPatData) {
                                if (existsPatData.size() > 1) {
                                    // throw new Exception("pct query patData result more than one!");
                                    Date newDate = DateUtil.parseDate(new Date());
                                    existsPatData.each { patDatas ->
                                        Date oldDate = patDatas.docDate;
                                        if (oldDate < newDate) {
                                            newDate = oldDate;
                                            patRefPct.publicPatId = existsPatData[0]["patId"];
                                        }
                                    }
                                } else {
                                    patRefPct.publicPatId = existsPatData[0]["patId"];
                                }
                            }
                        }
                        patRefPct.createDate = patData.lastUpdDate;
                    } // end pct list each loop
                } // end if pct list not null
            } //end if pct list parent tag not null
        }
        //            if (!!root["bibliographic-data"]) {
        //                if (!!root["bibliographic-data"]["priority-claims"]) {
        //                    if (!!root["bibliographic-data"]["priority-claims"]["priority-claim"]) {
        //                        List pcts = root["bibliographic-data"]["priority-claims"]["priority-claim"];
        //                        pcts.each { pct ->
        //                            if (pct["document-id"][0]["doc-number"].toString().matches("[A-Z]{2}\\d+[A-Z]{2}\\d+")) {
        //                                String country = pct["document-id"][0]["doc-number"][0..1];
        //                                if (pct["kind"] == "national" && country == "WO") {
        //                                    patRefPct = new PatRefPct();
        //                                    patRefPct.rawAppDate = pct["document-id"][0]["date"];
        //                                    patRefPct.appDate = DateUtil.parseDate(patRefPct.rawAppDate);
        //                                    patRefPct.rawAppNo = pct["document-id"][0]["doc-number"];
        //                                    String fixRawAppNo = patRefPct.rawAppNo[6..7] + patRefPct.rawAppNo[2..5] + StringUtil.leftPad(patRefPct.rawAppNo[8..-1], 6, "0");
        //                                    patRefPct.appNo = PatNumberUtil.getAppNoWO(fixRawAppNo);
        //                                    patRefPct.createDate = patData.lastUpdDate;
        //                                    patRefPct.patId = patData.patId;
        //                                    List<AppData> existsAppData = AppDataHelper.queryByCondition(COUNTRY.WO.getCountryName(), patRefPct.appNo, patRefPct.appDate);
        //                                    if (!!existsAppData) {
        //                                        if (existsAppData.size() > 1) {
        //                                            throw new Exception("AppData query result more than one!")
        //                                        }
        //                                        patRefPct.appData = existsAppData[0];
        //                                    } // end if existsAppData
        //                                } // end if pct["kind"] == "national" && country == "WO"
        //                            }
        //                        } // end if pcts each loop
        //                    } // end if root["bibliographic-data"]["priority-claims"]["priority-claim"]
        //                } // end if root["bibliographic-data"]["priority-claims"]
        //            } // end if root["bibliographic-data"]
        return patRefPct;
    }
    /**
     * 產生priority list,以便postgresql存入
     * @param root
     * @param patData
     * @return
     */
    private static List<PatRefPriority> genPatRefPriorityListEP(DBObject root, PatData patData) {
        List<PatRefPriority> patRefPriorityList = new ArrayList<PatRefPriority>();
        if (!!root["SDOBI"]) {
            if (!!root["SDOBI"]["B300"]) {
                List priorityNoList = root["SDOBI"]["B300"]["B310"];
                List priorityCountryList = root["SDOBI"]["B300"]["B330"];
                List priorityDateList = root["SDOBI"]["B300"]["B320"];
                if (!!priorityNoList && priorityNoList.size() >= 1) {
                    priorityNoList.eachWithIndex { priorityNo, index ->
                        PatRefPriority patRefPriority = new PatRefPriority();
                        patRefPriority.rawAppDate = priorityDateList[index]["date"];
                        patRefPriority.appDate = DateUtil.parseDate(patRefPriority.rawAppDate);
                        patRefPriority.country = priorityCountryList[index]["ctry"];
                        patRefPriority.rawAppNo = priorityNo;
                        // TODO: normalize appNo
                        patRefPriority.appNo = priorityNo;
                        patRefPriority.priType = CommonEnum.PRIORITYTYPE.findPriorityTypeCode();

                        List<AppData> existsAppData = AppDataHelper.queryByCondition(patRefPriority.country, patRefPriority.appNo, patRefPriority.appDate);
                        if (!!existsAppData) {
                            if (existsAppData.size() > 1) {
                                throw new Exception("priority appData query result more than one");
                            }
                            patRefPriority.appData = existsAppData[0];
                        }
                        PatRefPriorityId id = new PatRefPriorityId();
                        id.item = ++index;
                        id.sourceId = patData.defaultSourceId;
                        id.patId = patData.patId;
                        patRefPriority.id = id;
                        patRefPriority.createDate = patData.lastUpdDate;

                        patRefPriorityList.add(patRefPriority);
                    } // end priority patents each loop
                } // end if priority patent list not null
            } // end if priority patent list parent tag not null
        } else {
            if (!!root["bibliographic-data"]["priority-claims"]) {
                if (!!root["bibliographic-data"]["priority-claims"]["priority-claim"]) {
                    List priorityList = root["bibliographic-data"]["priority-claims"]["priority-claim"];
                    if (!!priorityList && priorityList.size() >= 1) {
                        int item = Constants.ZERO;
                        priorityList.each { prioritys ->
                            PatRefPriority patRefPriority = new PatRefPriority();
                            PatRefPriorityId id = new PatRefPriorityId();
                            prioritys["document-id"].each { priority ->
                                if (priority["document-id-type"] == "epodoc" && priority["doc-number"][0..1] != "WO") {
                                    patRefPriority.rawAppDate = priority["date"];
                                    patRefPriority.appDate = DateUtil.parseDate(patRefPriority.rawAppDate);
                                    patRefPriority.rawAppNo = priority["doc-number"];
                                    patRefPriority.country = priority["doc-number"][0..1];
                                    patRefPriority.appNo = priority["doc-number"];

                                    List<AppData> existsAppData = AppDataHelper.queryByCondition(patRefPriority.country, patRefPriority.appNo);
                                    if (!!existsAppData) {
                                        if (existsAppData.size() > 1) {
                                            throw new Exception("ops priority query appdata more than one!");
                                        }
                                        patRefPriority.appData = existsAppData[0];
                                    }
                                    patRefPriority.createDate = patData.lastUpdDate;
                                    id.item = ++item;
                                    id.sourceId = patData.defaultSourceId;
                                    id.patId = patData.patId;
                                    patRefPriority.id = id;

                                    patRefPriorityList.add(patRefPriority);
                                } // end if priority["document-id-type"] == "epodoc" && priority["doc-number"][0..1] != "WO"
                                if (prioritys["document-id"][0]["doc-number"].toString().matches("[A-Z]{2}\\d+[A-Z]{2}\\d+")) {
                                    String country = prioritys["document-id"][0]["doc-number"][0..1];
                                    if (prioritys["kind"] == "national" && country == "WO") {
                                        patRefPriority.rawAppDate = prioritys["document-id"][0]["date"];
                                        patRefPriority.appDate = DateUtil.parseDate(patRefPriority.rawAppDate);
                                        patRefPriority.rawAppNo = prioritys["document-id"][0]["doc-number"];
                                        String fixRawAppNo = patRefPriority.rawAppNo[6..7] + patRefPriority.rawAppNo[2..5] + StringUtil.leftPad(patRefPriority.rawAppNo[8..-1], 6, "0");
                                        patRefPriority.appNo = PatNumberUtil.getAppNoWO(fixRawAppNo);
                                        patRefPriority.createDate = patData.lastUpdDate;
                                        id.item = ++item;
                                        id.sourceId = patData.defaultSourceId;
                                        id.patId = patData.patId;
                                        patRefPriority.id = id;
                                        List<AppData> existsAppData = AppDataHelper.queryByCondition(COUNTRY.WO.getCountryName(), patRefPriority.appNo, patRefPriority.appDate);
                                        if (!!existsAppData) {
                                            if (existsAppData.size() > 1) {
                                                throw new Exception("AppData query result more than one!")
                                            }
                                            patRefPriority.appData = existsAppData[0];
                                        } // end if existsAppData
                                    } // end if pct["kind"] == "national" && country == "WO"
                                }
                            } // end prioritys["document-id"] each loop
                        } // end priorityList each loop
                    } // end if priorityList && priorityList.size() >= 1
                } // end if root["bibliographic-data"]["priority-claims"]["priority-claim"]
            } // end if root["bibliographic-data"]["priority-claims"]
        } // end if else EPD or OPS
        return patRefPriorityList;
    }

    /**
     * 產生ref related parent and child,以便postgresql存入
     * @param root
     * @param patData
     * @param prs
     */
    private static void savePatRefRelatedParentAndChildEP(DBObject root, PatData patData, PatRefService prs, AppData appData) {
        List<PatRefRelatedParent> patRefRelatedParentList = new ArrayList<PatRefRelatedParent>();
        PatRefRelatedParent patRefRelatedParent;
        List<PatRefRelatedChild> patRefRelatedChildList = new ArrayList<PatRefRelatedChild>();
        PatRefRelatedChild patRefRelatedChild;
        int item = Constants.ZERO, typeCode;

        if (!!root["SDOBI"]) {
            if (!!root["SDOBI"]["B200"]) {
                if (!!root["SDOBI"]["B200"]["B270"]) {
                    ++item;
                    patRefRelatedParent = new PatRefRelatedParent();
                    DBObject proviApplication = root["SDOBI"]["B200"]["B270"];
                    patRefRelatedParent.relatedType = Constants.RELATED_TYPE_CODE_US_PROVISIONAL_APPLICATION;
                    patRefRelatedParent.rawAppNo = proviApplication["dnum"]["anum"];
                    if (proviApplication["ctry"] != COUNTRY.EP.getCountryName()) {
                        patRefRelatedParent.appNo = patRefRelatedParent.rawAppNo;
                    } else {
                        patRefRelatedParent.appNo = PatNumberUtil.getAppNoEP(patRefRelatedParent.rawAppNo, proviApplication["ctry"]);patRefRelatedParent.rawAppNo
                    }

                    patRefRelatedParent.rawAppDate = proviApplication["date"];
                    patRefRelatedParent.appDate = DateUtil.parseDate(patRefRelatedParent.rawAppDate);
                    if (!!proviApplication["dnum"]["pnum"]) {
                        patRefRelatedParent.rawDocNo = proviApplication["dnum"]["pnum"];
                        patRefRelatedParent.docNo = PatNumberUtil.formatDocNoByCountry(patRefRelatedParent.rawDocNo, proviApplication["ctry"],  null, null, patRefRelatedParent.docDate);
                    }
                    patRefRelatedParent.createDate = patData.lastUpdDate;

                    PatRefRelatedParentId id = new PatRefRelatedParentId();
                    id.patId = patData.patId;
                    id.item = ++item;
                    id.sourceId = patData.defaultSourceId;
                    patRefRelatedParent.id = id;

                    patRefRelatedParentList.add(patRefRelatedParent);
                } // end if provisional application not null
            } // end if provisional application parent tag not null
            if (!!root["SDOBI"]["B600"]) {
                if (!!root["SDOBI"]["B600"]["B610"]) {
                    List additionList = root["SDOBI"]["B600"]["B610"];
                    if (!!additionList && additionList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_ADDITION;
                        additionList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            } // end addition list each loop
                        } // end if addition list not null
                    } // end if root["SDOBI"]["B600"]["B610"]
                } // end if root["SDOBI"]["B600"]

                if (!!root["SDOBI"]["B600"]["B620"]) {
                    List divisionList = root["SDOBI"]["B600"]["B620"];
                    if (!!divisionList && divisionList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_DIVISION;
                        divisionList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B620EP"]) {
                    List divisionList = root["SDOBI"]["B600"]["B620EP"];
                    if (!!divisionList && divisionList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_DIVISION;
                        divisionList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B630"]) {
                    if (!!root["SDOBI"]["B600"]["B630"]["B631"]) {
                        List continouationList = root["SDOBI"]["B600"]["B630"]["B631"];
                        if (!!continouationList && continouationList.size() >= 1) {
                            typeCode = Constants.RELATED_TYPE_CODE_CONTINUATION;
                            continouationList.each { parent ->
                                ++item;
                                if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                                } else if (!!parent["parent"]["pdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                } else if (!!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                                }
                            }
                        }
                    }

                    if (!!root["SDOBI"]["B600"]["B630"]["B632"]) {
                        List continouationInPartList = root["SDOBI"]["B600"]["B630"]["B632"];
                        if (!!continouationInPartList && continouationInPartList.size() >= 1) {
                            typeCode = Constants.RELATED_TYPE_CODE_CONTINUATION_IN_PART;
                            continouationInPartList.each { parent ->
                                ++item;
                                if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                                } else if (!!parent["parent"]["pdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                } else if (!!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                                }
                            }
                        }
                    }

                    if (!!root["SDOBI"]["B600"]["B630"]["B633"]) {
                        List continouationReissueList = root["SDOBI"]["B600"]["B630"]["B633"];
                        if (!!continouationReissueList && continouationReissueList.size() >= 1) {
                            typeCode = Constants.RELATED_TYPE_CODE_CONTINUING_REISSUE;
                            continouationReissueList.each { parent ->
                                ++item;
                                if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                                } else if (!!parent["parent"]["pdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                } else if (!!parent["parent"]["cdoc"]) {
                                    patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                    patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                                }
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B640"]) {
                    List reissueList = root["SDOBI"]["B600"]["B640"];
                    if (!!reissueList && reissueList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_CONTINUING_REISSUE;
                        reissueList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B645"]) {
                    List reExaminationList = root["SDOBI"]["B600"]["B645"];
                    if (!!reExaminationList && reExaminationList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_REEXAMINATION;
                        reExaminationList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B650"]) {
                    List relatedPublicationList = root["SDOBI"]["B600"]["B650"];
                    if (!!relatedPublicationList && relatedPublicationList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_RELATED_PUBLICATION;
                        relatedPublicationList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B660"]) {
                    List subsititutionList = root["SDOBI"]["B600"]["B660"];
                    if (!subsititutionList &&subsititutionList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_SUBSTITUTION;
                        subsititutionList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B665"]) {
                    List correcytionList = root["SDOBI"]["B600"]["B665"];
                    if (!!correcytionList && correcytionList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_CORRECTION;
                        correcytionList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }

                if (!!root["SDOBI"]["B600"]["B670"]) {
                    List utilityModelList = root["SDOBI"]["B600"]["B670"];
                    if (!!utilityModelList && utilityModelList.size() >= 1) {
                        typeCode = Constants.RELATED_TYPE_CODE_UTILITY_MODEL_BASIS;
                        utilityModelList.each { parent ->
                            ++item;
                            if (!!parent["parent"]["pdoc"] && !!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, patRefRelatedParent.id.item, patRefRelatedChildList);
                            } else if (!!parent["parent"]["pdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(parent, patData, typeCode, item, patRefRelatedParentList, appData);
                            } else if (!!parent["parent"]["cdoc"]) {
                                patRefRelatedParentList = genPatRefRelatedParentEP(null, patData, typeCode, item, patRefRelatedParentList, appData);
                                patRefRelatedChildList = genPatRefRelatedChildEP(parent, patData, typeCode, item, patRefRelatedChildList);
                            }
                        }
                    }
                }
            }
        } else {

        } // end if else EPD and OPS
        if (!!patRefRelatedChildList && !patRefRelatedChildList.contains(null)) {
            prs.savePatRefRelatedParentChild(patRefRelatedParentList, patRefRelatedChildList, patData.patId, patData.defaultSourceId)
        } else {
            prs.savePatRefRelatedParent(patRefRelatedParentList, patData.patId, patData.defaultSourceId)
        }

    }

    /**
     * 產生parent list,以便postgresql存入
     * @param root
     * @param patData
     * @param relatedType
     * @param item
     * @param patRefParentList
     * @return
     */
    private static List<PatRefRelatedParent> genPatRefRelatedParentEP(DBObject root, PatData patData, int relatedType, int item, List patRefParentList, AppData appData) {
        PatRefRelatedParent patRefRelatedParent= new PatRefRelatedParent();
        if (!!root) {
            if (!!root["parent"]["pdoc"]) {
                root["parent"]["pdoc"].each { pdoc ->
                    patRefRelatedParent.relatedType = relatedType;
                    patRefRelatedParent.rawAppNo = pdoc["dnum"][0]["anum"];
                    patRefRelatedParent.appNo = PatNumberUtil.getAppNoEP(patRefRelatedParent.rawAppNo, COUNTRY.EP.getCountryName());
                    patRefRelatedParent.rawAppDate = pdoc["date"][0];
                    patRefRelatedParent.appDate = DateUtil.parseDate(patRefRelatedParent.rawAppDate);
                    if (!!pdoc["dnum"][0]["pnum"]) {
                        patRefRelatedParent.rawDocNo = pdoc["dnum"][0]["pnum"];
                        patRefRelatedParent.docNo = PatNumberUtil.formatDocNoByCountry(patRefRelatedParent.rawDocNo, COUNTRY.EP.getCountryName(),  null, null, patRefRelatedParent.docDate);
                    }
                    patRefRelatedParent.createDate = patData.lastUpdDate;
                    //        List<AppData> appDataQueryList = AppDataHelper.queryByCondition(patRefRelatedParent.appNo, parent.pdoc[0].ctry, patRefRelatedParent.appDate);
                    //        if (!!appDataQueryList) {
                    //            if (appDataQueryList.size() > 1) {
                    //                throw new Exception("related parent appid query result more than one");
                    //            }
                    //            patRefRelatedParent.parentAppId = appDataQueryList[0].appId;
                    //        }
                    //
                    //        List<PatData> patDataQueryList = PatDataHelper.queryByCondition(patRefRelatedParent.docNo, parent.pdoc[0].ctry, patRefRelatedParent.appDate);
                    //        if (!!patDataQueryList) {
                    //            if (patDataQueryList.size() > 1) {
                    //                throw new Exception("related parent patid query result more than one");
                    //            }
                    //            patRefRelatedParent.parentPatId = patDataQueryList[0].patId;
                    //        }

                    PatRefRelatedParentId id = new PatRefRelatedParentId();
                    id.patId = patData.patId;
                    id.item = item;
                    id.sourceId = patData.defaultSourceId;
                    patRefRelatedParent.id = id;
                    patRefParentList.add(patRefRelatedParent);
                }
            }
        } else {
            patRefRelatedParent.relatedType = relatedType;
            patRefRelatedParent.docDate = patData.docDate;
            patRefRelatedParent.rawDocDate = DateUtil.toISODate(patData.docDate, "yyyy-MM-dd");
            patRefRelatedParent.rawAppNo = patData.rawAppNo;
            patRefRelatedParent.rawAppDate = DateUtil.toISODate(appData.appDate, "yyyy-MM-dd");
            patRefRelatedParent.appDate = appData.appDate;
            patRefRelatedParent.appNo = PatNumberUtil.getAppNoEP(patRefRelatedParent.rawAppNo, COUNTRY.EP.getCountryName());
            patRefRelatedParent.rawDocNo = patData.rawDocNo;
            patRefRelatedParent.docNo = patData.docNo;
            patRefRelatedParent.createDate = patData.lastUpdDate;

            List<AppData> appDataQueryList = AppDataHelper.queryByCondition(COUNTRY.EP.getCountryName(), patRefRelatedParent.rawAppNo, patRefRelatedParent.appDate);
            if (!!appDataQueryList) {
                if (appDataQueryList.size() > 1) {
                    throw new Exception("related parent appid query result more than one");
                }
                patRefRelatedParent.parentAppId = appDataQueryList[0].appId;
            }

            List<PatData> patDataQueryList = PatDataHelper.queryByCondition(COUNTRY.EP.getCountryName(), patRefRelatedParent.docNo, patData.kindCode);
            if (!!patDataQueryList) {
                if (patDataQueryList.size() > 1) {
                    throw new Exception("related parent patid query result more than one");
                }
                patRefRelatedParent.parentPatId = patDataQueryList[0].patId;
            }

            PatRefRelatedParentId id = new PatRefRelatedParentId();
            id.sourceId = patData.defaultSourceId;
            id.item = item;
            id.patId = patData.patId;
            patRefRelatedParent.id = id;

            patRefParentList.add(patRefRelatedParent);
        }

        return patRefParentList;
    }

    /**
     * 產生ref related child,以便存入postgresql
     * @param root
     * @param patData
     * @param relatedType
     * @param item
     * @param patRefChildList
     * @return
     */
    private static List<PatRefRelatedChild> genPatRefRelatedChildEP(DBObject root, PatData patData, int relatedType, int item, List patRefChildList) {
        PatRefRelatedChild patRefRelatedChild = new PatRefRelatedChild();
        if (!!root["parent"]["cdoc"]) {
            root["parent"]["cdoc"].each { cdoc ->
                patRefRelatedChild.relatedType = relatedType;
                patRefRelatedChild.rawAppNo = cdoc["dnum"][0]["anum"];
                patRefRelatedChild.appNo = PatNumberUtil.getAppNoEP(patRefRelatedChild.rawAppNo, COUNTRY.EP.getCountryName());
                if (!!cdoc["date"]) {
                    patRefRelatedChild.rawAppDate = cdoc["date"][0];
                    patRefRelatedChild.appDate = DateUtil.parseDate(patRefRelatedChild.rawAppDate);
                }
                if (!!cdoc["dnum"][0]["pnum"]) {
                    patRefRelatedChild.rawDocNo = cdoc["dnum"][0]["pnum"];
                    patRefRelatedChild.docNo = PatNumberUtil.formatDocNoByCountry(patRefRelatedChild.rawDocNo, COUNTRY.EP.getCountryName(),  null, null, null);
                }
                patRefRelatedChild.createDate = patData.lastUpdDate;

                PatRefRelatedChildId id = new PatRefRelatedChildId();
                patRefRelatedChild.parentItem = item;
                id.patId = patData.patId;
                id.item = item;
                id.sourceId = patData.defaultSourceId;
                patRefRelatedChild.id = id;

                patRefChildList.add(patRefRelatedChild);
            }
        }
        return patRefChildList;
    }

}
