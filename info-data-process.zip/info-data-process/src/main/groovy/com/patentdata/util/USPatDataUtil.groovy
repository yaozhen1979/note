package com.patentdata.util

import java.util.Date;

import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.mongodb.DBObject
import com.patentdata.common.CommonEnum
import com.patentdata.common.Constants
import com.patentdata.common.PatTypeEnum
import com.patentdata.helper.AppDataHelper
import com.patentdata.helper.PersonDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCpcId
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsCsetId
import com.patentdata.model.PatClsFieldOfSearch
import com.patentdata.model.PatClsFieldOfSearchId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatClsLoc
import com.patentdata.model.PatClsLocId
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatClsUspcId
import com.patentdata.model.PatData
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonAgentId
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonApplicantId
import com.patentdata.model.PatPersonAssignee
import com.patentdata.model.PatPersonAssigneeId
import com.patentdata.model.PatPersonCorrespondenceAddr
import com.patentdata.model.PatPersonCorrespondenceAddrId
import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonExaminerId
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PatPersonInventorId
import com.patentdata.model.PatRawUs
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefPriorityId
import com.patentdata.model.PersonData
import com.patentdata.service.PatDataLogService

/**
 * @author mikelin
 *
 */
public class USPatDataUtil {

    public static Logger logger = LoggerFactory.getLogger(USPatDataUtil.class);
    /**
     * @param root
     * @param biblio
     * @param appRefDataMap
     * @param now
     * @return
     */
    public static AppData genAppDataXML(DBObject root, DBObject biblio, Map appRefDataMap, Date now) {
        AppData appData = new AppData();
        appData.appId = appRefDataMap.appId;
        appData.appNo = appRefDataMap.appNo;
        appData.country = appRefDataMap.appCountry;
        appData.appDate = appRefDataMap.appDate;
        appData.appLang = StringUtils.lowerCase(root.lang);
        appData.createDate = now;
        appData.lastUpdDate = now;
        return appData;
    }

    /**
     * 來源為 XML 格式
     * @param doc
     * @param root
     * @param biblio
     * @param appRefDataMap
     * @param pubRefData
     * @param now
     * @return
     */
    public static PatData genPatDataXML(DBObject oldInfoDoc, DBObject doc, DBObject root, DBObject biblio, Map appRefDataMap, Map pubRefData, Date now) {
        PatData patData = new PatData();
        def patId = PatNumberUtil.getPatIdUS(doc.stat, doc._id);
        patData.patId = patId;
        patData.stat = doc.stat;
        patData.docDate = doc.doDate;
        patData.docNo = doc._id;
        patData.rawDocNo = doc._id;
        patData.docDate = doc.doDate;
        patData.oriLang = StringUtils.lowerCase(root.lang);
        patData.createDate = now;
        patData.lastUpdDate = now;
        
        // appRefDataMap
        patData.rawAppNo = appRefDataMap.rawAppNo;
        patData.appId = appRefDataMap.appId;
        patData.patType = appRefDataMap.patType;

        // pubRefData
        patData.kindCode = pubRefData.kindCode;
        patData.country = pubRefData.country;

        // familyID
        if (!!biblio."patent-family") {
            patData.familyId = biblio."patent-family"."id".trim().toString();
        }

        // Hard code
        // TODO: DOCDB FLAG
        patData.docdbFlag = Constants.DOCDB_FLAG_NO

        patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES;
        patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
        patData.deleteFlag = Constants.DELETE_FLAG_NO;
        patData.defaultSourceId = Constants.SOURCE_ID_US_FULLTEXT;

        patData.withdrawFlag = doc.withdraw
                ? Constants.WITHDRAW_FLAG_TRUE
                : Constants.WITHDRAW_FLAG_FALSE;

        patData.truncateFlag = doc.truncate
                ? Constants.TRUNCATE_FLAG_TRUE
                : Constants.TRUNCATE_FLAG_FALSE;


        if (!!biblio."figures") {
            // size_of_figures 圖檔張數
            if (!!biblio."figures"."number-of-figures") {
                patData.sizeOfFigures = biblio."figures"."number-of-figures".toInteger();
            }
            // figure_pages 圖檔頁數
            if (!!biblio."figures"."number-of-drawing-sheets") {
                patData.figurePages = biblio."figures"."number-of-drawing-sheets".toInteger();
            }
        }

        // size_of_claims
        if (!!biblio."number-of-claims") {
            patData.sizeOfClaims = biblio."number-of-claims".toInteger();
        }

        if (!!biblio."us-term-of-grant") {

            // grant_years integer
            if (!!biblio."us-term-of-grant"."length-of-grant") {
                patData.grantYears = biblio."us-term-of-grant"."length-of-grant"[0].toInteger();
            }

            // grant_extension_days integer
            if (!!biblio."us-term-of-grant"."us-term-extension") {
                String termExtension = biblio."us-term-of-grant"."us-term-extension"[0];
                if (termExtension.contains("5 years")) {
                    patData.grantExtensionDays = 1825;
                } else {
                    patData.grantExtensionDays = termExtension.toInteger();
                }
            }
        }

        // index_criteria character 刷Index 使用

        // ********  影像檔處理時寫入 (BackFile 才這樣處理)********
        getBackFileImgPageNum(oldInfoDoc, patData);
        
        // TODO ********  須爬官網取得 ********
        // reex_flag integer 1:是,符合USPTO中REEX/YES之資料
        // ptab_flag integer 1:是,符合USPTO中PTAB/YES之資料
        // sec_flag integer 1:是,符合USPTO中SEC/YES之資料


        // ********  其他PTO ********
        // registration_no character 登錄號(JP,KR,TW)
        // registration_date date 登錄日(JP,EP,KR,TW)
        // exam_app_date date 審查申請日(KR, EP)
        // gazette_no character 專利公報號(CN, DOCDB, WO)
        // gazette_public_date 專利公報公開日(CN,DOCDB, WO)
        // designation_of_states_json 國際申請指定國INID (81),DOCDB,WO
        
        return patData;
    }
    
    /**
     * 來源為 HTML 格式
     * @param oldInfoDoc
     * @param doc
     * @param root
     * @param now
     * @return
     */
    public static PatData genPatDataHTML(DBObject oldInfoDoc, DBObject doc, DBObject root, AppData appData, DBObject patFtDoc, Date now) {
        PatData patData = new PatData();
        
        def patId = PatNumberUtil.getPatIdUS(doc.stat, doc._id);
        patData.patId = patId;
        patData.stat = doc.stat;
        patData.docDate = doc.doDate;
        patData.docNo = doc._id;
        patData.rawDocNo = doc._id;
        patData.docDate = doc.doDate;
        patData.oriLang = Constants.US_LANG;
        patData.createDate = now;
        patData.lastUpdDate = now;
        
        // appRefDataMap
        patData.rawAppNo = root.rawAppNo;
        patData.appId = appData.appId;
        patData.patType = PatTypeEnum.US.findPatTypeCode(oldInfoDoc.type);
        
        // 來 patFtDoc 如果沒有, 就從 assignment 來
        if (doc.stat == 2) {
            if (!!patFtDoc && !!patFtDoc.kindCodeCPC) {
                patData.kindCode = patFtDoc.kindCodeCPC;
            }
        } else {
            // 公開網頁有提供kindcode
            patData.kindCode = root.kindCode;
        }
        
        // 如果沒有kindcode就放"--"
        if (!patData.kindCode && doc.stat == 2) {
            patData.kindCode = "--";
        }
                
        patData.country = (!!root.countryCode) ? root.countryCode.toUpperCase() : CommonEnum.COUNTRY.US.getCountryName();
        if (!!root.familyId) {
            patData.familyId = root.familyId;
        }
        
        patData.docdbFlag = Constants.DOCDB_FLAG_NO
        patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES;
        patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
        patData.deleteFlag = Constants.DELETE_FLAG_NO;
        patData.defaultSourceId = Constants.SOURCE_ID_US_FULLTEXT;
        
        patData.withdrawFlag = doc.withdraw ? Constants.WITHDRAW_FLAG_TRUE : Constants.WITHDRAW_FLAG_FALSE;
        patData.truncateFlag = doc.truncate ? Constants.TRUNCATE_FLAG_TRUE : Constants.TRUNCATE_FLAG_FALSE;
        
        getBackFileImgPageNum(oldInfoDoc, patData);
        
        return patData;
    }
    
    /**
     * BackFile 影像檔相關欄位處理
     * @param oldInfoDoc
     * @param patData
     */
    private static void getBackFileImgPageNum(DBObject oldInfoDoc, PatData patData) {

        if (!!oldInfoDoc) {

            // page_no_of_claim integer pdf檔中claim開始頁數,原始資料若未提供,於處理圖檔時寫
            if (!!oldInfoDoc.filePageClaim) {
                patData.pageNoOfClaim = oldInfoDoc.filePageClaim;
            }

            // page_no_of_desc integer pdf檔中desc開始頁數,原始資料若未提供,於處理圖檔時寫入
            if (!!oldInfoDoc.filePageDesc) {
                patData.pageNoOfDesc = oldInfoDoc.filePageDesc;
            }

            // page_no_of_first_img integer 首頁圖所在頁數,原始資料若未提供,於處理圖檔時寫入
            if (!!oldInfoDoc.filePageFig) {
                patData.pageNoOfFirstImg = oldInfoDoc.filePageFig;
            }

            // TODO: PDF 是否存在
            if (!!oldInfoDoc.filePageFirst) {
                // updateMap['filePageFirst'] = oldInfoDoc.filePageFirst
            }

            // total_pages integer pdf檔總頁數,處理圖檔時寫入(CN DESIGN TXT有提供)
            if (!!oldInfoDoc.filePageNumber) {
                patData.totalPages = oldInfoDoc.filePageNumber;
            }

            // size_of_clips integer  處理clips時寫入
            if (!!oldInfoDoc.clipPageNumber) {
                patData.sizeOfClips = oldInfoDoc.clipPageNumber;
            }

            // page_no_of_figure integer pdf檔中圖檔開始頁數,原始資料若未提供,於處理圖檔時寫入
            if (!!oldInfoDoc.figurePageNumber) {
                patData.pageNoOfFigure = oldInfoDoc.figurePageNumber;
            }

            // first_img_flag integer 是否存在首頁圖,處理圖檔時寫入 boolean 格式不能用"!!"判斷
            if (oldInfoDoc.firstImagePageFlag != null) {
                patData.firstImgFlag = (oldInfoDoc.firstImagePageFlag) ? 1 : Constants.ZERO;
            }
        }
    }

    /**
     * @param doc
     * @param patData
     * @param now
     * @return
     */
    public static PatRawUs genPatRawUsDataXML(DBObject doc, PatData patData, int relRawType, Date now) {
        PatRawUs patRawUs = new PatRawUs();
        patRawUs.rawId = doc._id;
        patRawUs.patId = patData.patId;
        patRawUs.relRawType = relRawType;
        patRawUs.createDate = now;
        patRawUs.lastUpdDate = now;
        def rawData = doc.data;
        if (patData.stat == Constants.PAT_STAT_PUBLIC) {
            rawData."us-patent-application".removeField("description");
            rawData."us-patent-application".removeField("claims");
            rawData."us-patent-application".removeField("abstract");
            rawData."us-patent-application"."us-bibliographic-data-application".removeField("invention-title");
        } else {
            rawData."us-patent-grant".removeField("description");
            rawData."us-patent-grant".removeField("claims");
            rawData."us-patent-grant".removeField("abstract");
            rawData."us-patent-grant"."us-bibliographic-data-grant".removeField("invention-title");
        }

        String rawJson = rawData.toString();
        if (JSONUtil.isJSONValid(rawJson)) {
            patRawUs.rawJson = rawJson;
        }
        
        return patRawUs;
    }
    
    /**
     * @param doc
     * @param patData
     * @param relRawType
     * @param now
     * @return
     */
    public static PatRawUs genPatRawUsDataHTML(DBObject doc, PatData patData, int relRawType, Date now) {
        
        PatRawUs patRawUs = new PatRawUs();
        patRawUs.rawId = doc._id;
        patRawUs.patId = patData.patId;
        patRawUs.relRawType = relRawType;
        patRawUs.createDate = now;
        patRawUs.lastUpdDate = now;
        
        doc.data.removeField("abstractt");
        doc.data.removeField("claims");
        doc.data.removeField("description");
        doc.data.removeField("title");
        
        String rawJson = doc.data.toString();
        if (JSONUtil.isJSONValid(rawJson)) {
            patRawUs.rawJson = rawJson;
        }
        
        return patRawUs;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonApplicant> genPatPersonApplicantsXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonApplicant> patPersonApplicants = new ArrayList<PatPersonApplicant>();

        def parties = (!!biblio['us-parties']) ? biblio['us-parties'] : biblio['parties'];
        // applicants
        def applicants = (!!parties['us-applicants']) ? parties['us-applicants'] : parties['applicants'];
        if (!!applicants) {
            def applicantArry = (!!applicants['us-applicant']) ? applicants['us-applicant'] : applicants['applicant'];
            if (!!applicantArry && applicantArry.size() > Constants.ZERO) {
                // loop applicant
                applicantArry.eachWithIndex {applicant, index ->
                    PersonData personData = null;
                    def addressbookApplicant = applicant."addressbook";
                    if (addressbookApplicant.size() > 1) {
                        throw new Exception("addressbookApplicant size larger than 1");
                    }
                    addressbookApplicant.each {addrBook ->
                        personData = USPatDataUtil.genPersonData(addrBook, now);
                    }

                    if (personData == null) {
                        throw new Exception("applicant addressbook error");
                    }

                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }

                    PatPersonApplicant patPersonApplicant = genPatPersonApplicant(applicant, patData, now, index+1);
                    patPersonApplicant.personData = personData;
                    patPersonApplicant.personCountry = personData.country;
                    patPersonApplicants.add(patPersonApplicant);

                } // end of loop for us-applicant
            }
        }

        if (patPersonApplicants.size() == Constants.ZERO) {
            return null;
        }

        return patPersonApplicants;
    }
    
    /**
     * 組出 PatPersonApplicant 所需欄位
     * @param applicant
     * @param patData
     * @param createDate
     * @return
     */
    public static PatPersonApplicant genPatPersonApplicant(def applicant, PatData patData, Date createDate, int item) {

        PatPersonApplicant patPersonApplicant = new PatPersonApplicant();
        patPersonApplicant.createDate = createDate;

        // PatPersonApplicantId
        PatPersonApplicantId id = new PatPersonApplicantId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonApplicant.id = id;

        patPersonApplicant.appCode = applicant."app-type";
        patPersonApplicant.designationCode = applicant."designation";
        patPersonApplicant.authCategory = applicant."applicant-authority-category";

        return patPersonApplicant;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonInventor> genPatPersonInventorsXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonInventor> patPersonInventors = new ArrayList<PatPersonInventor>();

        def parties = (!!biblio['us-parties']) ? biblio['us-parties'] : biblio['parties'];
        // inventors
        if (!!parties['inventors']) {

            if (!!parties['inventors']['inventor'] && parties['inventors']['inventor'].size() > Constants.ZERO) {

                // loop inventor
                parties['inventors']['inventor'].eachWithIndex {inventor, index ->
                    PersonData personData = null;
                    def addressbookInventor = inventor."addressbook";
                    if (addressbookInventor.size() > 1) {
                        throw new Exception("addressbookInventor size larger than 1");
                    }
                    addressbookInventor.each {addrBook ->
                        personData = USPatDataUtil.genPersonData(addrBook, now);
                    }

                    if (personData == null) {
                        throw new Exception("inventor addressbook error");
                    }

                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }

                    PatPersonInventor patPersonInventor = USPatDataUtil.genPatPersonInventor(inventor, patData, now, index+1);
                    patPersonInventor.personData = personData;
                    patPersonInventor.personCountry = personData.country;
                    patPersonInventors.add(patPersonInventor);

                } // end of loop for inventor

            }

        }

        if (patPersonInventors.size() == Constants.ZERO) {
            return null;
        }

        return patPersonInventors;
    }
    
    /**
     * 公開:name, address, 公告: name, address, address, country, state
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonInventor> genPatPersonInventorsHTML(def root, PatData patData, List<PersonData> personDataList, Date now) {
        
        if (!root."inventors") {
            // return null;
            throw new Exception("inventor is null, patId : $patData.patId");
        }
        
        List<PatPersonInventor> patPersonInventors = new ArrayList<PatPersonInventor>();
        
        root."inventors".eachWithIndex {inventor,  index ->
            
            if (!StringUtil.personFacetWrap(inventor."name")) {
                return false;
            }
            
            PersonData personData = USPatDataUtil.genPersonDataHTML(inventor, now);
            
            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
            if (existsData != null) {
                personData = existsData;
            } else {
                personData.personId = UUIDUtil.generateUUID();
                personDataList.add(personData);
            }
            
            PatPersonInventor patPersonInventor = new PatPersonInventor();
            patPersonInventor.createDate = now;
    
            // PatPersonInventorId
            PatPersonInventorId id = new PatPersonInventorId();
            id.item = index + 1;
            id.patId = patData.patId;
            id.sourceId = patData.defaultSourceId;
            patPersonInventor.id = id;
            
            patPersonInventor.personData = personData;
            patPersonInventor.personCountry = personData.country;
            patPersonInventors.add(patPersonInventor);
            
        }
        
        if (patPersonInventors.size() == Constants.ZERO) {
            return null;
        }
        
        return patPersonInventors;
    }
        
    
    /**
     * @param inventor
     * @param patData
     * @param createDate
     * @param item
     * @return
     */
    public static PatPersonInventor genPatPersonInventor(def inventor, PatData patData, Date createDate, int item) {

        PatPersonInventor patPersonInventor = new PatPersonInventor();
        patPersonInventor.createDate = createDate;

        // PatPersonInventorId
        PatPersonInventorId id = new PatPersonInventorId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonInventor.id = id;
        patPersonInventor.designation = inventor."designation";

        return patPersonInventor;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonAgent> genPatPersonAgentsXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonAgent> patPersonAgents = new ArrayList<PatPersonAgent>();
        def parties = (!!biblio['us-parties']) ? biblio['us-parties'] : biblio['parties'];
        // agents
        if (!!parties['agents']) {
            if (!!parties['agents']['agent'] && parties['agents']['agent'].size() > Constants.ZERO) {
                // loop agent
                parties['agents']['agent'].eachWithIndex {agent, index ->
                    PersonData personData = null;
                    def addressbookAgent = agent."addressbook";
                    if (addressbookAgent.size() > 1) {
                        throw new Exception("addressbookAgent size larger than 1");
                    }
                    addressbookAgent.each {addrBook ->
                        personData = USPatDataUtil.genPersonData(addrBook, now);
                    }

                    if (personData == null) {
                        throw new Exception("agent addressbook error");
                    }

                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }

                    PatPersonAgent patPersonAgent = genPatPersonAgent(agent, patData, index+1, now);
                    patPersonAgent.personData = personData;
                    patPersonAgent.personCountry = personData.country;
                    patPersonAgents.add(patPersonAgent);

                } // end of loop for agent
            }
        }

        if (patPersonAgents.size() == Constants.ZERO) {
            return null;
        }

        return patPersonAgents;
    }
    
    /**
     * 組出 PatPersonAgent 所需欄位
     * @param agent
     * @param patData
     * @param item
     * @param now
     * @return
     */
    public static PatPersonAgent genPatPersonAgent(def agent, PatData patData, int item, Date now) {

        PatPersonAgent patPersonAgent = new PatPersonAgent();
        patPersonAgent.createDate = now;

        // PatPersonAgentId
        PatPersonAgentId id = new PatPersonAgentId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonAgent.id = id;
        patPersonAgent.repCode = agent."rep-type";

        return patPersonAgent;
    }
    
    /**
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonAgent> genPatPersonAgentsHTML(def root, PatData patData, List<PersonData> personDataList, Date now) {
        
        List<PatPersonAgent> patPersonAgents = new ArrayList<PatPersonAgent>();
        
        if (!!root."attorneyAgentOrFirms") {
            
            root."attorneyAgentOrFirms".eachWithIndex {agent, item ->
                
                if (!!agent) {
                    PersonData personData = new PersonData();
                    personData.lang = Constants.US_LANG;
                    personData.personType = Constants.PERSON_TYPE_NONE;
                    personData.personName = StringUtil.wrapHtmlCode(agent);
                    personData.createDate = now;
                    personData.lastUpdDate = now;
                    
                    String personFacet = USPatDataUtil.genPersonFacet(personData.personName, "", "", "", "", "");
                    if (StringUtils.isBlank(personFacet)) {
                        throw new Exception("personFacet error");
                    }
                    personData.personFacet = personFacet;
                    
                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }
                    
                    PatPersonAgent patPersonAgent = new PatPersonAgent();
                    // PatPersonAgentId
                    PatPersonAgentId id = new PatPersonAgentId();
                    id.item = item + 1;
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    patPersonAgent.id = id;
                    // TODO:repCode 網頁無法判斷??
                    // patPersonAgent.repCode = "attorney";
                    
                    patPersonAgent.personData = personData;
                    patPersonAgent.personCountry = personData.country;
                    patPersonAgent.createDate = now;
                    
                    patPersonAgents.add(patPersonAgent);
                }
                
            }
        }
        
        return patPersonAgents;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonAssignee> genPatPersonAssigneesXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonAssignee> patPersonAssignees = new ArrayList<PatPersonAssignee>();
        def assignees = biblio['assignees']
        // assignees
        if (!!assignees) {
            if (!!assignees['assignee'] && assignees['assignee'].size() > Constants.ZERO) {
                // loop assignee
                assignees['assignee'].eachWithIndex {assignee, index ->
                    PersonData personData = null;
                    def addressbookAssignee = assignee."addressbook";
                    if (!!addressbookAssignee) {
                        if (addressbookAssignee.size() > 1) {
                            throw new Exception("addressbookAssignee size larger than 1");
                        }
                        addressbookAssignee.each {addrBook ->
                            personData = USPatDataUtil.genPersonData(addrBook, now);
                        }
                        
                        if (personData == null) {
                            throw new Exception("assignee addressbook error");
                        }
                    } else {
                        int personType = Constants.PERSON_TYPE_NONE;
                        // personName = prefix+" "+first-name +" "+ middle-name +" "+last-name+" "+ suffix 或 name 或orgname
                        String personName = "";
                
                        if (!!assignee."orgname") {
                            personType = Constants.PERSON_TYPE_ORG;
                            personName = assignee."orgname"[0].toString();
                
                        } else if (!!assignee."last-name"){
                            personType = Constants.PERSON_TYPE_PERSONAL;
                
                            if (!!assignee."prefix") {
                                personName += " " + assignee."prefix"[0]
                            }
                            if (!!assignee."first-name") {
                                personName += " " + assignee."first-name"[0]
                            }
                            if (!!assignee."middle-name") {
                                personName += " " + assignee."middle-name"[0]
                            }
                            if (!!assignee."last-name") {
                                personName += " " + assignee."last-name"[0]
                            }
                            if (!!assignee."suffix") {
                                personName += " " + assignee."suffix"[0]
                            }
                
                        } else if (!!assignee."name") {
                            personType = Constants.PERSON_TYPE_ORG;
                            personName = assignee."name"[0]."value".toString();
                        }
                
                        personName = StringUtil.wrapHtmlCode(personName);
                        // 如果 personFacet 為空就不組personData關聯
                        String personFacet = USPatDataUtil.genPersonFacet(personName, "", "", "", "", "");
                        if (StringUtils.isBlank(personFacet)) {
//                            throw new Exception("personFacet error");
                            logger.error("assignee error: personFacet is empty, patId: $patData.patId");
                        } else {
                            personData = new PersonData();
                            personData.lang = Constants.US_LANG;
                            personData.personType = personType;
                            personData.personName = personName.trim();
                            personData.createDate = now;
                            personData.lastUpdDate = now;
                            personData.personFacet = personFacet;
                        }
                    }

                    if (!!personData) {
                        PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                        if (existsData != null) {
                            personData = existsData;
                        } else {
                            personData.personId = UUIDUtil.generateUUID();
                            personDataList.add(personData);
                        }
                        
                        PatPersonAssignee patPersonAssignee = genPatPersonAssignee(patData, index+1, now);
                        patPersonAssignee.personData = personData;
                        patPersonAssignee.personCountry = personData.country;
                        patPersonAssignees.add(patPersonAssignee);
                    }

                } // end of loop for assignee
            }
        }

        if (patPersonAssignees.size() == Constants.ZERO) {
            return null;
        }

        return patPersonAssignees;
    }
    
    /**
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonAssignee> genPatPersonAssigneesHTML(def root, PatData patData, List<PersonData> personDataList, Date now) {
        
        if (!root."assignees") {
            return null;
        }
        
        List<PatPersonAssignee> patPersonAssignees = new ArrayList<PatPersonAssignee>();
        
        root."assignees".eachWithIndex {assignee,  index ->
            PersonData personData = USPatDataUtil.genPersonDataHTML(assignee, now);
            
            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
            if (existsData != null) {
                personData = existsData;
            } else {
                personData.personId = UUIDUtil.generateUUID();
                personDataList.add(personData);
            }
            
            PatPersonAssignee patPersonAssignee = new PatPersonAssignee();
            patPersonAssignee.createDate = now;
    
            // PatPersonAssigneeId
            PatPersonAssigneeId id = new PatPersonAssigneeId();
            id.item = index + 1;
            id.patId = patData.patId;
            id.sourceId = patData.defaultSourceId;
            patPersonAssignee.id = id;
            
            patPersonAssignee.personData = personData;
            patPersonAssignee.personCountry = personData.country;
            patPersonAssignees.add(patPersonAssignee);
            
        }
        
        if (patPersonAssignees.size() == Constants.ZERO) {
            return null;
        }
        
        return patPersonAssignees;
    }
    
    /**
     * @param patData
     * @param item
     * @return
     */
    public static PatPersonAssignee genPatPersonAssignee(PatData patData, int item, Date now) {

        PatPersonAssignee patPersonAssignee = new PatPersonAssignee();
        // PatPersonAssigneeId
        PatPersonAssigneeId id = new PatPersonAssigneeId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonAssignee.id = id;

        patPersonAssignee.createDate = now;

        return patPersonAssignee;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @return
     */
    public static List<PatPersonExaminer> genPatPersonExaminersXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonExaminer> patPersonExaminers = new ArrayList<PatPersonExaminer>();
        def examiners = biblio['examiners']
        // examiners
        if (!!examiners && examiners.size() > Constants.ZERO) {
            // primary-examiner or assistant-examiner
            examiners.eachWithIndex {examiner, index ->

                int examinerType = (examiner.key == "primary-examiner")
                        ? Constants.EXAMINER_TYPE_PRIMARY
                        : Constants.EXAMINER_TYPE_ASSISTANT;

                int personType = Constants.PERSON_TYPE_NONE;
                // personName = prefix+" "+first-name +" "+ middle-name +" "+last-name+" "+ suffix 或 name 或orgname
                def examinerData = examiner.value;
                String personName = "";
                if (!!examinerData."orgname") {
                    personType = Constants.PERSON_TYPE_ORG;
                    personName = examinerData."orgname"[0].toString();
                } else if (!!examinerData."last-name"){
                    personType = Constants.PERSON_TYPE_PERSONAL;
                    if (!!examinerData."prefix") {
                        personName += " " + examinerData."prefix"[0]
                    }
                    if (!!examinerData."first-name") {
                        personName += " " + examinerData."first-name"[0]
                    }
                    if (!!examinerData."middle-name") {
                        personName += " " + examinerData."middle-name"[0]
                    }
                    if (!!examinerData."last-name") {
                        personName += " " + examinerData."last-name"[0]
                    }
                    if (!!examinerData."suffix") {
                        personName += " " + examinerData."suffix"[0]
                    }

                } else if (!!examinerData."name") {
                    personType = Constants.PERSON_TYPE_ORG;
                    personName = examinerData."name".toString();
                }
                
                personName = StringUtil.wrapHtmlCode(personName);
                // person_name, address, city, state, postCode, country
                String personFacet = StringUtil.personFacetWrap(personName);

                PersonData personData = null;
                PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personFacet, null, personDataList);
                if (existsData != null) {
                    personData = existsData;
                } else {
                    personData = new PersonData();
                    personData.lang = Constants.US_LANG;
                    personData.personType = personType;
                    personData.personName = personName.trim();
                    personData.createDate = now;
                    personData.lastUpdDate = now;
                    personData.personId = UUIDUtil.generateUUID();
                    personData.personFacet = personFacet;
                    personDataList.add(personData);
                }

                PatPersonExaminer patPersonExaminer = genPatPersonExaminer(patData, index+1, now);
                patPersonExaminer.personData = personData;
                patPersonExaminer.examinerType = examinerType;
                if (!!examinerData."department") {
                    patPersonExaminer.department = examinerData."department"[0].toString();
                }
                patPersonExaminers.add(patPersonExaminer);
            } // // end of loop for examiners
        } // end of examiners

        if (patPersonExaminers.size() == Constants.ZERO) {
            return null;
        }

        return patPersonExaminers;
    }

    /**
     * @param patData
     * @param createDate
     * @param item
     * @return
     */
    public static PatPersonExaminer genPatPersonExaminer(PatData patData, int item, Date now) {

        PatPersonExaminer patPersonExaminer = new PatPersonExaminer();

        // PatPersonExaminerId
        PatPersonExaminerId id = new PatPersonExaminerId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonExaminer.id = id;
        patPersonExaminer.createDate = now;

        return patPersonExaminer;
    }
    
    /**
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    public static List<PatPersonExaminer> genPatPersonExaminersHTML(def root, PatData patData, List<PersonData> personDataList, Date now) {
     
        List<PatPersonExaminer> patPersonExaminers = new ArrayList<PatPersonExaminer>();
        
        String personName = "";
        if (!!root."primaryExaminer") {
            PatPersonExaminer patPersonExaminer = genPatPersonExaminerHTML(patData, personDataList, 1
                , root."primaryExaminer", Constants.EXAMINER_TYPE_PRIMARY, now);
            patPersonExaminers.add(patPersonExaminer);
        }
        
        if (!!root."assistantExaminer") {
            PatPersonExaminer patPersonExaminer = genPatPersonExaminerHTML(patData, personDataList, 2
                , root."assistantExaminer", Constants.EXAMINER_TYPE_ASSISTANT, now);
            patPersonExaminers.add(patPersonExaminer);
        }
        
        if (patPersonExaminers.size() == Constants.ZERO) {
            return null;
        }
        
        return patPersonExaminers;
    }
    
    /**
     * @param patData
     * @param personDataList
     * @param item
     * @param personName
     * @param examinerType
     * @param now
     * @return
     */
    public static PatPersonExaminer genPatPersonExaminerHTML(PatData patData, List<PersonData> personDataList, int item, String personName, int examinerType, Date now) {
        
        PersonData personData = new PersonData();
        personData.lang = Constants.US_LANG;
        personData.personType = Constants.PERSON_TYPE_NONE;
        personData.personName = StringUtil.wrapHtmlCode(personName);
        personData.createDate = now;
        personData.lastUpdDate = now;
        
        String personFacet = USPatDataUtil.genPersonFacet(personData.personName, "", "", "", "", "");
        if (StringUtils.isBlank(personFacet)) {
            throw new Exception("personFacet error");
        }
        personData.personFacet = personFacet;
        
        PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
        if (existsData != null) {
            personData = existsData;
        } else {
            personData.personId = UUIDUtil.generateUUID();
            personDataList.add(personData);
        }
        
        PatPersonExaminer patPersonExaminer = genPatPersonExaminer(patData, item, now);
        patPersonExaminer.personData = personData;
        patPersonExaminer.examinerType = examinerType;
        
        return patPersonExaminer;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param personDataList
     * @return
     */
    public static List<PatPersonCorrespondenceAddr> genPatPersonCorrespondenceAddrsXML(def biblio, PatData patData, List<PersonData> personDataList, Date now) {

        List<PatPersonCorrespondenceAddr> patPersonCorrespondenceAddrs = new ArrayList<PatPersonCorrespondenceAddr>();

        def parties = biblio['parties'];
        // correspondenceAddrs
        if (!!parties && !!parties['correspondence-address']) {
            if (!!parties['correspondence-address']["addressbook"] && parties['correspondence-address']["addressbook"].size() > Constants.ZERO) {

                if (parties['correspondence-address']["addressbook"].size() > 1) {
                    throw new Exception("addressbookCorrespondenceAddr size larger than 1");
                }

                // loop correspondenceAddr
                parties['correspondence-address']["addressbook"].eachWithIndex {addressbookCorrespondenceAddr, index ->

                    PersonData personData = null;
                    addressbookCorrespondenceAddr.each {addrBook ->
                        personData = USPatDataUtil.genPersonData(addressbookCorrespondenceAddr, now);
                    }

                    if (personData == null) {
                        throw new Exception("correspondenceAddr addressbook error");
                    }

                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }

                    PatPersonCorrespondenceAddr patPersonCorrespondenceAddr = genPatPersonCorrespondenceAddr(patData, index+1, now);
                    patPersonCorrespondenceAddr.personData = personData;
                    patPersonCorrespondenceAddr.personCountry = personData.country;
                    patPersonCorrespondenceAddrs.add(patPersonCorrespondenceAddr);

                } // end of loop correspondenceAddr
            }
        } // end of parties['correspondence-address']

        if (patPersonCorrespondenceAddrs.size() == Constants.ZERO) {
            return null;
        }

        return patPersonCorrespondenceAddrs;
    }
    
    public static List<PatPersonCorrespondenceAddr> genPatPersonCorrespondenceAddrsHTML(def root, PatData patData, List<PersonData> personDataList, Date now) {
        
        if (!root."correspondenceNameAndAddress") {
            return null;
        }
        
        List<PatPersonCorrespondenceAddr> patPersonCorrespondenceAddrs = new ArrayList<PatPersonCorrespondenceAddr>();
        
        PersonData personData = new PersonData();
        personData.lang = Constants.US_LANG;
        personData.personType = Constants.PERSON_TYPE_NONE;
        personData.personName = StringUtil.wrapHtmlCode(root."correspondenceNameAndAddress");
        personData.createDate = now;
        personData.lastUpdDate = now;
        
        String personFacet = USPatDataUtil.genPersonFacet(personData.personName, "", "", "", "", "");
        if (StringUtils.isBlank(personFacet)) {
            throw new Exception("personFacet error");
        }
        personData.personFacet = personFacet;
        
        PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
        if (existsData != null) {
            personData = existsData;
        } else {
            personData.personId = UUIDUtil.generateUUID();
            personDataList.add(personData);
        }
        
        PatPersonCorrespondenceAddr patPersonCorrespondenceAddr = new PatPersonCorrespondenceAddr();
        
        // PatPersonCorrespondenceAddrId
        PatPersonCorrespondenceAddrId id = new PatPersonCorrespondenceAddrId();
        id.item = 1;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonCorrespondenceAddr.id = id;
        patPersonCorrespondenceAddr.createDate = now;
        
        patPersonCorrespondenceAddr.personData = personData;
        patPersonCorrespondenceAddr.personCountry = personData.country;
        patPersonCorrespondenceAddrs.add(patPersonCorrespondenceAddr);
        
        return patPersonCorrespondenceAddrs;
    }

    /**
     * @param patData
     * @param item
     * @return
     */
    public static PatPersonCorrespondenceAddr genPatPersonCorrespondenceAddr(PatData patData, int item, Date now) {

        PatPersonCorrespondenceAddr patPersonCorrespondenceAddr = new PatPersonCorrespondenceAddr();

        // PatPersonCorrespondenceAddrId
        PatPersonCorrespondenceAddrId id = new PatPersonCorrespondenceAddrId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        patPersonCorrespondenceAddr.id = id;
        patPersonCorrespondenceAddr.createDate = now;

        return patPersonCorrespondenceAddr;
    }
    
    /**
     *
     * @param biblio
     * @param patData
     * @param now
     */
    public static List<PatClsIpc> genPatClsIpcXML(def biblio, PatData patData, Date now) {

        List<PatClsIpc> ipcList = new ArrayList<PatClsIpc>();

        // classification-ipc
        if (!!biblio."classification-ipc") {

            String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})?\/?([0-9]{1,6})/;

            // 項次
            int item = Constants.ZERO;
            // IPC或IPCR,依據tag判斷,1:ipc,2:ipcr
            int ipcType = Constants.CLS_TYPE_IPC;

            // main ipc
            if (!!biblio."classification-ipc"."main-classification") {

                item++;
                String ipcStr = biblio."classification-ipc"."main-classification".toUpperCase();
                String ipcText = null;
                // 
                if (ipcStr.contains("/")) {
                    // ex : C12P017/00, C 07D 4 9/02
                    ipcText = ipcStr.replaceAll("\\s", "");
                    ipcText.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                        ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                    }
                } else {
                    // ex : B60J  700
                    ipcStr.replaceAll(/([A-Z])([0-9]{2})([A-Z])(\s*)([0-9]+)/) {full, section, classStr, subClass, space, groups->
                        ipcText = section + classStr + subClass + " " + groups[0..3-space.length()-1] + "/" + groups[3-space.length()..-1]
                    }
                    
                }
                if (!PatClsUtil.validUSOriIpc(ipcText)) {
                    throw new Exception("main ipc origin format error, patId = $patData.patId");
                }

                PatClsIpc patClsIpc = new PatClsIpc();
                patClsIpc.ipcText = ipcText;
                patClsIpc.clsVersion = biblio."classification-ipc"?."edition".replaceFirst(/^0+(?!$)/, "0");
                // IPCR 不用判斷是否為Main ipc 固定為否
                patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_YES;
                patClsIpc.createDate = now;

                // PatClsIpcId
                PatClsIpcId id = new PatClsIpcId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;
                id.ipcType = ipcType;
                patClsIpc.id = id;

                ipcList.add(patClsIpc);

            } // endf of if main ipc

            // futher ipc (list)
            if (!!biblio."classification-ipc"."further-classification") {

                biblio."classification-ipc"."further-classification".each {futherIpc ->

                    item++;
                    String ipcStr = futherIpc."value";
                    String ipcText = null;
                    //
                    if (ipcStr.contains("/")) {
                        // ex : C12P017/00, C 07D 4 9/02
                        ipcText = ipcStr.replaceAll("\\s", "");
                        ipcText.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                            ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                        }
                    } else {
                        // ex : B60J  700
                        ipcStr.replaceAll(/([A-Z])([0-9]{2})([A-Z])(\s*)([0-9]+)/) {full, section, classStr, subClass, space, groups->
                            ipcText = section + classStr + subClass + " " + groups[0..3-space.length()-1] + "/" + groups[3-space.length()..-1]
                        }
                        
                    }
                    
                    //
                    PatClsIpc patClsIpc = new PatClsIpc();
                    patClsIpc.ipcText = ipcText;
                    // IPCR 不用判斷是否為Main ipc 固定為否
                    patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_NO;
                    patClsIpc.createDate = now;

                    // PatClsIpcId
                    PatClsIpcId id = new PatClsIpcId();
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    id.item = item;
                    id.ipcType = ipcType;
                    patClsIpc.id = id;

                    ipcList.add(patClsIpc);

                } // end of loop futher ipc

            } // end of if futher ipc

        }
        // classifications-ipcr
        if (!!biblio."classifications-ipcr" && !!biblio."classifications-ipcr"."classification-ipcr") {

            biblio."classifications-ipcr"."classification-ipcr".eachWithIndex {ipcData, index ->

                // 項次
                int item = index + 1;
                // IPC或IPCR,依據tag判斷,1:ipc,2:ipcr
                int ipcType = Constants.CLS_TYPE_IPCR;

                String section = ipcData."section";
                String classStr = ipcData."class";
                String subClass = ipcData."subclass";
                String mainGroup = ipcData."main-group";
                String subGroup = ipcData."subgroup";

                String ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);

                PatClsIpc patClsIpc = new PatClsIpc();
                patClsIpc.ipcText = ipcText;
                patClsIpc.symbolPosition = ipcData."symbol-position";
                patClsIpc.clsVersion = ipcData."ipc-version-indicator"."date";
                patClsIpc.clsLevel = ipcData."classification-level";
                patClsIpc.clsValue = ipcData."classification-value";
                patClsIpc.actionDate = DateUtil.parseDate(ipcData."action-date"."date");
                patClsIpc.genOffice = ipcData."generating-office"."country";
                patClsIpc.clsStatus = ipcData."classification-status";
                patClsIpc.clsDataSource = ipcData."classification-data-source";
                // IPCR 不用判斷是否為Main ipc 固定為否
                patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_NO;
                patClsIpc.createDate = now;

                // PatClsIpcId
                PatClsIpcId id = new PatClsIpcId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;
                id.ipcType = ipcType;
                patClsIpc.id = id;

                ipcList.add(patClsIpc);
            }
        } // classifications-ipcr

        return ipcList;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static List<PatClsCpc> genPatClsCpcXML(def biblio, PatData patData, Date now) {

        List<PatClsCpc> cpcList = new ArrayList<PatClsCpc>();

        // 項次
        int item = Constants.ZERO;
        if (!!biblio."classifications-cpc") {
            int rawMainFlag;

            // main cpc
            if (!!biblio."classifications-cpc"."main-cpc" && !!biblio."classifications-cpc"."main-cpc"."classification-cpc") {

                item ++;
                rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_YES;
                def classificationCpc = biblio."classifications-cpc"."main-cpc"."classification-cpc";

                PatClsCpc patClsCpc = genCpcInfo(classificationCpc, patData, item, rawMainFlag, now);
                cpcList.add(patClsCpc);

            } // end of main cpc

            // futher cpc
            if (!!biblio."classifications-cpc"."further-cpc") {

                rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;
                def furtherCpc = biblio."classifications-cpc"."further-cpc";
                def classificationCpcs = furtherCpc."classification-cpc";

                classificationCpcs.each {classificationCpc ->
                    item ++;
                    PatClsCpc patClsCpc = genCpcInfo(classificationCpc, patData, item, rawMainFlag, now);
                    cpcList.add(patClsCpc);
                } // end of loop classificationCpcs

            } // end of futher cpc

        } // end of if !!biblio."classifications-cpc"

        return cpcList;
    }

    /**
     * @param data
     * @param patData
     * @param item
     * @param rawMainFlag
     * @param now
     * @return
     */
    public static PatClsCpc genCpcInfo(def data, PatData patData, int item, int rawMainFlag, Date now) {

        PatClsCpc patClsCpc = new PatClsCpc();

        String section = data."section";
        String classStr = data."class";
        String subClass = data."subclass";
        String mainGroup = data."main-group";
        String subGroup = data."subgroup";

        String cpcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);

        patClsCpc.cpcText = cpcText;
        patClsCpc.symbolPosition = data."symbol-position";
        patClsCpc.clsVersion = data."cpc-version-indicator"."date";
        patClsCpc.clsValue = data."classification-value";
        patClsCpc.actionDate = DateUtil.parseDate(data."action-date"."date");
        patClsCpc.genOffice = data."generating-office"."country";
        patClsCpc.clsStatus = data."classification-status";
        patClsCpc.clsDataSource = data."classification-data-source";
        patClsCpc.schemaOriCode = data."scheme-origination-code";
        patClsCpc.rawMainFlag = rawMainFlag;
        patClsCpc.createDate = now;

        // PatClsCpcId
        PatClsCpcId id = new PatClsCpcId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;
        patClsCpc.id = id;

        return patClsCpc;
    }
    
    /**
     * @param biblio
     * @param patData
     * @return
     */
    public static List<PatClsCset> getPatClsCsetXML(def biblio, PatData patData, Date now) {

        List<PatClsCset> patClsCsetList = new ArrayList<PatClsCset>();

        if (!!biblio."classifications-cpc") {

            // combination-set
            if (!!biblio."classifications-cpc"."further-cpc" && !!biblio."classifications-cpc"."further-cpc"."combination-set") {

                biblio."classifications-cpc"."further-cpc"."combination-set".each {combinationSet ->

                    String groupNo = combinationSet."group-number";
                    // combination-rank
                    if (!!combinationSet."combination-rank") {
                        combinationSet."combination-rank".each {combinationRank ->
                            // 項次
                            String rankNumber = combinationRank."rank-number";
                            def classificationCpc = combinationRank."classification-cpc";
                            PatClsCset patClsCset = genCsetInfo(classificationCpc, patData, rankNumber.toInteger(), groupNo.toInteger(), now);
                            patClsCsetList.add(patClsCset);

                        } // end of loop combination-rank
                    } // end of if combination-rank

                } // end of loopcombination-set
            } // end of if combination-set

        }

        return patClsCsetList;
    }

    /**
     * @param data
     * @param patData
     * @param item
     * @param groupNo
     * @param now
     * @return
     */
    public static PatClsCset genCsetInfo(def data, PatData patData, int item, int groupNo, Date now) {

        PatClsCset patClsCset = new PatClsCset();

        String section = data."section";
        String classStr = data."class";
        String subClass = data."subclass";
        String mainGroup = data."main-group";
        String subGroup = data."subgroup";

        String cpcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);

        patClsCset.cpcText = cpcText;
        patClsCset.symbolPosition = data."symbol-position";
        patClsCset.clsVersion = data."cpc-version-indicator"."date";
        patClsCset.clsValue = data."classification-value";
        patClsCset.actionDate = DateUtil.parseDate(data."action-date"."date");
        patClsCset.genOffice = data."generating-office"."country";
        patClsCset.clsStatus = data."classification-status";
        patClsCset.clsDataSource = data."classification-data-source";
        patClsCset.schemaOriCode = data."scheme-origination-code";
        patClsCset.createDate = now;

        // PatClsCsetId
        PatClsCsetId id = new PatClsCsetId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;
        id.groupNo = groupNo;
        patClsCset.id = id;

        return patClsCset;
    }
    
    /**
     * @param biblio
     * @param patData
     * @return
     */
    public static List<PatClsLoc> genPatClsLocXML(def biblio, PatData patData, Date now) {

        List<PatClsLoc> patClsLocList = new ArrayList<PatClsLoc>();

        if (!!biblio."classification-locarno") {

            int item = Constants.ZERO;
            // main loc
            if (!!biblio."classification-locarno"."main-classification") {

                item++;
                String locStr = biblio."classification-locarno"."main-classification";
                String locVersion = biblio."classification-locarno"."edition";

                String locText = PatClsUtil.formatClsLoc(locStr);

                PatClsLocId id = new PatClsLocId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;

                PatClsLoc patClsLoc = new PatClsLoc();
                patClsLoc.id = id;
                patClsLoc.locText = locText;
                patClsLoc.clsVersion = locVersion;
                patClsLoc.rawText = locStr;
                patClsLoc.rawMainFlag = Constants.CLS_LOC_MAIN_FLAG_YES;
                patClsLoc.createDate = now;

                patClsLocList.add(patClsLoc);
            }

            // further loc
            if (!!biblio."classification-locarno"."further-classification") {

                biblio."classification-locarno"."further-classification".each {locStr ->

                    item++;

                    PatClsLocId id = new PatClsLocId();
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    id.item = item;

                    PatClsLoc patClsLoc = new PatClsLoc();
                    patClsLoc.id = id;
                    patClsLoc.rawText = locStr."value";
                    patClsLoc.locText = PatClsUtil.formatClsLoc(patClsLoc.rawText);
                    patClsLoc.rawMainFlag = Constants.CLS_LOC_MAIN_FLAG_NO;
                    patClsLoc.createDate = now;

                    patClsLocList.add(patClsLoc);
                } // end of loop further loc

            } // end of if !!biblio."classification-locarno"."further-classification"
        } // end of if !!biblio."classification-locarno"

        return patClsLocList;
    }
    
    /**
     * field-of-search : (classification-ipc|classifications-ipcr|classification-national)+<BR>
     * us-field-of-classification-search : (us-classifications-ipcr | classification-national | classification-cpc-text | classification-cpc-combination-text)+<BR>
     * @param biblio
     * @param patData
     * @return
     */
    public static List<PatClsFieldOfSearch> genPatClsFieldOfSearchXML(def biblio, PatData patData, Date now) {

        List<PatClsFieldOfSearch> patClsFieldOfSearchList = new ArrayList<PatClsFieldOfSearch>();

        String classType = "";
        // us-field-of-classification-search or field-of-search
        def fieldOfSearch = (!!biblio."us-field-of-classification-search") ? biblio."us-field-of-classification-search" : biblio."field-of-search";
        if (!!fieldOfSearch) {

            int item = Constants.ZERO;
            
            // USPC
            if (!!fieldOfSearch."classification-national") {
                
                classType = "USPC";

                fieldOfSearch."classification-national".each {
                    
                    if (!!it."futher-classification") {
                        // TODO : futher-classification
                        throw new Exception("us-field-of-classification-search futher-classification");
                    }
                  
                    String uspcStr = it."main-classification";
                    
                    if (uspcStr.equalsIgnoreCase("None")) {
                        // uspc = none 暫不處理
                    } else {
                        item++;
                        String addInfo = ""
                        if (!!it."additional-info") {
                            addInfo = it."additional-info"[0];
                        }
    
                        // USPC 呈現方式為區間, ex: 36167946-67955
                        boolean unstructuredFlag = (addInfo == "unstructured");
                        String uspcText = "";
                        String uspcFormat = "";
                        int defectFlag = Constants.CLS_DEFECT_FLAG_FALSE;
                        
                        try {
                            if (unstructuredFlag) {
                                uspcFormat = PatClsUtil.parseUnstructuredFieldOfSearch(uspcStr, classType);
                            } else {
                                uspcFormat = PatClsUtil.formatClsUspc(uspcStr);
                            }
                        } catch (Exception ex) {
                            logger.error("FieldOfSearch uspc format error ,patId: $patData.patId, error = " + ex);
                        }
                        
                        if (!!uspcFormat) {
                            uspcText = uspcFormat;
                        } else {
                            uspcText = uspcStr;
                            defectFlag = Constants.CLS_DEFECT_FLAG_TRUE;
                        }
                        
                        PatClsFieldOfSearch patClsFieldOfSearch = genPatClsFieldOfSearchInfo(patData, item, uspcText, defectFlag, classType, now);
                        patClsFieldOfSearchList.add(patClsFieldOfSearch);
                    }
                    
                }
            }
            
            // IPC
            if (!!fieldOfSearch."classification-ipc") {
                String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z])([0-9]{0,4})\/([0-9]{1,6})/;
                classType = "IPC";
                
                // main ipc
                if (!!fieldOfSearch."classification-ipc") {
                    
                    fieldOfSearch."classification-ipc".each {
                        
                        if (!!it."futher-classification") {
                            // TODO : futher-classification
                            throw new Exception("us-field-of-classification-search futher-classification");
                        }
                        
                        item++;
                        String ipcText = it."main-classification".toUpperCase();
                        int defectFlag = Constants.CLS_DEFECT_FLAG_FALSE;
                        if (PatClsUtil.validUSOriIpc(ipcText)) {
                            ipcText.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                                ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                            }
                        } else {
                            defectFlag = Constants.CLS_DEFECT_FLAG_TRUE;
                            logger.error("fieldOfSearch main ipc origin format error");
                        }
        
                        PatClsFieldOfSearch patClsFieldOfSearch = genPatClsFieldOfSearchInfo(patData, item, ipcText, defectFlag, classType, now);
                        patClsFieldOfSearchList.add(patClsFieldOfSearch);
                    }
                }
            }
            
            // classifications-ipcr
            def classificationsIpcr = fieldOfSearch."classifications-ipcr";
            if (!!classificationsIpcr) {
                classType = "IPC";
                // TODO: field-of-search classifications-ipcr
                throw new Exception("field-of-search classifications-ipcr");
            }
            
            // us-classifications-ipcr
            classificationsIpcr = fieldOfSearch."us-classifications-ipcr";
            if (!!classificationsIpcr) {
                classType = "IPC";
                classificationsIpcr.each {ipcText ->
                    item++;
                    PatClsFieldOfSearch patClsFieldOfSearch = genPatClsFieldOfSearchInfo(patData, item, ipcText, Constants.CLS_DEFECT_FLAG_FALSE, classType, now);
                    patClsFieldOfSearchList.add(patClsFieldOfSearch);
                }
            }
           
            // CPC
            if (!!fieldOfSearch."classification-cpc-text") {
                classType = "CPC";
                fieldOfSearch."classification-cpc-text".each {
                    item++;
                    String cpcText = it."value";
                    PatClsFieldOfSearch patClsFieldOfSearch = genPatClsFieldOfSearchInfo(patData, item, cpcText, Constants.CLS_DEFECT_FLAG_FALSE, classType, now);
                    patClsFieldOfSearchList.add(patClsFieldOfSearch);
                }
            }

            // CSET
            if (!!fieldOfSearch."classification-cpc-combination-text") {
                classType = "CSET";
                fieldOfSearch."classification-cpc-combination-text".each {
                    item++;
                    String csetText = it."value";
                    PatClsFieldOfSearch patClsFieldOfSearch = genPatClsFieldOfSearchInfo(patData, item, csetText, Constants.CLS_DEFECT_FLAG_FALSE, classType, now);
                    patClsFieldOfSearchList.add(patClsFieldOfSearch);
                }
            }

        }// end of if us-field-of-classification-search

        return patClsFieldOfSearchList;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static PatRefPct genPatRefPctDataXML(def biblio, PatData patData, Date now) {
        
        PatRefPct patRefPct = null;
        
        if (!!biblio?."pct-or-regional-filing-data"?."document-id") {
            
            patRefPct = new PatRefPct();
            patRefPct.patId = patData.patId;
            def pctDoc = biblio?."pct-or-regional-filing-data"?."document-id"[0];
            
            patRefPct.createDate = now;
            patRefPct.rawAppNo = pctDoc."doc-number";
            // 將raw_app_no依據[號碼規則]進行格式化
            patRefPct.appNo = PatNumberUtil.getPctAppNoUS(patRefPct.rawAppNo);
            
            // pctAppId
            String pctAppId = "WO" + patRefPct.appNo.replace("/", "");
            AppData pctAppData = AppDataHelper.findByAppId(pctAppId, "WO");
            if (!!pctAppData) {
//                patRefPct.pctAppId = pctAppId;
                patRefPct.appData = pctAppData;
            }
            
            // PCT申請日字串
            patRefPct.rawAppDate = pctDoc."date";
            // PCT申請日
            patRefPct.appDate = DateUtil.parseDate(pctDoc."date");
            
            // us-371c124-date, us-371c12-date 兩個只會出現一個
            if (!!biblio."pct-or-regional-filing-data"."us-371c124-date") {
                patRefPct.pct371c124Date = DateUtil.parseDate(biblio."pct-or-regional-filing-data"."us-371c124-date"."date");
            }
            
            if (!!biblio."pct-or-regional-filing-data"."us-371c12-date") {
                patRefPct.pct371c124Date = DateUtil.parseDate(biblio."pct-or-regional-filing-data"."us-371c12-date"."date");
            }
            // article2239Date US沒有
            
            if (!!biblio?."pct-or-regional-publishing-data"?."document-id") {
                def pctPublicDoc = biblio."pct-or-regional-publishing-data"."document-id"[0];
                patRefPct.rawPublicNo = pctPublicDoc."doc-number";
                patRefPct.publicNo = PatNumberUtil.getPctPublicDocNoUS(patRefPct.rawPublicNo);
                // TODO: publicPatId
                patRefPct.rawPublicDate = pctPublicDoc."date";
                patRefPct.publicDate = DateUtil.parseDate(pctPublicDoc."date");
                
                if (!!pctPublicDoc."gazette-reference") {
                    if (!!pctPublicDoc."gazette-reference"[0]."gazette-num") {
                        patRefPct.publicGazetteNo = pctPublicDoc."gazette-reference"[0]."gazette-num";
                    }
                    
                    if (!!pctPublicDoc."gazette-reference"[0]."date") {
                        patRefPct.publicGazetteDate = DateUtil.parseDate(pctPublicDoc."gazette-reference"[0]."date");
                    }
                }
                
            } // end of if !!biblio?."pct-or-regional-publishing-data"?."document-id"
            
        } // end of if !!biblio?."pct-or-regional-filing-data"?."document-id"
        
        return patRefPct;
    }
    
    /**
     * @param root
     * @param patData
     * @param now
     * @return
     */
    public static PatRefPct genPatRefPctDataHTML(def root, PatData patData, Date now) {
        
        PatRefPct patRefPct = null;
        if (!!root."pctNo") {
            patRefPct = new PatRefPct();
            patRefPct.patId = patData.patId;
            patRefPct.createDate = now;
            patRefPct.rawAppNo = root."pctNo";
            // 將raw_app_no依據[號碼規則]進行格式化
            patRefPct.appNo = PatNumberUtil.getPctAppNoUS(patRefPct.rawAppNo);
            // pctAppId
            String pctAppId = "WO" + patRefPct.appNo.replace("/", "");
            AppData pctAppData = AppDataHelper.findByAppId(pctAppId, "WO");
            if (!!pctAppData) {
                patRefPct.appData = pctAppData;
            }
            
            // PCT申請日字串
            patRefPct.rawAppDate = root."pctField";
            // PCT申請日
            patRefPct.appDate = DateUtil.parseDate(root."pctField");
            
            if (!!root."pctPubNo") {
                patRefPct.rawPublicNo = root."pctPubNo";
                patRefPct.publicNo = PatNumberUtil.getPctPublicDocNoUS(root."pctPubNo".replaceAll("/", ""));
            }
            
            if (!!root."pctPubDate") {
                patRefPct.rawPublicDate = root."pctPubDate";
                patRefPct.publicDate = DateUtil.parseDate(root."pctPubDate");
            }
            // TODO: d371??
            /*
            if (!!root."d371") {
                patRefPct.pct371c124Date = DateUtil.parseDate(biblio."pct-or-regional-filing-data"."us-371c12-date"."date");
            }
            */
        } 
        
        return patRefPct;
    }
    
    /**
     * @param patData
     * @param item
     * @param classText
     * @param classType
     * @param now
     * @return
     */
    public static PatClsFieldOfSearch genPatClsFieldOfSearchInfo(PatData patData, int item, String classText, int defectFlag, String classType, Date now) {

        PatClsFieldOfSearchId id = new PatClsFieldOfSearchId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;

        PatClsFieldOfSearch patClsFieldOfSearch = new PatClsFieldOfSearch();
        patClsFieldOfSearch.id = id;

        patClsFieldOfSearch.classType = classType;
        patClsFieldOfSearch.classText = classText;
        patClsFieldOfSearch.defectFlag = defectFlag;
        patClsFieldOfSearch.createDate = now;

        return patClsFieldOfSearch;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static List<PatClsUspc> genPatClsUspcXML(def biblio, PatData patData, Date now) {

        List<PatClsUspc> patClsUspcList = new ArrayList<PatClsLoc>();

        if (!!biblio."classification-national") {
            int item = Constants.ZERO;

            // main uspc
            if (!!biblio."classification-national"."main-classification") {

                item++;

                String uspcStr = biblio."classification-national"."main-classification";

                PatClsUspcId id = new PatClsUspcId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;

                PatClsUspc patClsUspc = new PatClsUspc();
                patClsUspc.id = id;

                patClsUspc.uspcText = PatClsUtil.formatClsUspc(uspcStr);
                patClsUspc.rawMainFlag = Constants.CLS_USPC_MAIN_FLAG_YES;
                patClsUspc.createDate = now;

                patClsUspcList.add(patClsUspc);

            } // end of main uspc

            // further uspc
            if (!!biblio."classification-national"."further-classification") {

                biblio."classification-national"."further-classification".each {uspcStr ->

                    item++;

                    PatClsUspcId id = new PatClsUspcId();
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    id.item = item;

                    PatClsUspc patClsUspc = new PatClsUspc();
                    patClsUspc.id = id;

                    String uspcText = PatClsUtil.formatClsUspc(uspcStr."value");
                    patClsUspc.uspcText = uspcText;
                    patClsUspc.rawMainFlag = Constants.CLS_USPC_MAIN_FLAG_NO;
                    patClsUspc.createDate = now;

                    patClsUspcList.add(patClsUspc);
                }

            } // end of further uspc

        }

        return patClsUspcList;
    }
    
    /**
     * @param patData
     * @param ipcText
     * @param version
     * @param rawMainFlag
     * @param item
     * @param now
     * @return
     */
    public static PatClsIpc genPatClsIpcHTML(PatData patData, String ipcText, String version, int rawMainFlag, int item, Date now) {
        
        PatClsIpc patClsIpc = new PatClsIpc();
        patClsIpc.ipcText = ipcText;
        patClsIpc.clsVersion = version;
        // IPCR 不用判斷是否為Main ipc 固定為否
        patClsIpc.rawMainFlag = rawMainFlag;
        patClsIpc.createDate = now;

        // PatClsIpcId
        PatClsIpcId id = new PatClsIpcId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;
        id.ipcType = Constants.CLS_TYPE_IPC;
        patClsIpc.id = id;

        return patClsIpc;
    }
    
    /**
     * @param patData
     * @param uspcText
     * @param rawMainFlag
     * @param item
     * @param now
     * @return
     */
    public static PatClsUspc genPatClsUspcHTML(PatData patData, String uspcText, int rawMainFlag, int item, Date now) {
        
        PatClsUspcId id = new PatClsUspcId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;

        PatClsUspc patClsUspc = new PatClsUspc();
        patClsUspc.id = id;

        patClsUspc.uspcText = uspcText;
        patClsUspc.rawMainFlag = rawMainFlag;
        patClsUspc.createDate = now;
        
        return patClsUspc;
    }
    
    /**
     * @param patData
     * @param locText
     * @param rawMainFlag
     * @param item
     * @param now
     * @return
     */
    public static PatClsLoc genPatClsLocHTML(PatData patData, String rawText, String locText, int rawMainFlag, int item, Date now) {
        
        PatClsLocId id = new PatClsLocId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;

        PatClsLoc patClsLoc = new PatClsLoc();
        patClsLoc.id = id;
        patClsLoc.rawText = rawText;
        patClsLoc.locText = locText;
        patClsLoc.rawMainFlag = rawMainFlag;
        patClsLoc.createDate = now;
        
        return patClsLoc;
    }
    
    /**
     * @param patData
     * @param cpcText
     * @param version
     * @param rawMainFlag
     * @param item
     * @param now
     * @return
     */
    public static PatClsCpc genPatClsCpcHTML(PatData patData, String cpcText, String version, int rawMainFlag, int item, Date now) {
        
        PatClsCpc patClsCpc = new PatClsCpc();
        patClsCpc.cpcText = cpcText;
        
        patClsCpc.clsVersion = version;
        patClsCpc.rawMainFlag = rawMainFlag;
        patClsCpc.createDate = now;
        
        // PatClsCpcId
        PatClsCpcId id = new PatClsCpcId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;
        patClsCpc.id = id;
        
        return patClsCpc;
    }
    
    /**
     * @param biblio
     * @param patData
     * @param now
     * @return
     */
    public static List<PatRefPriority> getPatRefPriorityXML(def biblio, PatData patData, Date now) {
        
        List<PatRefPriority> patRefPriorityList = new ArrayList<>();
        
        int item = 0;
        if (!!biblio?."priority-claims"?."priority-claim") {
            
            biblio."priority-claims"."priority-claim".each {priorityClaim ->
                item++;
                PatRefPriority patRefPriority = new PatRefPriority();
                patRefPriority.rawAppNo = priorityClaim."doc-number";
                // 20070057359 此筆priority claim的doc-number為空，官網已移除此欄位
                if (StringUtils.isBlank(patRefPriority.rawAppNo)) {
                     logger.warn "warning: pat_ref_priority.raw_app_no is null ";
                     new PatDataLogService().writeError(patData, 2, "NF-11", "pat_ref_priority.raw_app_no is null", "");
                     return;
                }
                // TODO: appNo 將raw_app_no依據[號碼規則]進行格式化
                
                patRefPriority.rawAppDate = priorityClaim?."date";
                patRefPriority.appDate = DateUtil.parseDate(priorityClaim?."date");
                patRefPriority.country = CountryUtil.transferCountryCodeUS(priorityClaim?."country");
                patRefPriority.priType = CommonEnum.PRIORITYTYPE.findPriorityTypeCode(priorityClaim?."kind");
                patRefPriority.createDate = now;
                
                // TODO: pri_pat_id?pri_app_id
                // 優先權資料是否存在於app_data中,存在的話寫入app_id,使用country,app_no至app_data查詢,寫入對應到的pri_pat_id?
                if (!!patRefPriority.country && !!patRefPriority.appNo && !!patRefPriority.appDate) {
                    List<AppData> appDataList = AppDataHelper.queryByCondition(patRefPriority.country, patRefPriority.appNo, patRefPriority.appDate);
                    if (!!appDataList) {
                        if (appDataList.size() > 1) {
                            throw new Exception("priority data query over 1...");
                        }
                        patRefPriority.appData = appDataList.get(0).appId;
                    }
                }
                
                PatRefPriorityId id = new PatRefPriorityId();
                id.item = item;
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                patRefPriority.id = id;
                
                patRefPriorityList.add(patRefPriority);
            }
        }
        return patRefPriorityList;
    }
    
    public static List<PatRefPriority> getPatRefPriorityHTML(def root, PatData patData, Date now) {
        
        List<PatRefPriority> patRefPriorityList = new ArrayList<>();
        // priority-claims
        if (!!root."foreignAppPriorityDatas") {
            
            root."foreignAppPriorityDatas".eachWithIndex {priorityClaim, item ->
                
                PatRefPriority patRefPriority = new PatRefPriority();
                patRefPriority.rawAppNo = priorityClaim."applicationNo";
                patRefPriority.rawAppDate = priorityClaim?."date";
                patRefPriority.appDate = DateUtil.parseDate(priorityClaim?."date");
                if (!!priorityClaim."countryCode") {
                    patRefPriority.country = CountryUtil.transferCountryCodeUS(priorityClaim?."countryCode");
                }
                patRefPriority.priType = Constants.PRIORITY_TYPE_UNKNOW;
                patRefPriority.createDate = now;
                
                if (!!patRefPriority.country && !!patRefPriority.appNo && !!patRefPriority.appDate) {
                    List<AppData> appDataList = AppDataHelper.queryByCondition(patRefPriority.country, patRefPriority.appNo, patRefPriority.appDate);
                    if (!!appDataList) {
                        if (appDataList.size() > 1) {
                            throw new Exception("priority data query over 1...");
                        }
                        patRefPriority.appData = appDataList.get(0).appId;
                    }
                }
                
                PatRefPriorityId id = new PatRefPriorityId();
                id.item = item.toInteger() + 1 ;
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                patRefPriority.id = id;
                
                patRefPriorityList.add(patRefPriority);
            }
        }
        
        return patRefPriorityList;
        
    }
    /**
     * 組出 PersonData 所需欄位<BR>
     * UUID<BR>
     * country<BR>
     * personName<BR>
     * postcode<BR>
     * state<BR>
     * city<BR>
     * address<BR>
     * person_facet<BR>
     */
    public static PersonData genPersonData(def addrBook, Date now) {

        int personType = Constants.PERSON_TYPE_NONE;
        // personName = prefix+" "+first-name +" "+ middle-name +" "+last-name+" "+ suffix 或 name 或orgname
        String personName = "";

        if (!!addrBook."orgname") {
            personType = Constants.PERSON_TYPE_ORG;
            personName = addrBook."orgname"[0].toString();

        } else if (!!addrBook."last-name"){
            personType = Constants.PERSON_TYPE_PERSONAL;

            if (!!addrBook."prefix") {
                personName += " " + addrBook."prefix"[0]
            }
            if (!!addrBook."first-name") {
                personName += " " + addrBook."first-name"[0]
            }
            if (!!addrBook."middle-name") {
                personName += " " + addrBook."middle-name"[0]
            }
            if (!!addrBook."last-name") {
                personName += " " + addrBook."last-name"[0]
            }
            if (!!addrBook."suffix") {
                personName += " " + addrBook."suffix"[0]
            }

        } else if (!!addrBook."name") {
            personType = Constants.PERSON_TYPE_ORG;
            personName = addrBook."name"[0]."value".toString();
        }

        PersonData personData = new PersonData();
        personData.lang = Constants.US_LANG;
        personData.personType = personType;
        personData.personName = StringUtil.wrapHtmlCode(personName.trim());
        personData.createDate = now;
        personData.lastUpdDate = now;

        // address
        String fullAddress = "";
        def addrMap = [:]
        if (!!addrBook."address") {
            addrMap = makeAddressMap(addrBook."address"[0]);
            fullAddress = addrMap["fullAddress"];

        } else if (!!addrBook."text") {
            fullAddress = addrBook."text"[0]
        }

        personData.address = fullAddress;
        personData.city = addrMap["city"];
        personData.state = addrMap["state"];
        personData.postcode = addrMap["postcode"];
        personData.country = addrMap["country"];

        /*
        if (personData.country.equalsIgnoreCase("unknown") || personData.country.equalsIgnoreCase("omitted")) {
            personData.country = "";
        }
        */
        
        String personFacet = USPatDataUtil.genPersonFacet(personData.personName, personData.address, personData.city, personData.state, personData.postcode, personData.country);
        if (StringUtils.isBlank(personFacet)) {
            throw new Exception("personFacet error");
        }
        personData.personFacet = personFacet;

        return personData;
    }
    
    /**
     *
     * @param inventor
     * @param now
     * @return
     */
    public static PersonData genPersonDataHTML(def data, Date now) {
        
        PersonData personData = new PersonData();
        personData.lang = Constants.US_LANG;
        personData.personType = Constants.PERSON_TYPE_NONE;
        personData.personName = StringUtil.wrapHtmlCode(data."name");
        personData.createDate = now;
        personData.lastUpdDate = now;
        
        personData.address = StringUtil.wrapHtmlCode(data."address");
        personData.state = StringUtil.wrapHtmlCode(data."state");
        personData.country = StringUtil.wrapHtmlCode(data."country");
        
        String personFacet = USPatDataUtil.genPersonFacet(personData.personName, personData.address, "", "", "", personData.country);
        if (StringUtils.isBlank(personFacet)) {
            throw new Exception("personFacet error");
        }
        personData.personFacet = personFacet;
        
        return personData;
    }

    /**
     * parse element document-id <BR>
     * includes country, doc-number, kind, name, date ..fields
     * @param documentData
     * @return
     */
    public static Map parseDocumentDataUS(def documentElem) {

        def map = [:];
        map << [country: documentElem."country".toUpperCase()];
        map << [docNo: documentElem."doc-number"];
        map << [kindCode: documentElem."kind"];
        map << [name: documentElem."name"];
        map << [rawDate: documentElem."date"];
        map << [date: DateUtil.parseDate(documentElem."date")];

        return map;
    }

    /**
     * facet combines person_name, address, city, state, postCode, country fields
     * @param personName
     * @param address
     * @param city
     * @param state
     * @param postCode
     * @param country
     * @return
     */
    public static String genPersonFacet(String personName, String address, String city, String state, String postCode, String country) {

        String facetStr = "";
        facetStr += (!!personName? personName : "");
        facetStr += (!!address? address : "");
        facetStr += (!!city? city : "");
        facetStr += (!!state? state : "");
        facetStr += (!!postCode? postCode : "");
        facetStr += (!!country? country : "");
       
        return StringUtil.personFacetWrap(facetStr);
    }
    
    /**
     * fullAddress = address-1 +" "+ address-2+" "+ address-3+" "+ mailcode +" "+ pobox+" "+ room+" "+ address-floor+" "+ building+" "+ street
     */
    public static Map makeAddressMap(def address) {

        def map = [:];

        String fullAddress = "";
        fullAddress += (!!address."address-1") ? " " + address."address-1" : "";
        fullAddress += (!!address."address-2") ? " " + address."address-2" : "";
        fullAddress += (!!address."address-3") ? " " + address."address-3" : "";
        fullAddress += (!!address."mailcode") ? " " + address."mailcode" : "";
        fullAddress += (!!address."pobox") ? " " + address."pobox" : "";
        fullAddress += (!!address."room") ? " " + address."room" : "";
        fullAddress += (!!address."address-floor") ? " " + address."address-floor" : "";
        fullAddress += (!!address."building") ? " " + address."building" : "";
        fullAddress += (!!address."street") ? " " + address."street" : "";

        map << ["fullAddress" : StringUtil.wrapHtmlCode(fullAddress)];
        map << ["city" : StringUtil.wrapHtmlCode(address."city")];
        map << ["state" : StringUtil.wrapHtmlCode(address."state")];
        map << ["postcode" : StringUtil.wrapHtmlCode(address."postcode")];
        map << ["country" : CountryUtil.transferCountryCodeUS(address.country)];

        return map;
    }
}
