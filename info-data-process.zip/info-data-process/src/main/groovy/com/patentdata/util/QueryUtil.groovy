package com.patentdata.util

import java.util.Date;
import java.util.List;

public class QueryUtil {
    
    /**
     * for fileType = 0
     * 
     * @return
     */
    public static def getQueryList_AT_1() {
        
        def queryList = [
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1899-07-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1905-01-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1908-07-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1914-01-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1919-05-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1927-10-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1935-07-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1938-06-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1950-02-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-10-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-01-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-04-12")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-11-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-12-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-10-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-12-27")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-08-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-03-10")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-04-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-02-25")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-12-12")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-08-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-06-25")]]
        ]
        
        return queryList;
        
    }   // end getQueryList_AT_1
    
    /**
     * for fileType = 0
     * 
     * @return
     */
    public static def getQueryList_AT_2() {
        def queryList = [
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-11-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-11-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-06-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-03-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-02-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-01-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-11-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-09-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-10-15")]],
        ]
        
        return queryList;
    }   // getQueryList_AT_2
    
    /**
     * for fileType = 0
     * 
     * @return
     */
    public static def getQueryList_AT_3() {
        
        def queryList = [
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-01-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-09-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-06-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-01-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-07-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-09-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-12-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-06-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-11-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-04-15")]],
        ]
        
        return queryList;
        
    }   // getQueryList_AT_3
    
    /**
     * for fileType = 0
     *
     * @return
     */
    public static def getQueryList_AT_3_5() {
        
        def queryList = [
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-08-15")]],
//            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-01-15")]],
            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-04-15")]],
            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-10-15")]],
        ]
        
        return queryList;
        
    }   // getQueryList_AT_3_5
    
    /**
     * for fileType = 0
     *
     * @return
     */
    public static def getQueryList_AT_3_6() {
        
        def queryList = [
            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-02-15")]],
            [country: "AT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-10-15")]],
        ]
        
        return queryList;
        
    }   // getQueryList_AT_3_6
    
    /**
     * for fileType = 1 or 2
     * 
     * @return
     */
    public static def getQueryList_AT_4() {
        
        def queryList = [
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "AT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "AT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
        
    }   // end getQueryList_AT_4
    
    /**
     * 
     * @return
     */
    public static def getQueryList_AU_1() {
        
        def queryList = [
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1923-03-15")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-09-21")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-10-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-03-28")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-03-04")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-10-28")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-09-15")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-06-12")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-01-22")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-09-16")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-04-14")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-10-06")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-11-21")]]
        ]
        
        return queryList;
    }   // end getQueryList_AU_1
    
    /**
     *
     * @return
     */
    public static def getQueryList_AU_1_2() {
        
        def queryList = [
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-12-01")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-04-18")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-04-17")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-10-23")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-01-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-01-05")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-06-01")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-21")]]
        ]
        
        return queryList;
    }   // end getQueryList_AU_1_2
    
    /**
     *
     * @return
     */
    public static def getQueryList_AU_2() {
        
        def queryList = [
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-04-18")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-08-02")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-03-11")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-09-19")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-10-15")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-11-02")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-02-23")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-01-13")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-08-15")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-05-08")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-05-11")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-05-18")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-01-25")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-10-03")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-10-10")]]
        ]
        
    }   // end getQueryList_AU_2
    
    /**
     * 
     * @return
     */
    public static def getQueryList_AU_2_1() {
        
        def queryList = [
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-12-19")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-02-18")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-06-12")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-06-19")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-11-26")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-01-22")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-03-06")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-05-29")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-06-29")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-08-25")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-10-29")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-11-24")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-03-29")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-06-17")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-10-14")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-11-01")]]
        ]
        
    }   // end getQueryList_AU_2_1
    
    /**
     *
     * @return
     */
    public static def getQueryList_AU_2_2() {
        
        def queryList = [
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-04-10")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-09-14")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-10-04")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-05-03")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-08-09")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-10-23")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-11-20")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-12-11")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-26")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-04-29")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-06-11")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-06-18")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-07-04")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-10-15")]]
        ]
        
    }   // end getQueryList_AU_2_2
    
    public static def getQueryList_AU_2_3() {
        
        def queryList = [
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-17")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-04-22")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-06-26")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-10-08")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-11-17")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-12-12")]],
            // [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-02-02")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-03-11")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-30")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-05-04")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-05-25")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-07-08")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-08-26")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-09-06")]]
        ]
        
    }   // end getQueryList_AU_2_3
    
    public static def getQueryList_AU_2_4() {
        
        def queryList = [
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-01-06")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-19")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-06-16")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-02-01")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-03-29")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-08-23")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-15")]],
//            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-02-21")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-07-24")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-09-25")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-01-29")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-06-11")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-07-02")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-07-30")]]
        ]
        
    }   // end getQueryList_AU_2_4
    
    /**
     *
     * @return
     */
    public static def getQueryList_AU_3() {
        
        def queryList = [
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-07-01")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-10-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-07-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-09-08")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-12-08")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-02-02")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-03-15")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-07-12")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-01-10")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-03-14")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-05-16")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-07-04")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-09-26")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-11-07")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-01-30")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-03-13")]],
            [country: "AU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-05-15")]]
        ]
        
    }   // end getQueryList_AU_3
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_AU_4() {
        
        def queryList = [
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
//            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
//            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "AU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "AU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }   // end getQueryList_AU_4
    
    /**
     * 
     * @return
     */
    public static def getQueryList_AR_1() {
        
        def queryList = [
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-12-27")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-05-31")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-11-20")]]
        ]
        
        return queryList;
    }   // end getQueryList_AR_1
    
    /**
     *
     * @return
     */
    public static def getQueryList_AR_2() {
        
        def queryList = [
            // [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-05-02")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-08-13")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-06-29")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-09-12")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-20")]],
            [country: "AR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-12-26")]],
        ]
        
        return queryList;
    }   // end getQueryList_AR_2
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_AR_3() {
        
        def queryList = [
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "AR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "AR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "AR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "AR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }   // end getQueryList_AR_3
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BE_1() {
        
        def queryList = [
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1932-05-31")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-09-18")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-08-12")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-02-22")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-09-12")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-02-16")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-06-16")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-09-01")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-02-22")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BE_1_2() {
        
        def queryList = [
//            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-08-26")]],
//            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-05-18")]],
//            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-02-05")]],
//            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-02-08")]],
//            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-12-16")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-05-22")]],
            [country: "BE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-07-04")]],
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BE_2() {
        
        def queryList = [
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "BE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "BE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BG() {
        
        def queryList = [
            [country: "BG", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-10-15")]],
            [country: "BG", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-31")]],
            [country: "BG", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-03-31")]],
            [country: "BG", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-01-31")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "BG", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BR_1() {
        
        def queryList = [
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-04-19")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-09-06")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-12-03")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-04-05")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-01-16")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-10-02")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-10-13")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-01-09")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-09-01")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-24")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-10-14")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-06-29")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-12-28")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BR_1_2() {
        
        def queryList = [
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-08-29")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-12-26")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-08-14")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-05-14")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-06-18")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-09-03")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-09-02")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-08-17")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-04-26")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-07-19")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-11-29")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-01-16")]],
//            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-05-29")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-20")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-10-06")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-24")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-06-28")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-07-05")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-10-02")]],
            [country: "BR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-10-14")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_BR_2() {
        
        def queryList = [
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "BR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "BR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1869-08-18")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1889-07-23")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1898-07-12")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1904-12-20")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1911-04-18")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1918-02-26")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1922-05-16")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1925-12-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1929-10-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1933-03-21")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1937-09-07")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1942-06-30")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_2() {
        def queryList = [
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1947-07-15")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-12-25")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1955-09-13")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1958-02-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1959-12-22")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-09-05")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-06-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-01-19")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-07-26")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-01-23")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-05-27")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-09-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-12-07")]]
        ]
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_3() {
        
        def queryList = [
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-01-16")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-01-22")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-01-28")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-02-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-01-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-01-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-11-14")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-07-24")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-04-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-12-16")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-08-25")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-05-18")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-01-25")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-11-01")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-08-07")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-05-28")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-04-29")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-03-31")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-04-26")]]
        ]
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_4() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-03-14")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-03-13")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-09-17")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-01-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-03-19")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-03-21")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-10-19")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-10-24")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-03-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-12-15")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-08-01")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-12-06")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-01-04")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-05-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-07-21")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-07-13")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-01")]]
        ]
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_5() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-05-05")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-05-15")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-06-18")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-10-10")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-02-25")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-05-15")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-12-16")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-12-23")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-02-12")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-06-19")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-12-23")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-05-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-08-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-10-28")]]
        ]
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_6() {
        
        def queryList = [
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-04-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-06-22")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-08-31")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-10-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-07-30")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-08-15")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-10-31")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-11-23")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-11-30")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-12-12")]]
        ]
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_7() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-01-16")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-04")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-21")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-08-05")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-08-21")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-11-18")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-12-16")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-30")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-09-18")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-10-07")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-02-18")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-03-03")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-26")]]
        ]
        
    }
    
    /**
     * finished
     *
     * @return
     */
    public static def getQueryList_CA_1_8() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-20")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-23")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-10-13")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-10-27")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-12-13")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-06-08")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-06-13")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-11-06")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-12-05")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-12-07")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-01-16")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-01-18")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-02-22")]],
//            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-06-29")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-08-09")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-09-15")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-10-25")]]
        ]
        
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CA_1_9() {
        
        def queryList = [
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-10-28")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-12-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-02-28")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-03-26")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-06-30")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-07-09")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-17")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-10-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-05")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-21")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-03-12")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-04-29")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-06-15")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-08-19")]]
        ]
        
    }
    
    /**
     * finished:
     *
     * @return
     */
    public static def getQueryList_CA_1_10() {
        
        def queryList = [
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-05")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-06-30")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-10-27")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-12-08")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-02-16")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-02-21")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-06")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-29")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-08-06")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-10-31")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-11-05")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-12-24")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-02-11")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-06-25")]],
            [country: "CA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-07-29")]],
        ]
        
        return queryList;
    }
    
    /**
     * finished:
     * 
     * @return
     */
    public static def getQueryList_CA_2() {
        
        def queryList = [
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "CA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def queryList_CH() {
        
        def queryList = [
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1888-11-01")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1906-02-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1915-04-16")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1923-08-01")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1929-01-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1933-05-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1937-07-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1942-03-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1947-01-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-01-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1954-06-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-10-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-10-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-10-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-06-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-05-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-04-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-03-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-05-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-06-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-08-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-11-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-07-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-04-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-02-29")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-12-31")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-09-13")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-06-15")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-02-27")]],
//            [country: "CH", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-07-31")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CH", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "CH", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CL() {
        
        def queryList = [
//            [country: "CL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-03-18")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CS() {
        
        def queryList = [
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1911-08-25")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-31")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-05-29")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-07-16")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-10-15")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-07-15")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-02-19")]],
            [country: "CS", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-11-18")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CS", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CS", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CO() {
        
        def queryList = [
            [country: "CO", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-02-13")]],
            [country: "CO", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-05-20")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CO", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CO", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_CR() {
        
        def queryList = [
            [country: "CR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-07-13")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished:
     * 
     * @return
     */
    public static def qetQueryList_CU() {
        
        def queryList = [
            [country: "CU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-02-13")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished:
     * 
     * @return
     */
    public static def getQueryList_CY() {
        
        def queryList = [
            [country: "CY", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1921-05-06")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CY", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "CY", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
    }
    
    /**
     * TODO
     *
     * @return
     */
    public static def getQueryList_CZ() {
        
        def queryList = [
//            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-12-16")]],
//            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-06-14")]],
//            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-06-16")]],
//            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-13")]],
            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-07-17")]],
            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-30")]],
            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-12-18")]],
            [country: "CZ", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-06-25")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "CZ", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "CZ", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_DE_1() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1920-12-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1922-12-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1924-06-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1926-05-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1928-05-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1931-04-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1932-07-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1933-10-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1935-07-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1937-06-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1939-05-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1941-05-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1943-04-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1952-01-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1952-09-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1952-10-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1953-02-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1953-06-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1954-03-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1955-08-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-02-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-12-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-07-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-12-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1958-11-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1959-09-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1959-10-22")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQueryList_DE_1_2() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-04-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-11-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-05-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-09-28")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-08-30")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-03-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-10-31")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-11-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1964-09-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-04-22")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-08-12")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-05-05")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-06-16")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-11-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-04-20")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-02-08")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-03-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-10-17")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-10-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-03-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-06-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-09-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-11-26")]]
        ] 
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_3() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-02-11")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-03-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-04-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-06-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-07-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-11-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-03-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-03-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-09-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-05-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-06-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-10-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-01-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-05-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-07-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-09-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-10-10")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-12-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-01-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-01-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-04-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-06-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-08-21")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-08-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-11-27")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_4() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-01-15")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-01-29")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-04-15")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-09-15")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-09-29")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-12-15")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-02-16")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-09")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-16")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-30")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-06-01")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-09-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-02-08")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-05-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-05-17")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-07-26")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-08-02")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-07-03")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-10-23")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-11-06")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-02-12")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-06-04")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-07-23")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-11-05")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-08-26")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-11-25")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-03-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-05-05")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-05-19")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-06-30")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-07-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-10-27")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-11-03")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-03-08")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-09-20")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-10-25")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-02-14")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-04-04")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-07-04")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-12-05")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-02-20")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-02-27")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-07-03")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-07-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-07-23")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-12-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-01-28")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-09-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-12-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-12-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-04-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-04-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-07-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-08-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-09-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-09-21")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-11-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-01-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-01-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-03-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-08-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-04-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-05-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-06-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-08-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-09-26")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-10-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-01-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-01-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-04-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-06-17")]],
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_5() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-02-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-03-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-04-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-05-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-06-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-09-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-02-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-03-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-03-10")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-04-21")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-05-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-05-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-06-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-06-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-11-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-11-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-02-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-05-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-06-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-07-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-08-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-09-21")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-26")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_6() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-01-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-01-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-03-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-07-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-08-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-11-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-11-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-12-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-01-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-02-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-05-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-09-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-10-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-10-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-03-26")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-04-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-06-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-07-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-08-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-10-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-12-10")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-12-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-03-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-06-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-07-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-07-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-08-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-10-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-12-09")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_7() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-01-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-03-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-05-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-08-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-09-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-11-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-12-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-01-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-01-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-06-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-07-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-08-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-08-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-10-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-01-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-01-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-04-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-04-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-08-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-10-10")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-10-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-11-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-11-28")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_8() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-01-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-03-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-04-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-04-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-06-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-06-26")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-11-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-12-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-12-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-01-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-02-26")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-03-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-05-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-07-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-08-26")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-10-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-11-04")]]
        ]
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_9() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-03-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-06-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-06-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-07-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-08-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-10-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-10-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-11-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-12-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-01-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-01-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-03-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-03-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-05-04")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-05-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-05-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-06-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-07-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-07-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-08-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-08-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-10-12")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_10() {
        
        def queryList = [
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-01-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-02-01")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-03-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-07-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-07-19")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-08-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-10-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-10-18")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-10-25")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-15")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-12-20")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-01-10")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-01-31")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-02-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-04-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-05-08")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-05-21")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-07-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-07-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-08-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-09-11")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-10-23")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-12-04")]]
        ]
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_11() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-04-02")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-05-07")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-05-28")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-10")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-09-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-10-29")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-12-03")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-12-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-04-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-05-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-05-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-06-17")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-07-22")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-09-30")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-12-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-12-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-01-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-02-24")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-12")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-07-14")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-09-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-10-27")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_1_12() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-01-26")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-03-15")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-03-22")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-06-14")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-08-02")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-11-29")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-03-21")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-06")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-13")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-27")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-10-02")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-12-05")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-01-09")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-05-28")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-08-07")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-10-16")]],
            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-11-06")]]
        ]
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DE_2() {
        
        def queryList = [
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
//            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
//            [country: "DE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
//            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "DE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DD() {
        
        def queryList = [
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-06-14")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-06-12")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-01-31")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-04-28")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-10-24")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-07-16")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-10-05")]],
            [country: "DD", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-10-31")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DD", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "DD", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_DK_1() {
        
        def queryList = [
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1895-03-25")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1919-10-06")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1964-08-03")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-26")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-09-08")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-06-22")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-05-10")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-08-20")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-12-04")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-08-06")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-09-12")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-02-19")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-12-09")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-06-30")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-09-04")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-07-06")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-12-23")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-07-24")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-02-24")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-07-31")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-06-25")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-11-01")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-11-08")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-06-30")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-09-01")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-04-22")]],
            [country: "DK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-10-21")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished:
     * @return
     */
    public static def getQueryList_DK_2() {
        
        def queryList = [
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "DK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "DK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished:
     * @return
     */
    public static def getQueryList_ES_1() {
        
        def queryList = [
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1836-03-26")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1949-11-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-01-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-02-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-05-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-03-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-07-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-09-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-01-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-12-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-02-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-07-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-03-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-12-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-09-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-11-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-05-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-11-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-01-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-04-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-05-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-06-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-03-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-10-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-07-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-10-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-06-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-06-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-01-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-08-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-06-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-10-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-04-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-02-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-07-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-10-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-04-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-08-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-03-16")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-11-16")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_ES_1_2() {
        
        def queryList = [
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-05-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-11-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-11-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-06-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-08-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-12-16")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-06-01")]],
//            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-02-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-07-07")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-10-23")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-03-10")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-10-07")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-11")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-12-21")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-06-01")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-12-17")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-05-27")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-09-18")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-12-02")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-06-03")]],
            [country: "ES", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2015-01-07")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_ES_2() {
        
        def queryList = [
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "ES", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "ES", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_1() {
        
        def queryList = [
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1902-12-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1905-10-13")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1907-11-09")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1910-05-09")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1912-05-31")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1913-09-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1914-06-22")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1919-11-21")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1921-09-21")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1923-09-10")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1925-09-01")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1927-10-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1929-08-05")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1930-12-22")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1932-07-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1934-05-17")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1936-05-01")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1937-10-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1938-07-27")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1941-03-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1945-01-17")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1947-10-31")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1950-04-28")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_1_2() {
        
        def queryList = [
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-11-08")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1953-04-16")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1954-03-01")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1955-02-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-05-22")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-11-15")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1959-03-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-01-27")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-10-05")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-04-21")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-12-08")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-03-02")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-12-14")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-09-27")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1964-06-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-02-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-10-29")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-06-03")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-01-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-08-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-03-08")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-10-04")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-05-23")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-04-17")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-06-22")]]
       ]
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_1_3() {
        
        def queryList = [
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-05-07")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-01-28")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-10-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-02-09")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-06-22")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-10-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-01-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-09-06")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-11-29")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-03-14")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-06-06")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-10-24")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-12-17")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-05-06")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-07-15")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-08-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-02-10")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-05-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-10-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-01-05")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-03-23")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-07-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-10-12")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_1_4() {
        
        def queryList = [
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-01-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-07-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-03-20")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-06-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-08-07")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-07-30")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-11-12")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-11-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-03-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-06-17")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-12-02")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-05-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-05-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-06-08")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-04-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-07-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-10-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-09-19")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-10-31")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-05-22")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-08-07")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-01-06")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-04-07")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-08-11")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-15")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_1_5() {
        
        def queryList = [
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-03-09")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-07-20")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-05-10")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-05-07")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-02-26")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-10-01")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-04-22")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-05-06")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-01-13")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-06-23")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-08-25")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-01-12")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-03-21")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-04-04")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-04-30")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-06-19")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-11-27")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-01-07")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-09-08")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-01-05")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-03-16")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-01-11")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-29")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-10-10")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-02-06")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-02-20")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-08-13")]],
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-11-05")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-02-18")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-03-03")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-04-28")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-09-15")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-10-26")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-07-04")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-01-16")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-07-03")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-29")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-06-04")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-09-03")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-12-24")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-07-01")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-07-13")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-03-14")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-05-16")]],
            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-10-10")]]
        ]
        
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FR_2() {
        
        def queryList = [
//            [country: "FR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-12-05")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "FR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "FR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_GB_1() {
        
        def queryList = [
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1896-04-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1899-01-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1900-09-08")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1902-11-06")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1905-02-09")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1907-02-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1908-02-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1910-02-17")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1910-10-27")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1913-01-09")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1914-04-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1915-09-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1919-02-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1921-05-26")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1921-10-27")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1924-06-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1925-09-10")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1927-03-31")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1928-01-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1929-02-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1930-03-27")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1931-05-14")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1932-03-17")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1933-03-16")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1934-05-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1935-05-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1936-05-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1937-07-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1938-07-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1939-07-06")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1940-11-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1942-10-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1945-03-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1947-04-16")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1948-08-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1949-07-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1950-10-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-12-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1952-10-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1953-11-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1954-10-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1955-08-10")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1956-07-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-03-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-12-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1958-11-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1959-10-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-06-22")]]
        ]
        
        return queryList;
    }
    
    /**
     * 
     * @return
     */
    public static def getQueryList_GB_1_2() {
        
        def queryList = [
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-12-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1961-07-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-02-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1962-09-26")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-04-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1963-10-09")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1964-04-08")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1964-09-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-03-24")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1965-08-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-01-05")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-06-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1966-10-26")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-03-22")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-08-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1967-11-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-04-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1968-08-14")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-01-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-05-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1969-10-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-03-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-07-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-11-25")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-04-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1971-09-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-01-19")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-06-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1972-10-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-02-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-07-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-11-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-06-05")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-10-16")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-02-26")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-07-16")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-12-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-04-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-08-18")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-01-19")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-06-22")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-11-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-04-19")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-09-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-02-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-10-17")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-02-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-08-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-12-10")]]
        ]
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_GB_1_3() {
        
        def queryList = [
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-01-14")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-05-20")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-10-21")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-03-24")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-07-07")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-09-15")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-03-09")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-04-27")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-11-09")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-02-22")]],
//            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-06-27")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-01-09")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-06-05")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-11-27")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-01-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-04-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-05-14")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-11-05")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-12-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-04-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-10-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-11-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-08-24")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-10-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-06-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-10-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-11-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-06")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-12-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-08-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-11-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-01-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-02-24")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-06-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-03-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-04-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-05-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-06-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-04")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-08-14")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-03-12")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-09-17")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-08-05")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-10-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-10-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-09-22")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-10-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-04-26")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-10-25")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-12-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-03-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-04-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-08-08")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-06")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-03-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-07-31")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-19")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-12-24")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-03-03")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-07")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-07-21")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-03-23")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-07-13")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-09-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-03-01")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-05-10")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-12-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-06-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-07-18")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-07-25")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-10-22")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-10-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-01-28")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-02-24")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-10-20")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-11-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-02-15")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-05-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-05-29")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-09-11")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-10-02")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-04-30")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-05-14")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-06-25")]],
            [country: "GB", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-11-26")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_GB_2() {
        
        def queryList = [
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "GB", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "GB", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_FI() {
        
        def queryList = [
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1842-06-29")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1951-01-10")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-10-01")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-01-14")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-12-10")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-08-02")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-05-31")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-09-03")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-12-25")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-01-25")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-05-10")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-12-12")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-06-15")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-01-24")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-02-19")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-05-26")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-09-15")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-11-14")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-09-15")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-12-02")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-06-09")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-02-15")]],
//            [country: "FI", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-05-25")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "FI", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "FI", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_GR() {
        
        def queryList = [
            [country: "GR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1920-12-11")]],
            [country: "GR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-03-20")]],
            [country: "GR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-11-12")]],
            [country: "GR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-07-30")]],
            [country: "GR", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-02-29")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "GR", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "GR", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_HK() {
        
        def queryList = [
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-01-14")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-11-28")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-06-23")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-07-14")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-30")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-02-01")]],
            [country: "HK", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-02-08")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "HK", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "HK", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_HU() {
        
        def queryList = [
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-08-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-01-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-10-30")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-08-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-03-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-04-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-09-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-06-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-11-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-12-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-01-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-01-28")]],
            [country: "HU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-05-29")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "HU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "HU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_IE() {
        
        def queryList = [
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-07-30")]],
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-08-23")]],
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-09-13")]],
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-04-29")]],
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-04-06")]],
            [country: "IE", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-09-09")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "IE", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "IE", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_IL() {
        
        def queryList = [
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-01-30")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-08-31")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-02-29")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-09-30")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-01-19")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-12-22")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-02-29")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-04-21")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-03-28")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-07-05")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-01-20")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-05-31")]],
            [country: "IL", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-01-31")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "IL", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "IL", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_IT_1() {
        
        def queryList = [
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-06-30")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-07-20")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-02-20")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-20")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-03-28")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-11-29")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-07-11")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-06-10")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-02-09")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-06-23")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-06-29")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-03-21")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-03-29")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-07-12")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-02-10")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-09-17")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-09-30")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-03-11")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-10-05")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-10-11")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-03-10")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-02-06")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-06-06")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-04-06")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-04-07")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-06-13")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-10-02")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-05-21")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-06-09")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-01-23")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-09-10")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-01-21")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-05-27")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-02-19")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-08-13")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-06-24")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-14")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-11-25")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-12-17")]],
//            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-04-24")]],
            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-11-28")]],
            [country: "IT", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-11-20")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_IT_2() {
        
        def queryList = [
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
//            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
//            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "IT", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "IT", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_SU_1() {
        
        def queryList = [
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1924-09-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1934-06-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1949-11-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1957-11-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1960-11-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1973-04-05")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1974-04-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-05-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1976-06-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1977-07-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-02-28")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-09-25")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-04-05")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1979-09-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-03-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-08-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1980-12-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-04-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-07-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-11-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-03-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-07-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1982-11-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-03-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1983-08-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-01-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1984-07-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-02-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-07-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-12-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-05-23")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1986-10-23")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-03-23")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-08-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-02-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-07-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1988-12-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-05-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1989-10-23")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-03-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-08-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-02-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-06-30")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1991-11-07")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-03-15")]],
            [country: "SU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-07-23")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_SU_2() {
        
        def queryList = [
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "SU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "SU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * @return
     */
    public static def getQueryList_RU_1() {
        
        def queryList = [
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1992-12-30")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-05-07")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-01-15")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1994-06-25")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1995-03-10")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-02-20")]],
//            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-05-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-11-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-04-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1997-12-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1998-09-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-09-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2000-08-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2001-10-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2002-11-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-02-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-08-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-03-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-04-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-02-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-10-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-11-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-03-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2006-08-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-05-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2007-11-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-01-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-02-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-08-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-01-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-03-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-08-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-11-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2009-12-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-06-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-07-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-12-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-02-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-05-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-10-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-02-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-03-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-08-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2012-10-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-01-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-05-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-06-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-08-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-09-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-01-10")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-01-20")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-01-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-05-27")]],
            [country: "RU", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2014-07-27")]]
        ]
        
        return queryList;
    }
    
    /**
     * TODO
     * @return
     */
    public static def getQueryList_RU_2() {
        
        def queryList = [
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
//            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
//            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "RU", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-25")]],
            [country: "RU", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * finished
     * 
     * @return
     */
    public static def getQuery_UA() {
        
        def queryList = [
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-09-15")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2004-12-15")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-03-11")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2010-01-11")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-07-11")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2011-10-10")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-04-10")]],
            [country: "UA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2013-12-25")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-28")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "UA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "UA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
    
    /**
     * TODO
     * @return
     */
    public static def getQueryList_ZA() {
        
        def queryList = [
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1970-01-01")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1975-01-29")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1978-01-25")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1981-08-26")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1985-02-27")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1987-03-25")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1990-05-30")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1993-05-04")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1996-08-28")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("1999-02-22")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2003-04-23")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2005-05-19")]],
            [country: "ZA", query: [fileType: 0, docdbDoDate: DateUtil.parseDate("2008-09-25")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-01")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-08")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-15")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-22")]],
            [country: "ZA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-01-29")]],
            [country: "ZA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-05")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-12")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-19")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-02-26")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-05")]],
            [country: "ZA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-12")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-19")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-03-26")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-02")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-09")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-16")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-23")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-04-30")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-07")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-14")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-21")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-05-28")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-04")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-11")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-18")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-06-25")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-02")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-09")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-16")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-23")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-07-30")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-06")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-13")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-20")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-08-27")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-03")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-10")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-17")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-09-24")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-01")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-08")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-15")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-22")]],
            [country: "ZA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-10-29")]],
            [country: "ZA", query: [fileType: 1, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-05")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-12")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-19")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-11-26")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-03")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-17")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-24")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-31")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-07")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-14")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-01-21")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-04")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-11")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-18")]],
            [country: "ZA", query: [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]]
        ]
        
        return queryList;
    }
  
    public static def getQueryList_AT_TEMPLATE() {
        
        def queryList = [
            
        ]
        
        return queryList;
    }
    
}
