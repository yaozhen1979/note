package com.patentdata.util

import org.codehaus.groovy.transform.tailrec.VariableReplacedListener.*

import com.patentdata.common.Constants
import com.patentdata.model.PatData
import com.patentsolr.model.SolrPatentInfo

/**
 * @author mikelin
 *
 */
public class SolrNumberUtil {
    
    /**
     * @param solrInfo
     * @param patData
     * @param appData
     */
    public static void getAppNumberAll(PatData patData, SolrPatentInfo solrInfo) {
        //  TODO:
        switch (patData.country) {
            case "US":
                getAppNumberAllUS(patData, solrInfo);
                break;
            case "CN":
            // TODO:
                break;
            case "JP":
            // TODO:
                break;
            case "TW":
            // TODO:
                break;
            case "EP":
                getAppNumberAllEP(patData, solrInfo)
                break;
            case "WO":
            // TODO:
                break;
            case "KR":
            // TODO:
                break;

        }
    }
    
    public static void getAppNumberAllEP(PatData patData, SolrPatentInfo solrInfo) {
        String originAppNo = solrInfo.appNumber;
        genAppNumberEP(solrInfo, originAppNo);
        genAppNumberEPWithKind(solrInfo, patData.kindCode, originAppNo);
        genAppNumberEPWithCountry(solrInfo, patData.country, originAppNo);
        genAppNumberEPWithKindAndCountry(solrInfo, patData.country, patData.kindCode, originAppNo);
        removeDuplicate(solrInfo.appNumberAll);
    }
    
    /**
     * @param solrInfo
     * @param patData
     * @param appData
     */
    public static void getAppNumberAllUS(PatData patData, SolrPatentInfo solrInfo) {
        
        String[] appNumberArry = solrInfo.appNumber.split("/");
        
        String seriesCode = appNumberArry[0];
        if (seriesCode == "D") {
            throw new Exception("appNumber seriesCode error!")
        }
        
        String number = appNumberArry[1];
        if (number.length() != 6) {
            throw new Exception("appNumber error!")
        }
        
        // 兩碼數字+/+六碼數字
        appNumberAllFormatUS(solrInfo, solrInfo.appNumber, patData.country, patData.kindCode);
        
        // 六碼數字
        appNumberAllFormatUS(solrInfo, number, patData.country, patData.kindCode);
         
        // 兩碼數字+/+(六碼數字,三位一撇)
        appNumberAllFormatUS(solrInfo, seriesCode + "/" + StringUtil.thousandsSeparatorToString(number), patData.country, patData.kindCode);
        
        if (seriesCode == "29") {
            appNumberAllFormatUS(solrInfo, "D" + "/" + number, patData.country, patData.kindCode);
        }
        
        removeDuplicate(solrInfo.appNumberAll);
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    public static void getPublicationNumberAll(PatData patData, SolrPatentInfo solrInfo) {
        //  TODO:
        switch (patData.country) {
            case "US":
                getPublicationNumberAllUS(patData, solrInfo);
                break;
            case "CN":
            // TODO:
                break;
            case "JP":
            // TODO:
                break;
            case "TW":
            // TODO:
                break;
            case "EP":
                getPublicationNumberAllEP(patData, solrInfo);
                break;
            case "WO":
            // TODO:
                break;
            case "KR":
            // TODO:
                break;

        }
    }
    
    public static void getPublicationNumberAllEP(PatData patData, SolrPatentInfo solrInfo) {
        String docNo = solrInfo.patentNumber;
        genPublicationNumberWithZero(solrInfo, patData.kindCode, docNo);
        genPublicationNumberWithoutZero(solrInfo, patData.kindCode, docNo);
        removeDuplicate(solrInfo.patentNumberAll);
    }
    
    /**
     * @param solrInfo
     * @param patData
     */
    public static void getPublicationNumberAllUS(PatData patData, SolrPatentInfo solrInfo) {
        
        // openNumberAll
        if (patData.stat == Constants.PAT_STAT_PUBLIC) {
            String openYear = patData.docNo[0..3];
            String number = patData.docNo[4..-1];
            // 四碼西元年+七碼數字
            openNumberAllFormatUS(solrInfo, patData.docNo, patData.country, patData.kindCode);
            //四碼西元年+數字(濾掉七碼數字前面的0)
            openNumberAllFormatUS(solrInfo, openYear + number.replaceFirst(/^0(?!$)/, ""), patData.country, patData.kindCode);
            // 
            removeDuplicate(solrInfo.openNumberAll);
        } else if (Constants.PAT_STAT_ISSUE) {
            
            // 全數字 or 文字+數字
            decisionNumberAllFormatUS(solrInfo, patData.docNo, patData.country, patData.kindCode);
            // 全數字 or 文字+數字 千分位逗號
            String number = patData.docNo.replaceAll(/([A-Za-z]{0,2})(\d+)/){full, engChar, no ->
                return engChar + StringUtil.thousandsSeparatorToString(no);
            }
            decisionNumberAllFormatUS(solrInfo, number, patData.country, patData.kindCode);
            
            removeDuplicate(solrInfo.decisionNumberAll);
        }
        
    }
    
    /**
     * @param solrInfo
     * @param number
     * @param country
     * @param kindCode
     */
    private static void openNumberAllFormatUS(SolrPatentInfo solrInfo, String number, String country, String kindCode){
        solrInfo.openNumberAll.add(number);
        solrInfo.openNumberAll.add(country + number);
        solrInfo.openNumberAll.add(number + kindCode);
        solrInfo.openNumberAll.add(country + number + kindCode);
    }
    
    /**
     * @param solrInfo
     * @param number
     * @param country
     * @param kindCode
     */
    private static void decisionNumberAllFormatUS(SolrPatentInfo solrInfo, String number, String country, String kindCode){
        solrInfo.decisionNumberAll.add(number);
        solrInfo.decisionNumberAll.add(country + number);
        solrInfo.decisionNumberAll.add(number + kindCode);
        solrInfo.decisionNumberAll.add(country + number + kindCode);
    }
    
    /**
     * @param solrInfo
     * @param number
     * @param country
     * @param kindCode
     */
    private static void appNumberAllFormatUS(SolrPatentInfo solrInfo, String number, String country, String kindCode){
        solrInfo.appNumberAll.add(number);
        solrInfo.appNumberAll.add(country + number);
        solrInfo.appNumberAll.add(number + kindCode);
        solrInfo.appNumberAll.add(country + number + kindCode);
    }
    
    public static void genPublicationNumberWithZero(SolrPatentInfo solrInfo, String kind, String docNo) {
        String country = docNo[0..1];
        String restDocNo = docNo[2..-1];
        // 0001257
        solrInfo.patentNumberAll.add(restDocNo);
        // 0001257B1
        solrInfo.patentNumberAll.add(restDocNo + kind);
        // EP0001257
        solrInfo.patentNumberAll.add(docNo);
        // EP0001257B1
        solrInfo.patentNumberAll.add(docNo + kind);
    }
    
    public static void genPublicationNumberWithoutZero(SolrPatentInfo solrInfo, String kind, String docNo) {
        String country = docNo[0..1];
        String restDocNo = docNo[2..-1];
        String docNoWithoutZero = restDocNo.replaceFirst("^0*","");
//        1257
        solrInfo.patentNumberAll.add(docNoWithoutZero);
//        1257B1
        solrInfo.patentNumberAll.add(docNoWithoutZero + kind);
//        EP1257
        solrInfo.patentNumberAll.add(country + docNoWithoutZero);
//        EP1257B1
        solrInfo.patentNumberAll.add(country + docNoWithoutZero + kind);
    }
    
    public static void genAppNumberEP(SolrPatentInfo solrInfo, String appNo)  {
        String halfYear = appNo[0..1];
        String restAppNo = appNo[2..-3];
        String checkDigit = appNo[-1];
        String wholeYear = new PatNumberUtil().getYearWO(halfYear);
        // 11700204.8
        solrInfo.appNumberAll.add(appNo);
        // 117002048
        solrInfo.appNumberAll.add(restAppNo + checkDigit);
        // 11700204
        solrInfo.appNumberAll.add(restAppNo);
        // 2011700204.8
        solrInfo.appNumberAll.add(wholeYear + restAppNo + "." + checkDigit);
        // 20117002048
        solrInfo.appNumberAll.add(wholeYear + restAppNo + checkDigit);
        // 2011700204
        solrInfo.appNumberAll.add(wholeYear + restAppNo);
        // 20110700204
        solrInfo.appNumberAll.add(wholeYear + Constants.ZERO.toString() + restAppNo);
        
    }
    
    public static void genAppNumberEPWithKind(SolrPatentInfo solrInfo, String kind, String appId) {
        String halfYear = appId[0..1];
        String restAppNo = appId[2..-3];
        String checkDigit = appId[-1];
        String wholeYear = new PatNumberUtil().getYearWO(halfYear);
        // 117002048B1
        solrInfo.appNumberAll.add(halfYear + restAppNo + checkDigit + kind);
        // 11700204B1
        solrInfo.appNumberAll.add(halfYear + restAppNo + kind);
        // 11700204.8B1
        solrInfo.appNumberAll.add(halfYear + restAppNo + "." + checkDigit + kind);
        // 2011700204.8B1
        solrInfo.appNumberAll.add(wholeYear + restAppNo + "." + checkDigit + kind);
        // 20117002048B1
        solrInfo.appNumberAll.add(wholeYear + restAppNo + checkDigit + kind);
        // 2011700204B1
        solrInfo.appNumberAll.add(wholeYear + restAppNo + kind);
        // 20110700204B1
        solrInfo.appNumberAll.add(wholeYear + Constants.ZERO.toString() + restAppNo + kind);
    }
    
    public static void genAppNumberEPWithCountry(SolrPatentInfo solrInfo, String country, String appId) {
        String halfYear = appId[0..1];
        String restAppNo = appId[2..-3];
        String checkDigit = appId[-1];
        String wholeYear = new PatNumberUtil().getYearWO(halfYear);
        // EP117002048
        solrInfo.appNumberAll.add(country + halfYear + restAppNo + checkDigit);
        // EP11700204
        solrInfo.appNumberAll.add(country + halfYear + restAppNo);
        // EP11700204.8
        solrInfo.appNumberAll.add(country + halfYear + restAppNo + "." + checkDigit);
        // EP2011700204.8
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo + "." + checkDigit);
        // EP20117002048
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo + checkDigit);
        // EP2011700204
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo);
        // EP20110700204
        solrInfo.appNumberAll.add(country + wholeYear + Constants.ZERO.toString() + restAppNo);
    }
    
    public static void genAppNumberEPWithKindAndCountry(SolrPatentInfo solrInfo, String country, String kind,  String appId) {
        String halfYear = appId[0..1];
        String restAppNo = appId[2..-3];
        String checkDigit = appId[-1];
        String wholeYear = new PatNumberUtil().getYearWO(halfYear);
        // EP117002048B1
        solrInfo.appNumberAll.add(country + halfYear + restAppNo + checkDigit + kind);
        // EP11700204B1
        solrInfo.appNumberAll.add(country + halfYear + restAppNo + kind);
        // EP11700204.8B1
        solrInfo.appNumberAll.add(country + halfYear + restAppNo + "." + checkDigit + kind);
        // EP2011700204.8B1
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo + "." + checkDigit + kind);
        // EP20117002048B1
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo + checkDigit + kind);
        // EP2011700204B1
        solrInfo.appNumberAll.add(country + wholeYear + restAppNo + kind);
        // EP20110700204B1
        solrInfo.appNumberAll.add(country + wholeYear + Constants.ZERO.toString() + restAppNo + kind);
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    public static void getPctAppNumberAll(PatData patData, SolrPatentInfo solrInfo) {
        
        //  TODO:
        switch (patData.country) {
            case "US":
                getPctAppNumberAllUS(patData, solrInfo);
                break;
            case "CN":
            // TODO:
                break;
            case "JP":
            // TODO:
                break;
            case "TW":
            // TODO:
                break;
            case "EP":
                getPctAppNumberAllEP(patData, solrInfo);
                break;
            case "WO":
            // TODO:
                break;
            case "KR":
            // TODO:
                break;

        }
        
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    public static void getPctAppNumberAllUS(PatData patData, SolrPatentInfo solrInfo) {
        
        if (!!solrInfo.pctAppNumber) {
            
            // PCT/EP2000/012768
            solrInfo.pctAppNumber.replaceAll(/PCT\/([A-Z]{2})([0-9]{4})\/([0-9]{6})/) {fullAppNumber, country, year, serialNo ->
                
                // PCT+/+國別大寫兩碼+申請年四碼西元年+/+六碼數字
                pctAppNumberAllFormatUS(solrInfo, fullAppNumber);
                
                // 國別大寫兩碼+申請年四碼西元年+/+六碼數字
                pctAppNumberAllFormatUS(solrInfo, country + year + "/" + serialNo);
                
                // 國別大寫兩碼+申請年四碼西元年+/+數字(濾掉前面的0)
                pctAppNumberAllFormatUS(solrInfo, country + year + "/" + serialNo.replaceFirst(/^0(?!$)/, ""));
                
                // PCT+國別大寫兩碼+申請年四碼西元年+六碼數字
                pctAppNumberAllFormatUS(solrInfo, fullAppNumber.replaceAll("/", ""));
                
                // 國別大寫兩碼+申請年四碼西元年+六碼數字
                pctAppNumberAllFormatUS(solrInfo, country + year + serialNo);
                
                // 國別大寫兩碼+申請年四碼西元年+數字(濾掉前面的0)
                pctAppNumberAllFormatUS(solrInfo, country + year + serialNo.replaceFirst(/^0(?!$)/, ""));
            }
            
            removeDuplicate(solrInfo.pctAppNumberAll);
        }
    }
    
    /**
     * @param solrInfo
     * @param number
     * @param country
     * @param kindCode
     */
    private static void pctAppNumberAllFormatUS(SolrPatentInfo solrInfo, String number){
        solrInfo.pctAppNumberAll.add(number);
        solrInfo.pctAppNumberAll.add("WO" + number);
    }
    
    public static void getPctAppNumberAllEP(PatData patData, SolrPatentInfo solrInfo) {
        if (!!solrInfo.pctAppNumber) {
            solrInfo.pctAppNumber.replaceAll("(PCT)/(\\p{Upper}{2})(\\d{4})/(\\d+)") { String fullDoc, String pct, String country, String year, String appNo ->
//                PCT+/+國別大寫兩碼+申請年四碼西元年+/+六碼數字
                genPctAppNumberEP(solrInfo, fullDoc);
//                國別大寫兩碼+申請年四碼西元年+/+六碼數字
                genPctAppNumberEP(solrInfo, country + year + "/" + appNo);
//                國別大寫兩碼+申請年四碼西元年+/+數字(濾掉前面的0)
                genPctAppNumberEP(solrInfo, country + year + "/" + appNo.replaceFirst(/^0*/, ""));
//                PCT+國別大寫兩碼+申請年四碼西元年+六碼數字
                genPctAppNumberEP(solrInfo, pct + country + year + appNo);
//                國別大寫兩碼+申請年四碼西元年+六碼數字
                genPctAppNumberEP(solrInfo, country + year + appNo);
//                國別大寫兩碼+申請年四碼西元年+數字(濾掉前面的0)
                genPctAppNumberEP(solrInfo, country + year + appNo.replaceFirst(/^0*/, ""));
            }
            removeDuplicate(solrInfo.pctAppNumberAll);
        }
    }
    
    public static void genPctAppNumberEP(SolrPatentInfo solrInfo, String formatPctAppNo) {
        solrInfo.pctAppNumberAll.add(formatPctAppNo);
        solrInfo.pctAppNumberAll.add("WO" + formatPctAppNo);
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    public static void getPctOpenNumberAll(PatData patData, SolrPatentInfo solrInfo) {
        
        //  TODO:
        switch (patData.country) {
            case "US":
                getPctOpenNumberAllUS(patData, solrInfo);
                break;
            case "CN":
            // TODO:
                break;
            case "JP":
            // TODO:
                break;
            case "TW":
            // TODO:
                break;
            case "EP":
                getPctOpenNumberAllEP(patData, solrInfo);
                break;
            case "WO":
            // TODO:
                break;
            case "KR":
            // TODO:
                break;

        }
        
    }
    
    public static void getPctOpenNumberAllEP(PatData patData, SolrPatentInfo solrInfo) {
        if (!!solrInfo.pctOpenNumber) {
            solrInfo.pctOpenNumber.replaceAll(/(\d+)\/(\d+)/) { fullDoc, year, openNo ->
    //            公開年四碼西元年+/+六碼數字
                genPctOpenNumberEP(solrInfo, fullDoc);
    //            公開年四碼西元年+/+數字(濾掉前面的0)
                genPctOpenNumberEP(solrInfo, year + "/" + openNo.replaceFirst(/^0*/,""));
    //            公開年四碼西元年+六碼數字
                genPctOpenNumberEP(solrInfo, year + openNo);
    //            公開年四碼西元年+數字(濾掉前面的0)
                genPctOpenNumberEP(solrInfo, year + openNo.replaceFirst(/^0*/,""));
            }
            removeDuplicate(solrInfo.pctOpenNumberAll);
        }
    }
    
    public static void genPctOpenNumberEP(SolrPatentInfo solrInfo, String openNumber) {
        solrInfo.pctOpenNumberAll.add(openNumber);
        solrInfo.pctOpenNumberAll.add("WO" + openNumber);
    }
    
    /**
     * @param patData
     * @param solrInfo
     */
    public static void getPctOpenNumberAllUS(PatData patData, SolrPatentInfo solrInfo) {
        
        if (!!solrInfo.pctOpenNumber) {
            
            String[] openNumberArry = solrInfo.pctOpenNumber.split("/");
            String year = openNumberArry[0];
            String serialNo = openNumberArry[1];
            
            // 公開年四碼西元年+/+六碼數字
            pctOpenNumberAllFormatUS(solrInfo, solrInfo.pctOpenNumber);
            
            // 公開年四碼西元年+/+數字(濾掉前面的0)
            pctOpenNumberAllFormatUS(solrInfo, year + "/" + serialNo.replaceFirst(/^0(?!$)/, ""));
            
            // 公開年四碼西元年+六碼數字
            pctOpenNumberAllFormatUS(solrInfo, year + serialNo);
            
            // 公開年四碼西元年+數字(濾掉前面的0)
            pctOpenNumberAllFormatUS(solrInfo, year + serialNo.replaceFirst(/^0+(?!$)/, ""));
            
            removeDuplicate(solrInfo.pctOpenNumberAll);
        }
    }
    
    /**
     * @param solrInfo
     * @param number
     * @param kindCode
     */
    private static void pctOpenNumberAllFormatUS(SolrPatentInfo solrInfo, String number){
        solrInfo.pctOpenNumberAll.add(number);
        solrInfo.pctOpenNumberAll.add("WO" + number);
    }
    
    /**
     * 去除重複
     * @param datas
     * @return
     */
    private static ArrayList<String> removeDuplicate(ArrayList<String> datas) {
        
        ArrayList<String> uniqueNames = new ArrayList<String>();
        
        for (String data : datas) {
            if (!uniqueNames.contains(data)) {
                uniqueNames.add(data);
            }
        }
        return uniqueNames;
    }
    
    public static void main(String[] args) {
        String docNo = "20120279753"
        println docNo[0..3] + ", " + docNo[4..-1]
        
    }
}
