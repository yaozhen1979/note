package com.patentdata.util

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.helper.CpcHelper
import com.patentdata.helper.IpcHelper
import com.patentdata.model.Cpc
import com.patentdata.model.Ipc
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCpcId
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsCsetId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatClsUspcId
import com.patentdata.model.PatData
import com.patentsolr.model.classification.IpcInfo

/**
 * @author mikelin
 *
 */
public class PatClsUtil {

    private static Logger log = LoggerFactory.getLogger(this.getClass());
    
    /**
     * CPC/IPC : <BR>
     * Section(A-H)<BR>
     * + Class(兩碼數字,未滿2位須前補0)<BR>
     * + Subclass(A-Z)<BR>
     * + " " <BR>
     * + Main Group(四碼數字,未滿4位無須補0,前有0刪除)<BR>
     * + / <BR>
     * + Subgroup(六位數字,,未滿2位須後補0至兩位)
     * @param section
     * @param classStr
     * @param subClass
     * @param mainGroup
     * @param subGroup
     * @return
     */
    public static String formatClsCpcIPC(String section, String classStr, String subClass
            , String mainGroup, String subGroup) {

        String clsText = "";

        clsText = section;
        clsText += '0' * (2 - classStr.length()) + classStr;
        clsText += subClass;
        clsText += " ";
        clsText += mainGroup.replaceFirst(/^0+(?!$)/, "");
        clsText += "/";
        clsText += (subGroup.length() < 2) ? (subGroup + '0' * (2 - subGroup.length())) : subGroup;
        clsText = clsText.toUpperCase();
        if (!validClsCpcIpc(clsText)) {
            throw new Exception("Cpc or Ipc format error");
        }

        return clsText;
    }

    /**
     * @param clsStr
     * @return
     */
    public static boolean validClsCpcIpc(String clsStr) {

        return clsStr =~ /[A-Z][0-9]{2}[A-Z]\s*[0-9]{0,4}\/[0-9]{1,6}/;
    }

    /**
     * @param clsStr
     * @return
     */
    public static boolean validUSOriIpc(String clsStr) {

        return clsStr =~ /([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})?\/?([0-9]{1,6})/;
    }

    /**
     * @param section
     * @param classStr
     * @param subClass
     * @param mainGroup
     * @param subGroup
     * @return
     */
    public static String formatClsLoc(String locStr) {

        String locText = locStr[0..1] + "-" + locStr[2..3];

        if (!validClsLoc(locText)) {
            throw new Exception("Loc format error");
        }

        return locText;
    }

    /**
     * @param locText
     * @return
     */
    public static boolean validClsLoc(String locText) {

        return locText =~ /[0-9]{2}-[0-9]{2}/;
    }

    /**
     * 資料格式為小於等於9碼之英數字,需再經過處理等於9碼之英數字<BR>
     * (1)用0取代空白<BR>
     * (2)數字結尾則後面再補0至9碼<BR>
     * (3)非數字結為則於數字與英文中間補0至9碼
     * @param uspcStr
     * @return
     */
    public static String formatClsUspc(String uspcStr) {

        String memoChar = "";
        
        if (uspcStr.endsWith("PZT")) {
            uspcStr = uspcStr.replace("PZT","");
            memoChar = "PZT";
        }
        
        // 去除前後 X
        uspcStr = removeCharX(uspcStr);
        String oriUspc = uspcStr;
        // 原始字串長度
        int length = uspcStr.length();
        
        // 如果出現USPC長度為10,把前9碼正規化後再把最後一碼補再後面
        if (length == 10) {
            memoChar = uspcStr.substring(length-1);
            uspcStr = uspcStr.substring(0, length-1);
            length = 9;
        }
        
        // 如果出現 "165DIG  415"類型的,把中間空白去掉
        if (uspcStr =~ /[0-9]{3}DIG\s*[0-9]{3}/) {
            uspcStr = uspcStr.replaceAll("\\s", "");
            length = uspcStr.length();
        }
        
        // 數字最後出現的位置
        int pos;
        char[] array = uspcStr.toCharArray();

        for (int index = length-1; index > -1; index--) {
            if (array[index] =~ /[0-9]/) {
                pos = index;
                break;
            }
        }

        // the lastest char is integer
        if (pos == length-1) {
            uspcStr += "0" * (9-length);
        } else {
            // the lastest char is not integer
            uspcStr = uspcStr[0..pos] + "0" * (9-length) + uspcStr[pos+1..-1];
        }

        uspcStr = uspcStr.replace(" ", "0");

        if (uspcStr.length() != 9) {
            throw new Exception("Uspc format error: size is not equal 9");
        }
        
        String uspcNormal = uspcNormal(uspcStr);
        
        //
        if (uspcNormal.startsWith("D")) {
            if (!checkUspcDesign(uspcNormal)) {
                int idx = oriUspc.indexOf("D");
                uspcStr = oriUspc.substring(0, idx+1) + "0" + oriUspc.substring(idx+1, oriUspc.length());
                
                return formatClsUspc(uspcStr);
            }
            
            // Dx/XX的資料,⇒ 須於D後面額外補0 D0x/XX
            String designUspcMain = uspcNormal.split("/")[0];
            if (!(designUspcMain =~ /(?i)D[0-9]{2}/)) {
                uspcNormal = uspcNormal.replace("D", "D0");
            }
        }
        
        return uspcNormal + memoChar;
    }
    
    public static String uspcNormal(String uspc) {
        
        String main = removeLeftZero(uspc.substring(0, 3));
//        if (uspc[0] == 'D') {    // D 開頭，uspto 會將 DXX 中間的 0 去掉, ex: D02 -> D2
//            main = "D" + removeLeftZero(uspc.substring(1, 3));
//        }
        String group = removeLeftZero(uspc.substring(3, 6));
        if (uspc[3] == 'E') {    // E 開頭，uspto 會將 EXX 中間的 0 去掉, ex: E02 -> E2
            group = "E" + removeLeftZero(uspc.substring(4, 6));
        }
        String subGroup = removeRightZero(uspc.substring(6, 9));
        String result = main + "/" + group;
        if (subGroup.length() > 0) {
            if (subGroup =~ /^00?[A-Z]{1,2}$/) {  // 0 + 英文, 則去掉左邊的 0 與句點
                result += removeLeftZero(uspc.substring(6, 9));
            } else {
                if (group.equals("DIG")) {  //若 group 為 DIG，subGroup只會是數字，且是去掉左邊的0
                    subGroup = removeLeftZero(uspc.substring(6, 9));
                } else if (subGroup =~ /^[1-9]0[A-Z]$/) {
                    subGroup = uspc[6] + "" + uspc[8];
                }
                result += "." + subGroup;
            }
        }
        return result;
    }
    
    private static String removeLeftZero(String s) {
        int i = 0;
        for (; i < s.length(); i++) {
            if (s.charAt(i) != '0') {
                break;
            }
        }
        return s.substring(i);
    }

    private static String removeRightZero(String s) {
        StringBuffer sb = new StringBuffer(s);
        for (int i = sb.length() - 1; i >= 0; i--) {
            if (sb.charAt(i) != '0') {
                break;
            }
            sb.deleteCharAt(i);
        }
        return sb.toString();
    }
    
    /**
     * Section(A-H)+Class(兩碼數字,未滿2位須前補0)+Subclass(A-Z)+" "+Main Group(四碼數字,未滿4位無須補0)+/+Subgroup(六位數字,,未滿2位須前補0至兩位)
     * ex:A61B 5/05, A61B 5/00 , G01N 21/64
     * 
     * @param patData
     * @param ipcStr
     * @param clsVersion
     * @param mainIPC
     * @param item
     * @param isIndexFlag 是否為[linked-indexing-code-group]
     * @param isMainLinkedIndex 是否為[1:main-linked-indexing, 2:sub-linked-indexing(ipc_text replace ":" to "/")]
     * @param isIpcUnlinkedIndexing
     * @return
     * @throws Exception
     */
    public static PatClsIpc getDocdbIpc(PatData patData, String ipcStr, String clsVersion, int item, boolean mainIPC = false, boolean isIndexFlag = false, boolean isMainLinkedIndex = false, boolean isIpcUnlinkedIndexing = false) throws Exception {

        PatClsIpc patClsIpc = new PatClsIpc();
        PatClsIpcId patClsIpcId = new PatClsIpcId();
        patClsIpcId.patId = patData.patId;
        patClsIpcId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patClsIpcId.ipcType = Constants.CLS_TYPE_IPC;
        if (mainIPC) {
            patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_YES;
        } else {
            patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;
        }
        
        if (item == 0) {
            patClsIpcId.item = 1;
        } else {
            patClsIpcId.item = item + 1;
        }
        
        patClsIpc.id = patClsIpcId;

        patClsIpc.ipcText = PatClsUtil.formatDocdbIpc(ipcStr);
        patClsIpc.clsVersion = clsVersion;
        patClsIpc.symbolPosition = " ";
        
        if (isIndexFlag) {
            patClsIpc.indexFlag = Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES;
            if (isMainLinkedIndex) {
                patClsIpc.indexType = Constants.IPC_MAIN_LINKED_INDEXING;
            } else {
                if (isIpcUnlinkedIndexing) {
                    patClsIpc.indexType = Constants.IPC_UNLINKED_INDEXING;
                } else {
                    patClsIpc.indexType = Constants.IPC_SUB_LINKED_INDEXING;
                }
            }
        }
        
        patClsIpc.createDate = new Date();

        return patClsIpc;
    }   // end getDocdbIpc

    /**
     * EX: ipc text B 01D 11/04 A or 3B 01D 11/04 A or 1B 22D
     *     
     *     or [D 04B    12/12     A] => [D, 04B, /, A] => [D04B /]
     *     
     * @param ipcStr
     * @return
     */
    public static String formatDocdbIpc(String ipcStr) {
        
        String ipcText = "";
        String[] ipcArray = ipcStr.trim().split("\\s+");
        
        if (ipcArray.length > 1) {
            //
            String ipcSection = "";
            
            if (ipcArray.length == 2) {
                // 處理例外資料: marshall._id = DOCDB-201511-001-BE-0019.xml/306895394, ipc資料為[E 21D]
                if (ipcStr.replaceAll("\\s", "").length() <= 4) {
                    ipcText = ipcStr.replaceAll("\\s", "");
                    log.debug("ipc data = ${ipcText}, data format error");
                } else {
                    ipcSection = ipcArray[0].substring(1, 2);
                    ipcText = ipcSection + ipcArray[1];
                }
            } else if (ipcArray.length == 4) {
                // 亂寫...
                ipcSection = ipcArray[0];
                if (ipcArray[2] == "/") {
                    String rawIpc = ipcSection + ipcArray[1];
                    ipcText = rawIpc;
                } else {
                    String rawIpc = ipcSection + ipcArray[1] + " " + ipcArray[2];
                    String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z]) ([0-9]{0,4})\/([0-9]{1,6})/;
                    rawIpc.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                        ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                    }
                }
            } else {
                ipcSection = ipcArray[0];
                String rawIpc = ipcSection + ipcArray[1] + " " + ipcArray[2];
                String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z]) ([0-9]{0,4})\/([0-9]{1,6})/;
                rawIpc.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                    ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                }
            }   // end if (ipcArray.length == 2)
            
        } else {
            
            // AP, DOCDB-201511-001-AP-0001.xml/381759991, ipc text = 7
            ipcText = ipcStr.trim();
            log.debug("ipc data = ${ipcText}, data format error");
            
        }   // end if (ipcArray.length > 1)
        
        return ipcText;
        
    }   // end formatDocdbIpc

    /**
     * 
     * 23碼字串拆解規則:
     * 
     *       |  欄位定義:                                         |  格式,可出現之值:
     * 1~8   |  Version indicator                                 |  YYYYMMDD
     * 9     |  Classification level                              |  C,A,S
     * 10    |  position of symbol                                |  F,L,空白(無須寫入欄位)
     * 11    |  Classification value (inventive or non-inventive) |  I, N
     * 12~19 |  Action date                                       |  YYYYMMDD
     * 20    |  classification status                             |  B,R,V,D
     * 21    |  classification-data-source                        |  H,M,G
     * 22~23 |  Generating office                                 |  兩碼大寫英文
     * 
     * @param patData
     * @param ipcr
     * @return
     */
    public static PatClsIpc getDocdbIpcr(PatData patData, DBObject ipcr) throws Exception {
        
        PatClsIpc patClsIpc = new PatClsIpc();
        PatClsIpcId patClsIpcId = new PatClsIpcId();
        patClsIpcId.patId = patData.patId;
        patClsIpcId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patClsIpcId.ipcType = Constants.CLS_TYPE_IPCR;
        patClsIpcId.item = ipcr.sequence as int;
        patClsIpc.id = patClsIpcId;
        //
        patClsIpc.createDate = new Date();

        String ipcrNumber23;

        /*
         * (2)有提供MainGroup與SubGroup的詳細資訊:字串中存在/
         * EX: C22B  23/00        20060101AFI20060310RMJP
         * EX: F16C  11/06        20060101AFI20150318  BR    => DOCDB-201513-CreateDelete-PubDate20150320AndBefore-BR-0001.xml/438092956  
         * 
         * NOTE: 例外處理: only for country = DK, 其中的20150304會有多種格式如20150305, 201504012等資料.
         * A61K  31/445       20060101AFI20150304 H
         * 要改為     
         * A61K  31/445       20060101AFI20150304BHDK 
         * 而要改BHDK
         * 則是依後來Amend的資料而得知.
         * 
         * DOCDB-201511-CreateDelete-PubDate20150306AndBefore-DK-0001.xml/437605616
         * DOCDB-201511-CreateDelete-PubDate20150306AndBefore-DK-0001.xml/437605606
         * DOCDB-201515-CreateDelete-PubDate20150403AndBefore-DK-0001.xml/438522533
         * 皆可測試
         * 
         * NOTE NOTE: 例外處理: only for country = ES, 其中的20150306.
         * B29B   7/76        20060101AFI20150306    
         * 要改為     
         * B29B   7/76        20060101AFI20150306BHES       
         * 則是依後來Amend的資料而得知.
         * 
         * DOCDB-201511-CreateDelete-PubDate20150306AndBefore-ES-0001.xml/437719726
         * DOCDB-201511-CreateDelete-PubDate20150306AndBefore-ES-0001.xml/437603977
         * DOCDB-201511-CreateDelete-PubDate20150306AndBefore-ES-0001.xml/437719561
         * 
         * or
         * C04B  41/87        20060101ALI20150305            
         * to
         * C04B  41/87        20060101ALI20150305BHES
         * or
         * F25J               20060101SFI20150306        
         * to
         * F25J               20060101SFI20150306BHES        
         * 
         * 
         */
        if (patData.country == "DK" && ipcr.text =~ /(2015\d{4}\sH)/) {
            ipcr.text = ipcr.text.replaceAll(/(2015\d{4}\sH)/) {full, word1 ->
                String[] data = word1.split(/\s/);
                if (data[1] == "H") {
                    return data[0] + "BHDK";
                } else {
                    throw new Exception("DK ipcr regex pattern error");
                }
            }
        } else if (patData.country == "ES" && ipcr.text.trim() =~ /(ALI2015\d{4}$|AFI2015\d{4}$|ALN2015\d{4}$|SFI2015\d{4}$)/) {
            ipcr.text = ipcr.text.trim() + "BHES";
        }
        
        if (ipcr.text.contains("/")) {
            // println ipcr.sequence
            // println ipcr.text
            String[] ipcrArray = ipcr.text.split(/(?i)\s+/);

            if (ipcrArray.length == 3) {
                ipcrNumber23 = ipcrArray[2];
            } else if (ipcrArray.length == 4) {
                int length = ipcrArray[2].length() + ipcrArray[3].length();
                int spaceSize = 23 - length;
                ipcrNumber23 = ipcrArray[2] + (" " * spaceSize) + ipcrArray[3];
            } else {
                throw new Exception("ipcr contain [/] split regex pattern [(?i)\\s+] exception...");
            }

            patClsIpc.ipcText = PatClsUtil.formatDocdbIpcr(ipcrArray[0] + " " + ipcrArray[1]);

        } else if (!ipcr.text.contains("/")) {
            /*
             * (3)未提供MainGroup與SubGroup的詳細資訊:字串中不存在/
             * EX: C07D               20060101SFI20160118BHHK  
             */
            String[] ipcrArray = ipcr.text.split(/(?i)\s+/);

            if (ipcrArray.length == 2) {
                ipcrNumber23 = ipcrArray[1];
            } else if (ipcrArray.length == 3) {
                int length = ipcrArray[1].length() + ipcrArray[2].length();
                int spaceSize = 23 - length;
                ipcrNumber23 = ipcrArray[1] + (" " * spaceSize) + ipcrArray[2];
            } else {
                throw new Exception("ipcr dont contain [/] split regex pattern [(?i)\\s+] exception...");
            }

            patClsIpc.ipcText = ipcrArray[0].trim();

        } else {
            throw new Exception("ipcr contains [/] exception...");
        }
        
        if (ipcrNumber23.length() != 23) {
            throw new Exception("pat_data.pat_id = ${patData.patId}, ipcr length is not equal 23.");
        }
        
        // println "ipcrNumber23 = ${ipcrNumber23}"
        patClsIpc.clsVersion = ipcrNumber23.substring(0, 8);
        patClsIpc.clsLevel = ipcrNumber23.substring(8, 9);
        patClsIpc.symbolPosition = ipcrNumber23.substring(9, 10);
        patClsIpc.clsValue = ipcrNumber23.substring(10, 11);
        patClsIpc.actionDate = DateUtil.parseDate(ipcrNumber23.substring(11, 19));
        patClsIpc.clsStatus = ipcrNumber23.substring(19, 20);
        patClsIpc.clsDataSource = ipcrNumber23.substring(20, 21);
        patClsIpc.genOffice = ipcrNumber23.substring(21, 23);
        //
        return patClsIpc;
    }   // end getDocdbIpcr

    /**
     * 
     * @param ipcrStr
     * @return
     */
    public static String formatDocdbIpcr(String ipcrStr) {
        String ipcrText = "";
        String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z]) ([0-9]{0,4})\/([0-9]{1,6})/;
        ipcrStr.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
            ipcrText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
        }
        return ipcrText;
    }

    /**
     * 
     * @param patData
     * @param cpc
     * @return
     * @throws Exception
     */
    public static PatClsCpc getDocdbCpc(PatData patData, DBObject cpc) throws Exception {

        PatClsCpc patClsCpc = new PatClsCpc();

        PatClsCpcId patClsCpcId = new PatClsCpcId();
        patClsCpcId.patId = patData.patId;
        patClsCpcId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patClsCpcId.item = cpc.sequence as int;
        patClsCpc.id = patClsCpcId;
        //
        patClsCpc.createDate = new Date();
        patClsCpc.cpcText = PatClsUtil.formatDocdbCpc(cpc."classification-symbol")
        
        if (cpc."classification-scheme"."scheme" == "CPC" || cpc."classification-scheme"."scheme" == "CPCNO") {
            if (!!cpc."classification-scheme"."date") {
                patClsCpc.clsVersion = cpc."classification-scheme"."date"
            } else if (!!cpc."classification-scheme"."edition") {
                patClsCpc.clsVersion = cpc."classification-scheme"."edition"
            } else {
                throw new Exception("cpc classification-scheme clsVersion error")
            }
        }

        patClsCpc.clsValue = cpc."classification-value";
        patClsCpc.symbolPosition = cpc."symbol-position";
        patClsCpc.actionDate = DateUtil.parseDate(cpc."action-date"?."date");
        patClsCpc.genOffice = cpc."classification-scheme"?."office";
        patClsCpc.clsStatus = cpc."classification-status";
        patClsCpc.clsDataSource = cpc."classification-data-source";
        patClsCpc.schemaOriCode = cpc."classification-scheme"?."scheme";
        patClsCpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;

        return patClsCpc;
    }   // end getDocdbCpc

    /**
     * A61K  31/506
     * A61K   9/0048
     * 
     * @param cpcStr
     * @return
     */
    public static String formatDocdbCpc(String cpcStr) {
        // println "cpcStr = ${cpcStr}"
        String cpcText = "";
        String cpcOriPattern = /([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})\/([0-9]{1,6})/;
        cpcStr.trim().replaceAll(cpcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
            cpcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
        }
        return cpcText;
    }
    
    /**
     * 
     * @param patData
     * @param cset
     * @param groundNumber
     * @return
     * @throws Exception
     */
    public static PatClsCset getDocdbCset(PatData patData, DBObject cset, String groundNumber) throws Exception {
        
        DBObject cpc = cset."patent-classification";
        PatClsCset patClsCset = new PatClsCset();
        
        PatClsCsetId patClsCsetId = new PatClsCsetId();
        patClsCsetId.patId = patData.patId;
        patClsCsetId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patClsCsetId.groupNo = groundNumber as int;
        patClsCsetId.item = cset."rank-number" as int;
        patClsCset.id = patClsCsetId;
        //
        patClsCset.createDate = new Date();
        patClsCset.cpcText = PatClsUtil.formatDocdbCpc(cpc."classification-symbol")
        
        if (!!cpc."classification-scheme"."date") {
            patClsCset.clsVersion = cpc."classification-scheme"."date"
        } else if (!!cpc."classification-scheme"."edition") {
            patClsCset.clsVersion = cpc."classification-scheme"."edition"
        } else {
            throw new Exception("cpc classification-scheme clsVersion error")
        }
        
        patClsCset.clsValue = cpc."classification-value";
        patClsCset.symbolPosition = cpc."symbol-position";
        patClsCset.actionDate = DateUtil.parseDate(cpc."action-date"?."date");
        patClsCset.genOffice = cpc."classification-scheme"?."office";
        patClsCset.clsStatus = cpc."classification-status";
        patClsCset.clsDataSource = cpc."classification-data-source";
        patClsCset.schemaOriCode = cpc."classification-scheme"?."scheme";
        
        return patClsCset;
    }
    
    
    /**
     * @param classText
     * @param classType
     * @return
     */
    public static String parseUnstructuredFieldOfSearch(String classText, String classType) {
        
        String result = null;
        if (classType == Constants.CLS_NAME_USPC) {
            // USPC 呈現方式為區間, ex: 36167946-67955
            // step1 . 36167946-36167955
            // step2 . 36167946 to 361/679.46, 36167955 to 361/679.55
            // step3 . return 361/679.46-361/679.55
            String startClsText = classText.split("-")[0];
            String endClsStr = classText.split("-")[1];
            // 特殊類型 '-' 後面有空格隔開, endClsLength要取空格前的長度
            // 1. '27 10-DIG 1'
            // 2. '707100-103 RZ'
            int startClsLength = startClsText.size();
            String[] endClsStrArry = endClsStr.split(" ");
            int endClsLength = 0;
            if (endClsStrArry.size() == 1) {
                endClsLength = endClsStr.size();
            } else {
                endClsLength = endClsStrArry[0].size();
            }
            String endClsText = startClsText[0..(startClsLength-endClsLength-1)] + endClsStr;
            result = PatClsUtil.formatClsUspc(startClsText) + "-" + PatClsUtil.formatClsUspc(endClsText);
        }
        
        return result;
    }
    
    /**
     * 
     * @param patData
     * @param uspc
     * @return
     * @throws Exception
     */
    public static PatClsUspc getDocdbUspc(PatData patData, String uspc, Integer index) throws Exception {
        
        PatClsUspc patClsUspc = new PatClsUspc();
        PatClsUspcId patClsUspcId = new PatClsUspcId();
        patClsUspcId.patId = patData.patId;
        patClsUspcId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;;
        patClsUspcId.item = index + 1;
        
        patClsUspc.id = patClsUspcId;
        
        uspc = uspc.replaceAll('^[X|x]', '')
        patClsUspc.uspcText = PatClsUtil.formatClsUspc(uspc);
        
        patClsUspc.rawMainFlag = Constants.CLS_USPC_MAIN_FLAG_NO;
        patClsUspc.createDate = new Date();
        
        return patClsUspc;
    }
    
    /** USPC的合理值為:D01~D30,D32,D34,D99 <BR>
     *  若format後之結果不在列舉出的資料中,則於D後面補上一個0
     * @param uspcNormal
     * @return
     */
    private static boolean checkUspcDesign(String uspcNormal) {
        int main = uspcNormal[1..-1].split("/")[0].toInteger();
        if ((main > 0 && main<31) || main == 32 || main == 34 || main == 99) {
            return true;
        }
        return false;
    }
    
    /**
     * 移除前後X字元
     * @param s
     * @return
     */
    private static String removeCharX(String s) {
        if (s.toUpperCase().startsWith("X")) {
            s = s.substring(1);
        }
        
        if (s.toUpperCase().endsWith("X")) {
            s = s.substring(0, s.length() -1);
        }
        
        return s;
    }
    
    // ********************* SOLR **************************
    
    /**
     * 正規化section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0)
     */
    public static List<IpcInfo> normalizeIPCAndCPCListSolr(List<String> clsTextList, String clsType) {

        List<IpcInfo> ipcInfoList = new ArrayList<>();
        
        clsTextList.each {clsText ->
            
            IpcInfo ipcInfo = new IpcInfo();
            if (clsType == "IPC" || clsType == "CPC") {
                if (clsText =~ /([A-Z])([0-9]{2})([A-Z])\s([0-9]{0,4})?\/([0-9]{1,6})/) {

                    clsText.replaceAll(/([A-Z])([0-9]{2})([A-Z])\s([0-9]{0,4})?\/([0-9]{1,6})/) {full, section, mainClazz, subClazz, mainGroup,subGroup ->
                        ipcInfo.ipcNormal = section + mainClazz + subClazz + "0" * (4 - mainGroup.length()) + mainGroup + subGroup + "0" * (6 - subGroup.length());
                        ipcInfo.clazz = section + mainClazz;
                        ipcInfo.subClazz = ipcInfo.clazz + subClazz;

                        Cpc cpc = CpcHelper.findById(ipcInfo.ipcNormal);
                        if (!!cpc) {
                            ipcInfo.group = cpc.maingroup;
                            ipcInfo.subGroup = cpc.subgroup;
                        }
                    }
                    ipcInfoList.add(ipcInfo);
                } else {
                    throw new Exception("$clsType format error, clsText : $clsText");
                }
            }
        }

        return ipcInfoList;
    }
    
    /**
     * 正規化section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0)
     */
    public static IpcInfo normalizeIPCAndCPCSolr(clsText, String clsType) {

        IpcInfo ipcInfo = new IpcInfo();
        if (clsType == "IPC" || clsType == "CPC") {
            if (clsText =~ /([A-Z])([0-9]{2})([A-Z])\s([0-9]{0,4})?\/([0-9]{1,6})/) {

                clsText.replaceAll(/([A-Z])([0-9]{2})([A-Z])\s([0-9]{0,4})?\/([0-9]{1,6})/) {full, section, mainClazz, subClazz, mainGroup,subGroup ->
                    ipcInfo.ipcNormal = section + mainClazz + subClazz + "0" * (4 - mainGroup.length()) + mainGroup + subGroup + "0" * (6 - subGroup.length());
                    ipcInfo.clazz = section + mainClazz;
                    ipcInfo.subClazz = ipcInfo.clazz + subClazz;

                    if (clsType == "CPC") {
                        Cpc cpc = CpcHelper.findById(ipcInfo.ipcNormal);
                        if (!!cpc) {
                            ipcInfo.group = cpc.maingroup;
                            ipcInfo.subGroup = cpc.subgroup;
                        }
                    } else if (clsType == "IPC") {
                        Ipc ipc = IpcHelper.findById(ipcInfo.ipcNormal);
                        if (!!ipc) {
                            ipcInfo.group = ipc.maingroup;
                            ipcInfo.subGroup = ipc.subgroup;
                        }
                    }
                }
            } else {
                throw new Exception("$clsType format error, clsText : $clsText");
            }
        }

        return ipcInfo;
    }
    
    // ********************* SOLR **************************
    
    public static void main(args) {
        println formatClsUspc("D 2952")
        println formatClsUspc(" D2951")
        println formatClsUspc(" D2948")
    }

}
