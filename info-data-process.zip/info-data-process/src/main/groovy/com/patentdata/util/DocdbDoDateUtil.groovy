package com.patentdata.util

import com.gmongo.GMongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.patentdata.util.MongoUtil;
import java.text.DateFormat
import java.text.SimpleDateFormat

class DocdbDoDateUtil {
    
    /**
     * 
     * @param cc
     * @return
     */
    public static List<Date> getDocdbDoDate(String cc) {
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        
        GMongoClient dbClient = MongoUtil.connectByConfig("DOCDB");
        DB marshallDB = dbClient.getDB("PatentMarshallDOCDB");
        DBCollection marshallCol = marshallDB.getCollection("PatentMarshall" + cc);
        
        List<Date> queryDistinctData = marshallCol.distinct("docdbDoDate").sort {a, b -> a.compareTo(b)};
        
        def queryDistinctDataStrList = [] 
        queryDistinctData.each { it -> 
            queryDistinctDataStrList << df.format(it);
        }
        
        return queryDistinctDataStrList;
    }
    
}
