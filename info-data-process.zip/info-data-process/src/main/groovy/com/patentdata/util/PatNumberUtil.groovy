package com.patentdata.util

import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.lang3.StringUtils

import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.model.PatData
public class PatNumberUtil {

    /**
     * Generic patId Transformer
     * 
     * @param doc: map with keys:
     *  necessary: 'country', 'doc-number'
     *  optional : 'date', 'kind'
     * @return 
     *  success: patId
     *  input incompatible: null 
     * @throws Exception : cannot convert to a valid form
     */
    public static String getFormalPatId(Map doc) throws Exception{

        // check input
        if(!doc.keySet().containsAll(['country', 'doc-number'])){
            return null
        }

        boolean isValidTransform = false
        String formalPatId = ""

        /***** 可改用工廠模式重構  ******/
        switch(doc.'country'){

            case "CN":
            // TODO:
                break;

            case "JP":
            // TODO:
                break;

            case "EP":
            // TODO
                break;

            case "WO":
                if(!doc.keySet().containsAll(['date', 'kind'])){
                    return null
                }
                formalPatId = getPatIdWO(doc.'doc-number', doc.'kind', doc.'date')
                isValidTransform = CheckUtil.checkPatIdWO(formalPatId)
                break

            default : return null
        }


        if(!isValidTransform){
            throw new Exception('unpredictable format occur:\tcountry:' + doc.'country' + '\t' + 'doc-number:' + doc.'doc-number')
        }

        return formalPatId
    }

    /**
     * @param patId
     * @param country
     * @return
     */
    public static getDocNoByPatId(String patId, String country){
        String formatDocNo = "";
        switch(country){

            case "CN":
            // TODO:
                break;

            case "JP":
            // TODO:
                break;

            case "EP":
            // TODO
                break;

            case "WO":
                formatDocNo = getDocNoByPatIdWO(patId)
                break

            default : return null
        }
        return formatDocNo
    }

    /**
     * 
     * @param rawAppNo
     * @param country
     * @param rawAppDate
     * @return
     */
    def static String formatAppNoByCountry(String rawAppNo, String country, String rawAppDate) {
        String formatAppNo = "";
        switch(country){
            case "US":
                formatAppNo = formatAppNoUS(rawAppNo);
                break;
            case "CN":
            // throw new Exception("patId = ${patId} format docNo error")
                formatAppNo = formatAppNoCN(rawAppNo, rawAppDate);
                break;
            case "JP":
                formatAppNo = formatAppNoJP(rawAppNo, rawAppDate);
                break;
            case "TW":
                formatAppNo = formatAppNoTW(rawAppNo);
                break;
            case "WO":
                formatAppNo = formatAppNoWO(rawAppNo);
                break;
            case "EP":
                formatAppNo = formatAppNoEP(rawAppNo);
                break;
            case "KR":
            // TODO:
                formatAppNo = rawAppNo;
                break;
            default :
            // 非既有PTO
                formatAppNo = rawAppNo;
                break;
        }

        return formatAppNo;
    }

    def static String formatAppNoUS(String rawAppNo) {
        String formatAppNo;
        return formatAppNo;
    }

    def static String formatAppNoEP(String rawAppNo) {
        String formatAppNo;
        rawAppNo = rawAppNo.replaceAll(/\s/, "");
        if (rawAppNo.matches(/\d{3,8}/)) {
            formatAppNo = "0" * (8 - rawAppNo[0..-1].length()) + rawAppNo[0..-1] + "." + getEpAppCheckcode(rawAppNo[0..1] + "0" * (6 - rawAppNo[2..-1].length()) + rawAppNo[2..-1]);
        } else if (rawAppNo.matches(/.*PCT.*/)) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/\d+\.\d{1}/)) {
            formatAppNo = formatAppNoEP(rawAppNo[0..rawAppNo.lastIndexOf(".") - 1]);
        } else if (rawAppNo.matches(/\d{9}/)) {
            formatAppNo = formatAppNoEP(rawAppNo[0..-2]);
        } else if (rawAppNo.matches(/EP\d{8}\.?\d?/)) {
            formatAppNo = formatAppNoEP(rawAppNo.replaceAll(/EP/, ""));
        } else if (rawAppNo.matches(/\d+\-\d+/)) {
            formatAppNo = formatAppNoEP(rawAppNo.replaceAll(/\-/, ""));
        } else if (rawAppNo.contains("I")) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/\d{8}\.?\d?EP/)) {
            formatAppNo = formatAppNoEP(rawAppNo.replaceAll(/EP/, ""));
        } else if (rawAppNo.matches(/\d{8}\.\d{1}\-\d+/)) {
            formatAppNo = formatAppNoEP(rawAppNo.split("-")[0]);
        } else if (rawAppNo.contains("/")) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/SN\d{8}\.?\d?/)) {
            formatAppNo = formatAppNoEP(rawAppNo.replaceAll(/SN/,""))
        } else {
            throw new Exception("wrong ep app no");
        }
        return formatAppNo;
    }

    def static String formatAppNoCN(String rawAppNo, String rawAppDate) {
        String formatAppNo;
        String fixAppNo;
        rawAppNo = rawAppNo.replaceAll("\\s|A|B|U|C|N|H|\\(","");
        if (rawAppNo.matches("\\d{8}|\\d{12}")) {
            fixAppNo = rawAppNo;
        } else if (rawAppNo.length() < 8) {
            if (rawAppNo[0..3] == rawAppDate[0..3]) {
                fixAppNo = rawAppNo[0..3] + "0" * (8 - rawAppNo[4..-1].size()) + rawAppNo[4..-1];
            } else if (rawAppNo[0..1] == rawAppDate[2..3]) {
                fixAppNo = rawAppNo[0..1] + "0" * (6 - rawAppNo[2..-1].size()) + rawAppNo[2..-1];
            }
        } else if (rawAppNo.matches("\\d{9}")) {
            formatAppNo = rawAppNo[0..7] + "." + rawAppNo[-1];
        } else if (!!rawAppNo.contains("PT")) {
            formatAppNo = null;
        } else if (rawAppNo.matches("\\d{8}\\.[\\dX]{1}|\\d{12}\\.[\\dX]{1}")) {
            formatAppNo = rawAppNo;
        } else if (rawAppNo.matches("\\d{10,11}")) {
            formatAppNo = null;
        } else if (rawAppNo.matches("\\d{4}/\\d{8}\\.\\d{1}")) {
            formatAppNo = rawAppNo.replaceAll("/", "");
        } else if (rawAppNo.matches("\\d{12}[\\dX]{1}")) {
            formatAppNo = rawAppNo[0..11] + "." + rawAppNo[-1];
        } else if (rawAppNo.matches("\\d{14}")) {
            formatAppNo = CaptchaUtil.genAppNumberWithCaptcha(rawAppNo[0..-3], true);
            if (rawAppNo[-1] != formatAppNo[-1]) {
                formatAppNo = null;
            } 
        } else if (rawAppNo.matches("[A-Z]{2}\\-\\d{2}\\d{8}\\.\\d{1}")) {
            formatAppNo = rawAppNo[5..-1];
        } else if (rawAppNo.matches("[A-Z]{2}\\d{2}\\-\\d{1}\\-\\d{5}\\.\\d{1}")) {
            formatAppNo = rawAppNo[2..-1].replaceAll("\\-","");
        } else if (rawAppNo.matches("\\d{4}\\-\\d{8}[\\.\\dX]{1,2}")) {
            formatAppNo = formatAppNoCN(rawAppNo.replaceAll("\\-",""), rawAppDate);
        } else if (rawAppNo.matches(/0?\d{12}\.[\dX]{1}/)) {
            formatAppNo = rawAppNo[1..-1];
        } else if (rawAppNo.matches(/\d{9}\.[\dX]{1}/)) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/\d{7}\.[\dX]{1}/)) {
            if (rawAppNo[0..1] != rawAppDate[2..3]) {
                formatAppNo = rawAppDate[2..3] + rawAppNo[1..-1];
            }
//            20031018058 => 200310108058
        } else if (rawAppNo.matches(/20031018058\.X/)) {
            formatAppNo = "200310108058.X";
//            20030117683 => 200320117683
        } else if (rawAppNo.matches(/20030117683\.6/)) {
            formatAppNo = "200320117683.6";
//            20031012451 => 200310112451
        } else if (rawAppNo.matches(/20031012451\.6/)) {
            formatAppNo = "200310112451.6";
        } else if (rawAppNo.matches(/20032011295\.X/)) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/2003101033184\.4/)) {
            formatAppNo = "200310103318.4";
        } else if (rawAppNo.matches(/20040002505.8/)) {
            formatAppNo = "200410002505.8";
        } else {
            throw new Exception("wrong cn app no");
        }
        if (!!fixAppNo) {
            formatAppNo = CaptchaUtil.genAppNumberWithCaptcha(fixAppNo, true);
        }
        return formatAppNo;
    }

    def static String formatAppNoWO(String rawAppNo) {
        String formatAppNo;
        rawAppNo = rawAppNo.replaceAll("\\s","").toUpperCase();
        if (rawAppNo.contains("DM")) {
            rawAppNo = rawAppNo.replaceAll(/A|B|\//,"");
            int position = rawAppNo.lastIndexOf("D");
            formatAppNo = rawAppNo[position..position + 1] + "/" + rawAppNo[position + 2..-1];
        } else if (rawAppNo.matches(/PCT\/?[A-Z]{2}\d{2}[\/]{0,2}\d{5,6}/)) {
            rawAppNo.replaceAll(/(PCT)\/?([A-Z]{2})(\d{2})[\/]{0,2}(\d{5,6})/) { full, pct, cc, year, series ->
                String yearString = getYearWO(year);
                formatAppNo = pct + "/" + cc + yearString + "/" + "0" * (6 - series.length()) + series;
            }
        } else if (rawAppNo.contains("WO")) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/[\d\-\/A]+/)) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/PCT[A-Z]{2}\/?\d{2}\/?\d{5,6}/)) {
            rawAppNo.replaceAll(/(PCT)([A-Z]{2})\/?(\d{2})\/?(\d{5,6})/) { full, pct, cc, year, series ->
                String yearString = getYearWO(year);
                formatAppNo = pct + "/" + cc + yearString + "/" + "0" * (6 - series.length()) + series;
            }
        } else if (rawAppNo.matches(/PCT\/?\d{4}\/?[A-Z]{2}\d{5,6}/)) {
            rawAppNo.replaceAll(/(PCT)\/?(\d{4})\/?([A-Z]{2})(\d{5,6})/) { full, pct, year, cc, series ->
                formatAppNo = pct + "/" + cc + year + "/" + "0" * (6 - series.length()) + series;
            }
        } else if (rawAppNo.matches(/[A-Z]{2}\d{2,4}\/\d{1,5}/)) {
            formatAppNo = getAppNoWO(rawAppNo);
        } else {
            throw new Exception("wrong wo app no");
        }
        return formatAppNo;
    }

    def static String formatAppNoTW(String rawAppNo) {
        String formatAppNo;
        rawAppNo = rawAppNo.replaceAll(/\s/,"");
        if (rawAppNo.matches(/.*U|.*D|.*A/)) {
            formatAppNo = formatAppNoTW(rawAppNo.replaceAll(/U|D|A/,""));
        } else if (rawAppNo.matches(/\d{8,9}/)) {
            if (rawAppNo.matches(/[01]{1}\d{7,8}/)) {
                formatAppNo = rawAppNo;
            } else {
                formatAppNo = "0" + rawAppNo;
            }
        } else if (rawAppNo.matches(/.*\..*/)) {
            formatAppNo = null;
        } else if (rawAppNo.contains("TW")) {
            formatAppNo = formatAppNoTW(rawAppNo.replaceAll(/TW/, ""));
        } else if (rawAppNo.matches(/D\d{8,9}/)) {
            formatAppNo = formatAppNoTW(rawAppNo.replaceAll(/D/,""));
        } else if (rawAppNo.matches(/\d{11}/)) {
            formatAppNo = null;
        } else if (rawAppNo.matches(/\d{7}/)) {
            formatAppNo = null;
        } else {
            throw new Exception("wrong tw app no");
        }

        return formatAppNo;
    }

    def static String formatAppNoJP(String rawAppNo, String date) {
        String formatAppNo;
        rawAppNo = rawAppNo.replaceAll(/[\.\sA-Z\(\)]/, "");
        if (rawAppNo.matches(/\d{1,4}\-\d{1,6}/)) {
            List<String> rawAppNoList = rawAppNo.split("-");
            formatAppNo =  date[0..3] + "0" * (6 - rawAppNoList[1].length()) + rawAppNoList[1];
        } else if (rawAppNo.matches(/\d+/)) {
            if (rawAppNo[0..3] == date[0..3]) {
                formatAppNo = rawAppNo[0..3] + "0" * (6 - rawAppNo[4..-1].length()) + rawAppNo[4..-1];
            } else {
                formatAppNo = null;
            }
            
        } else if (rawAppNo.matches(/.*\/.*/)) {
            List<String> rawAppNoList = rawAppNo.split("/");
            formatAppNo =  date[0..3] + "0" * (6 - rawAppNoList[0].length()) + rawAppNoList[0];
        } else {
            throw new Exception("wrong jp app no");
        }
        return formatAppNo;
    }

    /**
     * docNo 標準化統一在此處理
     * 
     * @param rawDocNo
     * @param country
     * @return null when format fail
     */
    def static String formatDocNoByCountry(String rawDocNo, String country, String patId = null, String kindCode, Date docDate) throws Exception {

        String formatDocNo = "";
        switch(country){
            case "US":
                formatDocNo = getDocNoUS(rawDocNo);
                break;
            case "CN":
            // throw new Exception("patId = ${patId} format docNo error")
                formatDocNo = getDocNoCN(rawDocNo, kindCode);
                break;
            case "JP":
                formatDocNo = getDocNoJP(rawDocNo, kindCode, docDate);
                break;
            case "TW":
                formatDocNo = getDocNoTW(rawDocNo, kindCode, docDate);
                break;
            case "WO":
                formatDocNo = getDocNoWo(rawDocNo);
                break;
            case "EP":
                formatDocNo = getDocNoEP(rawDocNo);
                break;
            case "KR":
            // TODO:
                formatDocNo = rawDocNo;
                break;
            default :
            // 非既有PTO
                formatDocNo = rawDocNo;
                break;
        }

        return formatDocNo;
    }

    /**
     * 登錄號，七碼流水號 + kindcode
     * @param rawAppNo
     * @return
     */
    def static String getDocNoJP(String kindcode, String originalPatNo) throws Exception {
        String patNo = ""
        if(originalPatNo ==~ /\d{7}/ && (kindcode ==~ /(?i)A/ || kindcode ==~ /(?i)B2/) || kindcode ==~ /(?i)U/ || kindcode ==~ /(?i)Y2/) {
            return originalPatNo + kindcode;
        } else {
            return ""
        }
    }

    /**
     * 
     * @param rawDocNo
     * @param kindCode
     * @param docDate
     * @return
     */
    def static String getDocNoJP(String rawDocNo, String kindCode, Date docDate) {
        String fixDocNo = null;
        String westernYear;

        rawDocNo = rawDocNo.replaceAll("[\\s/]*", "");

        if (!!docDate) {
            westernYear = DateUtil.toISODate(docDate, "yyyMMdd")[0..3];
        } else if (rawDocNo.matches("[SEIOMTH]{1,3}\\d+")) {
            westernYear = getYearJP(rawDocNo);
        }

        if (!!westernYear) {
            if (Integer.parseInt(westernYear) > 2016) {
                westernYear = null;
            }
        }

        if (!!kindCode) {
            kindCode = kindCode.trim()[0];
        } else {
            kindCode = "";
        }

        if (rawDocNo.matches("D[\\d\\-]+")) {
            if (rawDocNo.size() == 8) {
                fixDocNo = rawDocNo[1..-1];
            } else if (rawDocNo.size() == 10) {
                rawDocNo = rawDocNo.replaceAll("-", "");
                fixDocNo = rawDocNo[1..7] + "_" + "0" * (3 - rawDocNo[8..-1].size()) + rawDocNo[8..-1];
            }
        } else if (kindCode == "S" && rawDocNo.matches(/[\d\-]+/)) {
            fixDocNo = getDocNoJP("D" + rawDocNo, kindCode, docDate);
        } else if (rawDocNo.matches("[1-2]{1}[09]{1}[0-9]{1}[0-9]{1}\\d{5,7}")) {
            if (kindCode.matches("A|U")) {
                fixDocNo = rawDocNo[0..3] + "0" * (7 - rawDocNo[4..-1].size()) + rawDocNo[4..-1];
            } else if (kindCode.matches("B|Y")) {
                fixDocNo = rawDocNo[4..-1];
            }
        } else if (rawDocNo.matches("[SEIOMTH]{1,3}\\d+")) {
            if (rawDocNo.matches("[SEIOMTH]{1}\\d+")) {
                if (kindCode.matches("A|U")) {
                    if (!!westernYear) {
                        fixDocNo = westernYear + "0" * (7 - rawDocNo[3..-1].size()) + rawDocNo[3..-1];
                    }

                } else if (kindCode.matches("B|Y")) {
                    fixDocNo = rawDocNo[3..-1];
                }
            } else if (rawDocNo.matches("[SEIOMTH]{3}\\d+")) {
                if (kindCode.matches("A|U")) {
                    fixDocNo = westernYear + "0" * (7 - rawDocNo[5..-1].size()) + rawDocNo[5..-1];
                } else if (kindCode.matches("B|Y")) {
                    fixDocNo = rawDocNo[3..-1];
                }
            }

        } else if (rawDocNo.matches("\\d{7}")) {
            if (kindCode.matches("A|U")) {
                if (!!westernYear) {
                    fixDocNo = westernYear + "0" * (7 - rawDocNo[2..-1].size()) + rawDocNo[2..-1];
                }
            } else if (kindCode.matches("B|Y")) {
                fixDocNo = rawDocNo;
            }
        } else if (rawDocNo.size() <= 6) {
            if (!!docDate) {
                if (kindCode.matches("A|U")) {
                    fixDocNo = westernYear + "0" * (7 - rawDocNo.size()) + rawDocNo;
                }
            } else {
                if (kindCode.matches("B|Y")) {
                    fixDocNo = rawDocNo;
                }
            }
        } else if(rawDocNo.matches("\\d{8,9}")) {
            fixDocNo = null;
        } else if (rawDocNo.contains("WO")) {
            fixDocNo = null;
        }  else if (rawDocNo.matches("RBR.*|PBR.*")) {
            fixDocNo = null;
        } else if (rawDocNo.matches("\\d{1,3}\\-\\d+")) {
            if (kindCode.matches("B|Y")) {
                fixDocNo = rawDocNo.split("-")[1];
            } else if (kindCode.matches("A|U")) {
                if (!!docDate) {
                    fixDocNo = westernYear + "0" * (7 - rawDocNo.split("-")[1].size()) + rawDocNo.split("-")[1];
                }
            }

        } else if (rawDocNo.matches("\\d{4}\\-\\d+")) {
            fixDocNo = getDocNoJP(rawDocNo.replace("-",""), kindCode, docDate);
        } else if (rawDocNo.matches(/[SEIOMTH]{1,3}\d{4}\-\d+/)) {
            fixDocNo = getDocNoJP(rawDocNo.replaceAll(/[SEIOMTH]/, ""), kindCode, docDate);
        } else if (rawDocNo.matches("[SEIOMTH]{1,3}\\d{2}\\-\\d+")) {
            fixDocNo = getDocNoJP(rawDocNo.replace("-",""), kindCode, docDate);
        } else if (rawDocNo.matches("[ABUY]{1}[\\-\\s]?[12]{1}[09]{1}[0-9]{1}[0-9]{1}\\-\\d+")) {
            fixDocNo = getDocNoJP(rawDocNo[1..-1].replaceAll("\\-", ""), rawDocNo[0], docDate)
        } else if (rawDocNo.matches("[ABUY]{1}[\\-\\s]?[SEIOMTH]{1,3}\\d{2}\\-\\d+")) {
            fixDocNo = getDocNoJP(rawDocNo[1..-1].replaceAll("\\-", ""), rawDocNo[0], docDate);
        } else if (rawDocNo.matches("[ABUY]{1}\\d?[\\-\\s]?\\d{1,2}\\-\\d+")) {
            if (rawDocNo.split("-").size() == 2) {
                if (!!docDate && rawDocNo[0].matches("A|U")) {
                    fixDocNo = getDocNoJP(rawDocNo.split("-")[1], rawDocNo[0], docDate);
                } else if (rawDocNo[0].matches("B|Y")) {
                    fixDocNo = getDocNoJP(rawDocNo.split("-")[1], rawDocNo[0], docDate);
                }
            } else {
                if (!!docDate && rawDocNo[0].matches("A|U")) {
                    fixDocNo = getDocNoJP(rawDocNo.split("-")[2], rawDocNo[0], docDate);
                } else if (rawDocNo[0].matches("B|Y")) {
                    fixDocNo = getDocNoJP(rawDocNo.split("-")[2], rawDocNo[0], docDate);
                }
            }
        } else if (rawDocNo.matches("[AB]{1}\\d+")) {
            fixDocNo = null;
        } else {
            fixDocNo = null;
        }

        return fixDocNo;
    }

    /**
     * 因日本有年號,轉換成西元年
     * 
     * 明治年(M)+1867=西元年
     * 大正年(T)+1911=西元年
     * 昭和(S,SHO)+1925=西元年
     * 平成(H,HEI)+1988=西元年，平(1989/01/08~)
     * 
     * @param jpYear
     * @return
     */
    def static String getYearJP(String jpYear) {
        String yearName;
        int year;
        String westernYear;

        if (jpYear.matches("[SEIOMTH]{1,3}[\\d\\-]+")) {
            if (jpYear.matches("[SEIOMTH]{3}[\\d]+[\\-]?[\\d]+")) {
                yearName = jpYear[0..2];
                year = Integer.parseInt(jpYear[3..4]);
            } else if (jpYear.matches("[SEIOMTH]{1}[\\d]+[\\-]?[\\d]+")) {
                yearName = jpYear[0];
                year = Integer.parseInt(jpYear[1..2]);
            } else {
                return null;
            }
        }

        if (yearName == "M") {
            westernYear = (year + 1867).toString();
        }
        if (yearName == "T") {
            westernYear = (year + 1911).toString();
        }
        if (yearName == "S" || yearName == "SHO") {
            westernYear = (year + 1925).toString();
        }
        if (yearName == "H" || yearName == "HEI") {
            westernYear = (year + 1988).toString();
        }
        return westernYear;
    }

    /**
     *  (DP/U/D) + 四碼西元年 + 六碼流水號
     * @param rawAppNo
     * @return
     */
    def static String getAppIdJP(String kindcode, String originalAppNo) throws Exception {
        if(originalAppNo ==~ /\d{4}-\d{1,6}/) {
            String appId
            String[] tmp = originalAppNo.split('-')
            String appRefYear = tmp[0]
            String appRefNumber = tmp[1].padLeft(7, '0')
            //String appRefNumber = String.format("%1\$7s", tmp[1]).replace(' ', '0')
            appId = appRefYear + appRefNumber
            if(kindcode =~ /^A[\d]?$/ || kindcode =~/^B[\d]?$/) {
                appId = "P" + appId
            } else if(kindcode =~ /^U$/ || kindcode =~/^Y[\d]?$/) {
                appId = "U" + appId
            } else if(kindcode =~ /^S$/) {
                appId = "D" + appId
            } else {
                throw new Exception("kind code not recognized: " + kindcode)
            }
            return "JP" + appId
        } else {
            return ""
        }
    }

    /**
     * US+八碼數字(APP NO去掉/)
     * @param appNo
     * @return
     */
    public static String getAppIdUS(String appNo) {
        return "US" + appNo[0..1] + appNo[2..-1]
    }

    /**
     * 兩碼數字+"/"+六碼數　設計類專利,將申請號中的D轉為29
     * @param rawAppNo
     * @return
     */
    def static String getAppNoUS(String rawAppNo) {
        rawAppNo = rawAppNo.replaceAll(",", "").replaceAll("/","");
        String rawAppNoText = rawAppNo.startsWith("D") ? rawAppNo.replace("D", "29") : rawAppNo;
        return rawAppNoText[0..1] + "/" + rawAppNoText[2..-1];
    }

    /**
     * 公開:11碼數字,20110138416<BR>
     * 公告:7碼數字,5799200
     * @param rawDocNo
     * @return
     */
    def static String getDocNoUS(String rawDocNo) {
        String fixDocNo;
        rawDocNo = rawDocNo.trim();
        if (rawDocNo.contains("/")) {
            rawDocNo = rawDocNo.replace("/","");
        }
        if (rawDocNo.size() == 11) {
            fixDocNo = rawDocNo;
        } else if (rawDocNo.size() <= 7) {
            fixDocNo = rawDocNo;
        } else if (rawDocNo.matches("([1-2]{1}[09]{1}[0-9]{1}[0-9]{1})\\d{6}")) {
            fixDocNo = rawDocNo[0..3] + Constants.ZERO + rawDocNo[4..-1];
        } else if (rawDocNo.contains("RE")) {
            fixDocNo = rawDocNo;
        } else {
            fixDocNo = null;
        }
        return fixDocNo;
    }


    /**
     * 組出US patentNumber
     * @param docNumber
     * @return
     */
    def static String getPatentNumberUS(docNumber) {

        def patentNumber = ""

        if (docNumber =~ /D0*[1-9]\d+/) {

            docNumber.replaceAll(/D(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "D" + serialNo

            }

        } else if (docNumber =~ /RE0*[1-9]\d+/) {

            docNumber.replaceAll(/RE(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "RE" + serialNo

            }

        } else if (docNumber =~ /H0*[1-9]\d+/) {

            docNumber.replaceAll(/H(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "H" + serialNo

            }

        } else if (docNumber =~ /PP0*[1-9]\d+/) {

            docNumber.replaceAll(/PP(0*)([1-9]\d+)/) {fullMatch, zeros, serialNo ->

                patentNumber = "PP" + serialNo

            }

        } else if (docNumber =~ /^\d{4,11}$/) {

            patentNumber = docNumber

        } else{

            throw new RuntimeException("No PatentNumber or PatentNumber is not available")

        }

        return "US" + "0"*(11 - patentNumber.length()) + patentNumber
    }

    /**
     * PCT+/+國別大寫兩碼+申請年四碼西元年+/+六碼數字
     * @param rawAppNo
     * @return
     */
    public static String getPctAppNoUS(String rawAppNo) {
        //
        String appNo = "";
        if (rawAppNo =~ /(?i)pct[\/:-]?([A-Z]{2})([0-9]{2})[\/:-]?([0-9]{5})/) {
            rawAppNo.replaceAll(/(?i)pct[\/:-]?([A-Z]{2})([0-9]{2})[\/:-]?([0-9]{5})/) {full, country, year, serialNo ->
                appNo = "PCT" + "/" + country + getYearWO(year) + "/" + "0" + serialNo;
            }
        }

        return appNo.toUpperCase();
    }

    /**
     * 公開年四碼西元年+/+六碼數字(不足6位,前補0至6碼)
     * @param rawPublicNo
     * @return
     */
    public static String getPctPublicDocNoUS(String rawPublicNo) {

        String publicNo = "";

        if (rawPublicNo =~ /(?i)WO([0-9]{2})([0-9]{5})/) {
            rawPublicNo.replaceAll(/(?i)WO([0-9]{2})([0-9]{5})/) {full, year,serialNo ->
                publicNo = getYearWO(year) + "/" + "0" + serialNo;
            }
        }

        return publicNo;
    }

    /**
     * 
     * @param stat
     * @param docNo
     * @return
     */
    def static String getPatIdUS(int stat, String docNo) {

        String patId
        if (stat == Constants.PAT_STAT_PUBLIC) {
            patId = "US" + docNo
        } else {
            patId = "US" + "0" * (11 - docNo.length()) + docNo
        }

        return patId
    }

    /**
     * country + number + - + kindcode + - + doDate(yyyymmdd) 
     * EX: WO1996002947-A1-19960201
     *
     * @param docNo:
     * Acceptable docNo format:
     *  15/000001
     *  2015/000001
     *  2011065801
     *  8912944
     * @param kindCode:
     * @param doDate:
     * @return
     */
    def static String getPatIdWO(String docNo, String kindCode, String doDate){
        String normalizedDocNo
        if(StringUtils.contains(docNo, '/')){
            normalizedDocNo = getYearWO(StringUtils.substringBefore(docNo, '/')) + StringUtils.substringAfter(docNo, '/')

        }else{
            int prefix = Integer.valueOf(docNo.substring(0, 4))
            if(prefix>1970 && prefix<=2020){
                normalizedDocNo = getYearWO(docNo.substring(0, 4)) + StringUtils.leftPad(docNo.substring(4), 6, '0')
            }else{
                normalizedDocNo = getYearWO(docNo.substring(0, 2)) + StringUtils.leftPad(docNo.substring(2), 6, '0')
            }
        }
        return 'WO' + normalizedDocNo + '-' + kindCode + '-' + doDate
    }


    def static String getDocNoByPatIdWO(String patId){
        return patId.replaceAll(/WO(\d{4})(\d{6})-.*/){full, year, number->
            return year + '/' + number
        }
    }


    private static final List<Pattern> DOCNO_WO_REGEXPS = new ArrayList<Pattern>() {
        {

            // 2-year + number: 9819933, 03059581
            add( Pattern.compile("(\\d{2})(\\d{5,6})"));

            // year + [/\s] + number:
            add( Pattern.compile("(\\d{2,4})[/\\s](\\d{4,6})"));
            // 2007/090112, 98/35584
            // 98 09770

            // 4-year + number: 2004105531, 200410553
            add( Pattern.compile("(\\d{4})(\\d{5,6})"));

            // WO + [\\s-/] + year + [/-] + number
            add( Pattern.compile("WO[\\s-/]?(\\d{2,4})[\\\\./-](\\d{4,6})"));
            // WO 00/6792, WO 02/24140, WO 02/055923,
            // WO98/20466, WO02/053867
            // WO 2004/062426, WO2004/060984
            // WO-90/06775, WO-2004/087473
            // WO/02/088519
            // WO2004.113721
            // WO 01-17806

            // WO 2-year + number
            add( Pattern.compile("WO(\\d{2})/(\\d{5,6})"));
            // WO03036171

            // WO + [\\s-/] + year + / numb1 + numb2
            add( Pattern.compile("WO[\\s-/]?(\\d{2,4})/(\\d{3})\\s(\\d{3})"));
            //WO 2006/086 910

            // PCT/XX + year + / + number
            add( Pattern.compile("PCT/\\w[\\w\\d](\\d{2})/(\\d{4,6})"));
            // PCT/US98/091078
            // PCT/US98/09178
        }
    }

    /**
     * 公開年四碼西元年+/+六碼數字(不足6位,前補0至6碼)
     * Result: 2011/067944
     * 
     * @param rawDocNo
     * Acceptable format:
     *  2-year + 5-6 number: 
     *          9819933, 03059581
     *  
     *  year + [/\s] + number: 
     *          2007/090112, 98/35584, 98 09770
     *          
     *  4-year + number: 
     *          2004105531, 200410553    
     *  
     *  WO + [\\s-/] + year + [/-] + number:
     *          WO 00/6792, WO 02/24140, WO 02/055923,
     *          WO98/20466, WO02/053867
     *          WO 2004/062426, WO2004/060984
     *          WO-90/06775, WO-2004/087473
     *          WO/02/088519
     *          WO2004.113721
     *          WO 01-17806
     *  
     *  WO 2-year + number
     *          WO03036171
     *  
     *  WO + [\\s-/] + year + / numb1 + numb2
     *          WO 2006/086 910
     *    
     *  PCT/XX + year + / + number   
     *          PCT/US98/091078
     *          PCT/US98/09178
     *          PCT/F199/00865
     *  
     *  Optional Date String required?
     *  DM/061134
     *  
     *  error form?
     *  1 110 547?
     *  4000487?  
     *  
     * @return
     */
    def static String getDocNoWo(String rawDocNo){
        Matcher matcher
        for(Pattern pattern: this.DOCNO_WO_REGEXPS){
            matcher = pattern.matcher(rawDocNo)
            if(matcher.matches()){
                String year = matcher.group(1)
                String number = (matcher.groupCount()==3)? matcher.group(2) + matcher.group(3): matcher.group(2)

                return getYearWO(year) + '/' + StringUtils.leftPad(number, 6, '0')
            }
        }
        return null
    }


    /**
     * WO+(APP NO去掉/)
     * WOPCTDE1994000832
     * @param appNo 
     * Acceptable format example
     *  SE1998/000800
     *  EP1996003803
     *  US78000044
     *  BR8700004
     *  US82/712, US82/72 
     *  78SE 7800022 
     * @return
     */
    def static String getAppIdWO(String appNo){
        return 'WO' + StringUtils.remove(getAppNoWO( appNo), '/')
    }

    /**
     * PCT+/+國別大寫兩碼+申請年四碼西元年+/+六碼數字
     * PCT/DE1994/000832
     * 
     * @param appNo
     * Acceptable format example
     *  SE1998/000800
     *  EP1996003803
     *  US78000044
     *  BR8700004
     *  US82/712, DE80/81
     *  78SE 7800022
     * @return
     */
    def static String getAppNoWO(String appNo){
        CharSequence pat
        switch(appNo){
            case ~/\w{2}\d{4}\\/\d{6}/: // SE1998/000800
                pat = /(\w{2})(\d{4})\\/(\d{6})/
                break;

            case ~/\w{2}\d{10}/: // EP1996003803
                pat = /(\w{2})(\d{4})(\d{6})/
                break;

            case ~/\w{2}\d{8}/: // US78000044
                pat = /(\w{2})(\d{2})(\d{6})/
                break;

            case ~/\w{2}\d{7}/:  // BR8700004
                pat = /(\w{2})(\d{2})(\d{5})/
                break;

            case ~/\w{2}\d{2}\\/\d{1,5}/:  // US82/712
                pat = /(\w{2})(\d{2})\\/(\d{1,5})/
                break;

            case ~/\d{2}\w{2}\s\d{7}/:   // 78SE 7800022
                pat = /\d{2}(\w{2})\s(\d{2})(\d{5})/
                break;
            case ~ /^(?i)PCT-([a-z]{2})([\d]{4})-([\d]{6})$/: //JP WO 優先權申請號格式 PCT-US1997-011670
                pat = /^(?i)PCT-([a-z]{2})([\d]{4})-([\d]{6})$/
                break;
            default:
                return ''
        }
        return appNo.replaceAll(pat){full, country, year, number->
            return 'PCT/' + country.toString().toUpperCase() + getYearWO(year.toString()) + '/' + StringUtils.leftPad(number.toString(), 6, '0')
        }
    }

    /**
     * WO: convert marshallid to WO patId
     * (docNo去掉/)+-+kindcode+-+doDate(yyyymmdd)
     * WO1996002947-A1-19960201
     */
    def static String marshallidToPatidWO(String docId){
        return docId.replaceAll(/(\d{10})(\S{2})\\/(\d{8}).*/){full, num, kind, doDate->
            return 'WO' + num + '-' + kind + '-' + doDate
        }
    }

    /**
     * WO: convert marshallid to WO Doc No
     * 公開年四碼西元年+/+六碼數字(不足6位,前補0至6碼) 
     * 2011/067944
     * @param docId
     * @return
     */
    def static String marshallidToDocNoWO(String docId){
        return docId.replaceAll(/(\d{4})(\d{6}).*/){full, year, num ->
            return year + '/' + num
        }
    }

    /*
     * Convert marshallid to patentNumber in 121 
     */
    public static String marshallidToPatentNumberWO(String docId){
        CharSequence regx = /(\d{4})(\d{6})(\S{2})\/.*/
        return docId.replaceAll(regx){full, year, num, kind->
            return 'WO ' + year + '/' + num + ' ' + kind
        }
    }

    def static String patIdToPatentNumberWO(String docId){
        CharSequence regx = /WO(\d{4})(\d{6})-(\S{2}).*/
        return docId.replaceAll(regx){full, year, num, kind->
            return 'WO ' + year + '/' + num + ' ' + kind
        }
    }

    /**
     * Covert to 4 digit year String
     * @param yr: 2 or 4 digits year
     */
    protected static String getYearWO(String yr){
        if(yr.length()<4){
            return (Integer.valueOf(yr)<70)?  "20$yr" : "19$yr"
        }
        return yr
    }

    /**
     * country + (DOC NO去掉非英數字之特殊符號) + kindcode + doDate(yyyymmdd)
     * 
     * @param country
     * @param docNo
     * @param kindCode
     * @param doDate
     * @return
     * @throws Exception
     */
    def static String getPatIdDOCDB(String country, String docNo, String kindCode, String doDate) throws Exception {
        docNo = docNo.replaceAll("[\\.\\s-/\\\\]", "");

        /*
         * NOTE: docNo 有可能會是非數字格式, 如[MarshallId = DOCDB-201511-006-DO-0001.xml/387309639]
         *  
         * if (!(Long.valueOf(docNo) instanceof java.lang.Long)) {
         *     throw new Exception("docNo format error");
         * } 
         */

        if (StringUtils.isBlank(kindCode)) {
            throw new Exception("kindCode format error");
        }

        String doDateStr = "";
        if (!!doDate) {
            doDateStr = "-" + doDate;
        }

        return country + docNo + "-" +kindCode + doDateStr;
    }

    /**
     * Others:(APP NO去掉非英數字之特殊符號)
     * 
     * 特例:db.PatentMarshallRU.find({_id: "DOCDB-201511-018-RU-0007.xml/300843656"})
     * 
     * @param appNo
     * @return
     */
    def static String getAppIdDOCDB(String appNo, String country = null) {
        
        if (country == "RU") {
            if (appNo.substring(0, 2) == "SU") {
                appNo = appNo + "RU"
            }
        }
        
        return appNo.replaceAll("[\\.\\s-/\\\\]", "");
    }

    /**
     * 將appNo去掉非數字,再加上EP
     * @param appNo
     * @return
     */
    def static String getAppIdEP(String appNo) {
        return "EP" + appNo.replace(".", "");
    }

    /**
     * 將marshall._id去除patType,再加上EP
     * @param doc
     * @return
     */
    def static String getPatIdEP(DBObject doc) {
        return "EP" + doc["_id"][0..-5];
    }

    /**
     *      * 驗證碼規則
     * fix application number without check code
     * origin appNo = 12345678 ->
     * 1*1,2*2,3*1,4*2,5*1,6*2,7*1,8*2 ->
     * 1,4,3,8,5,12,7,16 ->
     * 1+4+3+8+5+1+2+7+1+6 = 38 ->
     * checkcode => 10 - 38%10 = 2 ->
     * fixAppNo = 12345678.2
     * @param appNo
     * @return
     */
    def static String getEpAppCheckcode(appNo) {
        def total = 0;
        def index = 0;
        appNo.each {
            int num = it.toInteger();
            if (index % 2 == 0) {
                total += num * 1;
            } else {
                if ((num*2)/10 >= 1) {
                    total += ( 1 + (num * 2) % 10);
                } else {
                    total += num * 2;
                }
            }
            index += 1;
        }
        int checkCode = 10 - (total % 10);
        if (checkCode == 10) {
            checkCode = 0;
        }
        return checkCode.toString()
    }

    /**
     * 九碼數字 + 一碼前置碼 + 兩碼數字 (前置碼和兩碼數字非必要)
     * 
     * @param appNo
     * @oaram pto  申請號從那個 pto 來的 (ex. JP 引證 EP 專利)
     * @return
     */
    def static String getAppNoTW(String appNo, String pto) {
        String fixAppNo = ""
        switch(pto){
            case "JP":
                if(appNo =~ /^([\d]{4})-([\d]{6})$/) { //2005-115044
                    def appNoMatcher = (appNo =~ /^([\d]{4})-([\d]{6})$/)[0]
                    def year = appNoMatcher[1]
                    year = Integer.toString(Integer.parseInt(year) - 1911)
                    year = StringUtils.leftPad(year, 3, '0')
                    def number = appNoMatcher[2]
                    fixAppNo = year + number
                } else {
                    throw new Exception("TW app number can't format at JPO's data: " + appNo)
                }
                break;
            default:
                throw new Exception("no pot info while normalize tw app no")
        }
        return fixAppNo;
    }

    /**
     * 沒有驗證碼,產生驗證碼
     * 如不足8位數,補0至8位數
     * 
     * @param appNo
     * @oaram pto  申請號從那個 pto 來的 (ex. JP 引證 EP 專利)
     * @return
     */
    def static String getAppNoEP(String appNo, String pto) {
        String fixAppNo = ""
        switch(pto){
            case "JP":
                if( appNo =~ /^([\d]{2})([\d]{2})-([\d]{6})$/) { //2006-114558
                    def appNoMatcher = (appNo =~ /^([\d]{2})([\d]{2})-([\d]{6})$/)[0]
                    appNo = appNoMatcher[2] + appNoMatcher[3]
                    fixAppNo = appNo + "." + getEpAppCheckcode(appNo);
                } else if(appNo =~ /^[\d]{8}[-:\.][\d]$/) { //06114558.7 06114558:7 06114558-7
                    fixAppNo = appNo.replaceAll("[-:\\.]", ".")
                } else if(appNo =~ /^([\d]{2})\s([\d]{3})\s([\d]{3}\.[\d])$/) {  //01 302 841.0
                    def appNoMatcher = (appNo =~ /^([\d]{2})\s([\d]{3})\s([\d]{3}\.[\d])$/)[0]
                    fixAppNo = appNoMatcher[1] + appNoMatcher[2] + appNoMatcher[3]
                }else {
                    throw new Exception("EP app number can't format at JPO's data: " + appNo)
                }
                break;
            default:
                if (appNo.contains(".")) {
                    String firstAppNo = appNo.split(/\./)[0];
                    if (firstAppNo.length() < 8) {
                        fixAppNo = "0" * (8- firstAppNo.length()) + appNo;
                    } else {
                        fixAppNo = appNo;
                    }
                } else {
                    if (appNo.size() < 8) {
                        appNo = "0" * (8-appNo.length()) + appNo;
                    }
                    fixAppNo = appNo + "." + getEpAppCheckcode(appNo);
                }
                break
        }

        return fixAppNo;
    }   // end getAppNoEP

    /**
     * DocNo為7碼或9碼
     * @param docNo
     * @param kindCode
     * @return
     */
    public static String getDocNoCN(String docNo, String kindCode) {
        String fixDocNo = "";
        String kindCodeNo;

        if (!!kindCode) {
            kindCode = kindCode.trim();
        } else {
            kindCode = "";
        }

        if (docNo.contains(" ")) {
            docNo = docNo.replaceAll("\\s","");
        }

        if (!!kindCode) {
            kindCodeNo = getKindCodeNoCN(kindCode);
        }
        if (docNo.matches("[ABCDSUY]?-\\d{7}")) {
            fixDocNo = getDocNoCN(docNo.split("-")[1], kindCode);
        } else if (docNo.size() == 9 && docNo.matches("\\d{9}")) {
            fixDocNo = docNo;
        } else if (docNo.size() == 8 && docNo.matches("\\d{8}")) {
            if (docNo[0] == "8" || !kindCode) {
                fixDocNo = null;
            } else {
                fixDocNo = kindCodeNo + docNo;
            }
        } else if (docNo.size() == 7 && docNo.matches("\\d{7}")) {
            if (docNo[0].matches("1|2|3")) {
                fixDocNo = docNo;
            } else {
                if (!!kindCode) {
                    fixDocNo = kindCodeNo + Constants.ZERO + docNo;
                } else {
                    fixDocNo = null;
                }
            }
        } else if (docNo.size() < 7) {
            fixDocNo = null;
        } else if (docNo.contains("-")) {
            fixDocNo = null;
        } else if (docNo.contains(".")) {
            fixDocNo = null;
        } else if (docNo.contains("(A)")) {
            fixDocNo = getDocNoCN(docNo.replace("(A)",""), kindCode);
        } else if (docNo.size() > 9) {
            fixDocNo = null;
        } else {
            fixDocNo = null;
        }
        return fixDocNo;
    }

    /**
     * 依照patType產生patTypeNo,以便組成DocNo
     * @param kindCode
     * @return
     */
    public static String getKindCodeNoCN(String kindCode) {
        String kindCodeNo = null;
        if (kindCode.matches("A.*|B.*")) {
            kindCodeNo = Constants.PAT_TYPE_FM_CODE_CN;
        }
        if (kindCode.matches("U.*|Y.*")) {
            kindCodeNo = Constants.PAT_TYPE_SD_CODE_CN;
        }
        if (kindCode.matches("S.*|D.*")) {
            kindCodeNo = Constants.PAT_TYPE_XX_CODE_CN;
        }
        return kindCodeNo;
    }

    /**
     * format TW rawDocNo 
     * @param docNo
     * @param kindCode
     * @param date
     * @return
     */
    public static String getDocNoTW(String docNo, String kindCode, Date date) {
        String fixDocNo;
        String kindCodeNo;
        docNo = docNo.replaceAll("[\\s\\-]*","");

        if (!!kindCode) {
            kindCodeNo = getKindCodeTW(kindCode.trim(), date);
        } else if (!!date && date < DateUtil.parseDate("20040801")) {
            kindCodeNo = getKindCodeTW(kindCode.trim(), date);
        }

        if (docNo.size() < 6) {
            docNo = "0" * (6 - docNo.size()) + docNo;
        }

        if (docNo.matches("[12]{1}[09]{1}[0-9]{1}[0-9]{1}\\d{5}") ) {
            fixDocNo = docNo;
        } else if (docNo.matches("[DIM0]{1}\\d{6}")) {
            fixDocNo = docNo;
        } else if (docNo.matches("\\d{6}")) {
            if (!!kindCodeNo) {
                fixDocNo = kindCodeNo + docNo;
            } else {
                fixDocNo = null;
            }
        } else if (docNo.size() == 8) {
            fixDocNo = null;
        } else if (docNo.matches("1\\d{6}")) {
            fixDocNo = "I" + docNo[1..-1];
        } else if (docNo.matches("[12]{1}[09]{1}[0-9]{1}[0-9]{1}[0-9]{1}\\d{5}")){
            fixDocNo = docNo[0..3] + docNo[5..-1];
        } else if (docNo.size() == 11) {
            fixDocNo = null;
        } else if (docNo.size() == 9){
            fixDocNo = null;
        } else {
            fixDocNo = null;
        }
        return fixDocNo;
    }

    /**
     * 產生kindCode for getDocNoTW
     * @param kindCode
     * @param date
     * @return
     */
    public static String getKindCodeTW(String kindCode, Date date) {
        String kindCodeNo;
        if (kindCode == "S") {
            kindCodeNo = "D";
        }
        if (kindCode == "U") {
            kindCodeNo = "M";
        }
        if (kindCode.matches("A.*|B.*")) {
            kindCodeNo = "I";
        }
        if (!!date) {
            kindCodeNo = "0";
        }
        return kindCodeNo;
    }

    /**
     * 回傳docNo,如果不足7位數補0
     * @param docNo
     * @return
     */
    def static String getDocNoEP(String docNo) {

        String fixDocNo = "";
        if (docNo.contains(" ")) {
            docNo = docNo.replaceAll("\\s","");
        }
        if (docNo.length() <= 7) {
            if (docNo.length() < 7) {
                int lostNum = 7 - docNo.length();
                fixDocNo = "0" * lostNum + docNo;
            } else {
                fixDocNo = docNo;
            }
        } else if (docNo.matches("[0]{1,2}\\d{7}")) {
            fixDocNo = docNo.replaceFirst("0{1,2}","");
        } else if (docNo.matches("[AB\\W]{1,2}\\d{7}")) {
            fixDocNo = docNo.replaceAll("[AB\\W]{1,2}","");
        } else if (docNo.contains("WO")) {
            fixDocNo = null;
        } else if (docNo.contains("-")) {
            fixDocNo = null;
        } else if (docNo.contains(".")) {
            fixDocNo = null;
        } else if (docNo.contains("XP")) {
            fixDocNo = null;
        } else if (docNo.size() > 7) {
            fixDocNo = null;
        } else {
            fixDocNo = null;
        }

        return fixDocNo;
    }   // end getDocNoEP

    /**
     * 
     * @param patData
     * @return
     */
    public static String getPatIdByOriginPTO(PatData patData) {

        String country = patData.country;

        String formatDocNo = "";

        switch(country){
            case "US":
                formatDocNo = PatNumberUtil.getPatIdUS(patData.stat, patData.docNo);
                break;
            case "CN":
            // TODO:
                throw new Exception("TODO: CN patId");
                break;
            case "JP":
            // TODO:
                throw new Exception("TODO: JP patId");
                break;
            case "TW":
            // TODO:
                throw new Exception("TODO: TW patId");
                break;
            case "WO":
            // TODO:
                throw new Exception("TODO: WO patId");
                break;
            case "EP":
            // TODO:
                throw new Exception("TODO: EP patId");
                break;
            case "KR":
            // TODO:
                throw new Exception("TODO: KR patId");
                break;
            default:
                throw new Exception("country error = ${country}");
                break;
        }

        return formatDocNo;

    }   // end getPatIdByOriginPTO

    /**
     * 
     * @param patData
     * @param dbObject
     * @return
     */
    def static getAppInfoByOriginPTO(DBObject dbObject, String country) {

        String appNo;
        String appYear;
        String appDate;
        // String dataFormat;

        def appInfo = [:];

        switch(country){
            case "US":

            // dataFormat = "docdb"
                appNo = dbObject."document-id"."doc-number";
                appDate = dbObject."document-id"."date" as String;
            //
                appYear = appDate?.substring(0, 4);
                if (appNo.substring(0, 4) == appYear) {
                    appNo = appNo.substring(4);
                }
            //
                appInfo << [rawAppNo : appNo];
                appInfo << [appNo : PatNumberUtil.getAppNoUS(appNo)];
                appInfo << [appId : PatNumberUtil.getAppIdUS(appNo)];
                appInfo << [appDate : DateUtil.parseDate(appDate)];
            // appInfo << [dataFormat : dataFormat];

                break;
            case "CN":
            /*
             * TODO:
             * NOTE: CN data-format="original", 資料格式會有
             * [_id:557bec47b4411f24f196e23b, appNumber:1985 85100275]
             * [_id:557c94c8b4411f24f1baf391, appNumber:A200710140702X]
             * 所以目前(2016-03-07)看起來應以data-format=docdb為主.               
             */
                throw new Exception("TODO: CN patId");
                break;
            case "JP":
            // TODO:
                throw new Exception("TODO: JP patId");
                break;
            case "TW":
            // TODO:
                throw new Exception("TODO: TW patId");
                break;
            case "WO":
            // TODO:
                throw new Exception("TODO: WO patId");
                break;
            case "EP":
            // TODO:
                throw new Exception("TODO: EP patId");
                break;
            case "KR":
            // TODO:
                throw new Exception("TODO: KR patId");
                break;
            default:
                throw new Exception("country error = ${country}");
                break;
        }

        return appInfo;

    }   // end getAppNoByOriginPTO

    /**
     * @param stat
     * @param docNo
     * @param country
     * @return
     */
    public static String getMappingPatentNumber(int stat, String docNo, String country, String kindCode) {

        //  TODO:
        switch (country) {
            case "US":
                getMappingPatentNumberUS(stat, docNo);
                break;
            case "CN":
            // TODO:
                break;
            case "JP":
            // TODO:
                break;
            case "TW":
            // TODO:
                break;
            case "EP":
                getMappingPatentNumberEP(docNo);
                break;
            case "WO":
                getMappingPatentNumberWO(docNo, kindCode);
                break;
            case "KR":
            // TODO:
                break;

        }
    }

    /**
     * 轉換成 mongo info 層中的 patentNumber
     * @param docNo
     * @return
     */
    public static String getMappingPatentNumberUS(int stat, String docNo) {

        if (stat == Constants.PAT_STAT_PUBLIC) {
            return docNo;
        } else {
            return "US" + "0" * (9 - docNo.length()) + docNo
        }
    }

    /**
     * WO 轉換成 121 patentNumber 格式
     * @param docNo
     * @param kindCode
     * @return
     */
    public static String getMappingPatentNumberWO(String docNo, String kindCode){
        return 'WO ' +  docNo + ' ' + kindCode
    }

    public static String getMappingPatentNumberEP(String docNo) {
        return "EP" + "0" * (7 - docNo.length()) + docNo
    }

}
