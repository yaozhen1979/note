package com.patentdata.process

import com.mongodb.DBObject;

import java.util.List;

import com.patentdata.model.PatClsCpc;
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataBriefId
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataClaimsId
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataDescId
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonAgentId
import com.patentdata.model.PatPersonApplicantId
import com.patentdata.model.PatPersonAssignee;
import com.patentdata.model.PatPersonAssigneeId
import com.patentdata.model.PatPersonInventorId
import com.patentdata.model.PatRawCn;
import com.patentdata.model.AppData;
import com.patentdata.model.PatData;
import com.patentdata.model.PatRefCited
import com.patentdata.model.PersonData;
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonInventor
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataService;
import com.patentdata.service.PatRawService;
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import com.gmongo.GMongoClient;
import com.mongodb.Bytes;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.patentdata.service.AppDataService
import com.patentdata.util.JSONUtil;
import com.patentdata.util.MongoUtil;
import com.patentdata.util.DateUtil;
import com.patentdata.util.MailUtil;
import com.patentdata.util.CaptchaUtil;
import com.patentdata.util.StringUtil;
import com.patentdata.util.UUIDUtil;
import com.patentdata.util.PatClsUtil;
import com.patentdata.util.HibernateUtil;
import com.patentdata.common.Constants;
import com.patentdata.exception.JsonFormatException
import com.patentdata.helper.PersonDataHelper


class CNPatDataProcess  extends BaseProcess {
	
	CNPatDataProcess() {
		logger = LoggerFactory.getLogger(CNPatDataProcess.class);
	}
	
	private static GMongoClient dbClient = MongoUtil.connectByConfig("CN");
	private static DB marshallDB = dbClient.getDB("PatentMarshallSIPO");
	
	@Override
	DBCursor queryData() throws Exception {
		String cc = null;
		if (!!queryMap) {
			cc = queryMap.country;
		} else {
			throw new Exception("error = queryMap is empty")
		}
		
		DBCollection marshallCol = marshallDB.getCollection("PatentMarshall" + cc);
		// TODO: find limit
		DBCursor queryCursor = marshallCol.find(queryMap.query).limit(1).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
		
		return queryCursor;
	}
	
	/**
	 * app_data
	 * pat_data
	 * pat_raw
	 * person_data
	 * person_lang (only for WO)
	 * person_lang_list (only for WO)
	 * person_person_agent
	 * person_person_applicant
	 * person_person_assignee
	 * person_person_correspondence_addr
	 * pat_person_examiner
	 * pat_person_inventor
	 * pat_data_brief
	 * pat_data_claims
	 * pat_data_desc
	 * pat_data_title
	 * pat_data_cls.....
	 * pat_data_ref.....
	 * pat_event_record
	 * pat_event_amend_log
	 */
	
	@Override
	void processData(DBObject data) throws Exception {
		
		logger.debug "data._id = ${data._id}";
		
		if(data._id.contains("null")){
			String cc = data.country;
			DBObject dbobject = marshallDB.getCollection("ErrorPatentMarshall${cc}").findOne(["_id":data._id]);
			
			marshallDB.getCollection("ErrorPatentMarshall${cc}").save(data);
			marshallDB.getCollection("PatentMarshall" + cc).remove(["_id": data._id]);
		}else{
			//appData
			AppData appData = genAppData(data);
			AppDataService appDataService = new AppDataService();
			appDataService.saveOrUpdateAppData(appData);
			
			//patData
			PatData patData = genPatData(data);
			PatDataService patDataService = new PatDataService();
			patDataService.saveOrUpdatePatData(patData);
			//pat_raw
			PatRawCn patRawCn = getPatRawCn(data,patData);
			PatRawService patRawService = new PatRawService();
			patRawService.saveOrUpdate(patRawCn);
			
			
			//person_data
			getPatPersonInfo(data,patData);
			
			// pat_data_brief
			/*List<PatDataBrief> patDataBriefList = getPatDataBrief(data, patData);
			patDataService.saveOrUpdatePatDataBrief(patDataBriefList);*/
			
			//pat_data_claims
			/*List<PatDataClaims> patDataClaimsList = getPatDataClaims(data,patData);
			patDataService.saveOrUpdatePatDataClaims(patDataClaimsList);*/
			
			//pat_data_desc
			/*List<PatDataDesc> patDataDescList = getPatDataDesc(data,patData);
			patDataService.saveOrUpdatePatDataClaims(patDataDescList);
			
			//pat_data_title
			List<PatDataTitle> patDataTitleList = getPatDataTitle(data, patData);
			patDataService.saveOrUpdatePatDataTitle(patDataTitleList)
			
			PatClsService patClsService = new PatClsService();
			// ipc and ipcr
			List<PatClsIpc>  patClsIpcList = genPatClsIpc(data, patData);
			patClsService.saveOrUpdatePatClsIpc(patClsIpcList);
			
			//pat_data_ref
			PatRefService patRefService = new PatRefService()
			List<PatRefCited> patRefCitedList = genPatRefCited(data,patData);
			*/
			
			
		}
	}
	
	@Override
	void processFailData(DBObject data, String message) throws Exception {
		// TODO Auto-generated method stub
		//logger.error("processFailData, todo...");
		//MailUtil.sendToPatentCloud("yingjieyang@patentcloud.com", "CNPatDataProcess Exception", message);
	}
	
	public PatRefCited genPatRefCited(DBObject data,PatData patData){
		List<PatRefCited> patRefCitedList = new ArrayList<PatRefCited>();
		DBObject marshallData = data.data.expansion;
		DBObject refCitedDBObject = marshallData."cn-patent-document"."cn-bibliogrophic-data"."references-cited";
		
	}
	
	
	public static PatClsIpc getCNIpc(PatData patData, String ipcStr, String clsVersion, int item, boolean mainIPC = false, boolean isIndexFlag = false, boolean isMainLinkedIndex = false) throws Exception {
		
		PatClsIpc patClsIpc = new PatClsIpc();
		PatClsIpcId patClsIpcId = new PatClsIpcId();
		patClsIpcId.patId = patData.patId;
		patClsIpcId.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
		patClsIpcId.ipcType = Constants.CLS_TYPE_IPC;
		if (mainIPC) {
			patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_YES;
		} else {
			patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;
		}
		
		if (item == 0) {
			patClsIpcId.item = 1;
		} else {
			patClsIpcId.item = item + 1;
		}
		
		patClsIpc.id = patClsIpcId;

		patClsIpc.ipcText = formatIpc(ipcStr);
		patClsIpc.clsVersion = clsVersion;
		patClsIpc.symbolPosition = " ";
		
		if (isIndexFlag) {
			patClsIpc.indexFlag = Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES;
			if (isMainLinkedIndex) {
				patClsIpc.indexType = Constants.IPC_MAIN_LINKED_INDEXING;
			} else {
				patClsIpc.indexType = Constants.IPC_SUB_LINKED_INDEXING;
			}
		}
		
		patClsIpc.createDate = new Date();

		return patClsIpc;
	}
	
	/**
	 *
	 * @param ipcStr
	 * @return
	 */
	public static String formatIpc(String ipcStr) {
		
		String ipcText = "";
		String[] ipcArray = ipcStr.trim().split("\\s+");
		
		if (ipcArray.length > 1) {
			//
			String ipcSection = "";
			
			if (ipcArray.length == 2) {
				if (ipcStr.replaceAll("\\s", "").length() <= 4) {
					ipcText = ipcStr.replaceAll("\\s", "");
					logger.debug("ipc data = ${ipcText}, data format error");
				} else {
					ipcSection = ipcArray[0].substring(1, 2);
					ipcText = ipcSection + ipcArray[1];
				}
			} else {
				ipcSection = ipcArray[0];
				String rawIpc = ipcSection + ipcArray[1] + " " + ipcArray[2];
				String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z]) ([0-9]{0,4})\/([0-9]{1,6})/;
				rawIpc.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
					ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
				}
			}   // end if (ipcArray.length == 2)
			
		} else {
			ipcText = ipcStr.trim();
			logger.debug("ipc data = ${ipcText}, data format error");
			
		}
		return ipcText;
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public List<PatClsIpc> genPatClsIpc(DBObject data,PatData patData){
		List<PatClsIpc> patClsIpcList = new ArrayList<PatClsIpc>();
		DBObject biblio = getBiblio(data);
		
		DBObject patIpc = biblio."classification-ipc";
		
		if(!!patIpc){
			if (!!patIpc."main-classification") {
				String clsVersion = ""
				if (!!patIpc.ipc-version) {
					clsVersion = patIpc.ipc-version
				}
				
				if (!!patIpc."main-classification"[0]) {
					// println "main-classification = " + ipcDBObject."main-classification"[0]
					PatClsIpc patClsIpc = getCNIpc(patData, patIpc."main-classification"[0], clsVersion, patClsIpcList.size(), true);
					patClsIpcList.add(patClsIpc);
				}
				
				if (!!patIpc."further-classification") {
					// println "further-classification = " + ipcDBObject."further-classification"[0].value
					PatClsIpc patClsIpc = getCNIpc(patData, patIpc."further-classification"[0].value, clsVersion, patClsIpcList.size(), false);
					patClsIpcList.add(patClsIpc);
				}
			}
		}else{
			logger.error "marshall._id = ${data._id}, classification-ipc is empty.";
		}
	}
	
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public List<PatDataDesc> getPatDataDesc(DBObject data,PatData patData){
		List<PatDataDesc> patDataDescList = null;
		DBObject marshallData = data.data.expansion;
		DBObject descDBObject = marshallData."cn-patent-document"."application-body"."description";
		if(!!descDBObject){
			patDataDescList = new ArrayList<PatDataDesc>();
			
			descDBObject.eachWithIndex { it,index->
				PatDataDescId patDataDescId = new PatDataDescId();
				patDataDescId.patId = patData.patId;
				patDataDescId.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
				patDataDescId.lang = patData.oriLang;
				
				PatDataDesc patDataDesc = new PatDataDesc();
				patDataDesc.id = patDataDescId;
				patDataDesc.createDate = new Date();
				patDataDesc.lastUpdDate = new Date();
				if (!!it.value) {
					patDataDesc.description = it.value[0];
					patDataDescList.add(patDataDesc);
				} else {
					logger.error "marshall._id = ${data._id}, title(lang = ${patDataTitleId.lang}) is empty."
				}
			}
		}else{
			logger.error "marshall._id = ${data._id}, claims is empty."
		}
		
		return patDataDescList;
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public List<PatDataTitle> getPatDataTitle(DBObject data,PatData patData){
		List<PatDataTitle> patDataTitleList = null;
		DBObject biblio = getBiblio(data);
		DBObject inventionTitle = biblio."invention-title"
		
		if(!!inventionTitle){
			patDataTitleList = new ArrayList<PatDataTitle>();
			inventionTitle.eachWithIndex { it, index ->
				PatDataTitleId patDataTitleId = new PatDataTitleId();
				patDataTitleId.patId = patData.patId;
				patDataTitleId.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
				patDataTitleId.lang = patData.oriLang;
				
				
				PatDataTitle patDataTitle = new PatDataTitle();
				patDataTitle.id = patDataTitleId;
				patDataTitle.createDate = new Date();
				patDataTitle.lastUpdDate = new Date();
				
				if (!!it.value) {
					patDataTitle.title = it.value[0];
					patDataTitleList.add(patDataTitle);
				} else {
					logger.error "marshall._id = ${data._id}, title(lang = ${patDataTitleId.lang}) is empty."
				}
			}
		}
		
		return patDataTitleList;
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public PatDataClaims getPatDataClaims(DBObject data,PatData patData){
		List<PatDataClaims> patDataClaimsList = null;
		DBObject marshallData = data.data.expansion;
		DBObject claimsDBObject = marshallData."cn-patent-document"."application-body"."claims";
		
		if(!!claimsDBObject){
			patDataClaimsList = new ArrayList<PatDataClaims>();
			
			claimsDBObject.eachWithIndex { it,index->
				PatDataClaims patDataClaims = new PatDataClaims();
				patDataClaims.createDate = new Date();
				patDataClaims.lastUpdDate = new Date();
				
				PatDataClaimsId patDataClaimsId = new PatDataClaimsId();
				patDataClaimsId.patId = patData.patId;
				patDataClaimsId.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
				patDataClaimsId.lang = patData.oriLang;
				patDataClaims.id = patDataClaimsId;
				
				patDataClaimsList.add(patDataClaims);
				
			}
		}else{
			logger.error "marshall._id = ${data._id}, claims is empty."
		}
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public PatDataBrief getPatDataBrief(DBObject data,PatData patData){
		List<PatDataBrief> patDataBriefList = null;
		DBObject marshallData = data.data.expansion;
		DBObject abstractDBObject = marshallData."cn-patent-document"."cn-bibliographic-data"."abstract";
		
		if (!!abstractDBObject) {
			
			patDataBriefList = new ArrayList<PatDataBrief>();
			
			abstractDBObject.eachWithIndex { it, index ->
				PatDataBrief patDataBrief = new PatDataBrief();
				patDataBrief.createDate = new Date();
				patDataBrief.lastUpdDate = new Date();
				
				PatDataBriefId patDataBriefId = new PatDataBriefId();
				patDataBriefId.patId = patData.patId;
				patDataBriefId.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
				patDataBriefId.lang = patData.oriLang;
				
				patDataBrief.id = patDataBriefId;
				//patDataBriefList.add(patDataBrief);
				if (!!it.p[0].value) {
					patDataBrief.brief = it.p[0].value[0]
					println patDataBrief.brief
					patDataBriefList.add(patDataBrief);
				} else {
					logger.error "marshall._id = ${data._id}, abstract is empty."
				}
				
			}
			
		}else{
			logger.error "marshall._id = ${data._id}, abstract is empty."
		}   // end if (!!abstractDBObject)
		
		return patDataBriefList;
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 */
	public void getPatPersonInfo(DBObject data,PatData patData){
		List<PersonData> personDataList = new ArrayList<PersonData>();
		
		List<PatPersonApplicant> patPersonApplicants = new ArrayList<PatPersonApplicant>();
		List<PatPersonInventor> patPersonInventors = new ArrayList<PatPersonInventor>();
		List<PatPersonAgent> patPersonAgents = new ArrayList<PatPersonAgent>();
		List<PatPersonAssignee> patPersonAssignees = new ArrayList<PatPersonAssignee>();
		
		DBObject biblio = getBiblio(data);
		
		DBObject applicants = biblio."cn-parties"?."cn-applicants"?."cn-applicant"
		DBObject inventors = biblio."cn-parties"?."cn-inventors"?."cn-inventor"
		DBObject agents = biblio."cn-parties"?."cn-agents"?."cn-agent"
		DBObject assignees = biblio."assignees"?."assignee"
		
		if(!!applicants){
			applicants.eachWithIndex { applicant, index->
				PersonData personData = null;
				String applicantName = "";
				String applicantCountry = "";
				String applicantAddress = "";
				int sequence;
				
				applicantName = applicant."addressbook"[0]?."name"[0]?.value;
				
				if(!!applicant."addressbook"."address"?."text"){
					applicantAddress = applicant."addressbook"."address"."text";
				}
				//未找到例子來解決country
				if(!!applicant."addressbook"."country"){
					applicantCountry = applicant."addressbook"."country";
				}
				
				personData = checkAndGeneratePersonData(applicantName,applicantAddress,applicantCountry,personDataList);
				personDataList << personData
				
				PatPersonApplicant patPersonApplicant = genPatPersonApplicant(applicant, personData, patData, index + 1);
				patPersonApplicants.add(patPersonApplicant);
			}
		}
		
		if(!!inventors){
			inventors.eachWithIndex { inventor,index->
				PersonData personData = null;
				String inventorName = "";
				String inventorCountry = "";
				String inventorAddress = "";
				int sequence;
				
				inventorName = inventor."name"[0]?.value.trim();
				//未找到inventorCountry && inventorAddress
				personData = checkAndGeneratePersonData(inventorName,null,null,personDataList);
				personDataList << personData
				
				PatPersonInventor patPersoninventor = genPatPersonInventor(inventor, personData, patData, index + 1);
				patPersonInventors.add(patPersoninventor);
				
			}
		}
		
		if(!!agents){
			agents.eachWithIndex { agent,index->
				PersonData personData = null;
				String agentName = "";
				String agentCountry = "";
				String agentAddress = "";
				int sequence;
				
				//agentName = agent."name"[0]?.value.trim();
				agentName = agent."cn-agency"[0]?."name"[0]?.value.trim()  +  agent."name"[0]?.value.trim();
				//未找到agentCountry && agentAddress
				personData = checkAndGeneratePersonData(agentName,null,null,personDataList);
				personDataList << personData
				
				PatPersonAgent patPersonAgent = genPatPersonAgent(agent , personData, patData, index + 1);
				patPersonAgents.add(patPersonAgent);
				
			}
		}
		
		if(!!assignees){
			assignees.eachWithIndex { assignee,index->
				PersonData personData = null;
				String assigneesName = "";
				String assigneesAddress = "";
				
				assigneesName = assignee."addressbook"."name".value ;
				assigneesAddress = assignee."addressbook"?."address"?."text"
				
				personData = checkAndGeneratePersonData(assigneesName,assigneesAddress,null,personDataList);
				personDataList << personData
				PatPersonAssignee patPersonAssignee = genPatPersonAssignee(assignee,personData,patData,index + 1);
				patPersonAssignees.add(patPersonAssignee);
			}
		}
		
		PersonDataServices personSvc = new PersonDataServices();
		personSvc.saveOrUpdate(personDataList, patPersonApplicants, patPersonInventors, patPersonAgents, PatPersonAssignee, null, null);
		
	}
	
	/**
	 *
	 * @param assignee
	 * @param personData
	 * @param patData
	 * @param item
	 * @return
	 */
	public PatPersonAssignee genPatPersonAssignee (DBObject assignee,PersonData personData,PatData patData,int item){
		PatPersonAssigneeId id = new PatPersonAssigneeId();
		id.item = item;
		id.patId = patData.patId;
		id.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
		
		PatPersonAssignee patPersonAssignee = new PatPersonAssignee();
		patPersonAssignee.id = id;
		patPersonAssignee.personData = personData;
		patPersonAssignee.createDate = new Date();
		
		return patPersonAssignee;
	}
	
	
	
	/**
	 *
	 * @param agent
	 * @param personData
	 * @param patData
	 * @param item
	 * @return
	 */
	public PatPersonAgent genPatPersonAgent(DBObject agent,PersonData personData,PatData patData,int item){
		PatPersonAgentId id = new PatPersonAgentId();
		id.item = item;
		id.patId = patData.patId;
		id.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
		
		PatPersonAgent patPersonAgent = new PatPersonAgent();
		patPersonAgent.id = id;
		patPersonAgent.personData = personData;
		patPersonAgent.createDate = new Date();
		return patPersonAgent;
	}
	
	/**
	 *
	 * @param inventor
	 * @param personData
	 * @param patData
	 * @param item
	 * @return
	 */
	public PatPersonInventor genPatPersonInventor(DBObject inventor, PersonData personData, PatData patData, int item){
		PatPersonInventorId id = new PatPersonInventorId();
		id.item = item;
		id.patId = patData.patId;
		id.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
		
		PatPersonInventor patPersonInventor = new PatPersonInventor();
		patPersonInventor.id = id;
		patPersonInventor.personData = personData;
		patPersonInventor.createDate = new Date();
		patPersonInventor.personCountry = personData.country;
		
		return patPersonInventor;
	}
	
	/**
	 *
	 * @param applicant
	 * @param personData
	 * @param patData
	 * @param item
	 * @return
	 */
	private PatPersonApplicant genPatPersonApplicant(DBObject applicant, PersonData personData, PatData patData, int item) {
		
		PatPersonApplicantId id = new PatPersonApplicantId();
		id.item = item;
		id.patId = patData.patId;
		id.sourceId = Constants.SOURCE_ID_CN_OPENDATA;
		PatPersonApplicant patPersonApplicant = new PatPersonApplicant();
		patPersonApplicant.id = id;
		patPersonApplicant.personData = personData;
		//patPersonApplicant.appCode = applicant."app-type";
		//patPersonApplicant.designationCode = applicant."designation";
		patPersonApplicant.createDate = new Date();
		patPersonApplicant.personCountry = personData.country;
		
		return patPersonApplicant;
	}
	
	/**
	 *
	 * @param personName
	 * @param address
	 * @param country
	 * @param personDataList
	 * @return
	 */
	public PersonData checkAndGeneratePersonData(String personName, String address, String country, List<PersonData> personDataList) {
		
		PersonData personData = null;
		String personFacet = genPersonFacet(personName, address, country);
		
		if (StringUtils.isBlank(personFacet)) {
			throw new Exception("personFacet error");
		}
		
		PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personFacet, country, personDataList);
		
		if (!!existsData) {
			personData = existsData;
		} else {
			personData = genPersonData(personName, address, country, personFacet);
		}
		
		return personData;
	}
	
	/**
	 *
	 * @param personName
	 * @param country
	 * @return
	 */
	public String genPersonFacet(String personName, String address = '', country) {
		return StringUtil.personFacetWrap(personName + address + country);
	}
	
	public PersonData genPersonData(String personName, String address, String country, String personFacet) {
		PersonData personData = new PersonData();
		personData.personId = UUIDUtil.generateUUID();
		personData.personFacet = personFacet;
		//这里没有判断personType，需根据标签<name> or <orgname> 则为2，标签为<first-name> or <last-first>则为1
		personData.personType = Constants.PERSON_TYPE_NONE;
		personData.lang = Constants.CN_LANG;
		personData.personName = personName.trim();
		personData.address = address;
		personData.createDate = new Date();
		personData.lastUpdDate = new Date();
		
		return personData;
		
	}
	
	/**
	 *
	 * @param data
	 * @param patData
	 * @return
	 */
	public PatRawCn getPatRawCn(DBObject data,PatData patData){
		PatRawCn patRawCn = new PatRawCn();
		
		DBObject dbObject = data.data.expansion
		String rawJson = dbObject;
		
		if(JSONUtil.isJSONValid(rawJson)){
			patRawCn.rawJson = rawJson;
		}else{
			throw new JsonFormatException("rawJson");
		}
		
		patRawCn.rawId = data._id;
		patRawCn.patData = patData;
		patRawCn.createDate = new Date();
		patRawCn.lastUpdDate = new Date();
		
		return patRawCn;
		
	}
	
	/**
	 *
	 * @param data
	 * @return
	 */
	public PatData genPatData(DBObject data){
		PatData patData = new PatData();
		DBObject biblio = getBiblio(data);
		//DBObject marshallData = data.tata.expansion;
		int typeCode = 0;
		patData.patId = "CN" + data._id;
		patData.country = "CN";
		if(data.patentType.equals("FM")){
			patData.stat = 1;
		}else{
			patData.stat = 2;
		}
		
		patData.rawDocNo = biblio."cn-publication-reference"."document-id"."doc-number";
		
		if(data.patentType.equals("FM") || data.patentType.equals("SD")){
			typeCode = 1;
		}else if(data.patentType.equals("WG")){
			typeCode = 3;
		}else if(data.patentType.equals("XX")){
			typeCode = 2;
		}
		
		
		
		if(patData.rawDocNo.length()>7 || patData.rawDocNo.length()==7){
			patData.docNo = typeCode + StringUtils.leftPad(patData.rawDocNo, 8, "0");
		}else{
			patData.docNo = typeCode + StringUtils.leftPad(patData.rawDocNo, 6, "0");
		}
		
		patData.patType = typeCode;
		
		patData.docDate = DateUtil.parseDate(biblio."cn-publication-reference"."document-id"."date" as String);
		
		patData.kindCode = biblio."cn-publication-reference"."document-id"."kind";
		
		patData.rawAppNo = biblio."application-reference"."document-id"."doc-number";
		
		patData.appId = "CN" + data._id.substring(0,13);
		
		patData.defaultSourceId = Constants.SOURCE_ID_CN_OPENDATA;
		
		patData.oriLang = Constants.CN_LANG;
		
		patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
		
		patData.truncateFlag = Constants.TRUNCATE_FLAG_FALSE;
		
		patData.withdrawFlag = Constants.WITHDRAW_FLAG_FALSE;
		
		patData.deleteFlag = Constants.DELETE_FLAG_NO;
		
		patData.createDate = new Date();
		
		patData.lastUpdDate = new Date();
		
		patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES;
		
		patData.docdbFlag = Constants.DOCDB_FLAG_NO;
		
		return patData;

	}
	
	/**
	 *
	 * @param data
	 * @return
	 */
	public AppData genAppData(DBObject data){
		
		AppData appData = new AppData();
		// get biblio
		DBObject biblio = getBiblio(data);
		
		String appNo;
		//String appId;
		//String appDate;
		//String country;
		
		appNo = biblio."application-reference"."document-id"."doc-number"
		def appDate = biblio."application-reference"."document-id"."date" as String
		def country= biblio."application-reference"."document-id"."country"
		
		if(appNo.contains(".")){
				appData.appNo = appNo;
		}else{
			appData.appNo = CaptchaUtil.genAppNumberWithCaptcha(appNo,true);
		}
		appData.appDate = DateUtil.parseDate(appDate);
		
		appData.country = country;

		appData.appId = getappId(data);
		appData.createDate = new Date();
		appData.lastUpdDate = new Date();
		appData.appLang = "cn";
		
		return appData;
	}
	
	/**
	 *
	 * @param data
	 * @return
	 */
	public String getappId(DBObject data){
		String _id = data._id;
		return "CN" + _id.substring(0,13);
	}
	
	
	/**
	 *
	 * @param data
	 * @return
	 */
	public DBObject getBiblio(DBObject data){
		DBObject marshallData = data.data.expansion;
		return marshallData["cn-patent-document"]["cn-bibliographic-data"]
		
	}
	
	static main(args) {
		def queryMap = [country: "SIPO", query: [_id: "2013800010365B"]]
		// def queryMap = [country: ""]
		logger.info "queryMap = ${queryMap}"
		new CNPatDataProcess().queryMap(queryMap).process();

		
		logger.info "finished..."
	}

}
