package com.patentdata.process.impl

import org.slf4j.LoggerFactory

import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.common.PatTypeEnum
import com.patentdata.common.RelRawTypeEnum
import com.patentdata.model.AppData
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCset
import com.patentdata.model.PatClsFieldOfSearch
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsLoc
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataBriefId
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataClaimsId
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataDescId
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonAssignee
import com.patentdata.model.PatPersonCorrespondenceAddr
import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PatPtopidMapping
import com.patentdata.model.PatRawUs
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedCls
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefCitedNplCls
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefRelatedChild
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PersonData
import com.patentdata.process.USPatDataProcess
import com.patentdata.service.AppDataService
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataService
import com.patentdata.service.PatPtopidMappingService
import com.patentdata.service.PatRawService
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.DateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.PatRefUtil
import com.patentdata.util.USPatDataUtil

class USPatDataProcessXmlImpl extends USPatDataProcess {
    
    public USPatDataProcessXmlImpl() {
        logger = LoggerFactory.getLogger(USPatDataProcessXmlImpl.class);
    }
    
    private DBObject biblio = null;
    private Map appRefDataMap = null;
    private PatDataService patSvc = new PatDataService();

    @Override
    public void processData(DBObject doc) throws Exception {
        marshallDoc = doc;
        // 1:XML or 2:HTML
        relRawType = RelRawTypeEnum.US.XML.findRelRawTypeCode(marshallDoc.relRawType);

        if (relRawType == Constants.US_REL_RAW_TYPE_XML_CODE) {

            root = getRoot(marshallDoc);
            if (root == null) {
                throw new Exception("no root error , marshall id = $marshallDoc._id ");
            }

            biblio = getBiblio(marshallDoc.stat, root);
            if (biblio == null) {
                throw new Exception("no biblio error, marshall id = $marshallDoc._id ");
            }

            brief = (!!root."abstract") ? root."abstract"  : "";
            claims = root."claims";
            description = root."description";
            title = biblio."invention-title";

            String dtdVersion = root."dtd-version";
            //
            appRefDataMap = parseApplicationReference();
            // AppData
            saveOrUpdateAppData();
            
            // PatData
            def pubRefData = parsePublicationReference();
            String oldPatNo = PatNumberUtil.getMappingPatentNumberUS(marshallDoc.stat, marshallDoc._id);
            DBObject oldInfoDoc = oldInfoCol.findOne(["patentNumber" : oldPatNo]);
            
            // generate PatData
            patData = USPatDataUtil.genPatDataXML(oldInfoDoc, marshallDoc, root, biblio, appRefDataMap, pubRefData, now);
            saveOrUpdatePatData();
            
            //
            savaOrUpdataPatPtoPidMapping(oldInfoDoc._id.toString());
            
            // PatRawUs
            saveOrUpdatePatRawUs();
            
            // PersonRelatedData
            saveOrUpdatePersonRelatedData();
            
            // title
            saveOrUpdatePatDataTitle();
            
            // brief
            if (!!brief) {
                saveOrUpdatePatDataBrief();
            }
            // claims
            saveOrUpdatePatDataClaims();
            
            // description
            saveOrUpdatePatDataDesc();
            
            // cls...
            saveOrUpdateCls();
            
            // pat_ref_cited
            saveOrUpdatePatRefCited();
            
        } else if (relRawType == Constants.US_REL_RAW_TYPE_HTML_CODE) {
            throw new Exception("wrong relRawType, marshall id = $marshallDoc._id ");
        }
    }
    
    @Override
    public void saveOrUpdateAppData() {
        // generate AppData
        AppData appData = USPatDataUtil.genAppDataXML(root, biblio, appRefDataMap, now);
        AppDataService appSvc = new AppDataService()
        appSvc.saveOrUpdateAppData(appData);
    }
    
    @Override
    public void saveOrUpdatePatData() {
        patSvc.saveOrUpdatePatData(patData);
    }
    
    @Override
    public void saveOrUpdatePatRawUs() {
        PatRawUs patRawUs = USPatDataUtil.genPatRawUsDataXML(marshallDoc, patData, relRawType, now);
        PatRawService patRawSvc = new PatRawService();
        patRawSvc.saveOrUpdatePatRawUs(patRawUs);
    }
    
    @Override
    public void saveOrUpdatePatRefCited() {
        
        PatRefService patRefService = new PatRefService();
        
        // patcit
        List<PatRefCited> patRefCitedList = null;
        List<PatRefCitedCls> patRefCitedClsList = null;
        // nplcit
        List<PatRefCitedNpl> patRefCitedNplList = null;
        List<PatRefCitedNplCls> patRefCitedNplClsList = null;
        
        (patRefCitedList,
         patRefCitedClsList,
         patRefCitedNplList,
         patRefCitedNplClsList) = PatRefUtil.getPatRefCitedUS(biblio, patData, now);
        // patcit cls
        patRefService.savePatRefCitedAndCls(patRefCitedList, patRefCitedClsList, patData.patId, patData.defaultSourceId);
        // nplcit cls
        patRefService.savePatRefCitedNplCls(patRefCitedNplClsList, patData.patId, patData.defaultSourceId);
        // nplcit
        patRefService.savePatRefCitedNpl(patRefCitedNplList, patData.patId, patData.defaultSourceId);
        
        // pct pct-or-regional-filing-data, pct-or-regional-publishing-data
        PatRefPct patRefPct = USPatDataUtil.genPatRefPctDataXML(biblio, patData, now);
        if (!!patRefPct) {
            patRefService.savePatRefPct(patRefPct);
        }
        
        // TODO: priority-claims
        List<PatRefPriority> patRefPriorityList = USPatDataUtil.getPatRefPriorityXML(biblio, patData, now);
        patRefService.savePatRefPriority(patRefPriorityList, patData.patId, patData.defaultSourceId);
        
        // TODO: pat_ref_related_parent
        List<PatRefRelatedParent> patRefRelatedParentList = null;
        List<PatRefRelatedChild> patRefRelatedChildList = null;
        (patRefRelatedParentList, patRefRelatedChildList) = PatRefUtil.getPatRefParentChildDataUS(biblio, patData, now);
        patRefService.savePatRefRelatedParentChild(patRefRelatedParentList, patRefRelatedChildList, patData.patId, patData.defaultSourceId);
        
    }

    @Override
    public void saveOrUpdateCls() {

        PatClsService clsSvc = new PatClsService();
        // ipc
        List<PatClsIpc> patClsIpcList = USPatDataUtil.genPatClsIpcXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsIpc(patClsIpcList);

        // cpc
        List<PatClsCpc> patClsCpcList = USPatDataUtil.genPatClsCpcXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsCpc(patClsCpcList);

        // Cset
        List<PatClsCset> patClsCsetList = USPatDataUtil.getPatClsCsetXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsCset(patClsCsetList);

        // loc
        List<PatClsLoc> patClsLocList = USPatDataUtil.genPatClsLocXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsLoc(patClsLocList);

        // uspc
        List<PatClsUspc> patClsUspcList = USPatDataUtil.genPatClsUspcXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsUspc(patClsUspcList);

        // pat_cls_field_of_search
        List<PatClsFieldOfSearch> patClsFieldOfSearchList = USPatDataUtil.genPatClsFieldOfSearchXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsFieldOfSearch(patClsFieldOfSearchList);
    }
    
//    @Override
//    protected void savaOrUpdataPatPtoPidMapping(String ptopidId) throws Exception {
//        
//        PatPtopidMapping patPtopidMapping = new PatPtopidMapping();
//        patPtopidMapping.patData = patData;
//        patPtopidMapping.ptopidId = ptopidId;
//        
//        PatPtopidMappingService svc = new PatPtopidMappingService();
//        svc.saveOrUpdatePatPtopidMapping(patPtopidMapping);
//    }


    @Override
    public void saveOrUpdatePersonRelatedData() {

        // generate person related data
        List<PersonData> personDataList = new ArrayList<PersonData>();
        // PatPersonApplicant
        List<PatPersonApplicant> patPersonApplicants = USPatDataUtil.genPatPersonApplicantsXML(biblio, patData, personDataList, now);
        // PatPersonInventor
        List<PatPersonInventor> patPersonInventors = USPatDataUtil.genPatPersonInventorsXML(biblio, patData, personDataList, now);
        // PatPersonAgents
        List<PatPersonAgent> patPersonAgents = USPatDataUtil.genPatPersonAgentsXML(biblio, patData, personDataList, now);
        // PatPersonAssignee
        List<PatPersonAssignee> patPersonAssignees = USPatDataUtil.genPatPersonAssigneesXML(biblio, patData, personDataList, now);
        // examiners
        List<PatPersonExaminer> patPersonExaminers = USPatDataUtil.genPatPersonExaminersXML(biblio, patData, personDataList, now);
        // correspondence-address
        List<PatPersonCorrespondenceAddr> patPersonCorrespondenceAddrs = USPatDataUtil.genPatPersonCorrespondenceAddrsXML(biblio, patData, personDataList, now);

        PersonDataServices personSvc = new PersonDataServices();
        personSvc.saveOrUpdate(personDataList, patPersonApplicants, patPersonInventors
                , patPersonAgents, patPersonAssignees, patPersonExaminers
                , patPersonCorrespondenceAddrs);
    }
    
    @Override
    public void saveOrUpdatePatDataTitle() {
        
        List<PatDataTitle> patDataTitles = new ArrayList<PatDataTitle>();
        patDataTitles.add(genPatDataTitle());
        patSvc.saveOrUpdatePatDataTitle(patDataTitles);
    }
    
    @Override
    public void saveOrUpdatePatDataBrief() {
        List<PatDataBrief> patDataBriefs = new ArrayList<PatDataBrief>();
        patDataBriefs.add(genPatDataBrief());
        patSvc.saveOrUpdatePatDataBrief(patDataBriefs);
    }
    
    @Override
    public void saveOrUpdatePatDataClaims() {
        List<PatDataClaims> patDataClaimsList = new ArrayList<PatDataClaims>();
        patDataClaimsList.add(genPatDataClaims());
        patSvc.saveOrUpdatePatDataClaims(patDataClaimsList);
    }
    
    @Override
    public void saveOrUpdatePatDataDesc() {
        List<PatDataDesc> patDataDescList = new ArrayList<PatDataDesc>();
        patDataDescList.add(genPatDataDesc());
        patSvc.saveOrUpdatePatDataDesc(patDataDescList);
    }
    
    /**
     *
     * @param biblio
     * @return A map includes kindCode, country
     */
    private Map parsePublicationReference() {

        def pubRefData = [:]

        def pubRef = biblio."publication-reference";
        def kindCode
        def country
        if (!!pubRef) {
            kindCode = pubRef."document-id"."kind";
            country = pubRef."document-id"."country";
        } else {
            throw new Exception("publication-reference miss")
        }

        pubRefData << ["kindCode" : kindCode]
        pubRefData << ["country" : country]

        return pubRefData
    }

    /**
     *
     * @param biblio
     * @return A map includes patType, applCountry, appDate, rawAppNo, appNo, appId
     */
    private Map parseApplicationReference() {

        def appRefData = [:]

        def appRef = biblio."application-reference";
        def applType
        if (!!appRef) {
            if (appRef."appl-type") {
                applType = appRef."appl-type"[0..0].toUpperCase() + appRef."appl-type"[1..-1]
                if(applType =~ /Sir/){
                    applType = "SIR";
                }
            }
        }

        int patType = PatTypeEnum.US.findPatTypeCode(applType)

        if (patType < Constants.ZERO) {
            throw new Exception("patType error")
        } else {
            appRefData << ["patType" :  patType]
        }

        if (!!appRef['document-id']) {
            def appRefDocId = appRef."document-id"[0]

            def applCountry = appRefDocId."country"

            def applDateStr = appRefDocId."date".toString()

            def applDocNumber = appRefDocId."doc-number".toString()

            appRefData << ["rawAppNo" : applDocNumber]
            appRefData << ["appCountry" : applCountry]
            appRefData << ["appDate" : DateUtil.parseDate(applDateStr)]
            appRefData << ["appNo" : PatNumberUtil.getAppNoUS(applDocNumber)]
            appRefData << ["appId" : PatNumberUtil.getAppIdUS(applDocNumber)]
        } else {
            throw new Exception("appNumber miss");
        }

        return appRefData;
    }

    /**
     * @param doc
     * @return
     */
    private Map getRoot(def doc) {

        def root = null;
        if (doc.stat == Constants.PAT_STAT_PUBLIC) {
            root = doc.data."us-patent-application";
        } else {
            root = doc.data."us-patent-grant";
        }

        return root;
    }

    /**
     * @param stat
     * @param root
     * @return
     */
    private Map getBiblio(int stat, def root) {

        def biblio = null;
        if (stat == Constants.PAT_STAT_PUBLIC) {
            biblio = root."us-bibliographic-data-application";
        } else {
            biblio = root."us-bibliographic-data-grant";
        }

        return biblio;
    }

    public static void main(String[] args) throws Exception {

        // 測試使用
//        args = ["-b", "20101201", "-e", "20110101"];

        def cli = new CliBuilder(usage: 'USPatDataProcess.groovy -[hbe]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
            s longOpt: 'skip count', args: 1, argName: 'integer',    'skip count'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;
        def skip = (!!options.s) ? options.s.toInteger() : 0 ;

        def query = ["beginDate" : beginDate, "endDate" : endDate, "skip" : skip];
        
        new USPatDataProcessXmlImpl().queryMap(query).process();
        
        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "import new info finished", "query : $query");
        
        logger.info("query : $query, finished...");
    }

}
