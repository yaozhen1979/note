package com.patentdata.process;

import org.slf4j.LoggerFactory

import com.gmongo.GMongoClient
import com.mongodb.Bytes
import com.mongodb.DBCollection
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.model.PatData
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataBriefId
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataClaimsId
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataDescId
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.model.PatPtopidMapping
import com.patentdata.service.PatPtopidMappingService
import com.patentdata.util.DateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.MongoUtil

/**
 * @author mikelin
 *
 */
public abstract class USPatDataProcess extends BaseProcess {

    protected Date now = null;
    protected Date last = null;
    protected Integer relRawType = null;
    protected PatData patData = null;
    protected DBObject marshallDoc = null
    protected DBObject root = null;
    protected String brief = null;
    protected String claims = null;
    protected String description = null;
    protected String title = null;
    protected DBCollection oldInfoCol = null;
    protected GMongoClient client = null;
    
    public USPatDataProcess() {
        logger = LoggerFactory.getLogger(USPatDataProcess.class);
        now = new Date();
        last = now;
    }
    
    /**
     *
     * @param claims
     * @param patData
     * @return
     */
    protected PatDataClaims genPatDataClaims() {

        PatDataClaims patDataClaims = new PatDataClaims();

        // PatDataClaimsId
        PatDataClaimsId id = new PatDataClaimsId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.lang = patData.oriLang;
        patDataClaims.id = id;
        patDataClaims.claims = claims;
        patDataClaims.createDate = now;
        patDataClaims.lastUpdDate = now;

        return patDataClaims;
    }
    
    /**
     * @param brief
     * @param patData
     * @return
     */
    protected PatDataBrief genPatDataBrief() {

        PatDataBrief patDataBrief = new PatDataBrief();

        // PatDataBriefId
        PatDataBriefId id = new PatDataBriefId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.lang = patData.oriLang;
        patDataBrief.id = id;
        patDataBrief.brief = brief;
        patDataBrief.createDate = now;
        patDataBrief.lastUpdDate = now;

        return patDataBrief;
    }
    
    /**
     *
     * @param title
     * @param patData
     * @return
     */
    protected PatDataTitle genPatDataTitle() {

        PatDataTitle patDataTitle = new PatDataTitle();

        // PatDataTitleId
        PatDataTitleId id = new PatDataTitleId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.lang = patData.oriLang;
        patDataTitle.id = id;
        patDataTitle.title = title;
        patDataTitle.createDate = now;
        patDataTitle.lastUpdDate = now;

        return patDataTitle;
    }
    
    /**
     *
     * @param description
     * @param patData
     * @return
     */
    protected PatDataDesc genPatDataDesc() {

        PatDataDesc patDataDesc = new PatDataDesc();

        // PatDataDescId
        PatDataDescId id = new PatDataDescId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.lang = patData.oriLang;
        patDataDesc.id = id;
        patDataDesc.description = description;
        patDataDesc.createDate = now;
        patDataDesc.lastUpdDate = now;

        return patDataDesc;
    }
    
    /**
     * 資料查詢
     * @return
     * @throws Exception
     */
    @Override
    DBCursor queryData() throws Exception {

        def client2x = MongoUtil.connect121DB();
        oldInfoCol = client2x.getDB("PatentInfoUSPTO").getCollection("PatentInfoUSPTO");
        
        println "queryMap : $queryMap"
        client = MongoUtil.connectByConfig("US");
        // marshall
        def marshallCol = client.getDB("PatentMarshallUS").getCollection("PatentMarshallUS");
        
        def dateBegin = DateUtil.parseDate(queryMap.beginDate);
        def dateEnd = DateUtil.parseDate(queryMap.endDate);
        
        def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];
        // def query = ['_id' : "7675119"];
        DBCursor cursor = marshallCol.find(query).sort([doDate:1]).limit(0).skip(queryMap.skip).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        return cursor;
    }

    @Override
    void processData(DBObject doc) throws Exception {

    }
    
    // AppData
    protected abstract void saveOrUpdateAppData() throws Exception;
    // PatData
    protected abstract void saveOrUpdatePatData() throws Exception;
    // PatRawUs
    protected abstract void saveOrUpdatePatRawUs() throws Exception;
    // PersonRelatedData
    protected abstract void saveOrUpdatePersonRelatedData() throws Exception;
    // title
    protected abstract void saveOrUpdatePatDataTitle() throws Exception;
    // brief
    protected abstract void saveOrUpdatePatDataBrief() throws Exception;
    // claims
    protected abstract void saveOrUpdatePatDataClaims() throws Exception;
    // description
    protected abstract void saveOrUpdatePatDataDesc() throws Exception;
    // cls...
    protected abstract void saveOrUpdateCls() throws Exception;
    // pat_ref_cited
    protected abstract void saveOrUpdatePatRefCited() throws Exception;

//    protected abstract void savaOrUpdataPatPtoPidMapping(String ptopidId) throws Exception;
    // pat_ptopid_mapping
    protected void savaOrUpdataPatPtoPidMapping(String ptopidId) throws Exception {
        
        PatPtopidMapping patPtopidMapping = new PatPtopidMapping();
        patPtopidMapping.patData = patData;
        patPtopidMapping.ptopidId = ptopidId;
        
//        println "patPtopidMapping : $patPtopidMapping.ptopidId";
        PatPtopidMappingService svc = new PatPtopidMappingService();
        svc.saveOrUpdatePatPtopidMapping(patPtopidMapping);
    }
    
    /**
     *
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    @Override
    void processFailData(DBObject data, String message) throws Exception {
        
        logger.info("import new info error : " + message);
        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "import new info error", "message : " + message);
    }

}