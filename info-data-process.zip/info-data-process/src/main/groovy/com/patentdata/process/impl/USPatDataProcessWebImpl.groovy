package com.patentdata.process.impl

import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory

import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.common.RelRawTypeEnum
import com.patentdata.helper.AppDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsFieldOfSearch
import com.patentdata.model.PatClsFieldOfSearchId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsLoc
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatData
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonAssignee
import com.patentdata.model.PatPersonCorrespondenceAddr
import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PatRawUs
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefRelatedChild
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PatRefRelatedParentId
import com.patentdata.model.PersonData
import com.patentdata.process.USPatDataProcess
import com.patentdata.service.AppDataService
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataLogService
import com.patentdata.service.PatDataService
import com.patentdata.service.PatRawService
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.DateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.PatRefUtil
import com.patentdata.util.USPatDataUtil

class USPatDataProcessWebImpl extends USPatDataProcess {
    
    public USPatDataProcessXmlImpl() {
        logger = LoggerFactory.getLogger(USPatDataProcessWebImpl.class);
    }
    
    private PatDataService patSvc = new PatDataService();
    private AppData appData = null;
    private DBObject patFtDoc = null;
    
    @Override
    public void processData(DBObject doc) throws Exception {
        
        marshallDoc = doc;
        relRawType = RelRawTypeEnum.US.XML.findRelRawTypeCode(marshallDoc.relRawType);
        
        if (relRawType == Constants.US_REL_RAW_TYPE_HTML_CODE) {
            
            root = doc.data;
            
            if (StringUtils.isBlank(root.applicationNo)) {
                logger.warn "marshall id : " + doc._id + ", root.applicationNo is null ";
                new PatDataLogService().writeError("US", doc._id, "", doc.doDate, Constants.LOG_TYPE_ERROR, "DA-05", "rel_raw_type為HTML之資料,使用APP_NO是否存在,判斷為withdraw資料,withdraw不寫入pat_data", doc._id, null);
                return;
           }
            
            brief = (!!root."abstractt") ? root."abstractt"  : "";
            claims = root."claims";
            description = root."description";
            title = root."title";
            
            //
            if (doc.stat == 2) {
                def patFtCol = client.getDB("PatentRawUSPTO").getCollection("PatFT");
                patFtDoc = patFtCol.findOne(["_id" : marshallDoc._id]);
            }
            
            // 
            saveOrUpdateAppData();
            
            String oldPatNo = PatNumberUtil.getMappingPatentNumberUS(marshallDoc.stat, marshallDoc._id);
            DBObject oldInfoDoc = oldInfoCol.findOne(["patentNumber" : oldPatNo]);
            
            //
            patData = USPatDataUtil.genPatDataHTML(oldInfoDoc, doc, root, appData, patFtDoc, now);
            // PatData
            saveOrUpdatePatData();
            
            // PatPtoPidMapping
            savaOrUpdataPatPtoPidMapping(oldInfoDoc._id.toString());
            
            // PatRawUs
            saveOrUpdatePatRawUs();
            
            // 
            saveOrUpdatePersonRelatedData();
            
            // title
            saveOrUpdatePatDataTitle();
            
            // brief
            if (!!brief) {
                saveOrUpdatePatDataBrief();
            }
            
            // claims
            saveOrUpdatePatDataClaims();
            
            // description
            if (!!description) {
                saveOrUpdatePatDataDesc();
            }
            // cls...
            saveOrUpdateCls();
            
            // 
            saveOrUpdatePatRefCited();
            
        } else if (relRawType == Constants.US_REL_RAW_TYPE_XML_CODE) {
            throw new Exception("wrong relRawType");
        }
    }
    

    @Override
    protected void saveOrUpdateAppData() throws Exception {
        // generate AppData
        appData = new AppData();
        appData.appNo = root.applicationNo;
        appData.appId = PatNumberUtil.getAppIdUS(appData.appNo.replaceAll("/", ""));
        appData.country = "US";
        if (!!patFtDoc && patFtDoc."combineAsg" && !!patFtDoc."appDateAsg") {
            appData.appDate = patFtDoc."appDateAsg";
        } else {
            appData.appDate = DateUtil.parseDate(root.applicationDate);
        }
        
        appData.appLang = Constants.US_LANG;
        appData.createDate = now;
        appData.lastUpdDate = now;
        AppDataService appSvc = new AppDataService();
        appSvc.saveOrUpdateAppData(appData);
    }

    @Override
    protected void saveOrUpdatePatData() throws Exception {
        patSvc.saveOrUpdatePatData(patData);
    }

    @Override
    protected void saveOrUpdatePatRawUs() throws Exception {
        PatRawUs patRawUs = USPatDataUtil.genPatRawUsDataHTML(marshallDoc, patData, relRawType, now);
        PatRawService patRawSvc = new PatRawService();
        patRawSvc.saveOrUpdatePatRawUs(patRawUs);
    }

    @Override
    protected void saveOrUpdatePersonRelatedData() throws Exception {
        // generate person related data
        List<PersonData> personDataList = new ArrayList<PersonData>();
        // TODO: PatPersonApplicant 網頁沒有applicants??
        List<PatPersonApplicant> patPersonApplicants = null;
        // PatPersonInventor 
        List<PatPersonInventor> patPersonInventors = USPatDataUtil.genPatPersonInventorsHTML(root, patData, personDataList, now);
        // PatPersonAgents
        List<PatPersonAgent> patPersonAgents = USPatDataUtil.genPatPersonAgentsHTML(root, patData, personDataList, now);
        // PatPersonAssignee
        List<PatPersonAssignee> patPersonAssignees = USPatDataUtil.genPatPersonAssigneesHTML(root, patData, personDataList, now);
        // examiners
        List<PatPersonExaminer> patPersonExaminers = USPatDataUtil.genPatPersonExaminersHTML(root, patData, personDataList, now);
        // correspondence-address
        List<PatPersonCorrespondenceAddr> patPersonCorrespondenceAddrs = USPatDataUtil.genPatPersonCorrespondenceAddrsHTML(root, patData, personDataList, now);
        PersonDataServices personSvc = new PersonDataServices();
        personSvc.saveOrUpdate(personDataList, patPersonApplicants, patPersonInventors
                , patPersonAgents, patPersonAssignees, patPersonExaminers
                , patPersonCorrespondenceAddrs);
                

    }

    @Override
    protected void saveOrUpdatePatDataTitle() throws Exception {
        List<PatDataTitle> patDataTitles = new ArrayList<PatDataTitle>();
        patDataTitles.add(genPatDataTitle());
        patSvc.saveOrUpdatePatDataTitle(patDataTitles);
        
    }
    
    @Override
    protected void saveOrUpdatePatDataBrief() throws Exception {
        List<PatDataBrief> patDataBriefs = new ArrayList<PatDataBrief>();
        patDataBriefs.add(genPatDataBrief());
        patSvc.saveOrUpdatePatDataBrief(patDataBriefs);

    }
    

    @Override
    protected void saveOrUpdatePatDataClaims() throws Exception {
        List<PatDataClaims> patDataClaimsList = new ArrayList<PatDataClaims>();
        patDataClaimsList.add(genPatDataClaims());
        patSvc.saveOrUpdatePatDataClaims(patDataClaimsList);
    }

    @Override
    protected void saveOrUpdatePatDataDesc() throws Exception {
        List<PatDataDesc> patDataDescList = new ArrayList<PatDataDesc>();
        patDataDescList.add(genPatDataDesc());
        patSvc.saveOrUpdatePatDataDesc(patDataDescList);
    }

    @Override
    protected void saveOrUpdateCls() throws Exception {
        
        // ipc
        List<PatClsIpc> patClsIpcList = null;
        // cpc
        List<PatClsCpc> patClsCpcList = null;
        // loc
        List<PatClsLoc> patClsLocList = null;
        // uspc
        List<PatClsUspc> patClsUspcList = null;
        // pat_cls_field_of_search
        List<PatClsFieldOfSearch> patClsFieldOfSearchList = null;
        
        // patentClassCodes
        if (!!root."patentClassCodes") {
            
            root."patentClassCodes".each { clsData ->
                
                // CLASSIFICATION_IPC = 1 or CLASSIFICATION_IPC8 = 2
                if (clsData.type == 1 || clsData.type == 2) {
                    if (!patClsIpcList) {
                        patClsIpcList = new ArrayList<>();
                    }
                    
                    String version = "";
                    if (!!clsData.version) {
                        version = clsData.version;
                    }
                    
                    int rawMainFlag = clsData.pos == 0 ? Constants.CLS_IPC_MAIN_FLAG_YES : Constants.CLS_IPC_MAIN_FLAG_NO;
                    PatClsIpc patClsIpc = USPatDataUtil.genPatClsIpcHTML(patData, clsData.classNo, version, rawMainFlag, clsData.pos + 1, now);
                    
                    patClsIpcList.add(patClsIpc);
                }
                
                // CLASSIFICATION_UPC = 10
                if (clsData.type == 10) {
                    
                    if (!patClsUspcList) {
                        patClsUspcList = new ArrayList<>();
                    }
                    int rawMainFlag = clsData.main ? Constants.CLS_USPC_MAIN_FLAG_YES : Constants.CLS_USPC_MAIN_FLAG_NO;
                    PatClsUspc patClsUspc = USPatDataUtil.genPatClsUspcHTML(patData, clsData.classNo, rawMainFlag, clsData.pos + 1, now);
                    patClsUspcList.add(patClsUspc);
                }
                
                // CLASSIFICATION_LOC = 3
                if (clsData.type == 3) {
                    if (!patClsLocList) {
                        patClsLocList = new ArrayList<>();
                    }
                    
                    int rawMainFlag = clsData.pos == 0 ? Constants.CLS_LOC_MAIN_FLAG_YES : Constants.CLS_LOC_MAIN_FLAG_NO;
                    PatClsLoc patClsLoc = USPatDataUtil.genPatClsLocHTML(patData, clsData.classNo, clsData.classId, rawMainFlag, clsData.pos + 1, now);
                    patClsLocList.add(patClsLoc);
                }
                
                // CLASSIFICATION_CPC = 4
                if (clsData.type == 4) {
                    
                    if (!patClsCpcList) {
                        patClsCpcList = new ArrayList<>();
                    }
                    int rawMainFlag = clsData.pos == 0 ? Constants.CLS_CPC_MAIN_FLAG_YES : Constants.CLS_CPC_MAIN_FLAG_NO;
                    String version = "";
                    if (!!clsData.version) {
                        version = clsData.version;
                    }
                    PatClsCpc patClsCpc = USPatDataUtil.genPatClsCpcHTML(patData, clsData.classNo, version, rawMainFlag, clsData.pos + 1, now);
                    patClsCpcList.add(patClsCpc);
                }
                
                
                // TODO: CLASSIFICATION_UPC_AT_PUBLICATION = 11 暫時不處理，目前還是用Current U.S. Class為主 
                if (clsData.type == 11) {
//                    throw new Exception("CLASSIFICATION_UPC_AT_PUBLICATION");
                }
            }
        }
        // patentClassCodeAppends
        if (!!root."patentClassCodeAppends") {
            // TODO:
        }
        
        // fieldOfSearch
        if (!!root."fieldOfSearch") {
            patClsFieldOfSearchList = new ArrayList<PatClsFieldOfSearch>();
            int item = 0;
            
            root."fieldOfSearch".split(";").each {fieldOfSearch ->
                if (!!fieldOfSearch) {
                    String classType = "UNKNOW";
                    int defectFlag = Constants.CLS_DEFECT_FLAG_FALSE;
                    if (fieldOfSearch.split(",").size() > 1) {
                        // multiple cls
                        String[] arry = fieldOfSearch.split(",");
                        
                        String firstCls = "";
                        for (int i=0; i < arry.size(); i++) {
                            String classText = "";
                            item++;
                            if (i == 0) {
                                firstCls = classText = arry[i];
                                if (firstCls =~ /(?i)[A-Z]*[0-9]+\/[A-Z0-9]+/) {
                                    classType = "USPC";
                                } else if (firstCls =~ /(?i)([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})?\/?([0-9]{1,6})/) {
                                    // 
                                    classType = "IPC";
                                    throw new Exception("fieldOfSearch ipc appear");
                                }
                            } else {
                                if (classType == "USPC") {
                                    classText = StringUtils.substringBefore(firstCls, "/") + "/" + arry[i];
                                } else if (classType == "IPC") {
                                    throw new Exception("fieldOfSearch ipc appear");
                                }
                            }
                            
                            PatClsFieldOfSearch patClsFieldOfSearch = genFieldOfSearchHTMLUS(patData, item, classText, classType, defectFlag, now);
                            patClsFieldOfSearchList.add(patClsFieldOfSearch);
                        }
                        
                        
                    } else {
                        // single cls
                        item++;
                        if (fieldOfSearch =~ /(?i)[A-Z]*[0-9]+\/[A-Z0-9]+/) {
                            classType = "USPC";
                        } else if (fieldOfSearch =~ /(?i)([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})?\/?([0-9]{1,6})/) {
                            classType = "IPC";
                            throw new Exception("fieldOfSearch ipc appear");
                        }
                        PatClsFieldOfSearch patClsFieldOfSearch = genFieldOfSearchHTMLUS(patData, item, fieldOfSearch, classType, defectFlag, now);
                        if (!patClsFieldOfSearch.classText) {
                            throw new Exception("patClsFieldOfSearch.classText is null");
                        }
                        patClsFieldOfSearchList.add(patClsFieldOfSearch);
                    }
                }
            }
        }
        
        PatClsService clsSvc = new PatClsService();
        
        if (!!patClsIpcList) {
            clsSvc.saveOrUpdatePatClsIpc(patClsIpcList);
        }
        
        if (!!patClsUspcList) {
            clsSvc.saveOrUpdatePatClsUspc(patClsUspcList);
        }
        
        if (!!patClsLocList) {
            clsSvc.saveOrUpdatePatClsLoc(patClsLocList);
        }
        
        if (!!patClsCpcList) {
            clsSvc.saveOrUpdatePatClsCpc(patClsCpcList);
        }
        
        if (!!patClsFieldOfSearchList) {
            clsSvc.saveOrUpdatePatClsFieldOfSearch(patClsFieldOfSearchList);
        }
    }
    
    /**
     * @param patData
     * @param item
     * @param classText
     * @param classType
     * @param defectFlag
     * @param now
     * @return
     */
    public static PatClsFieldOfSearch genFieldOfSearchHTMLUS(PatData patData, int item, String classText, String classType, int defectFlag, Date now) {
        
        PatClsFieldOfSearchId id = new PatClsFieldOfSearchId();
        id.patId = patData.patId;
        id.sourceId = patData.defaultSourceId;
        id.item = item;

        PatClsFieldOfSearch patClsFieldOfSearch = new PatClsFieldOfSearch();
        patClsFieldOfSearch.id = id;

        patClsFieldOfSearch.classType = classType;
        patClsFieldOfSearch.classText = classText;
        patClsFieldOfSearch.defectFlag = defectFlag;
        patClsFieldOfSearch.createDate = now;
        
        return patClsFieldOfSearch;
    }
    
    @Override
    protected void saveOrUpdatePatRefCited() throws Exception {
        PatRefService patRefService = new PatRefService();
        
        // patcit
        List<PatRefCited> patRefCitedList = PatRefUtil.genPatRefCitedHTMLUS(root, patData, now);
        patRefService.savePatRefCitedAndCls(patRefCitedList, null, patData.patId, patData.defaultSourceId);
        
        // nplcit
        List<PatRefCitedNpl> patRefCitedNplList = PatRefUtil.genPatRefCitedNplHTMLUS(root, patData, now);
        patRefService.savePatRefCitedNpl(patRefCitedNplList, patData.patId, patData.defaultSourceId);
        
        // pct pct-or-regional-filing-data, pct-or-regional-publishing-data
        PatRefPct patRefPct = USPatDataUtil.genPatRefPctDataHTML(root, patData, now);
        if (!!patRefPct) {
            patRefService.savePatRefPct(patRefPct);
        }
        
        // priority-claims
        List<PatRefPriority> patRefPriorityList = USPatDataUtil.getPatRefPriorityHTML(root, patData, now);
        patRefService.savePatRefPriority(patRefPriorityList, patData.patId, patData.defaultSourceId);
        
        // TODO: pat_ref_related_parent
        
//        List<PatRefRelatedParent> patRefRelatedParentList = getPatRefParentChildDataUSWeb(root, patData, now);
//        (patRefRelatedParentList, patRefRelatedChildList) = PatRefUtil.getPatRefParentChildDataUSWeb(biblio, patData, now);
//        patRefService.savePatRefRelatedParentChild(patRefRelatedParentList, null, patData.patId, patData.defaultSourceId);
        
        
    }
    
    public static getPatRefParentChildDataUSWeb(def root, PatData patData, Date now) {
        
        List<PatRefRelatedParent> patRefRelatedParentList = new ArrayList<>();
//        List<PatRefRelatedChild> patRefRelatedChildList = new ArrayList<>();
        
        int relatedType = Constants.RELATED_TYPE_CODE_UNKNOW;
        int parentItem = Constants.ZERO;
        
        if (!!root."relatedUSPatentDocs") {
            root."relatedUSPatentDocs".each {parentDoc ->
                
                PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent();
                patRefRelatedParent.createDate = now;
                patRefRelatedParent.relatedType = relatedType;
        
                PatRefRelatedParentId patRefRelatedParentId = new PatRefRelatedParentId();
                patRefRelatedParentId.patId = patData.patId;
                patRefRelatedParentId.sourceId = patData.defaultSourceId;
                patRefRelatedParentId.item = ++parentItem;
                patRefRelatedParent.id = patRefRelatedParentId;
        
                patRefRelatedParent.rawAppNo = parentDoc."applicationNo";
//                patRefRelatedParent.appCountry = null;
                if (!!parentDoc."filingDate") {
                    patRefRelatedParent.rawAppDate = parentDoc."filingDate";
                    patRefRelatedParent.appDate = DateUtil.parseDate(patRefRelatedParent.rawAppDate);
                }
                
                // appNO
                if (patRefRelatedParent.rawAppNo =~ /\d{8}/ || patRefRelatedParent.rawAppNo =~ /D\d{6}/
                || patRefRelatedParent.rawAppNo =~ /[0-9]{2}\/[0-9]{3}\,?[0-9]{3}/) {
        
                    patRefRelatedParent.appNo = PatNumberUtil.getAppNoUS(patRefRelatedParent.rawAppNo);
                } else if (patRefRelatedParent.rawAppNo =~ /(?i)PCT.*/){
                    // TODO:
                    patRefRelatedParent.appNo = patRefRelatedParent.rawAppNo;
                } else {
                    patRefRelatedParent.appNo = patRefRelatedParent.rawAppNo;
                    println "error : PatRefRelatedParent appNo does not format, rawAppNo : $patRefRelatedParent.rawAppNo, country: $docMap.country";
                }
                
                
                
                /*
                 * 
            doc.setPatentNo(patentNo);
            doc.setIssueDate(issueDate);
                
                
                if (!!parentDoc."patentNo") {
                    
                }
                patRefRelatedParent.rawDocDate = parentGrantDocMap.rawDate;
                patRefRelatedParent.docDate = parentGrantDocMap.date;
                patRefRelatedParent.kindCode = parentGrantDocMap.kindCode;
                patRefRelatedParent.inventorName = parentGrantDocMap.name;
                patRefRelatedParent.docCountry = parentGrantDocMap.country;
                 */
                // TODO: 網頁沒有Country
                /*
                List<AppData> appDataList = AppDataHelper.queryByCondition(docMap.country, patRefRelatedParent.appNo);
                if (!!appDataList) {
                    if (appDataList.size() > 1) {
                        throw new Exception("PatRefRelatedParent AppData query over 1...");
                    }
                    patRefRelatedParent.parentAppId = appDataList.get(0).appId;
                }
                */
                
            }
        }
        
//        return [patRefRelatedParentList, patRefRelatedChildList];
        return patRefRelatedParentList;
    }
    
    public static void main(String[] args) throws Exception {

        // 測試使用
//                args = ["-b", "19770101", "-e", "19770115"];
        def cli = new CliBuilder(usage: 'USPatDataProcess.groovy -[hbe]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
            s longOpt: 'skip count', args: 1, argName: 'integer',    'skip count'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;
        def skip = (!!options.s) ? options.s.toInteger() : 0 ;

        def query = ["beginDate" : beginDate, "endDate" : endDate, "skip" : skip];

        new USPatDataProcessWebImpl().queryMap(query).process();

        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "import new info finished", "query : $query");
        
        logger.info("query : $query, finished...");
    }

}
