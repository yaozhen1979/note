package com.patentdata.process;

import java.io.Serializable;
import java.util.Date
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gmongo.GMongoClient;
import com.mongodb.Bytes;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import com.patentdata.service.AppDataService;
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataService;
import com.patentdata.service.PatRawService;
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.MongoUtil;
import com.patentdata.util.CountryUtil;
import com.patentdata.util.DocdbKindCodeUtil;
import com.patentdata.util.PatNumberUtil;
import com.patentdata.util.DateUtil;
import com.patentdata.util.JSONUtil;
import com.patentdata.util.UUIDUtil;
import com.patentdata.util.StringUtil;
import com.patentdata.util.PatClsUtil;
import com.patentdata.util.PatRefUtil;
import com.patentdata.util.DocdbDoDateUtil;
import com.patentdata.util.QueryUtil;
import com.patentdata.util.MailUtil;

import org.apache.commons.lang3.StringUtils;

import com.patentdata.common.PatTypeEnum;
import com.patentdata.common.Constants;
import com.patentdata.exception.JsonFormatException;
import com.patentdata.model.AppData;
import com.patentdata.model.PatClsCpc;
import com.patentdata.model.PatClsCset;
import com.patentdata.model.PatClsIpc;
import com.patentdata.model.PatClsIpcId;
import com.patentdata.model.PatClsUspc
import com.patentdata.model.PatData;
import com.patentdata.model.PatDataBrief;
import com.patentdata.model.PatDataBriefId;
import com.patentdata.model.PatDataTitle;
import com.patentdata.model.PatDataTitleId;
import com.patentdata.model.PatPersonApplicant;
import com.patentdata.model.PatPersonApplicantId;
import com.patentdata.model.PatPersonInventor;
import com.patentdata.model.PatPersonInventorId;
import com.patentdata.model.PatRawDocdb;
import com.patentdata.model.PatRefCited;
import com.patentdata.model.PatRefCitedCls
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefCitedNplCls
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PersonData;

import com.patentdata.helper.PatDataHelper;
import com.patentdata.helper.PersonDataHelper;

/**
 * 
 * @author tonykuo
 *
 */
public class DOCDBPatDataProcess extends BaseProcess {
    
    DOCDBPatDataProcess() {
        logger = LoggerFactory.getLogger(DOCDBPatDataProcess.class);
    }
    
    private static GMongoClient dbClient = MongoUtil.connectByConfig("DOCDB");
    private static DB marshallDB = dbClient.getDB("PatentMarshallDOCDB");
    
    @Override
    DBCursor queryData() throws Exception {
        
        String cc = null;
        if (!!queryMap) {
            cc = queryMap.country;
        } else {
            throw new Exception("error = queryMap is empty")
        }
        
        DBCollection marshallCol = marshallDB.getCollection("PatentMarshall" + cc);
        // TODO: find limit
        DBCursor queryCursor = marshallCol.find(queryMap.query).limit(0).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
        
        return queryCursor;
    }
    
    @Override
    void processData(DBObject data) throws Exception {

        logger.debug "data._id = ${data._id}";
        
        if (data._id.contains("null")) {
            
            String cc = data.country;
            DBObject dbObject = marshallDB.getCollection("ErrorPatentMarshall${cc}").findOne(["_id": data._id]);
            
            logger.info "data._id = ${data._id} contains null, remove data from PatentMarshall${cc} and save data to ErrorPatentMarshall${cc}.";
            
            marshallDB.getCollection("ErrorPatentMarshall${cc}").save(data);
            marshallDB.getCollection("PatentMarshall" + cc).remove(["_id": data._id]);
            
        } else {
            
            AppData appData = genAppData(data);
            AppDataService appDataService = new AppDataService();
            appDataService.saveOrUpdateAppData(appData);
            
            PatData patData = genPatData(data);
            
            /*
             *  1. 再這先處理[patData], 是為了先取得patData.patId, 來處理PatRawDocdb data.
             *  2. 而在處理完[patRawService.saveOrUpdatePatRawDocdb]所取得的[patRawDocdb.lastestFlag],
             *     來帶入[patDataService.saveOrUpdatePatDataDOCDB]來對[PatEventRecordChangeLog]判斷
             *
             */
            PatRawDocdb patRawDocdb = getPatRawDocdb(data, patData);
            PatRawService patRawService = new PatRawService();
            patRawDocdb = patRawService.saveOrUpdatePatRawDocdb(patRawDocdb);
            //
            PatDataService patDataService = new PatDataService();
            patDataService.saveOrUpdatePatDataDOCDB(patData, patRawDocdb.lastestFlag);
            
            // person_data => // DOCDB-201516-Amend-PubDate20150410AndBefore-DE-0003.xml/314389878 有<address> tag
            genPatPersonInfo(data, patData);
            
            // pat_data_brief
            List<PatDataBrief> patDataBriefList = getPatDataBrief(data, patData);
            // println "patDataBriefList = ${patDataBriefList}"
            patDataService.saveOrUpdatePatDataBrief(patDataBriefList)
            
            // pat_data_title
            List<PatDataTitle> patDataTitleList = getPatDataTitle(data, patData);
            // println "patDataTitleList = ${patDataTitleList}"
            patDataService.saveOrUpdatePatDataTitle(patDataTitleList)
            
            // pat_data_cls
            PatClsService patClsService = new PatClsService();
            // ipc and ipcr
            List<PatClsIpc>  patClsIpcList = genPatClsIpc(data, patData)
            patClsService.saveOrUpdatePatClsIpc(patClsIpcList);
            // cpc
            List<PatClsCpc> patClsCpcList = genPatClsCpc(data, patData);
            patClsService.saveOrUpdatePatClsCpc(patClsCpcList);
            
            // cset
            List<PatClsCset> patClsCsetList = genPatClsCset(data, patData);
            patClsService.saveOrUpdatePatClsCset(patClsCsetList);
            
            /*
             * only for uspc, 但在[SE]也會有"classification-national", 所以特別以國別來判斷.
             */
            if (data.country == "US") {
                List<PatClsUspc> patClsUspcList = genPatClsUspc(data, patData);
                patClsService.saveOrUpdatePatClsUspc(patClsUspcList);
            }
            
            // TODO: fi
            // TODO: fterm
            // <林芷欣> [2016/03/10 15:48]
            // "patentNumber" : "H072848", country:"JP" -->ipc linked-indexing-code-group
            
            // 最新一筆資料判斷 ???
            logger.debug "patRawDocdb.lastestFlag = ${patRawDocdb.lastestFlag}"
            if (patRawDocdb.lastestFlag == Constants.DOCDB_LASTEST_FLAG_YES) {
                
                PatRefService patRefService = new PatRefService();
                
                List<PatRefCited> patRefCitedList = genPatRefCited(data, patData);
                patRefService.savePatRefCited(patRefCitedList, patData.patId, Constants.SOURCE_ID_DOCDB_BRIEF);
                
                List<PatRefCitedCls> patRefCitedClsList = genPatRefCitedCls(data, patData);  // 2016.02.25 目前無資料
                
                List<PatRefCitedNpl> patRefCitedNplList = genPatRefCitedNpl(data, patData);
                patRefService.savePatRefCitedNpl(patRefCitedNplList, patData.patId, Constants.SOURCE_ID_DOCDB_BRIEF);
                
                List<PatRefCitedNplCls> patRefCitedNplClsList = genPatRefCitedNplCls(data, patData);  // 2016.02.25 目前無資料
                
                // pat_data_pct, docdb 沒有
                
                // pat_ref_priority
                List<PatRefPriority> patRefPriorityList = genPatRefPriority(data, patData);
                patRefService.savePatRefPriority(patRefPriorityList, patData.patId, Constants.SOURCE_ID_DOCDB_BRIEF);
                
            }   // end if (patRawDocdb.lastestFlag == Constants.DOCDB_LASTEST_FLAG_YES)
            
            // TODO: pat_ptopid_mapping
            
            // TODO: record mongodb flag ???
        
        }   // end if (data._id.contains("null"))
        
    }   // end processData

    @Override
    void processFailData(DBObject data, String message) throws Exception {
        // TODO Auto-generated method stub
        logger.error("processFailData, todo...");
        MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "DOCDBPatDataProcess Exception", message);
    }
    
    /**
     *
     * @param data
     * @param patData
     * @return
     */
    public List<PatRefPriority> genPatRefPriority(DBObject data, PatData patData) {
        
        List<PatRefPriority> patRefPriorityList = null;
        DBObject biblio = getBiblio(data);
        DBObject priorityClaims = biblio."priority-claims"
        
        if (!!priorityClaims) {
            patRefPriorityList = new ArrayList<PatRefPriority>();
            //
            priorityClaims."priority-claim".each { it -> 
                // println "priority-claim = ${it}"
                if (it."data-format" == "docdb") {
                    PatRefPriority patRefPriority = PatRefUtil.getDocdbRefPriority(patData, it);
                    patRefPriorityList.add(patRefPriority);
                }
            }
        }
        
        return patRefPriorityList;
        
    }   // end genPatRefPriority
    
    /**
     *
     * 非專利資料引證分類檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證分類資料,若資料源有更新,則全部刪除再重新新增
     * => 等有相關範例資料時, 再來實作...
     *
     * @param data
     * @param patData
     * @return
     */
    public List<PatRefCitedNplCls> genPatRefCitedNplCls(DBObject data, PatData patData) {
        
        List<PatRefCitedNplCls> patRefCitedList = null;
        DBObject biblio = getBiblio(data);
        DBObject referencesCited = biblio."references-cited"
        
        if (!!referencesCited) {
            patRefCitedList = new ArrayList<PatRefCited>();
            referencesCited.each { citations ->
                citations."citation".each { it ->
                    // println it."cited-phase"
                    if (!!it."nplcit") {
                        if (it."classification-ipc") {
                            throw new Exception("PatRefCitedNplCls classification-ipc data find...");
                        }
                        if (it."classification-ipcr") {
                            throw new Exception("PatRefCitedNplCls classification-ipcr data find...");
                        }
                        if (it."classification-national") {
                            throw new Exception("PatRefCitedNplCls classification-national data find...");
                        }
                    }
                }
            }
        }
        
        return null;
        
    }   // end genPatRefCitedNplCls
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatRefCitedNpl> genPatRefCitedNpl(DBObject data, PatData patData) {
        
        List<PatRefCitedNpl> patRefCitedNplList = null;
        DBObject biblio = getBiblio(data);
        DBObject referencesCited = biblio."references-cited"
        
        if (!!referencesCited) {
            patRefCitedNplList = new ArrayList<PatRefCited>();
            int item = 1;
            referencesCited.each { citations ->
                citations."citation".each { it ->
                    // println it."cited-phase"
                    if (!!it.nplcit && it."nplcit"."text".toUpperCase() != "NONE") {
                        PatRefCitedNpl patRefCitedNpl = PatRefUtil.getDocdbRefCitedNpl(patData, it, item++);
                        patRefCitedNplList.add(patRefCitedNpl);
                    }
                }
            }
        }
        
        return patRefCitedNplList;
        
    }   // end genPatRefCitedNpl
    
    /**
     * 
     * 專利資料引證分類檔,依資料提供的順序依序寫入,紀錄各資料源所提供的最新的一份引證分類資料,若資料源有更新,則全部刪除再重新新增
     * => 等有相關範例資料時, 再來實作...
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatRefCitedCls> genPatRefCitedCls(DBObject data, PatData patData) {
        
        List<PatRefCitedCls> patRefCitedList = null;
        DBObject biblio = getBiblio(data);
        DBObject referencesCited = biblio."references-cited"
        
        if (!!referencesCited) {
            patRefCitedList = new ArrayList<PatRefCited>();
            referencesCited.each { citations ->
                citations."citation".each { it ->
                    // println it."cited-phase"
                    if (!!it."patcit") {
                        if (it."classification-ipc") {
                            throw new Exception("PatRefCitedCls classification-ipc data find...");
                        }
                        if (it."classification-ipcr") {
                            throw new Exception("PatRefCitedCls classification-ipcr data find...");
                        }
                        if (it."classification-national") {
                            throw new Exception("PatRefCitedCls classification-national data find...");
                        }
                    }
                }
            }
        }
        
        return null;
        
    }   // end genPatRefCitedCls
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatRefCited> genPatRefCited(DBObject data, PatData patData) {
        
        List<PatRefCited> patRefCitedList = null;
        DBObject biblio = getBiblio(data);
        DBObject referencesCited = biblio."references-cited"
        
        if (!!referencesCited) {
            
            patRefCitedList = new ArrayList<PatRefCited>();
            int item = 1;
            referencesCited.each { citations -> 
                citations."citation".each { it -> 
                    // println it."cited-phase"
                    if (!!it."patcit") {
                        PatRefCited ptRefCited = PatRefUtil.getDocdbRefCited(patData, it, item++);
                        patRefCitedList.add(ptRefCited);
                    }
                }
            }
            
        }
        
        return patRefCitedList;
        
    }   // end genPatRefCited
    
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatClsUspc> genPatClsUspc(DBObject data, PatData patData) {
        
        List<PatClsUspc> patClsUspcList = null;
        DBObject biblio = getBiblio(data);
        DBObject uspcDBObject = biblio."classification-national"?."text"
        
        if (!!uspcDBObject) {
            patClsUspcList = new ArrayList<PatClsCset>();
            uspcDBObject.eachWithIndex { uspc, index->
                // 
                PatClsUspc patClsUspc = PatClsUtil.getDocdbUspc(patData, uspc, index);
                patClsUspcList.add(patClsUspc);
            }
        }
        
        return patClsUspcList;
    }
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatClsCset> genPatClsCset(DBObject data, PatData patData) {
        
        List<PatClsCset> patClsCsetList = null;
        DBObject biblio = getBiblio(data);
        DBObject csetDBObject = biblio."patent-classifications"?."combination-set"
        
        if (!!csetDBObject) {
            patClsCsetList = new ArrayList<PatClsCset>();
            csetDBObject.each { cset-> 
                cset."combination-rank".each { crank -> 
                    // println "crank = ${crank}"
                    PatClsCset patClsCset = PatClsUtil.getDocdbCset(patData, crank, cset."group-number");
                    patClsCsetList.add(patClsCset);
                }
            }
        }
        
        return patClsCsetList;
    }
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatClsIpc> genPatClsCpc(DBObject data, PatData patData) {
        
        List<PatClsCpc> patClsCpcList = new ArrayList<PatClsCpc>();
        DBObject biblio = getBiblio(data);
        
        DBObject cpcDBObject = biblio."patent-classifications"?."patent-classification"
        if (!!cpcDBObject) {
            
            cpcDBObject.eachWithIndex { cpc, index ->
                // println "cpc = " + cpc
                PatClsCpc patClsCpc = PatClsUtil.getDocdbCpc(patData, cpc);
                patClsCpcList.add(patClsCpc);
            }
            
        }
        
        return patClsCpcList;
    }
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatClsIpc> genPatClsIpc(DBObject data, PatData patData) {
        
        List<PatClsIpc> patClsIpcList = new ArrayList<PatClsIpc>();
        DBObject biblio = getBiblio(data);
        
        DBObject ipcDBObject = biblio."classification-ipc"
        if (!!ipcDBObject) {
            
            String clsVersion = ""
            if (!!ipcDBObject.edition) {
                clsVersion = ipcDBObject.edition
            }
            
            if (!!ipcDBObject."main-classification") {
                
                if (!!ipcDBObject."main-classification"[0]) {
                    // println "main-classification = " + ipcDBObject."main-classification"[0]
                    PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, ipcDBObject."main-classification"[0], clsVersion, patClsIpcList.size(), true);
                    patClsIpcList.add(patClsIpc);
                }
                
                if (!!ipcDBObject."further-classification") {
                    // println "further-classification = " + ipcDBObject."further-classification"[0].value
                    PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, ipcDBObject."further-classification"[0].value, clsVersion, patClsIpcList.size(), false);
                    patClsIpcList.add(patClsIpc);
                }
                
            } else {
                //
                ipcDBObject.text.eachWithIndex { ipc, index ->
                    boolean rawMainFlag = false
                    if (index == 0) {
                        rawMainFlag = true;
                    } else {
                        rawMainFlag = false;
                    }
                    PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, ipc.replaceAll(/\*/, ""), null, patClsIpcList.size(), rawMainFlag);
                    patClsIpcList.add(patClsIpc);
                }
                
            }   // end if (!!ipcDBObject."main-classification")
            
            // AT 有資料
            if (!!ipcDBObject."linked-indexing-code-group") {
                
                ipcDBObject."linked-indexing-code-group".each { it ->
                    if (!!it."main-linked-indexing-code") {
                        PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, it."main-linked-indexing-code", clsVersion, patClsIpcList.size(), false, true, true);
                        patClsIpcList.add(patClsIpc);
                    }
                    if (!!it."sub-linked-indexing-code") {
                        it."sub-linked-indexing-code".each { it2 ->
                            PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, it2.replaceAll(/:/, "/"), clsVersion, patClsIpcList.size(), false, true, false);
                            patClsIpcList.add(patClsIpc);
                        }
                    }
                }
                
            }   // end if (!!ipcDBObject."linked-indexing-cdoe-group")
            
            // DE:marshallId=DOCDB-201511-004-DE-0008.xml/385316718
            if (!!ipcDBObject."unlinked-indexing-code") {
                ipcDBObject."unlinked-indexing-code".each { it -> 
                    // println "unlinked-indexing-code = ${it}"
                    PatClsIpc patClsIpc = PatClsUtil.getDocdbIpc(patData, it.replaceAll(/:/, "/"), clsVersion, patClsIpcList.size(), false, true, false, true);
                    patClsIpcList.add(patClsIpc);
                }
            }
            
        }   // end if (!!ipcDBObject)
        
        DBObject ipcrDBObject = biblio."classifications-ipcr"?."classification-ipcr"
        if (!!ipcrDBObject) {
            ipcrDBObject.eachWithIndex { ipcr, index ->
                PatClsIpc patClsIpc = PatClsUtil.getDocdbIpcr(patData, ipcr);
                patClsIpcList.add(patClsIpc);
            }   // end ipcrDBObject.eachWithIndex
        }   // end if (!!ipcrDBObject)
        
        return patClsIpcList;
    }   // end genPatClsIpc
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatDataTitle> getPatDataTitle(DBObject data, PatData patData) {
        
        List<PatDataTitle> patDataTitleList = null;
        DBObject biblio = getBiblio(data);
        DBObject inventionTitleDBObject = biblio."invention-title"
        
        if (!!inventionTitleDBObject) {
            
            patDataTitleList = new ArrayList<PatDataTitle>();
            inventionTitleDBObject.eachWithIndex { it, index ->
                
                PatDataTitle patDataTitle = new PatDataTitle();
                patDataTitle.createDate = new Date();
                patDataTitle.lastUpdDate = new Date();
                
                PatDataTitleId patDataTitleId = new PatDataTitleId();
                patDataTitleId.patId = patData.patId;
                patDataTitleId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
                patDataTitleId.lang = !!it.lang ? it.lang : data.country.toLowerCase();
                patDataTitle.id = patDataTitleId;
                
                // title中的value有可能是空值 or 沒有value => marshall._id = DOCDB-201516-Amend-PubDate20150410AndBefore-CH-0001.xml/315199592
                if (!!it.value) {
                    patDataTitle.title = it.value[0];
                    patDataTitleList.add(patDataTitle);
                } else {
                    logger.error "marshall._id = ${data._id}, title(lang = ${patDataTitleId.lang}) is empty."
                }
                
            }
            
        }   // end if (!!inventionTitleDBObject)
        
        return patDataTitleList;
    }   // end getPatDataTitle
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public List<PatDataBrief> getPatDataBrief(DBObject data, PatData patData) {
        
        List<PatDataBrief> patDataBriefList = null;
        DBObject marshallData = data.data.expansion;
        DBObject abstractDBObject = marshallData."exchange-document"."abstract";
        
        if (!!abstractDBObject) {
            
            patDataBriefList = new ArrayList<PatDataBrief>();
            
            abstractDBObject.eachWithIndex { it, index ->
                PatDataBrief patDataBrief = new PatDataBrief();
                patDataBrief.createDate = new Date();
                patDataBrief.lastUpdDate = new Date();
                
                PatDataBriefId patDataBriefId = new PatDataBriefId();
                patDataBriefId.patId = patData.patId;
                patDataBriefId.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
                patDataBriefId.lang = !!it.lang ? it.lang : data.country.toLowerCase();
                
                patDataBrief.id = patDataBriefId;
                // abstract中的value有可能是空值 => marshall._id = DOCDB-201511-002-CA-0114.xml/279578733
                if (!!it.p[0].value) {
                    patDataBrief.brief = it.p[0].value[0]
                    patDataBriefList.add(patDataBrief);
                } else {
                    logger.error "marshall._id = ${data._id}, abstract is empty."
                }
                
            }
            
        }   // end if (!!abstractDBObject)
        
        return patDataBriefList;
    }   // end getPatDataBrief
    
    /**
     * 
     * @param data
     * @param patData
     * @return
     */
    public void genPatPersonInfo(DBObject data, PatData patData) {
        
        List<PersonData> personDataList = new ArrayList<PersonData>()
        List<PatPersonApplicant> patPersonApplicants = new ArrayList<PatPersonApplicant>();
        List<PatPersonInventor> patPersonInventors = new ArrayList<PatPersonInventor>();
        
        DBObject biblio = getBiblio(data);
        //
        DBObject applicants = biblio."parties"?."applicants"?."applicant"
        DBObject inventors = biblio."parties"?."inventors"?."inventor"
        
        if (!!applicants) {
            //
            applicants.eachWithIndex { applicant, index -> 
                
                PersonData personData = null;
                String applicantName = "";
                String country = "";
                String address = "";
                // String personFacet = "";
                int sequence;
                
                if (applicant."data-format" == "docdb") {
                    
                    applicantName = applicant."applicant-name"[0]?."name"[0]?.value;
                    // println "applicant name = " + applicant."applicant-name"[0]?."name"[0]?.value
                    
                    // address 判斷address資料新舊 ??? => 目前沒有必要
                    if (!!applicant."address"?."text") {
                        address = applicant."address"."text"
                    }
                    
                    if (!!applicant."residence"?."country") {
                        country = applicant."residence"."country";
                        // println "country = " + applicant."residence"."country"
                    }
                    
                    personData = checkAndGeneratePersonData(applicantName, address, country, personDataList)
                    personDataList << personData
                    
                    PatPersonApplicant patPersonApplicant = genPatPersonApplicant(applicant, personData, patData, index + 1);
                    patPersonApplicants.add(patPersonApplicant);
                    
                }  // end if (applicant."data-format" == "docdb")
                
            }  // end applicants.each
            
        }  //  end if (!!applicants)
        
        if (!!inventors) {
            
            inventors.eachWithIndex { inventor, index -> 
                
                PersonData personData = null;
                String inventorName = "";
                String country = "";
                String address = "";
                String personFacet = "";
                
                if (inventor."data-format" == "docdb") {
                    
                    inventorName = inventor."inventor-name"[0]?."name"[0]?.value.trim();
                    // println "inventor name = " + inventor."inventor-name"[0]?."name"[0]?.value
                    
                    // NOTE: inventorName 有可能會出現有值, 但是是空字串的資料出現... ex: DOCDB-201511-001-AU-0036.xml/301888946
                    if (!!inventorName) {
                        // address 判斷address資料新舊 ??? => 目前沒有必要
                        if (!!inventor."address"?."text") {
                            address = inventor."address"."text"
                        }
                        
                        if (!!inventor."residence"?."country") {
                            country = inventor."residence"."country";
                            // println "country = " + inventor."residence"."country"
                        }
                        
                        personData = checkAndGeneratePersonData(inventorName, address, country, personDataList)
                        personDataList << personData
                        
                        PatPersonInventor patPersonInventor = genPatPersonInventor(inventor, personData, patData, index + 1);
                        patPersonInventors.add(patPersonInventor);
                    }
                    
                }  // end if (inventor."data-format" == "docdb")
                
            }  // end inventors.each
            
        }  // end if (!!inventors)
        
        // logger.debug("personDataList = {}, size = {}", personDataList, personDataList.size());
        // logger.debug("patPersonApplicants = {}, size = {}", patPersonApplicants, patPersonApplicants.size());
        // logger.debug("patPersonInventors = {}, size = {}", patPersonInventors, patPersonInventors.size());
        
        PersonDataServices personSvc = new PersonDataServices();
        personSvc.saveOrUpdate(personDataList, patPersonApplicants, patPersonInventors, null, null, null, null);
    }   // end genPatPersonInfo
    
    /**
     * 
     * @param personName
     * @param address
     * @param country
     * @param personDataList
     * @return
     */
    public PersonData checkAndGeneratePersonData(String personName, String address, String country, List<PersonData> personDataList) {
        
        PersonData personData = null;
        String personFacet = genPersonFacet(personName, address, country);
        
        if (StringUtils.isBlank(personFacet)) {
            throw new Exception("personFacet error");
        }
        
        PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personFacet, country, personDataList);
        
        if (!!existsData) {
            personData = existsData;
        } else {
            personData = genPersonData(personName, address, country, personFacet);
        }
        
        return personData;
    }  // end checkAndGeneratePersonData
    
    /**
     * 組出 PatPersonInventor 所需欄位
     * @param inventor
     * @param patData
     * @param createDate
     * @param item
     * @return
     */
    private PatPersonInventor genPatPersonInventor(DBObject inventor, PersonData personData, PatData patData, int item) {

        PatPersonInventorId id = new PatPersonInventorId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        
        PatPersonInventor patPersonInventor = new PatPersonInventor();
        patPersonInventor.id = id;
        patPersonInventor.personData = personData;
        patPersonInventor.designation = inventor."designation";
        patPersonInventor.createDate = new Date();
        patPersonInventor.personCountry = personData.country;
        
        return patPersonInventor;
    }   // end genPatPersonInventor
    
    /**
     * 組出 PatPersonApplicant 所需欄位
     * @param applicant
     * @param patData
     * @param createDate
     * @return
     */
    private PatPersonApplicant genPatPersonApplicant(DBObject applicant, PersonData personData, PatData patData, int item) {

        PatPersonApplicantId id = new PatPersonApplicantId();
        id.item = item;
        id.patId = patData.patId;
        id.sourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        
        PatPersonApplicant patPersonApplicant = new PatPersonApplicant();
        patPersonApplicant.id = id;
        patPersonApplicant.personData = personData;
        patPersonApplicant.appCode = applicant."app-type";
        patPersonApplicant.designationCode = applicant."designation";
        patPersonApplicant.createDate = new Date();
        patPersonApplicant.personCountry = personData.country;
        
        return patPersonApplicant;
    }
    
    /**
     * 
     * @param applicantName
     * @param address
     * @param country
     * @param personFacet
     * @return
     */
    public PersonData genPersonData(String personName, String address, String country, String personFacet) {
        
        PersonData personData = new PersonData();
        //
        personData.personId = UUIDUtil.generateUUID();
        personData.personFacet = personFacet;
        personData.personType = Constants.PERSON_TYPE_NONE;
        personData.lang = Constants.US_LANG;
        personData.personName = personName.trim();
        personData.address = address;
        personData.country = country;
        personData.createDate = new Date();
        personData.lastUpdDate = new Date();
        
        return personData;
    }
    
    /**
     * facet combines person_name, country fields
     */
    public String genPersonFacet(String personName, String address = '', country) {
        return StringUtil.personFacetWrap(personName + address + country);
    }
    
    /**
     * @deprecated 
     * @param data
     * @return
     */
    public String genPatId(DBObject data) {
        return PatNumberUtil.getPatIdDOCDB(data.country, data.patentNumber, data.kindcode, data.doDate as String);
    }
    
    /**
     * TABLE: pat_raw_docdb process
     * 
     * @param data
     * @param patData
     * @return
     */
    public PatRawDocdb getPatRawDocdb(DBObject data, PatData patData) {
        
        PatRawDocdb patRawDocdb = new PatRawDocdb();
        
        patRawDocdb.rawId = data._id;
        patRawDocdb.patId = patData.patId;
        
        DBObject dbObject = data.data.expansion
        
        // dbObject."exchange-document"."abstract" = "";
        // dbObject."exchange-document"."bibliographic-data"."invention-title" = "";
        String rawJson = dbObject;
        if (JSONUtil.isJSONValid(rawJson)) {
            patRawDocdb.rawJson = rawJson;
        } else {
            throw new JsonFormatException("rawJson");
        }
        
        patRawDocdb.lastestFlag = 1
        
        def lastExchangeDate = dbObject."exchange-document"."date-of-last-exchange" as String
        if (!!lastExchangeDate) {
            patRawDocdb.lastExchangeDate = DateUtil.parseDate(lastExchangeDate)
        }
        
        if (!!dbObject."exchange-document"."patent-family") {
            String familyMemberJsonStr = data.data.expansion."exchange-document"."patent-family"
            if (JSONUtil.isJSONValid(familyMemberJsonStr)) {
                patRawDocdb.familyMemberJson = familyMemberJsonStr
            } else {
                throw new JsonFormatException("familyMemberJsonStr");
            }
             
        }
        
        patRawDocdb.createDate = new Date();
        patRawDocdb.lastUpdDate = new Date();
        
        return patRawDocdb;
        
    }   // end getPatRawDocdb
    
    /**
     * TABLE: app_data process
     * 
     * APP NO:
     * 既有PTO:參照各PTO規則
     * Others:application-reference data-format="docdb"中的doc-number
     * 
     * app_data.app_id:
     * 既有PTO:參照各PTO規則
     * Others:country+(APP NO去掉非英數字之特殊符號)
     * 
     * @param data
     * @return
     */
    public AppData genAppData(DBObject data) {
        
        AppData appData = new AppData();
        //
        DBObject biblio = getBiblio(data);
        //
        String appNo;
        String appId;
        String appDate;
        String appYear;
        
        appData.country = data.country;
        
        biblio."application-reference".each { it ->
            
            // NOTE: data-format="epodoc" 會出現沒有date的情況..., 所以default date == data-format = "docdb"
            if (!appDate && it."data-format" == "docdb") {
                appDate = it."document-id"."date" as String;
            }
            
            // ****既有pto 使用 data-format="original" 或  data-format="docdb"
            if (CountryUtil.isOriginPTO(data.country)) {
                
                if (it."data-format" == "docdb") {
                    def appInfo = PatNumberUtil.getAppInfoByOriginPTO(it, data.country);
                    appData.appNo = appInfo.appNo;
                    appData.appId = appInfo.appId;
                    appData.appDate = appInfo.appDate;
                    
                    // TODO: 如果和即有[PTO]中的appNo, appDate不一致的話, 寫pat_data_log.
                    
                }
                
            } else {
            
                // Other country 使用 data-format="epodoc"
                if (it."data-format" == "epodoc") {
                    // 因應前台要求, 取得的appNo中前二碼的國碼去除. => 有要做 ???
                    appNo = it."document-id"."doc-number"
                    
                    if (!!it."document-id"."date") {
                        appDate = it."document-id"."date" as String;
                    }
                    
                    appId = PatNumberUtil.getAppIdDOCDB(appNo, data.country)
                    //
                    appData.appNo = appNo;
                    appData.appId = appId;
                    appData.appDate = DateUtil.parseDate(appDate);
                }
            
            }   // end if isOriginPTO
            
        }   // end [application-reference]
        
        if (!appData.appDate) {
            appData.appDate = DateUtil.parseDate(Constants.DOCDB_DEFAULT_DATE);
        }
        
        appData.appLang = getLang(data);
        appData.createDate = new Date();
        appData.lastUpdDate = new Date();
        
        return appData;
        
    }   // end genAppData
    
    /**
     * // TODO: 如果和即有[PTO]中的docDate不一致的話, 寫pat_data_log.
     * 
     * TABLE: pat_data process
     * 
     * @param data
     * @return
     */
    public PatData genPatData(DBObject data) {
        
        PatData patData = new PatData();
        
        DBObject marshallData = data.data.expansion;
        DBObject biblio = marshallData."exchange-document"."bibliographic-data";
        
        DB patentInfoDOCDB = dbClient.getDB("PatentInfoDOCDB");
        // DBCollection kindCodeMapColl = patentInfoDOCDB.getCollection("KindCodeMap");
        
        Map kindCodeDataMap = DocdbKindCodeUtil.getKindcodeData(data, patentInfoDOCDB);
        logger.debug "kindCodeDataMap = ${kindCodeDataMap}"
        patData.stat = kindCodeDataMap.stat;
        patData.patType = PatTypeEnum.DOCDB.findPatTypeCode(kindCodeDataMap.type)
        patData.parentCaseText = "test"
        
        biblio."publication-reference".each { it ->
            //
            if (it."data-format" == "docdb") {
                
                String docNo = it."document-id"."doc-number";
                String country = it."document-id"."country";
                String kindCode = it."document-id"."kind";
                String doDate = it."document-id"."date";
                
                patData.rawDocNo = docNo;
                patData.docNo = docNo;
                patData.kindCode = kindCode;
                patData.country = country;
                if (!!doDate) {
                    patData.docDate = DateUtil.parseDate(doDate);
                } else {
                    patData.docDate = DateUtil.parseDate(Constants.DOCDB_DEFAULT_DATE);
                }
                
                if (CountryUtil.isOriginPTO(country)) {
                    
                    // TODO: PatData.patId
                    patData.patId = PatNumberUtil.getPatIdByOriginPTO(patData);
                    logger.info("patData.patId = ${patData.patId}");
                    
                } else {
                    logger.debug "other country patId"
                    patData.patId = PatNumberUtil.getPatIdDOCDB(country, docNo, kindCode, doDate);
                }
                
            }
            
        }   // end [publication-reference]
        
        biblio."application-reference".each { it ->
            
            String rawAppNo;
            String appId;
            
            // ****既有pto 使用 data-format="original" 或  data-format="docdb"
            if (CountryUtil.isOriginPTO(data.country)) {
                
                if (it."data-format" == "docdb") {
                    def appInfo = PatNumberUtil.getAppInfoByOriginPTO(it, data.country);
                    patData.rawAppNo = appInfo.rawAppNo;
                    patData.appId = appInfo.appId;
                }
            
            } else {
            
                // Other country 使用 data-format="epodoc"
                if (it."data-format" == "epodoc") {
                    rawAppNo = it."document-id"."doc-number"
                    appId = PatNumberUtil.getAppIdDOCDB(rawAppNo)
                    //
                    patData.rawAppNo = rawAppNo;
                    patData.appId = appId;
                }
            
            }   // end isOriginPTO
            
        }   // end [application-reference]
        
        String familyId = marshallData."exchange-document"."family-id";
        patData.familyId = familyId;
        
        patData.defaultSourceId = Constants.SOURCE_ID_DOCDB_BRIEF;
        patData.oriLang = getLang(data);
        patData.docdbFlag = Constants.DOCDB_FLAG_YES;
        patData.ptoFlag = Constants.FULL_TEXT_FLAG_NO;
        patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
        
        // 判斷 stauts
        String status = marshallData."exchange-document"."status"
        if (status == "D" || status == "DV" || status == "CV") {
            patData.withdrawFlag = Constants.WITHDRAW_FLAG_TRUE;
            patData.deleteFlag = Constants.DELETE_FLAG_YES;
        } else {
            patData.withdrawFlag = Constants.WITHDRAW_FLAG_FALSE;
            patData.deleteFlag = Constants.DELETE_FLAG_NO;
        }
        
        patData.truncateFlag = Constants.TRUNCATE_FLAG_FALSE;
        
        if (!!biblio."dates-of-public-availability"?."gazette-pub-announcement") {
            
            DBObject gazette = biblio."dates-of-public-availability"?."gazette-pub-announcement"
            logger.debug("gazette = {}", gazette);
            
            if (!!gazette."gazette-num") {
                patData.gazettePublicDate = gazetteDate."gazette-num";
            }
            
            if (!!gazette."date") {
                Date gazetteDate = DateUtil.parseDate(gazette."date" as String)
                patData.gazettePublicDate = gazetteDate;
            }
            
        }   // end if gazette-pub-announcement exist
        
        if (!!biblio."designation-of-states") {
            
            String designationOfStatesJsonStr = biblio."designation-of-states";
            // logger.debug("designationOfStatesJsonStr = {}", designationOfStatesJsonStr);
            
            if (JSONUtil.isJSONValid(designationOfStatesJsonStr)) {
                patData.designationOfStatesJson = designationOfStatesJsonStr;
            } else {
                throw new JsonFormatException("designationOfStatesJson");
            }
            
        }   // end if designation-of-states exist
        
        patData.createDate = new Date();
        patData.lastUpdDate = new Date();
        
        // logger.debug "patData = ${patData.toString()}"
        
        return patData;
        
    }   // end genPatData
    
    /*
     * ori_lang(pat_data), app_lang(app_data) 共用
     *
     * patData.oriLang : <exch:language-of-filing>en</exch:language-of-filing>
     *
     * 若country為CN, 且lang為zh, 則寫入zh_cn, else則寫入lang之值
     * 若country為TW, 且lang為zh, 則寫入zh_tw, else則寫入lang之值
     *
     */
    public String getLang(DBObject data) {
        
        DBObject biblio = getBiblio(data);
        
        // default language encode
        String lang = Constants.US_LANG;
        
        if (!!biblio."language-of-filing") {
            
            if (data.country == "TW") {
                // patData.oriLang = marshallData."exchange-document"."bibliographic-data"."language-of-filing"."value";
                lang = "zn_tw";
            } else if (data.country == "CN") {
                lang = "zn_cn";
            } else {
                lang = biblio."language-of-filing"."value";
            }
            
        } else {
            
            biblio."publication-reference".each { it ->
                if (it."data-format" == "docdb") {
                    if (!!it."document-id"."lang") {
                        lang = it."document-id"."lang"
                    }
                }
            }   // end [publication-reference]
        
        }   // end if biblio."language-of-filing"
        
        return lang;
        
    }   // end getLang
    
    /**
     *
     * @param data
     * @return
     */
    private DBObject getBiblio(DBObject data) {
        DBObject marshallData = data.data.expansion;
        return marshallData."exchange-document"."bibliographic-data";
    }
    
    static main(args) {
        
        /*
         * designation-of-states => 
         * 
         * WO, DOCDB-201546-Amend-PubDate20151106AndBefore-WO-0004.xml/404630674
         * DE, DOCDB-201550-Amend-PubDate20151204AndBefore-DE-0003.xml/302074175 => 有"gazette-pub-announcement"
         * 
         * getLang test =>
         * 
         * WO, DOCDB-201546-Amend-PubDate20151106AndBefore-WO-0004.xml/404630674
         *
         * exception: org.hibernate.AssertionFailure: possible non-threadsafe access to session 
         * => DOCDB-201546-Amend-PubDate20151106AndBefore-IS-0001.xml/391225009
         * 
         * JP, DOCDB-201504-Amend-PubDate20150116AndBefore-JP-0001.xml/299686711
         * => linked-indexing...
         * 
         */

//        NOTE: 查詢條件:1 ============================================================
//        CountryUtil.getOtherCountryList().each { cc -> 
//            def queryMap = [country: cc]
//            logger.info "queryMap = ${queryMap}"
//            new DOCDBPatDataProcess().queryMap(queryMap).process();
//        }

//        // NOTE: 查詢條件:2 ============================================================ 查詢docdbDoDate and file type
//        def cc = "ZA";
//        println "to start..."
//        DocdbDoDateUtil.getDocdbDoDate(cc).each { docdbDoDate ->
//            
//            // println "docdbDoDate = ${docdbDoDate}"
//            
//            def fileTypeList = [0, 1, 2]
//            
//            fileTypeList.each { fileType ->
//                def queryMap = [country: cc, query: [fileType: fileType, docdbDoDate: DateUtil.parseDate(docdbDoDate)]]
//                def count = marshallDB.getCollection("PatentMarshall${cc}").count(queryMap.query)
//                if (count > 0) {
//                    println "[country: \"${cc}\", query: [fileType: ${fileType}, docdbDoDate: DateUtil.parseDate(\"${docdbDoDate}\")]],"
//                    // logger.info "queryMap = ${queryMap}"
//                    // new DOCDBPatDataProcess().queryMap(queryMap).process();
//                }
//            }
//            
//        }   // end DocdbDoDateUtil.getDocdbDoDate
        
        
        // NOTE: 查詢條件:3 ============================================================
        QueryUtil.getQueryList_RU_2().each { queryMap -> 
            logger.info "queryMap = ${queryMap}"
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        }
        MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "DOCDBPatDataProcess Complete Message", "QueryUtil.getQueryList_RU_2 complete");
        
//        // NOTE: 查詢條件:4 ============================================================
//        def queryMap = [country: "RU", query: [_id: "DOCDB-201511-018-RU-0041.xml/408318339"]]
//        // def queryMap = [country: ""]
//        logger.info "queryMap = ${queryMap}"
//        new DOCDBPatDataProcess().queryMap(queryMap).process();
        
//        // NOTE: 查詢條件 5 ============================================================ 讀檔刷資料
//        new File("bak/rebuild/rebuild_person_info_data.txt").eachLine { it, line -> 
//            
//            String cc = it.toString().split("-")[-2];
//            String marshallId = it.toString();
//            def queryMap = [country: cc, query: [_id: marshallId]]
//            logger.info "queryMap = ${queryMap}"
//            new DOCDBPatDataProcess().queryMap(queryMap).process();
//            
//            println "process ${line} / 33561"
//        }
        
        logger.info "finished..."
        
    }

}
