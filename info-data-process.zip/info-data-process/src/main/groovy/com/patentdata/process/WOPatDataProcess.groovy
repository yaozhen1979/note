package com.patentdata.process;

import static org.apache.commons.collections.MapUtils.getObject
import static org.apache.commons.collections.MapUtils.getString

import java.text.SimpleDateFormat

import org.apache.commons.lang3.StringUtils
import org.bson.Document
import org.slf4j.LoggerFactory

import com.mongodb.BasicDBList
import com.mongodb.Bytes
import com.mongodb.DBCollection
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.helper.PatDataHelper
import com.patentdata.helper.PersonDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsEcla
import com.patentdata.model.PatClsEclaId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatData
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataBriefId
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataClaimsId
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataDescId
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonAgentId
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonApplicantId
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PatPersonInventorId
import com.patentdata.model.PatPtopidMapping
import com.patentdata.model.PatRawWo
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedId
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefCitedNplId
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefPriorityId
import com.patentdata.model.PatRefRelatedChild
import com.patentdata.model.PatRefRelatedChildId
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PatRefRelatedParentId
import com.patentdata.model.PersonData
import com.patentdata.model.SourceData
import com.patentdata.service.AppDataService
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataLogService
import com.patentdata.service.PatDataMemoService
import com.patentdata.service.PatDataService
import com.patentdata.service.PatPtopidMappingService
import com.patentdata.service.PatRawService
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.CheckUtil
import com.patentdata.util.CountryUtil
import com.patentdata.util.DateUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatClsUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.StringUtil
import com.patentdata.util.UUIDUtil


public class WOPatDataProcess extends BaseProcess {

    public DBCollection marshallCol // marshallWO
    public DBCollection patInfoCol  // 121
    
    ///// for logging error id//////
    public PrintWriter printWriter
    public int errornum = 0
    public int procesednum = 0
    /////////////////////////////////////////
    public int skipNumber = 0
    public int limitNumber = 5000
    /////////////////////////////////////////


    public WOPatDataProcess() {
        logger = LoggerFactory.getLogger(WOPatDataProcess.class);
        this.marshallCol = MongoUtil.connectByConfig("WO").getDB("PatentMarshallWIPO").getCollection("PatentMarshallWIPO")
        this.patInfoCol = MongoUtil.connectByConfig("121").getDB("PatentInfoWIPO").getCollection("PatentInfoWIPO")
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        this.printWriter = new PrintWriter(new FileOutputStream( new File("./logs/ErrorId/" + sdf.format(new Date()) + ".txt"), true));
        
    }

    @Override
    DBCursor queryData() throws Exception {
        logger.info( "queryMap : $queryMap")

        DBCursor cursor = marshallCol.find(queryMap).sort(['doDate':1]).limit(limitNumber).skip(skipNumber).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
        return cursor;
    }

    @Override
    void processData(DBObject data) throws Exception {
        Processor processor = getProcessor(data)
        processor.process()
    }


    protected Processor getProcessor(DBObject data){
        switch (data['xmltypeAbb']){
            case Constants.WO_XMLTYPE_WPA:
                return new ProcessorWPA(data)

            case Constants.WO_XMLTYPE_LNP:
                return new ProcessorLNP(data)
        }
    }




    protected abstract class Processor{
        protected Date currentTime
        protected DBObject data
        protected DBObject oldData
        protected PatData patData
        protected AppData appData
        protected PatDataService patSvc
        protected AppDataService appSvc

        public Processor(DBObject data){
            this.currentTime = new Date()
            this.patSvc = new PatDataService()
            this.appSvc = new AppDataService()
            this.data = data            
            this.oldData = getOldMongoObject(PatNumberUtil.marshallidToPatentNumberWO(this.data.'docId'), this.data.'doDate')
        }

        /**
         * app_data 
         * pat_data 
         * pat_raw 
         * person_data 
         * person_lang (only for WO) 
         * person_lang_list (only for WO) 
         * person_person_agent 
         * person_person_applicant 
         * person_person_assignee 
         * person_person_correspondence_addr 
         * pat_person_examiner 
         * pat_person_inventor 
         * pat_data_brief 
         * pat_data_claims 
         * pat_data_desc 
         * pat_data_title 
         * pat_data_cls..... 
         * pat_data_ref..... 
         * pat_event_record 
         * pat_event_amend_log
         */
        public void process() throws Exception{
            WOPatDataProcess.this.procesednum++
            
//            Date timer = new Date();
//            println timer.getTime()
            saveAppData();
//            println 'saveApp:' + (new Date().getTime()-timer.getTime())
            
            savePatData();
//            println 'savePat:' + (new Date().getTime()-timer.getTime())
            
            savePtopidMapping();
//            println 'savePtopidMapping:' + (new Date().getTime()-timer.getTime())
            
            savePatRaw();
//            println 'savePatRaw:' + (new Date().getTime()-timer.getTime())
            
            savePersonData();
//            println 'savePersonData:' + (new Date().getTime()-timer.getTime())
            
            savePatDataBrief();
//            println 'savePatDataBrief:' + (new Date().getTime()-timer.getTime())
            
            savePatDataClaims();
//            println 'savePatDataClaims:' + (new Date().getTime()-timer.getTime())
            
            savePatDataDesc();
//            println 'savePatPatDataDesc:' + (new Date().getTime()-timer.getTime())
            
            savePatDataTitle();
//            println 'savePatDataTitle:' + (new Date().getTime()-timer.getTime())
            
            savePatDataCls();
//            println 'savePatDataCls:' + (new Date().getTime()-timer.getTime())
            
            savePatDataRef();
//            println 'savePatDataRef:' + (new Date().getTime()-timer.getTime())
            
        }

        protected abstract void saveAppData();
        protected abstract void savePatData();
        protected abstract void savePatRaw();
        protected abstract void savePersonData();
        protected abstract void savePatDataBrief();
        protected abstract void savePatDataClaims();
        protected abstract void savePatDataDesc();
        protected abstract void savePatDataTitle();
        protected abstract void savePatDataCls();
        protected abstract void savePatDataRef();
        
        protected void savePtopidMapping(){
            WoPatPtopidMapping woPatPtopidMapping  = new WoPatPtopidMapping()
            PatPtopidMapping patPtopidMapping = woPatPtopidMapping.getPatPtopidMapping(this.patData, this.oldData)
            
            PatPtopidMappingService svc = new PatPtopidMappingService();
            svc.saveOrUpdatePatPtopidMapping(patPtopidMapping);
        }
        
        public DBObject getOldMongoObject(String patentNumber, Date doDate){
            Calendar c = Calendar.getInstance()
            c.setTime(doDate)
            c.add(Calendar.DATE, -1)
            Date start = c.getTime()
            
            c.add(Calendar.DATE, 2)
            Date end = c.getTime()
            Map query = ["patentNumber": patentNumber, "doDate": ['$gt': start, '$lt':end]]

            DBObject oldObj = WOPatDataProcess.this.patInfoCol.findOne(query)
            if(!oldObj){
                throw new Exception('mapping fail: cannot find old from 121')
            }
            return oldObj
        }
        
    }

    /**
     * *** Assumption: every OPA and WAB can map into at least one WPA ***     
     * @author yeatschung
     */
    protected class ProcessorWPA extends Processor{
        DBObject fulltext

        public ProcessorWPA(DBObject data){
            super(data)
            this.patData = new WoPatDataWPA().getPatData(this.data, this.currentTime, this.oldData)
//            println this.patData.patId
        }

        @Override
        protected void saveAppData() {
            this.appData = new WoAppDataWPA().getAppData(this.data, patData)
            if(!!this.appData){
                appSvc.saveOrUpdateAppData(this.appData)
            }
        }

        @Override
        protected void savePatData() {
            patSvc.saveOrUpdatePatData( patData)
        }

        @Override
        protected void savePatRaw() {
            DBObject obj
            String OPAId = StringUtils.substringBeforeLast(this.data.'docId', '/') + '/OPA'
            String WABId = StringUtils.substringBeforeLast(this.data.'docId', '/') + '/WAB'

            PatRawService patRawSvc = new PatRawService();

            obj = WOPatDataProcess.this.marshallCol.findOne(['docId': OPAId])
            if( !!obj){
                PatRawWo patRawWoOPA = new WoPatRawOPA().getWoPatRawWo(obj, this.patData.lastUpdDate)
                patRawSvc.saveOrUpdatePatRawWo(patRawWoOPA)
                this.fulltext = obj
            }

            obj = WOPatDataProcess.this.marshallCol.findOne(['docId': WABId])
            if(!!obj){
                PatRawWo patRawWoWAB = new WoPatRawWAB().getWoPatRawWo(obj, this.patData.lastUpdDate)
                patRawSvc.saveOrUpdatePatRawWo(patRawWoWAB)
                this.fulltext = obj
            }

            PatRawWo patRawWoWPA = new WoPatRawWPA().getWoPatRawWo(this.data, this.patData.lastUpdDate)
            patRawSvc.saveOrUpdatePatRawWo(patRawWoWPA)
        }

        @Override
        protected void savePersonData() {

            WoPersonDataWPA woPersonDataWPA = new WoPersonDataWPA()
            woPersonDataWPA.importPersonData(this.data, this.patData)

            PersonDataServices personDataServices = new PersonDataServices()
            
            personDataServices.saveOrUpdate(
                    woPersonDataWPA.personDatas,
                    woPersonDataWPA.patPersonApplicants,
                    woPersonDataWPA.patPersonInventors,
                    woPersonDataWPA.patPersonAgents,
                    new ArrayList(),
                    new ArrayList(),
                    new ArrayList()
                    )

            PatDataMemoService patDataMemoService = new PatDataMemoService()
            if(woPersonDataWPA.addMemoFlag){
                patDataMemoService.savePatDataMemo(this.patData.patId, this.patData.defaultSourceId, Constants.DATA_MEMO_PERSON_WITH_MULTILANG)
            }
        }

        @Override
        protected void savePatDataBrief() {
            List<PatDataBrief> patDataBriefs = new WoPatDataBriefWPA().getPatDataBriefList(this.data, patData)
            patSvc.saveOrUpdatePatDataBrief(patDataBriefs)
        }

        @Override
        protected void savePatDataClaims() {
            // no fulltext files found
            if(!this.fulltext){
                return
            }

            WoPatDataClaimsBasic woPatDataClaims
            switch (this.fulltext.'xmltypeAbb'){
                case Constants.WO_XMLTYPE_WAB:
                    woPatDataClaims = new WoPatDataClaimsWAB()
                    break;

                case Constants.WO_XMLTYPE_OPA:
                    woPatDataClaims = new WoPatDataClaimsOPA()
                    break;
            }

            List<PatDataClaims> patDataClaims = woPatDataClaims.getPatDataClaims(this.fulltext, this.currentTime)
            patSvc.saveOrUpdatePatDataClaims(patDataClaims)
        }
        @Override
        protected void savePatDataDesc() {
            // no fulltext files found
            if(!this.fulltext){
                return
            }

            WoPatDataDescsBasic woPatDataDescs

            switch (this.fulltext.'xmltypeAbb'){
                case Constants.WO_XMLTYPE_WAB:
                    woPatDataDescs = new WoPatDataDescsWAB()
                    break;

                case Constants.WO_XMLTYPE_OPA:
                    woPatDataDescs = new WoPatDataDescsOPA()
                    break;
            }

            List<PatDataDesc> patDataDescs = woPatDataDescs.getPatDataDescs(this.fulltext, this.patData.lastUpdDate)
            patSvc.saveOrUpdatePatDataDesc(patDataDescs);

        }

        @Override
        protected void savePatDataTitle() {
            List<PatDataTitle> patDataTitles = new WoPatDataTitleWPA().getPatDataTitles(this.data, patData)
            patSvc.saveOrUpdatePatDataTitle(patDataTitles)
        }

        @Override
        protected void savePatDataCls() {
            PatClsService patClsService = new PatClsService()
            WoPatClsIPCWPA woPatClsIPCWPA = new WoPatClsIPCWPA()
            woPatClsIPCWPA.importPatCls(this.data, this.patData)
            patClsService.saveOrUpdatePatClsIpc(woPatClsIPCWPA.patClsIpcs)
            patClsService.saveOrUpdatePatClsIpc(woPatClsIPCWPA.patClsIpcrs)
        }

        @Override
        protected void savePatDataRef() {
            PatRefService patRefService = new PatRefService()
            PatRefPct patRefPct = new WoPatRefPctWPA().getPatRefPct(this.data, this.patData, this.appData)
            patRefService.savePatRefPct(patRefPct);

            List<PatRefPriority> patRefPrioritys = new WoPatRefPriorityWPA().getPatRefPrioritys(this.data, this.patData)
            patRefService.savePatRefPriority(patRefPrioritys, this.patData.patId, this.patData.defaultSourceId)
        }

    }

    protected class ProcessorLNP extends Processor{
        public ProcessorLNP(DBObject data){
            super(data)
            patData = new WoPatDataLNP().getPatData(this.data, this.currentTime, this.oldData)
        }

        @Override
        protected void saveAppData() {
            this.appData = new WoAppDataLNP().getAppData(this.data, this.patData)
            appSvc.saveOrUpdateAppData(this.appData)
        }
        @Override
        protected void savePatData() {
            patSvc.saveOrUpdatePatData(patData)
        }
        @Override
        protected void savePatRaw() {
            PatRawService patRawSvc = new PatRawService();
            PatRawWo patRawWoLNP = new WoPatRawLNP().getWoPatRawWo(this.data, this.patData.lastUpdDate)
            patRawSvc.saveOrUpdatePatRawWo(patRawWoLNP)
        }
        @Override
        protected void savePersonData() {

            WoPersonDataLNP woPersonDataLNP = new WoPersonDataLNP()
            woPersonDataLNP.importPersonData(this.data, this.patData)

            PersonDataServices personDataServices = new PersonDataServices()

            personDataServices.saveOrUpdate(
                    woPersonDataLNP.personDatas,
                    woPersonDataLNP.patPersonApplicants,
                    woPersonDataLNP.patPersonInventors,
                    woPersonDataLNP.patPersonAgents,
                    new ArrayList(),
                    new ArrayList(),
                    new ArrayList()
                    )

            PatDataMemoService patDataMemoService = new PatDataMemoService()
            if(woPersonDataLNP.addMemoFlag){
                patDataMemoService.savePatDataMemo(this.patData.patId, this.patData.defaultSourceId, Constants.DATA_MEMO_PERSON_WITH_MULTILANG)
            }

        }
        @Override
        protected void savePatDataBrief() {
            List<PatDataBrief> patDataBriefs = new WoPatDataBriefLNP().getPatDataBriefList(this.data, this.patData)
            patSvc.saveOrUpdatePatDataBrief(patDataBriefs)
        }
        @Override
        protected void savePatDataClaims() {
            List<PatDataClaims> patDataClaims = new WoPatDataClaimsLNP().getPatDataClaims(this.data, this.patData)
            patSvc.saveOrUpdatePatDataClaims(patDataClaims);
        }
        @Override
        protected void savePatDataDesc() {
            List<PatDataDesc> patDataDescs = new WoPatDataDescsLNP().getPatDataDescs(this.data, this.patData.lastUpdDate)
            patSvc.saveOrUpdatePatDataDesc(patDataDescs);
        }
        @Override
        protected void savePatDataTitle() {
            List<PatDataTitle> patDataTitles = new WoPatDataTitleLNP().getPatDataTitles(this.data, this.patData)
            patSvc.saveOrUpdatePatDataTitle(patDataTitles)
        }
        @Override
        protected void savePatDataCls() {
            PatClsService patClsService = new PatClsService()
            WoPatClsIPCLNP woPatClsIPCLNP = new WoPatClsIPCLNP()
            woPatClsIPCLNP.importPatCls(this.data, this.patData)
            patClsService.saveOrUpdatePatClsIpc(woPatClsIPCLNP.patClsIpcs)
            patClsService.saveOrUpdatePatClsIpc(woPatClsIPCLNP.patClsIpcrs)
            
            List<PatClsEcla> patClsEclas = new WoPatClsEclaLNP().getPatClsEcla(this.data, this.patData)
            patClsService.saveOrUpdatePatClsEcla(patClsEclas)
        }
        @Override
        protected void savePatDataRef() {
            PatRefService patRefService = new PatRefService()

            List<PatRefCited> woPatRefCiteds = new WoPatRefCitedLNP().getPatRefCiteds(this.data, this.patData)
            patRefService.savePatRefCited(woPatRefCiteds, this.patData.patId, this.patData.defaultSourceId)

            List<PatRefCitedNpl> woPatRefCitedNpls = new WoPatRefCitedNplLNP().getPatRefCitedNpls(this.data, this.patData)
            patRefService.savePatRefCitedNpl(woPatRefCitedNpls, this.patData.patId, this.patData.defaultSourceId)

            PatRefPct patRefPct = new WoPatRefPctLNP().getPatRefPct(this.data, this.patData, this.appData)
            patRefService.savePatRefPct(patRefPct);

            List<PatRefPriority> patRefPrioritys = new WoPatRefPriorityLNP().getPatRefPrioritys(this.data, this.patData)
            patRefService.savePatRefPriority(patRefPrioritys, this.patData.patId, this.patData.defaultSourceId)

            WoPatRefRelatedDocumentsLNP woPatRefRelatedDocumentsLNP = new WoPatRefRelatedDocumentsLNP()
            woPatRefRelatedDocumentsLNP.importRelatedDocuments(this.data, this.patData)

            patRefService.savePatRefRelatedParentChild(
                    woPatRefRelatedDocumentsLNP.patRefRelatedParents,
                    woPatRefRelatedDocumentsLNP.patRefRelatedChilds,
                    this.patData.patId,
                    this.patData.defaultSourceId)


        }
    }

    /**
     * 
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    @Override
    void processFailData(DBObject data, String message) throws Exception {
        errornum++
        logger.error(data.'docId' + '\t' + this.errornum + '/' + this.procesednum);
        this.printWriter.println( data.get("docId"));
        this.printWriter.flush();
        new PatDataLogService().writeErrorMessage(data.get("docId"), 'WO', message)
    }

    protected class WoPatPtopidMapping{

        public PatPtopidMapping getPatPtopidMapping(PatData patData, DBObject oldData){
            PatPtopidMapping patPtopidMapping = new PatPtopidMapping()
            patPtopidMapping.patData = patData
            patPtopidMapping.ptopidId = oldData.'_id'
            return patPtopidMapping
        }        
    }
    

    
    protected class WoPatClsEclaLNP{
        
        String eclaPath = 'data.bibliographic-data.classifications-ecla'
        public List<PatClsEcla> getPatClsEcla(Map doc, PatData patData) throws Exception{
            List<PatClsEcla> patClsEclas = new ArrayList()
            
            for(Object classificationEcla: WOPatDataProcess.getMapRecursively(doc, eclaPath)?.'classification-ecla'){
                PatClsEcla patClsEcla = createPatClsEcla(patData)
                patClsEcla.id.item = patClsEclas.size()+1
                
                String eclaText
                try{ // skip ecla error case
                    eclaText = WOPatDataProcess.formatClsIpc(classificationEcla)
                }catch(Exception e){ 
                    continue;
                }
                
                classificationEcla?.'additional-subgroups'?.'additional-subgroup'.each{additionalSubgroup->
                    eclaText +=  StringUtils.defaultString(additionalSubgroup?.'value').trim()
                }
                patClsEcla.eclaText = eclaText
                patClsEclas.add(patClsEcla)
            }
            
            return patClsEclas
        }
        
        protected PatClsEcla createPatClsEcla(PatData patData){
            PatClsEcla patClsEcla = new PatClsEcla(
                new PatClsEclaId(patData.patId, patData.defaultSourceId, 0),
                patData, new SourceData(), '', patData.lastUpdDate
                )
            
            patClsEcla.sourceData.sourceId = patData.defaultSourceId
            return patClsEcla
        }
    }
    

    protected abstract class WoPatClsIPCBasic{
        protected String ipcPath        // path of classification-ipc
        protected String ipcrPath        //path of classifications-ipcr
        public List<PatClsIpc> patClsIpcs
        public List<PatClsIpc> patClsIpcrs

        public WoPatClsIPCBasic(){
            patClsIpcs = new ArrayList<PatClsIpc>()
            patClsIpcrs = new ArrayList<PatClsIpc>()
        }

        public void importPatCls(Map doc, PatData patData){

            importIpc(WOPatDataProcess.getMapRecursively(doc, this.ipcPath), patData)

            importIpcr(WOPatDataProcess.getMapRecursively(doc, this.ipcrPath), patData)

        }

        protected abstract void importIpc(Object clsIpc, PatData patData);
        
        protected abstract void importIpcr(Object clsIpcrs, PatData patData)
        
        protected abstract Map generateIPCMap(Map doc)
        
        public PatClsIpc createPatClsIpc(PatData patData, int ipcType, int isMain){
            PatClsIpc patClsIpc = new PatClsIpc()
            
            patClsIpc.id = new PatClsIpcId(patData.patId, patData.defaultSourceId, ipcType, 0)
            if(ipcType == Constants.CLS_TYPE_IPC){
                patClsIpc.id.item = patClsIpcs.size()+1
            }else if(ipcType == Constants.CLS_TYPE_IPCR){
                patClsIpc.id.item = patClsIpcrs.size()+1
            }
            
            patClsIpc.rawMainFlag = isMain
            patClsIpc.createDate = patData.lastUpdDate

            return patClsIpc
        }

        /**
         * get PatClsIpc from clsIpc object
         * @param patData
         * @param clsIpc
         * @param ipcType
         * @param isMain
         * @param indexFlag
         * @param indexType
         * @return
         */
        protected PatClsIpc getPatClsIpc(PatData patData, Object clsIpc, int ipcType, int isMain, int indexFlag, int indexType){
            PatClsIpc patClsIpc = createPatClsIpc(patData, ipcType, isMain)
            
            patClsIpc.ipcText = formatClsIpc(generateIPCMap(clsIpc))
            patClsIpc.indexFlag = indexFlag
            patClsIpc.indexType = indexType
            
            // most in ipcr 
            patClsIpc.symbolPosition = clsIpc?.'symbol-position'
            patClsIpc.clsVersion = getClsVersion(clsIpc, ipcType)
            patClsIpc.clsValue = clsIpc?.'classification-value'
            patClsIpc.actionDate = DateUtil.parseDate(WOPatDataProcess.getMapRecursively(clsIpc, 'action-date.date'))
            patClsIpc.clsLevel = clsIpc?.'classification-level'

            patClsIpc.genOffice = CountryUtil.formalCountryCode( WOPatDataProcess.getMapRecursively(clsIpc, 'generating-office.country'))
            patClsIpc.clsStatus = clsIpc?.'classification-status'
            patClsIpc.clsDataSource = clsIpc?.'classification-data-source'
            
            return patClsIpc
        }
        
        protected PatClsIpc getMainPatClsIpc(PatData patData, Object clsIpc, int indexType){
            int indexFlag = (indexType>0)? Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES:Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO
            return getPatClsIpc( patData, clsIpc, Constants.CLS_TYPE_IPC, Constants.CLS_IPC_MAIN_FLAG_YES, indexFlag, indexType)
        }
        
        /**
         * get sub ipc (not main)
         * @param patData
         * @param clsIpc
         * @param indexType
         * @return
         */
        protected PatClsIpc getSubPatClsIpc(PatData patData, Object clsIpc, int indexType){
            int indexFlag = (indexType>0)? Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES:Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO
            return getPatClsIpc( patData, clsIpc, Constants.CLS_TYPE_IPC, Constants.CLS_IPC_MAIN_FLAG_NO, indexFlag, indexType)
        }
        
        protected PatClsIpc getPatClsIpcr(PatData patData, Object clsIpc){
            return getPatClsIpc( patData, clsIpc, Constants.CLS_TYPE_IPCR,
                 Constants.CLS_IPC_MAIN_FLAG_NO, Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO, 0)
        }
        
        protected String getClsVersion(Object clsIpc, int ipcType){
            if(ipcType == Constants.CLS_TYPE_IPC){
                return getString(clsIpc, 'edition', null)
                
            }else if(ipcType == Constants.CLS_TYPE_IPCR){
                return getString(clsIpc?.'ipc-version-indicator', 'edition', null) 
            }
        }
        
        protected String formatClsIpc(Map doc){
            return WOPatDataProcess.formatClsIpc(doc)
        }

    }

    protected class WoPatClsIPCWPA extends WoPatClsIPCBasic{
        WoPatClsIPCWPA(){
            super()
            this.ipcPath = 'data.wo-bibliographic-data.classification-ipc'
            this.ipcrPath = 'data.wo-bibliographic-data.classifications-ipcr'
        }
        
        @Override
        protected void importIpc(Object clsIpc, PatData patData) {
           String mainClassification = clsIpc?.'main-classification'
           if(!!mainClassification){
               PatClsIpc patClsIpc = createPatClsIpc(patData, Constants.CLS_TYPE_IPC, Constants.CLS_IPC_MAIN_FLAG_YES)
               patClsIpc.ipcText = WOPatDataProcess.formatIpc(mainClassification)
               if(!!patClsIpc.ipcText){
                   this.patClsIpcs.add(patClsIpc)
               }
           }
        }

        @Override
        protected void importIpcr(Object clsIpcrs, PatData patData) {
            clsIpcrs?.'classification-ipcr'.each{clsIpc->
                PatClsIpc patClsIpc = getPatClsIpcr(patData, clsIpc)
                this.patClsIpcrs.add(patClsIpc)
            }
        }

        @Override
        protected Map generateIPCMap(Map doc) {
            Map ipc = new HashMap()
            ipc.'section' = getString(doc, 'section', null)
            ipc.'class' = getString(doc?.'class', 'value', null)
            ipc.'subclass' = getString(doc, 'subclass', null)
            ipc.'main-group' = getString(doc, 'main-group', null)
            ipc.'subgroup' = getString(doc, 'subgroup', null)
            
            return ipc
        }
    }
    
    protected class WoPatClsIPCLNP extends WoPatClsIPCBasic{
        WoPatClsIPCLNP(){
            super()
            ipcPath = 'data.bibliographic-data.classification-ipc'
            ipcrPath = 'data.bibliographic-data.classifications-ipcr'
        }
        
        @Override
        protected void importIpc(Object clsIpc, PatData patData){
            clsIpc?.'further-classification'.each{furtherCls->
                PatClsIpc patClsIpc = getSubPatClsIpc(patData, furtherCls, 0)
                this.patClsIpcs.add(patClsIpc)
            }
            
            Object mainCls = clsIpc?.'main-classification'
            if(!!mainCls){
                PatClsIpc patClsIpcMain = getMainPatClsIpc(patData, mainCls, 0)
                this.patClsIpcs.add(patClsIpcMain)
            } 
            
            clsIpc?.'linked-indexing-code-group'.each{linkedIdxCls->
                Object mainLinkedCls = linkedIdxCls?.'main-linked-indexing-code'
                if(!!mainLinkedCls){
                    PatClsIpc patClsIpcMain = getMainPatClsIpc(patData, mainCls, Constants.IPC_MAIN_LINKED_INDEXING)
                    this.patClsIpcs.add(patClsIpcMain)
                }
                
                linkedIdxCls?.'sub-linked-indexing-code'.each{subCls->
                    PatClsIpc patClsIpc = getSubPatClsIpc(patData, subCls, Constants.IPC_SUB_LINKED_INDEXING)
                    this.patClsIpcs.add(patClsIpc)
                }
            }
        }

        @Override
        protected void importIpcr(Object clsIpcrs, PatData patData) {
            clsIpcrs?.'classification-ipcr'.each{clsIpc->
                PatClsIpc patClsIpc = getPatClsIpcr(patData, clsIpc)
                this.patClsIpcrs.add(patClsIpc)
            }
        }

        @Override
        protected Map generateIPCMap(Map doc) {
            return doc;
        }
    }

    protected abstract class WoPersonDataBasic{
        List<PersonData> personDatas
        List<PatPersonApplicant> patPersonApplicants
        List<PatPersonInventor> patPersonInventors
        List<PatPersonAgent> patPersonAgents
        String agentPath
        String applicantPath
        String inventorPath
        boolean addMemoFlag

        WoPersonDataBasic(){
            this.personDatas = new ArrayList<PersonData>()
            this.patPersonApplicants = new ArrayList<PatPersonApplicant>()
            this.patPersonInventors = new ArrayList<PatPersonInventor>()
            this.patPersonAgents = new ArrayList<PatPersonAgent>()
            this.addMemoFlag = false
        }

        public void importPersonData(Map doc, PatData patData){
            importAgents(WOPatDataProcess.getMapRecursively(doc, agentPath), patData)
            importApplicants(WOPatDataProcess.getMapRecursively(doc, applicantPath), patData)
            importInvertors(WOPatDataProcess.getMapRecursively(doc, inventorPath), patData)
        }

        protected void importAgents(Object agents, PatData patData){
            if(!agents){
                return
            }

            agents?.'agent'.each{agent->

                String repType = getString(agent, 'rep-type', null)

                agent?.'addressbook'.eachWithIndex{addressbook, index->
                    if(index > 0){ //add memo
                        this.addMemoFlag = true
                    }

                    int personType = getPersonType(addressbook)
                    String name = getName(addressbook)
                    String lang = getLang(addressbook)

                    if(!addressbook?.'address'){  // addressbook case w/o address
                        PersonData personData = importPersonDataWOAddress(name, personType, lang, patData.lastUpdDate)
                        PatPersonAgent patPersonAgent = createPatPersonAgent(personData, patData, repType)
                        patPersonAgents.add(patPersonAgent)

                    }else{
                        addressbook?.'address'.each{address->
                            Map addressInfo = extractAddress(address)
                            PersonData personData = importPersonData( name, personType, addressInfo, lang, patData.lastUpdDate)
                            PatPersonAgent patPersonAgent = createPatPersonAgent(personData, patData, repType)
                            patPersonAgents.add(patPersonAgent)
                        }
                    }

                }

            }
        }

        protected void importApplicants(Object applicants, PatData patData){
            if(!applicants){
                return
            }

            applicants?.'applicant'.each{applicant ->
                String appCode = getString(applicant, 'app-type', null)
                String designationCode = getString(applicant, 'designation', null)
                
//                String personNationalityCountry = StringUtils.defaultString(WOPatDataProcess.getMapRecursively(applicant, 'nationality.country'))
                String personNationalityCountry = getString(applicant?.'nationality', 'country', null)
                
                applicant.'addressbook'.eachWithIndex{addressbook, index->
                    if(index > 0){ //add memo
                        this.addMemoFlag = true
                    }

                    int personType = getPersonType(addressbook)
                    String name = getName(addressbook)
                    String lang = getLang(addressbook)

                    if(!addressbook?.'address'){  // addressbook case w/o address
                        PersonData personData = importPersonDataWOAddress(name, personType, lang, patData.lastUpdDate)
                        PatPersonApplicant patPersonApplicant = createPatPersonApplicant(personData, patData, appCode, designationCode, personNationalityCountry)
                        patPersonApplicants.add(patPersonApplicant)

                    }else{
                        addressbook?.'address'.each{address->
                            Map addressInfo = extractAddress(address)
                            PersonData personData = importPersonData( name, personType, addressInfo, lang, patData.lastUpdDate)
                            PatPersonApplicant patPersonApplicant = createPatPersonApplicant(personData, patData, appCode, designationCode, personNationalityCountry)
                            patPersonApplicants.add(patPersonApplicant)
                        }
                    }
                }
            }
        }

        protected void importInvertors(Object inventors, PatData patData){
            if(!inventors){
                return
            }
            inventors?.'inventor'.each{inventor->
                String designation = getString(inventor, 'designation', null)
//                String personNationalityCountry = StringUtils.defaultString(WOPatDataProcess.getMapRecursively(inventor, 'nationality.country'))
                String personNationalityCountry = getString(inventor?.'nationality', 'country', null)

                inventor.'addressbook'.eachWithIndex{addressbook, index->
                    if(index > 0){ //add memo
                        this.addMemoFlag = true
                    }

                    String name = getName(addressbook)
                    String lang = getLang(addressbook)
                    int personType = getPersonType(addressbook)

                    if(!addressbook?.'address'){  // addressbook case w/o address
                        PersonData personData = importPersonDataWOAddress(name, personType, lang, patData.lastUpdDate)
                        PatPersonInventor patPersonInventor = createPatPersonInventor(personData, patData, designation, personNationalityCountry)
                        this.patPersonInventors.add(patPersonInventor)

                    }else{
                        addressbook?.'address'.each{address->
                            Map addressInfo = extractAddress(address)
                            PersonData personData = importPersonData( name, personType, addressInfo, lang, patData.lastUpdDate)
                            PatPersonInventor patPersonInventor = createPatPersonInventor(personData, patData, designation, personNationalityCountry)
                            this.patPersonInventors.add(patPersonInventor)
                        }
                    }
                }
            }

        }

        protected abstract String getLang(Object addressbook)

        /**
         * extract address object to a map with the following keys
         *      address, city, state, postCode, country
         * @param address
         * @return
         */
        protected abstract Map extractAddress(Object address)

        protected PatPersonInventor createPatPersonInventor(PersonData personData, PatData patData, String designation, String personNationalityCountry){
            PatPersonInventor patPersonInventor = new PatPersonInventor()
            patPersonInventor.id = new PatPersonInventorId(patData.patId, patData.defaultSourceId,  this.patPersonInventors.size()+1)
            patPersonInventor.personData = personData
            patPersonInventor.designation = designation
            patPersonInventor.personCountry = CountryUtil.formalCountryCode(personNationalityCountry)
            patPersonInventor.createDate = patData.lastUpdDate
            return patPersonInventor
        }


        protected PatPersonApplicant createPatPersonApplicant(PersonData personData, PatData patData,
                String appCode, String designationCode, String personNationalityCountry){

            PatPersonApplicant patPersonApplicant = new PatPersonApplicant()
            patPersonApplicant.id = new PatPersonApplicantId(patData.patId, patData.defaultSourceId,  this.patPersonApplicants.size()+1)
            patPersonApplicant.personData = personData
            patPersonApplicant.createDate = patData.lastUpdDate
            patPersonApplicant.appCode = appCode
            patPersonApplicant.designationCode = designationCode
            patPersonApplicant.personCountry = CountryUtil.formalCountryCode(personNationalityCountry)

            return patPersonApplicant
        }

        protected PatPersonAgent createPatPersonAgent(PersonData personData, PatData patData, String repType){

            PatPersonAgent patPersonAgent = new PatPersonAgent()
            patPersonAgent.id = new PatPersonAgentId(patData.patId, patData.defaultSourceId, this.patPersonAgents.size()+1)
            patPersonAgent.personData = personData
            patPersonAgent.repCode = repType
            patPersonAgent.createDate = patData.lastUpdDate

            return patPersonAgent
        }

        /**
         * import Person data & return the created one 
         * person_name + address + city + state + postcode + country
         * @param name
         * @param address
         * @param city
         * @param state
         * @param postcode
         * @param country
         * @param lang
         * @param date
         * @return
         */
        protected PersonData importPersonData( String name, int personType, String address, String city,
                String state, String postCode, String country, String lang, Date date){
                
            // TODO repair table postcode schema
            if(!!postCode && postCode.length()>50){
                throw new Exception("postCode longer than 50");
            }
                
            PersonData personData = new PersonData()
            personData.personName = name
            personData.personType = personType
            personData.address = address
            personData.state = state
            personData.city = city
            personData.postcode = postCode
            personData.country = CountryUtil.formalCountryCode(country)
            personData.lang = lang
            personData.personFacet = StringUtil.personFacetWrap(
                StringUtils.defaultString(personData.personName)+
                StringUtils.defaultString(personData.address)+
                StringUtils.defaultString(personData.city)+
                StringUtils.defaultString(personData.state)+
                StringUtils.defaultString(personData.postcode)+
                StringUtils.defaultString(personData.country))
            
            personData.createDate = personData.lastUpdDate = date

            // find facet & personID
            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, this.personDatas);
            
            if (existsData != null) {
                personData = existsData;
            } else {
                personData.personId = UUIDUtil.generateUUID();
                this.personDatas.add(personData)
            }

            return personData
        }

        /**
         *  addressInfo contains keys: address city state postCode country
         */
        protected PersonData importPersonData(String name, int personType, Map addressInfo, String lang, Date date){
            return importPersonData( name, personType, addressInfo.'address',
                    addressInfo.'city',
                    addressInfo.'state',
                    addressInfo.'postCode',
                    addressInfo.'country',
                    lang,
                    date)
        }

        /**
         * import person w/o address
         * @param name
         * @param personType
         * @param lang
         * @param date
         * @return
         */
        protected PersonData importPersonDataWOAddress(String name, int personType, String lang, Date date){
            return importPersonData( name, personType, '', '', '', '', '', lang, date)
        }


        /**
         *  assumption:
         *  1. WPA no orgname & last-name
         *  2. only 1 name in the name array     
         * @param addressbook
         * @return
         */
        protected String getName(Object addressbook){
//            String name = StringUtils.defaultString(WOPatDataProcess.getMapRecursively(addressbook, 'name.0.value'))
            String name = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(addressbook, 'name.0.value'), null)
            if(!name){
//                name = StringUtils.defaultString(WOPatDataProcess.getMapRecursively(addressbook, 'orgname.0'))
                name = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(addressbook, 'orgname.0'), null)                
            }
            return name
        }

        protected int getPersonType(Map addressbook){
            if(addressbook.containsKey('first-name') || addressbook.containsKey('last-name')){
                return Constants.PERSON_TYPE_PERSONAL

            }else if(addressbook.containsKey('orgname')){
                return Constants.PERSON_TYPE_ORG

            }else{
                return Constants.PERSON_TYPE_NONE
            }
        }
    }

    protected class WoPersonDataLNP extends WoPersonDataBasic{

        WoPersonDataLNP(){
            super()
            this.agentPath = 'data.bibliographic-data.parties.agents'
            this.applicantPath = 'data.bibliographic-data.parties.applicants'
            this.inventorPath = 'data.bibliographic-data.parties.inventors'
        }


        @Override
        protected Map extractAddress(Object address) {
            Map map = new HashMap()
            map.'address' = getAddress(address)
            map.'city' = getString(address, 'city', null)
            map.'state' = getString(address, 'state', null)
            map.'postCode' = getString(address, 'postCode', null)
            map.'country' = CountryUtil.formalCountryCode(getString(address, 'country', null))
            return map
        }

        @Override
        protected String getLang(Object addressbook){
            return WOPatDataProcess.normalizeLang(getString(addressbook, 'lang', null))
        }

        /**
         * get address from address object
         * @param addressbook
         * @return
         */
        protected String getAddress(Object address){
            String result = ""
            String curAddress

            for(int i=1; i<6; i++){
                curAddress = 'address-' + i.toString()
                result += (!!address?."$curAddress")?  address?."$curAddress" + " " : ''
            }

            result += (!!address?."mailcode")? address?."mailcode" + " " : ''
            result += (!!address?."pobox")? address?."pobox" + " " : ''
            result += (!!address?."room")? address?."room" + " " : ''
            result += (!!address?."address-floor")? address?."address-floor" + " " : ''
            result += (!!address?."building")? address?."building" + " " : ''
            result += (!!address?."street")? address?."street" + " " : ''

            result = (!!result.trim())? result: null
            
            return result
        }

    }

    protected class WoPersonDataWPA extends WoPersonDataBasic{

        WoPersonDataWPA(){
            super()
            agentPath = 'data.wo-bibliographic-data.parties.agents'
            applicantPath = 'data.wo-bibliographic-data.parties.applicants'
            inventorPath = 'data.wo-bibliographic-data.parties.inventors'
        }


        @Override
        protected String getLang(Object addressbook) {
            return getString(addressbook, 'lang', null)
        }

        @Override
        protected Map extractAddress(Object address){
            Map map = new HashMap()
            map.'address' = getAddress(address)
            map.'city' = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(address, 'city.0'), null)
            map.'state' = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(address, 'state.0'), null)
            map.'postCode' = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(address, 'postcode.0'), null)
            map.'country' = StringUtils.defaultIfBlank(WOPatDataProcess.getMapRecursively(address, 'country.0'), null)
            
            return map
        }

        /**
         * get address from address object
         * @param addressbook
         * @return
         */
        protected String getAddress(Object address){
            String result = ""
            String curAddress

            for(int i=1; i<6; i++){
                curAddress = 'address-' + i.toString()
                result += (!!address?."$curAddress")?  address?."$curAddress"[0] + " " : ''
            }

            result += (!!address?."mailcode")? address?."mailcode"[0] + " " : ''
            result += (!!address?."pobox")? address?."pobox"[0] + " " : ''
            result += (!!address?."room")? address?."room"[0] + " " : ''
            result += (!!address?."address-floor")? address?."address-floor"[0] + " " : ''
            result += (!!address?."building")? address?."building"[0] + " " : ''
            result += (!!address?."street")? address?."street"[0] + " " : ''

            result = (!!result.trim())? result: null
            return result
        }
    }



    protected class WoPatRefRelatedDocumentsLNP{
        List<PatRefRelatedParent> patRefRelatedParents
        List<PatRefRelatedChild> patRefRelatedChilds

        WoPatRefRelatedDocumentsLNP(){
            patRefRelatedParents = new ArrayList<PatRefRelatedParent>()
            patRefRelatedChilds = new ArrayList<PatRefRelatedChild>()
        }

        public void importRelatedDocuments(Map doc, PatData patData){
            Object obj = WOPatDataProcess.getMapRecursively(doc, 'data.bibliographic-data.related-documents')

            // check type
            if(!!obj?."division"){
                importGenericPatRefRelated(obj?."division", patData,  Constants.RELATED_TYPE_CODE_DIVISION)
            }

            if(!!obj?."continuation-in-part"){
                importGenericPatRefRelated(obj?."continuation-in-part", patData,  Constants.RELATED_TYPE_CODE_CONTINUATION_IN_PART)
            }

            if(!!obj?."continuation"){
                importGenericPatRefRelated(obj?."continuation", patData,  Constants.RELATED_TYPE_CODE_CONTINUATION)
            }

            if(!!obj?."related-publication"){
                importRelatedPublicationPatRef(obj?."related-publication", patData)
            }


        }

        private void importRelatedPublicationPatRef(List relationList, PatData patData){
            relationList.each{relatedPublication ->
                PatRefRelatedParent patRefRelatedParent =
                        getRelatedPublicationPatRefRelatedParent( relatedPublication?.'document-id'[0], patData)
                patRefRelatedParent = normalizePatRefRelatedParent(patRefRelatedParent)
                patRefRelatedParents.add(patRefRelatedParent)
            }
        }

        private void importGenericPatRefRelated(List relationList, PatData patData, int relatedType){
            relationList.each{it ->
                PatRefRelatedParent patRefRelatedParent =
                        getGenericPatRefRelatedParent(it?."relation"?."parent-doc"?."document-id"[0], patData, relatedType)
                patRefRelatedParent = normalizePatRefRelatedParent(patRefRelatedParent)
                patRefRelatedParents.add(patRefRelatedParent)

                // child reference
                it?."relation"?."child-doc"?."document-id".each{ childDoc->
                    PatRefRelatedChild patRefRelatedChild =
                            getGenericPatRefRelatedChild(childDoc, patData, relatedType)
                    patRefRelatedChild.parentItem = patRefRelatedParent.id.item
                    patRefRelatedChild = normalizePatRefRelatedChild(patRefRelatedChild)
                    patRefRelatedChilds.add(patRefRelatedChild)
                }
            }
        }


        private PatRefRelatedChild createPatRefRelatedChild(PatData patData){
            PatRefRelatedChild patRefRelatedChild = new PatRefRelatedChild()
            patRefRelatedChild.id = new PatRefRelatedChildId(patData.patId, patData.defaultSourceId, 0)
            patRefRelatedChild.createDate = patData.lastUpdDate
            return patRefRelatedChild
        }

        private PatRefRelatedChild getGenericPatRefRelatedChild(Map appDocId, PatData patData, int relatedType){
            PatRefRelatedChild patRefRelatedChild = createPatRefRelatedChild(patData)
            patRefRelatedChild.relatedType = relatedType

            patRefRelatedChild.rawAppNo = getString(appDocId, 'doc-number')
            patRefRelatedChild.rawAppDate = getString(appDocId, 'date')
            patRefRelatedChild.appDate = DateUtil.parseDate(patRefRelatedChild.rawAppDate)
            patRefRelatedChild.appCountry = CountryUtil.formalCountryCode( getString(appDocId, 'country'))

            return patRefRelatedChild
        }

        private PatRefRelatedChild normalizePatRefRelatedChild(PatRefRelatedChild patRefRelatedChild){
            // TODO normalize & query SQL
            patRefRelatedChild.id.item = this.patRefRelatedChilds.size() + 1
            return patRefRelatedChild
        }

        private PatRefRelatedParent normalizePatRefRelatedParent(PatRefRelatedParent patRefRelatedParent){
            // TODO normalize & query SQL
            patRefRelatedParent.id.item = this.patRefRelatedParents.size() +1
            return patRefRelatedParent
        }

        private PatRefRelatedParent createPatRefRelatedParent(PatData patData){
            PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent()
            patRefRelatedParent.id = new PatRefRelatedParentId(patData.patId, patData.defaultSourceId, 0)
            patRefRelatedParent.createDate = patData.lastUpdDate
            return patRefRelatedParent
        }

        private PatRefRelatedParent getGenericPatRefRelatedParent(Map appDocId, PatData patData, int relatedType){
            PatRefRelatedParent patRefRelatedParent = createPatRefRelatedParent(patData)
            patRefRelatedParent.relatedType = relatedType

            patRefRelatedParent.rawAppNo = getString(appDocId, 'doc-number')
            patRefRelatedParent.rawAppDate = getString(appDocId, 'date')
            patRefRelatedParent.appDate = DateUtil.parseDate(patRefRelatedParent.rawAppDate)
            patRefRelatedParent.appCountry = CountryUtil.formalCountryCode(getString(appDocId, 'country'))

            return patRefRelatedParent
        }

        private PatRefRelatedParent getRelatedPublicationPatRefRelatedParent(Map patDocId, PatData patData){
            PatRefRelatedParent patRefRelatedParent = createPatRefRelatedParent(patData)
            patRefRelatedParent.relatedType = Constants.RELATED_TYPE_CODE_RELATED_PUBLICATION

            patRefRelatedParent.rawDocNo = getString(patDocId, 'doc-number')
            patRefRelatedParent.rawDocDate = getString(patDocId, 'date')
            patRefRelatedParent.docDate = DateUtil.parseDate(patRefRelatedParent.rawDocDate)
            patRefRelatedParent.kindCode = getString(patDocId, 'kind')
            patRefRelatedParent.docCountry = CountryUtil.formalCountryCode( getString(patDocId, 'country'))

            return patRefRelatedParent
        }


    }



    protected abstract class WoPatRefPriorityBasic{
        protected static String path

        public List<PatRefPriority> getPatRefPrioritys(Map doc, PatData patData){
            List<PatRefPriority> patRefPrioritys = new ArrayList<PatRefPriority>();

            BasicDBList priorityClaims = WOPatDataProcess.getMapRecursively(doc, path)
            if(!priorityClaims){ // w/o priority claim
                return patRefPrioritys
            }

            for(int i=0; i<priorityClaims.size(); i++){
                PatRefPriority patRefPriority = getPatRefPriority(priorityClaims[i], patData)
                if(!patRefPriority){
                    continue
                } 
                patRefPriority.id.item = patRefPrioritys.size()+1

                // TODO Querry and check
                patRefPrioritys.add(patRefPriority)
            }

            return patRefPrioritys
        }

        protected PatRefPriority getPatRefPriority(Map priorityClaim, PatData patData){
            if(priorityClaim?.'kind' != 'national'){ // only national form retain
                return null
            }
            
            PatRefPriority patRefPriority = createPatRefPriority(patData)
            // necessary
            patRefPriority.rawAppNo = priorityClaim.'doc-number'

            // optional
            patRefPriority.rawAppDate = priorityClaim.'date'
            patRefPriority.appDate = DateUtil.parseDate( patRefPriority.rawAppDate)
            patRefPriority.country = CountryUtil.formalCountryCode( priorityClaim?.country)

            patRefPriority.priType = Constants.CITED_BY_TYPE_UNKNOW

            return patRefPriority
        }

        public PatRefPriority createPatRefPriority(PatData patData){
            PatRefPriority patRefPriority = new PatRefPriority()
            patRefPriority.id = new PatRefPriorityId(patData.patId, patData.defaultSourceId, 0)
            patRefPriority.createDate = patData.lastUpdDate
            return patRefPriority
        }
    }

    protected class WoPatRefPriorityWPA extends WoPatRefPriorityBasic{

        public WoPatRefPriorityWPA(){
            this.path = 'data.wo-bibliographic-data.wo-priority-info.priority-claim';
        }
    }

    protected class WoPatRefPriorityLNP extends WoPatRefPriorityBasic{

        public WoPatRefPriorityLNP(){
            this.path = 'data.bibliographic-data.priority-claims.priority-claim';
        }
    }



    protected abstract class WoPatRefPctBasic{
        public abstract PatRefPct getPatRefPct(Map doc, PatData patData, AppData appData)

        protected PatRefPct createPatRefPct(PatData patData, AppData appData){
            PatRefPct patRefPct = new PatRefPct()
            // from patData
            patRefPct.publicPatId = patRefPct.patId = patData.patId
            patRefPct.publicNo = patData.docNo
            patRefPct.rawPublicNo = patData.rawDocNo
            patRefPct.rawAppNo = patData.rawAppNo
            patRefPct.appNo = appData.appNo
            patRefPct.rawPublicDate = new SimpleDateFormat("yyyyMMdd").format(patData.docDate)
            patRefPct.publicDate = patData.docDate
            patRefPct.publicGazetteNo = patData.gazetteNo
            patRefPct.publicGazetteDate = patData.gazettePublicDate
            patRefPct.createDate = patData.lastUpdDate

            // from appData
            patRefPct.rawAppDate = new SimpleDateFormat("yyyyMMdd").format(appData.appDate)
            patRefPct.appDate = appData.appDate

            return patRefPct
        }
    }

    protected class WoPatRefPctLNP extends WoPatRefPctBasic{
        @Override
        public PatRefPct getPatRefPct(Map doc, PatData patData, AppData appData){
            PatRefPct patRefPct = createPatRefPct(patData, appData)
            patRefPct.pct371c124Date = DateUtil.parseDate(WOPatDataProcess.getMapRecursively(doc, 'data.bibliographic-data.pct-or-regional-filing-data.document-id.0.date'))
            return patRefPct
        }
    }

    protected class WoPatRefPctWPA extends WoPatRefPctBasic{

        @Override
        public PatRefPct getPatRefPct(Map doc, PatData patData, AppData appData) {
            PatRefPct patRefPct = createPatRefPct(patData, appData)
            return patRefPct;
        }

    }


    protected class WoPatRefCitedNplLNP{
        public List<PatRefCitedNpl> getPatRefCitedNpls(Map doc, PatData patData){
            List<PatRefCitedNpl> patRefCitedNplList = new ArrayList<PatRefCitedNpl>()

            BasicDBList citations = WOPatDataProcess.getMapRecursively( doc, 'data.bibliographic-data.references-cited.citation')
            if(!citations){ // w/o citation
                return patRefCitedNplList
            }

            for(int i=0; i<citations.size(); i++){
                if(citations[i] && citations[i]?.'nplcit'){
                    PatRefCitedNpl patRefCitedNpl = createPatRefCitedNpl(WOPatDataProcess.getMapRecursively(citations[i], 'nplcit.0'), patData)
                    patRefCitedNpl.id.item = patRefCitedNplList.size() + 1
                    patRefCitedNplList.add(patRefCitedNpl)
                }
            }
            return patRefCitedNplList
        }

        private PatRefCitedNpl createPatRefCitedNpl(Map doc, PatData patData){

            PatRefCitedNpl patRefCitedNpl = new PatRefCitedNpl();
            patRefCitedNpl.id = new PatRefCitedNplId(patData.patId, patData.defaultSourceId, 0)
            patRefCitedNpl.createDate = patData.lastUpdDate

            patRefCitedNpl.nplJson = doc.toString()
            patRefCitedNpl.nplText = WOPatDataProcess.getMapRecursively(doc, 'text.0')
            patRefCitedNpl.citedByType = Constants.CITED_BY_TYPE_UNKNOW
            return patRefCitedNpl
        }
    }


    protected class WoPatRefCitedLNP{

        public List<PatRefCited> getPatRefCiteds(Map doc, PatData patData){
            List<PatRefCited> patRefCitedList = new ArrayList<PatRefCited>();

            BasicDBList citations = WOPatDataProcess.getMapRecursively( doc, 'data.bibliographic-data.references-cited.citation')
            if(!citations){ // w/o citation
                return patRefCitedList
            }

            for(int i=0; i<citations.size(); i++){
                if(citations[i] && citations[i]?.'patcit'){
                    PatRefCited patRefCitedNpl = createPatRefCited(WOPatDataProcess.getMapRecursively(citations[i], 'patcit.0'), patData)
                    patRefCitedNpl.id.item = patRefCitedList.size() + 1
                    patRefCitedList.add(patRefCitedNpl)
                }
            }
            return patRefCitedList
        }

        private PatRefCited createPatRefCited(Map doc, PatData patData){

            PatRefCited patRefCited = new PatRefCited();
            patRefCited.id = new PatRefCitedId(patData.patId, patData.defaultSourceId, 0)
            patRefCited.createDate = patData.lastUpdDate

            // necessary
            patRefCited.rawDocNo = doc.'document-id'.'0'.'doc-number'

            // date, country, kind may miss
            patRefCited.country = CountryUtil.formalCountryCode(WOPatDataProcess.getMapRecursively(doc, 'document-id.0.country'))
            patRefCited.kindCode = WOPatDataProcess.getMapRecursively(doc, 'document-id.0.kind')
            patRefCited.rawDocDate = WOPatDataProcess.getMapRecursively(doc, 'document-id.0.date')
            patRefCited.citedByType = Constants.CITED_BY_TYPE_UNKNOW
            patRefCited.docDate = DateUtil.parseDate(patRefCited.'rawDocDate')

            // TODO normalize doc number
            patRefCited.docNo = patRefCited.rawDocNo

            // cited_pat_id
            // 引證資料是否存在於pat_data中,存在的話寫入pat_id,使用country,docnum,kind至pat_data查詢,寫入對應到的pat_id
//            List<PatData> citedPatDataList = PatDataHelper.queryByCondition(patRefCited.country, patRefCited.docNo, "", patRefCited.docDate);
//            if (!!citedPatDataList) {
//                if (citedPatDataList.size() > 1) {
//                    throw new Exception("cited data query over 1");
//                }
//                patRefCited.citedPatId = citedPatDataList.get(0).patId;
//            }

            return patRefCited
        }
    }


    protected abstract class WoPatRawBasic{
        protected PatRawWo getWoPatRawWo(DBObject doc, Date date){
            PatRawWo patRawWo = createPatRawWo(doc.'docId', date)
            Document repiredDoc = new Document()
            repiredDoc.putAll(doc.'data')
            patRawWo.rawJson = toJsonString(repiredDoc)

            return patRawWo
        }

        protected abstract String toJsonString(Document doc)
        protected PatRawWo createPatRawWo(String docId, Date date){
            PatRawWo patRawWo = new PatRawWo()
            patRawWo.rawId = docId
            patRawWo.patId = PatNumberUtil.marshallidToPatidWO(docId)
            patRawWo.xmlType = StringUtils.substringAfterLast(docId, '/')
            patRawWo.createDate = patRawWo.lastUpdDate = date
            return patRawWo
        }

        /**
         * remove fields for pat_data_raw table 
         * and recover the fields after json string has been generated         * 
         * @param doc : bson document to be the json string 
         * @param entrys : path of the map, separated by '/'. EX: key1/key2/key3
         * @return : result json string
         */
        protected String standardJson(Document doc, List<String> entrys){
            List<Object> objs = new ArrayList<Object>(entrys.size())

            entrys.eachWithIndex{entry, i->
                List<String> tokens = StringUtils.split(entry, '/')
                Object tmpcur = doc
                tokens.eachWithIndex{token, j->
                    if(!tmpcur){
                        return
                    }else if(j == tokens.size()-1){
                        objs[i] = tmpcur.get(token)
                        tmpcur.put(token, null)
                    }
                    tmpcur = getObject(tmpcur, token)
                }
            }

            String resultJson = doc.toJson()

            entrys.eachWithIndex{entry, i->
                List<String> tokens = StringUtils.split(entry, '/')
                Object tmpcur = doc
                tokens.eachWithIndex{token, j->
                    if(!tmpcur){
                        return
                    }else if(j == tokens.size()-1){
                        tmpcur.put(token, objs[i])
                    }
                    tmpcur = getObject(tmpcur, token)
                }
            }

            return resultJson

        }
    }

    protected class WoPatRawWPA extends WoPatRawBasic{
        @Override
        protected String toJsonString(Document doc) {
            return standardJson(doc, ['abstract', 'wo-bibliographic-data/invention-title'])
        }

    }

    protected class WoPatRawOPA extends WoPatRawBasic{
        @Override
        protected String toJsonString(Document doc) {
            return standardJson(doc, ['claims', 'description'])
        }
    }

    protected class WoPatRawWAB extends WoPatRawBasic{
        @Override
        protected String toJsonString(Document doc) {
            return standardJson(doc, ['claims', 'wo-amended-claims/amend-body/claims', 'description'])
        }
    }

    protected class WoPatRawLNP extends WoPatRawBasic{

        @Override
        protected String toJsonString(Document doc) {
            return standardJson(doc, ['abstract', 'bibliographic-data/invention-title', 'claims', 'description'])
        }
    }


    protected abstract class WoPatDataDescsBasic{
        protected abstract List<PatDataDesc> getPatDataDescs(Map doc, Date date)

        protected PatDataDesc createPatDataDesc(String docId, Date date){
            PatDataDesc patDataDesc = new PatDataDesc();
            PatDataDescId id = new PatDataDescId();
            id.patId = PatNumberUtil.marshallidToPatidWO(docId)
            id.sourceId = Constants.SOURCE_ID_WO_FULLTEXT
            patDataDesc.id = id;
            patDataDesc.createDate = patDataDesc.lastUpdDate = date
            return patDataDesc
        }

    }

    protected class WoPatDataDescsOPA extends WoPatDataDescsBasic{

        @Override
        protected List<PatDataDesc> getPatDataDescs(Map doc, Date date) {
            Object obj = WOPatDataProcess.getMapRecursively(doc, 'data.description')

            if(!obj){
                return null;
            }

            List<PatDataDesc> patDataDescs = new ArrayList<PatDataDesc>()
            PatDataDesc patDataDesc = createPatDataDesc(doc.docId, date)
            patDataDesc.id.lang = getString(obj, 'lang').toLowerCase()
            patDataDesc.description = getString(obj, 'CData')
            patDataDescs.add(patDataDesc)
            return patDataDescs
        }
    }

    protected class WoPatDataDescsWAB extends WoPatDataDescsBasic{
        @Override
        protected List<PatDataDesc> getPatDataDescs(Map doc, Date date) {
            Object obj = WOPatDataProcess.getMapRecursively(doc, 'data.description')
            if(!obj){
                return null
            }

            List<PatDataDesc> patDataDescs = new ArrayList<PatDataDesc>()
            PatDataDesc patDataDesc = createPatDataDesc(doc.docId, date)
            patDataDesc.id.lang = WOPatDataProcess.getMapRecursively(doc, 'data.lang')
            patDataDesc.description = getString(obj, 'CData')
            patDataDescs.add(patDataDesc)

            return patDataDescs
        }
    }

    protected class WoPatDataDescsLNP extends WoPatDataDescsBasic{

        @Override
        protected List<PatDataDesc> getPatDataDescs(Map doc, Date date) {
            BasicDBList obj = WOPatDataProcess.getMapRecursively(doc, 'data.description')

            if(!obj){
                return null
            }

            List<PatDataDesc> patDataDescs = new ArrayList<PatDataDesc>()
            for(int i=0; i<obj.size(); i++){
                PatDataDesc patDataDesc = createPatDataDesc(doc.docId, date)
                patDataDesc.id.lang = WOPatDataProcess.normalizeLang(getString(obj[i], 'lang'))
                patDataDesc.description = getString(obj[i], 'CData')
                patDataDescs.add(patDataDesc)
            }

            return patDataDescs;
        }

    }

    /**
     * for generating PatDataClaims 
     */
    protected abstract class WoPatDataClaimsBasic{
        protected abstract List<PatDataClaims> getPatDataClaims(Map doc, Date date)

        protected PatDataClaims createPatDataClaims(String docId, Date date){
            PatDataClaims patDataClaims = new PatDataClaims();

            PatDataClaimsId id = new PatDataClaimsId()
            id.patId = PatNumberUtil.marshallidToPatidWO(docId)
            id.sourceId = Constants.SOURCE_ID_WO_FULLTEXT

            patDataClaims.id = id;
            patDataClaims.createDate = patDataClaims.lastUpdDate = date
            return patDataClaims
        }
    }

    protected class WoPatDataClaimsLNP extends WoPatDataClaimsBasic{
        @Override
        protected List<PatDataClaims> getPatDataClaims(Map doc, Date date) {
            BasicDBList obj = WOPatDataProcess.getMapRecursively(doc, 'data.claims')

            if(!obj){
                // without abstract
                return null
            }

            List<PatDataClaims> patDataClaims = new ArrayList<PatDataClaims>()
            for(int i=0; i<obj.size(); i++){
                PatDataClaims patDataClaim = createPatDataClaims( doc.docId, date)
                patDataClaim.id.lang = WOPatDataProcess.normalizeLang(getString(obj[i], 'lang'))
                patDataClaim.claims = getString(obj[i], 'CData')
                patDataClaims.add(patDataClaim)
            }
            return patDataClaims
        }

        protected List<PatDataClaims> getPatDataClaims(Map doc, PatData patData) {
            return getPatDataClaims(doc, patData.lastUpdDate)
        }

    }

    protected class WoPatDataClaimsWAB extends WoPatDataClaimsBasic{

        @Override
        protected List<PatDataClaims> getPatDataClaims(Map doc,  Date date) {

            Object obj = WOPatDataProcess.getMapRecursively(doc, 'data.claims')
            if(!obj){
                return null
            }

            List<PatDataClaims> patDataClaims = new ArrayList<PatDataClaims>()
            PatDataClaims patDataClaim = createPatDataClaims(doc.'docId', date)
            patDataClaim.id.lang = WOPatDataProcess.getMapRecursively(doc, 'data.lang')
            patDataClaim.claims = WOPatDataProcess.getMapRecursively(doc, 'data.claims.CData')
            patDataClaim.amendedClaims = WOPatDataProcess.getMapRecursively(doc, 'data.wo-amended-claims.amend-body.claims.CData')
            patDataClaims.add(patDataClaim)

            return patDataClaims
        }
    }

    protected class WoPatDataClaimsOPA extends WoPatDataClaimsBasic{

        @Override
        protected List<PatDataClaims> getPatDataClaims(Map doc,  Date date){

            BasicDBList obj = WOPatDataProcess.getMapRecursively(doc, 'data.claims')

            if(!obj){
                return null
            }

            List<PatDataClaims> patDataClaims = new ArrayList<PatDataClaims>()

            for(int i=0; i<obj.size(); i++){
                PatDataClaims patDataClaim = createPatDataClaims( doc.docId, date)
                patDataClaim.id.lang = getString(obj[i], 'lang').toLowerCase()
                patDataClaim.claims = getString(obj[i], 'CData')
                patDataClaims.add(patDataClaim)
            }
            return patDataClaims
        }
    }



    /**
     * for generating PatDataTitle 
     * @author yeatschung
     */
    protected abstract class WoPatDataTitleBasic{
        protected abstract List<PatDataTitle> getPatDataTitles(Map doc, PatData patData)

        protected PatDataTitle createPatDataTitle(PatData patData){
            PatDataTitle patDataTitle = new PatDataTitle()
            PatDataTitleId id = new PatDataTitleId();
            id.patId = patData.patId
            id.sourceId = patData.defaultSourceId

            patDataTitle.id = id
            patDataTitle.createDate = patData.createDate
            patDataTitle.lastUpdDate = patData.lastUpdDate
            return patDataTitle
        }
    }

    protected class WoPatDataTitleWPA extends WoPatDataTitleBasic{
        @Override
        protected List<PatDataTitle> getPatDataTitles(Map doc, PatData patData){
            BasicDBList obj = WOPatDataProcess.this.getMapRecursively(doc, 'data.wo-bibliographic-data.invention-title')

            if(!obj){
                // without Title
                return null
            }

            List<PatDataTitle> patDataTitles = new ArrayList<PatDataTitle>()

            for(int i=0; i<obj.size(); i++){
                PatDataTitle patDataTitle = createPatDataTitle(patData)
                patDataTitle.id.lang = getString(obj[i], 'lang')
                patDataTitle.title = getString(obj[i], 'CData')
                patDataTitles.add(patDataTitle)
            }
            return patDataTitles
        }
    }

    protected class WoPatDataTitleLNP extends WoPatDataTitleBasic{
        @Override
        protected List<PatDataTitle> getPatDataTitles(Map doc, PatData patData) {
            BasicDBList obj = WOPatDataProcess.this.getMapRecursively(doc, 'data.bibliographic-data.invention-title')

            if(!obj){
                // without Title
                return null
            }

            List<PatDataTitle> patDataTitles = new ArrayList<PatDataTitle>()

            for(int i=0; i<obj.size(); i++){
                PatDataTitle patDataTitle = createPatDataTitle(patData)
                patDataTitle.id.lang = WOPatDataProcess.normalizeLang(getString(obj[i], 'lang'))
                patDataTitle.title = getString(obj[i], 'CData')
                patDataTitles.add(patDataTitle)
            }
            return patDataTitles
        }
    }


    /**
     * for generating WoAppData
     */
    protected abstract class WoAppDataBasic{
        protected abstract AppData getAppData(Map doc, PatData patData)
        protected AppData createAppData(PatData patData){
            AppData appData = new AppData();
            appData.appId = patData.appId
            appData.country = CountryUtil.formalCountryCode(patData.country)
            appData.appNo = PatNumberUtil.getAppNoWO(patData.rawAppNo)
            appData.createDate = patData.createDate
            appData.lastUpdDate = patData.lastUpdDate
            return appData
        }
    }

    protected class WoAppDataWPA extends WoAppDataBasic{
        @Override
        protected AppData getAppData(Map doc, PatData patData) {
            AppData appData = createAppData(patData)
//            appData.appDate = WOPatDataProcess.getDate(WOPatDataProcess.getMapRecursively(doc, 'data.wo-bibliographic-data.application-reference.document-id.date'))
            appData.appDate = WOPatDataProcess.getDate(doc.'data'.'wo-bibliographic-data'.'application-reference'.'document-id'.'date')
            
            appData.appLang = WOPatDataProcess.getMapRecursively(doc, 'data.wo-bibliographic-data.application-reference.document-id.lang')
            return appData
        }
    }

    protected class WoAppDataLNP extends WoAppDataBasic{
        @Override
        protected AppData getAppData(Map doc, PatData patData) {
            AppData appData = createAppData(patData)
            appData.appDate = WOPatDataProcess.getDate(doc.'data'.'bibliographic-data'.'application-reference'.'document-id'.'0'.'date')
            
            appData.appLang = WOPatDataProcess.normalizeLang(getAppLang(WOPatDataProcess.getMapRecursively(doc, 'data.bibliographic-data')))
            return appData
        }

        protected String getAppLang(Map biblioData){
            if(biblioData.containsKey('language-of-filing')){
                return biblioData.'language-of-filing'
            }else if(biblioData.containsKey('lang')){
                return biblioData.'lang'
            }
            return null
        }
    }

    /**
     * for generating PatDataBrief 
     * @author yeatschung
     */
    protected abstract class WoPatDataBriefBasic{

        protected PatDataBrief createPatDataBrief(PatData patData){
            PatDataBrief patDataBrief = new PatDataBrief()
            PatDataBriefId id = new PatDataBriefId();
            id.patId = patData.patId;
            id.sourceId = patData.defaultSourceId;

            patDataBrief.id = id
            patDataBrief.lastUpdDate = patDataBrief.createDate = patData.lastUpdDate
            return patDataBrief
        }

        protected abstract List<PatDataBrief> getPatDataBriefList(Map doc, PatData patData)
    }

    protected class WoPatDataBriefWPA extends WoPatDataBriefBasic{

        @Override
        protected List<PatDataBrief> getPatDataBriefList(Map doc, PatData patData){
            BasicDBList obj = WOPatDataProcess.this.getMapRecursively(doc, 'data.abstract')

            if(!obj){
                // without abstract
                return null
            }

            List<PatDataBrief> patDataBriefs = new ArrayList<PatDataBrief>()
            for(int i=0; i<obj.size(); i++){
                PatDataBrief patDataBrief = createPatDataBrief(patData)
                patDataBrief.id.lang = getString(obj[i], 'lang')
                patDataBrief.brief = getString(obj[i], 'CData')
                patDataBriefs.add(patDataBrief)
            }
            return patDataBriefs
        }
    }

    protected class WoPatDataBriefLNP extends WoPatDataBriefBasic{

        @Override
        protected List<PatDataBrief> getPatDataBriefList(Map doc, PatData patData) {
            BasicDBList obj = WOPatDataProcess.this.getMapRecursively(doc, 'data.abstract')

            if(!obj){
                // without abstract
                return null
            }

            List<PatDataBrief> patDataBriefs = new ArrayList<PatDataBrief>()
            for(int i=0; i<obj.size(); i++){
                PatDataBrief patDataBrief = createPatDataBrief(patData)
                patDataBrief.id.lang = WOPatDataProcess.normalizeLang(getString(obj[i], 'lang'))
                patDataBrief.brief = getString(obj[i], 'CData')
                patDataBriefs.add(patDataBrief)
            }
            return patDataBriefs
        }
    }



    /**
     * for generating PatData
     * @author yeatschung
     */
    protected abstract class WoPatDataBasic{

        public PatData getPatData(Map doc, Date date, Map oldData) throws Exception{
            PatData patData = getPatData(doc, date)
            
            if(oldData?.'firstImagePageFlag' != null){
                patData.firstImgFlag = (oldData.'firstImagePageFlag')? 1:0
            }
            patData.totalPages = oldData?.'filePageNumber'
            return patData
        }
        
        
        public abstract PatData getPatData(Map doc, Date date) throws Exception

        protected PatData createPatData(Date date){
            PatData patData = new PatData()
            patData.country = Constants.WO_PAT_COUNTRY
            patData.stat = Constants.PAT_STAT_PUBLIC
            patData.patType = Constants.WO_PAT_TYPE
            patData.defaultSourceId = Constants.SOURCE_ID_WO_FULLTEXT
            patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES
            patData.docdbFlag = Constants.DOCDB_FLAG_NO
            patData.cryptoFlag = Constants.CRYPTO_FLAG_NO
            patData.withdrawFlag = Constants.WITHDRAW_FLAG_FALSE
            patData.deleteFlag = Constants.DELETE_FLAG_NO
            patData.truncateFlag = Constants.TRUNCATE_FLAG_FALSE
            patData.createDate = patData.lastUpdDate = date
            return patData
        }

        protected PatData createPatData(Map doc, Date date){
            PatData patData = createPatData(date)
            patData.patId = PatNumberUtil.marshallidToPatidWO(doc.'docId')
            patData.docNo = PatNumberUtil.marshallidToDocNoWO(doc.'docId')
            patData.docDate = doc['doDate']
            patData.gazettePublicDate = doc['doDate']
            patData.kindCode = doc['kindcode']
            return patData
        }
    }

    protected class WoPatDataWPA extends WoPatDataBasic{
        
        @Override
        public PatData getPatData(Map doc, Date date) throws Exception {
            PatData patData = createPatData( doc, date)
            // necessary
            patData.rawDocNo = doc.'data'.'wo-bibliographic-data'.'publication-reference'.'document-id'.'doc-number'
            patData.rawAppNo = doc.'data'.'wo-bibliographic-data'.'application-reference'.'document-id'.'doc-number'
            patData.oriLang = doc.'data'.'wo-bibliographic-data'.'publication-reference'.'document-id'.'lang'
            patData.appId = PatNumberUtil.getAppIdWO(patData.rawAppNo)

            // optional
            BasicDBList tmpDocPage = WOPatDataProcess.getMapRecursively(doc, 'data.drawings.doc-page')
            patData.figurePages = (!!tmpDocPage)? tmpDocPage.size(): null
            patData.pageNoOfFigure = getFirstPage(tmpDocPage)
            patData.pageNoOfClaim = getFirstPage(WOPatDataProcess.getMapRecursively(doc, 'data.claims.doc-page'))
            patData.pageNoOfDesc = getFirstPage(WOPatDataProcess.getMapRecursively(doc, 'data.description.doc-page'))
            patData.pageNoOfFirstImg = getFirstPage(WOPatDataProcess.getMapRecursively(doc, 'data.front-page.doc-page'))
            patData.gazetteNo = getGazNo(WOPatDataProcess.getMapRecursively(doc, 'data.wo-bibliographic-data.wo-publication-info'))
            patData.designationOfStatesJson = WOPatDataProcess.getMapRecursively(doc, 'data.wo-bibliographic-data.designation-of-states').toString()
            return patData
        }

        protected int toPageNum(String str){
            return Integer.parseInt( StringUtils.substringBeforeLast(str, '.'))
        }

        protected Integer getFirstPage(def docPage){
            return (!!docPage)? toPageNum( getObject(docPage[0], 'file')): null
        }

        protected String getGazNo(Map woPubInfo){
            if( !!getObject(woPubInfo, 'wo-correction')){
                return getObject( getObject(woPubInfo, 'wo-correction')[0], 'wo-pubnum')
            }else{
                return getObject(woPubInfo, 'wo-pubnum')
            }
        }
    }

    protected class WoPatDataLNP extends WoPatDataBasic{

        @Override
        public PatData getPatData(Map doc, Date date) throws Exception {
            PatData patData = createPatData( doc, date)
            // necessary
            patData.rawDocNo = doc.'data'.'bibliographic-data'.'publication-reference'.'document-id'.'0'.'doc-number'
            
            if(!doc?.'data'?.'bibliographic-data'?.'application-reference'){ // w/o application reference error
                throw new Exception('application-reference missing')
            }
            
            patData.rawAppNo = doc.'data'.'bibliographic-data'.'application-reference'.'document-id'.'0'.'doc-number'
            patData.oriLang = WOPatDataProcess.normalizeLang( getLang( doc.'data'.'bibliographic-data'))
            patData.appId = PatNumberUtil.getAppIdWO(patData.rawAppNo)

            // optional
            patData.sizeOfClaims = WOPatDataProcess.getMapRecursively(doc, 'data.bibliographic-data.number-of-claims.value')
            patData.designationOfStatesJson = WOPatDataProcess.getMapRecursively(doc, 'data.bibliographic-data.designation-of-states').toString()
            return patData
        }

        protected String getLang(Map biblioData){
            return (biblioData.containsKey('language-of-publication'))? biblioData.'language-of-publication': biblioData.'lang'
        }
    }


    public DBObject getFulltext(){
        return null
    }
    
    /**
     * format Ipc from a map with keys: section, class, subclass, main-group, subgroup
     * @param doc
     * @return
     */
    def static String formatClsIpc(Map doc){
        return PatClsUtil.formatClsCpcIPC(
                StringUtils.defaultString(doc?.'section'),
                StringUtils.defaultString(doc?.'class'),
                StringUtils.defaultString(doc?.'subclass'),
                StringUtils.defaultString(doc?.'main-group'),
                StringUtils.defaultString(doc?.'subgroup')
                )
    }
    
    def static String formatIpc(String rawIpc){
        String result = rawIpc.trim()
        switch(result){
            case ~/(\w{1})\s*(\d{2})(\w{1})\s*(\d{1,4})\/(\d{1,4})/:
                result = result.replaceAll(/(\w{1})\s*(\d{2})(\w{1})\s*(\d{1,4})\/(\d{1,4})/){full, sec, cla, subcla, main, sub->
                    return PatClsUtil.formatClsCpcIPC(sec, cla, subcla, main, sub)
                }            
                break;
            
            case ~/(\w{1})\s*(\d{2})(\w{1})/:
                result = result.replaceAll(/(\w{1})\s*(\d{2})(\w{1})/){full, sec, cla, subcla->
                    return PatClsUtil.formatClsCpcIPC(sec, cla, subcla, '', '')
                }
                break;
                
            default:
                result = null
                
        }
        return result
    }
    
    
    /**
     * publication date
     * format: yyyyMMdd, Ex: 20150108
     * @param date
     * @return
     */
    def static Date getDate(String date){
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd")
        format.setTimeZone(TimeZone.getTimeZone("GMT"))
        return format.parse(date)
    }

    /**
     * safely find a value in map recursively  
     */
    def static Object getMapRecursively(Map doc, String path){
        def result = doc
        StringUtils.split(path, '.').each{ key->
            result = (result instanceof Map)? getObject(result, key): ((result instanceof BasicDBList)? result[Integer.parseInt(key)]:null)
        }
        return result
    }

    /**
     * convert lang to 2-letter code
     * reference :
     *  https://en.wikipedia.org/wiki/List_of_ISO_639-2_codes
     *  https://www.w3.org/WAI/ER/IG/ert/iso639.htm
     * @param lang
     * @return
     */
    def static String normalizeLang(String lang){
        switch(lang){
            case "ara":         return "ar"
            case "chi":         return "zh"
            case "cze":         return "cs"
            case "dan":         return "da"
            case "dut":         return "nl"
            case "eng":         return "en"
            case "fin":         return "fi"
            case "ger":         return "de"
            case "fre":         return "fr"
            case "hun":         return "hu"     // Hungarian
            case "ita":         return "it"
            case "jpn":         return "ja"
            case "kor":         return "kr"
            case "lit":         return "lt"     // Lithuanian
            case "nor":         return "no"
            case "por":         return "pt"
            case "rus":         return "ru"
            case "scr":         return "sh"     // Serbo-Croatian
            case "slo":         return "sk"     // Slovak
            case "slv":         return "sl"     // Slovene
            case "spa":         return "es"
            case "swe":         return "sv"
            case "tha":         return "th"
            case "tur":         return "tr"     // Turkish
            default:            return "original"
        }
    }


}