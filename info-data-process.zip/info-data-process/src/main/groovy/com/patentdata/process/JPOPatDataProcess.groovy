package com.patentdata.process;

import groovy.json.JsonOutput

import java.lang.invoke.MethodHandleImpl.BindCaller.T
import java.lang.reflect.Method.*
import java.text.SimpleDateFormat

import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.helper.AppDataHelper
import com.patentdata.helper.PersonDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsFi
import com.patentdata.model.PatClsFiId
import com.patentdata.model.PatClsFterm
import com.patentdata.model.PatClsFtermId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatData
import com.patentdata.model.PatDataAmend
import com.patentdata.model.PatDataAmendId
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatRawJp
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PatRefPriorityId
import com.patentdata.model.PatRefRelatedParent
import com.patentdata.model.PatRefRelatedParentId
import com.patentdata.model.PersonData
import com.patentdata.model.PersonLang
import com.patentdata.model.PersonLangList
import com.patentdata.service.AppDataService
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataMemoService
import com.patentdata.service.PatDataService
import com.patentdata.service.PatRawService
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.UUIDUtil

public class JPOPatDataProcess extends BaseProcess {

    enum XSD_TYPE {
        WIPS_APPLICATION, WIPS_GRANT
    }

    static PatRawService patRawService= new PatRawService()
    static AppDataService appDataSevice = new AppDataService()
    static PatDataService patDataService = new PatDataService()
    static PatClsService patClsService = new PatClsService()
    static PersonDataServices personDataService = new PersonDataServices()
    static PatRefService patRefService = new PatRefService()
    static PatDataMemoService patDataMemoService = new PatDataMemoService()
    def static sdfDoDateParse = new SimpleDateFormat("yyyyMMdd")
    static Date ipcrDate = sdfDoDateParse.parse("20060101")
    /**
     * 資料查詢
     * @return
     * @throws Exception
     */
    @Override
    DBCursor queryData() throws Exception {

        println "queryData..."
        def client = MongoUtil.connectByConfig("JP");
        // marshall
        def marshallCol = client.getDB("PatentMarshallJPO").getCollection("PatentMarshallJPO")
        DBCursor cursor = marshallCol.find(queryMap).addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        return cursor
    }

    @Override
    void processData(DBObject doc) throws Exception {
        Date now = new Date();
        Date last = now;
        def provider = doc.provider
        def kindcode = doc.kindcode
        //處理 wips application 資料
        if((kindcode == "A" || kindcode == "U") && provider == "WIPS") {
            processWipsApplication(doc)
        }
    }

    static processWipsApplication(doc) throws Exception{
        def wipsPatentDocument = doc.data['wips-patent-document']
        //dd.xml
        //app_data
        AppData appData = genWipsApplicationAppData(doc)
        appDataSevice.saveOrUpdateAppData(appData)
        //pat_data
        PatData patData = genWipsApplicationPatData(doc, appData)
        patDataService.saveOrUpdatePatDataJP(patData)
        //pat_data_brief
        PatDataBrief patDataBrief = genWipsApplicationPataDataText(doc, patData, "Brief")
        List briefList = new ArrayList<PatDataBrief>()
        briefList.add(patDataBrief)
        patDataService.saveOrUpdatePatDataBrief(briefList)
        //pat_data_claims
        PatDataClaims patDataClaims = genWipsApplicationPataDataText(doc, patData, "Claims")
        List claimList = new ArrayList<PatDataClaims>()
        claimList.add(patDataClaims)
        patDataService.saveOrUpdatePatDataClaims(claimList)
        //pat_data_desc
        PatDataDesc patDataDesc = genWipsApplicationPataDataText(doc, patData, "Desc")
        List descList = new ArrayList<PatDataDesc>()
        descList.add(patDataDesc)
        patDataService.saveOrUpdatePatDataDesc(descList)
        //pat_data_tiitle
        PatDataTitle patDataTitle = genWipsApplicationPataDataText(doc, patData, "Title")
        List titleList = new ArrayList<PatDataTitle>()
        titleList.add(patDataTitle)
        patDataService.saveOrUpdatePatDataTitle(titleList)
        //dd_cls.xml
        try {
            //ipc
            List patClsIpcList = genWipsApplicationPatClsIpcList(doc)
            patClsService.saveOrUpdatePatClsIpc(patClsIpcList)
            //fi
            //19950002848A 這篇 fi 為亂碼，不處理
            if(!doc['_id'].equals("19950002848A")) {
                List patClsFiList = genWipsApplicationPatClsFiList(doc)
                patClsService.saveOrUpdatePatClsFi(patClsFiList)
            }
            //fterm
            List patClsFtermList = genWipsApplicationPatClsFtermList(doc)
            patClsService.saveOrUpdatePatClsFterm(patClsFtermList)
        } catch (Exception e) {
            def msg = e.getMessage()
            throw new Exception(msg + ": " + doc["_id"])
        }
        //amend
        List patDataAmendList = genWipaApplicationAmendList(doc)
        patDataService.saveOrUpdatePatAmendJP(patDataAmendList)
        //person
        List personDataList = new LinkedList<PersonData>()
        List personLangList = new LinkedList<PersonLang>()
        List personLangListList = new LinkedList<PersonLangList>()
        List patPersonApplicantList
        (patPersonApplicantList, personDataList) = genWipsApplicationPatPartiesPersonAndRelateDataList("Applicant", doc, personDataList)
        List patPersonInventor
        (patPersonInventor, personDataList) = genWipsApplicationPatPartiesPersonAndRelateDataList("Inventor", doc, personDataList)
        List patPersonAgentList
        (patPersonAgentList, personDataList) = genWipsApplicationPatPartiesPersonAndRelateDataList("Agent", doc, personDataList)
        personDataService.saveOrUpdate(personDataList, patPersonApplicantList, patPersonInventor, patPersonAgentList, null, null, null)
        //dd_ref
        //wips 的 application 資料沒有 references-cited
        //priority patent
        List patRefPriorityList = genWipsApplicationPatRefPriorityList(doc)
        patRefService.savePatRefPriority(patRefPriorityList, patData.getPatId(), com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
        //related patent && dates-of-public-availability
        List patRefRelatedParentList = genWipsApplicationPatRefRelatedParentList(doc)
        patRefService.savePatRefRelatedParent(patRefRelatedParentList, patData.getPatId(), com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
        //dd_raw.xml
        //pat_raw_jp
        PatRawJp patRawJp = genWipsApplicationPatRawJP(doc)
        patRawService.saveOrUpdatePatRawJp(patRawJp)

        /*
         * 待處理
         */
        if(doc.data['wips-patent-document']['bibliographic-data']['request-open-application']) {
            //throw new Exception("element: request-open-application isn't null: " + doc['_id'])
            println "element: request-open-application isn't null: " + doc['_id']
        }
        //參考 19950000090A 這篇
        if(doc.data['wips-patent-document']['bibliographic-data']['article-of-lack-of-novelty']) {
            //throw new Exception("element: article-of-lack-of-novelty isn't null: " + doc['_id'])
            println "element: article-of-lack-of-novelty isn't null: " + doc['_id']
        }
        if(doc.data['wips-patent-document']['bibliographic-data']['article-of-public-order-and-morality']) {
            //throw new Exception("element: article-of-public-order-and-morality isn't null: " + doc['_id'])
            println "element: article-of-public-order-and-morality isn't null: " + doc['_id']
        }
        if(doc.data['wips-patent-document']['bibliographic-data']['article-of-industrial-revitalizing-law']) {
            //throw new Exception("element: article-of-industrial-revitalizing-law isn't null: " + doc['_id'])
            println "element: article-of-industrial-revitalizing-law isn't null: " + doc['_id']
        }
        /**
         * TODO 未明確的 element 
         * request-for-examination
         * filing-form
         * article-of-public-order-and-morality
         * written-amendment-group
        **/ 
    }

    static genWipaApplicationAmendList(doc) throws Exception {
        def amendCount = 0
        List patDataAmendList = new LinkedList<PatDataAmend>()
        if(!!doc.data['wips-patent-document']['bibliographic-data']['written-amendment-group']) {
            genWipaApplicationAmend(doc.data['wips-patent-document']['bibliographic-data']['written-amendment-group'], doc['_id'], patDataAmendList)
        }
        if(!!doc.data['wips-patent-document']['written-amendment-group']) {
            genWipaApplicationAmend(doc.data['wips-patent-document']['written-amendment-group'], amendCount, doc['_id'], patDataAmendList)
        }
        return patDataAmendList
    }

    static genWipaApplicationAmend(amendGroup, amendCount, patId, patDataAmendList) throws Exception {
        amendGroup['written-amendment'].each { writenAmend -> 
            def amendDate
            if(writenAmend['date'].size() > 1) {
                throw new Exception("multi datr in written amendment")
            } else {
                amendDate = sdfDoDateParse.parse(writenAmend['date'][0])
            }
            writenAmend['amendment-article'].each { amendmentArticle ->
                amendmentArticle['amendment-group'].each { amendmentGroup->
                    PatDataAmend  patDataAmend = new PatDataAmend()
                    PatDataAmendId PatDataAmendId = new PatDataAmendId()
                    amendCount++
                    PatDataAmendId.setPatId(patId)
                    PatDataAmendId.setAmendDate(amendDate)
                    PatDataAmendId.setItem(amendCount)
                    PatDataAmendId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    patDataAmend.setId(PatDataAmendId)
                    if(!!amendmentGroup['document-code']) {
                        patDataAmend.setAmendColumnDesc(amendmentGroup['document-code'])
                    }
                    if(!!amendmentGroup['item-of-amendment']) {
                        patDataAmend.setAmendScopeDesc(amendmentGroup['item-of-amendment'])
                    }
                    if(!!amendmentGroup['way-of-amendment']) {
                        patDataAmend.setAmendTypeDesc(amendmentGroup['way-of-amendment'])
                    }
                    if(!!amendmentGroup['contents-of-amendment']) {
                        def val = ""
                        amendmentGroup['contents-of-amendment']['value'].each { amendVal ->
                            val += amendVal
                        }
                        patDataAmend.setAmendVal(val)
                    }
                    patDataAmend.setCreateDate(new Date())
                    patDataAmendList.add(patDataAmend)
                }
            }
        }
        return patDataAmendList
    }

    static genWipsApplicationPatRefPriorityList(doc) throws Exception {
        List patefPriorityList = new LinkedList<PatRefPriority>()
        if(doc.data['wips-patent-document']['bibliographic-data']['priority-claims']) {
            def wipsCount = 0
            def originalCount = 0
            def itemCount = 0;
            doc.data['wips-patent-document']['bibliographic-data']['priority-claims'].each { priority ->
                if(priority['data-format'] == "wips") {
                    wipsCount++
                    //參考 19950000070A 這篇有複數 priority
                    priority['priority-claim'].each { priorityInfo ->
                        itemCount++
                        PatRefPriority patRefPriority = new PatRefPriority()
                        PatRefPriorityId patRefPriorityId = new PatRefPriorityId()
                        patRefPriorityId.setPatId(doc['_id'])
                        patRefPriorityId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                        patRefPriorityId.setItem(itemCount)
                        patRefPriority.setId(patRefPriorityId)
                        def country = priorityInfo['country']
                        patRefPriority.setCountry(country)
                        def appDate = sdfDoDateParse.parse(priorityInfo['date'])
                        patRefPriority.setAppDate(appDate)
                        patRefPriority.setRawAppDate(priorityInfo['date'])
                        patRefPriority.setRawAppNo(priorityInfo['doc-number'])
                        def appNo
                        if(country ==~ /(?i)US/) {
                            //美國專利需要專利類型才能判斷前兩碼的 series code
                            if(priority['right']) {
                                //有的話拋出異常，方便看範例
                                throw new Exception("there is content of right at us priority")
                            }
                        } else if (country ==~ /(?i)CN/) {
                            //TODO CN 號碼待 CN 開始處理再弄
                        } else if (country ==~ /(?i)TW/) {
                            try {
                                appNo = PatNumberUtil.getAppNoTW(priorityInfo['doc-number'], "JP")
                            } catch(Exception e) {
                                def msg = e.getMessage()
                                throw new Exception(msg + ": " + doc['_id'])
                            }
                        } else if (country ==~ /(?i)JP/) {
                            //日本專利需要專利類型才能定位出唯一的申請號
                            if(priority['right']) {
                                def kindcode = ""
                                if (priority['right'] ==~ /(?i)P/) {
                                    kindcode = "A"
                                } else if (priority['right'] ==~ /(?i)U/) {
                                    kindcode = "U"
                                } else if (priority['right'] ==~ /(?i)D/) {
                                    kindcode = "S"
                                } else {
                                    throw new Exception("unexpect content of right element at related pat: " + doc['_id'])
                                }
                                try {
                                    appNo = PatNumberUtil.getAppIdJP(kindcode, priorityInfo['doc-number'])
                                } catch(Exception e) {
                                    def msg = e.getMessage()
                                    throw new Exception(msg + ": " + doc['_id'])
                                }
                            }
                        } else if (country ==~ /(?i)EP/) {
                            //優先權為 EP 參考這篇 19950000216A
                            try {
                                appNo = PatNumberUtil.getAppNoEP(priorityInfo['doc-number'], "JP")
                            } catch (Exception e) {
                                def msg = e.getMessage()
                                throw new Exception(msg + ": " + doc['_id'])
                            }
                            //throw new Exception("priority country in ep: " + doc['_id'])
                        } else if (country ==~ /(?i)WO/) {
                            try {
                                appNo = PatNumberUtil.getAppNoWO(priorityInfo['doc-number'])
                            } catch (Exception e) {
                                def msg = e.getMessage()
                                throw new Exception(msg + ": " + doc['_id'])
                            }
                        }
                        if(!!appNo) {
                            patRefPriority.setAppNo(appNo)
                            def parAppId
                            parAppId = AppDataHelper.queryByCondition("JP", appNo, appDate)
                            List<AppData> appDataList = AppDataHelper.queryByCondition(country, appNo, appDate);
                            if (!!appDataList) {
                                if (appDataList.size() > 1) {
                                    throw new Exception("priority data query over 1 at priority");
                                }
                                patRefPriority.appData = appDataList.get(0);
                                patRefPriority.setAppData(appDataList)
                            }
                        }
                        patRefPriority.setCreateDate(new Date())
                        patefPriorityList.add(patRefPriority)
                    }
                } else {
                    originalCount++
                }
            }
            if(wipsCount != originalCount) {
                throw new Exception("wips count not equals original count in proiority")
            }
        }
        return patefPriorityList
    }

    static genWipsApplicationPatRefRelatedParentList(doc) throws Exception {
        //related-document & dates-of-public-availability 都是 related parent
        List patRefRelatedParentList = new LinkedList<PatRefRelatedParent>()
        patRefRelatedParentList = genWipsApplicationRefRelatedList(doc, patRefRelatedParentList)
        patRefRelatedParentList = genWipsAlllicationPubAvailableList(doc, patRefRelatedParentList)
        return patRefRelatedParentList
    }

    static genWipsAlllicationPubAvailableList(doc, patRefRelatedParentList) throws Exception {
        def wipsCount = 0
        def originalCount = 0
        if(!!doc.data['wips-patent-document']['bibliographic-data']['dates-of-public-availability']) {
            doc.data['wips-patent-document']['bibliographic-data']['dates-of-public-availability'].each { pubAvailable ->
                if(pubAvailable['data-format'] == "wips") {
                    wipsCount++
                    if(!!pubAvailable['printed-with-grant'] && !!pubAvailable['printed-with-grant']['document-id']) {
                        PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent()
                        PatRefRelatedParentId patRefRelatedParentId = new PatRefRelatedParentId()
                        patRefRelatedParentId.setPatId(doc['_id'])
                        patRefRelatedParentId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                        patRefRelatedParentId.setItem(patRefRelatedParentList.size()+1)
                        patRefRelatedParent.setId(patRefRelatedParentId)
                        if(!!pubAvailable['printed-with-grant']['document-id']['country']) {
                            //有遇到國家先噴錯，看一下這欄位是不是可能有其他國家的
                            throw new Exception("there is country info at date of public available")
                        }
                        if(!!pubAvailable['printed-with-grant']['document-id']['doc-num']) {
                            def docNo = pubAvailable['printed-with-grant']['document-id']['doc-num']
                            patRefRelatedParent.setRawDocNo(docNo)
                            //有 kindcode 才能正規化 doc no
                            if(!!pubAvailable['printed-with-grant']['document-id']['kind']) {
                                def kindcode = pubAvailable['printed-with-grant']['document-id']['kind']
                                docNo = PatNumberUtil.getDocNoJP(kindcode, docNo)
                                if(docNo == "") {
                                    throw new Exception("unexception format of doc no at date-of-public-available")
                                }
                                patRefRelatedParent.setDocNo(docNo)
                                patRefRelatedParent.setKindCode(kindcode)
                            }
                        }
                        if(!!pubAvailable['printed-with-grant']['document-id']['date']) {
                            def docDate = pubAvailable['printed-with-grant']['document-id']['date']
                            patRefRelatedParent.setRawDocDate(docDate)
                            patRefRelatedParent.setDocDate(sdfDoDateParse.parse(docDate))
                        }
                        if(!!pubAvailable['printed-with-grant']['document-id']['right']) {
                            throw new Exception("there is right info at date of public available")
                        }
                        patRefRelatedParent.setCreateDate(new Date())
                        patRefRelatedParent.setRelatedType(com.patentdata.common.Constants.RELATED_TYPE_CODE_RELATED_GRANT)
                        patRefRelatedParentList.add(patRefRelatedParent)
                    }
                } else {
                    originalCount++
                }
            }
        }
        if(wipsCount != originalCount) {
            throw new Exception("wips count and original count do not equals at date-of-public-available")
        }
        return patRefRelatedParentList
    }

    static genWipsApplicationRefRelatedList(doc, patRefRelatedParentList) {
        def wipsCount = 0
        if(!!doc.data['wips-patent-document']['bibliographic-data']['related-documents']) {
            doc.data['wips-patent-document']['bibliographic-data']['related-documents'].each { relDoc ->
                if(relDoc['data-format'] == "wips") {
                    wipsCount++
                    PatRefRelatedParent patRefRelatedParent = new PatRefRelatedParent()
                    PatRefRelatedParentId patRefRelatedParentId = new PatRefRelatedParentId()
                    patRefRelatedParentId.setPatId(doc['_id'])
                    patRefRelatedParentId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    patRefRelatedParentId.setItem(wipsCount)
                    patRefRelatedParent.setId(patRefRelatedParentId)
                    def relDocInfo
                    if(!!relDoc['division']) {
                        relDocInfo = relDoc['division']['parent-doc']['document-id']
                        patRefRelatedParent.setRelatedType(com.patentdata.common.Constants.RELATED_TYPE_CODE_JP_DIVISION)
                    }
                    if(!!relDoc['change-of-application']) {
                        relDocInfo = relDoc['change-of-application']['parent-doc']['document-id']
                        patRefRelatedParent.setRelatedType(com.patentdata.common.Constants.RELATED_TYPE_CODE_JP_CHANGE_APPLICATION)
                    }
                    if(!!relDoc['change-of-utility']) {
                        relDocInfo = relDoc['change-of-utility']['parent-doc']['document-id']
                        patRefRelatedParent.setRelatedType(com.patentdata.common.Constants.RELATED_TYPE_CODE_JP_CHANGE_UTILITY)
                    }
                    patRefRelatedParent.setRawAppNo(relDocInfo['doc-num'])
                    def right = relDocInfo['right']
                    def kindcode = ""
                    if(right ==~ /(?i)P/) {
                        kindcode = "A"
                    } else if (right ==~ /(?i)U/) {
                        kindcode = "U"
                    } else if (right ==~ /(?i)D/) {
                        kindcode = "S"
                    } else {
                        throw new Exception("unexpect content of right element at related pat: " + doc['_id'])
                    }
                    def appNo
                    try {
                        appNo = PatNumberUtil.getAppIdJP(kindcode, relDocInfo['doc-num'])
                    } catch (Exception e) {
                        throw new Exception(e.getMessage() + ": " + doc['_id'])
                    }
                    patRefRelatedParent.setAppNo(appNo)
                    def parAppId
                    List<AppData> appDataList
                    if(!!relDocInfo['date']) {
                        def appDate = sdfDoDateParse.parse(relDocInfo['date'])
                        patRefRelatedParent.setAppDate(appDate)
                        appDataList = AppDataHelper.queryByCondition("JP", appNo, appDate)
                    } else {
                         appDataList = AppDataHelper.queryByCondition("JP", appNo)
                    }
                    if(!!appDataList && appDataList.size() == 1) {
                        parAppId = appDataList.get(0).getAppId()
                    } else if (appDataList.size() > 1) {
                        throw new Exception("priority data query over 1 at relaed parent");
                    }
                    if(!!parAppId) {
                        patRefRelatedParent.setParentAppId(parAppId)
                    }
                    patRefRelatedParent.setCreateDate(new Date())
                    patRefRelatedParentList.add(patRefRelatedParent)
                    if(!!relDocInfo['country']) {
                        throw new Exception("there is country info at related patent")
                    }
                }
            }
            if(wipsCount == 0) {
                throw new Exception("no related patent in wips format")
            }
        }
        return patRefRelatedParentList
    }

    static genWipsApplicationPatPartiesPersonAndRelateDataList(personType, doc, personDataList) {
        List patPeronList = new LinkedList<T>()
        def eleName = personType.toLowerCase()
        int itemCount = 1
        if(doc.data['wips-patent-document']['bibliographic-data']['parties'][eleName + 's']) {
            doc.data['wips-patent-document']['bibliographic-data']['parties'][eleName + 's'][eleName].each { person->
                def lang = covertCountry2Lang(person['lang'])
                person['addressbook'].each  { addressbook ->
                    PersonData personData = genWipsApplicationPersonData(addressbook, lang)
                    //沒有人名記錄到 memo 
                    if(personData.getPersonName() == null) {
                        patDataMemoService.savePatDataMemo(doc['_id'], com.patentdata.common.Constants.SOURCE_ID_JP_XXX, 
                            com.patentdata.common.Constants.DATA_MEMO_PERSON_WITH_MULTILANG)
                    }
                    PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.getCountry(), personDataList);
                    if (existsData != null) {
                        personData = existsData;
                    } else {
                        personData.personId = UUIDUtil.generateUUID();
                        personDataList.add(personData);
                    }
                    String className = "com.patentdata.model.PatPerson" + personType
                    Class personCls = Class.forName(className)
                    Object personObj = personCls.newInstance()
                    Class idCls = Class.forName(className + "Id")
                    Object idObj = idCls.newInstance()
                    idObj.setPatId(doc['_id'])
                    idObj.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    idObj.setItem(itemCount)
                    itemCount++
                    personObj.setId(idObj)
                    if(personType == "Applicant" || personType == "Agent") {
                        if(addressbook['registered-number']) {
                            personObj.setPtoPersonId(addressbook['registered-number'])
                        }
                    }
                    personObj.setPersonData(personData)
                    personObj.setCreateDate(new Date())
                    patPeronList.add(personObj)
                }
            }
        }
        return [patPeronList, personDataList]
    }

    static genWipsApplicationPersonData(addressbook, lang) {
        PersonData personData = new PersonData()
        String parsonFacet = ""
        if(lang == "") {
            //日本 person data 沒給語系的話預設都給 ja
            lang = com.patentdata.common.Constants.JP_LANG 
        }
        personData.setLang(lang)
        if(addressbook['name']) {
            String name = addressbook['name']
            name = name.replaceAll("▲", "").replaceAll("▼", "").replaceAll("\\(外\\d+名\\)", "")
            name 
            personData.setPersonName(name)
            parsonFacet += name
        }
        if(addressbook['address']) {
            if(addressbook['address'].size() == 1){
                if(addressbook['address'][0]['text']) {
                    personData.setAddress(addressbook['address'][0]['text'])
                    parsonFacet += addressbook['address'][0]['text']
                }
                if(addressbook['address'][0]['coutry']) {
                    personData.setCountry(addressbook['address'][0]['coutry'].toString().toUpperCase())
                    parsonFacet += addressbook['address'][0]['coutry'].toString().toUpperCase()
                }
                if(addressbook['address'][0]['postcode']) {
                    personData.setPostcode(addressbook['address'][0]['postcode'])
                    parsonFacet += addressbook['address'][0]['postcode']
                }
                if(addressbook['address'][0]['code']) {
                    //TODO 跑到出現有這欄位拋錯出來看這是甚麼東西....
                    throw new Exception("there is code element")
                }
            } else {
                throw new Exception("there are multi addresses map to one addressbook at person")
            }
        }
        personData.setPersonFacet(com.patentdata.util.StringUtil.personFacetWrap(parsonFacet))
        personData.setPersonType(com.patentdata.common.Constants.PERSON_TYPE_NONE)
        Date curTime = new Date()
        personData.setCreateDate(curTime)
        personData.setLastUpdDate(curTime)
        return personData
    }

    static genWipsApplicationPatClsFtermList(doc) throws Exception{
        List patClsFtermList = new LinkedList<PatClsFterm>()
        def itemCount = 1
        if(doc.data['wips-patent-document']['bibliographic-data']['f-term-info']) {
            doc.data['wips-patent-document']['bibliographic-data']['f-term-info'].each { fterms ->
                fterms['f-term'].each { fterm ->
                    PatClsFterm patClsFterm = new PatClsFterm()
                    PatClsFtermId patClsFtermId = new PatClsFtermId()
                    patClsFtermId.setPatId(doc['_id'])
                    patClsFtermId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    patClsFtermId.setItem(itemCount)
                    itemCount++
                    patClsFterm.setId(patClsFtermId)
                    def themeCode = ""
                    def viewPoint = ""
                    def figure = ""
                    //20110068704A 這篇專利的 figure 有三碼
                    //但三碼 figure 在官方 fi-fterm 無法檢索 ..先照著存
                    def ftermMatcher = fterm =~ /^(?i)([\d][a-z][\d]{3})([a-z]{2})([\d]{2,3})([a-z])?$/
                    if(ftermMatcher) {
                        patClsFterm.setThemeCode(ftermMatcher.group(1))
                        patClsFterm.setViewpoint(ftermMatcher.group(2))
                        patClsFterm.setFigure(ftermMatcher.group(3))
                        if(!!ftermMatcher.group(4)) {
                            patClsFterm.setAdditionalCode((Character)ftermMatcher.group(4))
                        }
                    } else {
                        throw new Exception("can't parse f-term format")
                    }
                    patClsFterm.setFtermText(fterm)
                    patClsFterm.setCreateDate(new Date())
                    patClsFtermList.add(patClsFterm)
                }
            }
        }
        return patClsFtermList
    }

    static genWipsApplicationPatClsFiList(doc) throws Exception {
        List patClsFiList = new LinkedList<PatClsFi>()
        def wipsCount = 0
        def originalCount = 0
        //先找 classification-national 這個 element，如果沒有即 fi 資訊跟 ipc 欄位沒有分開 (早期專利 fi 資訊會寫在 ipc 欄位)
        def fiEleSuffix = "national"
        if (!doc.data['wips-patent-document']['bibliographic-data']['classifications-national'] ){
            fiEleSuffix = "ipc"
        }
        doc.data['wips-patent-document']['bibliographic-data']['classifications-' + fiEleSuffix].each { fisEle ->
            if(fisEle['data-format'] == "wips") {
                //wips 資料比 original 還乾淨，故解析 wips
                def itemCount = 1
                fisEle['classification-' + fiEleSuffix].each { fiEle ->
                    PatClsFi patClsFi = new PatClsFi()
                    PatClsFiId patClsFiId = new PatClsFiId()
                    patClsFiId.setPatId(doc['_id'])
                    patClsFiId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    patClsFiId.setItem(itemCount)
                    itemCount++
                    patClsFi.setId(patClsFiId)
                    def fullFiText = ""
                    def ipcText = ""
                    def subDivisionSymbol = ""
                    def fileDiscriminationSymbolStr = ""
                    //JP20050006482A 這篇專利的 ipc 官網和原始資料都長這樣...跳過不處理
                    if(fiEle['text'] =~ /00000\/00/) {
                        return
                    }
                    (fullFiText, ipcText, subDivisionSymbol, fileDiscriminationSymbolStr) = genWipsApplicationFiFormated(fiEle['text'])
                    patClsFi.setFiText(fullFiText)
                    patClsFi.setIpc(ipcText)
                    patClsFi.setSubDivisionSymbol(subDivisionSymbol)
                    if(fileDiscriminationSymbolStr != "") {
                        patClsFi.setFileDiscriminationSymbol(fileDiscriminationSymbolStr.charAt(0))
                    }
                    if(fiEle['cls_cd'] == "main-clsf") {
                        patClsFi.setRawMainFlag(com.patentdata.common.Constants.CLS_FI_MAIN_FLAG_YES)
                        patClsFi.setClsValue(com.patentdata.common.Constants.CLS_FI_VALUE_CODE_MAIN_OR_FURTHER)
                    } else if (fiEle['cls_cd'] == "further-clsf"){
                        patClsFi.setRawMainFlag(com.patentdata.common.Constants.CLS_FI_MAIN_FLAG_NO)
                        patClsFi.setClsValue(com.patentdata.common.Constants.CLS_FI_VALUE_CODE_MAIN_OR_FURTHER)
                    } else if (fiEle['cls_cd'] == "add-info"){
                        patClsFi.setRawMainFlag(com.patentdata.common.Constants.CLS_FI_MAIN_FLAG_NO)
                        patClsFi.setClsValue(com.patentdata.common.Constants.CLS_FI_VALUE_CODE_ADD_INFO)
                    } else {
                        patClsFi.setRawMainFlag(com.patentdata.common.Constants.CLS_FI_MAIN_FLAG_NO)
                    }
                    Date curTime = new Date()
                    patClsFi.setCreateDate(curTime)
                    patClsFiList.add(patClsFi)
                }
                wipsCount = fisEle['classification-' + fiEleSuffix].size()
            } else if(fisEle['data-format'] == "original") {
                originalCount = fisEle['classification-' + fiEleSuffix].size()
            }
        }
        if(wipsCount != originalCount) {
            throw new Exception("wips count, original count are not equals in fi")
        }
        return patClsFiList
    }

    static genWipsApplicationFiFormated(fi) {
        def ipcText = ""
        def subDivisionSymbol = ""
        def fileDiscriminationSymbol = ""
        ipcText = genWipsApplicationIpcFormated(fi)

        def subDivisionSymbolMatcher1 = fi =~ /[\s]+([\d]{3})[\s]+/
        def subDivisionSymbolMatcher2 = fi =~ /[\s]+([\d]{3})$/
        if(subDivisionSymbolMatcher1) {
            subDivisionSymbol = subDivisionSymbolMatcher1.group(1)
        } else if(subDivisionSymbolMatcher2) {
            subDivisionSymbol = subDivisionSymbolMatcher2.group(1)
        }

        def fileDiscriminationSymbolMatcher1 = fi =~ /(?i)[\s]+([a-z]{1})[\s]+/
        def fileDiscriminationSymbolMatcher2 = fi =~ /(?i)[\s]+([a-z]{1})$/
        if(fileDiscriminationSymbolMatcher1) {
            fileDiscriminationSymbol = fileDiscriminationSymbolMatcher1.group(1)
        } else if(fileDiscriminationSymbolMatcher2) {
            fileDiscriminationSymbol = fileDiscriminationSymbolMatcher2.group(1)
        }

        if (subDivisionSymbol == "" && fileDiscriminationSymbol == "") {
            def symbolMatcher1 = fi =~ /(?i)[\s]+([\d]{3})([a-z]{1})[\s]+/
            def symbolMatcher2 = fi =~ /(?i)[\s]+([\d]{3})([a-z]{1})$/
            if(symbolMatcher1) {
                subDivisionSymbol = symbolMatcher1.group(1)
                fileDiscriminationSymbol = symbolMatcher1.group(2)
            } else if(symbolMatcher2) {
                subDivisionSymbol = symbolMatcher2.group(1)
                fileDiscriminationSymbol = symbolMatcher2.group(2)
            }
        }
        def fullFiText = ipcText
        if(subDivisionSymbol != "") {
            fullFiText += " " + subDivisionSymbol
        }
        if(fileDiscriminationSymbol != "") {
            fullFiText += " " + fileDiscriminationSymbol
        }
        return [fullFiText, ipcText, subDivisionSymbol, fileDiscriminationSymbol]
    }

    static genWipsApplicationIpcFormated(ipc) throws Exception {
        def ipcMatcher = ipc =~ /^(?i)([a-z])([\d]{2})([a-z])-([\d]+)[\/|:]([\d]+)/
        if(ipcMatcher) {
            def sesion = ipcMatcher.group(1)
            def clazz = ipcMatcher.group(2)
            def subClazz = ipcMatcher.group(3)
            def group = ipcMatcher.group(4)
            group = group.replaceAll(/^0*/, "")
            def subGroup = ipcMatcher.group(5)
           subGroup = subGroup.replaceAll(/^0*/, "")
            if (subGroup.length() <2) {
                subGroup = subGroup.padLeft(2, '0')
            }
            def ipcNormal = sesion + clazz + subClazz + " " + group + "/" + subGroup
            return ipcNormal
        } else {
            throw new Exception("can't parse ipc format: " + ipc)
        }
    }

    static genWipsApplicationPatClsIpcList(doc) throws Exception{
        List patClsIpcList = new LinkedList<PatClsIpc>()
        def wipsCount = 0
        def originalCount = 0
        doc.data['wips-patent-document']['bibliographic-data']['classifications-ipc'].each { ipcsEle ->
            if(ipcsEle['data-format'] == "wips") {
                ipcsEle['classification-ipc'].each { ipcEle ->
                    PatClsIpc patClsIpc = new PatClsIpc()
                    PatClsIpcId patClsIpcId = new PatClsIpcId()
                    patClsIpcId.setPatId(doc['_id'])
                    patClsIpcId.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
                    patClsIpcId.setIpcType(com.patentdata.common.Constants.CLS_TYPE_IPC)
                    if(!!ipcEle['ipc-version-indicator']) {
                        patClsIpc.setClsVersion(ipcEle['ipc-version-indicator']['date'])
                        Date versionDate = sdfDoDateParse.parse(ipcEle['ipc-version-indicator']['date'])
                        if(versionDate >= ipcrDate) {
                            patClsIpcId.setIpcType(com.patentdata.common.Constants.CLS_TYPE_IPCR)
                        }
                    }
                    patClsIpcId.setItem(Integer.parseInt(ipcEle['sequence']))
                    patClsIpc.setId(patClsIpcId)
                    try {
                        //JP20050006482A 這篇專利的 ipc 官網和原始資料都長這樣...跳過不處理
                        if(ipcEle['text'] =~ /00000\/00/) {
                            return
                        }
                        patClsIpc.setIpcText(genWipsApplicationIpcFormated(ipcEle['text']))
                    } catch (Exception e) {
                        //遇到這篇專利 19950002848A 的分類號出現 263:00 這種 case 時，把前一個 ipc 的 section / class / subclass 代入 
                        def ipcExceptionMatcher = ipcEle['text'] =~ /^([\d]+:[\d]+)\s+/
                        if(ipcExceptionMatcher) {
                            def preIpc = patClsIpcList.get(patClsIpcList.size()-1).getIpcText();
                            patClsIpc.setIpcText(genWipsApplicationIpcFormated(preIpc.substring(0,4) + "-" + ipcExceptionMatcher.group(1)))
                        } else {
                            throw e
                        }
                    }
                    if(!!ipcEle['symbol-position']) {
                        Character symbolPosition = ipcEle['symbol-position']
                        patClsIpc.setSymbolPosition(symbolPosition)
                    }
                    if(!!ipcEle['classification-level']) {
                        Character level = ipcEle['classification-level']
                        patClsIpc.setClsLevel(level)
                    }
                    if(!!ipcEle['classification-value']) {
                        Character classValue = ipcEle['classification-value']
                        patClsIpc.setClsValue(classValue)
                    }
                    if(!!ipcEle['action-date']) {
                        patClsIpc.setActionDate(sdfDoDateParse.parse(ipcEle['action-date']['date']))
                    }
                    if(!!ipcEle['generating-office']) {
                        patClsIpc.setGenOffice(ipcEle['generating-office']['country'].toUpperCase())
                    }
                    if(!!ipcEle['classification-status']) {
                        Character classStatus = ipcEle['classification-status']
                        patClsIpc.setClsStatus(classStatus)
                    }
                    if(!!ipcEle['classification-data-source']) {
                        Character dataSource = ipcEle['classification-data-source']
                        patClsIpc.setClsDataSource(dataSource)
                    }
                    if(ipcEle['cls_cd'] == "main-clsf") {
                        patClsIpc.setRawMainFlag(com.patentdata.common.Constants.CLS_IPC_MAIN_FLAG_YES)
                        patClsIpc.setClsValue(com.patentdata.common.Constants.CLS_IPC_VALUE_CODE_MAIN_OR_FURTHER)
                        patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO)
                    } else if (ipcEle['cls_cd'] == "further-clsf") {
                        patClsIpc.setRawMainFlag(com.patentdata.common.Constants.CLS_IPC_MAIN_FLAG_NO)
                        patClsIpc.setClsValue(com.patentdata.common.Constants.CLS_IPC_VALUE_CODE_MAIN_OR_FURTHER)
                        patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO)
                    } else if(ipcEle['cls_cd'] == "add-info") {
                        patClsIpc.setRawMainFlag(com.patentdata.common.Constants.CLS_IPC_MAIN_FLAG_NO)
                        patClsIpc.setClsValue(com.patentdata.common.Constants.CLS_IPC_VALUE_CODE_ADD_INFO)
                        patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO)
                    } else {
                        patClsIpc.setRawMainFlag(com.patentdata.common.Constants.CLS_IPC_MAIN_FLAG_NO)
                        if(ipcEle['cls_cd'] =~ /^main-linked-indexing$/) {
                            patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES)
                            patClsIpc.setIndexType(com.patentdata.common.Constants.IPC_MAIN_LINKED_INDEXING)
                        } else if(ipcEle['cls_cd'] =~ /^sub-linked-indexing$/) {
                            patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES)
                            patClsIpc.setIndexType(com.patentdata.common.Constants.IPC_SUB_LINKED_INDEXING)
                        } else if(ipcEle['cls_cd'] =~ /^unlinked-indexing$/){
                            patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_YES)
                            patClsIpc.setIndexType(com.patentdata.common.Constants.IPC_UNLINKED_INDEXING)
                        } else if (!ipcEle['cls_cd']) {
                            patClsIpc.setIndexFlag(com.patentdata.common.Constants.IPC_LINKED_INDEXING_CODE_GROUP_NO)
                        } else {
                            throw new Exception("there is unknow ipc type in ipc")
                        }
                    }
                    Date curTime = new Date()
                    patClsIpc.setCreateDate(curTime)
                    patClsIpcList.add(patClsIpc)
                }
                wipsCount = ipcsEle['classification-ipc'].size()
            } else if (ipcsEle['data-format'] == "original") {
                originalCount = ipcsEle['classification-ipc'].size()
            }
        }
        if(wipsCount != originalCount) {
            //這篇例外不判斷處理完的 ipc 數量和 xml element 數量是否相等
            throw new Exception("wips count, original count are not equals in ipc")
        }
        return patClsIpcList
    }

    //claim, description, desc, title  
    static genWipsApplicationPataDataText(doc, patData, textType) throws Exception {
        String className = "com.patentdata.model.PatData" + textType
        Class textCls = Class.forName(className)
        Object textObj = textCls.newInstance()
        Class idCls = Class.forName(className + "Id")
        Object idObj = idCls.newInstance()
        idObj.setPatId(patData.getPatId())
        idObj.setSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
        def lang = patData.getOriLang()
        idObj.setLang(lang)
        textObj.setId(idObj)
        String eleName = ""
        if(textType == "Brief") {
            eleName = "abstract"
        } else if (textType == "Claims") {
            eleName = "claims"
        } else if (textType == "Desc") {
            textType = "Description"
            eleName = "description"
        } else if (textType == "Title") {
            eleName = "invention-title"
        } else {
            throw new Exception("no ele name")
        }
        String text = ""
        if(!!doc.data['wips-patent-document'][eleName]) {
            doc.data['wips-patent-document'][eleName]['value'].each { val->
                text += val
            }
        } else if(!!doc.data['wips-patent-document']['bibliographic-data'][eleName]) {
            doc.data['wips-patent-document']['bibliographic-data'][eleName]['value'].each { val->
                text += val
            }
        }
        //文字欄位為空先不判斷，之後透過 sql 查詢盤查
        if(!text.equals("")) {
            java.lang.reflect.Method method = textObj.getClass().getMethod("set" + textType, (new String()).class);
            method.invoke(textObj, text);
        }
        def curTime = new Date()
        textObj.setCreateDate(curTime)
        textObj.setLastUpdDate(curTime)
        return textObj
    }

    static genWipsApplicationPatData(doc, appData) throws Exception {
        PatData patData = new PatData()
        patData.setPatId(doc['_id'])
        def country = doc.data['wips-patent-document']['country']
        patData.setCountry(country.toUpperCase())
        patData.setStat(com.patentdata.common.Constants.PAT_STAT_PUBLIC)
        def rawDocNo = ""
        doc.data['wips-patent-document']['bibliographic-data']['Publication-reference'].each { pubRef ->
            if(pubRef['data-format'] == "wips") {
                rawDocNo = pubRef['document-id']['doc-num']
                return true
            }
        }
        if(rawDocNo.equals("")) {
            throw new Exception("no doc no")
        }
        patData.setRawDocNo(rawDocNo)
        patData.setDocNo(doc['_id'])
        patData.setDocDate(doc['doDate'])
        def kindcode = doc.data['wips-patent-document']['kind']
        def type = com.patentdata.common.Constants.TYPE_NO_DEFINED_CODE
        patData.setKindCode(kindcode)
        if(kindcode =~ /^A/ || kindcode =~ /^B/) {
            type = com.patentdata.common.Constants.PAT_TYPE_PATENT_CODE_JPO
        } else if (kindcode =~ /^U/ || kindcode =~ /^Y/) {
            type = com.patentdata.common.Constants.PAT_TYPE_UTILITY_CODE_JPO
        }
        patData.setPatType(type)
        def rawAppNo = ""
        doc.data['wips-patent-document']['bibliographic-data']['application-reference'].each { appRef ->
            if(appRef['data-format'] == "original") {
                rawAppNo = appRef['document-id']['doc-num']
                return true
            }
        }
        if(rawAppNo.equals("")) {
            throw new Exception("no raw app no")
        }
        patData.setRawAppNo(rawAppNo)
        patData.setAppId(appData.getAppId())
        //公開專利不會有登錄日/登錄號
        //patData.setRegistrationNo()
        //patData.setRegistrationDate()
        //日本專利暫時沒看到 FamilyId
        //patData.setFamilyId()
        patData.setDefaultSourceId(com.patentdata.common.Constants.SOURCE_ID_JP_XXX)
        String lang = covertCountry2Lang(doc.data['wips-patent-document']['bibliographic-data']['lang'])
        if(lang != "") {
            patData.setOriLang(lang)
        }
        def totalPage = Integer.parseInt(doc.data['wips-patent-document']['bibliographic-data']['total-pages'])
        patData.setTotalPages(totalPage)
        patData.setCryptoFlag(com.patentdata.common.Constants.CRYPTO_FLAG_NO)
        patData.setWithdrawFlag(com.patentdata.common.Constants.WITHDRAW_FLAG_FALSE)
        patData.setDeleteFlag(com.patentdata.common.Constants.DELETE_FLAG_NO)
        if(doc['truncate']) {
            patData.setTruncateFlag(com.patentdata.common.Constants.TRUNCATE_FLAG_TRUE)
        } else {
            patData.setTruncateFlag(com.patentdata.common.Constants.TRUNCATE_FLAG_FALSE)
        }
        patData.setPtoFlag(com.patentdata.common.Constants.FULL_TEXT_FLAG_YES)
        def curTime = new Date()
        patData.setCreateDate(curTime)
        patData.setLastUpdDate(curTime)
        if(!!doc.data['wips-patent-document']['bibliographic-data']['number-of-claims']) {
            def claimsNumberStr = doc.data['wips-patent-document']['bibliographic-data']['number-of-claims']
            patData.setSizeOfClaims(Integer.parseInt(claimsNumberStr))
        }
        return patData
    }

    static genWipsApplicationAppData(doc) throws Exception {
        AppData appData = new AppData()
        def appId = ""
        def appDate
        doc.data['wips-patent-document']['bibliographic-data']['application-reference'].each { appRef ->
            if(appRef['data-format'] == "wips") {
                appId = PatNumberUtil.getAppIdJP(doc.data['wips-patent-document']['kind'], appRef['document-id']['doc-num'])
                appDate = sdfDoDateParse.parse(appRef['document-id']['date'])
                return true
            }
        }
        if(appId.equals("")) {
            throw new Exception("no app id")
        }
        appData.setAppId(appId)
        def country = doc.data['wips-patent-document']['country']
        appData.setCountry(country.toUpperCase())
        appData.setAppNo(appId.substring(2, 7) + "-" + appId.substring(7))
        appData.setAppDate(appDate)
        
        String lang = covertCountry2Lang(doc.data['wips-patent-document']['lang'])
        if(lang != "") {
            appData.setAppLang(lang)
        }
        def curTime = new Date()
        appData.setCreateDate(curTime)
        appData.setLastUpdDate(curTime)
        return appData
    }

    static removeTextField(doc, field) {
        if(doc[field]) {
            doc.remove(field)
        }
    }

    static genWipsApplicationPatRawJP(doc) throws Exception {
        PatRawJp patRawJp = new PatRawJp()
        patRawJp.setRawId(doc['_id'])
        patRawJp.setPatId(doc['_id'])
        def rawJson = cloneObj(doc.data)
        removeTextField(rawJson['wips-patent-document'], 'abstract-correction')
        removeTextField(rawJson['wips-patent-document'], 'claims')
        removeTextField(rawJson['wips-patent-document'], 'description')
        removeTextField(rawJson['wips-patent-document'], 'abstract')
        removeTextField(rawJson['wips-patent-document']['bibliographic-data'], 'abstract-correction')
        removeTextField(rawJson['wips-patent-document']['bibliographic-data'], 'claims')
        removeTextField(rawJson['wips-patent-document']['bibliographic-data'], 'description')
        removeTextField(rawJson['wips-patent-document']['bibliographic-data'], 'abstract')
        patRawJp.setRawJson(JsonOutput.toJson(rawJson))
        def rawPubNo = ""
        rawJson['wips-patent-document']['bibliographic-data']['Publication-reference'].each { pubRef ->
            if(pubRef['data-format'] == "original") {
                rawPubNo = pubRef['document-id']['doc-num']
                return true
            }
        }
        if(rawPubNo.equals("")) {
            throw new Exception("PatRawJp no raw_public_no")
        }
        patRawJp.setXmlType(XSD_TYPE.WIPS_APPLICATION.toString())
        Date curTime = new Date();
        patRawJp.setCreateDate(curTime)
        patRawJp.setLastUpdDate(curTime)
        return patRawJp
    }

    static covertCountry2Lang(country) {
        def lang = ""
        if(!!country) {
            if(country =~ /(?i)jp/) {
                lang = com.patentdata.common.Constants.JP_LANG
            } else if(country =~ /(?i)us/) {
                lang = com.patentdata.common.Constants.US_LANG
            } else {
                throw new Exception("unexpect lang: " + lang)
            }
        }
        return lang
    }

    static cloneObj(doc) {
         def bos = new ByteArrayOutputStream()
         def oos = new ObjectOutputStream(bos)
         oos.writeObject(doc); oos.flush()
         def bin = new ByteArrayInputStream(bos.toByteArray())
         def ois = new ObjectInputStream(bin)
         return ois.readObject()
    }

    /**
     * 
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    @Override
    void processFailData(DBObject data, String message) throws Exception {
        // TODO Auto-generated method stub
        logger.info("process fail data")
    }

    public static void main(String[] args) throws Exception {
        //parser args
        def cli = new CliBuilder(
            usage: 'import jp marshall (1993~2011) to postgresql',
            header: '\nAvailable options (use -h for help):\n')
        
        cli.with
        {
            h(longOpt: 'help', 'Usage Information', required: false)
            k(longOpt: 'kindcode', 'A, U, A1, etc.'
                        , args: 1, required: true)
            s(longOpt: 'startDate', '19900101', args: 1, required: true)
            e(longOpt: 'endDate', '19900131', args: 1, required: true)
        }
        
        def opt = cli.parse(args)
        
        if (!opt) {
            cli.usage()
            assert opt : "some argument is required"
        }
        if (opt.h) cli.usage()
        def kindcode = opt.k
        def startDate = com.patentdata.util.DateUtil.parseDate(opt.s)
        def endDate = com.patentdata.util.DateUtil.parseDate(opt.e)
//        def kindcode = "U"
//        def startDate = com.patentdata.util.DateUtil.parseDate("19000101")
//        def endDate = com.patentdata.util.DateUtil.parseDate("20150101")
        def queryMap = [:]
        queryMap << ['doDate' : ['$gte' : startDate, '$lt' : endDate], 'kindcode': kindcode]
        //queryMap <<['_id': 'JP19940014119A']
        new JPOPatDataProcess().queryMap(queryMap).process();
        logger.info("finished...");
    }
}