package com.patentdata.process

import java.nio.file.Files
import java.nio.file.StandardOpenOption
import java.util.regex.Matcher

import com.gmongo.GMongoClient
import com.mongodb.Bytes
import com.mongodb.DB
import com.mongodb.DBCollection
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.common.CommonEnum
import com.patentdata.common.Constants
import com.patentdata.common.PatTypeEnum
import com.patentdata.common.CommonEnum.COUNTRY
import com.patentdata.helper.PersonDataHelper
import com.patentdata.model.AppData
import com.patentdata.model.PatClsCpc
import com.patentdata.model.PatClsCpcId
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatData
import com.patentdata.model.PatDataBrief
import com.patentdata.model.PatDataBriefId
import com.patentdata.model.PatDataClaims
import com.patentdata.model.PatDataClaimsId
import com.patentdata.model.PatDataDesc
import com.patentdata.model.PatDataDescId
import com.patentdata.model.PatDataTitle
import com.patentdata.model.PatDataTitleId
import com.patentdata.model.PatPersonAgent
import com.patentdata.model.PatPersonAgentId
import com.patentdata.model.PatPersonApplicant
import com.patentdata.model.PatPersonApplicantId
import com.patentdata.model.PatPersonAssignee
import com.patentdata.model.PatPersonAssigneeId
import com.patentdata.model.PatPersonExaminer
import com.patentdata.model.PatPersonExaminerId
import com.patentdata.model.PatPersonInventor
import com.patentdata.model.PatPersonInventorId
import com.patentdata.model.PatPtopidMapping
import com.patentdata.model.PatRawEp
import com.patentdata.model.PatRefCited
import com.patentdata.model.PatRefCitedNpl
import com.patentdata.model.PatRefPct
import com.patentdata.model.PatRefPriority
import com.patentdata.model.PersonData
import com.patentdata.service.AppDataService
import com.patentdata.service.PatClsService
import com.patentdata.service.PatDataService
import com.patentdata.service.PatPtopidMappingService
import com.patentdata.service.PatRawService
import com.patentdata.service.PatRefService
import com.patentdata.service.PersonDataServices
import com.patentdata.util.CheckUtil
import com.patentdata.util.DateUtil
import com.patentdata.util.JSONUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatClsUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.PatRefUtil
import com.patentdata.util.StringUtil
import com.patentdata.util.UUIDUtil

/**
 * 
 * @author ericxiao
 *
 */
class EPPatDataProcess extends BaseProcess {

    private HashMap lostPersonInventorMap = ["1":"thedesignationoftheinventorhasnotyetbeenfiled", "2":"dieerfindernennungliegtnochnichtvor", "3":"ladésignationdel'inventeurn'apasencoreétédéposée", "4":"ladésignationdel'inventeurn'apasencoreétéd"]
    private static GMongoClient oldDB;
    private static DBCollection oldInfoCol;
    private AppData appData;
    private static HashMap noOriLangMap = [:];
    private static GMongoClient client;
    private static DB marshalDB;
    private static DBCollection marCol;
    private static int skipNo = 0;

    /**
     * 因確認有些patent,沒有ori_lang,故在這裡處理
     */
    static {
        new File("T:/EPO/document/no_origin_lang.txt").eachLine { docNo ->
            noOriLangMap << [(docNo):""];
        }
    }

    @Override
    DBCursor queryData() throws Exception {
        oldDB = MongoUtil.connect121DB();
        DB oldInfoDB = oldDB.getDB("PatentInfoEPO");
        oldInfoCol= oldInfoDB.getCollection("PatentInfoEPO");

        client = MongoUtil.connectByConfig(COUNTRY.EP.getCountryName());
        marshalDB = client.getDB("PatentMarshallEPO");
        marCol = marshalDB.getCollection("PatentMarshallEPO");

        //        String beginDateString = "20160131"
        //        String endDateString = "20160206"
        //        Date beginDate = DateUtil.parseDate(beginDateString)
        //        Date endDate = DateUtil.parseDate(endDateString)
        //        Map queryMap = [doDate:["$gte":beginDate,"$lt":endDate]]

        DBCursor queryRespond = marCol.find(queryMap).addOption(Bytes.QUERYOPTION_NOTIMEOUT).skip(skipNo);
        return queryRespond;
    }

    @Override
    void processData(DBObject doc) throws Exception {
        if (!noOriLangMap.containsKey(doc["patentNumber"]) && doc["_id"].contains("OPS")) {
            String patentNumber = doc["patentNumber"];
            DBObject oldInfoDoc = oldInfoCol.findOne([patentNumber:patentNumber]);

            Date now = new Date();
            Date last = now;
            DBObject root = getRoot(doc);

            Map titles = getTitle(root);
            Map claims = getClaims(doc);
            Map desc = getDesc(doc);
            Map brief = getBrief(root);

            String marshallId = doc["_id"];
            int stat = doc["stat"];
            Date docDate = doc["doDate"];

            appData = genAppData(root, doc, now);
            appData.createDate = now;
            appData.lastUpdDate = last;

            PatData patData = genPatData(root, doc, appData, oldInfoDoc);
            patData.createDate = now;
            patData.lastUpdDate = last;

            int appYear = DateUtil.toISODate(appData.appDate, "yyyy-MM-dd'T'HH:mm:ssZ")[0..3] as int;
            int doYear = DateUtil.toISODate(patData.docDate, "yyyy-MM-dd'T'HH:mm:ssZ")[0..3] as int;
            Boolean checkFlag = CheckUtil.checkYear(appYear, doYear);

            if (!checkFlag) {
                throw new Exception("app date and public date distance error");
            }

            AppDataService ads = new AppDataService();
            ads.saveOrUpdateAppData(appData);

            PatDataService pds = new PatDataService();
            pds.saveOrUpdatePatData(patData);

            PatRawEp patRawEp = genPatRawEp(root, doc, patData);
            patRawEp.createDate = now;
            patRawEp.lastUpdDate = last;
            PatRawService prs = new PatRawService();
            prs.saveOrUpdatePatRawEp(patRawEp);

            saveOrUpdatedPersonRelatedData(root, patData, now);

            List<PatDataClaims> patDataClaimsList = new ArrayList<PatDataClaims>();
            patDataClaimsList = genPatDataClaims(claims, root, patData);
            pds.saveOrUpdatePatDataClaims(patDataClaimsList);

            List<PatDataBrief> patDataBriefList = new ArrayList<PatDataBrief>();
            patDataBriefList = genPatDataBrief(brief, root, patData);
            pds.saveOrUpdatePatDataBrief(patDataBriefList);

            List<PatDataTitle> patDataTitleList = new ArrayList<PatDataTitle>();
            patDataTitleList = genPatDataTitle(titles, patData, root);

            pds.saveOrUpdatePatDataTitle(patDataTitleList);

            List<PatDataDesc> patDataDescList = new ArrayList<PatDataDesc>();
            patDataDescList = genPatDataDesc(desc, root, patData);
            pds.saveOrUpdatePatDataDesc(patDataDescList);

            saveOrUpdateCls(root, patData);

            saveOrUpdateRef(root, patData, appData);

            if (!!oldInfoDoc) {
                saveMapingTable(patData, oldInfoDoc["_id"].toString());
            } else {
                throw new Exception("no old info data for mapping!");
            }
        }
    }

    /**
     * 
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    @Override
    void processFailData(DBObject data, String message) throws Exception {
        //TODO
        Files.write(new File("./error.txt").toPath(), (data["_id"].toString() + "\t" + message + System.lineSeparator).bytes, StandardOpenOption.APPEND)
    }

    /**
     * 產生appData,以便存入postgresql
     * @param root
     * @param doc
     * @param now
     * @return
     */
    private AppData genAppData(DBObject root, DBObject doc, Date now) {
        AppData appData = new AppData();
        String dateString;
        Date date;
        if (root["SDOBI"] != null) {
            dateString = root["SDOBI"]["B200"]["B220"]["date"];
            date = DateUtil.parseDate(dateString);
            String appNo = root["SDOBI"]["B200"]["B210"];
            appData.appId = PatNumberUtil.getAppIdEP(appNo);
            appData.appNo = appNo;
            appData.country = root["country"];
            appData.appDate = date;
            if (!!root["SDOBI"]["B200"]["B250"]) {
                appData.appLang = root["SDOBI"]["B200"]["B250"]["value"].toLowerCase();
            }
            appData.createDate = now;
            appData.lastUpdDate = now;
        } else {
            root["bibliographic-data"]["application-reference"][0]["document-id"].each { app ->
                if (app["document-id-type"] == "docdb") {
                    String oriAppNo = app["doc-number"];
                    String fixAppNo = PatNumberUtil.getAppNoEP(oriAppNo, COUNTRY.EP.getCountryName());
                    appData.appId = PatNumberUtil.getAppIdEP(fixAppNo);
                    appData.appNo = fixAppNo;
                    appData.country = app["country"];
                }
                if (app["document-id-type"] == "epodoc") {
                    dateString = app["date"];
                    date = DateUtil.parseDate(dateString);
                    appData.appDate = date;
                }
            }
            appData.createDate = now;
            appData.lastUpdDate = now;
        }

        return appData;
    }

    /**
     * 產生patData,以便存入postgresql
     * @param root
     * @param doc
     * @param appData
     * @return
     */
    private PatData genPatData(DBObject root, DBObject doc, AppData appData, DBObject oldDoc) {
        PatData patData = new PatData();
        if (root["SDOBI"] != null) {
            String patId = PatNumberUtil.getPatIdEP(doc);
            patData.patId = patId;
            patData.country = root["country"];
            patData.rawAppNo = root["SDOBI"]["B200"]["B210"];
            patData.appId = appData.appId;
            patData.rawDocNo = root["SDOBI"]["B100"]["B110"]["value"];
            patData.docNo = PatNumberUtil.getDocNoEP(root["SDOBI"]["B100"]["B110"]["value"]);
            patData.docDate = DateUtil.parseDate(doc["data"]["ep-patent-document"]["date-publ"]);
            patData.kindCode = root["SDOBI"]["B100"]["B130"]["value"];
            patData.stat = doc["stat"];
            patData.patType = PatTypeEnum.EP.findPatTypeCode("Utility");
            if (!!root["SDOBI"]["B200"]["B240"]) {
                if (!!root["SDOBI"]["B200"]["B240"]["B241"]) {
                    String regDateStr = root["SDOBI"]["B200"]["B240"]["B241"]["date"];
                    Date regDate = DateUtil.parseDate(regDateStr);
                    patData.registrationDate = regDate;
                    patData.examAppDate = regDate;
                }
            }
            if (!!root["SDOBI"]["B200"]["B260"]) {
                patData.oriLang = root["SDOBI"]["B200"]["B260"]["value"];
            } else if (!!root["lang"]) {
                patData.oriLang = root["lang"];
            } else {
                throw new Exception("no origin language");
            }
            patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES;
            patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
            patData.deleteFlag = Constants.DELETE_FLAG_NO;
            patData.defaultSourceId = Constants.SOURCE_ID_EP_FULLTEXT;
            int truncateFlag = doc["truncate"] ? Constants.TRUNCATE_FLAG_TRUE:Constants.TRUNCATE_FLAG_FALSE;
            patData.truncateFlag = truncateFlag;
            patData.gazetteNo = root["SDOBI"]["B400"]["B405"]["bnum"];
            patData.gazettePublicDate = DateUtil.parseDate(root["SDOBI"]["B400"]["B405"]["date"]);
            if (!!root["SDOBI"]["B800"]["B810"]) {
                patData.designationOfStatesJson = root["SDOBI"]["B800"]["B810"];
            }
            if (!!oldDoc["filePageClaim"]) {
                patData.pageNoOfClaim = oldDoc["filePageClaim"];
            }
            if (!!oldDoc["filePageDesc"]) {
                patData.pageNoOfDesc = oldDoc["filePageDesc"];
            }
            patData.firstImgFlag = (oldDoc["firstImagePageFlag"])? 1:0;
            if (!!oldDoc["filePageNumber"]) {
                patData.totalPages = oldDoc["filePageNumber"];
            }
            if (!!oldDoc["filePageFirst"]) {
                patData.pageNoOfFirstImg = oldDoc["filePageFirst"];
            }
            if (!!oldDoc["filePageFig"]) {
                patData.pageNoOfFigure = oldDoc["filePageFig"];
            }
        } else {
            root["bibliographic-data"]["publication-reference"][0]["document-id"].each { pub ->
                if (pub["document-id-type"] == "docdb") {
                    String patId = COUNTRY.EP.getCountryName() + doc["_id"].replace("-OPS","")
                    patData.patId = patId;
                    patData.country = pub["country"];
                    patData.rawAppNo = pub["doc-number"];
                    patData.appId = appData.appId;
                    patData.rawDocNo = pub["doc-number"];
                    patData.docNo = PatNumberUtil.getDocNoEP(patData.rawDocNo);
                    patData.docDate = DateUtil.parseDate(pub["date"] as String);
                    patData.kindCode = pub["kind"];
                    patData.stat = doc["stat"];
                    patData.patType = PatTypeEnum.EP.findPatTypeCode("Utility");
                    patData.defaultSourceId = Constants.SOURCE_ID_EP_FULLTEXT;
                    patData.oriLang = genLang(root, doc);
                    patData.docdbFlag = Constants.DOCDB_FLAG_NO;
                    patData.ptoFlag = Constants.FULL_TEXT_FLAG_YES;
                    patData.cryptoFlag = Constants.CRYPTO_FLAG_NO;
                    patData.deleteFlag = Constants.DELETE_FLAG_NO;
                    patData.familyId = root["family-id"];
                    int truncateFlag = doc["truncate"] ? Constants.TRUNCATE_FLAG_TRUE:Constants.TRUNCATE_FLAG_FALSE;
                    patData.truncateFlag = truncateFlag;
                }
            }
        } // end if eles EPD and OPS
        return patData;
    }

    /**
     * 產生patent lang for OPS
     * @param root
     * @param doc
     * @return
     */
    private String genLang(DBObject root, DBObject doc) {
        String lang;
        if (!!root["bibliographic-data"]["language-of-publication"]) {
            lang = root["bibliographic-data"]["language-of-publication"]["value"];
        } else if (!!root["abstract"]) {
            root["abstract"].each { key, value ->
                lang = key;
            }
        } else if (!!doc["data"]["claims"]) {
            lang = doc["data"]["claims"]["world-patent-data"]["fulltext-documents"]["fulltext-document"][0]["claims"][0]["lang"];
        } else if (!!doc["data"]["description"]) {
            doc["data"]["description"]["world-patent-data"]["fulltext-documents"]["fulltext-document"][0]["description"].each { key, value ->
                lang = key;
            }
        }
        return lang;
    }

    /**
     * 從doc取出title,以便後面處理
     * @param root
     * @return
     */
    private Map getBrief(DBObject root) {
        Map brief;
        if (root["SDOBI"] != null) {
            if (!!root["abstract"]) {
                brief = root["abstract"].toMap();
            }
        } else {
            if (!!root["abstract"]) {
                brief = root["abstract"].toMap();
            }
        }
        return brief;
    }

    /**
     * 取出description,以便後面處理
     * @param doc
     * @return
     */
    private Map getDesc(DBObject doc) {
        Map desc;
        if (!!doc["data"]["ep-patent-document"]) {
            if (!!doc["data"]["ep-patent-document"]["description"]) {
                desc = doc["data"]["ep-patent-document"]["description"].toMap();
            }
        } else {
            if (!!doc["data"]["descrription"]) {
                desc = doc["data"]["descrription"]["world-patent-data"]["fulltext-documents"]["fulltext-document"][0]["description"].toMap();
            }
        }
        return desc;
    }

    /**
     * 取出claim,以便後面處理
     * @param doc
     * @return
     */
    private Map getClaims(DBObject doc) {
        Map claims;
        if (!!doc["data"]["ep-patent-document"]) {
            if (!!doc["data"]["ep-patent-document"]["claims"]) {
                claims = doc["data"]["ep-patent-document"]["claims"].toMap();
            }
        } else {
            if (!!doc["data"]["claims"]) {
                claims = doc["data"]["claims"]["world-patent-data"]["fulltext-documents"]["fulltext-document"][0]["claims"].toMap();
            }
        }
        return claims;
    }

    /**
     * 取出title,以便後面處理
     * @param root
     * @return
     */
    private Map getTitle(DBObject root) {
        Map titles;
        if (root["SDOBI"] != null) {
            if (!!root["SDOBI"]["B500"]["B540"]) {
                titles = root["SDOBI"]["B500"]["B540"].toMap();
            }
        } else {
            if (!!root["bibliographic-data"]["invention-title"]) {
                titles = root["bibliographic-data"]["invention-title"].toMap();
            }
        }
        return titles;
    }

    /**
     * 產生raw data,以便存入postgresql
     * @param root
     * @param doc
     * @param patData
     * @return
     */
    private PatRawEp genPatRawEp(def root, DBObject doc, PatData patData) {
        PatRawEp patRawEp = new PatRawEp();
        patRawEp.rawId = doc["_id"];
        patRawEp.patId = patData.patId;
        patRawEp.rawJson = generateRawJson(root, doc);
        return patRawEp;
    }

    /**
     * 取出mongo raw json,以便存入pat raw
     * @param root
     * @param doc
     * @return
     */
    private String generateRawJson(DBObject root, DBObject doc) {
        Map json = root;
        if (root["SDOBI"] != null) {
            json["SDOBI"]["B500"]["B540"].remove("B541")
            json["SDOBI"]["B500"]["B540"].remove("B542")
            json["SDOBI"]["B500"].remove("B540")
            json.remove("claims")
            json.remove("description")
        } else {
            json.remove("abstract");
            json["bibliographic-data"].removeField("invention-title");
        }
        if (JSONUtil.isJSONValid(json.toString())) {
            return json.toString();
        }
    }

    /**
     * 儲存或是更新與personData相關的table(agent, applicant, examiner, inventor, assignee)
     * @param root
     * @param patData
     * @param now
     */
    private void saveOrUpdatedPersonRelatedData(DBObject root, PatData patData, Date now) {
        List<PersonData> personDataList = new ArrayList<PersonData>();

        List<PatPersonApplicant> patPersonApplicants = genPatPersonApplicants(root, patData, personDataList, now);
        List<PatPersonInventor> patPersonInventors = genPatPersonInventors(root, patData, personDataList, now);
        List<PatPersonAgent> patPersonAgents = genPatPersonAgents(root, patData, personDataList, now);
        List<PatPersonAssignee> patPersonAssignees = genPatPersonAssignees(root, patData, personDataList, now);
        List<PatPersonExaminer> patPersonExaminers = genPatPatPersonExaminers(root, patData, personDataList, now);
        PersonDataServices pds = new PersonDataServices();
        pds.saveOrUpdate(personDataList, patPersonApplicants, patPersonInventors, patPersonAgents, patPersonAssignees, patPersonExaminers, null);
    }
    //for each OPS person to get country
    String opsPersonCountryMatch = /.*\[[\w\W]{2}\]/;

    /**
     * 產生agent,以便存入pat person agent
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    private List<PatPersonAgent> genPatPersonAgents(DBObject root, PatData patData, List<PersonData> personDataList, Date now) {
        List<PatPersonAgent> patPersonAgentList = new ArrayList<PatPersonAgent>();
        if (root["SDOBI"] != null) {
            if (root["SDOBI"]["B700"]["B740"] != null) {
                ArrayList agentsList = root["SDOBI"]["B700"]["B740"]["B741"];
                if (!!agentsList && agentsList.size() > Constants.ZERO) {
                    agentsList.eachWithIndex { agent, item ->
                        PersonData personData = genPersonData(agent, patData);
                        if (!!personData.personFacet) {
                            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                            if (existsData != null) {
                                personData = existsData;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonAgent patPersonAgent = genPatPersonAgent(patData, now, ++item, personData);
                            patPersonAgent.personData = personData;
                            patPersonAgentList.add(patPersonAgent);
                        }
                    } // end agentlist each loop
                } //end if EPD agent size
            } //end if EPD agent parent tag not null
        } else {
            if (!!root["bibliographic-data"]["parties"]["agents"]) {
                List agents = root["bibliographic-data"]["parties"]["agents"]["agent"];
                if (!!agents && agents.size() >= 1) {
                    List agentList = new ArrayList<Map>();
                    agentList = genAgentData(agents, patData);
                    agentList.eachWithIndex { agent, item->
                        PersonData personData = genPersonData(agent, patData);
                        PersonData existsPerson= PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList)
                        if (!!existsPerson) {
                            personData = existsPerson;
                        } else {
                            personData.personId = UUIDUtil.generateUUID();
                            personDataList.add(personData);
                        }
                        PatPersonAgent patPersonAgent = genPatPersonAgent(patData, now, ++item, personData);
                        patPersonAgent.repCode = agent["rep-type"];
                        patPersonAgent.personData = personData;
                        patPersonAgentList.add(patPersonAgent);
                    } // end ops agent list each loop
                } // end if ops agent list not null
            } // edn if ops agent parent tag not null
        } //end if else EPD or OPS
        return patPersonAgentList;
    }

    /**
     * 產生agent data (OPS),以便後續利用
     * @param agents
     * @param patData
     * @return
     */
    private List genAgentData(List agents, PatData patData) {
        Map agentCountryMap = new HashMap<String, String>();
        Map agentNameMap = new HashMap<String, String>();
        List agentList = new ArrayList<Map>();
        agents.each { agent ->
            if (agent["data-format"] == "epodoc") {
                String index = agent["sequence"];
                if (agent["agent-name"][0]["name"][0]["value"].trim().matches(opsPersonCountryMatch)) {
                    String country = agent["agent-name"][0]["name"][0]["value"].trim()[-3..-2];
                    agentCountryMap << [(index):country];
                } else {
                    agentCountryMap << [(index):null];
                }
            }
            if (agent["data-format"] == "original") {
                String name = agent["agent-name"][0]["name"][0]["value"].trim();
                String index = agent["sequence"];
                agentNameMap << [(index):name];
            }
        }
        if (agentCountryMap.size() != agentNameMap.size()) {
            if (agentCountryMap.size() > agentNameMap.size()) {
                agentCountryMap.clear();
                agentNameMap.clear();
                String agentMatchString = /([\s\S]+)\[([\w\W]{2})\]/
                agents.each { agent ->
                    String agentName = agent["agent-name"][0]["name"][0]["value"].trim();
                    if (agent["data-format"] == "epodoc") {
                        if (agentName.matches(agentMatchString)) {
                            String index = agent["sequence"];
                            agentName.replaceAll(agentMatchString) { full, name, country ->
                                agentCountryMap << [(index):country];
                                agentNameMap << [(index):name];
                            }
                            agentCountryMap.each { key, ctry ->
                                String name = agentNameMap[index];
                                agentList << [(name):ctry];
                            }
                        } else {
                            agentList << [(agentName):null]
                        }
                    }
                }
                return agentList;
            } else {
                int countryCount = agentCountryMap.size();
                agentNameMap.eachWithIndex { name, cou ->
                    int countDown = cou+1;
                    if (countDown <= countryCount) {
                        return true;
                    }
                    agentCountryMap << [("$countDown"):null];
                }
            }
        }
        //將兩個map(agentCountryMap, agentNameMap)結合成agentList
        agentCountryMap.each { index, ctry ->
            String name = agentNameMap[index];
            agentList << [(name):ctry];
        }
        return agentList;
    }

    /**
     * 產生agent data 加入 agentList
     * @param agent
     * @param patData
     * @param createdDate
     * @param item
     * @return
     */
    private PatPersonAgent genPatPersonAgent(PatData patData, Date createdDate, int item, PersonData personData) {
        PatPersonAgent patPersonAgent = new PatPersonAgent();
        patPersonAgent.createDate = createdDate;
        patPersonAgent.personCountry = personData.country;

        PatPersonAgentId patPersonAgentId = new PatPersonAgentId();
        patPersonAgentId.item = item;
        patPersonAgentId.sourceId = patData.defaultSourceId;
        patPersonAgentId.patId = patData.patId;
        patPersonAgent.id = patPersonAgentId;

        return patPersonAgent;
    }

    /**
     * 產生inventors,以便存入postgresql
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    private List<PatPersonInventor> genPatPersonInventors(DBObject root, PatData patData, List<PersonData> personDataList, Date now) {
        List<PatPersonInventor> patPersonInventorList = new ArrayList<PatPersonInventor>();
        if (root["SDOBI"] != null) {
            if (root["SDOBI"]["B700"]["B720"] != null) {
                ArrayList inventorsList = root["SDOBI"]["B700"]["B720"]["B721"];
                if (!!inventorsList && inventorsList.size() > Constants.ZERO) {
                    inventorsList.eachWithIndex { inventor, item ->
                        if (!!inventor["snm"]) {
                            String lostInventor = inventor["snm"].toLowerCase().replaceAll(' ','');
                            if (lostInventor != "" && !lostPersonInventorMap.containsValue(lostInventor)) {
                                PersonData personData = genPersonData(inventor, patData);
                                PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                                if (!!existsData) {
                                    personData = existsData
                                } else {
                                    personData.personId = UUIDUtil.generateUUID();
                                    personDataList.add(personData);
                                }
                                PatPersonInventor patPersonInventor = genPatPersonInventor(patData, now, ++item, personData);
                                patPersonInventor.personData = personData;
                                patPersonInventorList.add(patPersonInventor);
                            } // end if inventor has not be filled
                        } // end if each The inventors have agreed to waive their entitlement to designation.
                    } // end inventorList each loop
                } // end if inventorList not null
            } // end if inventorList parent tag not null
        } else {
            if (!!root["bibliographic-data"]["parties"]) {
                if (!!root["bibliographic-data"]["parties"]["inventors"]) {
                    List inventors = root["bibliographic-data"]["parties"]["inventors"]["inventor"];
                    if (!!inventors && inventors.size() >= 1) {
                        List inventorList = new ArrayList<Map>();
                        inventorList = genInventorData(inventors, patData);
                        inventorList.eachWithIndex { inventor, item->
                            PersonData personData = genPersonData(inventor, patData);
                            PersonData existsPerson = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList)
                            if (!!existsPerson) {
                                personData = existsPerson;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonInventor patPersonInventor = genPatPersonInventor(patData, now, ++item, personData);
                            patPersonInventor.personData = personData;
                            patPersonInventorList.add(patPersonInventor);
                        } // end ops invetor list each loop
                    } // end if inventor list is not null
                } // end if inventors tag is not null
            } // end if parties tag not null
        } //end if else EPD or OPS
        return patPersonInventorList;
    }

    /**
     * 產生inventor data(OPS), 以便後續使用
     * @param inventors
     * @param patData
     * @return
     */
    private List genInventorData(List inventors, PatData patData) {
        Map inventorCountryMap = new HashMap<String, String>();
        Map inventorNameMap = new HashMap<String, String>();
        List inventorList = new ArrayList<Map>();
        inventors.each { inventor ->
            if (inventor["data-format"] == "epodoc") {
                String index = inventor["sequence"];
                if (inventor["inventor-name"][0]["name"][0]["value"].trim().matches(opsPersonCountryMatch)) {
                    String country = inventor["inventor-name"][0]["name"][0]["value"].trim()[-3..-2];
                    inventorCountryMap << [(index):country];
                } else {
                    inventorCountryMap << [(index):null];
                }
            }
            if (inventor["data-format"] == "original") {
                String name = inventor["inventor-name"][0]["name"][0]["value"].trim();
                String index = inventor["sequence"];
                inventorNameMap << [(index):name];
            }
        }
        //有時兩邊數目不同,故重新處理
        if (inventorCountryMap.size() != inventorNameMap.size()) {
            if (inventorCountryMap.size() > inventorNameMap.size()) {
                inventorCountryMap.clear();
                inventorNameMap.clear();
                String inventorMatchString = /([\s\S]+)\[([\w\W]{2})\]/
                inventors.each { inventor ->
                    String inventorName = inventor["inventor-name"][0]["name"][0]["value"].trim();
                    if (inventor["data-format"] == "epodoc") {
                        if (inventorName.matches(inventorMatchString)) {
                            String index = inventor["sequence"];
                            inventorName.replaceAll(inventorMatchString) { full, name, country ->
                                inventorCountryMap << [(index):country];
                                inventorNameMap << [(index):name];
                            }
                            inventorCountryMap.each { key, ctry ->
                                String name = inventorNameMap[index];
                                inventorList << [(name):ctry];
                            }
                        } else {
                            inventorList << [(inventorName):null]
                        }
                    }
                }
                return inventorList;
            } else {
                int countryCount = inventorCountryMap.size();
                inventorNameMap.eachWithIndex { name, cou ->
                    int countDown = cou+1;
                    if (countDown <= countryCount) {
                        return true;
                    }
                    inventorCountryMap << [("$countDown"):null];
                }
            }
        }
        //將兩個map(inventorCountryMap, inventorNameMap)結合成inventorList
        inventorCountryMap.each { index, ctry ->
            String name = inventorNameMap[index];
            inventorList << [(name):ctry];
        }
        return inventorList;
    }

    /**
     * 產生inventorData 存入inventorList
     * @param inventor
     * @param patData
     * @param createdDate
     * @param item
     * @return
     */
    private PatPersonInventor genPatPersonInventor(PatData patData, Date createdDate, int item, PersonData personData) {
        PatPersonInventor patPersonInventor = new PatPersonInventor();
        patPersonInventor.createDate = createdDate;
        patPersonInventor.personCountry = personData.country;

        PatPersonInventorId patPersonInventorId = new PatPersonInventorId();
        patPersonInventorId.patId = patData.patId;
        patPersonInventorId.item = item;
        patPersonInventorId.sourceId = patData.defaultSourceId;
        patPersonInventor.id = patPersonInventorId;

        return patPersonInventor;
    }

    /**
     * 產生examiner list,以便postgresql存入
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    private List<PatPersonExaminer> genPatPatPersonExaminers(DBObject root, PatData patData, List<PersonData> personDataList, Date now) {
        List<PatPersonExaminer> patPersonExaminerList = new ArrayList<PatPersonExaminer>();
        if(root["SDOBI"] != null) {
            if (!!root["SDOBI"]["B700"]["B745"]) {
                ArrayList examinerList = root["SDOBI"]["B700"]["B745"];
                if (!!examinerList && examinerList.size() > Constants.ZERO) {
                    examinerList.each { examinerType ->
                        String type = examinerType.key
                        examinerType.eachWithIndex { examiner, item ->
                            PersonData personData = genPersonData(examiner, patData);
                            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                            if (!!existsData) {
                                personData = existsData;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonExaminer patPersonExaminer = genPatPersonExaminer(patData, now, ++item, personData);
                            patPersonExaminer.examinerType = (type == "B746") ? Constants.EXAMINER_TYPE_PRIMARY : Constants.EXAMINER_TYPE_ASSISTANT;
                            patPersonExaminer.personData = personData;
                            patPersonExaminerList.add(patPersonExaminer);
                        } // end examiner each loop
                    } // end examiner type each loop
                } // end if examinerList not null
            } // end if examinerList parent tag not null
        } else {
            if (!!root["bibliographic-data"]["parties"]) {
                if (!!root["bibliographic-data"]["parties"]["examiners"]) {
                    List examiners = root["bibliographic-data"]["parties"]["examiners"]["examiner"];
                    if (!!examiners && examiners.size() >= 1) {
                        List examinerList = new ArrayList<Map>();
                        examinerList = genExaminerData(examiners, patData);
                        examinerList.eachWithIndex { examiner, index->
                            PersonData personData = genPersonData(examiner, patData);
                            PersonData existsPerson= PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList)
                            if (!!existsPerson) {
                                personData = existsPerson;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonExaminer patPersonExaminer = genPatPersonExaminer(patData, now, ++item, personData);
                            patPersonExaminer.personData = personData;
                            patPersonExaminerList.add(patPersonExaminer);
                        } // end examiner list each loop
                    } // end if examiner list not null
                } // end if examiners not null
            } // end if partied not null
        } //end if else EPD or OPS

        return patPersonExaminerList;
    }

    /**
     * 產生examiner data(OPS),以便後續利用
     * @param examiners
     * @param patData
     * @return
     */
    private List genExaminerData(List examiners, PatData patData) {
        Map examinerCountryMap = new HashMap<String, String>();
        Map examinerNameMap = new HashMap<String, String>();
        List examinerList = new ArrayList<Map>();
        examiners.each { examiner ->
            if (examiner["data-format"] == "epodoc") {
                String index = examiner["sequence"];
                if (examiner["examiner-name"][0]["name"][0]["value"].trim().matches(opsPersonCountryMatch)) {
                    String country = examiner["examiner-name"][0]["name"][0]["value"].trim()[-3..-2];
                    examinerCountryMap << [(index):country];
                } else {
                    examinerCountryMap << [(index):""];
                }
            }
            if (examiner["data-format"] == "original") {
                String name = examiner["examiner-name"][0]["name"][0]["value"].trim();
                String index = examiner["sequence"];
                examinerNameMap << [(index):name];
            }
        }
        if (examinerCountryMap.size() != examinerNameMap.size()) {
            if (examinerCountryMap.size() > examinerNameMap.size()) {
                examinerCountryMap.clear();
                examinerNameMap.clear();
                String examinerMatchString = /([\s\S]+)\[([\w\W]{2})\]/
                examiners.each { examiner ->
                    String examinerName = examiner["examiner-name"][0]["name"][0]["value"].trim();
                    if (examiner["data-format"] == "epodoc") {
                        if (examinerName.matches(examinerMatchString)) {
                            String index = examiner["sequence"];
                            examinerName.replaceAll(examinerMatchString) { full, name, country ->
                                examinerCountryMap << [(index):country];
                                examinerNameMap << [(index):name];
                            }
                            examinerCountryMap.each { key, ctry ->
                                String name = examinerNameMap[index];
                                examinerList << [(name):ctry];
                            }
                        } else {
                            examinerList << [(examinerName):null]
                        }
                    }
                }
                return examinerList;
            } else {
                int countryCount = examinerCountryMap.size();
                examinerNameMap.eachWithIndex { name, cou ->
                    int countDown = cou+1;
                    if (countDown <= countryCount) {
                        return true;
                    }
                    examinerCountryMap << [("$countDown"):null];
                }
            }
        }
        examinerCountryMap.each { index, ctry ->
            String name = examinerNameMap[index];
            examinerList << [(name):ctry];
        }
        return examinerList;
    }

    /**
     * 產生examiner data 存入examinerList
     * @param examiner
     * @param patData
     * @param createdDate
     * @param item
     * @return
     */
    private PatPersonExaminer genPatPersonExaminer(PatData patData, Date createdDate, int item, PersonData personData) {
        PatPersonExaminer patPersonExaminer = new PatPersonExaminer();
        patPersonExaminer.createDate = createdDate;
        patPersonExaminer.personCountry = personData.country;

        PatPersonExaminerId patPersonExaminerId = new PatPersonExaminerId();
        patPersonExaminerId.patId = patData.patId;
        patPersonExaminerId.sourceId = patData.defaultSourceId;
        patPersonExaminerId.item = item;
        patPersonExaminer.id = patPersonExaminerId;

        return patPersonExaminer
    }

    /**
     * 產生assignee list,以便postgresql存入
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    private List<PatPersonAssignee> genPatPersonAssignees(def root, PatData patData, List<PersonData> personDataList, Date now) {
        List<PatPersonAssignee> patPersonAssigneeList = new ArrayList<PatPersonAssignee>();
        if (root["SDOBI"] != null) {
            if (root["SDOBI"]["B700"]["B730"] != null) {
                ArrayList assigneeList = root["SDOBI"]["B700"]["B730"]["B731"];
                if (!!assigneeList && assigneeList.size() > Constants.ZERO) {
                    assigneeList.eachWithIndex { assignee, item ->
                        PersonData personData = genPersonData(assignee, patData);
                        if (!!personData.personFacet) {
                            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                            if (!!existsData) {
                                personData = existsData
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonAssignee patPersonAssignee = genPatPersonAssignee(patData, now, ++item, personData);
                            patPersonAssignee.personData = personData;
                            patPersonAssigneeList.add(patPersonAssignee);
                        }
                    } // end assigneeList each loop
                } // end if assigneeList not null
            } // end if assigneeList parent tag not null
            //        } else {
            //            if (!!root["bibliographic-data"]["parties"]) {
            //                if (!!root["bibliographic-data"]["parties"]["assignees"]) {
            //                    List assignees = root["bibliographic-data"]["parties"]["assignees"]["assignee"];
            //                    if (!!assignees && assignees.size() >= 1) {
            //                        List assigneesList = new ArrayList<Map>();
            //                        assigneesList = genAssigneeData(assignees, patData);
            //                        assigneesList.eachWithIndex { assignee, item->
            //                            PersonData personData = genPersonData(assignee, patData);
            //                            PersonData existsPerson= PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personData.country)
            //                            if (!!existsPerson) {
            //                                personData = existsPerson;
            //                            } else {
            //                                personData.personId = UUIDUtil.generateUUID();
            //                                personDataList.add(personData);
            //                            }
            //                            PatPersonAssignee patPersonAssignee = genPatPersonAssignee(patData, now, ++item, personData);
            //                            patPersonAssignee.personData = personData;
            //                            patPersonAssigneeList.add(patPersonAssignee);
            //                        } //end assignee list each loop
            //                    } //end if assignee list not null
            //                } // end if assignees tag not null
            //            } // end if  parties tag not null
        } // end if else EPD or OPS
        return patPersonAssigneeList;
    }

    /**
     * 產生assignee data(OPS),以便後續利用
     * @param assignees
     * @param patData
     * @return
     */
    private List genAssigneeData(List assignees, PatData patData) {
        Map assigneeCountryMap = new HashMap<String, String>();
        Map assigneeNameMap = new HashMap<String, String>();
        List assigneeList = new ArrayList<Map>();
        assignees.each { assignee ->
            if (assignee["data-format"] == "epodoc") {
                String index = assignee["sequence"];
                if (assignee["assignee-name"][0]["name"][0]["value"].trim().matches(opsPersonCountryMatch)) {
                    String country = assignee["assignee-name"][0]["name"][0]["value"].trim()[-3..-2];
                    assigneeCountryMap << [(index):country];
                } else {
                    assigneeCountryMap << [(index):""];
                }
            }
            if (assignee["data-format"] == "original") {
                String name = assignee["assignee-name"][0]["name"][0]["value"].trim();
                String index = assignee["sequence"];
                assigneeNameMap << [(index):name];
            }
        }
        if (assigneeCountryMap.size() != assigneeNameMap.size()) {
            if (assigneeCountryMap.size() > assigneeNameMap.size()) {
                assigneeCountryMap.clear();
                assigneeNameMap.clear();
                String assigneeMatchString = /([\s\S]+)\[([\w\W]{2})\]/
                assignees.each { assignee ->
                    String assigneeName = assignee["assignee-name"][0]["name"][0]["value"].trim();
                    if (assignee["data-format"] == "epodoc") {
                        if (assigneeName.matches(assigneeMatchString)) {
                            String index = assignee["sequence"];
                            assigneeName.replaceAll(assigneeMatchString) { full, name, country ->
                                assigneeCountryMap << [(index):country];
                                assigneeNameMap << [(index):name];
                            }
                            assigneeCountryMap.each { key, ctry ->
                                String name = assigneeNameMap[index];
                                assigneeList << [(name):ctry];
                            }
                        } else {
                            assigneeList << [(assigneeName):null]
                        }
                    }
                }
                return assigneeList;
            } else {
                int countryCount = assigneeCountryMap.size();
                assigneeNameMap.eachWithIndex { name, cou ->
                    int countDown = cou+1;
                    if (countDown <= countryCount) {
                        return true;
                    }
                    assigneeCountryMap << [("$countDown"):null];
                }
            }
        }
        assigneeCountryMap.each { index, ctry ->
            String name = assigneeNameMap[index];
            assigneeList << [(name):ctry];
        }
        return assigneeList;
    }

    /**
     * 產生assignee data 存入assigneeList
     * @param assignee
     * @param patData
     * @param createdDate
     * @param item
     * @return
     */
    private PatPersonAssignee genPatPersonAssignee(PatData patData, Date createdDate, int item, PersonData personData) {
        PatPersonAssignee patPersonAssignee = new PatPersonAssignee();
        patPersonAssignee.createDate = createdDate;
        patPersonAssignee.personCountry = personData.country;

        PatPersonAssigneeId patPersonAssigneeId = new PatPersonAssigneeId();
        patPersonAssigneeId.item = item;
        patPersonAssigneeId.patId = patData.patId;
        patPersonAssigneeId.sourceId = patData.defaultSourceId;
        patPersonAssignee.id = patPersonAssigneeId;

        return patPersonAssignee;
    }

    /**
     * 產生applicant list,以便postgresql存入
     * @param root
     * @param patData
     * @param personDataList
     * @param now
     * @return
     */
    private List<PatPersonApplicant> genPatPersonApplicants(DBObject root, PatData patData, List<PersonData> personDataList, Date now) {
        List<PatPersonApplicant> patPersonApplicantList = new ArrayList<PatPersonApplicant>();
        if (root["SDOBI"] != null) {
            if (root["SDOBI"]["B700"]["B710"] != null) {
                ArrayList applicantList = root["SDOBI"]["B700"]["B710"]["B711"];
                if (!!applicantList && applicantList.size() > Constants.ZERO) {
                    applicantList.eachWithIndex { applicant, item ->
                        PersonData personData = genPersonData(applicant, patData);
                        if (!!personData.personFacet) {
                            PersonData existsData = PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList);
                            if (!!existsData) {
                                personData = existsData;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonApplicant patPersonApplicant = genPatPersonApplicant(patData, now, ++item, personData);
                            patPersonApplicant.personData = personData;
                            patPersonApplicantList.add(patPersonApplicant);
                        }
                    } // end applicantList each loop
                } //end if applicantList not null
            } // end if applicantList parent tag not null
        } else {
            if (!!root["bibliographic-data"]["parties"]) {
                if (!!root["bibliographic-data"]["parties"]["applicants"]) {
                    List applicants = root["bibliographic-data"]["parties"]["applicants"]["applicant"];
                    if (!!applicants && applicants.size() >= 1) {
                        List applicantList = new ArrayList<Map>();
                        applicantList = genApplicantData(applicants, patData);
                        applicantList.eachWithIndex { applicant, item->
                            PersonData personData = genPersonData(applicant, patData);
                            PersonData existsPerson= PersonDataHelper.findExistsPersonDataByPersonFacet(personData.personFacet, personData.country, personDataList)
                            if (!!existsPerson) {
                                personData = existsPerson;
                            } else {
                                personData.personId = UUIDUtil.generateUUID();
                                personDataList.add(personData);
                            }
                            PatPersonApplicant patPersonApplicant = genPatPersonApplicant(patData, now, ++item, personData);
                            patPersonApplicant.personData = personData;
                            patPersonApplicantList.add(patPersonApplicant);
                        } // end applicant list each loop
                    } //end if applicant list not null
                } // end if applicants tag not null
            } // end if parties tag not null
        } // end if else EPD or OPS
        return patPersonApplicantList;
    }

    /**
     * 產生applicant data(OPS),以便後續利用
     * @param applicants
     * @param patData
     * @return
     */
    private List genApplicantData(List applicants, PatData patData) {
        Map applicantCountryMap = new HashMap<String, String>();
        Map applicantNameMap = new HashMap<String, String>();
        List applicantList = new ArrayList<Map>();
        applicants.each { applicant ->
            if (applicant["data-format"] == "epodoc") {
                String index = applicant["sequence"];
                if (applicant["applicant-name"][0]["name"][0]["value"].trim().matches(opsPersonCountryMatch)) {
                    String country = applicant["applicant-name"][0]["name"][0]["value"].trim()[-3..-2];
                    applicantCountryMap << [(index):country];
                } else {
                    applicantCountryMap << [(index):""];
                }
            }
            if (applicant["data-format"] == "original") {
                String name = applicant["applicant-name"][0]["name"][0]["value"].trim();
                String index = applicant["sequence"];
                applicantNameMap << [(index):name];
            }
        }
        if (applicantCountryMap.size() != applicantNameMap.size()) {
            if (applicantCountryMap.size() > applicantNameMap.size()) {
                applicantCountryMap.clear();
                applicantNameMap.clear();
                String applicantMatchString = /([\s\S]+)\[([\w\W]{2})\]/
                applicants.each { applicant ->
                    String applicantName = applicant["applicant-name"][0]["name"][0]["value"].trim();
                    if (applicant["data-format"] == "epodoc") {
                        if (applicantName.matches(applicantMatchString)) {
                            String index = applicant["sequence"];
                            applicantName.replaceAll(applicantMatchString) { full, name, country ->
                                applicantCountryMap << [(index):country];
                                applicantNameMap << [(index):name];
                            }
                            applicantCountryMap.each { key, ctry ->
                                String name = applicantNameMap[index];
                                applicantList << [(name):ctry];
                            }
                        } else {
                            applicantList << [(applicantName):null]
                        }
                    }
                }
                return applicantList;
            } else {
                int countryCount = applicantCountryMap.size();
                applicantNameMap.eachWithIndex { name, cou ->
                    int countDown = cou+1;
                    if (countDown <= countryCount) {
                        return true;
                    }
                    applicantCountryMap << [("$countDown"):null];
                }
            }
        }
        Map fixApplicantCountryMap = [:]
        applicantCountryMap.eachWithIndex { key, value, cou ->
            fixApplicantCountryMap << [(cou + 1):value]
        }
        Map fixApplicantNameMap = [:]
        applicantNameMap.eachWithIndex { key, value, cou ->
            fixApplicantNameMap << [(cou + 1):value]
        }
        fixApplicantCountryMap.each { index, ctry ->
            String name = fixApplicantNameMap[index];
            applicantList << [(name):ctry];
        }
        return applicantList;
    }

    /**
     * 產生 applicant data 存入 applicantList
     * @param applicant
     * @param patData
     * @param createdDate
     * @param item
     * @return
     */
    private PatPersonApplicant genPatPersonApplicant(PatData patData, Date createdDate, int item, PersonData personData) {
        PatPersonApplicant patPersonApplicant = new PatPersonApplicant();
        patPersonApplicant.createDate = createdDate;
        patPersonApplicant.personCountry = personData.country;

        PatPersonApplicantId patPersonApplicantId = new PatPersonApplicantId();
        patPersonApplicantId.patId = patData.patId;
        patPersonApplicantId.item = item;
        patPersonApplicantId.sourceId = patData.defaultSourceId;
        patPersonApplicant.id = patPersonApplicantId;

        return patPersonApplicant;
    }

    /**
     * 產生person data,以便postgresql存入
     * @param eachPersonTypeData
     * @param patData
     * @return
     */
    private PersonData genPersonData(Object eachPersonTypeData, PatData patData) {
        PersonData personData = new PersonData();
        if (eachPersonTypeData["snm"] != null) {
            if (!!eachPersonTypeData["snm"]) {
                personData.personName = StringUtil.wrapHtmlCode(eachPersonTypeData["snm"]);
                if (!!eachPersonTypeData["adr"]) {
                    if (!!eachPersonTypeData["adr"]["str"]) {
                        personData.address =  StringUtil.wrapHtmlCode(eachPersonTypeData["adr"]["str"][0].replaceAll("[\n\r]?", ""));
                    }
                    if (!!eachPersonTypeData["adr"]["city"]) {
                        personData.city = StringUtil.wrapHtmlCode(eachPersonTypeData["adr"]["city"]);
                    }
                    if (!!eachPersonTypeData["adr"]["state"]) {
                        personData.state = StringUtil.wrapHtmlCode(eachPersonTypeData["adr"]["state"]);
                    }
                    if (!!eachPersonTypeData["adr"]["postcode"]) {
                        personData.postcode = StringUtil.wrapHtmlCode(eachPersonTypeData["adr"]["pcode"]);
                    }
                    if (!!eachPersonTypeData["adr"]["ctry"]) {
                        personData.country = StringUtil.wrapHtmlCode(eachPersonTypeData["adr"]["ctry"]);
                    }
                }
                personData.lang = patData.oriLang;
                personData.personType = Constants.PERSON_TYPE_NONE;
                personData.personFacet = generatePersonFacet(personData);
                personData.createDate = patData.createDate;
                personData.lastUpdDate = patData.lastUpdDate;
            }
        } else {
            eachPersonTypeData.each { name, country ->
                personData.personName = name;
                if (!!country) {
                    personData.country = country;
                }
                personData.lang = patData.oriLang;
                personData.personFacet = generatePersonFacet(personData);
                personData.createDate = patData.createDate;
                personData.lastUpdDate = patData.lastUpdDate;
            }
        } //end if else EPD or OPS

        return personData
    }

    /**
     * 產生brief data,以便postgresql存入
     * @param briefs
     * @param root
     * @param patData
     * @return
     */
    private List<PatDataBrief> genPatDataBrief(Map briefs,DBObject root, PatData patData) {
        List<PatDataBrief> patDataBriefList = new ArrayList<PatDataBrief>();
        PatDataBrief patDataBrief;
        PatDataBriefId id;
        if (!!root["SDOBI"]) {
            briefs.each { keys, brief ->
                brief.each { lang, briefString ->
                    patDataBrief = new PatDataBrief();

                    id = new PatDataBriefId();

                    id.patId = patData.patId;
                    id.lang = lang.toLowerCase();
                    id.sourceId = patData.defaultSourceId;

                    patDataBrief.brief = briefString.trim();

                    patDataBrief.id = id;
                    patDataBrief.createDate = patData.createDate;
                    patDataBrief.lastUpdDate = patData.lastUpdDate;
                    patDataBriefList.add(patDataBrief);
                } // end briefMap each loop
            } // end briefMaps each loop
        } else {
            briefs.each { lang, string ->
                patDataBrief = new PatDataBrief();

                id = new PatDataBriefId();

                id.patId = patData.patId;
                id.lang = lang;
                id.sourceId = patData.defaultSourceId;

                patDataBrief.brief = string.trim();

                patDataBrief.id = id;
                patDataBrief.createDate = patData.createDate;
                patDataBrief.lastUpdDate = patData.lastUpdDate;
                patDataBriefList.add(patDataBrief);
            } // end ops briefMap each loop
        } // end if else EPD or OPS
        return patDataBriefList;
    }

    /**
     * 產生claims list,以便postgresql存入
     * @param claims
     * @param root
     * @param patData
     * @return
     */
    private List<PatDataClaims> genPatDataClaims(Map claims, DBObject root, PatData patData) {
        List<PatDataClaims> patDataClaimsList = new ArrayList<PatDataClaims>();
        PatDataClaims patDataClaims;
        PatDataClaimsId id
        if (!!root["SDOBI"]) {
            claims.each { keys, claim->
                claim.each { lang, string ->
                    patDataClaims = new PatDataClaims();

                    id = new PatDataClaimsId();
                    id.patId = patData.patId;
                    id.lang = lang;
                    id.sourceId = patData.defaultSourceId;

                    patDataClaims.id = id;
                    patDataClaims.claims = string.trim();
                    patDataClaims.createDate = patData.createDate;
                    patDataClaims.lastUpdDate = patData.lastUpdDate;
                    patDataClaimsList.add(patDataClaims);
                } // end claimMap each loop
            } //end claimMaps each loop
        } else {
            if (!!claims) {
                patDataClaims = new PatDataClaims();

                id = new PatDataClaimsId();
                id.patId = patData.patId;
                id.lang = claims["0"]["lang"];
                id.sourceId = patData.defaultSourceId;

                patDataClaims.id = id;
                patDataClaims.claims = claims["0"]["claim"].trim();
                patDataClaims.createDate = patData.createDate;
                patDataClaims.lastUpdDate = patData.lastUpdDate;
                patDataClaimsList.add(patDataClaims);
            }
        }
        return patDataClaimsList;
    }

    /**
     * 產生description list,以便postgresql存入
     * @param descs
     * @param root
     * @param patData
     * @return
     */
    private List<PatDataDesc> genPatDataDesc(Map descs, DBObject root, PatData patData) {
        List<PatDataDesc> patDataDescList = new ArrayList<PatDataDesc>();
        PatDataDesc patDataDesc;
        PatDataDescId id;
        if (!!root["SDOBI"]) {
            descs.each { keys, desc ->
                desc.each { lang, string ->
                    patDataDesc = new PatDataDesc();

                    id = new PatDataDescId();
                    id.patId = patData.patId;
                    id.lang = lang;
                    id.sourceId = patData.defaultSourceId;

                    patDataDesc.description = string.trim();
                    patDataDesc.id = id;
                    patDataDesc.createDate = patData.createDate;
                    patDataDesc.lastUpdDate = patData.lastUpdDate;
                    patDataDescList.add(patDataDesc);
                } // end descMap each loop
            } //end descMaps each loop
        } else {
            descs.each { lang, string ->
                patDataDesc = new PatDataDesc();

                id = new PatDataDescId();
                id.patId = patData.patId;
                id.lang = lang;
                id.sourceId = patData.defaultSourceId;

                patDataDesc.description = string.trim();
                patDataDesc.id = id;
                patDataDesc.createDate = patData.createDate;
                patDataDesc.lastUpdDate = patData.lastUpdDate;
                patDataDescList.add(patDataDesc);
            }
        }
        return patDataDescList;
    }

    /**
     * 產生title list,以便postgresql存入
     * @param titles
     * @param patData
     * @param root
     * @return
     */
    private List<PatDataTitle> genPatDataTitle(Map titles, PatData patData, DBObject root) {

        List<PatDataTitle> patDataTitleList = new ArrayList<PatDataTitle>();
        PatDataTitle patDataTitle;
        PatDataTitleId id;
        if (root["SDOBI"] != null) {
            List titleLang = titles["B541"];
            List titleString = titles["B542"];
            titleLang.eachWithIndex { lang, index ->
                patDataTitle = new PatDataTitle();

                id = new PatDataTitleId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.lang = lang;

                patDataTitle.id = id;
                patDataTitle.title = titleString[index]["value"].trim();
                patDataTitle.createDate = patData.createDate;
                patDataTitle.lastUpdDate = patData.lastUpdDate;
                patDataTitleList.add(patDataTitle);
            } //end titleLangList each loop
        } else {
            titles.each { lang, string ->
                patDataTitle = new PatDataTitle();

                id = new PatDataTitleId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.lang = lang;

                patDataTitle.id = id;
                patDataTitle.title = string.trim();
                patDataTitle.createDate = patData.createDate;
                patDataTitle.lastUpdDate = patData.lastUpdDate;
                patDataTitleList.add(patDataTitle);
            }
        } // end if else EPD or OPS
        return patDataTitleList;
    }

    /**
     * 產生ipc ipcr cpc
     * @param root
     * @param patData
     */
    private void saveOrUpdateCls(DBObject root, PatData patData) {
        PatClsService clsSvc = new PatClsService();

        List<PatClsIpc> patClsIpcList = new ArrayList<PatClsIpc>();
        patClsIpcList = genPatClsIpc(root, patData);
        clsSvc.saveOrUpdatePatClsIpc(patClsIpcList);

        List<PatClsCpc> patClsCpcList = new ArrayList<PatClsCpc>();
        patClsCpcList = genPatClsCpc(root, patData);
        clsSvc.saveOrUpdatePatClsCpc(patClsCpcList);
    }

    /**
     * 產生ipc list 及 ipcr list,以便postgresql存入
     * @param root
     * @param patData
     * @return
     */
    private List<PatClsIpc> genPatClsIpc(DBObject root, PatData patData) {
        List<PatClsIpc>patClsIpcList = new ArrayList<PatClsIpc>();
        PatClsIpcId id;
        PatClsIpc patClsIpc;
        int item = Constants.ZERO;
        if (!!root["SDOBI"]) {
            if (!!root."SDOBI"."B500"."B510") {
                String version = root."SDOBI"."B500"."B510"."B516";
                if (!!root."SDOBI"."B500"."B510"."B511") {
                    String mainIpcs = root."SDOBI"."B500"."B510"."B511";
                    item++;
                    patClsIpc = new PatClsIpc();

                    id = new PatClsIpcId();
                    id.item = item;
                    id.ipcType = Constants.CLS_TYPE_IPC;
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    patClsIpc.ipcText = PatClsUtil.formatDocdbIpc(mainIpcs);
                    patClsIpc.id = id;
                    patClsIpc.createDate = patData.createDate;
                    patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_YES;
                    patClsIpc.clsVersion = version;

                    patClsIpcList.add(patClsIpc);
                } // end if main ipc (EPD)

                List furtherIpcs = root."SDOBI"."B500"."B510"."B512";
                furtherIpcs.each { ipc->
                    item++;

                    id = new PatClsIpcId();
                    id.item = item;
                    id.ipcType = Constants.CLS_TYPE_IPC;
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;

                    patClsIpc = new PatClsIpc();
                    patClsIpc.ipcText = PatClsUtil.formatDocdbIpc(ipc);
                    patClsIpc.id = id;
                    patClsIpc.createDate = patData.createDate;
                    patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_NO;
                    patClsIpc.clsVersion = version;
                    patClsIpcList.add(patClsIpc);
                } //end if further ipc (EPD)
            } //end if ipcs

            if (!!root."SDOBI"."B500"."B510EP") {
                List ipcrs = root."SDOBI"."B500"."B510EP"."classification-ipcr";
                ipcrs.eachWithIndex { ipcr, index ->
                    patClsIpc = new PatClsIpc();
                    id = new PatClsIpcId();
                    String fixIpcr = ipcr["text"].replaceAll("\\s+","")
                    if (fixIpcr.size() < 15) {
                        id.patId = patData.patId;
                        id.sourceId = patData.defaultSourceId;
                        id.ipcType = Constants.CLS_TYPE_IPCR;

                        patClsIpc.id = id;
                        patClsIpc.ipcText = normalizeIpcs(ipcr["text"].trim());
                        String modifyIpcr = ipcr["text"].trim().replaceAll("\\s+", "");
                        patClsIpc.clsLevel = modifyIpcr[-2];
                        patClsIpc.clsValue = modifyIpcr[-1];
                        patClsIpc.createDate = patData.createDate;
                    } else {
                        patClsIpc = PatClsUtil.getDocdbIpcr(patData, ipcr);
                        id = patClsIpc.id;
                        id.sourceId = patData.defaultSourceId;

                    }
                    patClsIpcList.add(patClsIpc);
                } // end ipcrs(EPD) each loop
            } // end if ipcr
        } else {
            if (!!root["bibliographic-data"]["classification-ipc"]) {
                if (!!root["bibliographic-data"]["classification-ipc"]["main-classification"]) {
                    if (!!root["bibliographic-data"]["classification-ipc"]["main-classification"][0]) {
                        String ipc = root["bibliographic-data"]["classification-ipc"]["main-classification"][0];
                        patClsIpc = new PatClsIpc();
                        String fixIpc;
                        if (ipc.size() == 4) {
                            fixIpc = ipc;
                        } else {
                            fixIpc = ipc[0..3] + " " +ipc[4..-1];
                        }
                        patClsIpc.ipcText = normalizeIpcs(fixIpc);
                        patClsIpc.createDate = patData.createDate;
                        patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_YES;
                        id = new PatClsIpcId();
                        id.item = 1;
                        id.sourceId = patData.defaultSourceId;
                        id.patId = patData.patId;
                        id.ipcType = Constants.CLS_TYPE_IPC;
                        patClsIpc.id = id;

                        patClsIpcList.add(patClsIpc);
                    }
                    
                    if (!!root["bibliographic-data"]["classification-ipc"]["futher-classification"][0]) {
                        String ipc = root["bibliographic-data"]["classification-ipc"]["futher-classification"][0];
                        patClsIpc = new PatClsIpc();
                        String fixIpc;
                        if (ipc.size() == 4) {
                            fixIpc = ipc;
                        } else {
                            fixIpc = ipc[0..3] + " " +ipc[4..-1];
                        }
                        patClsIpc.ipcText = normalizeIpcs(fixIpc);
                        patClsIpc.createDate = patData.createDate;
                        patClsIpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;
                        id = new PatClsIpcId();
                        id.item = 2;
                        id.sourceId = patData.defaultSourceId;
                        id.patId = patData.patId;
                        id.ipcType = Constants.CLS_TYPE_IPC;
                        patClsIpc.id = id;

                        patClsIpcList.add(patClsIpc);
                    }
                }
                if (!!root["bibliographic-data"]["classification-ipc"]["text"]) {
                    List ipcList = root["bibliographic-data"]["classification-ipc"]["text"];
                    if (!!ipcList && ipcList.size() >= 1) {
                        ipcList.eachWithIndex { ipc, index ->
                            patClsIpc = new PatClsIpc();
                            String fixIpc;
                            if (ipc.size() == 4) {
                                fixIpc = ipc;
                            } else {
                                fixIpc = ipc[0..3] + " " +ipc[4..-1];
                            }
                            patClsIpc.ipcText = normalizeIpcs(fixIpc);
                            patClsIpc.createDate = patData.createDate;

                            id = new PatClsIpcId();
                            id.item = ++index;
                            id.sourceId = patData.defaultSourceId;
                            id.patId = patData.patId;
                            id.ipcType = Constants.CLS_TYPE_IPC;
                            patClsIpc.id = id;

                            patClsIpcList.add(patClsIpc);
                        } // end if ipc(OPS) list each loop
                    } // end if ipc(OPS) list not null
                } // end if root["bibliographic-data"]["classification-ipc"]["text"]
            } // end if root["bibliographic-data"]["classification-ipc"]

            if (!!root["bibliographic-data"]["classifications-ipcr"]) {
                if (!!root["bibliographic-data"]["classifications-ipcr"]["classification-ipcr"]) {
                    List ipcrList = root["bibliographic-data"]["classifications-ipcr"]["classification-ipcr"];
                    if (!!ipcrList && ipcrList.size() >= 1) {
                        ipcrList.each { ipcr ->
                            patClsIpc = new PatClsIpc();
                            id = new PatClsIpcId();
                            String fixIpcr = ipcr.text.replaceAll("\\s+","")
                            if (fixIpcr.size() < 15) {
                                id.patId = patData.patId;
                                id.sourceId = patData.defaultSourceId;
                                id.ipcType = Constants.CLS_TYPE_IPCR;
                                id.item = ipcr["sequence"] as int;

                                patClsIpc.id = id;
                                patClsIpc.ipcText = normalizeIpcs(ipcr["text"].trim());
                                String modifyIpcr = ipcr["text"].trim().replaceAll("\\s+", "");
                                patClsIpc.clsLevel = modifyIpcr[-2];
                                patClsIpc.clsValue = modifyIpcr[-1];
                                patClsIpc.createDate = patData.createDate;
                            } else {
                                patClsIpc = PatClsUtil.getDocdbIpcr(patData, ipcr);
                                id = patClsIpc.id;
                                id.sourceId = patData.defaultSourceId;
                            }
                            patClsIpcList.add(patClsIpc);
                        } // end if ipcr list each loop
                    } // end if ipcr list not null
                } // end if root["bibliographic-data"]["classifications-ipcr"]["classification-ipcr"]
            } // end if root["bibliographic-data"]["classifications-ipcr"]
        } // end if else EPD or OPS
        return patClsIpcList;
    }

    /**
     * 產生cpc list,以便postgresql存入
     * @param root
     * @param patData
     * @return
     */
    private List<PatClsCpc> genPatClsCpc(DBObject root, PatData patData) {
        List<PatClsCpc> patClsCpcList = new ArrayList<PatClsCpc>();
        if (!!root["bibliographic-data"]) {
            if (!!root["bibliographic-data"]["patent-classifications"]) {
                if (!!root["bibliographic-data"]["patent-classifications"][0]) {
                    if (!!root["bibliographic-data"]["patent-classifications"][0]["patent-classification"]) {
                        List cpcList = root["bibliographic-data"]["patent-classifications"][0]["patent-classification"];
                        if (!!cpcList && cpcList.size() >= 1) {
                            cpcList.each { cpc ->
                                PatClsCpc patClsCpc = new PatClsCpc();
                                patClsCpc.schemaOriCode = cpc["classification-scheme"]["scheme"];
                                String section, classString, subClass, mainGroup, subGroup;
                                section = cpc["section"];
                                classString = cpc["class"]["value"];
                                subClass = cpc["subclass"];
                                mainGroup = cpc["main-group"];
                                subGroup = cpc["subgroup"];
                                if (cpc."classification-scheme"."scheme" == "CPC" || cpc."classification-scheme"."scheme" == "CPCNO") {
                                    if (!!cpc."classification-scheme"."date") {
                                        patClsCpc.clsVersion = cpc."classification-scheme"."date"
                                    } else if (!!cpc."classification-scheme"."edition") {
                                        patClsCpc.clsVersion = cpc."classification-scheme"."edition"
                                    }
                                }

                                if (!!cpc["classification-value"]) {
                                    patClsCpc.clsValue = cpc["classification-value"];
                                }
                                if (!!cpc."classification-data-source") {
                                    patClsCpc.clsDataSource = cpc."classification-data-source";
                                }
                                if (!!cpc."classification-scheme"?."scheme") {
                                    patClsCpc.schemaOriCode = cpc."classification-scheme"?."scheme";
                                }
                                patClsCpc.actionDate = DateUtil.parseDate(cpc."action-date"?."date");
                                patClsCpc.symbolPosition = cpc."symbol-position";
                                patClsCpc.clsStatus = cpc."classification-status";
                                patClsCpc.cpcText = PatClsUtil.formatClsCpcIPC(section, classString, subClass, mainGroup, subGroup);
                                patClsCpc.genOffice = cpc["classification-scheme"]["office"];
                                patClsCpc.rawMainFlag = Constants.CLS_CPC_MAIN_FLAG_NO;
                                patClsCpc.createDate = patData.createDate;

                                PatClsCpcId id = new PatClsCpcId();
                                id.sourceId = patData.defaultSourceId;
                                id.patId = patData.patId;
                                id.item = cpc["sequence"] as int;
                                patClsCpc.id = id;
                                patClsCpcList.add(patClsCpc);
                            } // end cpc list each loop
                        } // end if cpc list not null
                    } // end if root["bibliographic-data"]["patent-classifications"][0]["patent-classification"]
                } // end if root["bibliographic-data"]["patent-classifications"][0]
            } // end if root["bibliographic-data"]["patent-classifications"]
        } // end if root["bibliographic-data"]
        return patClsCpcList;
    }

    /**
     * format ipc及ipcr,以便後續利用
     * @param ipc
     * @return
     */
    private String normalizeIpcs(String ipc) {
        String normalIpc;
        String ipcMatchString = /\d+\s+(?<section>[A-H]?)(?<mainclass>\d{1,2})(?<subclass>[A-Z]?)\s+(?<maingroup>\d{1,4})\/(?<subgroup>\d{1,6})\s+([A-B]?)/;
        Matcher ipcMatch = ipc =~ ipcMatchString;

        String ipcrMatchString = /(?<section>[A-H]?)(?<mainclass>\d{1,2})(?<subclass>[A-Z]?)\s*(?<maingroup>\d{1,4})\/\s*(?<subgroup>\d{1,6})\s*([A,C,S]?)\s*([A-Z]?)/;
        Matcher ipcrMatch = ipc =~ ipcrMatchString;
        //G06F                       C I
        String anoIpcrMatchString = /([A-H]?)(\d{1,2})([A-Z]?)\s*([A,C,S]?)\s*([I,N]?)/;
        Matcher anoIpcrMatch = ipc =~ anoIpcrMatchString;

        String ipcrGroupMatchString = /([A-H]?)(\d{1,2})([A-Z]?)\s*([\w]?)/;
        Matcher ipcrGroupMatch = ipc =~ ipcrGroupMatchString;
        if (ipcMatch.matches()) {
            ipc.replaceAll(ipcMatchString) { full, section, mainClass, subClass, mainGroup, subGroup, classify ->
                normalIpc = PatClsUtil.formatClsCpcIPC(section, mainClass, subClass, mainGroup, subGroup);
            }
        } else if (ipcrMatch.matches()) {
            ipc.replaceAll(ipcrMatchString) { full, section, mainClass, subClass, mainGroup, subGroup, clsLevel, clsValue ->
                normalIpc = PatClsUtil.formatClsCpcIPC(section, mainClass, subClass, mainGroup, subGroup);
            }
        } else if (anoIpcrMatch.matches()) {
            ipc.replaceAll(anoIpcrMatchString) { full, section, mainClass, subClass, clsLevel, clsValue ->
                normalIpc = section + mainClass + subClass;
            }
        } else if (ipcrGroupMatch.matches()) {
            ipc.replaceAll(ipcrGroupMatchString) { full, section, mainClass, subClass, group ->
                normalIpc = section + mainClass + subClass;
            }
        } else {
            throw new Exception("wrong ipc format");
        }


        return normalIpc
    }

    /**
     * 處理各個ref及存入postgresql
     * @param root
     * @param patData
     */
    private void saveOrUpdateRef(DBObject root, PatData patData, AppData appData) {
        PatRefService prs = new PatRefService();
        List<PatRefCited> patRefCitedList = PatRefUtil.genPatRefCitedEP(root, patData);
        prs.savePatRefCited(patRefCitedList, patData.patId, patData.defaultSourceId);

        List<PatRefCitedNpl> patRefCitedNplList = PatRefUtil.genPatRefCitedNplEP(root, patData)
        prs.savePatRefCitedNpl(patRefCitedNplList, patData.patId, patData.defaultSourceId)

        PatRefPct patRefPct = PatRefUtil.genPatRefPctEP(root, patData);
        if (!!patRefPct) {
            prs.savePatRefPct(patRefPct);
        }

        List<PatRefPriority> patRefPriorityList = PatRefUtil.genPatRefPriorityListEP(root, patData);
        prs.savePatRefPriority(patRefPriorityList, patData.patId, patData.defaultSourceId);

        PatRefUtil.savePatRefRelatedParentAndChildEP(root, patData, prs, appData);
    }

    /**
     * 產生WO docNo,以便後續利用
     * @param docNo
     * @return
     */
    private static String genWoPublicNo(String docNo) {
        String docNoRegex = /(WO)(\d{2})(\d{1,6})/;
        String anoDocNoRegex = /(WO)(\d{4})(\d{1,6})/;
        String normalizeDocNo;
        if (docNo.matches(docNoRegex))  {
            docNo.replaceAll(docNoRegex) { full, country, year, no ->
                String normalizeYear = PatNumberUtil.getYearWO(year);
                String normalizeNo;
                if (no.size() <6) {
                    normalizeNo = "0" * (6 - no.size()) + no
                }
                normalizeDocNo =  PatNumberUtil.marshallidToDocNoWO(normalizeYear + normalizeNo);
            }
        } else if (docNo.matches(anoDocNoRegex)) {
            docNo.replaceAll(anoDocNoRegex) { full, country, year, no ->
                String normalizeYear = PatNumberUtil.getYearWO(year);
                String normalizeNo;
                if (no.size() <6) {
                    normalizeNo = "0" * (6 - no.size()) + no;
                } else {
                    normalizeNo = no;
                }
                normalizeDocNo =  PatNumberUtil.marshallidToDocNoWO(normalizeYear + normalizeNo);
            }
        } else {
            throw new Exception("ref pct wo public no not match!");
        }
        return normalizeDocNo;
    }

    /**
     * 產生app no,以便後續利用
     * @param rawAppNo
     * @param country
     * @return
     */
    private String genAppNoEp(String rawAppNo, String country) {
        String fixAppNo;
        if (country == "EP") {
            fixAppNo = PatNumberUtil.getAppNoEP(rawAppNo, "EP");
        } else {
            fixAppNo = rawAppNo;
        }
        return fixAppNo;
    }

    /**
     * 產生maping,以便postgresql存入
     * @param patData
     * @param ptopidId
     */
    private void saveMapingTable(PatData patData, String ptopidId) {
        PatPtopidMappingService ppms = new PatPtopidMappingService();
        PatPtopidMapping patPtopidMapping = new PatPtopidMapping();

        patPtopidMapping.patData = patData;
        patPtopidMapping.ptopidId = ptopidId;

        ppms.saveOrUpdatePatPtopidMapping(patPtopidMapping);
    }

    /**
     * 產生(EPD, OPS)root
     * @param doc
     * @return
     */
    private DBObject getRoot(DBObject doc) {
        DBObject root;
        if (doc["data"]["ep-patent-document"] != null) {
            root = doc["data"]["ep-patent-document"];
        } else {
            root = doc["data"]["biblio"]["world-patent-data"]["exchange-documents"]["exchange-document"][0];
        } // end if else EPD and OPS
        return root;
    }

    /**
     * 產生person facet,以便後續利用
     * @param personData
     * @return
     */
    private String generatePersonFacet(PersonData personData) {
        String facet;
        //facet字串,將person_name+address+city+state+postcode+country串起來
        String name, address, city, state, postcode,country;
        name = personData.personName;
        address = personData.address;
        city = personData.city;
        state = personData.state;
        postcode = personData.postcode;
        country = personData.country;
        if (!!name) {
            facet = name;
        }
        if (!!address) {
            facet += address;
        }
        if (!!city) {
            facet += city;
        }
        if (!!state) {
            facet += state;
        }
        if (!!postcode) {
            facet += postcode
        }
        if (!!country) {
            facet += country;
        }
        return StringUtil.personFacetWrap(facet);
    }

    static main(args) throws Exception {
        def cli = new CliBuilder(usage: 'EPPatDataProcess.groovy -[hbep]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                     'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyyMMdd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyyMMdd', 'End doDate'
            p longOpt: 'id', args:1, argName:'0012915-B1-19840516-EPD', 'id String'
            s longOpt: 'skip', args:1, argName:'the number you want skip', 'number'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }
        Map query = [:]
        if (!!options.b) {
            def beginDate = options.b;
            def endDate = options.e;
            def dateBegin = DateUtil.parseDate(beginDate);
            def dateEnd = DateUtil.parseDate(endDate);

            query = ["doDate" : ["\$gte" : dateBegin, "\$lt" : dateEnd]];
        }

        if (!!options.p) {
            query = [_id:options.p];
        }
        if (!!options.s) {
            skipNo = Integer.parseInt(options.s);
        }
        //        query = [_id:"1269674-A2-20030102-OPS"];
        //        query = [_id:"1267939-A2-20030102-OPS"]
        //        query = [_id:"2820948-A1-20150107-EPD"]
        //        query = [_id:"0241469-A1-19871021-OPS"]
        //        query = [_id:"2820948-A1-20150107-EPD"]
        //        query = [_id:"2551667-B1-20150107-EPD"]
        //        query = [_id:"2452030-B9-20160323-EPD"]
        //        query = [_id:"2925025-B1-20160323-EPD"]
        //        query = [_id:"2999044-A1-20160323-EPD"]
        //        query = [_id:"2793094-B9-20160323-EPD"]
        //        query = [_id:"0044957-A3-19820217-OPS"]
        //        query = [provider:"EPO_OPS"]
        //        query = [_id:"0044957-A3-19820217-OPS"]
        //        query = [_id:"0241469-A1-19871021-OPS"]
        //        query = [_id:"2146429-B1-20160323-EPD"]
        //        query = [_id :"0006960-A1-19800123-EPD"]
        //        query = [_id:"0074583-A3-19840104-OPS"]
        //        query = [_id:"0053132-B1-19840919-EPD"]
        //        query = [_id:"0146747-B1-19870429-EPD"]
        //        query = [_id:"0221171-A1-19870513-OPS"]
        //        query = [_id:"2997012-A1-20160323-EPD"]
        //        query = [_id:"0342264-A3-19901128-OPS"]

        //        query = [_id:"0394352-A1-19901031-EPD"]
        //        query = [_id:"0395688-A1-19901107-EPD"]
        //        query = [_id:"0274724-A3-19901212-OPS"]
        //        query = [_id:"0215226-B1-19900509-EPD"]
        //        query = [_id:"0355159-A1-19900228-OPS"]
        //        query = [_id:"0201554-A1-19861120-OPS"]
        //        query = [_id:"0412953-A3-19910502-OPS"]
        //        query = [_id:"0432188-A1-19910619-OPS"]
        //        query = [_id:"0447483-A1-19910925-OPS"]
        //        query = [_id:"0425542-A1-19910508-EPD"]
        //        query = [_id:"0423227-A1-19910424-OPS"]
        //        query = [_id:"0412953-A3-19910502-OPS"]
        //        query = [_id:"0267880-B1-19910410-EPD"]
        //        query = [_id:"0399000-A1-19901128-OPS"]
        //        query = [_id:"0476130-A1-19920325-OPS"]
        //        query = [_id:"0471030-A1-19920219-OPS"]
        //        query = [_id:"0471030-A1-19920219-OPS"]
        //        query = [_id:"0471280-A2-19920219-OPS"]
        //        query = [_id:"0205506-B1-19920311-EPD"]
        //        query = [_id:"0496152-A2-19920729-OPS"]
        //        query = [_id:"0201579-B1-19921007-EPD"]
        //        query = [_id:"0507604-A3-19931006-OPS"]
        //        query = [_id:"0467971-B1-19941019-EPD"]
        //        query = [_id:"0192199-A2-19860827-EPD"]
        //        query = [_id:"0806461-A1-19971112-EPD"]
        //        query = [_id:"0006088-A2-19791212-OPS"]
        //        query = [_id:"0000010-A1-19781220-EPD"]
        //        query = [_id:"0000010-A1-19781220-EPD"]
        //        query = [_id:'0114494-A3-19860312-EPD']
        //        query = [_id:"0151253-B1-19900912-EPD"]
        query = [doDate:["\$gte":DateUtil.parseDate("20020101"),"\$lt":DateUtil.parseDate("20020701")], provider:"EPO_OPS"]
        new EPPatDataProcess().queryMap(query).process();
    }
}