package com.patentdata.common;

public class CommonEnum {

    public enum COUNTRY {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME), 
        US(1, "US"), 
        CN(2, "CN"), 
        JP(3, "JP"), 
        DOCDB(4, "DOCDB"), 
        EP(5, "EP"), 
        WO(6, "WO"), 
        TW(7, "TW"), 
        KR(8, "KR"), 
        IN(9, "IN");

        private final int countryCode;
        private final String countryName;

        public int getCountryCode() {
            return countryCode;
        }

        public String getCountryName() {
            return countryName;
        }

        private COUNTRY(int countryCode, String countryName) {
            this.countryCode = countryCode;
            this.countryName = countryName;
        }

        public static int findCuntryCode(String countryName) {
            if (countryName == null || countryName.length() == 0) {
                return NO_DEFINED.countryCode;
            }
            for (COUNTRY element : COUNTRY.values()) {
                if (element.getCountryName().equals(countryName)) {
                    return element.getCountryCode();
                }
            }
            return NO_DEFINED.countryCode;
        }

        public static String findCountryName(Integer countryCode) {
            if (countryCode == null) {
                return NO_DEFINED.countryName;
            }
            for (COUNTRY element : COUNTRY.values()) {
                if (element.getCountryCode() == countryCode) {
                    return element.getCountryName();
                }
            }
            return NO_DEFINED.countryName;
        }

    }

    public enum CITEDBYTYPE {

        UNKNOW(Constants.CITED_BY_TYPE_UNKNOW, Constants.CITED_BY_TYPE_DESC_UNKNOW), 
        APPLICANT(Constants.CITED_BY_TYPE_APPLICANT, Constants.CITED_BY_TYPE_DESC_APPLICANT), 
        EXAMINER(Constants.CITED_BY_TYPE_EXAMINER, Constants.CITED_BY_TYPE_DESC_EXAMINER);

        private final int citedByTypeCode;
        private final String citedByTypeDesc;

        private int getCitedByTypeCode() {
            return citedByTypeCode;
        }

        private String getCitedByTypeDesc() {
            return citedByTypeDesc;
        }

        private CITEDBYTYPE(int citedByTypeCode, String citedByTypeDesc) {
            this.citedByTypeCode = citedByTypeCode;
            this.citedByTypeDesc = citedByTypeDesc;
        }

        public static int findCitedByTypeCode(String citedByTypeDesc) {
            if (citedByTypeDesc == null || citedByTypeDesc.length() == 0) {
                return UNKNOW.citedByTypeCode;
            }
            for (CITEDBYTYPE element : CITEDBYTYPE.values()) {
                if (element.getCitedByTypeDesc().equals(citedByTypeDesc)) {
                    return element.getCitedByTypeCode();
                }
            }
            return UNKNOW.citedByTypeCode;
        }

        public static String findCitedByTypeDesc(Integer citedByTypeCode) {
            if (citedByTypeCode == null) {
                return UNKNOW.citedByTypeDesc;
            }
            for (CITEDBYTYPE element : CITEDBYTYPE.values()) {
                if (element.getCitedByTypeCode() == citedByTypeCode) {
                    return element.getCitedByTypeDesc();
                }
            }
            return UNKNOW.citedByTypeDesc;
        }

    }
    
    /**
     * 優先權種類,0:無法判斷,1:national, 2:regional, 3:international
     * @author mikelin
     *
     */
    public enum PRIORITYTYPE {
        
        UNKNOW(Constants.PRIORITY_TYPE_UNKNOW, Constants.PRIORITY_TYPE_UNKNOW_DESC), 
        NATIONAL(Constants.PRIORITY_TYPE_NATIONAL, Constants.PRIORITY_TYPE_NATIONAL_DESC), 
        REGIONAL(Constants.PRIORITY_TYPE_REGIONAL, Constants.PRIORITY_TYPE_REGIONAL_DESC),
        INTERNATIONAL(Constants.PRIORITY_TYPE_INTERNATIONAL, Constants.PRIORITY_TYPE_INTERNATIONAL_DESC);

        private final int priorityTypeCode;
        private final String priorityTypeDesc;
        
        public int getPriorityTypeCode() {
            return priorityTypeCode;
        }

        public String getPriorityTypeDesc() {
            return priorityTypeDesc;
        }

        private PRIORITYTYPE(int priorityTypeCode, String priorityTypeDesc) {
            this.priorityTypeCode = priorityTypeCode;
            this.priorityTypeDesc = priorityTypeDesc;
        }

        public static int findPriorityTypeCode(String priorityTypeDesc) {
            if (priorityTypeDesc == null || priorityTypeDesc.length() == 0) {
                return UNKNOW.priorityTypeCode;
            }
            for (PRIORITYTYPE element : PRIORITYTYPE.values()) {
                if (element.getPriorityTypeDesc().equals(priorityTypeDesc)) {
                    return element.getPriorityTypeCode();
                }
            }
            return UNKNOW.priorityTypeCode;
        }

        public static String findPriorityTypeDesc(Integer priorityTypeCode) {
            if (priorityTypeCode == null) {
                return UNKNOW.priorityTypeDesc;
            }
            for (PRIORITYTYPE element : PRIORITYTYPE.values()) {
                if (element.getPriorityTypeCode() == priorityTypeCode) {
                    return element.getPriorityTypeDesc();
                }
            }
            return UNKNOW.priorityTypeDesc;
        }

    }
    

    public static void main(String[] args) {
    }

}
