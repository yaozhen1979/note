package com.patentdata.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PatTypeEnum {

    private static Logger logger = LoggerFactory.getLogger(PatTypeEnum.class);

    /**
     * US:1:Utility, 3:Design, 4:Plant, 5:Reissue, 6:SIR
     * @author mikelin
     *
     */
    public enum US {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME),
        UTILITY(Constants.PAT_TYPE_UTILITY_CODE_US, Constants.PAT_TYPE_UTILITY_NAME_US),
        DESIGN(Constants.PAT_TYPE_DESIGN_CODE_US, Constants.PAT_TYPE_DESIGN_NAME_US),
        PLANT(Constants.PAT_TYPE_PLANT_CODE_US, Constants.PAT_TYPE_PLANT_NAME_US),
        REISSUE(Constants.PAT_TYPE_REISSUE_CODE_US, Constants.PAT_TYPE_REISSUE_NAME_US),
        SIR(Constants.PAT_TYPE_SIR_CODE_US, Constants.PAT_TYPE_SIR_NAME_US);

        private final int typeCode;
        private final String typeName;

        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private US(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }

        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (US element : US.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }

        public static String findPatTypeName(Integer typeCode){
            if(typeCode == null){
                return NO_DEFINED.typeName;
            }
            for (US element : US.values()) {
                if(element.getTypeCode() == typeCode){
                    return element.getTypeName();
                }
            }
            return NO_DEFINED.typeName;
        }
    }

    /**
     * CN:1:发明专利,2:实用新型,3:外观专利
     * @author mikelin
     *
     */
    public enum CN {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME),
        FM(Constants.PAT_TYPE_FM_CODE_CN, Constants.PAT_TYPE_FM_NAME_CN),
        SD(Constants.PAT_TYPE_SD_CODE_CN, Constants.PAT_TYPE_SD_NAME_CN),
        XX(Constants.PAT_TYPE_XX_CODE_CN, Constants.PAT_TYPE_XX_NAME_CN),
        WG(Constants.PAT_TYPE_WG_CODE_CN, Constants.PAT_TYPE_WG_NAME_CN);

        private final int typeCode;
        private final String typeName;

        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private CN(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }

        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (CN element : CN.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }

        public static String findPatTypeName(Integer typeCode){
            if(typeCode == null){
                return NO_DEFINED.typeName;
            }
            for (CN element : CN.values()) {
                if(element.getTypeCode() == typeCode){
                    return element.getTypeName();
                }
            }
            return NO_DEFINED.typeName;
        }
    }

    /**
     * DOCDB: 1:Utility, 2:Model, 3:Design, 4:Plant, 9:Others
     * @author mikelin
     *
     */
    public enum DOCDB {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME),
        UTILITY(Constants.PAT_TYPE_UTILITY_CODE_DOCDB, Constants.PAT_TYPE_UTILITY_NAME_DOCDB),
        MODEL(Constants.PAT_TYPE_MODEL_CODE_DOCDB, Constants.PAT_TYPE_MODEL_NAME_DOCDB),
        DESIGN(Constants.PAT_TYPE_DESIGN_CODE_DOCDB, Constants.PAT_TYPE_DESIGN_NAME_DOCDB),
        PLANT(Constants.PAT_TYPE_PLANT_CODE_DOCDB, Constants.PAT_TYPE_PLANT_NAME_DOCDB),
        OTHERS(Constants.PAT_TYPE_OTHERS_CODE_DOCDB, Constants.PAT_TYPE_OTHERS_NAME_DOCDB);

        private final int typeCode;
        private final String typeName;

        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private DOCDB(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }

        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (DOCDB element : DOCDB.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }

        public static String findPatTypeName(Integer typeCode){
            if(typeCode == null){
                return NO_DEFINED.typeName;
            }
            for (DOCDB element : DOCDB.values()) {
                if(element.getTypeCode() == typeCode){
                    return element.getTypeName();
                }
            }
            return NO_DEFINED.typeName;
        }
    }

    /**
     * EPO:1->"Utility"
     * @author ericxiao
     *
     */
    public enum EP {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME),
        UTILITY(Constants.PAT_TYPE_UTILITY_CODE_EPO, Constants.PAT_TYPE_UTILITY_NAME_EPO);

        private final int typeCode;
        private final String typeName;

        public int getTypeCode() {
            return typeCode;
        }

        public String getTypeName() {
            return typeName;
        }

        private EP(int typeCode, String typeName) {
            this.typeCode = typeCode;
            this.typeName = typeName;
        }

        public static int findPatTypeCode(String typeName){
            if(typeName == null || typeName.length() == 0){
                return NO_DEFINED.typeCode;
            }
            for (EP element : EP.values()) {
                if(element.getTypeName().equals(typeName)){
                    return element.getTypeCode();
                }
            }
            return NO_DEFINED.typeCode;
        }

        public static String findPatTypeName(Integer typeCode){
            if(typeCode == null){
                return NO_DEFINED.typeName;
            }
            for (EP element : EP.values()) {
                if(element.getTypeCode() == typeCode){
                    return element.getTypeName();
                }
            }
            return NO_DEFINED.typeName;
        }
    }
}
