package com.patentdata.common;

public final class Constants {
    
    public final static int ZERO = 0;
    
    // **** COMMON ****
    public final static String SOURCE_ID_US_FULLTEXT = "USA01";              // USPTO全文,mongo:PatentMarshallUS
    public final static String SOURCE_ID_US_FULLTEXT_UPDATE_CPC = "USA02";   // USPTO全文欄位定期更新-CPC:CPC_yyyymm
    public final static String SOURCE_ID_US_FULLTEXT_UPDATE_USPC = "USA03";  // SPTO全文欄位定期更新-USPC:USPCAppl_yyyymm
    public final static String SOURCE_ID_US_ASSIGNMENT = "USB01";            // USPTO Assignment DB
    public final static String SOURCE_ID_US_PAIR = "USC01";                  // USPTO PAIR
    
    public final static String SOURCE_ID_CN_OPENDATA = "CNA01";              // CN OpenData
    
    public final static String SOURCE_ID_WO_FULLTEXT = "WOA01";              // WO全文
    
    public final static String SOURCE_ID_DOCDB_BRIEF = "DOCA01";             // DOCDB摘要
    
    public final static String SOURCE_ID_JP_XXX = "JPA01";                   // JPO全文
    
    public final static String SOURCE_ID_EP_FULLTEXT = "EPA01";              // EPO全文
    
    public final static int TRUNCATE_FLAG_FALSE = 0;                         // 是否有因資料過長而truncate資料, 0:無
    public final static int TRUNCATE_FLAG_TRUE = 1;                          // 是否有因資料過長而truncate資料,1:有
    
    public final static int WITHDRAW_FLAG_FALSE = 0;                         // 是否WITHDRAW, 0:無
    public final static int WITHDRAW_FLAG_TRUE = 1;                          // 是否WITHDRAW, 1:有
    
    public final static int PAT_STAT_PUBLIC = 1;                             // 公開
    public final static int PAT_STAT_ISSUE = 2;                              // 公告
    public final static int PAT_STAT_BOTH = 3;                               // 公開或公告
    
    public final static int TYPE_NO_DEFINED_CODE = -99;
    public final static String TYPE_NO_DEFINED_NAME = "Non-Defined";
    
    public final static int PAT_TYPE_UTILITY_CODE_US = 1;
    public final static String PAT_TYPE_UTILITY_NAME_US = "Utility";
    
    public final static int PAT_TYPE_DESIGN_CODE_US = 3;
    public final static String PAT_TYPE_DESIGN_NAME_US = "Design";
    
    public final static int PAT_TYPE_PLANT_CODE_US = 4;
    public final static String PAT_TYPE_PLANT_NAME_US = "Plant";
    
    public final static int PAT_TYPE_REISSUE_CODE_US = 5;
    public final static String PAT_TYPE_REISSUE_NAME_US = "Reissue";
    
    public final static int PAT_TYPE_SIR_CODE_US = 6;
    public final static String PAT_TYPE_SIR_NAME_US = "SIR";
    
    public final static int PAT_TYPE_FM_CODE_CN = 1;
    public final static String PAT_TYPE_FM_NAME_CN = "发明专利";
    
    public final static int PAT_TYPE_SD_CODE_CN = 2;
    public final static String PAT_TYPE_SD_NAME_CN = "发明专利";
    
    public final static int PAT_TYPE_XX_CODE_CN = 3;
    public final static String PAT_TYPE_XX_NAME_CN = "实用新型";
    
    public final static int PAT_TYPE_WG_CODE_CN = 4;
    public final static String PAT_TYPE_WG_NAME_CN = "外观专利";
    
    public final static int PAT_TYPE_UTILITY_CODE_DOCDB = 1;
    public final static String PAT_TYPE_UTILITY_NAME_DOCDB = "Utility";
    
    public final static int PAT_TYPE_MODEL_CODE_DOCDB = 2;
    public final static String PAT_TYPE_MODEL_NAME_DOCDB = "Model";
    
    public final static int PAT_TYPE_DESIGN_CODE_DOCDB = 3;
    public final static String PAT_TYPE_DESIGN_NAME_DOCDB = "Design";
    
    public final static int PAT_TYPE_PLANT_CODE_DOCDB = 4;
    public final static String PAT_TYPE_PLANT_NAME_DOCDB = "Plant";
    
    public final static int PAT_TYPE_OTHERS_CODE_DOCDB = 9;
    public final static String PAT_TYPE_OTHERS_NAME_DOCDB = "Others";
    
    public final static int PAT_TYPE_UTILITY_CODE_EPO = 1;
    public final static String PAT_TYPE_UTILITY_NAME_EPO = "Utility";

    public final static int PAT_TYPE_PATENT_CODE_JPO = 1;

    public final static int PAT_TYPE_UTILITY_CODE_JPO = 2;

    public final static int PERSON_TYPE_PERSONAL = 1;                        // 1:個人
    public final static int PERSON_TYPE_ORG = 2;                             // 2:組織
    public final static int PERSON_TYPE_NONE = 3;                            // 3:無法判斷
    
    public final static int EXAMINER_TYPE_PRIMARY = 1;                       // 專利審查官類別,1:主審
    public final static int EXAMINER_TYPE_ASSISTANT = 2;                     // 專利審查官類別,2:助理審查官
    
    // **** US ****
    public final static int US_REL_RAW_TYPE_XML_CODE = 1;                    // US原始資料格式,1:XML
    public final static String US_REL_RAW_TYPE_XML_NAME = "XML";             // US原始資料格式,1:XML
    
    public final static int US_REL_RAW_TYPE_HTML_CODE = 2;                   // US原始資料格式,2:HTML
    public final static String US_REL_RAW_TYPE_HTML_NAME = "HTML";           // US原始資料格式,2:HTML
    
    public final static int DOCDB_FLAG_NO = 0;                               // DOCDB無相對應的PAT_ID
    public final static int DOCDB_FLAG_YES = 1;                              // DOCDB有相對應的PAT_ID
    
    public final static int FULL_TEXT_FLAG_NO = 0;                           // 是否為全文 0:否
    public final static int FULL_TEXT_FLAG_YES = 1;                          // 是否為全文 1:否
    
    public final static int CRYPTO_FLAG_NO = 0;
    public final static int CRYPTO_FLAG_YES = 1;
    
    public final static int DELETE_FLAG_NO = 0;
    public final static int DELETE_FLAG_YES = 1;
    
    public final static String TW_LANG = "zh-tw";
    public final static String US_LANG = "en";
    public final static String CN_LANG = "zh-cn";
    public final static String JP_LANG = "ja";
    
    // **** WO ****
    public final static String WO_XMLTYPE_WPA = "WPA";
    public final static String WO_XMLTYPE_OPA = "OPA";
    public final static String WO_XMLTYPE_WAB = "WAB";
    public final static String WO_XMLTYPE_LNP = "LNP";
    public final static String WO_PAT_COUNTRY = "WO";
    public final static int WO_PAT_TYPE = 1;
    public final static String PAT_TYPE_PLANT_NAME_WO = "Utility";
    
    // CLS
    public final static int CLS_CPC_MAIN_FLAG_NO = 0;                           // 是否為mainCPC 0:否
    public final static int CLS_CPC_MAIN_FLAG_YES = 1;                          // 是否為mainCPC 1:是
    
    public final static int CLS_IPC_MAIN_FLAG_NO = 0;                           // 是否為mainIPC 0:否
    public final static int CLS_IPC_MAIN_FLAG_YES = 1;                          // 是否為mainIPC 1:是

    public final static int CLS_FI_MAIN_FLAG_NO = 0;                           // 是否為mainFI 0:否
    public final static int CLS_FI_MAIN_FLAG_YES = 1;                          // 是否為mainFI 1:是

    public final static int CLS_TYPE_IPC = 1;                                   // IPC或IPCR,1:ipc
    public final static int CLS_TYPE_IPCR= 2;                                   // IPC或IPCR,2:ipcr
    
    public final static String CLS_NAME_IPC = "IPC";                            // 分類號 IPC
    public final static String CLS_NAME_CPC = "CPC";                            // 分類號 CPC
    public final static String CLS_NAME_USPC = "USPC";                          // 分類號 USPC
    
    public final static int CLS_LOC_MAIN_FLAG_NO = 0;                           // 是否為mainLOC 0:否
    public final static int CLS_LOC_MAIN_FLAG_YES = 1;                          // 是否為mainLOC 1:是
    
    public final static int CLS_USPC_MAIN_FLAG_NO = 0;                          // 是否為mainUSPC 0:否
    public final static int CLS_USPC_MAIN_FLAG_YES = 1;                         // 是否為mainUSPC 1:是
    
    // defectFlag_true : 1, defectFlag_false : 0
    public final static int CLS_DEFECT_FLAG_TRUE = 1;
    public final static int CLS_DEFECT_FLAG_FALSE = 0;
    
    public final static String DOCDB_DEFAULT_DATE = "1911-10-10";
    
    // PAT_REF_CITED => 引證資料種類,0:無法確認, 1:cited by applicant, 2:cited by examiner
    public final static int CITED_BY_TYPE_UNKNOW = 0;
    public final static int CITED_BY_TYPE_APPLICANT = 1;
    public final static int CITED_BY_TYPE_EXAMINER = 2;
    
    public final static String CITED_BY_TYPE_DESC_UNKNOW = "unknow";                    // 引證資料種類,0:無法確認
    public final static String CITED_BY_TYPE_DESC_APPLICANT = "cited by applicant";     // 引證資料種類,1:cited by applicant
    public final static String CITED_BY_TYPE_DESC_EXAMINER = "cited by examiner";       // 引證資料種類,2:cited by examiner
    
    // 優先權種類,0:無法判斷,1:national, 2:regional, 3:international
    public final static int PRIORITY_TYPE_UNKNOW = 0;
    public final static int PRIORITY_TYPE_NATIONAL = 1;
    public final static int PRIORITY_TYPE_REGIONAL = 2;
    public final static int PRIORITY_TYPE_INTERNATIONAL = 3;
    
    public final static String PRIORITY_TYPE_UNKNOW_DESC = "unknow";
    public final static String PRIORITY_TYPE_NATIONAL_DESC = "national";
    public final static String PRIORITY_TYPE_REGIONAL_DESC = "regional";
    public final static String PRIORITY_TYPE_INTERNATIONAL_DESC = "international";
    
    // citationType 1:patcit, 2:nplcit
    public final static int CITATION_TYPE_PATCIT = 1;                                   // citationType 1:patcit
    public final static int CITATION_TYPE_NPLCIT = 2;                                   // citationType 2:nplcit
    
    public final static int DOCDB_LASTEST_FLAG_NO = 0;
    public final static int DOCDB_LASTEST_FLAG_YES = 1;
    
    //關聯的種類,0:無法判斷, 1:addition, 2:division, 
    //3:continuation, 4:continuation-in-part, 
    //5:continuing-reissue, 6:reissue, 7:divisional-reissue,
    //8:reexamination, 9: reexamination-reissue-merger,
    //10:substitution, 11:provisional-application, 12:utility-model-basis, 
    //13:correction, 14:related-publication, 15:a-371-of-international, 16:related-grant
    public final static int RELATED_TYPE_CODE_UNKNOW = 0;
    public final static int RELATED_TYPE_CODE_ADDITION = 1;
    public final static int RELATED_TYPE_CODE_DIVISION = 2;
    public final static int RELATED_TYPE_CODE_CONTINUATION = 3;
    public final static int RELATED_TYPE_CODE_CONTINUATION_IN_PART = 4;
    public final static int RELATED_TYPE_CODE_CONTINUING_REISSUE = 5;
    public final static int RELATED_TYPE_CODE_REISSUE = 6;
    public final static int RELATED_TYPE_CODE_US_DIVISIONAL_REISSUE = 7;
    public final static int RELATED_TYPE_CODE_REEXAMINATION = 8;
    public final static int RELATED_TYPE_CODE_US_REEXAMINATION_REISSUE_MERGER = 9;
    public final static int RELATED_TYPE_CODE_SUBSTITUTION = 10;
    public final static int RELATED_TYPE_CODE_US_PROVISIONAL_APPLICATION = 11;
    public final static int RELATED_TYPE_CODE_UTILITY_MODEL_BASIS = 12;
    public final static int RELATED_TYPE_CODE_CORRECTION = 13;
    public final static int RELATED_TYPE_CODE_RELATED_PUBLICATION = 14;
    public final static int RELATED_TYPE_CODE_A_371_OF_INTERNATIONAL = 15;
    public final static int RELATED_TYPE_CODE_RELATED_GRANT = 16;
    public final static int RELATED_TYPE_CODE_JP_DIVISION = 17;
    public final static int RELATED_TYPE_CODE_JP_CHANGE_APPLICATION = 18;
    public final static int RELATED_TYPE_CODE_JP_CHANGE_UTILITY = 19;


    // pat_event_record => Event種類,1:create,2:update,9:delete
    public final static int EVENT_TYPE_CREATE = 1;
    public final static int EVENT_TYPE_UPDATE = 2;
    public final static int EVENT_TYPE_DELETE = 9;
    
    // 資料來自linked-indexing-code-group,unlinked-indexing-code則為1, 否則為0
    public final static int IPC_LINKED_INDEXING_CODE_GROUP_YES = 1;
    public final static int IPC_LINKED_INDEXING_CODE_GROUP_NO = 0;
    
    // 1:main-linked-indexing, 2:sub-linked-indexing(ipc_text replace ":" to "/"), 3:unlinked-indexing
    public final static int IPC_MAIN_LINKED_INDEXING = 1;
    public final static int IPC_SUB_LINKED_INDEXING = 2;
    public final static int IPC_UNLINKED_INDEXING = 3;

    //I:資料中定義cls_cd為"main-clsf"或cls_cd="further-clsf",  N:"資料中定義cls_cd為"add-info"
    public final static Character CLS_FI_VALUE_CODE_MAIN_OR_FURTHER = 'I';
    public final static Character CLS_FI_VALUE_CODE_ADD_INFO = 'N';

    //I:資料中定義cls_cd為"main-clsf"或cls_cd="further-clsf",  N:"資料中定義cls_cd為"add-info"
    public final static Character CLS_IPC_VALUE_CODE_MAIN_OR_FURTHER = 'I';
    public final static Character CLS_IPC_VALUE_CODE_ADD_INFO = 'N';

    // pat_data_memo memo type 紀錄已知但未處理之狀況 
    public final static int DATA_MEMO_PERSON_WITH_MULTILANG = 1;
    
    // log Type,1:ERROR(處理時資料不符合預期,不寫入table中), 2:WARN(處理時資料不符合預期,仍寫入table中)
    public final static int LOG_TYPE_ERROR = 1; 
    public final static int LOG_TYPE_WARN = 2; 
    
    private Constants() {
    }
}

