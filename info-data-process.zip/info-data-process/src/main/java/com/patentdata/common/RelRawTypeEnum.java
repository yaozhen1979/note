package com.patentdata.common;

public class RelRawTypeEnum {

    public enum US {
        
        NO_DEFINED(Constants.TYPE_NO_DEFINED_CODE, Constants.TYPE_NO_DEFINED_NAME),
        
        XML(Constants.US_REL_RAW_TYPE_XML_CODE, 
            Constants.US_REL_RAW_TYPE_XML_NAME),
        
        HTML(Constants.US_REL_RAW_TYPE_HTML_CODE,
             Constants.US_REL_RAW_TYPE_HTML_NAME);
        
        private final int relRawTypeCode;
        private final String relRawTypeName;
        
        public int getRelRawTypeCode() {
            return relRawTypeCode;
        }

        public String getRelRawTypeName() {
            return relRawTypeName;
        }

        private US(int relRawTypeCode, String relRawTypeName) {
            this.relRawTypeCode = relRawTypeCode;
            this.relRawTypeName = relRawTypeName;
        }
        
        public static int findRelRawTypeCode(String relRawTypeName){
            if(relRawTypeName == null || relRawTypeName.length() == 0){
                return NO_DEFINED.relRawTypeCode;
            }
            for (US element : US.values()) {
                if(element.getRelRawTypeName().equals(relRawTypeName)){
                    return element.getRelRawTypeCode();
                }
            }
            return NO_DEFINED.relRawTypeCode;
        }
        
        public static String findRelRawTypeName(Integer relRawTypeCode){
            if(relRawTypeCode == null){
                return NO_DEFINED.relRawTypeName;
            }
            for (US element : US.values()) {
                if(element.getRelRawTypeCode() == relRawTypeCode){
                    return element.getRelRawTypeName();
                }
            }
            return NO_DEFINED.relRawTypeName;
        }
        
        
    }
}
