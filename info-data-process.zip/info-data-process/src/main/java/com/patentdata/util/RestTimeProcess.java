package com.patentdata.util;

import java.text.DecimalFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestTimeProcess {
	
    Logger log = LoggerFactory.getLogger(RestTimeProcess.class);
    
	Long totalCnt;
	int currCnt;
	int lastCnt;
	String msg;
	Date now;
	Date lastTime;
    // File log
	final int interval = 5000;
	
	public RestTimeProcess(Long totalCnt, String msg){
		this.totalCnt = totalCnt;
		this.currCnt = 0;
		this.lastCnt = 0;
		this.lastTime = new Date();
		this.msg = msg;
	}
    
    public RestTimeProcess(Long totalCnt){
        this.totalCnt = totalCnt;
        this.currCnt = 0;
        this.lastCnt = 0;
        this.lastTime = new Date();
    }
	
	public void process() {
		
		currCnt++;
		now = new Date();
		
		if (currCnt == 1) {
			lastCnt = currCnt;
			log.info(msg + ": start process total counts : " + totalCnt);
		}
		
		if ((now.compareTo(lastTime) > 0 && 
                (now.getTime()- lastTime.getTime()) > interval && currCnt > lastCnt) || 
                (currCnt == totalCnt)) {
			
			//進度百分比
			double percent = (currCnt / totalCnt.doubleValue()) * 100;
			//剩餘數量
			Long restNum = totalCnt - currCnt;
			//單位時間(interval)內進行的數量
			int procNum = currCnt - lastCnt;
			//已使用時間
			Long usedTime = now.getTime()- lastTime.getTime();
			//剩餘時間
			Long restTime = (procNum == 0 ? 0 : (restNum / procNum) * usedTime);
            
			Long ms = restTime / 1000;
			
			//取秒數
			int secs = ms.intValue() % 60;
			
			ms = (ms / 60);
			
			//取分鐘數
			int mins = ms.intValue() % 60;
			
			ms = ms / 60;
			
			//取時數
			int hours = ms.intValue();
//			
			log.info(msg + " process " + currCnt + " / " + totalCnt + " (" + new DecimalFormat("####0.##").format(percent) + "%), Rest time:" + String.format("%02d:%02d:%02d", hours, mins, secs));
			
			lastTime = now;
			lastCnt = currCnt;
		}

	}  // end function
	
	/**
	 * 
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
	   
	    RestTimeProcess restTimeProcess = new RestTimeProcess(1000L, "RestTimeProcess");
	    
	    for (int i = 0; i < 1000; i++) {
	        Thread.sleep(Math.round(Math.random() * 1000));
	        restTimeProcess.process();
        }
	    
    }
	
}


