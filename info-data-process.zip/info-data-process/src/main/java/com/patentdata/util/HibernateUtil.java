package com.patentdata.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.jboss.logging.Logger;

/**
 * 
 * 
 * @author tonykuo
 *
 */
public class HibernateUtil {
    
    static Logger logger = Logger.getLogger(HibernateUtil.class);
    
    private static final SessionFactory sessionFactory;
    private static final ServiceRegistry serviceRegistry;
    
    private static final ThreadLocal<Session> session = new ThreadLocal<Session>();
    
    static {
        
        try {
            Configuration configuration = new Configuration();
            configuration.configure();
            
            // setting properties programmatically
            configuration.setProperty("hibernate.dataSource.cachePrepStmts", "true");
            configuration.setProperty("hibernate.dataSource.prepStmtCacheSize", "250");
            configuration.setProperty("hibernate.dataSource.prepStmtCacheSqlLimit", "2048");
            configuration.setProperty("hibernate.hbm2ddl.auto", "none");
            
            serviceRegistry = new StandardServiceRegistryBuilder()
                    .applySettings(configuration.getProperties()).build();
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        } catch (HibernateException ex) {
            throw new RuntimeException("Configuratio error = " + ex.getMessage(), ex);
        }
        
    }
    
    public static Session currentSession() throws HibernateException {
        Session s = (Session) session.get();
        if (s == null) {
            s = sessionFactory.openSession();
            session.set(s);
        }
        // logger.debug("get current session tenant identifier:" + s.getTenantIdentifier());
        logger.debug("get current session hashCode = " + s.hashCode());
        return s;
    }
    

    public static Session newSession() throws HibernateException {
        return sessionFactory.openSession();
    }
    
    public static void closeSession() throws HibernateException {
        Session s = (Session) session.get();
        session.set(null);
        session.remove();
        if (s != null) {
            logger.debug("close current session");
            s.close();
            //
        }
        if(serviceRegistry != null) {
            // StandardServiceRegistryBuilder.destroy(serviceRegistry);
        }
    }
    
}
