package com.patentdata.util;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringEscapeUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class JSONUtil {
    
    public static boolean isJSONValid(String jsonString) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.readTree(jsonString);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
    
    public static String object2Json(Object obj) {
        return object2Json(obj, false);
    }
    
    public static String object2Json(Object obj, boolean pertty) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            ObjectWriter ow = objectMapper.writer();
            if (pertty) {
                ow = ow.withDefaultPrettyPrinter();
            }
            String json = ow.writeValueAsString(obj);
            return json;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * only for SolrInfoTransfer 使用
     * 
     * @param dataList
     * @return
     */
    public static String toJSONString(List dataList, boolean isOriginPTO) {
        
        StringBuilder sb = new StringBuilder();
        
        if (dataList != null && dataList.size() > 0) {
            sb.append("{ ");
            for (int i = 0; i < dataList.size(); i++) {
                
                Object[] data = (Object[]) dataList.get(i);
                
                String key;
                String value;
                if (isOriginPTO == true) {
                    String tempKey = data[2].toString().trim();
                    if (tempKey.toLowerCase().equals("en")) {
                        key = "origin";
                    } else {
                        key = tempKey;
                    }
                    /*
                     * pat_id = DE10056507-A1-20020529, [Möbelstück, das um seine vertikale Mittelachse drehbar ist]
                     * 使用[StringEscapeUtils.escapeJava]會轉成亂碼...
                     */
                    value = StringEscapeUtils.escapeJava(StringUtil.unwrap(data[3].toString(), "\""));
                } else {
                    key = data[2].toString().trim();
                    value = StringUtil.unwrap(data[3].toString(), "\"");
                }
                
                if (i == 0) {
                    sb.append("\"" + key + "\" : \"" + value + "\"");
                } else {
                    sb.append(", \"" + key + "\" : \"" + value + "\"");
                }
            }
            sb.append(" }");
        }
        
        return sb.toString();
        
    }   // end toJSONString
    
    /**
     * for SolrInfoTransfer 使用
     * @param country
     * @param patNo
     * @return
     */
    public static String citedPatentsToJSONString(String country, String patNo) {
        
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        // country
        String key = "country";
        String value = country;
        sb.append("\"" + key + "\":\"" + value + "\"");
        
        // patentNumber
        key = "patentNumber";
        value = patNo;
        sb.append(",\"" + key + "\":\"" + value + "\"");
        
        sb.append("}");
        
        return sb.toString();
    }
    
    /**
     * for SolrInfoTransfer 使用
     * @param country
     * @param patNo
     * @return
     */
    public static String priorityPatentsToJSONString(String country, String appNo) {
        
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        // country
        String key = "country";
        String value = country;
        sb.append("\"" + key + "\":\"" + value + "\"");
        
        // patentNumber
        key = "appNumber";
        value = appNo;
        sb.append(",\"" + key + "\":\"" + value + "\"");
        
        sb.append("}");
        
        return sb.toString();
    }
    
    /**
     * 
     * @param mapData
     * @return
     */
    public static String mapToJSONString(Map mapData) {
        
        StringBuilder sb = new StringBuilder();
        
        if (mapData.size() > 0) {
            int i = 0;
            sb.append("{ ");
            Iterator it = mapData.entrySet().iterator();
            while (it.hasNext()) { 
                Map.Entry entry = (Map.Entry) it.next();
                Object key = entry.getKey();
                
                if (key.toString().equals("name") || key.toString().equals("country")) {
                    
                    if (i++ == 0) {
                        sb.append("\"" + key.toString() + "\" : { \"origin\" : \"" + entry.getValue() + "\" }");
                    } else {
                        sb.append(", \"" + key.toString() + "\" : { \"origin\" : \"" + entry.getValue() + "\" }");
                    }
                    
                } else if (key.toString().equals("sequence")) {
                    
                    if (i++ == 0) {
                        sb.append("\"" + key.toString() + "\" : " + entry.getValue());
                    } else {
                        sb.append(", \"" + key.toString() + "\" : " + entry.getValue());
                    }
                    
                } else {
                    
                    if (i++ == 0) {
                        sb.append("\"" + key.toString() + "\" : \"" + entry.getValue() + "\"");
                    } else {
                        sb.append(", \"" + key.toString() + "\" : \"" + entry.getValue() + "\"");
                    }
                    
                }
                
            }   // end if (mapData.size() > 0)
            
            sb.append(" }");
            
        }
        
        return sb.toString();
        
    }   // end mapToJSONString
    
}
