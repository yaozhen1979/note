package com.patentdata.util;

import java.util.UUID;

public class UUIDUtil {

    public static UUID generateUUID() {
        
        UUID uuid = UUID.randomUUID();
        
        return uuid;
    }
    
}
