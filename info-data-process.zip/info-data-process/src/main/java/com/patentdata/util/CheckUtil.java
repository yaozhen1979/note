package com.patentdata.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckUtil {

    public final static Pattern patternDocNoWo = Pattern.compile("(\\d{4})/\\d{6}");
    public final static Pattern patternPatIdWo = Pattern.compile("WO(\\d{4})\\d{6}-\\S{2}-(\\d{4})\\d{4}");
    public final static Pattern patternAppIdWO = Pattern.compile("WOPCT\\w{2}(\\d{4})\\d{6}");
    public final static Pattern patternAppNoWO = Pattern.compile("PCT/\\w{2}(\\d{4})/\\d{6}");

    /**
     * 確認四位數西元年份是否為合理範圍數值
     * 
     * @param year
     * @return
     */
    public static boolean checkYear(int year) {
        return (year > 1900 && year < 2100);
    }

    /**
     * 確認 appYear 和 doYear 是否為合理數值
     * @param appYear application year
     * @param doYear year of doDate
     * @return
     */
    public static boolean checkYear(int appYear, int doYear) {
        return (doYear >= appYear && checkYear(appYear) && checkYear(doYear));
    }

    /**
     * 公開年四碼西元年+/+六碼數字(不足6位,前補0至6碼) Format: 2011/067944
     * 
     * @param docNo
     * @return
     */
    public static boolean checkDocNoWO(String docNo) {
        Matcher matcher = patternDocNoWo.matcher(docNo);
        return (matcher.matches() && checkYear(Integer.valueOf(matcher.group(1))));
    }

    /**
     * check WO patId format (docNo去掉/)+-+kindcode+-+doDate(yyyymmdd)
     * WO1996002947-A1-19960201
     * 
     * @param patId
     * @return
     */
    public static boolean checkPatIdWO(String patId) {
        Matcher matcher = patternPatIdWo.matcher(patId);
        return (matcher.matches() && checkYear(Integer.valueOf(matcher.group(1)), Integer.valueOf(matcher.group(2))));
    }

    /**
     * check WO appId format WOPCTDE1994000832
     * @param appId
     * @return
     */
    public static boolean checkAppIdWO(String appId) {
        Matcher matcher = patternAppIdWO.matcher(appId);
        return (matcher.matches() && checkYear(Integer.valueOf(matcher.group(1))));
    }

    /**
     * check WO appNo format PCT+/+國別大寫兩碼+申請年四碼西元年+/+六碼數字 PCT/DE1994/000832 *
     * PCT/DE1994/000832
     * @param appNo
     * @return
     */
    public static boolean checkAppNoWO(String appNo) {
        Matcher matcher = patternAppNoWO.matcher(appNo);
        return (matcher.matches() && checkYear(Integer.valueOf(matcher.group(1))));

    }

}
