package com.patentdata.helper;

public class PatClsFtermHelper extends BaseHelper {

}
