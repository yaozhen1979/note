package com.patentdata.helper;

import java.math.BigInteger;

import org.hibernate.Query;
import org.hibernate.Session;

import com.patentdata.util.HibernateUtil;

public class SequenceHelper {
    
    /**
     * java 64bit Integer.MAX_VALUE =  2147483647
     *            Integer.MIN_VALUE = -2147483648
     * 
     * synchronized => useless
     * 
     * @return
     */
    public static Integer getSeqEventRecordIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_event_record_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * 
     * @return
     */
    public static Integer getSeqChangeLogIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_change_log_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * 
     * @return
     */
    public static Integer getSeqLogIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_log_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * 
     * @return
     */
    public static Integer getSeqPersonLangIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_person_lang_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * 
     * @return
     */
    public static Integer getSeqPtopidMappingIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_ptopid_mapping_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * 
     * @return
     */
    public static Integer getSeqDataMemoIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_memo_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    /**
     * @return
     */
    public static Integer getSeqPatDataLogIdNextVal() {
        
        Session session = HibernateUtil.currentSession();
        Query query = session.createSQLQuery("select nextval('seq_log_id')");
        
        return ((BigInteger) query.uniqueResult()).intValue();
    }
    
    
    public static void main(String[] args) {
        //
        // System.out.println(SequenceHelper.getSeqEventRecordIdNextVal());
        // System.out.println(SequenceHelper.getSeqChangeLogIdNextVal());
        // System.out.println(SequenceHelper.getSeqLogIdNextVal());
        // System.out.println(SequenceHelper.getSeqPersonLangIdNextVal());
        // System.out.println(SequenceHelper.getSeqPtopidMappingIdNextVal());
        // System.out.println(Integer.MIN_VALUE);
        
        HibernateUtil.closeSession();
    }

}
