package com.patentdata.helper;

public class PatClsFiHelper extends BaseHelper {

}
