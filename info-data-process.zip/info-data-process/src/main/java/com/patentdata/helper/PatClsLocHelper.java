package com.patentdata.helper;

import java.util.List;

import com.patentdata.model.PatClsLoc;
import com.patentdata.util.QueryBuilder;

public class PatClsLocHelper extends BaseHelper {

public static List<PatClsLoc> findByCondition(String patId, String sourceId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("PatClsLoc");
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        queryBuilder.eq("source_id", sourceId);
        queryBuilder.order("item");
        
        List queryList = queryBuilder.query();
        
        if (queryList != null && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
    }
}
