package com.patentdata.helper;

public class PatClsFieldOfSearchHelper extends BaseHelper {

}
