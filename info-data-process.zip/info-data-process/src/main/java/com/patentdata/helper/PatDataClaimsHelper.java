package com.patentdata.helper;

import java.util.List;

import com.patentdata.util.QueryBuilder;

public class PatDataClaimsHelper extends BaseHelper {

    /**
     * native query, 無法使用ORM Data
     *
     * @param patId
     * @return
     */
    public static List nativeQueryByPatId(String patId) {
        
        QueryBuilder queryBuilder = new QueryBuilder("select * from pat_data_claims");
        queryBuilder.setNativeSQL(true);
        queryBuilder.eq("substr(pat_id, 1, 2)", patId.substring(0, 2));
        queryBuilder.eq("pat_id", patId);
        
        List queryList = queryBuilder.query();
        
        if (queryList != null && queryList.size() > 0) {
            return queryList;
        } else {
            return null;
        }
        
    }
}
