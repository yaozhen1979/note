package com.patentdata.helper;

public class PatPersonCorrespondenceAddrHelper extends BaseHelper {

}
