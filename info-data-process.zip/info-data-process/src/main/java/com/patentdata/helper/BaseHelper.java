package com.patentdata.helper;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.patentdata.util.HibernateUtil;

public class BaseHelper<T> {
    
    @SuppressWarnings("unchecked")
    public static <T> T findByPK(Class<T> clazz, Object pk) {
        Session session = HibernateUtil.currentSession();
        T t = (T) session.get(clazz, (Serializable) pk);
        
        if (t != null) {
            session.evict(t);
        }
        
        return t;
    }
    
    /**
     * @deprecated
     * @param clazz
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> queryAll(Class<T> clazz) {
        Session session = HibernateUtil.currentSession();
        return session.createCriteria(clazz).add(Restrictions.sqlRestriction("1 = 1 LIMIT 100")).list();
    }
    
    /**
     *
     * @deprecated
     * @param clazz
     * @return
     */
    public static <T> Long count(Class<T> clazz) {
        Session session = HibernateUtil.currentSession();
        return (Long) session.createCriteria(clazz).setProjection(Projections.rowCount()).uniqueResult();
    }

    
}
