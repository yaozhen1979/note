package com.patentdata.exception;

public class JsonFormatException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private static final String DEFAULT_MESSAGE = ", json data format error";
    
    private String errCode = "";
    private String errMsg = "";

    public JsonFormatException(String message) {
        super(message + DEFAULT_MESSAGE);
    }

    public JsonFormatException(String errCode, String errMsg) {
        super(errMsg);
        this.errCode = errCode;
        this.errMsg = errMsg + DEFAULT_MESSAGE;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg + DEFAULT_MESSAGE;
    }

}
