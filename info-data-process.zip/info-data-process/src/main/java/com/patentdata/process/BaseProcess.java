package com.patentdata.process;

import java.util.Map;
import java.util.Properties;

import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.patentdata.exception.DataNotFoundException;
import com.patentdata.util.HibernateUtil;
import com.patentdata.util.PropertiesUtil;
import com.patentdata.util.RestTimeProcess;
import com.patentdata.util.StringUtil;

public abstract class BaseProcess {
    
    public static Logger logger = LoggerFactory.getLogger(BaseProcess.class);
    
    public static Properties properties = PropertiesUtil.load("message.properties");
    
    public Map<Object, Object> queryMap;
    
    /**
     * 
     * @return
     * @throws Exception
     */
    abstract DBCursor queryData() throws Exception;
    
    /**
     * 資料處理(單筆)
     * 相關TABLE寫入順序
     * <li>app_data
     * <li>pat_data
     * <li>pat_raw
     * <li>person_data
     * <li>person_lang (only for WO)
     * <li>person_lang_list (only for WO)
     * <li>person_person_agent
     * <li>person_person_applicant
     * <li>person_person_assignee
     * <li>person_person_correspondence_addr
     * <li>pat_person_examiner
     * <li>pat_person_inventor
     * <li>pat_data_brief
     * <li>pat_data_claims
     * <li>pat_data_desc
     * <li>pat_data_title
     * <li>pat_data_cls.....
     * <li>pat_data_ref.....
     * <li>pat_event_record
     * <li>pat_event_amend_log
     * 
     * @param data
     * @throws Exception
     */
    abstract void processData(DBObject data) throws Exception;
    
    /**
     * 
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    abstract void processFailData(DBObject data, String message) throws Exception;
    
    /**
     * 
     * @throws Exception
     */
    public void process() throws Exception {
        
        try {
            processFlow();
        } catch (Exception e) {
            HibernateUtil.closeSession();
            logger.error(StringUtil.stack2string(e));
            throw new Exception(e);
        }
        
    }
    
    /**
     * 
     * @throws Exception
     */
    private void processFlow() throws Exception {
        
        Session session = null;
        Transaction tx = null;
        RestTimeProcess rtp = null;
        
        DBCursor cursor = queryData();
        long count = cursor.size();
        
        if (count < 1) {
            logger.error("query data list is null or empty...");
            throw new DataNotFoundException(properties.getProperty("msg.query.data.zero"));
        } else {
            rtp = new RestTimeProcess(count, "");
        }
        
        while (cursor.hasNext()) {
            
            DBObject data = null;
            
            try {
                
                session = HibernateUtil.currentSession();
                /*
                 * ref: http://blog.csdn.net/wkcgy/article/details/6192839
                 */
                session.setFlushMode(FlushMode.MANUAL);
                tx = session.beginTransaction();
                data = cursor.next();
                processData(data);
                tx.commit();
                session.flush();
                rtp.process();
                
            } catch (Exception e) {
                
                String message = "marshall._id = " + data.get("_id") + ", Exception = " + e;
                logger.error(message);
                
                try {
                    tx.rollback();
                    // TODO: refactor, processFailData 少傳入一個Exception message
                    session = HibernateUtil.currentSession();
                    processFailData(data, message);
                    tx.commit();
                    session.flush();
                } catch (Throwable T) {}
                
                throw new Exception(e);
                
            } finally {
                session.clear();
            }
            
        }  // end for each
        
        HibernateUtil.closeSession();
        
        // TODO: send mail ???
    }
    
    /**
     * 處理 queryData 查詢方法
     * 
     * @param queryMap
     * @return
     */
    public BaseProcess queryMap(Map<Object, Object> queryMap) {
        this.queryMap = queryMap;
        return this;
    }
    
}
