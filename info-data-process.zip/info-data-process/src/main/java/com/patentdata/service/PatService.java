package com.patentdata.service;

public class PatService extends BaseService {

}
