package com.patentdata.service;

import org.hibernate.Session;

public interface HibernateTemplate {

    void doTransaction(Session session);
    
}
