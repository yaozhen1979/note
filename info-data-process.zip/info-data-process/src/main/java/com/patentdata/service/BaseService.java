package com.patentdata.service;

import java.io.Serializable;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentdata.util.HibernateUtil;

public class BaseService<T> {

    protected Logger log;

    public BaseService() {
        if (log == null) {
            log = LoggerFactory.getLogger(this.getClass());
        }
    }

    protected void persist(final T t) {
        Session session = HibernateUtil.currentSession();
        session.persist(t);
        session.flush();
    }
    
    protected Serializable save(final T t) {
        Session session = HibernateUtil.currentSession();
        Serializable serializable =  session.save(t);
        session.flush();
        return serializable;
    }
    
    protected void saveOrUpdate(final T t) {
        Session session = HibernateUtil.currentSession();
        session.saveOrUpdate(t);
        session.flush();
    }
    
    protected void update(final T t) {
        Session session = HibernateUtil.currentSession();
        session.update(t);
        session.flush();
    }
    
    protected Object merge(final T t) {
        Session session = HibernateUtil.currentSession();
        Object object = session.merge(t);
        session.flush();
        return object;
    }
    
    protected void remove(final T t) {
        Session session = HibernateUtil.currentSession();
        session.delete(t);
        session.flush();
        session.clear();
    }

}
