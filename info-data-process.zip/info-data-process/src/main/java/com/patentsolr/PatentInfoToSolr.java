package com.patentsolr;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentdata.util.JSONUtil;
import com.patentdata.util.StringUtil;
import com.patentsolr.model.MultiLangString;
import com.patentsolr.model.MultiLangString.LangFilter;
import com.patentsolr.model.PatentInfo2;
import com.patentsolr.model.Person;
import com.patentsolr.model.RelatedPatent;
import com.patentsolr.model.SolrPatentInfo;
import com.patentsolr.model.classification.ClassificationType;
import com.patentsolr.model.classification.FiInfo;
import com.patentsolr.model.classification.IpcCpcFinder;
import com.patentsolr.model.classification.IpcInfo;
import com.patentsolr.model.classification.LocInfo;

public class PatentInfoToSolr {

    static Logger log = LoggerFactory.getLogger(PatentInfoToSolr.class);

    //為日本資料雜訊額外撰寫的規則，碰到 01/01 這樣的會找前一個 subClass 來補
    private static Pattern rePatentIpcNormal4JPSubClass = Pattern.compile("^([A-Z])[\\s]*([0-9]{2})[\\s]*([A-Z])");
    private static Pattern rePatentIpcNormal4JPGroup = Pattern.compile("^([0-9]+)/([0-9]+)(.*$)");
    
    public static SolrPatentInfo mongo2Solr(PatentInfo2 patentInfo2)
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        
        SolrPatentInfo solrInfo = new SolrPatentInfo();

        solrInfo.ptopid = patentInfo2.pto.toUpperCase() + "." + patentInfo2.id.toLowerCase();

        solrInfo.id = patentInfo2.id;

        solrInfo.pto = patentInfo2.pto;

        solrInfo.country = patentInfo2.country.toUpperCase();

        fillDate(patentInfo2.appDate, solrInfo, "app");

        fillDate(patentInfo2.certificateDate, solrInfo, "certificate");

        fillDate(patentInfo2.decisionDate, solrInfo, "decision");

        fillDate(patentInfo2.examDate, solrInfo, "exam");

        fillDate(patentInfo2.openDate, solrInfo, "open");

        fillDate(patentInfo2.pctAppDate, solrInfo, "pctApp");

        fillDate(patentInfo2.pctOpenDate, solrInfo, "pctOpen");
        
        // TODO:
        String country = "";

        fillNumber(patentInfo2.appNumber, solrInfo, "app", country, patentInfo2.kindcode);

        if(patentInfo2.type != "Reissue") {
            if(!isEmpty(patentInfo2.appNumber)) {
                solrInfo.appNumberGroup = (patentInfo2.country + patentInfo2.appNumber).toUpperCase();
            } else {
                solrInfo.appNumberGroup = solrInfo.ptopid;
            }
        }

        fillNumber(patentInfo2.certificateNumber, solrInfo, "certificate", country, patentInfo2.kindcode);

        fillNumber(patentInfo2.decisionNumber, solrInfo, "decision", country, patentInfo2.kindcode);

        fillNumber(patentInfo2.openNumber, solrInfo, "open", country, patentInfo2.kindcode);

        fillNumber(patentInfo2.patentNumber, solrInfo, "patent", country, patentInfo2.kindcode);

        fillNumber(patentInfo2.pctAppNumber, solrInfo, "pctApp", country, patentInfo2.kindcode);
        
        fillNumber(patentInfo2.pctOpenNumber, solrInfo, "pctOpen", country, patentInfo2.kindcode);

        if(patentInfo2.mainCPC != null) {
            solrInfo.mainCPC = patentInfo2.mainCPC.toUpperCase();
            IpcInfo ipcInfo = normalizeIpcAndCpc(ClassificationType.CPC, solrInfo.mainCPC , solrInfo);
            solrInfo.mainCPCNormal = ipcInfo.ipcNormal;
            solrInfo.mainCPCClass = ipcInfo.clazz;
            solrInfo.mainCPCSubClass = ipcInfo.subClazz;
            solrInfo.mainCPCGroup = ipcInfo.group;
            solrInfo.mainCPCSubGroup = ipcInfo.subGroup;
        } else {
            solrInfo.mainCPC = patentInfo2.mainCPC;
        }


        if(patentInfo2.mainIPC != null) {
            solrInfo.mainIPC = patentInfo2.mainIPC.toUpperCase();
            IpcInfo ipcInfo = normalizeIpcAndCpc(ClassificationType.IPC, solrInfo.mainIPC, solrInfo);
            solrInfo.mainIPCNormal = ipcInfo.ipcNormal;
            solrInfo.mainIPCClass = ipcInfo.clazz;
            solrInfo.mainIPCSubClass = ipcInfo.subClazz;
            solrInfo.mainIPCGroup = ipcInfo.group;
            solrInfo.mainIPCSubGroup = ipcInfo.subGroup;
        } else {
            solrInfo.mainIPC = patentInfo2.mainIPC;
        }

        if(patentInfo2.mainIPCR != null) {
            solrInfo.mainIPCR = patentInfo2.mainIPCR.toUpperCase();
            solrInfo.mainIPCRNormal = normalizeIpcAndCpc(ClassificationType.IPC, solrInfo.mainIPCR, solrInfo).ipcNormal;
        } else {
            solrInfo.mainIPCR = patentInfo2.mainIPCR;
        }

        if(patentInfo2.mainLOC != null) {
            LocInfo locInfo = normalizeLoc(patentInfo2.mainLOC.toUpperCase(), solrInfo);
            solrInfo.mainLOCClass = locInfo.clazz;
            solrInfo.mainLOC= locInfo.locNormal;
        } else {
            solrInfo.mainLOC = patentInfo2.mainLOC;
        }

        if(patentInfo2.mainUSPC != null) {
            solrInfo.mainUSPC = patentInfo2.mainUSPC.toUpperCase();
        } else {
            solrInfo.mainUSPC = patentInfo2.mainUSPC;
        }

        if(patentInfo2.mainFI != null) {
            //Matcher fiMatcher = rePatentFISubDivision.matcher(patentInfo2.mainFI);
            FiInfo fiInfo = normalizeFI(patentInfo2.mainFI.toUpperCase(), solrInfo);
            solrInfo.mainFI = fiInfo.fiNormal;
            solrInfo.mainFIClass = fiInfo.clazz;
            solrInfo.mainFISubClass = fiInfo.subClazz;
            solrInfo.mainFIGroup = fiInfo.group;
            solrInfo.mainFISubGroup = fiInfo.subGroup;
            solrInfo.mainFIAll = fiInfo.fiAll;
        } else {
            solrInfo.mainFI = patentInfo2.mainFI;
        }

        if(patentInfo2.mainFTerm != null) {
            solrInfo.mainFterm = patentInfo2.mainFTerm.toUpperCase();
        } else {
            solrInfo.mainFterm = patentInfo2.mainFTerm;
        }

        if(patentInfo2.mainDI != null) {
            solrInfo.mainDI = patentInfo2.mainDI.toUpperCase();
        } else {
            solrInfo.mainDI = patentInfo2.mainDI;
        }

        if(patentInfo2.mainDTerm != null) {
            solrInfo.mainDTerm = patentInfo2.mainDTerm.toUpperCase();
        } else {
            solrInfo.mainDTerm = patentInfo2.mainDTerm;
        }

        if(patentInfo2.cpcs != null) {
            solrInfo.cpcs = upperCaseStrList(patentInfo2.cpcs);
            List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.CPC, solrInfo.cpcs, solrInfo);
            for(IpcInfo ipcInfo: ipcInfos) {
                solrInfo.cpcsNormal.add(ipcInfo.ipcNormal);
                solrInfo.cpcsClass.add(ipcInfo.clazz);
                solrInfo.cpcsSubClass.add(ipcInfo.subClazz);
                solrInfo.cpcsGroup.add(ipcInfo.group);
                solrInfo.cpcsSubGroup.add(ipcInfo.subGroup);
            }
        }

        if(patentInfo2.ipcs != null) {
            solrInfo.ipcs = upperCaseStrList(patentInfo2.ipcs);
            //only for JP case, ex: [H01L 29/784, 21/76] -> [H01L 29/784, H01L 21/76]
            if(patentInfo2.pto.equals("JPO")) {
                String ipcSubClass = "";
                for(int i = 0; i< solrInfo.ipcs.size();i++) {
                    Matcher matcher4JPSubClass = rePatentIpcNormal4JPSubClass.matcher(solrInfo.ipcs.get(i));
                    if(matcher4JPSubClass.find()) {
                        ipcSubClass = matcher4JPSubClass.group(1) + matcher4JPSubClass.group(2) + matcher4JPSubClass.group(3);
                    } else if (rePatentIpcNormal4JPGroup.matcher(solrInfo.ipcs.get(i)).find()){
                        solrInfo.ipcs.set(i, ipcSubClass + " " + solrInfo.ipcs.get(i));
                    }
                }
            }
            List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.IPC, solrInfo.ipcs, solrInfo);
            for(IpcInfo ipcInfo: ipcInfos) {
                solrInfo.ipcsNormal.add(ipcInfo.ipcNormal);
                solrInfo.ipcsClass.add(ipcInfo.clazz);
                solrInfo.ipcsSubClass.add(ipcInfo.subClazz);
                solrInfo.ipcsGroup.add(ipcInfo.group);
                solrInfo.ipcsSubGroup.add(ipcInfo.subGroup);
            }
        }

        if(patentInfo2.ipcrs != null) {
            solrInfo.ipcrs = upperCaseStrList(patentInfo2.ipcrs);
            List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.IPC, solrInfo.ipcrs, solrInfo);
            for(IpcInfo ipcInfo: ipcInfos) {
                solrInfo.ipcrsNormal.add(ipcInfo.ipcNormal);
            }
        }

        if(patentInfo2.locs != null) {
            List<LocInfo> loccInfos = normalizeLocs(upperCaseStrList(patentInfo2.locs), solrInfo);
            for(LocInfo loccInfo: loccInfos) {
                solrInfo.locs.add(loccInfo.locNormal);
                solrInfo.locsClass.add(loccInfo.clazz);
            }
        }

        if(patentInfo2.uspcs != null) {
            solrInfo.uspcs = upperCaseStrList(patentInfo2.uspcs);
        }

        if(patentInfo2.fis != null) {
            //only for JP case, ex: [H01L 29/784, 21/76] -> [H01L 29/784, H01L 21/76]
            solrInfo.fis = upperCaseStrList(patentInfo2.fis);
            String fiSubClass = "";
            for(int i = 0; i< solrInfo.fis.size();i++) {
                Matcher matcher4JPSubClass = rePatentIpcNormal4JPSubClass.matcher(solrInfo.fis.get(i));
                if(matcher4JPSubClass.find()) {
                    fiSubClass = matcher4JPSubClass.group(1) + matcher4JPSubClass.group(2) + matcher4JPSubClass.group(3);
                } else if (rePatentIpcNormal4JPGroup.matcher(solrInfo.fis.get(i)).find()){
                    solrInfo.fis.set(i, fiSubClass + " " + solrInfo.fis.get(i));
                }
            }
            List<FiInfo> fiInfos = normalizeFis(solrInfo.fis, solrInfo);
            solrInfo.fis = new ArrayList<String>();
            for(FiInfo fiInfo: fiInfos) {;
                solrInfo.fis.add(fiInfo.fiNormal);
                solrInfo.fisClass.add(fiInfo.clazz);
                solrInfo.fisSubClass.add(fiInfo.subClazz);
                solrInfo.fisGroup.add(fiInfo.group);
                solrInfo.fisSubGroup.add(fiInfo.subGroup);
                solrInfo.fisAll.addAll(fiInfo.fiAll);
            }
        }

        if(patentInfo2.fterms != null) {
            solrInfo.fterms = upperCaseStrList(patentInfo2.fterms);
        }

        if(patentInfo2.dis != null) {
            solrInfo.dis = upperCaseStrList(patentInfo2.dis);
        }

        if(patentInfo2.dterms != null) {
            solrInfo.dterms = upperCaseStrList(patentInfo2.dterms);
        }

        if(patentInfo2.eclas != null) {
            solrInfo.eclas = upperCaseStrList(patentInfo2.eclas);
        }

        for (Person person : patentInfo2.agents) {
            fillPerson(person, solrInfo, "agents");
        }

        for (Person person : patentInfo2.agentOperators) {
            fillPerson(person, solrInfo, "agentOperators");
        }

        for (Person person : patentInfo2.applicants) {
            fillPerson(person, solrInfo, "applicants");
        }

        for (Person person : patentInfo2.assignees) {
            fillPerson(person, solrInfo, "assignees");
        }

        for (Person person : patentInfo2.docdbAssignees) {
            fillPerson(person, solrInfo, "docdbAssignees");
        }

        for (Person person : patentInfo2.docdbaAssignees) {
            fillPerson(person, solrInfo, "docdbaAssignees");
        }

        for (Person person : patentInfo2.inventors) {
            fillPerson(person, solrInfo, "inventors");
        }

        for (Person person : patentInfo2.docdbInventors) {
            fillPerson(person, solrInfo, "docdbInventors");
        }

        for (Person person : patentInfo2.docdbaInventors) {
            fillPerson(person, solrInfo, "docdbaInventors");
        }

        for (Person person : patentInfo2.examinerMasters) {
            fillPerson(person, solrInfo, "examinerMasters");
        }

        for (Person person : patentInfo2.examinerSlaves) {
            fillPerson(person, solrInfo, "examinerSlaves");
        }

        solrInfo.filePageClaim = patentInfo2.filePageClaim;
        solrInfo.filePageDesc = patentInfo2.filePageDesc;
        solrInfo.filePageFig = patentInfo2.filePageFig;
        solrInfo.filePageFirst = patentInfo2.filePageFirst;
        solrInfo.filePageNumber = patentInfo2.filePageNumber;
        solrInfo.gazettePageNumber = patentInfo2.gazettePageNumber;
        solrInfo.clipPageNumber = patentInfo2.clipPageNumber;
        solrInfo.figurePageNumber = patentInfo2.figurePageNumber;
        solrInfo.firstImagePageFlag = patentInfo2.firstImagePageFlag;

        for (String otherReferences : patentInfo2.otherReferences) {
            addUnique(solrInfo.otherReferences, otherReferences);
        }

        for (RelatedPatent pat : patentInfo2.priorityPatents) {
            if(pat.appNumber!=null) {
                addUnique(solrInfo.priorityPatentsNumberAll, pat.appNumber);
            } else {
                addUnique(solrInfo.priorityPatentsNumberAll, pat.patentNumber);
            }
            solrInfo.priorityPatents.add(JSONUtil.object2Json(pat).replaceAll("\"pto\"", "\"country\""));
        }

        for (RelatedPatent pat : patentInfo2.citedPatents) {
            addUnique(solrInfo.citedPatentsNumberAll, pat.patentNumber);
            solrInfo.citedPatents.add(JSONUtil.object2Json(pat).replaceAll("\"pto\"", "\"country\""));
        }

        for (RelatedPatent pat : patentInfo2.relatedPatents) {
            solrInfo.relatedPatents.add(JSONUtil.object2Json(pat).replaceAll("\"pto\"", "\"country\""));
            if(pat.relation !=null && pat.relation.equals("ReissueOf")) {
                solrInfo.appNumberGroup = (patentInfo2.country + pat.appNumber).toUpperCase();
            }
        }

        if(patentInfo2.dividedPatent != null) {
            solrInfo.dividedPatent = JSONUtil.object2Json(patentInfo2.dividedPatent).replaceAll("\"pto\"", "\"country\"");
        }

        if(patentInfo2.kindcode == null) {
            solrInfo.kindcode = "";
        } else {
            solrInfo.kindcode = patentInfo2.kindcode.toUpperCase();
        }
        
        solrInfo.type = patentInfo2.type;
        if(patentInfo2.pto.equals("WIPO") || patentInfo2.pto.equals("EPO")) {
            solrInfo.type = "Utility";
        }
        if(!isEmpty(solrInfo.type)) {
            solrInfo.typeCode = getTypeCode(solrInfo.type);
        }

        if(patentInfo2.stat != 3) {
            solrInfo.stats = new Integer[1];
            solrInfo.stats[0] = patentInfo2.stat;
        } else {
            solrInfo.stats = new Integer[2];
            solrInfo.stats[0] = 1;
            solrInfo.stats[0] = 2;
        }

        solrInfo.familyId = patentInfo2.familyId;
        if(patentInfo2.familyId != null) {
            solrInfo.familyIdGroup = patentInfo2.familyId.toString().toUpperCase();
        } else {
            String familyId = solrInfo.appNumberGroup;
            if (isEmpty(familyId)) {
                familyId = solrInfo.ptopid;
            }
            solrInfo.familyIdGroup = familyId.toUpperCase();
        }

        if(!isEmpty(patentInfo2.brief)) {
            solrInfo.brief = getMultiLang(patentInfo2.brief, "");
        }

        if(!isEmpty(patentInfo2.claim)) {
            solrInfo.claim = getMultiLang(patentInfo2.claim, "");
        }

        if(!isEmpty(patentInfo2.description)) {
            solrInfo.description = getMultiLang(patentInfo2.description, "");
        }

        if(!isEmpty(patentInfo2.title)) {
            solrInfo.title = getMultiLang(patentInfo2.title, "");
        }

        fillDate(patentInfo2.doDate, solrInfo, "do");
        fillDate(patentInfo2.docdbDoDate, solrInfo, "docdbDo");

        solrInfo.truncate = patentInfo2.truncate;

        return solrInfo;
    }

    protected static ArrayList<IpcInfo> normalizeIpcsAndCpcs(Enum<ClassificationType> classificationType, List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<IpcInfo> IpcInfos = new ArrayList<IpcInfo>();
        for(String pc: pcs) {
            IpcInfos.add(normalizeIpcAndCpc(classificationType, pc, solrInfo));
        }
        return IpcInfos;
    }

    //pattern original ipc or cpc format
    private static Pattern rePatentIpcAndCpc1 = Pattern.compile("^([A-Z])([0-9]{2})([A-Z])[\\s]*([0-9]+)/{1,2}([0-9]+)(.*$)");
    //for special case like "C 10 M 1/ 7/12"
    private static Pattern rePatentIpcAndCpc2 = Pattern.compile("^([A-Z])[\\s]+([0-9]{2})[\\s]+([A-Z])[\\s]+([0-9]+)/[\\s]+([0-9]+)/([0-9]+)");
    //pattern for ipc format after normalize
    private static Pattern rePatentIpcAndCpcNormal = Pattern.compile("^([A-Z])([0-9]{2})([A-Z])([0-9]{4})([0-9]{6})");
    protected static IpcInfo normalizeIpcAndCpc(Enum<ClassificationType> classificationType, String pc, SolrPatentInfo solrInfo) {
        Matcher matcher1 = rePatentIpcAndCpc1.matcher(pc);
        if(matcher1.find()) {
            String section = matcher1.group(1);
            String clazz = matcher1.group(2);
            String subClazz = matcher1.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher1.group(4)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher1.group(5)).replace(' ', '0');

            return getIpcInfo(classificationType, section, clazz, subClazz,
                    group, subGroupOri);
        }
        
        Matcher matcherNormal = rePatentIpcAndCpcNormal.matcher(pc);
        if (matcherNormal.find()){
            String section = matcherNormal.group(1);
            String clazz = matcherNormal.group(2);
            String subClazz = matcherNormal.group(3);
            String group = matcherNormal.group(4);
            String subGroupOri = matcherNormal.group(5);

            return getIpcInfo(classificationType, section, clazz, subClazz,
                    group, subGroupOri);
        }

        Matcher matcher2 = rePatentIpcAndCpc2.matcher(pc);
        if(matcher2.find()) {
            String section = matcher2.group(1);
            String clazz = matcher2.group(2);
            String subClazz = matcher2.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher2.group(4) + matcher2.group(5)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher2.group(6)).replace(' ', '0');

            return getIpcInfo(classificationType, section, clazz, subClazz,
                    group, subGroupOri);
        }
        IpcInfo ipcInfo = new IpcInfo();
        solrInfo.isPcNormal = false;
        ipcInfo.ipcNormal = pc;
        return ipcInfo;
    }

    private static IpcInfo getIpcInfo(Enum<ClassificationType> classificationType, String section, String clazz, String subClazz, String group, String subGroupOri) {
        
        IpcInfo ipcInfo = new IpcInfo();
        ipcInfo.clazz = section + clazz;
        ipcInfo.subClazz = ipcInfo.clazz + subClazz;
        ipcInfo.group = ipcInfo.subClazz + group;
        String subGroupVal = IpcCpcFinder.getSubGroup(classificationType, ipcInfo.group + subGroupOri);
        if(subGroupVal != null) {
            ipcInfo.subGroup = subGroupVal;
        }
        ipcInfo.ipcNormal = ipcInfo.group + subGroupOri;
        String mainGroupVal = IpcCpcFinder.getMainGroup(classificationType, ipcInfo.group + subGroupOri);
        if(mainGroupVal != null) {
            ipcInfo.group = mainGroupVal;
        } else {
            ipcInfo.group = ipcInfo.group + "000000";
        }
        return ipcInfo;
    }

    protected static ArrayList<FiInfo> normalizeFis(List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<FiInfo> fiInfos = new ArrayList<FiInfo>();
        for(String pc: pcs) {
            fiInfos.add(normalizeFI(pc, solrInfo));
        }
        return fiInfos;
    }

    //日本 fi
    private static Pattern rePatentFI = Pattern.compile("^([A-Z])[\\s]*([0-9]{2})[\\s]*([A-Z])[\\s]*([0-9]+)/([0-9]+)[\\s]*(.*)");
    //"G01F 21/01 301" or "G01F 21/01 301 A"
    private static Pattern rePatentFISubDivision = Pattern.compile("^([0-9]{3})\\s*([A-Z]?)");
    //"G01F 21/01 A"
    private static Pattern rePatentFIFileDiscrimination = Pattern.compile("^([A-Z])");
    protected static FiInfo normalizeFI(String pc, SolrPatentInfo solrInfo) {
        FiInfo fiInfo = new FiInfo();
        fiInfo.fiAll = new ArrayList<String>();
        Matcher matcher = rePatentFI.matcher(pc);
        if(matcher.find()) {
            String section = matcher.group(1);
            String clazz = matcher.group(2);
            String subClazz = matcher.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher.group(4)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher.group(5)).replace(' ', '0');
            String others = matcher.group(6);

            fiInfo.clazz = section + clazz;
            fiInfo.subClazz = fiInfo.clazz + subClazz;
            fiInfo.group = fiInfo.subClazz + group;
            String subGroupVal = IpcCpcFinder.getSubGroup(ClassificationType.IPC, fiInfo.group + subGroupOri);
            if(subGroupVal != null) {
                fiInfo.subGroup = subGroupVal;
            }
            fiInfo.fiNormal = fiInfo.group + subGroupOri;
            fiInfo.fiAll.add(fiInfo.fiNormal);
            Matcher fiMatcher1 = rePatentFISubDivision.matcher(others);
            if(fiMatcher1.find()) {
                if(!fiMatcher1.group(2).isEmpty()) {
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1) + fiMatcher1.group(2));
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1));
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(2));
                    fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher1.group(1) + fiMatcher1.group(2);
                } else {
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1));
                    fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher1.group(1);
                }
            }
            Matcher fiMatcher2 = rePatentFIFileDiscrimination.matcher(others);
            if(fiMatcher2.find()) {
                fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher2.group(1));
                fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher2.group(1);
            }
            fiInfo.group = fiInfo.group + "000000";
            return fiInfo;
        }
        
        solrInfo.isPcNormal = false;
        fiInfo.fiNormal = pc;
        return fiInfo;
    }

    protected static ArrayList<LocInfo> normalizeLocs(List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<LocInfo> LocInfos = new ArrayList<LocInfo>();
        for(String pc: pcs) {
            LocInfos.add(normalizeLoc(pc, solrInfo));
        }
        return LocInfos;
    }

    private static Pattern rePatentLoc1 = Pattern.compile("^([0-9]{1,2})([\\s/-−]0?)([0-9]{1,2})(.*$)");
    //for 0805/
    private static Pattern rePatentLoc2 = Pattern.compile("^([0-9]{1,2})([0-9]{1,2})/");
    protected static LocInfo normalizeLoc(String loc, SolrPatentInfo solrInfo) {
        LocInfo locInfo = new LocInfo();

        Matcher matcher1 = rePatentLoc1.matcher(loc);
        if(matcher1.find()) {
            String clazz = String.format("%02d", Integer.parseInt(matcher1.group(1)));
            String subClazz = String.format("%02d", Integer.parseInt(matcher1.group(3)));


            locInfo.clazz = clazz;
            locInfo.locNormal = clazz + "-" + subClazz;
            return locInfo;
        }

        Matcher matcher2 = rePatentLoc2.matcher(loc);
        if(matcher2.find()) {
            String clazz = String.format("%02d", Integer.parseInt(matcher2.group(1)));
            String subClazz = String.format("%02d", Integer.parseInt(matcher2.group(2)));

            locInfo.clazz = clazz;
            locInfo.locNormal = clazz + "-" + subClazz;
            return locInfo;
        }

        solrInfo.isPcNormal = false;
        locInfo.locNormal = loc;
        return locInfo;
    }

    protected static ArrayList<String> upperCaseStrList(List<String> list) {
        ArrayList<String> upperList = new ArrayList<String>();
        for(String str : list)
        {
            upperList.add(str);
        }
        return upperList;
    }

    protected static boolean isEmpty(String value) {
        if (value == null) {
            return true;
        }
        if (value.trim().isEmpty()) {
            return true;
        }
        return false;
    }

    protected static boolean isEmpty(MultiLangString value) {
        if (value == null) {
            return true;
        }
        return isEmpty(getMultiLang(value, null));
    }

    protected static void addUnique(List<String> field, String value) {
        if (isEmpty(value)) {
            return;
        }
        if (!field.contains(value)) {
            field.add(value);
        }
    }

    protected static String genString(String... args) {
        StringBuffer sb = new StringBuffer();
        for (String s : args) {
            if (!isEmpty(s)) {
                sb.append(s);
            }
        }
        return sb.toString();
    }

    protected static String getMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        data = (MultiLangString) data.clone();
        String ret = JSONUtil.object2Json(data);
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    protected static Class<?> clazz = MultiLangString.class;
    protected static String getPersonNameMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        
        data = (MultiLangString) data.clone();
        data.filter(new LangFilter() {
            @Override
            public String filter(String lang, String value, MultiLangString context) {
                return StringUtil.personFacetWrap(value);
            }
        });

        String ret = JSONUtil.object2Json(data);
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    protected static void fillPerson(Person person, SolrPatentInfo solr, String solrFieldName) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        if (person == null) {
            return;
        }

        //為了解決 facet search bug 的治標方法，強行將語系都轉成 origin，避免 facet search 因為語系不同分成不同組
        //目前應該只有 WIPO 和 DOCDB 會遇到此問題
        if(person.name != null && person.name.origin == null && person.name.langCount() == 1) {
            String lang = person.name.langValues().get(0);
            Field field = clazz.getField(lang);
            String value = (String) field.get(person.name);
            person.name.origin = value;
            field.set(person.name, null);
        }

        try {
            Field fperson = solr.getClass().getField(solrFieldName);
            ArrayList<String> pperson = (ArrayList<String>) fperson.get(solr);
            if(person != null) {
                pperson.add(JSONUtil.object2Json(person));
            }

            Field ffacetname = solr.getClass().getField(solrFieldName + "Facetname");
            ArrayList<String> pfacetname = (ArrayList<String>) ffacetname.get(solr);
            if(!isEmpty(getPersonNameMultiLang(person.name, null))) {
                pfacetname.add(getPersonNameMultiLang(person.name, null));
            }

            if(solrFieldName.startsWith("docdba")) {
                solrFieldName = solrFieldName.replaceAll("docdba", "").toLowerCase();
            } else if(solrFieldName.startsWith("docdb")) {
                solrFieldName = solrFieldName.replaceAll("docdb", "").toLowerCase();
            }
            Field fname = solr.getClass().getField(solrFieldName + "Name");
            ArrayList<String> pname = (ArrayList<String>) fname.get(solr);
            if(!isEmpty(person.name)) {
                pname.add(getMultiLang(person.name, null));
            }

            Field faddress = solr.getClass().getField(solrFieldName + "Address");
            ArrayList<String> paddress = (ArrayList<String>) faddress.get(solr);
            if(!isEmpty(person.name)) {
                paddress.add(getMultiLang(person.address, null));
            }

            Field fcountry = solr.getClass().getField(solrFieldName + "Country");
            ArrayList<String> pcountry = (ArrayList<String>) fcountry.get(solr);
            if(!isEmpty(person.name) && person.country != null) {
                List<String> countrys = person.country.langValues();
                if (countrys.size() > 0) {
                    pcountry.add(countrys.get(0));
                }
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }
    
    public static Pair<String, String> getPersonNameAndFacetname(Person person) {
        if (person == null) {
            return null;
        }

        try {
            //為了解決 facet search bug 的治標方法，強行將語系都轉成 origin，避免 facet search 因為語系不同分成不同組
            //目前應該只有 WIPO 和 DOCDB 會遇到此問題
            if(person.name != null && person.name.origin == null && person.name.langCount() == 1) {
                String lang = person.name.langs().get(0);
                Field field = clazz.getField(lang);
                String value = (String) field.get(person.name);
                person.name.origin = value;
                field.set(person.name, null);
            }
            
            String facetname = null;
            if(!isEmpty(getPersonNameMultiLang(person.name, null))) {
                facetname = getPersonNameMultiLang(person.name, null);
            }

            String name = null;
            if(!isEmpty(person.name)) {
                name = getMultiLang(person.name, null);
            }
            
            return new ImmutablePair<>(name, facetname);
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
    
    protected static void fillDate(Date date, SolrPatentInfo solr, String solrFieldName) {
        if (date == null) {
            return;
        }

        try {
            Field fdate = solr.getClass().getField(solrFieldName + "Date");
            fdate.set(solr, date);

            Field fdateYear = solr.getClass().getField(solrFieldName + "Year");
            SimpleDateFormat fmtYear = new SimpleDateFormat("yyyy");
            fdateYear.set(solr, Integer.parseInt(fmtYear.format(date)));

            Field fdateYearMon = solr.getClass().getField(solrFieldName + "Yearmon");
            SimpleDateFormat fmtYearMon = new SimpleDateFormat("yyyyMM");
            fdateYearMon.set(solr, Integer.parseInt(fmtYearMon.format(date)));
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    protected static int getTypeCode(String type) {
        int typeCode = 0;
        List<String> type1 = new ArrayList<String>();
        type1.add("Utility");
        type1.add("发明专利");
        type1.add("發明");
        type1.add("특허");
        type1.add("特許");

        List<String> type2 = new ArrayList<String>();
        type2.add("实用新型");
        type2.add("新型");
        type2.add("실용신안");
        type2.add("実用新案");
        type2.add("Model");

        List<String> type3 = new ArrayList<String>();
        type3.add("Design");
        type3.add("外观专利");
        type3.add("設計");
        type3.add("디자인");
        type3.add("意匠公報");

        List<String> type4 = new ArrayList<String>();
        type4.add("Plant");

        List<String> type5 = new ArrayList<String>();
        type5.add("Reissue");

        List<String> type6 = new ArrayList<String>();
        type6.add("SIR");

        List<String> type7 = new ArrayList<String>();
        type7.add("公表");
        type7.add("再公表");

        List<String> type9 = new ArrayList<String>();
        type9.add("Others");

        Hashtable typeHash = new Hashtable();
        typeHash.put(type1, 1);
        typeHash.put(type2, 2);
        typeHash.put(type3, 3);
        typeHash.put(type4, 4);
        typeHash.put(type5, 5);
        typeHash.put(type6, 6);
        typeHash.put(type7, 7);
        typeHash.put(type9, 9);

        Enumeration en = typeHash.keys();
        while (en.hasMoreElements()) {
            List list = (List) en.nextElement();
            if(list.contains(type)) {
                typeCode = (int)typeHash.get(list);
            }
        }
        return typeCode;
    }

    // US1: US008295630 US00D242762 US000PP3994 US00RE28691 US0000H1443
    private static Pattern rePatentNumberUS1 = Pattern.compile("^(US)?0*((D|PP|RE|H|T)?\\d+)$");
    // US2: 12/575,551
    private static Pattern rePatentNumberUS2 = Pattern.compile("^(US)?(\\d+)/(\\d*),?(\\d*)$");
    // US3: 20040095078 2004095078, EPDOC use secondary
    private static Pattern rePatentNumberUS3 = Pattern.compile("^(\\d{4})0(\\d{6})$");
    // TW1: 079100883 I319544 M363691 D138757
    private static Pattern rePatentNumberTW1 = Pattern.compile("^(TW)?0*((I|M|D)?\\d+)$");
    // CN1: 200810306395.2 CN200810306395
    private static Pattern rePatentNumberCN1 = Pattern.compile("^(CN)?(\\d{12})(\\.\\S+)?$");
    // CN2: CN101751575A 101751575 
    private static Pattern rePatentNumberCN2 = Pattern.compile("^(CN)?(\\d{7,9})(\\D)?$");

    private static Pattern rePatentNumberTail = Pattern.compile("^(\\S+)(\\d\\d\\d)$");
    // added by yiyun for WO 2013/10/31        WO: WO 2012/000001
    private static Pattern rePatentNumberWO = Pattern.compile("^WO(\\s)(\\d{4})/(\\d{6})$");
    // added by yiyun for WO 2014/04/08     APN: PCT/US2007/022037
    private static Pattern rePatentNumberWO1 = Pattern.compile("^PCT/(\\w{6})/0?(\\d*)$");
    // added by yh
    // EP1: appNo: 11165961.1
    private static Pattern rePatentNumberEP1 = Pattern.compile("^(\\d{8})(\\.\\S+)?$");
    // EP2: pn/openNo : EP2398401
    private static Pattern rePatentNumberEP2 = Pattern.compile("^(EP)(\\d{7})?$");
    //added by luken 20131109
    private static Pattern rePatentNumberKR1 = Pattern.compile("^(\\d{13})?$");
    //added end

    @SuppressWarnings("unchecked")
    protected static void fillNumber(String number, SolrPatentInfo solr, String solrFieldName, 
                                        String country, String kindcode) {
        if (isEmpty(number)) {
            return;
        }

        ArrayList<String> numberall = new ArrayList<>();
        numberall.add(number);

        String fix;
        Matcher matcher;

        matcher = rePatentNumberUS1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberUS2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);

            fix = genString(matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberUS3.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberTW1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberCN1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberCN2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }
        
        // added by yiyun for WO 2013/10/31
        matcher = rePatentNumberWO.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }
        // added by yiyun for WO 2014/04/08
        matcher = rePatentNumberWO1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
            
            fix = genString("PCT/", matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
        }
        
        // added by yh
        matcher = rePatentNumberEP1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);

            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
        }
        
        matcher = rePatentNumberEP2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }
        // add end
        
        //added by luken 20131129
        matcher = rePatentNumberKR1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);
        }
        
        //added end
        
        // added by hanyao 20140624
        if (country.contains("JP")) {
            if (number.contains("(") || number.contains(")")) {
                String temNumber = number.substring(0, number.indexOf("("));
                addUnique(numberall, temNumber);
            }
            String regx = "\\d{1,}-?\\d{1,}";
            Pattern reNumberJP = Pattern.compile(regx);
            matcher = reNumberJP.matcher(number);
            if (matcher.find()) {
                String temp = matcher.group(0);
                if (temp.contains("-")) {
                    String preTemp = temp.substring(0, temp.indexOf("-"));
                    String aftTemp = temp.substring(temp.indexOf("-") + 1);
                    if (preTemp.length() < 2) {
                        preTemp = "0" + preTemp;
                    }
                    temp = preTemp + "-" + aftTemp;
                    addUnique(numberall, temp);
                    if (aftTemp.length() < 6) {
                        int i = 6 - aftTemp.length();
                        switch (i) {
                        case 1:
                            aftTemp = "0" + aftTemp;
                            break;
                        case 2:
                            aftTemp = "00" + aftTemp;
                            break;
                        case 3:
                            aftTemp = "000" + aftTemp;
                            break;
                        case 4:
                            aftTemp = "0000" + aftTemp;
                            break;
                        case 5:
                            aftTemp = "00000" + aftTemp;
                            break;
                        }
                        temp = preTemp + "-" + aftTemp;
                        addUnique(numberall, temp);
                    }
                    String num = temp.substring(temp.indexOf("-") + 1);
                    String year = temp.substring(0,temp.indexOf("-"));
                    String jpNum = "";
                    int j = Integer.parseInt(num);
                    num = j + "";
                    num = temp.substring(0, temp.indexOf("-") + 1) + num;
                    addUnique(numberall, num);
                    addUnique(numberall, "JP" + num);
                    if (number.contains("平")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1988) + temp.substring(temp.indexOf("-"));
                        num = "H" + num;
                        temp = "H" + temp;
                        //addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    if (number.contains("昭")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1925) + temp.substring(temp.indexOf("-"));
                        num = "S" + num;
                        temp = "S" + temp;
                        //addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    //addUnique(numberall, "JP" + num);
                    //addUnique(numberall, "JP" + temp);
                    addUnique(numberall, temp);
                    addUnique(numberall, num);
                } else {
                    addUnique(numberall, temp);
                    //addUnique(numberall, "JP" + temp);
                }
            }
        }

        //Add country + to number
        for (String n : (ArrayList<String>) numberall.clone()) {
            if (!n.startsWith(country)) {
                fix = country + n;
                addUnique(numberall, fix);
            }
        }

        if (country.equals("US") && solrFieldName.contains("decision")) {
            if (number.length() != 11) {    //公告
                String pn = "US" + StringUtils.leftPad(number, 9, "0");
                addUnique(numberall, pn);
            }
        }

        //besides appNumber, add kindcode to all number's tail
        if(!solrFieldName.contains("appNumber") && kindcode != null) {
            for (String n : (ArrayList<String>) numberall.clone()) {
                if (!n.endsWith(kindcode)) {
                    fix = n + kindcode;
                    addUnique(numberall, fix);
                }
            }
        }
        
        try {
            if(solrFieldName.contains("decision")) {
                number = number.replaceAll("^(US)0*", "");
            }
            Field fnumber = solr.getClass().getField(solrFieldName + "Number");
            fnumber.set(solr, number);
            if(!solrFieldName.contains("patent")) {
                Field fnumberall = solr.getClass().getField(solrFieldName + "NumberAll");
                fnumberall.set(solr, numberall);
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }


}
