package com.patentsolr.assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class AssignmentFinder {

    public static List<AssignmentRecord> queryByAppNumber(String appNumber) throws Exception {
        Connection conn = getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<AssignmentRecord> data = new ArrayList<AssignmentRecord>();
        try {
            pstmt = conn.prepareStatement("select * from AssignmentETL where appNumber = ? order by executionDate");
            pstmt.setString(1, appNumber);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                AssignmentRecord r = new AssignmentRecord();
                r.autoId = rs.getInt("Auto_ID");
                r.appNumber = rs.getString("appNumber");
                r.patentNumber = rs.getString("patentNumber");
                r.reelframeNo = rs.getString("reelframeNo");
                Timestamp timestamp = rs.getTimestamp("recordedDate");
                if (timestamp != null) {
                    r.recordedDate = new java.util.Date(timestamp.getTime());
                }
                timestamp = rs.getTimestamp("executionDate");
                if (timestamp != null) {
                    r.executionDate = new java.util.Date(timestamp.getTime());
                }
                r.conveyanceText = rs.getString("conveyanceText");
                r.conveyanceType = rs.getFloat("conveyanceType");
                r.assignorName = rs.getString("assignorName");
                r.assigneeName = rs.getString("assigneeName");
                r.assigneeCountry = rs.getString("assigneeCountry");
                r.correspondentname = rs.getString("Correspondentname");
                timestamp = rs.getTimestamp("lastUpdate");
                if (timestamp != null) {
                    r.lastUpdate = new java.util.Date(timestamp.getTime());
                }
                r.iNtoCORP = rs.getInt("INtoCORP");
                r.pubFlag = rs.getInt("PubFlag");
                timestamp = rs.getTimestamp("Updated");
                if (timestamp != null) {
                    r.updated = new java.util.Date(timestamp.getTime());
                }
                data.add(r);
            }
        } finally {
            try { rs.close(); } catch (Exception e) {}
            try { pstmt.close(); } catch (Exception e) {}
            try { conn.close(); } catch (Exception e) {}
        }
        return data;
    }
    
    private static Connection getConnection() throws Exception {
        // org.mariadb.jdbc.MySQLDataSource
        Class.forName("org.logicalcobwebs.proxool.ProxoolDriver");
        Connection conn = DriverManager.getConnection("proxool.mariadb:org.mariadb.jdbc.Driver:jdbc:mariadb://10.60.90.211/Assignment", "allenwu", "allenwu");
        return conn;
    }
    
}
