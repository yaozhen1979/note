package com.patentsolr.assignment;

import java.util.Date;

public class AssignmentRecord {

    public int autoId;
    public String appNumber;
    public String patentNumber;
    public String reelframeNo;
    public Date recordedDate;
    public Date executionDate;
    public String conveyanceText;
    public float conveyanceType;
    public String assignorName;
    public String assigneeName;
    public String assigneeCountry;
    public String correspondentname;
    public Date lastUpdate;
    public int iNtoCORP;
    public int pubFlag;
    public Date updated;
    
}
