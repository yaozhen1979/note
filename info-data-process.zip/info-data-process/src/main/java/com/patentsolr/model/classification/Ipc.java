package com.patentsolr.model.classification;

public class Ipc {

    public String id;
    public String parentId;
    public String symbol;
    public String title;
    public int level;
    public String subGroup;
    public String mainGroup;
    
}
