package com.patentsolr.model;

import java.util.Date;

public class OutsideData {

    public String type;

    public String data;

    public Date updateTime;

    @Override
    public String toString() {
        return "OutsideData [type=" + type + ", data=" + data + ", updateTime="
                + updateTime + "]";
    }

}
