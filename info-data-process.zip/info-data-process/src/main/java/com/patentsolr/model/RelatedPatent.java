package com.patentsolr.model;

import java.util.ArrayList;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RelatedPatent {
    
    public String pto;
    public String appNumber;
    public String patentNumber;
    public String decsisionNumber;
    public String openNumber;
    public String doNumber;
    public String kindcode;
    public Integer stat;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date appDate;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date decisionDate;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date openDate;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date doDate;
    public String relation;
    public ArrayList<Person> inventors = new ArrayList<>();
    
    @Override
    public String toString() {
        return "RelatedPatent [pto=" + pto + ", appNumber=" + appNumber
                + ", patentNumber=" + patentNumber + ", decsisionNumber="
                + decsisionNumber + ", openNumber=" + openNumber
                + ", doNumber=" + doNumber + ", kindcode=" + kindcode
                + ", stat=" + stat + ", appDate=" + appDate + ", decisionDate="
                + decisionDate + ", openDate=" + openDate + ", doDate="
                + doDate + ", relation=" + relation + ", inventors="
                + inventors + "]";
    }
}
