package com.patentsolr.model.integration;

import java.util.Date;
import java.util.List;

import org.jongo.marshall.jackson.oid.MongoId;

public class IntegrationUS {

    @MongoId
    public String id;
    
    public boolean docdb;
    public boolean fullText;
    public boolean currentAssignee;
    public boolean litigationLN;
    public boolean litigationDN;
    public boolean uspc;
    public boolean cpc;
    
    public Date createdDate;
    public Date lastUpdateDate;
    
    public String appNumber;
    public Date appDate;

    public String docNumber;
    public Date docDate;
    
    public Integer stat;
    
    public Relations relations;
    
    public Date docdbDoDate;
    public Date currentAssigneeUpdateLog;
    
    public List<Event> events;
    
    @Override
    public String toString() {
        return "IntegrationUS [id=" + id + ", docdb=" + docdb + ", fullText="
                + fullText + ", currentAssignee=" + currentAssignee
                + ", litigationLN=" + litigationLN + ", uspc=" + uspc
                + ", cpc=" + cpc + ", createdDate=" + createdDate
                + ", lastUpdateDate=" + lastUpdateDate + ", appNumber="
                + appNumber + ", appDate=" + appDate + ", docNumber="
                + docNumber + ", docDate=" + docDate + ", stat=" + stat
                + ", relations=" + relations + ", docdbDoDate=" + docdbDoDate
                + ", currentAssigneeUpdateLog=" + currentAssigneeUpdateLog
                + ", events=" + events + "]";
    }
}
