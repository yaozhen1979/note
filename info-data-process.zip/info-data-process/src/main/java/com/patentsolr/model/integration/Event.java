package com.patentsolr.model.integration;

import java.util.Date;

public class Event {

    public String id;
    public String name;
    public String log;
    public Date updatedDate;
    public Date assigneeUpdatedDate;
    
    @Override
    public String toString() {
        return "Event [name=" + name + ", id=" + id + ", updatedDate="
                + updatedDate + ", assigneeUpdatedDate=" + assigneeUpdatedDate
                + ", log=" + log + "]";
    }
}
