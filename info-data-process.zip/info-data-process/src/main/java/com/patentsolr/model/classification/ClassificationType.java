package com.patentsolr.model.classification;

public enum ClassificationType {
    IPC, CPC
}
