package com.patentsolr.model;

import java.util.ArrayList;
import java.util.Date;

public class PatentInfo2 {
    
    public String id;
    
    public String pto;

    public String country;

    // date info
    public Date appDate;

    public Date certificateDate;

    public Date decisionDate;

    public Date examDate;

    public Date openDate;

    public Date pctAppDate;

    public Date pctOpenDate;

    // number info
    public String appNumber;

    public String certificateNumber;

    public String decisionNumber;

    public String openNumber;

    public String patentNumber;

    public String pctAppNumber;

    public String pctOpenNumber;

    // patent class
    public String mainCPC;

    public String mainIPC;

    public String mainIPCR;

    public String mainLOC;

    public String mainUSPC;

    public String mainFI;

    public String mainFTerm;

    public String mainDI;

    public String mainDTerm;

    public ArrayList<String> cpcs = new ArrayList<>();

    public ArrayList<String> ipcs = new ArrayList<>();

    public ArrayList<String> ipcrs = new ArrayList<>();

    public ArrayList<String> locs = new ArrayList<>();

    public ArrayList<String> uspcs = new ArrayList<>();

    public ArrayList<String> fis = new ArrayList<>();

    public ArrayList<String> fterms = new ArrayList<>();

    public ArrayList<String> dis = new ArrayList<>();

    public ArrayList<String> dterms = new ArrayList<>();

    public ArrayList<String> eclas = new ArrayList<>();
    
    // person info
    public ArrayList<Person> agents = new ArrayList<>();

    public ArrayList<Person> agentOperators = new ArrayList<>();

    public ArrayList<Person> applicants = new ArrayList<>();

    public ArrayList<Person> assignees = new ArrayList<>();

    public ArrayList<Person> docdbAssignees = new ArrayList<>();

    public ArrayList<Person> docdbaAssignees = new ArrayList<>();

    public ArrayList<Person> docdbAAssignees = new ArrayList<>();

    public ArrayList<Person> inventors = new ArrayList<>();

    public ArrayList<Person> docdbInventors = new ArrayList<>();

    public ArrayList<Person> docdbaInventors = new ArrayList<>();
    
    public ArrayList<Person> docdbAInventors = new ArrayList<>();

    public ArrayList<Person> examinerMasters = new ArrayList<>();

    public ArrayList<Person> examinerSlaves = new ArrayList<>();

    // PDF file page
    public Integer filePageClaim;

    public Integer filePageDesc;

    public Integer filePageFig;

    public Integer filePageFirst;

    public Integer filePageNumber;

    public Integer gazettePageNumber;
    
    public Integer clipPageNumber;
    
    public Integer figurePageNumber;
    
    public boolean firstImagePageFlag = false;
    
    // citation
    public ArrayList<RelatedPatent> citedPatents = new ArrayList<>();

    public ArrayList<String> otherReferences = new ArrayList<String>();

    // priority
    public ArrayList<RelatedPatent> priorityPatents = new ArrayList<>();

    // related
    public ArrayList<RelatedPatent> relatedPatents = new ArrayList<>();

    // division
    public RelatedPatent dividedPatent;

    // document status latest
    public String kindcode;

    public String type;

    public Integer stat;

    public Integer familyId;

    // multiple language latest
    public MultiLangString brief;

    public MultiLangString claim;

    public MultiLangString description;

    public MultiLangString title;

    // outside cache data
    public OutsideData family;

    //public OutsideData strength;

    // extend variables
    public Date doDate;

    public Date docdbDoDate;

    public boolean truncate;

    public MongoSyncFlag mongoSyncFlag;

    @Override
    public String toString() {
        return "PatentInfo2 [id=" + id + ", pto=" + pto + ", country="
                + country + ", appDate=" + appDate + ", certificateDate="
                + certificateDate + ", decisionDate=" + decisionDate
                + ", examDate=" + examDate + ", openDate=" + openDate
                + ", pctAppDate=" + pctAppDate + ", pctOpenDate=" + pctOpenDate
                + ", appNumber=" + appNumber + ", certificateNumber="
                + certificateNumber + ", decisionNumber=" + decisionNumber
                + ", openNumber=" + openNumber + ", patentNumber="
                + patentNumber + ", pctAppNumber=" + pctAppNumber
                + ", pctOpenNumber=" + pctOpenNumber + ", mainCPC=" + mainCPC
                + ", mainIPC=" + mainIPC + ", mainIPCR=" + mainIPCR
                + ", mainLOC=" + mainLOC + ", mainUSPC=" + mainUSPC
                + ", mainFI=" + mainFI + ", mainFTerm=" + mainFTerm
                + ", mainDI=" + mainDI + ", mainDTerm=" + mainDTerm + ", cpcs="
                + cpcs + ", ipcs=" + ipcs + ", ipcrs=" + ipcrs + ", locs="
                + locs + ", uspcs=" + uspcs + ", fis=" + fis + ", fterms="
                + fterms + ", dis=" + dis + ", dterms=" + dterms + ", eclas="
                + eclas + ", agents=" + agents + ", agentOperators="
                + agentOperators + ", applicants=" + applicants
                + ", assignees=" + assignees + ", docdbAssignees="
                + docdbAssignees + ", docdbaAssignees=" + docdbaAssignees
                + ", inventors=" + inventors + ", docdbInventors="
                + docdbInventors + ", docdbaInventors=" + docdbaInventors
                + ", examinerMasters=" + examinerMasters + ", examinerSlaves="
                + examinerSlaves + ", filePageClaim=" + filePageClaim
                + ", filePageDesc=" + filePageDesc + ", filePageFig="
                + filePageFig + ", filePageFirst=" + filePageFirst
                + ", filePageNumber=" + filePageNumber + ", gazettePageNumber="
                + gazettePageNumber + ", clipPageNumber=" + clipPageNumber
                + ", figurePageNumber=" + figurePageNumber
                + ", firstImagePageFlag=" + firstImagePageFlag
                + ", citedPatents=" + citedPatents + ", otherReferences="
                + otherReferences + ", priorityPatents=" + priorityPatents
                + ", relatedPatents=" + relatedPatents + ", dividedPatent="
                + dividedPatent + ", kindcode=" + kindcode + ", type=" + type
                + ", stat=" + stat + ", familyId=" + familyId + ", brief="
                + brief //+ ", claim=" + claim + ", description=" + description
                + ", title=" + title + ", family=" + family + ", doDate="
                + doDate + ", docdbDoDate=" + docdbDoDate + ", truncate="
                + truncate + ", mongoSyncFlag=" + mongoSyncFlag + "]";
    }
}
