package com.patentsolr.model.integration;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Relations {

    @JsonProperty("USPTO")
    public Event uspto;
    
    @JsonProperty("DOCDB")
    public Event docdb;
    
    @JsonProperty("CurrentAssignee")
    public Event currentAssignee;

    @JsonProperty("LitigationLN")
    public Event litigationLN;

    @JsonProperty("LitigationDN")
    public List<Event> litigationDN;
    
    @JsonProperty("cpc")
    public Event cpc;
    
    @JsonProperty("uspc")
    public Event uspc;

    @Override
    public String toString() {
        return "Relations [uspto=" + uspto + ", docdb=" + docdb
                + ", currentAssignee=" + currentAssignee + ", litigationLN="
                + litigationLN + ", litigationDN=" + litigationDN + ", cpc="
                + cpc + ", uspc=" + uspc + "]";
    }
    
}
