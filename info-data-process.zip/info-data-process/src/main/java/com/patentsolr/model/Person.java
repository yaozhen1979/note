package com.patentsolr.model;

public class Person {

    public MultiLangString name;

    public MultiLangString country;

    public MultiLangString address;

    public Integer sequence;

    @Override
    public String toString() {
        return "Person [name=" + name + ", country=" + country + ", address="
                + address + ", sequence=" + sequence + "]";
    } 
}
