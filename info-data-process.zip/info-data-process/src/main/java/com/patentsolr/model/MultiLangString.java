package com.patentsolr.model;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class MultiLangString implements Cloneable {

    protected static Class<?> clazz = MultiLangString.class;
    
    protected static String languages[] = {
        "origin", "en", "zhTW", "zhCN", "jp", "kr", "fr", "de", "ru", "es", "pt", "ar"
    };
    
    public String origin;

    public String en;

    public String zhTW;

    public String zhCN;

    public String jp;

    public String kr;

    public String fr;

    public String de;

    public String ru;

    public String es;

    public String pt;

    public String ar;
    

    public interface LangFilter {
        public String filter(String lang, String value, MultiLangString context);
    }

    public MultiLangString filter(LangFilter langFilter) {
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!StringUtils.isEmpty(value)) {
                    field.set(this, langFilter.filter(lang, value, this));
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return this;
    }

    public int langCount() {
        int cnt = 0;
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!StringUtils.isEmpty(value)) {
                    cnt++;
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return cnt;
    }
    
    public List<String> langs() {
        List<String> langs = new ArrayList<String>();
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!StringUtils.isEmpty(value)) {
                    langs.add(lang);
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return langs;
    }
    
    public List<String> langValues() {
        List<String> langs = new ArrayList<String>();
        for (String lang : languages) {
            try {
                Field field = clazz.getField(lang);
                String value = (String) field.get(this);
                if (!StringUtils.isEmpty(value)) {
                    langs.add(value);
                }
            } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
                throw new InternalError(e.getMessage());
            }
        }
        return langs;
    }

    @Override
    public String toString() {
        return "MultiLangString [origin=" + origin + ", en=" + en + ", zhTW="
                + zhTW + ", zhCN=" + zhCN + ", jp=" + jp + ", kr=" + kr
                + ", fr=" + fr + ", de=" + de + ", ru=" + ru + ", es=" + es
                + ", pt=" + pt + ", ar=" + ar + "]";
    }

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
