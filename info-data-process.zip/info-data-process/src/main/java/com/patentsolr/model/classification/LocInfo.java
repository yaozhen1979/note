package com.patentsolr.model.classification;

public class LocInfo {
    public String clazz;
    public String locNormal;
}
