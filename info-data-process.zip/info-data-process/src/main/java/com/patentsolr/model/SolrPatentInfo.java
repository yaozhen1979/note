package com.patentsolr.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.solr.client.solrj.beans.Field;

public class SolrPatentInfo {

    @Field
    public String ptopid;

    @Field
    public String id;

    @Field
    public String pto;
    
    @Field
    public String patid;

    @Field
    public String country;

    @Field
    public Date appDate;

    @Field
    public Integer appYear;

    @Field
    public Integer appYearmon;

    @Field
    public Date certificateDate;

    @Field
    public Integer certificateYear;

    @Field
    public Integer certificateYearmon;

    @Field
    public Date decisionDate;

    @Field
    public Integer decisionYear;

    @Field
    public Integer decisionYearmon;

    @Field
    public Date examDate;

    @Field
    public Integer examYear;

    @Field
    public Integer examYearmon;

    @Field
    public Date openDate;

    @Field
    public Integer openYear;

    @Field
    public Integer openYearmon;

    @Field
    public Date pctAppDate;

    @Field
    public Integer pctAppYear;

    @Field
    public Integer pctAppYearmon;

    @Field
    public Date pctOpenDate;

    @Field
    public Integer pctOpenYear;

    @Field
    public Integer pctOpenYearmon;

    @Field
    public String appNumber;

    @Field
    public String appNumberGroup;

    @Field
    public ArrayList<String> appNumberAll = new ArrayList<>();

    @Field
    public String certificateNumber;

    @Field
    public ArrayList<String> certificateNumberAll = new ArrayList<>();

    @Field
    public String decisionNumber;

    @Field
    public ArrayList<String> decisionNumberAll = new ArrayList<>();

    @Field
    public String openNumber;

    @Field
    public ArrayList<String> openNumberAll = new ArrayList<>();

    @Field
    public String patentNumber;

    @Field
    public ArrayList<String> patentNumberAll = new ArrayList<>();

    @Field
    public String pctAppNumber;

    @Field
    public ArrayList<String> pctAppNumberAll = new ArrayList<>();

    @Field
    public String pctOpenNumber;

    @Field
    public ArrayList<String> pctOpenNumberAll = new ArrayList<>();

    @Field
    public String mainCPC;

    @Field
    public String mainCPCClass;

    @Field
    public String mainCPCSubClass;

    @Field
    public String mainCPCGroup;

    @Field
    public String mainCPCSubGroup;

    @Field
    public String mainCPCNormal;

    @Field
    public String mainIPC;

    @Field
    public String mainIPCClass;

    @Field
    public String mainIPCSubClass;

    @Field
    public String mainIPCGroup;

    @Field
    public String mainIPCSubGroup;

    @Field
    public String mainIPCNormal;

    @Field
    public String mainIPCR;

    @Field
    public String mainIPCRNormal;

    @Field
    public String mainLOC;

    @Field
    public String mainLOCClass;

    @Field
    public String mainUSPC;

    @Field
    public String mainFI;

    @Field
    public ArrayList<String> mainFIAll = new ArrayList<String>();

    public String mainFIClass;

    @Field
    public String mainFISubClass;

    @Field
    public String mainFIGroup;

    @Field
    public String mainFISubGroup;

    @Field
    public String mainFterm;

    @Field
    public String mainDI;

    @Field
    public String mainDTerm;

    @Field
    public ArrayList<String> cpcs = new ArrayList<>();

    @Field
    public ArrayList<String> cpcsClass = new ArrayList<>();

    @Field
    public ArrayList<String> cpcsSubClass = new ArrayList<>();

    @Field
    public ArrayList<String> cpcsGroup = new ArrayList<>();

    @Field
    public ArrayList<String> cpcsSubGroup = new ArrayList<>();

    @Field
    public ArrayList<String> cpcsNormal = new ArrayList<>();

    @Field
    public ArrayList<String> ipcs = new ArrayList<>();

    @Field
    public ArrayList<String> ipcsClass = new ArrayList<>();

    @Field
    public ArrayList<String> ipcsSubClass = new ArrayList<>();

    @Field
    public ArrayList<String> ipcsGroup = new ArrayList<>();

    @Field
    public ArrayList<String> ipcsSubGroup = new ArrayList<>();

    @Field
    public ArrayList<String> ipcsNormal = new ArrayList<>();

    @Field
    public ArrayList<String> ipcrs = new ArrayList<>();

    @Field
    public ArrayList<String> ipcrsNormal = new ArrayList<>();

    @Field
    public ArrayList<String> locs = new ArrayList<>();

    @Field
    public ArrayList<String> locsClass = new ArrayList<>();

    @Field
    public ArrayList<String> uspcs = new ArrayList<>();

    @Field
    public ArrayList<String> fis = new ArrayList<>();

    @Field
    public ArrayList<String> fisClass = new ArrayList<>();

    @Field
    public ArrayList<String> fisSubClass = new ArrayList<>();

    @Field
    public ArrayList<String> fisGroup = new ArrayList<>();

    @Field
    public ArrayList<String> fisSubGroup = new ArrayList<>();

    @Field
    public ArrayList<String> fisAll = new ArrayList<>();

    @Field
    public ArrayList<String> fterms = new ArrayList<>();

    @Field
    public ArrayList<String> dis = new ArrayList<>();

    @Field
    public ArrayList<String> dterms = new ArrayList<>();

    @Field
    public ArrayList<String> eclas = new ArrayList<>();

    @Field
    public ArrayList<String> agents = new ArrayList<>();

    @Field
    public ArrayList<String> agentsName = new ArrayList<>();

    @Field
    public ArrayList<String> agentsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> agentsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> agentsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperators = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperatorsName = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperatorsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperatorsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> agentOperatorsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> applicants = new ArrayList<>();

    @Field
    public ArrayList<String> applicantsName = new ArrayList<>();

    @Field
    public ArrayList<String> applicantsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> applicantsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> applicantsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> assignees = new ArrayList<>();

    @Field
    public ArrayList<String> assigneesName = new ArrayList<>();

    @Field
    public ArrayList<String> assigneesAddress = new ArrayList<>();

    @Field
    public ArrayList<String> assigneesCountry = new ArrayList<>();

    @Field
    public ArrayList<String> assigneesFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> currentAssigneesName = new ArrayList<>();

    @Field
    public ArrayList<String> currentAssigneesFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> docdbAssignees = new ArrayList<>();

    @Field
    public ArrayList<String> docdbAssigneesName = new ArrayList<>();

    @Field
    public ArrayList<String> docdbAssigneesAddress = new ArrayList<>();

    @Field
    public ArrayList<String> docdbAssigneesCountry = new ArrayList<>();

    @Field
    public ArrayList<String> docdbAssigneesFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaAssignees = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaAssigneesName = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaAssigneesAddress = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaAssigneesCountry = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaAssigneesFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> inventors = new ArrayList<>();

    @Field
    public ArrayList<String> inventorsName = new ArrayList<>();

    @Field
    public ArrayList<String> inventorsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> inventorsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> inventorsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> docdbInventors = new ArrayList<>();

    @Field
    public ArrayList<String> docdbInventorsName = new ArrayList<>();

    @Field
    public ArrayList<String> docdbInventorsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> docdbInventorsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> docdbInventorsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaInventors = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaInventorsName = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaInventorsAddress = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaInventorsCountry = new ArrayList<>();

    @Field
    public ArrayList<String> docdbaInventorsFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMasters = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMastersName = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMastersAddress = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMastersCountry = new ArrayList<>();

    @Field
    public ArrayList<String> examinerMastersFacetname = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlaves = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlavesName = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlavesAddress = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlavesCountry = new ArrayList<>();

    @Field
    public ArrayList<String> examinerSlavesFacetname = new ArrayList<>();

    // image info
    @Field
    public Integer filePageClaim;

    @Field
    public Integer filePageDesc;

    @Field
    public Integer filePageFig;

    @Field
    public Integer filePageFirst;

    @Field
    public Integer filePageNumber;

    @Field
    public Integer gazettePageNumber;

    @Field
    public Integer clipPageNumber;

    @Field
    public Integer figurePageNumber;

    @Field
    public boolean firstImagePageFlag;

    @Field
    public ArrayList<String> otherReferences = new ArrayList<>();

    @Field
    public ArrayList<String> priorityPatents = new ArrayList<>();

    @Field
    public ArrayList<String> priorityPatentsNumberAll = new ArrayList<>();

    @Field
    public ArrayList<String> citedPatents = new ArrayList<>();

    @Field
    public ArrayList<String> citedPatentsNumberAll = new ArrayList<>();

    @Field
    public ArrayList<String> relatedPatents = new ArrayList<>();

    @Field
    public String dividedPatent;

    @Field
    public String kindcode;

    @Field
    public String type;

    @Field
    public Integer typeCode;

    @Field
    public Integer[] stats;

    @Field
    public Integer familyId;

    @Field
    public String familyIdGroup;

    @Field
    public String brief;

    @Field
    public String claim;

    @Field
    public String description;

    @Field
    public String title;

    @Field
    public Date doDate;

    @Field
    public Integer doYear;

    @Field
    public Integer doYearmon;

    @Field
    public Date docdbDoDate;

    @Field
    public Integer docdbDoYear;

    @Field
    public Integer docdbDoYearmon;

    @Field
    public boolean truncate;

    @Field
    public Date solrIndexTime = new Date();

    // project usage
    @Field
    public String projid;

    @Field
    public List<String> treeid;

    @Field
    public List<String> nodeid;

    @Field
    public String patentid;

    @Field
    public List<String> tag;

    // record source from pto or patentcloud
    @Field
    public int source;

    @Field
    public List<String> tagValue;

    @Field
    public Boolean isPcNormal;
    
    @Field
    public Date currentAssigneesUpdateDate;
    
    @Field
    public List<String> assignmentAssignors;
    
    @Field
    public List<String> assignmentAssignees;
    
    @Field
    public List<Date> assignmentAssigneeDates;
    
    @Field
    public int assignmentAssigneeCount;
    
    @Field
    public List<String> assignmentLicensors;
    
    @Field
    public List<String> assignmentLicensees;
    
    @Field
    public List<Date> assignmentLicenseeDates;
    
    @Field
    public int assignmentLicenseeCount;
    
    @Field
    public List<String> assignmentMortgageCreditors;
    
    @Field
    public List<String> assignmentMortgageApplicants;
    
    @Field
    public List<Date> assignmentMortgageApplicantDates;
    
    @Field
    public int assignmentMortgageApplicantCount;
    
    @Field
    public List<String> litigationCaseTypes;
    
    @Field
    public List<String> litigationCaseNumbers;

    @Field
    public List<String> litigationCaseNames;

    @Field
    public List<String> litigationCaseStatus;

    @Field
    public List<String> litigationCounts;

    @Field
    public List<String> litigationPleading;

    @Field
    public List<String> litigationPleadingType;

    @Field
    public List<Date> litigationFilingDates;

    @Field
    public List<String> litigationPlaintiffs;

    @Field
    public List<String> litigationDefendants;

    @Field
    public List<String> litigationPlaintiffFirms;

    @Field
    public List<String> litigationDefendantFirms;

    @Field
    public List<String> litigationPatentValidity;

    @Field
    public List<String> litigationPatentInfringement;

    @Field
    public List<String> litigationContents;

    @Field
    public Integer litigationTotalCount;

    @Override
    public String toString() {
        return "SolrPatentInfo [ptopid=" + ptopid + ", id=" + id + ", pto="
                + pto + ", patid=" + patid + ", country=" + country
                + ", appDate=" + appDate + ", appYear=" + appYear
                + ", appYearmon=" + appYearmon + ", certificateDate="
                + certificateDate + ", certificateYear=" + certificateYear
                + ", certificateYearmon=" + certificateYearmon
                + ", decisionDate=" + decisionDate + ", decisionYear="
                + decisionYear + ", decisionYearmon=" + decisionYearmon
                + ", examDate=" + examDate + ", examYear=" + examYear
                + ", examYearmon=" + examYearmon + ", openDate=" + openDate
                + ", openYear=" + openYear + ", openYearmon=" + openYearmon
                + ", pctAppDate=" + pctAppDate + ", pctAppYear=" + pctAppYear
                + ", pctAppYearmon=" + pctAppYearmon + ", pctOpenDate="
                + pctOpenDate + ", pctOpenYear=" + pctOpenYear
                + ", pctOpenYearmon=" + pctOpenYearmon + ", appNumber="
                + appNumber + ", appNumberGroup=" + appNumberGroup
                + ", appNumberAll=" + appNumberAll + ", certificateNumber="
                + certificateNumber + ", certificateNumberAll="
                + certificateNumberAll + ", decisionNumber=" + decisionNumber
                + ", decisionNumberAll=" + decisionNumberAll + ", openNumber="
                + openNumber + ", openNumberAll=" + openNumberAll
                + ", patentNumber=" + patentNumber + ", patentNumberAll="
                + patentNumberAll + ", pctAppNumber=" + pctAppNumber
                + ", pctAppNumberAll=" + pctAppNumberAll + ", pctOpenNumber="
                + pctOpenNumber + ", pctOpenNumberAll=" + pctOpenNumberAll
                + ", mainCPC=" + mainCPC + ", mainCPCClass=" + mainCPCClass
                + ", mainCPCSubClass=" + mainCPCSubClass + ", mainCPCGroup="
                + mainCPCGroup + ", mainCPCSubGroup=" + mainCPCSubGroup
                + ", mainCPCNormal=" + mainCPCNormal + ", mainIPC=" + mainIPC
                + ", mainIPCClass=" + mainIPCClass + ", mainIPCSubClass="
                + mainIPCSubClass + ", mainIPCGroup=" + mainIPCGroup
                + ", mainIPCSubGroup=" + mainIPCSubGroup + ", mainIPCNormal="
                + mainIPCNormal + ", mainIPCR=" + mainIPCR + ", mainIPCRNormal="
                + mainIPCRNormal + ", mainLOC=" + mainLOC + ", mainLOCClass="
                + mainLOCClass + ", mainUSPC=" + mainUSPC + ", mainFI=" + mainFI
                + ", mainFIAll=" + mainFIAll + ", mainFIClass=" + mainFIClass
                + ", mainFISubClass=" + mainFISubClass + ", mainFIGroup="
                + mainFIGroup + ", mainFISubGroup=" + mainFISubGroup
                + ", mainFterm=" + mainFterm + ", mainDI=" + mainDI
                + ", mainDTerm=" + mainDTerm + ", cpcs=" + cpcs + ", cpcsClass="
                + cpcsClass + ", cpcsSubClass=" + cpcsSubClass + ", cpcsGroup="
                + cpcsGroup + ", cpcsSubGroup=" + cpcsSubGroup + ", cpcsNormal="
                + cpcsNormal + ", ipcs=" + ipcs + ", ipcsClass=" + ipcsClass
                + ", ipcsSubClass=" + ipcsSubClass + ", ipcsGroup=" + ipcsGroup
                + ", ipcsSubGroup=" + ipcsSubGroup + ", ipcsNormal="
                + ipcsNormal + ", ipcrs=" + ipcrs + ", ipcrsNormal="
                + ipcrsNormal + ", locs=" + locs + ", locsClass=" + locsClass
                + ", uspcs=" + uspcs + ", fis=" + fis + ", fisClass=" + fisClass
                + ", fisSubClass=" + fisSubClass + ", fisGroup=" + fisGroup
                + ", fisSubGroup=" + fisSubGroup + ", fisAll=" + fisAll
                + ", fterms=" + fterms + ", dis=" + dis + ", dterms=" + dterms
                + ", eclas=" + eclas + ", agents=" + agents + ", agentsName="
                + agentsName + ", agentsAddress=" + agentsAddress
                + ", agentsCountry=" + agentsCountry + ", agentsFacetname="
                + agentsFacetname + ", agentOperators=" + agentOperators
                + ", agentOperatorsName=" + agentOperatorsName
                + ", agentOperatorsAddress=" + agentOperatorsAddress
                + ", agentOperatorsCountry=" + agentOperatorsCountry
                + ", agentOperatorsFacetname=" + agentOperatorsFacetname
                + ", applicants=" + applicants + ", applicantsName="
                + applicantsName + ", applicantsAddress=" + applicantsAddress
                + ", applicantsCountry=" + applicantsCountry
                + ", applicantsFacetname=" + applicantsFacetname
                + ", assignees=" + assignees + ", assigneesName="
                + assigneesName + ", assigneesAddress=" + assigneesAddress
                + ", assigneesCountry=" + assigneesCountry
                + ", assigneesFacetname=" + assigneesFacetname
                + ", currentAssigneesName=" + currentAssigneesName
                + ", currentAssigneesFacetname=" + currentAssigneesFacetname
                + ", docdbAssignees=" + docdbAssignees + ", docdbAssigneesName="
                + docdbAssigneesName + ", docdbAssigneesAddress="
                + docdbAssigneesAddress + ", docdbAssigneesCountry="
                + docdbAssigneesCountry + ", docdbAssigneesFacetname="
                + docdbAssigneesFacetname + ", docdbaAssignees="
                + docdbaAssignees + ", docdbaAssigneesName="
                + docdbaAssigneesName + ", docdbaAssigneesAddress="
                + docdbaAssigneesAddress + ", docdbaAssigneesCountry="
                + docdbaAssigneesCountry + ", docdbaAssigneesFacetname="
                + docdbaAssigneesFacetname + ", inventors=" + inventors
                + ", inventorsName=" + inventorsName + ", inventorsAddress="
                + inventorsAddress + ", inventorsCountry=" + inventorsCountry
                + ", inventorsFacetname=" + inventorsFacetname
                + ", docdbInventors=" + docdbInventors + ", docdbInventorsName="
                + docdbInventorsName + ", docdbInventorsAddress="
                + docdbInventorsAddress + ", docdbInventorsCountry="
                + docdbInventorsCountry + ", docdbInventorsFacetname="
                + docdbInventorsFacetname + ", docdbaInventors="
                + docdbaInventors + ", docdbaInventorsName="
                + docdbaInventorsName + ", docdbaInventorsAddress="
                + docdbaInventorsAddress + ", docdbaInventorsCountry="
                + docdbaInventorsCountry + ", docdbaInventorsFacetname="
                + docdbaInventorsFacetname + ", examinerMasters="
                + examinerMasters + ", examinerMastersName="
                + examinerMastersName + ", examinerMastersAddress="
                + examinerMastersAddress + ", examinerMastersCountry="
                + examinerMastersCountry + ", examinerMastersFacetname="
                + examinerMastersFacetname + ", examinerSlaves="
                + examinerSlaves + ", examinerSlavesName=" + examinerSlavesName
                + ", examinerSlavesAddress=" + examinerSlavesAddress
                + ", examinerSlavesCountry=" + examinerSlavesCountry
                + ", examinerSlavesFacetname=" + examinerSlavesFacetname
                + ", filePageClaim=" + filePageClaim + ", filePageDesc="
                + filePageDesc + ", filePageFig=" + filePageFig
                + ", filePageFirst=" + filePageFirst + ", filePageNumber="
                + filePageNumber + ", gazettePageNumber=" + gazettePageNumber
                + ", clipPageNumber=" + clipPageNumber + ", figurePageNumber="
                + figurePageNumber + ", firstImagePageFlag="
                + firstImagePageFlag + ", otherReferences=" + otherReferences
                + ", priorityPatents=" + priorityPatents
                + ", priorityPatentsNumberAll=" + priorityPatentsNumberAll
                + ", citedPatents=" + citedPatents + ", citedPatentsNumberAll="
                + citedPatentsNumberAll + ", relatedPatents=" + relatedPatents
                + ", dividedPatent=" + dividedPatent + ", kindcode=" + kindcode
                + ", type=" + type + ", typeCode=" + typeCode + ", stats="
                + Arrays.toString(stats) + ", familyId=" + familyId
                + ", familyIdGroup=" + familyIdGroup + ", brief=" + brief
                + ", claim=" + claim + ", description=" + description
                + ", title=" + title + ", doDate=" + doDate + ", doYear="
                + doYear + ", doYearmon=" + doYearmon + ", docdbDoDate="
                + docdbDoDate + ", docdbDoYear=" + docdbDoYear
                + ", docdbDoYearmon=" + docdbDoYearmon + ", truncate="
                + truncate + ", solrIndexTime=" + solrIndexTime + ", projid="
                + projid + ", treeid=" + treeid + ", nodeid=" + nodeid
                + ", patentid=" + patentid + ", tag=" + tag + ", source="
                + source + ", tagValue=" + tagValue + ", isPcNormal="
                + isPcNormal + ", currentAssigneesUpdateDate="
                + currentAssigneesUpdateDate + ", assignmentAssignors="
                + assignmentAssignors + ", assignmentAssignees="
                + assignmentAssignees + ", assignmentAssigneeDates="
                + assignmentAssigneeDates + ", assignmentAssigneeCount="
                + assignmentAssigneeCount + ", assignmentLicensors="
                + assignmentLicensors + ", assignmentLicensees="
                + assignmentLicensees + ", assignmentLicenseeDates="
                + assignmentLicenseeDates + ", assignmentLicenseeCount="
                + assignmentLicenseeCount + ", assignmentMortgageCreditors="
                + assignmentMortgageCreditors
                + ", assignmentMortgageApplicants="
                + assignmentMortgageApplicants
                + ", assignmentMortgageApplicantDates="
                + assignmentMortgageApplicantDates
                + ", assignmentMortgageApplicantCount="
                + assignmentMortgageApplicantCount + ", litigationCaseTypes="
                + litigationCaseTypes + ", litigationCaseNumbers="
                + litigationCaseNumbers + ", litigationCaseNames="
                + litigationCaseNames + ", litigationCaseStatus="
                + litigationCaseStatus + ", litigationCounts="
                + litigationCounts + ", litigationPleading="
                + litigationPleading + ", litigationPleadingType="
                + litigationPleadingType + ", litigationFilingDates="
                + litigationFilingDates + ", litigationPlaintiffs="
                + litigationPlaintiffs + ", litigationDefendants="
                + litigationDefendants + ", litigationPlaintiffFirms="
                + litigationPlaintiffFirms + ", litigationDefendantFirms="
                + litigationDefendantFirms + ", litigationPatentValidity="
                + litigationPatentValidity + ", litigationPatentInfringement="
                + litigationPatentInfringement + ", litigationContents="
                + litigationContents + ", litigationTotalCount="
                + litigationTotalCount + "]";
    }

    

}
