package com.patentsolr.model.classification;

import java.util.ArrayList;


public class FiInfo extends IpcInfo{
    public String fiNormal;
    public ArrayList<String> fiAll;
}
