package com.patentsolr.model;

import java.util.Date;

public class MongoSyncFlag {

    public Date init;

    public Date last;
    
    public Date update;

    @Override
    public String toString() {
        return "MongoSyncFlag [init=" + init + ", last=" + last + ", update="
                + update + "]";
    }

}
