package com.patentsolr.litigation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class CourtAbbrFinder {

    private static Map<String, String> courtAbbrMap = new HashMap<String, String>();
    
    public static void load() throws Exception {
        
        if (courtAbbrMap.size() > 0) {
            return;
        }
        
        Class.forName("net.sourceforge.jtds.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:jtds:sqlserver://10.60.90.47:1433/PatentCloudDev", "sa", "itec.sql.123");
        
        ResultSet rs = conn.createStatement().executeQuery("select * from CourtAbbr");
        
        while (rs.next()) {
            courtAbbrMap.put(rs.getString("code"), rs.getString("en"));
        }
    }
    
    public static String getCourtName(String abbr) {
        return courtAbbrMap.get(abbr);
    }
}
