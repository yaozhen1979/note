package com.patentsolr.litigation;

import java.util.ArrayList;
import java.util.List;

public class Party {

    public String name;
    public List<String> roles = new ArrayList<String>();
    public List<Firm> firms = new ArrayList<Firm>();
    
}
