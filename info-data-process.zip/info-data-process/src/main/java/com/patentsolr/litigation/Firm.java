package com.patentsolr.litigation;

import java.util.ArrayList;
import java.util.List;

public class Firm {

    public String name;
    public List<String> attorneyNames = new ArrayList<String>();
    
}
