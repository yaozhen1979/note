package com.patentsolr.litigation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DocketCase {

    public String id;
    
    public String court;
    public String caseStatus;
    public String caseName;
    public String courtAbbr;
    public String caseNumber;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date caseFilingDate;
    
    public String patentValidityInvaild;
    public String patentValidityNotInvaild;
    public String patentInfringementInvaild;
    public String patentInfringementNotInvaild;
    
    public List<String> pleadings = new ArrayList<String>();
    public List<String> remedys = new ArrayList<String>();
    public List<String> patents = new ArrayList<String>();
    public List<Party> parties = new ArrayList<Party>();
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    public Date lastUpdated;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    public Date importDate;
    
    @Override
    public String toString() {
        return "DocketCase [id=" + id + ", court=" + court + ", caseStatus="
                + caseStatus + ", caseName=" + caseName + ", courtAbbr="
                + courtAbbr + ", caseNumber=" + caseNumber + ", caseFilingDate="
                + caseFilingDate + ", patentValidityInvaild="
                + patentValidityInvaild + ", patentValidityNotInvaild="
                + patentValidityNotInvaild + ", patentInfringementInvaild="
                + patentInfringementInvaild + ", patentInfringementNotInvaild="
                + patentInfringementNotInvaild + ", pleadings=" + pleadings
                + ", remedys=" + remedys + ", patents=" + patents + ", parties="
                + parties + ", lastUpdated=" + lastUpdated + ", importDate="
                + importDate + "]";
    }
}
