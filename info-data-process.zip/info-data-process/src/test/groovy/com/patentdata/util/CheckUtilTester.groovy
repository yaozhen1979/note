package com.patentdata.util

//import org.junit.Test
import org.junit.Test;

import spock.lang.Specification

class CheckUtilTester extends Specification {
    
    
    def "test checkDocNoWO "(){
        expect:
            assert CheckUtil.checkDocNoWO('2011/067944')
            
            assert !CheckUtil.checkDocNoWO('2200/067944')
    }
    
    def "test checkPatIdWO"() {
        expect:
            assert CheckUtil.checkPatIdWO("WO1996002947-A1-19960201")
            
            assert !CheckUtil.checkPatIdWO("WO1996002947-A1-1996001")
            assert !CheckUtil.checkPatIdWO("WO2996002947-A1-19960201")
            assert !CheckUtil.checkPatIdWO('WO1996002947-A1-22000201')            
    }

    
    def "test checkAppIdWO "(){
        expect:
            assert CheckUtil.checkAppIdWO('WOPCTDE1994000832')
            
            assert !CheckUtil.checkAppIdWO('WOPTDE1994000832')
    }
    
    
    def "test checkAppNoWO"(){
        expect:
            assert CheckUtil.checkAppNoWO("PCT/DE1994/000832")
            
            assert !CheckUtil.checkAppNoWO("PCT/DE2994/000832")
    }
    
}
