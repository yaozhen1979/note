package com.patentdata.util;

import static org.junit.Assert.assertEquals

import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Ignore

public class PatNumberUtilTester {
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void testGetFormalPatId() throws Exception{
        assertEquals(PatNumberUtil.getFormalPatId(['country':'WO', 'doc-number':'1999065801', 'date':'20001031', 'kind':'A1']), 'WO1999065801-A1-20001031')
    }
    
    /**
     * NOTE By Tony: 測試資料是WO, 但PatNumberUtil中找不到該method ???
     * 
     * @throws Exception
     */
    @Test
    public void testGetDocNoByPatId() throws Exception{
        assertEquals( PatNumberUtil.getDocNoByPatId( PatNumberUtil.getFormalPatId('WO1999065801-A1-20001031')), '1999/065801')
    }
    
    @Test
    public void testGetPatIdDOCDB() throws Exception {
        String result = PatNumberUtil.getPatIdDOCDB("AP", "123-45", "T", "20150126");
        assertEquals("AP12345T20150126", result);
    }
    
    @Test
    public void testGetAppId() {
        String result = PatNumberUtil.getAppIdDOCDB("123-45");
        assertEquals("12345", result);
    }

    @Test
    public void testGetPatIdWO(){
        String kindcode = "A1";
        String doDate = "19960201";
        assertEquals( PatNumberUtil.getPatIdWO("15/000001", kindcode, doDate), "WO2015000001-A1-19960201");
        assertEquals( PatNumberUtil.getPatIdWO("2015/000001", kindcode, doDate), "WO2015000001-A1-19960201");
        assertEquals( PatNumberUtil.getPatIdWO("2015000001", kindcode, doDate), "WO2015000001-A1-19960201");
        assertEquals( PatNumberUtil.getPatIdWO("1500001", kindcode, doDate), "WO2015000001-A1-19960201");
    }
    
    @Test
    public void testGetAppIdWO(){
        assertEquals( PatNumberUtil.getAppIdWO("SE1998/000800"), "WOPCTSE1998000800");
        assertEquals( PatNumberUtil.getAppIdWO("EP1996003803"), "WOPCTEP1996003803");
        assertEquals( PatNumberUtil.getAppIdWO("US78000044"), "WOPCTUS1978000044");
        assertEquals( PatNumberUtil.getAppIdWO("BR8700004"), "WOPCTBR1987000004");
        assertEquals( PatNumberUtil.getAppIdWO("US82/712"), "WOPCTUS1982000712");
        assertEquals( PatNumberUtil.getAppIdWO("DE80/81"), "WOPCTDE1980000081");
        assertEquals( PatNumberUtil.getAppIdWO("78SE 7800022"), "WOPCTSE1978000022");
        
        // other cases
        assertEquals( PatNumberUtil.getAppIdWO("ffddddf"), "WO");
        
    }

    @Test
    void testGetDocNoWo(){
        assertEquals( PatNumberUtil.getDocNoWo('9819933'), '1998/019933')
        assertEquals( PatNumberUtil.getDocNoWo('03059581'), '2003/059581')        
        
        assertEquals( PatNumberUtil.getDocNoWo('2004105531'), '2004/105531')        
        assertEquals( PatNumberUtil.getDocNoWo('200410553'), '2004/010553')
        
        assertEquals( PatNumberUtil.getDocNoWo('WO 00/6792'), '2000/006792')
        assertEquals( PatNumberUtil.getDocNoWo('WO 02/24140'), '2002/024140')
        assertEquals( PatNumberUtil.getDocNoWo('WO 02/055923'), '2002/055923')
        assertEquals( PatNumberUtil.getDocNoWo('WO98/20466'), '1998/020466')
        assertEquals( PatNumberUtil.getDocNoWo('WO02/053867'), '2002/053867')
        assertEquals( PatNumberUtil.getDocNoWo('WO2004/060984'), '2004/060984')
        assertEquals( PatNumberUtil.getDocNoWo('WO 2004/062426'), '2004/062426')
        assertEquals( PatNumberUtil.getDocNoWo('WO-90/06775'), '1990/006775')
        assertEquals( PatNumberUtil.getDocNoWo('WO/02/088519'), '2002/088519')
        assertEquals( PatNumberUtil.getDocNoWo('WO 01-17806'), '2001/017806')
        assertEquals( PatNumberUtil.getDocNoWo('WO2004.113721'), '2004/113721')
        
        assertEquals( PatNumberUtil.getDocNoWo('98 09770'), '1998/009770')
        assertEquals( PatNumberUtil.getDocNoWo('2007/090112'), '2007/090112')
        assertEquals( PatNumberUtil.getDocNoWo('98/35584'), '1998/035584')
        
        assertEquals( PatNumberUtil.getDocNoWo('PCT/US98/091078'), '1998/091078')
        assertEquals( PatNumberUtil.getDocNoWo('PCT/US98/09178'), '1998/009178')
        assertEquals( PatNumberUtil.getDocNoWo('PCT/F199/00865'), '1999/000865')
        
        assertEquals( PatNumberUtil.getDocNoWo('WO 2006/086 910'), '2006/086910')
        
    }
    
    @Test
    void testGetDocNoByPatIdWO(){
        assertEquals( PatNumberUtil.getDocNoByPatIdWO("WO1996002947-A1-19960201"), "1996/002947")
    }
    
    // getAppIdUS
    @Test
    public void testGetAppIdUSByDocdbData() {
        //
        String rawAppNo = "13813173";
        assertEquals(PatNumberUtil.getAppIdUS(rawAppNo), "");
    }
    
    @Test
    public void testGetAppNoUSByDocdbData() {
        //
        String rawAppNo = "13813173";
        assertEquals(PatNumberUtil.getAppNoUS(rawAppNo), "");
    }
    
    @Test
    public void testGetPatIdUSByDocdbData() {
        //
        String docNo = "9192065";
        assertEquals(PatNumberUtil.getPatIdUS(2, docNo), "");
    }

    @Test
    public void testGetAppNoTW(){
        assertEquals( PatNumberUtil.getAppNoTW("2005-115044", "JP"), "094115044");
    }

    @Test
    public void testGetAppNoEP(){
        assertEquals( PatNumberUtil.getAppNoEP("2006-114558", "JP"), "06114558.7");
        assertEquals( PatNumberUtil.getAppNoEP("06114558.7", "JP"), "06114558.7");
        assertEquals( PatNumberUtil.getAppNoEP("06114558:7", "JP"), "06114558.7");
        assertEquals( PatNumberUtil.getAppNoEP("06114558-7", "JP"), "06114558.7");
        assertEquals( PatNumberUtil.getAppNoEP("01 302 841.0", "JP"), "01302841.0");
    }

    @Test
    public void testGetAppNoWO(){
        assertEquals( PatNumberUtil.getAppNoWO("PCT-US1997-011670"), "PCT/US1997/011670");
    }
    
    @Test
    public void testFormatDocNoByCountry() {
        
        PatNumberUtil.formatDocNoByCountry("12345", "CN", "CN1234567")
        
        assert "" == PatNumberUtil.formatDocNoByCountry("12345", "CN")
        
    }
    
}
