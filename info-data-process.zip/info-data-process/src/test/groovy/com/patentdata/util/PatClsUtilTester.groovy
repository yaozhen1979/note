package com.patentdata.util

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

class PatClsUtilTester {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testFormatClsCpcIPC() throws Exception {
        
        String result = PatClsUtil.formatClsCpcIPC("A", "01", "H", "5", "10");
        // A01H 5/10
        assertEquals("A01H 05/10", result);
    }
    
    @Test
    public void testFormatClsUspc() throws Exception {
        
        // 623  146
        // X427  224
        String result = PatClsUtil.formatClsUspc("623  146");
        // A01H 5/10
        assertEquals("A01H 05/10", result);
    }
    
    @Test
    public void testFormatDocdbIpc() throws Exception {
        
        // B 01D 11/04 A
        // 1B 22D
        // String result = PatClsUtil.formatDocdbIpc("B 01D 11/04 A");
        
        // E 21D
        String result = PatClsUtil.formatDocdbIpc("D 04B    12/12     A");
        
        assertEquals("A01H 05/10", result);
    }
    
}
