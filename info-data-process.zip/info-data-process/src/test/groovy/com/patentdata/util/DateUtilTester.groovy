package com.patentdata.util;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.patentdata.util.DateUtil;

public class DateUtilTester {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testParseDate() {
        assert new Date() == DateUtil.parseDate("1911-10-10")
    }
    
    @Test
    public void testParseDateErrorFormat1() {
        
        assert new Date() == DateUtil.parseDate("19940900")
    }

}
