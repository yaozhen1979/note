package com.patentdata.helper;

import static org.junit.Assert.*;

import com.patentdata.model.PersonData
import org.junit.Test;

public class PersonDataHelperTester {

    @Test
    public void testFindByPersonId() {
        
        PersonData personData = PersonDataHelper.findByPersonId("de898c00-cafe-4f22-8fd9-9525ac44c7ab")
        
        println personData.personId
        println personData.personType
        println personData.personFacet
        
    }

}
