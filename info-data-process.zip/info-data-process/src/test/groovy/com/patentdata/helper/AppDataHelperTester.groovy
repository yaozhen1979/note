package com.patentdata.helper;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentdata.helper.AppDataHelper;
import com.patentdata.model.AppData
import com.patentdata.util.DateUtil;

public class AppDataHelperTester {
    
    Logger logger = LoggerFactory.getLogger(AppDataHelperTester.class);
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void testFindByAppIdForNullData() {
        AppData appData = AppDataHelper.findByAppId("XXXXXXXXXXXXXXXXX", "AT");
        assert appData == null
    }
    
    @Test
    public void testFindByAppId() {
        AppData appData = AppDataHelper.findByAppId('AT20000000296U', "AT");
        assert appData.appId == "AT20000000296U"
    }

    @Test
    public void testQueryByCondition() {
        
        String country = "DE";
        String appNo = "DE2001103150";
        Date appDate = DateUtil.parseDate("2001-01-24");
        
        int count = AppDataHelper.queryByCondition(country, appNo, appDate).size();
        
        assert 2 == count
        // assertEquals(2, count);
    }

}
