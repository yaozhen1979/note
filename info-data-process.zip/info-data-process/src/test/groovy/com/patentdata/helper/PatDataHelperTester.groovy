package com.patentdata.helper;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentdata.model.PatData;

public class PatDataHelperTester {
    
    Logger logger = LoggerFactory.getLogger(PatDataHelperTester.class);
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
    @Ignore
    @Test
    public void testFindByPatIdForNullData() {
        PatData patData = PatDataHelper.findByPatId("XXXXXXXXXXXXXXXXX");
        assert patData == null
    }
    
    @Ignore
    @Test
    public void testFindByPatId() {
        PatData patData = PatDataHelper.findByPatId("US0000D500417");
        assert patData.patId == "US0000D500417"
    }
    
    @Ignore
    @Test
    public void testHQL() {
        
        // sess.createSQLQuery("SELECT * FROM CATS").addEntity(Cat.class);
        
        logger.info("" + PatDataHelper.queryByCondition("US00D747841"));
        
        // println PatDataHelper.queryAll(PatData.class);
        // println PatDataHelper.count(PatData.class)
        // System.out.println(PatDataHelper.count("US20160021809"));
    }
    
    @Ignore
    @Test
    public void testNativeSQL() {
        
        // sess.createSQLQuery("SELECT * FROM CATS").addEntity(Cat.class);
        
        logger.info("" + PatDataHelper.queryNativeSQLByCondition("US00D747841"));
        
        // println PatDataHelper.queryAll(PatData.class);
        // println PatDataHelper.count(PatData.class)
        // System.out.println(PatDataHelper.count("US20160021809"));
    }
    
    @Test
    public void testNativeQueryByCountry() {
        
        String country = "BR"
        String fileName = "bak/${country}_doc_date_list.txt"
        if (new File(fileName).delete()) {
            println "delete file ${fileName} complete."
        }
        
        File file = new File(fileName);
        
        def queryList = PatDataHelper.nativeQueryByCountry(country);
        logger.info("" + queryList);
        
        queryList.each { it ->
            file << "docDateList << [\"${it[0]}\", ${it[1]}];" << "\r\n"
        }
        
        assert 1 == queryList.size();
    }
    
    @Ignore
    @Test
    public void testQueryByDocDate() {
        
        List queryList = PatDataHelper.queryByDocDate("2015-12-31", "AP");
        int size = queryList.size()
        
        assert 110 == size;
    }

}
