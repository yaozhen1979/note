package com.patentdata.helper;

import static org.junit.Assert.*;

import com.patentdata.model.PatPersonApplicant
import org.junit.Test;

public class PatPersonApplicantHelperTester {

    @Test
    public void testQueryByPatId() {
        
        List dataList = PatPersonApplicantHelper.nativeQueryByPatId('DE10056507-A1-20020529')
                
        // println dataList[0][0]  // pat_id ???
        
        assert 5 == dataList.size();
    }

}
