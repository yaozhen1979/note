package com.patentdata.helper;

import static org.junit.Assert.*;

import org.junit.Test;

public class PatDataTitleHelperTester {

    @Test
    public void testQueryByPatId() {
        
        List dataList = PatDataTitleHelper.nativeQueryByPatId('DE10056507-A1-20020529')
                
        println dataList[0][3]  // title
        println dataList[0][2]  // lang
        
        assert 5 == dataList.size();
    }

}
