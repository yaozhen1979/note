package com.patentdata.process;

import org.slf4j.LoggerFactory

import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.helper.PatDataHelper
import com.patentdata.model.PatClsIpc
import com.patentdata.model.PatClsIpcId
import com.patentdata.model.PatData
import com.patentdata.process.BaseProcess
import com.patentdata.service.PatClsService
import com.patentdata.util.DateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatClsUtil
import com.patentdata.util.PatNumberUtil

/**
 * @author mikelin
 *
 */
public class IpcRevocer extends BaseProcess {

    public IpcRevocer() {
        logger = LoggerFactory.getLogger(IpcRevocer.class);
    }

    
    /**
     * 資料查詢
     * @return
     * @throws Exception
     */
    @Override
    DBCursor queryData() throws Exception {

        println "queryMap : $queryMap"
        def client = MongoUtil.connectByConfig("US");
        // marshall
        def marshallCol = client.getDB("PatentMarshallUS").getCollection("PatentMarshallUS")

        DBCursor cursor = marshallCol.find(queryMap).sort([doDate:1]).limit(0).skip(0).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        return cursor;
    }



    @Override
    void processData(DBObject doc) throws Exception {

        Date now = new Date();
        
        def patId = PatNumberUtil.getPatIdUS(doc.stat, doc._id);

        def root = getRoot(doc);

        def biblio = getBiblio(doc.stat, root);

        def patData = PatDataHelper.findByPatId(patId);

        PatClsService clsSvc = new PatClsService();
        // ipc
        List<PatClsIpc> patClsIpcList = genPatClsIpcXML(biblio, patData, now);
        clsSvc.saveOrUpdatePatClsIpc(patClsIpcList);
    }

    /**
     * @param doc
     * @return
     */
    private Map getRoot(def doc) {

        def root = null;
        if (doc.stat == Constants.PAT_STAT_PUBLIC) {
            root = doc.data."us-patent-application";
        } else {
            root = doc.data."us-patent-grant";
        }

        return root;
    }

    /**
     * @param stat
     * @param root
     * @return
     */
    private Map getBiblio(int stat, def root) {

        def biblio = null;
        if (stat == Constants.PAT_STAT_PUBLIC) {
            biblio = root."us-bibliographic-data-application";
        } else {
            biblio = root."us-bibliographic-data-grant";
        }

        return biblio;
    }
    
    /**
     *
     * @param biblio
     * @param patData
     * @param now
     */
    public static List<PatClsIpc> genPatClsIpcXML(def biblio, PatData patData, Date now) {

        List<PatClsIpc> ipcList = new ArrayList<PatClsIpc>();

        // classification-ipc
        if (!!biblio."classification-ipc") {

            String ipcOriPattern = /([A-Z])([0-9]{2})([A-Z])\s*([0-9]{0,4})?\/?([0-9]{1,6})/;

            // 項次
            int item = Constants.ZERO;
            // IPC或IPCR,依據tag判斷,1:ipc,2:ipcr
            int ipcType = Constants.CLS_TYPE_IPC;

            // main ipc
            if (!!biblio."classification-ipc"."main-classification") {

                item++;
                String ipcStr = biblio."classification-ipc"."main-classification";
                String ipcText = null;
                //
                if (ipcStr.contains("/")) {
                    // ex : C12P017/00, C 07D 4 9/02
                    ipcText = ipcStr.replaceAll("\\s", "");
                    ipcText.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                        ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                    }
                } else {
                    // ex : B60J  700
                    ipcStr.replaceAll(/([A-Z])([0-9]{2})([A-Z])(\s*)([0-9]+)/) {full, section, classStr, subClass, space, groups->
                        ipcText = section + classStr + subClass + " " + groups[0..3-space.length()-1] + "/" + groups[3-space.length()..-1]
                    }
                    
                }
                if (!PatClsUtil.validUSOriIpc(ipcText)) {
                    throw new Exception("main ipc origin format error, patId = $patData.patId");
                }

                PatClsIpc patClsIpc = new PatClsIpc();
                patClsIpc.ipcText = ipcText;
                patClsIpc.clsVersion = biblio."classification-ipc"?."edition";
                // IPCR 不用判斷是否為Main ipc 固定為否
                patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_YES;
                patClsIpc.createDate = now;

                // PatClsIpcId
                PatClsIpcId id = new PatClsIpcId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;
                id.ipcType = ipcType;
                patClsIpc.id = id;

                ipcList.add(patClsIpc);

            } // endf of if main ipc

            // futher ipc (list)
            if (!!biblio."classification-ipc"."further-classification") {

                biblio."classification-ipc"."further-classification".each {futherIpc ->

                    item++;
                    String ipcStr = futherIpc."value";
                    String ipcText = null;
                    //
                    if (ipcStr.contains("/")) {
                        // ex : C12P017/00, C 07D 4 9/02
                        ipcText = ipcStr.replaceAll("\\s", "");
                        ipcText.replaceAll(ipcOriPattern) {full, section, classStr, subClass, mainGroup, subGroup ->
                            ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);
                        }
                    } else {
                        // ex : B60J  700
                        ipcStr.replaceAll(/([A-Z])([0-9]{2})([A-Z])(\s*)([0-9]+)/) {full, section, classStr, subClass, space, groups->
                            ipcText = section + classStr + subClass + " " + groups[0..3-space.length()-1] + "/" + groups[3-space.length()..-1]
                        }
                        
                    }
                    
                    //
                    PatClsIpc patClsIpc = new PatClsIpc();
                    patClsIpc.ipcText = ipcText;
                    // IPCR 不用判斷是否為Main ipc 固定為否
                    patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_NO;
                    patClsIpc.createDate = now;

                    // PatClsIpcId
                    PatClsIpcId id = new PatClsIpcId();
                    id.patId = patData.patId;
                    id.sourceId = patData.defaultSourceId;
                    id.item = item;
                    id.ipcType = ipcType;
                    patClsIpc.id = id;

                    ipcList.add(patClsIpc);

                } // end of loop futher ipc

            } // end of if futher ipc

        }
        // classifications-ipcr
        if (!!biblio."classifications-ipcr" && !!biblio."classifications-ipcr"."classification-ipcr") {

            biblio."classifications-ipcr"."classification-ipcr".eachWithIndex {ipcData, index ->

                // 項次
                int item = index + 1;
                // IPC或IPCR,依據tag判斷,1:ipc,2:ipcr
                int ipcType = Constants.CLS_TYPE_IPCR;

                String section = ipcData."section";
                String classStr = ipcData."class";
                String subClass = ipcData."subclass";
                String mainGroup = ipcData."main-group";
                String subGroup = ipcData."subgroup";

                String ipcText = PatClsUtil.formatClsCpcIPC(section, classStr, subClass, mainGroup, subGroup);

                PatClsIpc patClsIpc = new PatClsIpc();
                patClsIpc.ipcText = ipcText;
                patClsIpc.symbolPosition = ipcData."symbol-position";
                patClsIpc.clsVersion = ipcData."ipc-version-indicator"."date";
                patClsIpc.clsLevel = ipcData."classification-level";
                patClsIpc.clsValue = ipcData."classification-value";
                patClsIpc.actionDate = DateUtil.parseDate(ipcData."action-date"."date");
                patClsIpc.genOffice = ipcData."generating-office"."country";
                patClsIpc.clsStatus = ipcData."classification-status";
                patClsIpc.clsDataSource = ipcData."classification-data-source";
                // IPCR 不用判斷是否為Main ipc 固定為否
                patClsIpc.rawMainFlag = Constants.CLS_IPC_MAIN_FLAG_NO;
                patClsIpc.createDate = now;

                // PatClsIpcId
                PatClsIpcId id = new PatClsIpcId();
                id.patId = patData.patId;
                id.sourceId = patData.defaultSourceId;
                id.item = item;
                id.ipcType = ipcType;
                patClsIpc.id = id;

                ipcList.add(patClsIpc);
            }
        } // classifications-ipcr

        return ipcList;
    }

    /**
     *
     * @param data
     * @param message 錯誤訊息
     * @throws Exception
     */
    @Override
    void processFailData(DBObject data, String message) throws Exception {

        logger.info("Ipc Revocer error : " + message);
        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "import new info error", "message : " + message);
    }

    public static void main(String[] args) throws Exception {

        // 測試使用
//        args = ["-b", "20061201", "-e", "20070101"];

        def cli = new CliBuilder(usage: 'IpcRevocer.groovy -[hbe]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;

        def dateBegin = DateUtil.parseDate(beginDate);
        def dateEnd = DateUtil.parseDate(endDate);

        def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];

//        def query = ['_id' : "H2113"];

        new IpcRevocer().queryMap(query).process();

        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "IpcRevocer finished", "$beginDate - $endDate");

        logger.info("finished...");
    }

}