package com.patentdata.process

import spock.lang.Specification

class JPOPatDataProcessTester extends Specification {
    def "format fi at applicaton patent of wips"() {
        expect:
        JPOPatDataProcess.genWipsApplicationFiFormated(fi) == [fullFiText, ipcText, subDivisionSymbol, fileDiscriminationSymbol]

        where:
        fi                                || fullFiText         | ipcText      | subDivisionSymbol | fileDiscriminationSymbol
        "F02D-035/00     H "              || "F02D 35/00 H"     | "F02D 35/00" | ""                | "H"
        "F02D-035/00     H"               || "F02D 35/00 H"     | "F02D 35/00" | ""                | "H"
        "F02D-035/00   304 "              || "F02D 35/00 304"   | "F02D 35/00" | "304"             | ""
        "F02D-035/00   304"               || "F02D 35/00 304"   | "F02D 35/00" | "304"             | ""
        "F02D-035/00   304 H "            || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "F02D-035/00   304 H"             || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "F02D-035/00   H 304 "            || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "F02D-035/00   H 304"             || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "F02D-035/00   304H "             || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "F02D-035/00   304H"              || "F02D 35/00 304 H" | "F02D 35/00" | "304"             | "H"
        "C07J-009/00   7180-4C   "        || "C07J 9/00"        | "C07J 9/00"  | ""                | ""
        "G01N-030/26      L   8506-2J   " || "G01N 30/26 L"     | "G01N 30/26" | ""                | "L"
        "G01N-030:26      L   8506-2J   " || "G01N 30/26 L"     | "G01N 30/26" | ""                | "L"
      }

    def "format ipc at applicaton patent of wips"() {
        expect:
        JPOPatDataProcess.genWipsApplicationIpcFormated(ipc) == ipcNormal
    
        where:
        ipc                               || ipcNormal
        "F02D-035/00     H "              || "F02D 35/00"
        "F02D-35/00     H"                || "F02D 35/00"
        "F02D-5/00   304 "                || "F02D 5/00"
        "F02D-5/1   304 "                 || "F02D 5/01"
        "F02D-035/1   304 "               || "F02D 35/01"
        "F02D-305/11   304 "              || "F02D 305/11"
    }
}
