package com.patentdata.process

import org.hibernate.Query
import org.hibernate.Session
import org.hibernate.Transaction

import com.patentdata.helper.PatDataHelper
import com.patentdata.util.HibernateUtil
import com.patentdata.util.PatNumberUtil

public class USFlagUpdateFromText {

    public static void main(String[] args) {
        
        String fileName = "D:\\note\\uspto\\withdrawn05032016.txt";
//        String fileName = "D:\\note\\uspto\\sec05132016.txt";
//        String fileName = "D:\\note\\uspto\\reex05132016.txt";
//        String fileName = "D:\\note\\uspto\\ptab05132016.txt";
        
        File file = new File(fileName);
        
        List<String> patIdList = new ArrayList<>();
        
        file.eachLine {
            patIdList <<  PatNumberUtil.getPatIdUS(2, PatNumberUtil.formatDocNoByCountry(it.trim(), "US", null, null, null));
        }
        
        int updateCnt = 0;
        int foundCnt = 0;
        List patDataList = null;
        String hql = null;
        String flagName = null;
        Session session = HibernateUtil.newSession();
        Transaction tx = session.beginTransaction();
        
        for (int i=0; i<patIdList.size(); i++) {
            if (i > 0 && i%500 == 0) {
                println "process $i/38974";
            }
            String patId = patIdList[i];
            String cc = patId.substring(0, 2);
            patDataList = PatDataHelper.queryNativeSQLByCondition(patId);
            if (!patDataList || patDataList.size() == 0) {
                continue;
            } else if (patDataList.size() == 1) {
                updateCnt++;
                foundCnt++;
                if (file.name.contains("withdrawn")) {
                    flagName = "withdraw_flag";
                } else if (file.name.contains("ptab")) {
                    flagName = "ptab_flag";
                } else if (file.name.contains("sec")) {
                    flagName = "sec_flag";
                } else if (file.name.contains("reex")) {
                    flagName = "reex_flag";
                }
                
//                hql = "update pat_data set " + flagName + "= :flag where substr(pat_id, 1, 2) = :cc and pat_id= :patId"
                hql = "update part.pat_data_us set " + flagName + "= :flag where pat_id= :patId"
                
                println "patId$i: $patId ,hql :$hql"
                
                Query updateQuery = session.createSQLQuery(hql);
//                updateQuery.setString("cc", cc);
                updateQuery.setString("patId", patId);
                updateQuery.setInteger("flag", 1);
                int updateCount = updateQuery.executeUpdate();
                
                if (updateCnt > 0 && updateCnt%500 == 0) {
                    tx.commit();
                    session.flush();
                    session.close();
                    session = HibernateUtil.newSession();
                    tx = session.beginTransaction();
                }
                
//                break;
            } else {
                throw new Exception("patId $patId over than 1 PatData");
            }
            
        }
        
        tx.commit();
        session.flush();
        session.close();
        HibernateUtil.closeSession();
        
        println "foundCnt : $foundCnt";
    }
    
}
