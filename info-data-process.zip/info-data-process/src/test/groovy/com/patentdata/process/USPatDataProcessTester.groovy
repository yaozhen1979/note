/**
 * 
 */
package com.patentdata.process

import static org.junit.Assert.*

import org.junit.Test

import spock.lang.Ignore
import spock.lang.Specification

import com.patentdata.common.CommonEnum
import com.patentdata.process.impl.USPatDataProcessXmlImpl


/**
 * @author mikelin
 *
 */
class USPatDataProcessXMLTester extends Specification {

    @Ignore
    def "test ipcr"() {
        when:
            def query = ['_id' : "9237737"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "case includes ipc(main,futher), priority-claims"() {
        when:
            def query = ['_id' : "6901624"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test loc"() {
        when:
            def query = ['_id' : "D505825"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test uspc futher Utility"() {
        when:
            def query = ['_id' : "6901609"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test uspc futher Design"() {
        when:
            def query = ['_id' : "D749816"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test references-cited citation patcit and nplcit"() {
        when:
            def query = ['_id' : "D505772"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "case cset,us-references-cited citation patcit and nplcit"() {
        when:
            def query = ['_id' : "9249021"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "case includes pct, us-references-cited nplcit priority-claims"() {
        when:
            def query = ['_id' : "9192065"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test correspondence-address"() {
        when:
            def query = ['_id' : "20100212058"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test us-field-of-classification-search and main-classification none"() {
        when:
            def query = ['_id' : "9192078"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
           println "finished..."
    }
    
    @Ignore
    def "test seq list"() {
        when:
            def query = ['_id' : "20150327522"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test ield-of-search classification-ipc"() {
        when:
            def query = ['_id' : "6901719"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test us-field-of-classification-search us-classifications-ipcr"() {
        when:
            def query = ['_id' : "9265231"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "case includes us-term-of-grant length-of-grant"() {
        when:
            def query = ['_id' : "D749817"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "case include continuation (parent-doc child-doc), us-provisional-application"() {
        when:
            def query = ['_id' : "20150352689"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    
    @Ignore
    def "case includes continuation parent-status, continuation-in-part, us-provisional-application,related-publication"() {
        when:
            def query = ['_id' : "20160055525"];
        then:
            new USPatDataProcessXmlImpl().queryMap(query).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test Cited By Type Code" () {
        
        expect:
            CommonEnum.CITEDBYTYPE.findCitedByTypeCode(citedByTypeDesc) == citedByTypeCode
        
        where:
            citedByTypeDesc         || citedByTypeCode
            "cited by examiner"     || 2
            "cited by applicant"    || 1
        
    }
}
