package com.patentdata.process

import static org.junit.Assert.*

import org.bson.Document

import spock.lang.Ignore
import spock.lang.Specification

import com.patentdata.helper.PersonDataHelper


public class WOPatDataProcessTester extends Specification{
    @Ignore
    def "test query a data"() {
        String docId = "1996002947A1/19960201/WPA"
        Map query = ["docId": docId]
        String resultDocId = new WOPatDataProcess().queryMap(query).queryData().next()['docId']

        expect:
        resultDocId == docId
    }
    
    @Ignore
    def "test format IPC"() {
        
        expect:
        WOPatDataProcess.formatIpc(ipc) == ipcNormal
        
        where:
            ipc                 || ipcNormal
            "H 01L 31/048"      || 'H01L 31/048'
            "H 04L"             || 'H04L /00'
            "C 07D211/42"       || 'C07D 211/42'
            "C 12Q   1/68"      || 'C12Q 1/68'
    }
    
    

    @Ignore
    def "test WPA case with ipcr"(){
        String docId = '2011067864A1/20110609/WPA'

        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA case with OPA fulltext"(){
        String docId = '2011068654A1/20110609/WPA'
        //  corresponding full text docId: 2011068654A1/20110609/OPA
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }


    @Ignore
    def "test WPA case with WAB fulltext"(){
        String docId = '2011067944A1/20110609/WPA'
        //  corresponding full text docId: 2011067944A1/20110609/WAB
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA case multiple agent addressbook"(){
        String docId = '2011025332A3/20110609/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA case with inventors"(){
        String docId = '2011042210A3/20110609/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA case with ipc main-classification"(){
        String docId = '1996019705A1/19960627/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    


    @Ignore
    def "test Korean facet query"(){
        String personFacet = "김기영대전광역시유성구도룡동3862대덕테크비즈센터301호305340daejeon305340kr"

        expect:
        println personFacet
        println PersonDataHelper.findExistsPersonDataByPersonFacet(personFacet, 'KR', new ArrayList()).personId;
    }

    @Ignore
    def "test English facet query"(){
        String personFacet = "kimkiyoungdaedeoktechbizcenter3013862doryongdongyuseonggudaejeon305340nullnull305340kr"

        expect:
        println personFacet
        println PersonDataHelper.findExistsPersonDataByPersonFacet(personFacet, "kr", new ArrayList()).personId;
    }

    @Ignore
    def "test WPA case with WAB fulltext fail case1 "(){
        String docId = '2011067816A1/20110609/WPA'
        //  corresponding full text docId: 2011067944A1/20110609/WAB
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA fail case - N/A country in applicant"(){
        String docId = '1996002947A1/19960201/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test WPA case - agent reptype length > 20 "(){
        String docId = '2004065443A2/20040805/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    //////////////////////////
    /** LNP Testing Region **/    
    
    @Ignore
    def "test LNP case with clsIpc & ecla"(){
        String docId = '1985002188A1/19850523/LNP'

        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }


    @Ignore
    def "test LNP case with agents, applicants, inventors"(){
        String docId = '1991007646A3/19910530/LNP'

        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP inventor addressbook w/o address case"(){
        String docId = '1978000002A2/19781207/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }


    @Ignore
    def "test LNP case processing"(){
        String docId = '1978000015A1/19781221/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test LNP with patcit and nplcit reference case processing"(){
        String docId = '1979000326A1/19790614/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test LNP with related dacument - related-publication"(){
        String docId = '2009012867A2/20090129/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test LNP with related dacument - continuation"(){
        String docId = '2008047204A2/20080424/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    def "test LNP case - Ipc format error "(){
        String docId = '1979000116A1/19790308/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }

    @Ignore
    // TODO not repair
    def "test LNP case - missing application reference "(){
        String docId = '1987005927A3/19880324/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
        
        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP case - citation kindcode null convert to null"(){
        String docId = '1993010743A2/19930610/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP case - agent w/o person - foreign key deleted"(){
        String docId = '2005008893A1/20050127/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
        
        expect:
        println 'done'
    }
    
    
    @Ignore
    // TODO
    def "test LNP case - cited data query over 1"(){
        String docId = '1997039038A1/19971023/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP case - not found in 121"(){
        String docId = '1985005264A2/19851205/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP case - null on ipcr[13]-subgroup"(){
        String docId = '1979001052A1/19791213/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    
    
    @Ignore
    def "test LNP case - testing "(){
        String docId = '1985004289A2/19850926/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()

        expect:
        println 'done'
    }
    
    /** LNP Testing Region **/
    //////////////////////////

////    @Ignore
//    def "test LNP batch case processing"(){
//        String xmltypeAbb = 'LNP'
//        Map query = ["xmltypeAbb": xmltypeAbb]
//        int factor = 100
//
//        int startUnit = 32
//        int limit = 500
//        int max = 2400000/(limit*factor)
//        int skipstep = limit * factor
//
//
//        WOPatDataProcess woPatDataProcess = new WOPatDataProcess()
//        woPatDataProcess.limitNumber = limit
//
//        for(int i : startUnit..max){
//            woPatDataProcess.logger.error('LNP testing region: ' +  i*skipstep + '-' + (i*skipstep + limit))
//            woPatDataProcess.skipNumber = i*skipstep
//            woPatDataProcess.queryMap(query).process()
//        }
//
//
//        expect:
//        println 'done'
//    }

    //////////////////////////
    /////// WPA Testing //////
    @Ignore
    // TODO
    def "test WPA case - applicant postcode is string"(){
        String docId = '2011146646A1/20111124/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
//    @Ignore
    def "test WPA case - testing"(){
        String docId = '2014120969A1/20140807/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'testing case done'
    }

    
//    @Ignore
//    def "test WPA batch case processing"(){
//        String xmltypeAbb = 'WPA'
//        Map query = ["xmltypeAbb": xmltypeAbb]
//        int factor = 100
//
//        int limit = 500
//        int max = 1000000/(limit*factor)
//        int skipstep = limit * factor
//
//
//        WOPatDataProcess woPatDataProcess = new WOPatDataProcess()
//        woPatDataProcess.limitNumber = limit
//
//        for(int i : 0..max){
//            woPatDataProcess.logger.error('WPA testing region: ' +  i*skipstep + '-' + (i*skipstep + limit))
//            //            println 'WPA testing region: ' +  i*skipstep + '-' + (i*skipstep + limit)
//            woPatDataProcess.skipNumber = i*skipstep
//            woPatDataProcess.queryMap(query).process()
//        }
//
//
//        expect:
//        println 'done'
//    }

    @Ignore
    def "test error log data - batch"(){
        FileReader logReader = new FileReader('./logs/ErrorId/20160418.txt')
        
        for(String line : logReader.readLines()){
            String docId = line
            Map query = ["docId": docId]
            new WOPatDataProcess().queryMap(query).process()
        }
        
        expect:
        println 'done'
    }
    
    
    
    
    
    ////////////////////////////////
    @Ignore
    def "test WPA error - error figure number"(){
        String docId = '2015175638A1/20151119/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }

    @Ignore
    def "test WPA error - error person create date"(){
        String docId = '1997009311A1/19970313/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    @Ignore
    def "test WPA error - cancel main-ipc == none"(){
        String docId = '2006040763A2/20060420/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    @Ignore
    def "test priority claim error - start from 1"(){
        String docId = '2011065567A1/20110603/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    
    @Ignore
    def "test WPA with firstImageFlag & filePageNumber"(){
        String docId = '2013151330A1/20131010/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    @Ignore
    def "test WPA with error create date"(){
        String docId = '1997009311A1/19970313/WPA'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    @Ignore
    def "test LNP with multipli priority claim"(){
        String docId = '1997039038A1/19971023/LNP'
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    @Ignore
    def "test WPA missing input case"(){
        String docId = '2015197860A2/20151230/WPA'
        
        Map query = ["docId": docId]
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    

//    @Ignore
    def "manually modification process 20160426"(){
        
        Map query = new Document([ "docId": [$in:
        [
            // add application reference
            '2004078228B1/20051013/LNP',
            '2001009665A3/20010208/LNP',
            '2001003042B1/20010308/LNP',
            '1993020020A3/19931125/LNP',
            '1991015349A3/19911128/LNP',
            '1991009096A3/19910725/LNP',
            '1991006059A3/19910530/LNP',
            '1991002447A3/19910418/LNP',
            '1990004323A3/19900628/LNP',
            '1989010372A3/19891116/LNP',
            '1989003863A3/19890601/LNP',
            '1988010444A3/19890223/LNP',
            '1988010224A3/19890126/LNP',
            '1988006886A3/19890112/LNP',
            '1988006615A3/19881006/LNP',
            '1988004951A3/19880825/LNP',
            '1988004313A3/19880714/LNP',
            '1988003553A3/19880811/LNP',
            '1988002763A3/19880505/LNP',
            '1988002691A3/19880728/LNP',
            '1988002690A3/19880728/LNP',
            '1988002089A3/19880407/LNP',
            '1988001138A3/19880421/LNP',
            '1988000950A3/19880324/LNP',
            '1988000611A3/19880324/LNP',
            '1988000603A3/19880324/LNP',
            '1988000200A3/19880421/LNP',
            '1987005927A3/19880324/LNP',
            '1987003613A3/19870911/LNP',
            '1987000032A3/19870312/LNP',
            '1986006756A3/19861218/LNP',
            '1985004289A3/19851024/LNP',
            '1984003188A3/19840816/LNP',
            '1981003327A2/19811126/LNP',
            // ipc modification
            '2014120969A1/20140807/WPA',
            // kind code modification
            '1985005264A1/19851205/LNP',
            '1985004289A1/19850926/LNP',
            '1985003838A2/19850812/LNP',
            // date error
            '2007109735A3/20070927/LNP',
            '2008082726A3/20080710/LNP',
            '2001051353A1/20010719/LNP',
            '2007120563A3/20071025/LNP',
            '1996033173A2/19961024/LNP',
            '1983004188A1/19831208/LNP',
            '1993004728A1/19930318/LNP',
            '1993014278A1/19930722/LNP',
            '1999011647A1/19990311/LNP',
            '1998036037A1/19980820/LNP',
            '2007030902A3/20070322/LNP',
            '1998029384A1/19980709/LNP',
            '1987006338A1/19871022/LNP',
        ]
    ]])
    
        new WOPatDataProcess().queryMap(query).process()
    
        expect:
        println 'done'
    }
    
    
    
    @Ignore
    def "test batch processing"(){
        String xmltypeAbb = 'LNP'
        Map query = ["xmltypeAbb": xmltypeAbb]

        WOPatDataProcess woPatDataProcess = new WOPatDataProcess()
//        woPatDataProcess.skipNumber = 0
//        woPatDataProcess.skipNumber = 680000
        woPatDataProcess.skipNumber = 940000
//        680000, 260000
//        940000, 260000
        woPatDataProcess.limitNumber = 260000
//        woPatDataProcess.limitNumber = 520000
//        woPatDataProcess.limitNumber = 10000000000
        
        woPatDataProcess.queryMap(query).process()
        
        expect:
        println 'done'
    }
    
}