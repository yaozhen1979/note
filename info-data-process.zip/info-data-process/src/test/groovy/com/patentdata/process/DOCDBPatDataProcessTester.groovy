package com.patentdata.process

import spock.lang.Specification;
import spock.lang.Ignore

class DOCDBPatDataProcessTester extends Specification {
    
    @Ignore
    def "test genPersonFacet"() {
        setup:
            DOCDBPatDataProcess docdbPatDataProcess = new DOCDBPatDataProcess();
        when:
            String applicantName = "Tony Kuo";
            String address = "";
            String country = "TW";
        then:
            String personFacet = docdbPatDataProcess.genPersonFacet(applicantName, address, country)
        expect:
            personFacet == "" ;
    }
    
    @Ignore
    def "run priority-claims data"() {
        when:
            def queryMap = [_id: "DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513406", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run references-cited data for patcit"() {
        when:
            def queryMap = [_id: "DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513404", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run references-cited data for nplcit"() {
        when:
            def queryMap = [_id: "DOCDB-201548-Amend-PubDate20151120AndBefore-AP-0001.xml/381755310", country: "AP"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run CSet data By DOCDB-201511-004-DE-0001.xml/384998907"() {
        when:
            def queryMap = [_id: "DOCDB-201511-004-DE-0001.xml/384998907", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run CSet data By DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513608"() {
        when:
            def queryMap = [_id: "DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513608", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data have ipc and ipcr"() {
        when:
            def queryMap = [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-AP-0001.xml/381753675", country: "AP"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    def "run test data have multi lang de, en"() {
        when:
            def queryMap = [query: [_id: "DOCDB-201550-Amend-PubDate20151204AndBefore-DE-0002.xml/289726483"], country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data scheme = 'CPC'"() {
        when:
            def queryMap = [_id: "DOCDB-201511-001-AU-0103.xml/338369650", country: "AU"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    /**
     * 
     * 但是address的資料是在data-format="docdba", 所以還是沒資料...
     * 
     * @return
     */
    @Ignore
    def "run test data inventor data have address"() {
        when:
            def queryMap = [_id: "DOCDB-201516-Amend-PubDate20150410AndBefore-DE-0003.xml/314389878", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data ipc, further ipc, have edition - EP"() {
        when:
            def queryMap = [_id: "DOCDB-201511-006-EP-0001.xml/311822029", country: "EP"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data ipc, further ipc, have edition - DE"() {
        when:
            def queryMap = [_id: "DOCDB-201550-Amend-PubDate20151204AndBefore-DE-0003.xml/386601327", country: "DE"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data ipc, further ipc, have no edition - AU"() {
        when:
            def queryMap = [_id: "DOCDB-201550-Amend-PubDate20151204AndBefore-AU-0001.xml/382850391", country: "AU"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    /*
     * IPCR字串拆解方式:
     * (1)僅提供版本資訊 => G01P 15/00 (2006.01) => ??? CN ??? => docdb 無此資料
     */
    
    /**
     * (2)有提供MainGroup與SubGroup的詳細資訊:字串中存在[/] => ??? DOCDB-201511-006-EP-0001.xml/311822029
     * @return
     */
    @Ignore
    def "run test data ipc, 有提供MainGroup與SubGroup的詳細資訊:字串中存在[/]"() {
        when:
            def queryMap = [_id: "DOCDB-201511-006-EP-0001.xml/311822029", country: "EP"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    /**
     * (3)未提供MainGroup與SubGroup的詳細資訊:字串中不存在[/] => ??? DOCDB-201604-CreateDelete-PubDate20160122AndBefore-HK-0001.xml/448475007/C
     * @return
     */
    @Ignore
    def "run test data ipc, 未提供MainGroup與SubGroup的詳細資訊:字串中不存在[/]"() {
        when:
            def queryMap = [_id: "DOCDB-201604-CreateDelete-PubDate20160122AndBefore-HK-0001.xml/448475007/C", country: "HK"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    /**
     * US Marshall data id = '9192065'
     * 
     * @return
     */
    @Ignore
    def "run test data us data"() {
        when:
            def queryMap = [_id: "DOCDB-201548-CreateDelete-PubDate20151120AndBefore-US-0002.xml/446168139", country: "US"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run test data us data have uspc and cset"() {
        when:
            def queryMap = [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-US-0020.xml/284709175", country: "US"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run AP test data ipc data, ipc only have text, no ipc.main-classification"() {
        when:
            def queryMap = [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-AP-0001.xml/381756204", country: "AP"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run NZ test data ipc data, ipc only have text, no ipc.main-classification"() {
        when:
            def queryMap = [country: "NZ", query: [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-NZ-0001.xml/402426740", country: "NZ"]]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run SV test data ipc data, pat_data中doc_data為null..."() {
        when:
            def queryMap = [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-SI-0001.xml/404046993", country: "SI"]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run JP test data linked-indexing-code-group..."() {
        when:
            def queryMap = [country: "JP", query: [_id: "DOCDB-201504-Amend-PubDate20150116AndBefore-JP-0001.xml/299686711"]]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    @Ignore
    def "run AT test data, pat_type = -99"() {
        when:
            def queryMap = [country: "AT", query: [_id: "DOCDB-201501-Amend-PubDate20141226AndBefore-AT-0001.xml/381904051"]]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap).process();
        expect:
            println "finished..."
    }
    
    def "run AT test last_flag data"() {
        when:
            def queryMap1 = [country: "AP", query: [_id: "DOCDB-201511-001-AP-0001.xml/381754030"]]
            def queryMap2 = [country: "AP", query: [_id: "DOCDB-201546-Amend-PubDate20151106AndBefore-AP-0001.xml/381754030"]]
            def queryMap3 = [country: "AP", query: [_id: "DOCDB-201547-Amend-PubDate20151113AndBefore-AP-0001.xml/381754030"]]
        then:
            new DOCDBPatDataProcess().queryMap(queryMap1).process();
            new DOCDBPatDataProcess().queryMap(queryMap3).process();
            new DOCDBPatDataProcess().queryMap(queryMap2).process();
            
        expect:
            println "finished..."
    }
    
    @Ignore
    def "test something..."() {
        setup:
            ""
        when:
            ""
        then:
            ""
        expect:
            ""
    }
    
}
