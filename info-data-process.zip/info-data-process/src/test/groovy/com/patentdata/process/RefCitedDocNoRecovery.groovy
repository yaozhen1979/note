package com.patentdata.process


import org.hibernate.FlushMode
import org.hibernate.Session
import org.hibernate.Transaction
import org.slf4j.LoggerFactory

import ch.qos.logback.classic.Logger

import com.gmongo.GMongoClient
import com.mongodb.DB
import com.mongodb.DBCollection
import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.common.CommonEnum.COUNTRY
import com.patentdata.helper.PatDataHelper
import com.patentdata.helper.PatRefCitedHelper
import com.patentdata.model.PatData
import com.patentdata.model.PatRefCited
import com.patentdata.service.PatRefService
import com.patentdata.util.DateUtil
import com.patentdata.util.HibernateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.RestTimeProcess
import com.patentdata.util.StringUtil

class RefCitedDocNoRecovery {
    Logger log = LoggerFactory.getLogger(RefCitedDocNoRecovery.class.name)

    public enum MARSHALL {

        NO_DEFINED(Constants.TYPE_NO_DEFINED_NAME, Constants.TYPE_NO_DEFINED_NAME),
        US("PatentMarshallUS", "US"),
        EP("PatentMarshallEPO", "EP"),
        CN("PatentMarshallCN", "CN"),
        JP("PatentMarshallJPO", "JP"),
        WO("PatentMarshallWO", "WO"),
        DOCDB("PatentMarshallDOCDB", "DOCDB"),
        TW("PatentMarshallTW", "TW");

        private final String colName;
        private final String countryName;
        private String getColName() {
            return colName;
        }

        private String getCountryName() {
            return countryName;
        }

        private MARSHALL(String colName, String countryName) {
            this.colName = colName;
            this.countryName = countryName;
        }

        public static String getCollectionName(String cc) {
            if (cc == null || cc == "") {
                return NO_DEFINED.colName;
            }
            for (MARSHALL country : MARSHALL.values()) {
                if (country.getCountryName().equals(cc)) {
                    return country.getColName();
                }
            }
        }
    }

    private List<Date> distinctDoDate(String beginDateString, String endDateString, String country) {
        GMongoClient mongoClient = MongoUtil.connectByConfig(country);
        DB marDB = mongoClient.getDB(MARSHALL.getCollectionName(country));
        DBCollection marCol = marDB.getCollection(MARSHALL.getCollectionName(country));
        Date beginDate, endDate;
        beginDate = DateUtil.parseDate(beginDateString);
        endDate = DateUtil.parseDate(endDateString);

        List<Date> doDateList = marCol.distinct("doDate", ["doDate":['$gte':beginDate,'$lt':endDate]]);

        return doDateList;
    }

    private process(String beginDateString, String endDateString, String country) {
        GMongoClient client = MongoUtil.connectByConfig(COUNTRY.EP.getCountryName());
        DB infoDB = client.getDB("PatentInfoEPO");
        DBCollection statusCol = infoDB.getCollection('RecoveryStatus');
        //        Transaction tx;
        RestTimeProcess rtp;
        Map docMap;
        int total = 0;
        List<PatRefCited> formatDocNoList = new ArrayList<PatRefCited>();
        List<Date> dateList = distinctDoDate(beginDateString, endDateString, country);
        Object[] patData;
        try {
            PatRefService prs = new PatRefService();
            for (int i = 0; i < dateList.size(); i++) {
                Date date = dateList[i];
                docMap = [:];
                int index = 0;
                DBObject statDoc = statusCol.findOne([_id : country + "-" + DateUtil.toISODate(date, "yyyy-MM-dd"), status : 1]);
                if (!!statDoc) {
                    // continue
                    continue;
                }

                docMap << [_id : country + "-" + DateUtil.toISODate(date, "yyyy-MM-dd"), status : -1, createdDate : new Date(), recovery:[[tableName:"pat_ref_cited", columnName:"doc_no"]]];
                statusCol.save(docMap);

                List<Object> patDataList = PatDataHelper.nativeQueryByDocDate(date.format('yyyyMMdd'), country);

                rtp = new RestTimeProcess(patDataList.size(), RefCitedDocNoRecovery.class.name);
                total += patDataList.size();

                Iterator<Object> patDataIterator = patDataList.iterator();
                Session session = HibernateUtil.newSession();
                try {
                    while (patDataIterator.hasNext()) {
                        patData = (Object[]) patDataIterator.next();
                        List<PatRefCited> citedSet = PatRefCitedHelper.findByCondition(patData[0].toString(), patData[1].toString());
                        formatDocNoList.clear();
                        String rawDocNo, countryForPrint;
                        try {
                            if (index == 0) {
                                docMap << [status : 0];
                                statusCol.save(docMap);
                            }
                            if (citedSet == null || citedSet.size() == 0) {
                                rtp.process();
                                continue;
                                //                            return false;
                            }
                            for (int k = 0; k < citedSet.size(); k++) {
                                String formatDocNo = PatNumberUtil.formatDocNoByCountry(citedSet[k].rawDocNo, citedSet[k].country, null, citedSet[k].kindCode, DateUtil.parseDate(citedSet[k].rawDocDate));
                                citedSet[k].docNo = formatDocNo;
                                formatDocNoList.add(citedSet[k]);
                            }
                            //tx = session.beginTransaction();
                            prs.updateRefData(formatDocNoList, session);
                            //tx.commit();
                            session.flush();
                            
                        } catch (e) {
                            log.error(e.toString() + '\t' + patData[0].toString() + '\t' + rawDocNo);
                            docMap << [status:2];
                            statusCol.save(docMap);
                            //                        try {
                            //                            tx.rollback();
                            //                        } catch (Throwable T) {}
                            throw new Exception(patData[0].toString() + '\t' + countryForPrint + '\t' +  rawDocNo + ", error : " + e);
                        }
                        ++index;
                        rtp.process();
                    }
                } catch(e) {
                    throw e;
                } finally {
                    session.close();
                }
                docMap << [status:1, total:patDataList.size()];
                statusCol.save(docMap);
                log.info("doc date: " + date.format("yyyyMMdd") + "total: " + patDataList.size() + " complete");
            }
            MailUtil.sendToPatentCloud("ericxiao@patentcloud.com", "cited doc no process success", "begin date: ${beginDateString}, end date: ${endDateString} count: " + total + " complete");
        } catch (e) {
            MailUtil.sendToPatentCloud("ericxiao@patentcloud.com", "error", StringUtil.stack2string(e));
            println StringUtil.stack2string(e);
        } finally {
            HibernateUtil.closeSession();
        }
    }

    static main(args) {
        String beginDateString, endDateString, country;
//                args = ["-b", "20060425", "-e", "20060426", "-c", "us"]
        def cli = new CliBuilder(usage: 'RefCitedDocNoRecovery.groovy -[hbec]');

        cli.with {
            h longOpt: 'help',                                     'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyyMMdd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyyMMdd', 'End doDate'
            c longOpt: 'country', args: 1, argName: 'Country', "US"
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        if (!!options.b) {
            beginDateString = options.b;
            endDateString = options.e;
        }

        if (!!options.c) {
            country = options.c.toUpperCase();
        } else {
            throw new Exception("please enter country");
        }
        new RefCitedDocNoRecovery().process(beginDateString, endDateString, country);
    }
}
