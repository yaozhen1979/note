package com.patentdata.process

import org.slf4j.LoggerFactory

import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.patentdata.common.Constants
import com.patentdata.helper.PatDataHelper
import com.patentdata.model.PatRefPct
import com.patentdata.service.PatRefService
import com.patentdata.util.DateUtil
import com.patentdata.util.MailUtil
import com.patentdata.util.MongoUtil
import com.patentdata.util.PatNumberUtil
import com.patentdata.util.USPatDataUtil

class PctNumberRecover extends BaseProcess {

    public PctNumberRecover() {
        logger = LoggerFactory.getLogger(IpcRevocer.class);
    }

    @Override
    DBCursor queryData() throws Exception {
        println "queryMap : $queryMap"
        def client = MongoUtil.connectByConfig("US");
        // marshall
        def marshallCol = client.getDB("PatentMarshallUS").getCollection("PatentMarshallUS")

        DBCursor cursor = marshallCol.find(queryMap).sort([doDate:1]).limit(0).skip(0).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        return cursor;
    }

    @Override
    void processData(DBObject doc) throws Exception {
        
        Date now = new Date();
        
        def patId = PatNumberUtil.getPatIdUS(doc.stat, doc._id);

        def root = getRoot(doc);

        def biblio = getBiblio(doc.stat, root);

        def patData = PatDataHelper.findByPatId(patId);
        
        // pct pct-or-regional-filing-data, pct-or-regional-publishing-data
        PatRefPct patRefPct = USPatDataUtil.genPatRefPctDataXML(biblio, patData, now);
        if (!!patRefPct) {
            PatRefService patRefService = new PatRefService();
            patRefService.savePatRefPct(patRefPct);
        }

    }
    
    /**
     * @param doc
     * @return
     */
    private Map getRoot(def doc) {

        def root = null;
        if (doc.stat == Constants.PAT_STAT_PUBLIC) {
            root = doc.data."us-patent-application";
        } else {
            root = doc.data."us-patent-grant";
        }

        return root;
    }

    /**
     * @param stat
     * @param root
     * @return
     */
    private Map getBiblio(int stat, def root) {

        def biblio = null;
        if (stat == Constants.PAT_STAT_PUBLIC) {
            biblio = root."us-bibliographic-data-application";
        } else {
            biblio = root."us-bibliographic-data-grant";
        }

        return biblio;
    }

    @Override
    void processFailData(DBObject data, String message) throws Exception {
        // TODO Auto-generated method stub

    }

    public static void main(String[] args) throws Exception {

        // 測試使用
//        args = ["-b", "20061201", "-e", "20070101"];

        def cli = new CliBuilder(usage: 'IpcRevocer.groovy -[hbe]');
        // Create the list of options.
        cli.with {
            h longOpt: 'help',                                       'Show usage information'
            b longOpt: 'begin-date', args: 1, argName: 'yyyy/MM/dd', 'Begin doDate'
            e longOpt: 'end-date',   args: 1, argName: 'yyyy/MM/dd', 'End doDate'
        }

        def options = cli.parse(args);
        if (!options) {
            return;
        }
        if (options.h) {
            cli.usage();
            return;
        }

        def beginDate = options.b;
        def endDate = options.e;

        def dateBegin = DateUtil.parseDate(beginDate);
        def dateEnd = DateUtil.parseDate(endDate);

        def query = ['doDate' : ['$gte' : dateBegin, '$lt' : dateEnd]];

//        def query = ['_id' : "6836924"];

        new PctNumberRecover().queryMap(query).process();

        MailUtil.sendToPatentCloud("mikelin@patentcloud.com", "PctNumberRecover finished", "$beginDate - $endDate");

        logger.info("finished...");
    }

}
