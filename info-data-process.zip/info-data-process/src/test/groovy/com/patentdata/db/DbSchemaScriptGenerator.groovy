package com.patentdata.db

/**
 * 依輸入的table_name, 來產生相關的partition_table script
 * 
 * @author tonykuo
 *
 */
class DbSchemaScriptGenerator {
    
    private final static String PARTITION_TABLE_SCHEMA = "part";
    
    // pat_ptopid_mapping_template
    def static String pat_ptopid_mapping_template(def country) {
        
        def tableName = "pat_ptopid_mapping"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  ptopid_mapping_id integer NOT NULL DEFAULT nextval('seq_ptopid_mapping_id'::regclass),
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (ptopid_mapping_id),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    // pat_raw_docdb_template
    def static String pat_raw_docdb_template(def country) {
        
        def tableName = "pat_raw_docdb"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  raw_id character varying NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (raw_id),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_ref_pct_template
     */
    def static String pat_ref_pct_template(def country) {
        
        def tableName = "pat_ref_pct"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_ref_priority_template
     */
    def static String pat_ref_priority_template(def country) {
        
        def tableName = "pat_ref_priority"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_ref_cited_npl_template
     */
    def static String pat_ref_cited_npl_template(def country) {
        
        def tableName = "pat_ref_cited_npl"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_ref_cited_template
     */
    def static String pat_ref_cited_template(def country) {
        
        def tableName = "pat_ref_cited"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_person_inventor_template
     */
    def static String pat_person_inventor_template(def country) {
        
        def tableName = "pat_person_inventor"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_person_assignee_template
     */
    def static String pat_person_assignee_template(def country) {
        
        def tableName = "pat_person_assignee"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_person_applicant_template
     */
    def static String pat_person_applicant_template(def country) {
        
        def tableName = "pat_person_applicant"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_person_agent_template
     */
    def static String pat_person_agent_template(def country) {
        
        def tableName = "pat_person_agent"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_data_desc_template
     */
    def static String pat_data_desc_template(def country) {
        
        def tableName = "pat_data_desc"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, lang),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_data_claims_template
     */
    def static String pat_data_claims_template(def country) {
        
        def tableName = "pat_data_claims"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, lang),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_data_brief_template
     */
    def static String pat_data_brief_template(def country) {
        
        def tableName = "pat_data_brief"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, lang),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * pat_data_template
     */
    def static String pat_data_template(def country) {
        
        def tableName = "pat_data"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * table pat_cls_cset_template
     */
    def static String pat_cls_cset_template(def country) {
        
        def tableName = "pat_cls_cset"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  group_no integer NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, group_no, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * table pat_cls_cpc
     * 
     * @param country
     * @return
     */
    def static String pat_cls_cpc_template(def country) {
        
        def tableName = "pat_cls_cpc"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  item integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * TABLE pat_data_title
     * 
     * @param country
     * @return
     */
    def static String pat_data_title_template(def country) {
        
        def tableName = "pat_data_title"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  lang character(5) NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, lang),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * TABLE pat_cls_ipc
     * 
     * @param country
     * @return
     */
    def static String pat_cls_ipc_template(def country) {
        
        def tableName = "pat_cls_ipc"
        
        def partition_table_script = '''DROP TABLE IF EXISTS ${schema}.${tableName}_${cc};

create table ${schema}.${tableName}_${cc} (
  pat_id character varying(50) NOT NULL,
  source_id character varying(50) NOT NULL,
  ipc_type integer NOT NULL,
  CONSTRAINT ${tableName}_${cc}_pkey PRIMARY KEY (pat_id, source_id, ipc_type, item),
  ${checkCondition}
) inherits (${tableName});
        '''
        
        return generateScript(tableName, country, partition_table_script);
    }
    
    /**
     * 
     * 
     * @param tableName
     * @return
     */
    def static String generate_trigger_script(def tableName) {
        
        def checkCondition;
        if (tableName.toLowerCase() == "app_data") {
            checkCondition = "NEW.country"
        } else {
            checkCondition = "substr(NEW.pat_id, 1, 2)"
        }
        
        def partition_trigger_script = '''
CREATE OR REPLACE FUNCTION ${table_name}_insert_trigger()
RETURNS TRIGGER AS \\$\\$
BEGIN
  IF ( ${checkCondition} = 'US' ) THEN
    INSERT INTO ${schema}.${table_name}_us VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'WO' ) THEN
    INSERT INTO ${schema}.${table_name}_wo VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'JP' ) THEN
    INSERT INTO ${schema}.${table_name}_jp VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'CN' ) THEN
    INSERT INTO ${schema}.${table_name}_cn VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'EP' ) THEN
    INSERT INTO ${schema}.${table_name}_ep VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'TW' ) THEN
    INSERT INTO ${schema}.${table_name}_tw VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'KR' ) THEN
    INSERT INTO ${schema}.${table_name}_kr VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'IN' ) THEN
    INSERT INTO ${schema}.${table_name}_in VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'AT' ) THEN
    INSERT INTO ${schema}.${table_name}_at VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'AU' ) THEN
    INSERT INTO ${schema}.${table_name}_au VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'CA' ) THEN
    INSERT INTO ${schema}.${table_name}_ca VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'DE' ) THEN
    INSERT INTO ${schema}.${table_name}_de VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'ES' ) THEN
    INSERT INTO ${schema}.${table_name}_es VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'FR' ) THEN
    INSERT INTO ${schema}.${table_name}_fr VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'GB' ) THEN
    INSERT INTO ${schema}.${table_name}_gb VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'IT' ) THEN
    INSERT INTO ${schema}.${table_name}_it VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'RU' ) THEN
    INSERT INTO ${schema}.${table_name}_ru VALUES (NEW.*);
  ELSIF ( ${checkCondition} = 'SU' ) THEN
    INSERT INTO ${schema}.${table_name}_su VALUES (NEW.*);
  ELSIF ( ${checkCondition} in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 
      'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 
      'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) THEN
    INSERT INTO ${schema}.${table_name}_other_a VALUES (NEW.*);
  ELSIF ( ${checkCondition} in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 
      'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 
      'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 
      'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) THEN
    INSERT INTO ${schema}.${table_name}_other_b VALUES (NEW.*);
  ELSE
    RAISE EXCEPTION 'Country out of codition.  Fix the ${table_name}_insert_trigger() function!';
  END IF;
    
  RETURN NULL;
END;
\\$\\$
LANGUAGE plpgsql;

-- insert trigger 

DROP TRIGGER IF EXISTS insert_${table_name}_trigger on ${table_name};

CREATE TRIGGER insert_${table_name}_trigger
  BEFORE INSERT ON ${table_name}
  FOR EACH ROW EXECUTE PROCEDURE ${table_name}_insert_trigger();
        '''
        
        def binding = [
            table_name : tableName.toLowerCase(),
            checkCondition : checkCondition,
            schema : PARTITION_TABLE_SCHEMA
        ]
        
        def engine = new groovy.text.SimpleTemplateEngine()
        def createTriggerScript = engine.createTemplate(partition_trigger_script).make(binding)
        
        return createTriggerScript
        
    }
    
    /**
     * app_data, person_data 目前仍要手動產生...
     */
    def static generateScript = { tableName, country, template ->
        
        def cc = country.toLowerCase()
        def CC = country.toUpperCase()
        
        def checkCondition = "";
        if (country == 'other_a') {
            checkCondition = "check ( substr(pat_id, 1, 2) in ( 'AM', 'AP', 'AR', 'BA', 'BE', 'BG', 'BR', 'BY', 'CH', 'CL', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DD', 'DZ', 'DK', 'DO', 'EA', 'EC', 'EE', 'EG', 'FI', 'GC', 'GE', 'GR', 'GT', 'HK', 'HN', 'HR', 'HU') ) "
        } else if (country == 'other_b') {
            checkCondition = "check ( substr(pat_id, 1, 2) in ( 'ID', 'IE', 'IL', 'IS', 'JO', 'KE', 'KG', 'KZ', 'LT', 'LU', 'LV', 'MA', 'MC', 'MD', 'ME', 'MN', 'MT', 'MW', 'MX', 'MY', 'NI', 'NL', 'NO', 'NZ', 'OA', 'PA', 'PE', 'PH', 'PL', 'PT', 'RO', 'RS', 'SE', 'SG', 'SI', 'SK', 'SM', 'SV', 'TH', 'TJ', 'TN', 'TR', 'TT', 'UA', 'VN', 'YU', 'ZA', 'ZM', 'ZW') ) "
        } else {
            checkCondition = "check ( substr(pat_id, 1, 2) = '${country}')"
        }
        
        def binding = [
            "cc" : cc,
            "CC" : CC,
            "schema" : PARTITION_TABLE_SCHEMA,
            "tableName" : tableName,
            "checkCondition" : checkCondition
        ]
        
        def engine = new groovy.text.SimpleTemplateEngine()
        def createTableScript = engine.createTemplate(template).make(binding)
        
        return createTableScript
    }
    
    static main(args) {
        
        def other_country_a = [
            "AM", "AP", "AR",
            "BA", "BE", "BG", "BR", "BY",
            "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
            "DD", "DZ", "DK", "DO",
            "EA", "EC", "EE", "EG",
            "FI",
            "GC", "GE", "GR", "GT",
            "HK", "HN", "HR", "HU"
        ]
        
        def other_country_b = [
            "ID", "IE", "IL", "IS",
            "JO",
            "KE", "KG", "KZ",
            "LT", "LU", "LV",
            "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
            "NI", "NL", "NO", "NZ",
            "OA",
            "PA", "PE", "PH", "PL", "PT",
            "RO", "RS",
            "SE", "SG", "SI", "SK", "SM", "SV",
            "TH", "TJ", "TN", "TR", "TT",
            "UA", "UY",
            "VN",
            "YU",
            "ZA", "ZM", "ZW"
        ]
        
        def origin_country = [
            "CN", "EP", "IN", "JP", "KR", "TW", "US", "WO"
        ]
        
        def other_individual_country = [
            "AT", "AU", "CA", "DE", "ES", "FR", "GB", "IT", "RU", "SU"
        ]
        
        def other_country = [
            "other_a", "other_b"
        ]
        
        def all_country = [
            "CN", "EP", "IN", "JP", "KR", "TW", "US", "WO",
            "AT", "AU", "CA", "DE", "ES", "FR", "GB", "IT", "RU", "SU",
            "other_a", "other_b"
        ]
        
        ///////////////////////////////////////////////////////////////
        
        // TODO:
        
        // pat_ptopid_mapping
        println "---------------------------- pat_ptopid_mapping part table"
        println "";
        all_country.each { cc ->
            println pat_ptopid_mapping_template(cc);
        }
        println "---------------------------- pat_ptopid_mapping trigger"
        println generate_trigger_script("pat_ptopid_mapping");
        
//        println "---------------------------- pat_raw_docdb part table"
//        println "";
//        all_country.each { cc ->
//            println pat_raw_docdb_template(cc);
//        }
//        println "---------------------------- pat_raw_docdb trigger"
//        println generate_trigger_script("pat_raw_docdb");
        
//        println "---------------------------- pat_ref_pct part table"
//        println "";
//        all_country.each { cc ->
//            println pat_ref_pct_template(cc);
//        }
//        println "---------------------------- pat_ref_pct trigger"
//        println generate_trigger_script("pat_ref_pct");
        
//        println "---------------------------- pat_ref_priority part table"
//        println "";
//        all_country.each { cc ->
//            println pat_ref_priority_template(cc);
//        }
//        println "---------------------------- pat_ref_priority trigger"
//        println generate_trigger_script("pat_ref_priority");
        
        
//        println "---------------------------- pat_ref_cited_npl part table"
//        println "";
//        all_country.each { cc ->
//            println pat_ref_cited_npl_template(cc);
//        }
//        println "---------------------------- pat_ref_cited_npl trigger"
//        println generate_trigger_script("pat_ref_cited_npl");
        
//        println "---------------------------- pat_ref_cited part table"
//        println "";
//        all_country.each { cc ->
//            println pat_ref_cited_template(cc);
//        }
//        println "---------------------------- pat_ref_cited trigger"
//        println generate_trigger_script("pat_ref_cited");
        
//        println "---------------------------- pat_person_inventor part table"
//        println "";
//        all_country.each { cc ->
//            println pat_person_inventor_template(cc);
//        }
//        println "---------------------------- pat_person_inventor trigger"
//        println generate_trigger_script("pat_person_inventor");
        
        
//        println "---------------------------- pat_person_assignee part table"
//        println "";
//        all_country.each { cc ->
//            println pat_person_assignee_template(cc);
//        }
//        println "---------------------------- pat_person_assignee trigger"
//        println generate_trigger_script("pat_person_assignee");
        
//        println "---------------------------- pat_person_applicant part table"
//        println "";
//        all_country.each { cc ->
//            println pat_person_applicant_template(cc);
//        }
//        println "---------------------------- pat_person_applicant trigger"
//        println generate_trigger_script("pat_person_applicant");
        
        
//        println "---------------------------- pat_person_agent part table"
//        println "";
//        all_country.each { cc ->
//            println pat_person_agent_template(cc);
//        }
//        println "---------------------------- pat_person_agent trigger"
//        println generate_trigger_script("pat_person_agent");
        
//        println "---------------------------- pat_data_desc part table"
//        println "";
//        all_country.each { cc ->
//            println pat_data_desc_template(cc);
//        }
//        println "---------------------------- pat_data_desc trigger"
//        println generate_trigger_script("pat_data_desc");
        
//        println "---------------------------- pat_data_claims part table"
//        println "";
//        all_country.each { cc ->
//            println pat_data_claims_template(cc);
//        }
//        println "---------------------------- pat_data_claims trigger"
//        println generate_trigger_script("pat_data_claims");
        
//        println "---------------------------- pat_data_brief part table"
//        println "";
//        all_country.each { cc ->
//            println pat_data_brief_template(cc);
//        }
//        println "---------------------------- pat_data_brief trigger"
//        println generate_trigger_script("pat_data_brief");
        
//        println "---------------------------- pat_data part table"
//        println "";
//
//        all_country.each { cc ->
//            println pat_data_template(cc);
//        }
//
//        println "---------------------------- pat_data trigger"
//        println generate_trigger_script("pat_data");
        
        
//        println "---------------------------- pat_cls_cset part table"
//        println "";
//        all_country.each { cc ->
//            println pat_cls_cset_template(cc);
//        }
//        println "---------------------------- pat_cls_cset trigger"
//        println generate_trigger_script("pat_cls_cset");

                
//        println "---------------------------- pat_cls_cpc part table"
//        println "";
//        all_country.each { cc ->
//            println pat_cls_cpc_template(cc);
//        }
//        println "---------------------------- pat_cls_cpc trigger"
//        println generate_trigger_script("pat_cls_cpc");
        
        
//        println "---------------------------- pat_data_title part table"
//        println "";
//        all_country.each { cc ->
//            println pat_data_title_template(cc);
//        }
//        println "---------------------------- pat_data_title trigger"
//        println generate_trigger_script("pat_data_title");
        
//        println "---------------------------- pat_cls_ipc part table"
//        println "";
//        all_country.each { cc -> 
//            println pat_cls_ipc_template(cc);
//        }
//        println "---------------------------- pat_cls_ipc trigger"
//        println generate_trigger_script("pat_cls_ipc");
        
    }

}
