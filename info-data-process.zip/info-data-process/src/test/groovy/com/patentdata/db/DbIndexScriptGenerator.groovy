package com.patentdata.db

import com.patentdata.util.CountryUtil;

/**
 * 依所輸入的template, 來產出sql index script.
 * 
 * @author tonykuo
 *
 */
class DbIndexScriptGenerator {
    
    static main(args) {
        
        // person_data的index, 還要再加上other_c
        def all_country = [
            "CN", "EP", "IN", "JP", "KR", "TW", "US", "WO",
            "AT", "AU", "CA", "DE", "ES", "FR", "GB", "IT", "RU", "SU",
            "other_a", "other_b"
        ]
        
        def templateList = [
            "pat_data_pat_id_idx" : "CREATE INDEX ON part.pat_data_\${cc} USING btree (pat_id COLLATE pg_catalog.\"default\");",
            "pat_data_country_idx" : "CREATE INDEX ON part.pat_data_\${cc} USING btree (country COLLATE pg_catalog.\"default\");",
            "pat_data_country_doc_no_kind_code_idx" : "CREATE INDEX ON part.pat_data_\${cc} USING btree (country COLLATE pg_catalog.\"default\", doc_no COLLATE pg_catalog.\"default\", kind_code COLLATE pg_catalog.\"default\");",
            "pat_data_doc_date_idx" : "CREATE INDEX ON part.pat_data_\${cc} USING btree (doc_date);",
            "app_data_app_id_idx" : "CREATE INDEX ON part.app_data_\${cc} USING btree (app_id COLLATE pg_catalog.\"default\");",
            "app_data_country_app_no_app_date_idx" : "CREATE INDEX ON part.app_data_\${cc} USING btree (country COLLATE pg_catalog.\"default\", app_no COLLATE pg_catalog.\"default\", app_date);",
            "person_data_person_id_idx" : "CREATE INDEX ON part.person_data_\${cc} USING btree (person_id);",
            "person_data_person_facet_idx" : "CREATE INDEX ON part.person_data_\${cc} USING btree (person_facet COLLATE pg_catalog.\"default\");",
            "person_data_country_person_facet_idx" : "CREATE INDEX ON part.person_data_\${cc} USING btree (country COLLATE pg_catalog.\"default\", person_facet COLLATE pg_catalog.\"default\");",
            "pat_person_applicant_pat_id_source_id_item_idx" : "CREATE INDEX ON part.pat_person_applicant_\${cc} USING btree (pat_id COLLATE pg_catalog.\"default\", source_id COLLATE pg_catalog.\"default\", item);",
            "pat_person_inventor_pat_id_source_id_item_idx" : "CREATE INDEX ON part.pat_person_inventor_\${cc} USING btree (pat_id COLLATE pg_catalog.\"default\", source_id COLLATE pg_catalog.\"default\", item);",
            "pat_raw_docdb_pat_id_idx" : "CREATE INDEX ON part.pat_raw_docdb_\${cc} USING btree (pat_id COLLATE pg_catalog.\"default\");",
            "pat_raw_docdb_raw_id_idx" : "CREATE INDEX ON part.pat_raw_docdb_\${cc} USING btree (raw_id COLLATE pg_catalog.\"default\");",
            "pat_ptopid_mapping_pat_id_ptopid_id_idx" : "CREATE INDEX ON part.pat_ptopid_mapping_\${cc} USING btree (pat_id COLLATE pg_catalog.\"default\", ptopid_id COLLATE pg_catalog.\"default\");",
            "pat_ref_cited_country_idx" : "CREATE INDEX ON part.pat_ref_cited_\${cc} USING btree (country COLLATE pg_catalog.\"default\");"
        ]
        
        templateList.each { key, value ->
            
            println "---------------------------- create index ${key}"
            
            all_country.each { cc ->
                //
                def binding = [
                    "cc" : cc,
                ]
                
                def engine = new groovy.text.SimpleTemplateEngine()
                def createIndexScript = engine.createTemplate(value).make(binding)
                    
                println createIndexScript
                
            }   // end CountryUtil.getDocdbCountryList
            
        }   // end templateList.each
        
        // hard code template: start
        
        println "---------------------------- create index pat_event_record_pat_id_idx"
        println "CREATE INDEX ON public.pat_event_record USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_cn_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_cn USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_cn_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_cn USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_ep_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_ep USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_ep_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_ep USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_in_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_in USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_in_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_in USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_jp_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_jp USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_jp_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_jp USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_kr_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_kr USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_kr_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_kr USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_tw_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_tw USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_tw_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_tw USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_us_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_us USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_us_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_us USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_wo_raw_id_idx"
        println "CREATE INDEX ON public.pat_raw_wo USING btree (raw_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_raw_wo_pat_id_idx"
        println "CREATE INDEX ON public.pat_raw_wo USING btree (pat_id COLLATE pg_catalog.\"default\");"
        
        println "---------------------------- create index pat_data_memo_pat_id_memo_type_idx"
        println "CREATE INDEX ON public.pat_data_memo USING btree (pat_id COLLATE pg_catalog.\"default\", memo_type);"
        
        // hard code template: end
        
        /*
         * NOTE: CREATE INDEX CONCURRENTLY idx_salary ON employees(last_name, salary);
         */
        
    }

}
