package com.patentdata.db

import groovy.io.FileType

class DbScriptMerge {
    
    private static final String MERGE_FILE = "hibernate/db_partition_setting/db_script_merge.txt";

    static main(args) {
        
        // hibernate/db_parition_setting
        
        if (new File(MERGE_FILE).delete()) {
            println "delete file ${MERGE_FILE} complete."
        }
        
        def fileList = []
        
        File mergeFile = new File(MERGE_FILE);
        
        new File("hibernate/db_partition_setting").eachFileMatch(FileType.FILES, ~/^.*\.sql/) { file -> 
            fileList << file
        }
        
        def sortFileList = fileList.sort {a, b ->
            int seqA = a.name.split("_")[0] as int
            int seqB = b.name.split("_")[0] as int
            return seqA.compareTo(seqB)
        }
        
        sortFileList.each { file ->
            
            println "merge file = ${file.name}"
            
            file.eachLine { it, line  ->
                if (line == 1) {
                    mergeFile << "---------------------------------------XXX ${file.name}" << "\r\n"
                }
                mergeFile << it << "\r\n"
            }
        }
        
        println "finished..."
    }

}
