package com.patentsolr

import spock.lang.Specification;
import spock.lang.Ignore

class IndexMakerTester extends Specification {
    
    /**
     * TODO: US20050256223, 該筆資料有applicant, 但在176的solr us, 也同時有assignees和inventors, 但可是新建索引及其相關table卻沒有資料. why ???
     * 
     * @return
     */
    def "test us multi applicants, [US20050256223]"() {
        setup:
            ""
        when:
            ""
        then:
            ""
        expect:
            ""
    }
    
    def "test docdb multi inventors, [AP9901478-D0-19990331]"() {
        setup:
            ""
        when:
            ""
        then:
            ""
        expect:
            ""
    }
    
    def "test something..."() {
        setup:
            ""
        when:
            ""
        then:
            ""
        expect:
            ""
    }
    
}
