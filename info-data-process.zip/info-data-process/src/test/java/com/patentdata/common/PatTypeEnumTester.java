package com.patentdata.common;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PatTypeEnumTester {
    
    public static Logger logger = LoggerFactory.getLogger(PatTypeEnumTester.class);
    
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testUS() {
        
        assertSame(3, PatTypeEnum.US.DESIGN.getTypeCode());
        assertSame("Design", PatTypeEnum.US.DESIGN.getTypeName());
        assertSame(3, PatTypeEnum.US.findPatTypeCode("Design"));
        assertSame("Design", PatTypeEnum.US.findPatTypeName(3));
    }
    
    @Test
    public void testCN() {
        
        assertSame(1, PatTypeEnum.CN.FM.getTypeCode());
        assertSame("发明专利", PatTypeEnum.CN.FM.getTypeName());
        assertSame(3, PatTypeEnum.CN.findPatTypeCode("实用新型"));
        assertSame("实用新型", PatTypeEnum.CN.findPatTypeName(3));
    }
    
    @Test
    public void testDOCDB() {
        
        assertSame(9, PatTypeEnum.DOCDB.OTHERS.getTypeCode());
        assertSame("Others", PatTypeEnum.DOCDB.OTHERS.getTypeName());
        assertSame(9, PatTypeEnum.DOCDB.findPatTypeCode("Others"));
        assertSame("Others", PatTypeEnum.DOCDB.findPatTypeName(9));
    }

}
