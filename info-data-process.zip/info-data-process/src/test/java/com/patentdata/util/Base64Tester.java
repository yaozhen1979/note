package com.patentdata.util;

import static org.junit.Assert.*;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Base64Tester {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testEncode() throws UnsupportedEncodingException {
        
        String user = "";
        String pwd = "hadfhastr";
        
        assertEquals(new Base64().encodeToString(user.getBytes("UTF-8")), "");
        assertEquals(new Base64().encodeToString(pwd.getBytes("UTF-8")), "");
        
    }
    
    @Test
    public void testDecode() throws UnsupportedEncodingException {
        
        String userEncode = "";
        String pwdEncode = "";
        
        assertEquals("", new String(Base64.decodeBase64(userEncode), "UTF-8"));
        assertEquals("", new String(Base64.decodeBase64(pwdEncode), "UTF-8"));
        
    }

}
