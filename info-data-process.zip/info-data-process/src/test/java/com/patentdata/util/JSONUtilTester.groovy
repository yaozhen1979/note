package com.patentdata.util;

import static org.junit.Assert.*

import org.junit.After
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

import com.patentdata.exception.JsonFormatException

public class JSONUtilTester {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    @Ignore
    public void testIsJSONValid() {
        
        String jsonString = ''' 
        { "designation-pct" : { "national" : { "country" : [ "AE" , "AG" , "AL" , "AM" , "AO" , "AT" , "AU" , "AZ" , "BA" , "BB" , "BG" , "BH" , "BN" , "BR" , "BW" , "BY" , "BZ" , "CA" , "CH" , "CL" , "CN" , "CO" , "CR" , "CU" , "CZ" , "DE" , "DK" , "DM" , "DO" , "DZ" , "EC" , 
        "EE" , "EG" , "ES" , "FI" , "GB" , "GD" , "GE" , "GH" , "GM" , "GT" , "HN" , "HR" , "HU" , "ID" , "IL" , "IN" , "IR" , "IS" , "JP"
         , "KE" , "KG" , "KN" , "KP" , "KR" , "KZ" , "LA" , "LC" , "LK" , "LR" , "LS" , "LU" , "LY" , "MA" , "MD" , "ME" , "MG" , "MK" , "MN" , "MW" , "MX" , "MY" , "MZ" , "NA" , "NG" , "NI" , "NO" , "NZ" , "OM" , "PA" , "PE" , "PG" , "PH" , "PL" , "PT" , "QA" , "RO" 
        , "RS" , "RU" , "RW" , "SA" , "SC" , "SD" , "SE" , "SG" , "SK" , "SL" , "SM" , "ST" , "SV" , "SY" , "TH" , "TJ" , "TM" , "TN" , "TR" , "TT" , "TZ" , "UA" , "UG" , "US" , "UZ" , "VC" , "VN" , "ZA" , "ZM" , "ZW"]} , "regional" : [ { "country" : [ "BW" , "GH" , "GM" , "KE" , "LR" , "LS" , "MW" , "MZ" , "NA" , "RW" , "SD" , "SL" , "SZ" , "TZ" , "UG" , "ZM" , "ZW"] , "region" : { "country" : 
        "AP"}} , { "country" : [ "AM" , "AZ" , "BY" , "KG" , "KZ" , "RU" , "TJ" , "TM"] , "region" : { "country" : "EA"}} , { "country" : 
        [ "AL" , "AT" , "BE" , "BG" , "CH" , "CY" , "CZ" , "DE" , "DK" , "EE" , "ES" , "FI" , "FR" , "GB" , "GR" , "HR" , "HU" , "IE" , "IS" , "IT" , "LT" , "LU" , "LV" , "MC" , "MK" , "MT" , "NL" , "NO" , "PL" , "PT" , "RO" , "RS" , "SE" , "SI" , "SK" , "SM" , "TR"] 
        , "region" : { "country" : "EP"}} , { "country" : [ "BF" , "BJ" , "CF" , "CG" , "CI" , "CM" , "GA" , "GN" , "GQ" , "GW" , "KM" , "ML" , "MR" , "NE" , "SN" , "TD" , "TG"] , "region" : { "country" : "OA"}}]}}
        '''
        
        assertEquals(true, JSONUtil.isJSONValid(jsonString))

    }
    
    @Test
    public void testMapToJSONString1() {
        def map = [name: "AVERBECK ALFRED", country: "NZ", sequence:1]
        String jsonStr = JSONUtil.mapToJSONString(map);
        String expected = "{ \"name\" : { \"origin\" : \"AVERBECK ALFRED\" }, \"country\" : { \"origin\" : \"NZ\" }, \"sequence\" : 1 }"
        assert expected == jsonStr
    }
    
    //
    @Test
    public void testMapToJSONString2() {
        def map = ["origin": "averbeckalfred"]
        String jsonStr = JSONUtil.mapToJSONString(map);
        String expected = "{ \"origin\" : \"averbeckalfred\" }"
        assert expected == jsonStr
    }
    
    @Test(expected = JsonFormatException.class)
    public void testJsonFormatException() {
        throw new JsonFormatException("dataJsor")
    }

}
