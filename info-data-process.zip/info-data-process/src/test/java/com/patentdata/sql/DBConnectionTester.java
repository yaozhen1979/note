package com.patentdata.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DBConnectionTester {

    private static Connection getConnection() throws Exception {
        
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName("org.mariadb.jdbc.MySQLDataSource");
        config.setJdbcUrl("jdbc:mariadb://10.60.90.211/Assignment");
        config.setUsername("allenwu");
        config.setPassword("allenwu");

        HikariDataSource ds = new HikariDataSource(config);
        
        return ds.getConnection();
    }
    
    /**
     * 
     * @param args
     * @throws SQLException
     * @throws Exception
     */
    public static void main(String[] args) throws SQLException, Exception {
        System.out.println(getConnection().getSchema()); 
        System.out.println("finished");
    }

}
