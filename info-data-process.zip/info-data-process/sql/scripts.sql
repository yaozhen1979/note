CREATE SEQUENCE seq_change_log_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_data_import_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_event_record_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_log_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_memo_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_person_lang_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_ptopid_mapping_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE SEQUENCE seq_solr_build_id
       INCREMENT BY 1
       MINVALUE 1
       CACHE 1
       NO CYCLE;

CREATE TABLE app_cur_assignee
(
   app_id                varchar(50)     NOT NULL,
   item                  integer         NOT NULL,
   cur_assignee_name     varchar(200)    NOT NULL,
   right_effective_date  date,
   process_date          date,
   create_date           timestamp       NOT NULL,
   last_upd_date         timestamp       NOT NULL
);

ALTER TABLE app_cur_assignee
   ADD CONSTRAINT app_cur_assignee_pkey
   PRIMARY KEY (app_id, item);

CREATE TABLE app_data
(
   app_id         varchar(50)    NOT NULL,
   country        varchar(2)     NOT NULL,
   app_no         varchar(50)    NOT NULL,
   app_date       date           NOT NULL,
   app_lang       varchar(2),
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE app_data
   ADD CONSTRAINT app_data_pkey
   PRIMARY KEY (app_id);

CREATE TABLE cpc
(
   id         varchar(50)      NOT NULL,
   parentid   varchar(50)      NOT NULL,
   symbol     varchar(50)      NOT NULL,
   title      varchar(3000)    NOT NULL,
   level      integer          NOT NULL,
   editionid  varchar(50)      NOT NULL,
   subgroup   varchar(50),
   maingroup  varchar(50)
);

ALTER TABLE cpc
   ADD CONSTRAINT cpc_pkey
   PRIMARY KEY (id);

CREATE TABLE fi
(
   id         varchar(50)      NOT NULL,
   parentid   varchar(50),
   symbol     varchar(50),
   title      varchar(3000),
   level      integer,
   extension  integer,
   subgroup   varchar(50),
   maingroup  varchar(50)
);

ALTER TABLE fi
   ADD CONSTRAINT fi_pkey
   PRIMARY KEY (id);

CREATE TABLE ipc
(
   id         varchar(50)      NOT NULL,
   parentid   varchar(50)      NOT NULL,
   symbol     varchar(50)      NOT NULL,
   title      varchar(3000)    NOT NULL,
   level      integer          NOT NULL,
   editionid  varchar(50)      NOT NULL,
   subgroup   varchar(50),
   maingroup  varchar(50)
);

ALTER TABLE ipc
   ADD CONSTRAINT ipc_pkey
   PRIMARY KEY (id);

CREATE TABLE job_data_import
(
   data_import_id  integer       DEFAULT nextval('seq_data_import_id'::regclass) NOT NULL,
   source_id       varchar(50)    NOT NULL,
   job_type        integer        NOT NULL,
   status          integer        NOT NULL,
   "count"         integer        NOT NULL,
   save_count      integer        NOT NULL,
   diff_count      integer        NOT NULL,
   create_date     timestamp      NOT NULL,
   finish_date     timestamp,
   doc_start_date  date,
   doc_end_date    date
);

ALTER TABLE job_data_import
   ADD CONSTRAINT job_data_import_pkey
   PRIMARY KEY (data_import_id);

CREATE TABLE job_solr_build
(
   solr_build_id   integer     DEFAULT nextval('seq_solr_build_id'::regclass) NOT NULL,
   doc_start_date  date         NOT NULL,
   doc_end_date    date         NOT NULL,
   pto             char(10)     NOT NULL,
   solr_ip         char(15)     NOT NULL,
   status          integer      NOT NULL,
   "count"         integer      NOT NULL,
   save_count      integer      NOT NULL,
   diff_count      integer      NOT NULL,
   create_date     timestamp    NOT NULL,
   finish_date     timestamp
);

ALTER TABLE job_solr_build
   ADD CONSTRAINT job_solr_build_pkey
   PRIMARY KEY (solr_build_id);

CREATE TABLE pat_cls_cpc
(
   pat_id           varchar(50)    NOT NULL,
   source_id        varchar(50)    NOT NULL,
   item             integer        NOT NULL,
   cpc_text         varchar(30)    NOT NULL,
   symbol_position  char(1),
   cls_version      varchar(10),
   cls_value        char(1),
   action_date      date,
   gen_office       char(2),
   cls_status       char(1),
   cls_data_source  char(1),
   schema_ori_code  varchar(10),
   raw_main_flag    integer        NOT NULL,
   create_date      timestamp      NOT NULL
);

ALTER TABLE pat_cls_cpc
   ADD CONSTRAINT pat_cls_cpc_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_cset
(
   pat_id           varchar(50)    NOT NULL,
   source_id        varchar(50)    NOT NULL,
   group_no         integer        NOT NULL,
   item             integer        NOT NULL,
   cpc_text         varchar(30)    NOT NULL,
   symbol_position  char(1),
   cls_version      varchar(10),
   cls_value        char(1),
   action_date      date,
   gen_office       char(2),
   cls_status       char(1),
   cls_data_source  char(1),
   schema_ori_code  varchar(10),
   create_date      timestamp      NOT NULL
);

ALTER TABLE pat_cls_cset
   ADD CONSTRAINT pat_cls_cset_pkey
   PRIMARY KEY (pat_id, source_id, group_no, item);

CREATE TABLE pat_cls_di
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   item         integer        NOT NULL,
   di_text      varchar(30)    NOT NULL,
   create_date  timestamp      NOT NULL
);

ALTER TABLE pat_cls_di
   ADD CONSTRAINT pat_cls_di_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_dterm
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   item         integer        NOT NULL,
   dterm_text   varchar(30)    NOT NULL,
   create_date  timestamp      NOT NULL
);

ALTER TABLE pat_cls_dterm
   ADD CONSTRAINT pat_cls_dterm_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_ecla
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   item         integer        NOT NULL,
   ecla_text    varchar(50)    NOT NULL,
   create_date  timestamp      NOT NULL
);

ALTER TABLE pat_cls_ecla
   ADD CONSTRAINT pat_cls_ecla_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_fi
(
   pat_id                      varchar(50)    NOT NULL,
   source_id                   varchar(50)    NOT NULL,
   item                        integer        NOT NULL,
   fi_text                     varchar(30)    NOT NULL,
   ipc                         varchar(30)    NOT NULL,
   sub_division_symbol         char(3),
   file_discrimination_symbol  char(1),
   raw_main_flag               integer        NOT NULL,
   create_date                 timestamp      NOT NULL,
   cls_value                   char(1),
   index_flag                  integer,
   index_type                  integer,
   fi_facets                   char(3)
);

ALTER TABLE pat_cls_fi
   ADD CONSTRAINT pat_cls_fi_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_field_of_search
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   item         integer        NOT NULL,
   class_type   varchar(10)    NOT NULL,
   class_text   varchar(30)    NOT NULL,
   create_date  timestamp      NOT NULL,
   defect_flag  integer
);

ALTER TABLE pat_cls_field_of_search
   ADD CONSTRAINT pat_cls_field_of_search_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_fterm
(
   pat_id           varchar(50)    NOT NULL,
   source_id        varchar(50)    NOT NULL,
   item             integer        NOT NULL,
   fterm_text       varchar(30)    NOT NULL,
   theme_code       char(5)        NOT NULL,
   viewpoint        char(2),
   figure           char(3),
   create_date      timestamp      NOT NULL,
   additional_code  char(1)
);

ALTER TABLE pat_cls_fterm
   ADD CONSTRAINT pat_cls_fterm_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_ipc
(
   pat_id           varchar(50)    NOT NULL,
   source_id        varchar(50)    NOT NULL,
   ipc_type         integer        NOT NULL,
   item             integer        NOT NULL,
   ipc_text         varchar(30)    NOT NULL,
   symbol_position  char(1),
   cls_version      varchar(10),
   cls_level        char(1),
   cls_value        char(1),
   action_date      date,
   gen_office       char(2),
   cls_status       char(1),
   cls_data_source  char(1),
   raw_main_flag    integer        NOT NULL,
   create_date      timestamp      NOT NULL,
   index_flag       integer        DEFAULT 0,
   index_type       integer
);

ALTER TABLE pat_cls_ipc
   ADD CONSTRAINT pat_cls_ipc_pkey
   PRIMARY KEY (pat_id, source_id, ipc_type, item);

CREATE TABLE pat_cls_loc
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   item           integer        NOT NULL,
   loc_text       varchar(30),
   cls_version    varchar(10),
   raw_main_flag  integer        NOT NULL,
   create_date    timestamp      NOT NULL,
   raw_text       varchar(30)
);

ALTER TABLE pat_cls_loc
   ADD CONSTRAINT pat_cls_loc_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_cls_uspc
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   item           integer        NOT NULL,
   uspc_text      char(30)       NOT NULL,
   raw_main_flag  integer        NOT NULL,
   create_date    timestamp      NOT NULL
);

ALTER TABLE pat_cls_uspc
   ADD CONSTRAINT pat_cls_uspc_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_data
(
   pat_id                      varchar(50)    NOT NULL,
   country                     varchar(2)     NOT NULL,
   stat                        integer        NOT NULL,
   raw_doc_no                  varchar(50)    NOT NULL,
   doc_no                      varchar(50)    NOT NULL,
   doc_date                    date,
   kind_code                   varchar(2)     NOT NULL,
   pat_type                    integer        NOT NULL,
   raw_app_no                  varchar(50)    NOT NULL,
   app_id                      varchar(50)    NOT NULL,
   registration_no             varchar(50),
   registration_date           date,
   family_id                   varchar(30),
   default_source_id           varchar(50)    NOT NULL,
   ori_lang                    char(5)        NOT NULL,
   crypto_flag                 integer        NOT NULL,
   withdraw_flag               integer        NOT NULL,
   delete_flag                 integer        NOT NULL,
   size_of_clips               integer,
   size_of_figures             integer,
   grant_years                 integer,
   grant_extension_days        integer,
   page_no_of_claim            integer,
   page_no_of_desc             integer,
   page_no_of_figure           integer,
   page_no_of_first_img        integer,
   first_img_flag              integer,
   truncate_flag               integer,
   gazette_no                  varchar(50),
   gazette_public_date         date,
   figure_pages                integer,
   create_date                 timestamp      NOT NULL,
   last_upd_date               timestamp      NOT NULL,
   reex_flag                   integer,
   ptab_flag                   integer,
   sec_flag                    integer,
   size_of_claims              integer,
   index_criteria              varchar(50),
   designation_of_states_json  text,
   total_pages                 integer,
   exam_app_date               date,
   docdb_flag                  integer        NOT NULL,
   pto_flag                    integer        NOT NULL,
   parent_case_text            text,
   partial_design_flag         integer,
   appeal_no                   varchar(50),
   appeal_date                 date,
   related_design_flag         integer
);

ALTER TABLE pat_data
   ADD CONSTRAINT pat_data_pkey
   PRIMARY KEY (pat_id);

CREATE TABLE pat_data_amend
(
   pat_id             varchar(50)    NOT NULL,
   source_id          varchar(50)    NOT NULL,
   amend_date         date           NOT NULL,
   item               integer        NOT NULL,
   amend_column_desc  varchar(50),
   amend_scope_desc   varchar(50),
   amend_type_desc    varchar(50),
   amend_val          text,
   create_date        timestamp      NOT NULL
);

ALTER TABLE pat_data_amend
   ADD CONSTRAINT pat_data_amend_pkey
   PRIMARY KEY (pat_id, source_id, amend_date, item);

CREATE TABLE pat_data_brief
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   lang           char(5)        NOT NULL,
   brief          text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_data_brief
   ADD CONSTRAINT pat_data_brief_pkey
   PRIMARY KEY (pat_id, source_id, lang);

CREATE TABLE pat_data_claims
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   lang            char(5)        NOT NULL,
   claims          text,
   create_date     timestamp      NOT NULL,
   last_upd_date   timestamp      NOT NULL,
   amended_claims  text
);

ALTER TABLE pat_data_claims
   ADD CONSTRAINT pat_data_claims_pkey
   PRIMARY KEY (pat_id, source_id, lang);

CREATE TABLE pat_data_desc
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   lang           char(5)        NOT NULL,
   description    text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_data_desc
   ADD CONSTRAINT pat_data_desc_pkey
   PRIMARY KEY (pat_id, source_id, lang);

CREATE TABLE pat_data_log
(
   log_id      integer        DEFAULT nextval('seq_log_id'::regclass) NOT NULL,
   country     char(2)         NOT NULL,
   raw_doc_no  varchar(50)     NOT NULL,
   doc_no      varchar(50)     NOT NULL,
   doc_date    date,
   log_type    integer         NOT NULL,
   log_code    varchar(50)     NOT NULL,
   msg         varchar(200)    NOT NULL,
   pat_id      varchar(50),
   source_id   varchar(50),
   raw_id      varchar(50),
   log_date    timestamp       NOT NULL,
   flag        integer         NOT NULL
);

ALTER TABLE pat_data_log
   ADD CONSTRAINT pat_data_log_pkey
   PRIMARY KEY (log_id);

CREATE TABLE pat_data_memo
(
   memo_id      integer       DEFAULT nextval('seq_memo_id'::regclass) NOT NULL,
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   memo_type    integer        NOT NULL,
   create_date  timestamp      NOT NULL
);

ALTER TABLE pat_data_memo
   ADD CONSTRAINT pat_data_memo_pkey
   PRIMARY KEY (memo_id);

CREATE TABLE pat_data_title
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   lang           char(5)        NOT NULL,
   title          text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_data_title
   ADD CONSTRAINT pat_data_title_pkey
   PRIMARY KEY (pat_id, source_id, lang);

CREATE TABLE pat_event_record
(
   record_id   integer        DEFAULT nextval('seq_event_record_id'::regclass) NOT NULL,
   pat_id      varchar(50)     NOT NULL,
   pat_item    integer         NOT NULL,
   source_id   varchar(50)     NOT NULL,
   event_type  integer         NOT NULL,
   remark      varchar(100)    NOT NULL,
   event_date  timestamp       NOT NULL
);

ALTER TABLE pat_event_record
   ADD CONSTRAINT pat_event_record_pkey
   PRIMARY KEY (record_id);

CREATE TABLE pat_event_record_change_log
(
   record_id        integer        NOT NULL,
   log_id           integer       DEFAULT nextval('seq_change_log_id'::regclass) NOT NULL,
   change_col_name  varchar(50)    NOT NULL,
   cur_val          text           NOT NULL,
   change_val       text           NOT NULL,
   create_date      timestamp      NOT NULL
);

ALTER TABLE pat_event_record_change_log
   ADD CONSTRAINT pat_event_record_amend_log_pkey
   PRIMARY KEY (log_id);

CREATE TABLE pat_person_agent
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   item            integer        NOT NULL,
   person_id       uuid           NOT NULL,
   rep_code        varchar(50),
   create_date     timestamp      NOT NULL,
   pto_person_id   varchar(20),
   person_country  char(2)
);

ALTER TABLE pat_person_agent
   ADD CONSTRAINT pat_person_agent_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_person_applicant
(
   pat_id            varchar(50)    NOT NULL,
   source_id         varchar(50)    NOT NULL,
   item              integer        NOT NULL,
   person_id         uuid           NOT NULL,
   app_code          varchar(50),
   designation_code  varchar(50),
   auth_category     varchar(50),
   create_date       timestamp      NOT NULL,
   pto_person_id     varchar(20),
   person_country    char(2)
);

ALTER TABLE pat_person_applicant
   ADD CONSTRAINT pat_person_applicant_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_person_assignee
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   item            integer        NOT NULL,
   person_id       uuid           NOT NULL,
   create_date     timestamp      NOT NULL,
   person_country  char(2)
);

ALTER TABLE pat_person_assignee
   ADD CONSTRAINT pat_person_assignee_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_person_correspondence_addr
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   item            integer        NOT NULL,
   person_id       uuid           NOT NULL,
   create_date     timestamp      NOT NULL,
   person_country  char(2)
);

ALTER TABLE pat_person_correspondence_addr
   ADD CONSTRAINT pat_person_correspondence_addr_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_person_examiner
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   item            integer        NOT NULL,
   person_id       uuid           NOT NULL,
   examiner_type   integer        NOT NULL,
   department      varchar(50),
   create_date     timestamp      NOT NULL,
   person_country  char(2)
);

ALTER TABLE pat_person_examiner
   ADD CONSTRAINT pat_person_examiner_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_person_inventor
(
   pat_id          varchar(50)    NOT NULL,
   source_id       varchar(50)    NOT NULL,
   item            integer        NOT NULL,
   person_id       uuid           NOT NULL,
   designation     varchar(50),
   create_date     timestamp      NOT NULL,
   person_country  char(2)
);

ALTER TABLE pat_person_inventor
   ADD CONSTRAINT pat_person_inventor_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_ptopid_mapping
(
   ptopid_mapping_id  integer       DEFAULT nextval('seq_ptopid_mapping_id'::regclass) NOT NULL,
   pat_id             varchar(50)    NOT NULL,
   ptopid_id          varchar(50)    NOT NULL
);

ALTER TABLE pat_ptopid_mapping
   ADD CONSTRAINT pat_ptopid_mapping_pkey
   PRIMARY KEY (ptopid_mapping_id);

CREATE TABLE pat_raw_cn
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_cn
   ADD CONSTRAINT pat_raw_cn_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_docdb
(
   raw_id              varchar        NOT NULL,
   pat_id              varchar(50)    NOT NULL,
   raw_json            text           NOT NULL,
   lastest_flag        integer        NOT NULL,
   family_member_json  text,
   last_exchange_date  date           NOT NULL,
   create_date         timestamp      NOT NULL,
   last_upd_date       timestamp      NOT NULL
);

ALTER TABLE pat_raw_docdb
   ADD CONSTRAINT pat_raw_docdb_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_ep
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_ep
   ADD CONSTRAINT pat_raw_ep_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_in
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_in
   ADD CONSTRAINT pat_raw_in_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_jp
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   xml_type       varchar(20)    NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_jp
   ADD CONSTRAINT pat_raw_jp_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_kr
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   raw_public_no  varchar(50),
   public_no      varchar(50),
   public_date    date,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_kr
   ADD CONSTRAINT pat_raw_kr_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_tw
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_tw
   ADD CONSTRAINT pat_raw_tw_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_us
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   rel_raw_type   integer        NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_us
   ADD CONSTRAINT pat_raw_us_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_raw_wo
(
   raw_id         varchar(50)    NOT NULL,
   pat_id         varchar(50)    NOT NULL,
   raw_json       text           NOT NULL,
   xml_type       char(3)        NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE pat_raw_wo
   ADD CONSTRAINT pat_raw_wo_pkey
   PRIMARY KEY (raw_id);

CREATE TABLE pat_ref_cited
(
   pat_id         varchar(50)     NOT NULL,
   source_id      varchar(50)     NOT NULL,
   item           integer         NOT NULL,
   raw_doc_no     varchar(50)     NOT NULL,
   doc_no         varchar(50),
   country        varchar(10),
   kind_code      char(2),
   inventor_name  varchar(200),
   doc_date       date,
   app_date       date,
   cited_by_type  integer         NOT NULL,
   cited_pat_id   varchar(50),
   create_date    timestamp       NOT NULL,
   raw_doc_date   varchar(20),
   raw_app_date   varchar(20)
);

ALTER TABLE pat_ref_cited
   ADD CONSTRAINT pat_ref_cited_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_ref_cited_cls
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   cited_item   integer        NOT NULL,
   item         integer        NOT NULL,
   class_type   varchar(10)    NOT NULL,
   class_text   varchar(30)    NOT NULL,
   create_date  timestamp      NOT NULL,
   defect_flag  integer
);

ALTER TABLE pat_ref_cited_cls
   ADD CONSTRAINT pat_ref_cited_cls_pkey
   PRIMARY KEY (pat_id, source_id, cited_item, item);

CREATE TABLE pat_ref_cited_npl
(
   pat_id         varchar(50)    NOT NULL,
   source_id      varchar(50)    NOT NULL,
   item           integer        NOT NULL,
   npl_json       text           NOT NULL,
   cited_by_type  integer        NOT NULL,
   create_date    timestamp      NOT NULL,
   npl_text       text
);

ALTER TABLE pat_ref_cited_npl
   ADD CONSTRAINT pat_ref_cited_npl_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_ref_cited_npl_cls
(
   pat_id       varchar(50)    NOT NULL,
   source_id    varchar(50)    NOT NULL,
   cited_item   integer        NOT NULL,
   item         integer        NOT NULL,
   class_type   varchar(10)    NOT NULL,
   class_text   varchar(30)    NOT NULL,
   create_date  timestamp      NOT NULL,
   defect_flag  integer
);

ALTER TABLE pat_ref_cited_npl_cls
   ADD CONSTRAINT pat_ref_cited_npl_cls_pkey
   PRIMARY KEY (pat_id, source_id, cited_item, item);

CREATE TABLE pat_ref_hague
(
   pat_id           varchar(50)    NOT NULL,
   raw_app_date     varchar(20),
   app_date         date,
   raw_public_date  varchar(20),
   public_date      date,
   registration_no  varchar(50),
   design_no        varchar(3),
   create_date      timestamp      NOT NULL
);

ALTER TABLE pat_ref_hague
   ADD CONSTRAINT pat_ref_hague_pkey
   PRIMARY KEY (pat_id);

CREATE TABLE pat_ref_pct
(
   pat_id               varchar(50)    NOT NULL,
   raw_app_no           varchar(50)    NOT NULL,
   app_no               varchar(50),
   app_date             date,
   pct_371c124_date     date,
   article_22_39_date   date,
   pct_371c12_date      varchar(10),
   pct_app_id           varchar(50),
   raw_public_no        varchar(50),
   public_no            varchar(50),
   public_date          date,
   public_gazette_no    varchar(50),
   public_gazette_date  date,
   public_pat_id        varchar(50),
   create_date          timestamp      NOT NULL,
   raw_app_date         varchar(20),
   raw_public_date      varchar(20)
);

ALTER TABLE pat_ref_pct
   ADD CONSTRAINT pat_ref_pct_pkey
   PRIMARY KEY (pat_id);

CREATE TABLE pat_ref_priority
(
   pat_id        varchar(50)    NOT NULL,
   source_id     varchar(50)    NOT NULL,
   item          integer        NOT NULL,
   country       char(2),
   raw_app_no    varchar(50)    NOT NULL,
   app_no        varchar(50),
   app_date      date,
   pri_type      integer,
   pri_app_id    varchar(50),
   create_date   timestamp      NOT NULL,
   raw_app_date  varchar(20)
);

ALTER TABLE pat_ref_priority
   ADD CONSTRAINT pat_ref_priority_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_ref_related_child
(
   pat_id        varchar(50)    NOT NULL,
   source_id     varchar(50)    NOT NULL,
   item          integer        NOT NULL,
   related_type  integer        NOT NULL,
   parent_item   integer,
   raw_app_no    varchar(50),
   app_no        varchar(50),
   app_date      date,
   child_app_id  varchar(50),
   raw_doc_no    varchar(50),
   doc_no        varchar(50),
   child_pat_id  varchar(50),
   create_date   timestamp      NOT NULL,
   raw_app_date  varchar(20),
   app_country   char(2)
);

ALTER TABLE pat_ref_related_child
   ADD CONSTRAINT pat_ref_related_child_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE pat_ref_related_parent
(
   pat_id                  varchar(50)     NOT NULL,
   source_id               varchar(50)     NOT NULL,
   item                    integer         NOT NULL,
   related_type            integer         NOT NULL,
   raw_app_no              varchar(50),
   app_no                  varchar(50),
   app_date                date,
   parent_app_id           varchar(50),
   pat_status              varchar(50),
   raw_doc_no              varchar(50),
   doc_no                  varchar(50),
   doc_date                date,
   kind_code               varchar(2),
   inventor_name           varchar(200),
   parent_pat_id           varchar(50),
   raw_pct_app_no          varchar(50),
   pct_app_no              varchar(50),
   pct_app_date            date,
   pct_app_id              varchar(50),
   correction_code         varchar(50),
   correction_gazettle_no  varchar(50),
   create_date             timestamp       NOT NULL,
   raw_app_date            varchar(20),
   raw_doc_date            varchar(20),
   raw_pct_app_date        varchar(20),
   app_country             char(2),
   doc_country             char(2),
   gazette_public_date     date
);

ALTER TABLE pat_ref_related_parent
   ADD CONSTRAINT pat_ref_related_parent_pkey
   PRIMARY KEY (pat_id, source_id, item);

CREATE TABLE person_data
(
   person_id      uuid            NOT NULL,
   person_type    integer         NOT NULL,
   person_name    varchar,
   address        varchar(500),
   city           varchar(200),
   state          varchar(50),
   postcode       varchar(50),
   country        char(2),
   lang           char(5)         NOT NULL,
   person_facet   text            NOT NULL,
   create_date    timestamp       NOT NULL,
   last_upd_date  timestamp       NOT NULL
);

ALTER TABLE person_data
   ADD CONSTRAINT person_data_pkey
   PRIMARY KEY (person_id);

CREATE TABLE person_lang
(
   person_lang_id  integer     DEFAULT nextval('seq_person_lang_id'::regclass) NOT NULL,
   enabled_flag    integer      NOT NULL,
   create_date     timestamp    NOT NULL,
   last_upd_date   timestamp    NOT NULL
);

ALTER TABLE person_lang
   ADD CONSTRAINT person_lang_pkey
   PRIMARY KEY (person_lang_id);

CREATE TABLE person_lang_list
(
   person_lang_id  integer      NOT NULL,
   person_id       uuid         NOT NULL,
   create_date     timestamp    NOT NULL,
   last_upd_date   timestamp    NOT NULL
);

ALTER TABLE person_lang_list
   ADD CONSTRAINT person_lang_list_pkey
   PRIMARY KEY (person_lang_id, person_id);

CREATE TABLE source_data
(
   source_id      varchar(50)    NOT NULL,
   remark         varchar(50)    NOT NULL,
   create_date    timestamp      NOT NULL,
   last_upd_date  timestamp      NOT NULL
);

ALTER TABLE source_data
   ADD CONSTRAINT source_data_pkey
   PRIMARY KEY (source_id);


ALTER TABLE app_cur_assignee
  ADD CONSTRAINT app_cur_assignee_app_id_fkey FOREIGN KEY (app_id)
  REFERENCES app_data (app_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE job_data_import
  ADD CONSTRAINT job_data_import_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_cpc
  ADD CONSTRAINT pat_cls_cpc_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_cpc
  ADD CONSTRAINT pat_cls_cpc_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_cset
  ADD CONSTRAINT pat_cls_cset_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_cset
  ADD CONSTRAINT pat_cls_cset_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_di
  ADD CONSTRAINT pat_cls_di_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_di
  ADD CONSTRAINT pat_cls_di_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_dterm
  ADD CONSTRAINT pat_cls_dterm_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_dterm
  ADD CONSTRAINT pat_cls_dterm_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_ecla
  ADD CONSTRAINT pat_cls_ecla_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_ecla
  ADD CONSTRAINT pat_cls_ecla_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_fi
  ADD CONSTRAINT pat_cls_fi_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_fi
  ADD CONSTRAINT pat_cls_fi_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_field_of_search
  ADD CONSTRAINT pat_cls_field_of_search_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_field_of_search
  ADD CONSTRAINT pat_cls_field_of_search_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_fterm
  ADD CONSTRAINT pat_cls_fterm_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_fterm
  ADD CONSTRAINT pat_cls_fterm_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_ipc
  ADD CONSTRAINT pat_cls_ipc_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_ipc
  ADD CONSTRAINT pat_cls_ipc_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_loc
  ADD CONSTRAINT pat_cls_loc_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_loc
  ADD CONSTRAINT pat_cls_loc_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_uspc
  ADD CONSTRAINT pat_cls_uspc_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_cls_uspc
  ADD CONSTRAINT pat_cls_uspc_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_amend
  ADD CONSTRAINT pat_data_amend_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_amend
  ADD CONSTRAINT pat_data_amend_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_brief
  ADD CONSTRAINT pat_data_brief_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_brief
  ADD CONSTRAINT pat_data_brief_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_claims
  ADD CONSTRAINT pat_data_claims_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_claims
  ADD CONSTRAINT pat_data_claims_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_desc
  ADD CONSTRAINT pat_data_desc_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_desc
  ADD CONSTRAINT pat_data_desc_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_log
  ADD CONSTRAINT pat_data_log_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_memo
  ADD CONSTRAINT pat_data_memo_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_memo
  ADD CONSTRAINT pat_data_memo_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_title
  ADD CONSTRAINT pat_data_title_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_data_title
  ADD CONSTRAINT pat_data_title_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_event_record
  ADD CONSTRAINT pat_event_record_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_event_record
  ADD CONSTRAINT pat_event_record_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_event_record_change_log
  ADD CONSTRAINT pat_event_record_amend_log_record_id_fkey FOREIGN KEY (record_id)
  REFERENCES pat_event_record (record_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_agent
  ADD CONSTRAINT pat_person_agent_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_agent
  ADD CONSTRAINT pat_person_agent_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_agent
  ADD CONSTRAINT pat_person_agent_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_applicant
  ADD CONSTRAINT pat_person_applicant_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_applicant
  ADD CONSTRAINT pat_person_applicant_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_applicant
  ADD CONSTRAINT pat_person_applicant_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_assignee
  ADD CONSTRAINT pat_person_assignee_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_assignee
  ADD CONSTRAINT pat_person_assignee_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_assignee
  ADD CONSTRAINT pat_person_assignee_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_correspondence_addr
  ADD CONSTRAINT pat_person_correspondence_addr_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_correspondence_addr
  ADD CONSTRAINT pat_person_correspondence_addr_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_correspondence_addr
  ADD CONSTRAINT pat_person_correspondence_addr_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_examiner
  ADD CONSTRAINT pat_person_examiner_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_examiner
  ADD CONSTRAINT pat_person_examiner_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_examiner
  ADD CONSTRAINT pat_person_examiner_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_inventor
  ADD CONSTRAINT pat_person_inventor_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_inventor
  ADD CONSTRAINT pat_person_inventor_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_person_inventor
  ADD CONSTRAINT pat_person_inventor_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ptopid_mapping
  ADD CONSTRAINT ptopid_mapping_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_raw_cn
  ADD CONSTRAINT pat_pto_cn_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_raw_in
  ADD CONSTRAINT pat_raw_in_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_raw_kr
  ADD CONSTRAINT pat_raw_kr_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_raw_tw
  ADD CONSTRAINT pat_raw_tw_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited
  ADD CONSTRAINT pat_ref_cited_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited
  ADD CONSTRAINT pat_ref_cited_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited_cls
  ADD CONSTRAINT pat_ref_cited_cls_pat_id_fkey FOREIGN KEY (pat_id,source_id,cited_item)
  REFERENCES pat_ref_cited (pat_id,source_id,item)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited_npl
  ADD CONSTRAINT pat_ref_cited_npl_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited_npl
  ADD CONSTRAINT pat_ref_cited_npl_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_cited_npl_cls
  ADD CONSTRAINT pat_ref_cited_npl_cls_pat_id_fkey FOREIGN KEY (pat_id,source_id,cited_item)
  REFERENCES pat_ref_cited_npl (pat_id,source_id,item)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_hague
  ADD CONSTRAINT pat_ref_hague_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_pct
  ADD CONSTRAINT pat_ref_pct_pct_app_id_fkey FOREIGN KEY (pct_app_id)
  REFERENCES app_data (app_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_pct
  ADD CONSTRAINT pat_ref_pct_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_priority
  ADD CONSTRAINT pat_ref_priority_app_id_fkey FOREIGN KEY (pri_app_id)
  REFERENCES app_data (app_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_priority
  ADD CONSTRAINT pat_ref_priority_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_priority
  ADD CONSTRAINT pat_ref_priority_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_child
  ADD CONSTRAINT pat_ref_related_child_child_app_id_fkey FOREIGN KEY (child_app_id)
  REFERENCES app_data (app_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_child
  ADD CONSTRAINT pat_ref_related_child_child_pat_id_fkey FOREIGN KEY (child_pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_child
  ADD CONSTRAINT pat_ref_related_child_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_child
  ADD CONSTRAINT pat_ref_related_child_parent_item_fkey FOREIGN KEY (pat_id,source_id,parent_item)
  REFERENCES pat_ref_related_parent (pat_id,source_id,item)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_child
  ADD CONSTRAINT pat_ref_related_child_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_parent
  ADD CONSTRAINT pat_ref_related_parent_pat_id_fkey FOREIGN KEY (pat_id)
  REFERENCES pat_data (pat_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE pat_ref_related_parent
  ADD CONSTRAINT pat_ref_related_parent_source_id_fkey FOREIGN KEY (source_id)
  REFERENCES source_data (source_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE person_lang_list
  ADD CONSTRAINT person_lang_list_person_id_fkey FOREIGN KEY (person_id)
  REFERENCES person_data (person_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;

ALTER TABLE person_lang_list
  ADD CONSTRAINT person_lang_list_person_lang_id_fkey FOREIGN KEY (person_lang_id)
  REFERENCES person_lang (person_lang_id)
  ON UPDATE NO ACTION
  ON DELETE NO ACTION;


COMMIT;
