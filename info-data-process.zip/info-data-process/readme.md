# TODO

專利號碼標準化 http://redmine.scienbizip.com/redmine/projects/data_process/wiki/%E5%B0%88%E5%88%A9%E8%99%9F%E7%A2%BC%E6%A8%99%E6%BA%96%E5%8C%96