package itec.indexmaker.test;

import org.tsaikd.java.utils.ConfigUtils;

public class TestConfig {
    
    public String getConfigPatentCloudJDBCUrl(){
        return ConfigUtils.get("patentcloud.jdbc.url");
    }
    
    public static void main(String[] args) {
        TestConfig testConfig = new TestConfig();
        System.out.println(testConfig.getConfigPatentCloudJDBCUrl());
    }

}
