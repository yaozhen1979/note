package patent.loc.en;

import itec.patent.mongodb.LocarnoClass;
import itec.patent.mongodb.embed.MultiLangString;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

@Deprecated
public class ImportLocToMongoDB {

    static Log log = LogFactory.getLog(ImportLocToMongoDB.class);

    public static void main(String[] args) throws Exception {
        ConfigUtils.setSearchBase(ImportLocToMongoDB.class);
        log.debug("Start");

        addStream(ImportLocToMongoDB.class.getResourceAsStream("result.txt"));

        log.debug("Finished");
    }

    private static int addCount = 0;
    public static void addStream(InputStream is) throws Exception {
        LocarnoClass loc;
        String line;
        String[] cols;
        List<String> norLoc;
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ( (line = br.readLine()) != null ) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            if (line.startsWith("#")) {
                continue;
            }

            cols = line.split("<!>");
            if (cols.length < 2) {
                throw new Exception("Invalid line: " + line);
            }
            loc = new LocarnoClass();
            norLoc = LocarnoClass.normalize(cols[0].trim());
            loc.name = norLoc.get(0);
            loc.text = new MultiLangString();
            loc.text.en = cols[1].trim();
            loc.level = norLoc.size() - 1;
            if (loc.level > 1) {
                loc.parent = LocarnoClass.findOne(norLoc.get(1));
            }

            loc.save();
            addCount++;
            if (addCount % 100 == 0) {
                log.debug("Added " + addCount + " LOC");
            }
        }
        br.close();
    }

}
