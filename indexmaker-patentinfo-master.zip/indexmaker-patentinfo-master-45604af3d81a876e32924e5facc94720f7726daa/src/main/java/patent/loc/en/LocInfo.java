package patent.loc.en;

public class LocInfo {
    public String clazz;
    public String locNormal;
}
