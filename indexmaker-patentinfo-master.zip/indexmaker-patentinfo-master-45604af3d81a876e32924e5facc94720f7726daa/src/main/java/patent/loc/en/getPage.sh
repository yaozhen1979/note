#!/bin/bash

PN="${BASH_SOURCE[0]##*/}"
PD="${BASH_SOURCE[0]%/*}"

mainpage="enlnot.htm"

pushd "${PD}" >/dev/null

if [ ! -f "${mainpage}" ] ; then
    wget "http://www.wipo.int/classifications/nivilo/locarno/enlnot.htm"
fi

fname="result.txt"
if [ ! -f "${fname}" ] ; then
    for ((i=1 ; i<=32 ; i++)) ; do
        si="$(printf "%02d" "${i}")"
        lv1list="$(perl -ane 'undef $/; $_=<>;
s|<p class="classid"><a name="'${si}'">.*\s*.*\s*<p>(.*?)</p>|
    print "'${si}'", " <!> ", $1, "\n";
|ie;' < "${mainpage}")"
        while read line ; do
            lv1="${line:0:2}"
            echo "${line}" >> "${fname}"
            perl -ane 'undef $/; $_=<>;
s|<a name="('${lv1}'..)">.*\s*.*?<p>(.*?)</p>|
print $1, " <!> ", $2, "\n";
|ige;' < "${mainpage}" >> "${fname}"
        done <<<"${lv1list}"
    done
fi

popd >/dev/null

