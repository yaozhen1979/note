package patent.uspc.en;

import itec.patent.mongodb.USPatentClass;
import itec.patent.mongodb.base.BasePatentClass;
import itec.patent.mongodb.embed.MultiLangString;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.DBCollection;

@Deprecated
public class ImportUSpcToMongoDB {

    static Log log = LogFactory.getLog(ImportUSpcToMongoDB.class);

    public static void main(String[] args) throws Exception {
        ConfigUtils.setSearchBase(ImportUSpcToMongoDB.class);
        log.debug("Start");

        addStream(ImportUSpcToMongoDB.class.getResourceAsStream("result.txt"));

        log.debug("Finished");
    }

    private static Pattern patternUspc = Pattern.compile("(?i)^C(\\S{3})(S(\\S{3})(\\S{3}))?$");
    public static List<String> normalize(String str) {
        List<String> nor = new ArrayList<String>();
        Matcher matcherUspc = patternUspc.matcher(str);
        if (matcherUspc.find()) {
            String name, lv1, lv2, lv3 = null;
            lv1 = matcherUspc.group(1);
            if (lv1.isEmpty()) {
                lv1 = null;
            }
            name = lv1;

            lv2 = matcherUspc.group(3);
            if (lv2 != null) {
                lv2 = lv2.replaceAll("^0*", "");
                if (lv2.isEmpty()) {
                    lv2 = null;
                } else {
                    name += "/" + lv2;
                    lv3 = matcherUspc.group(4);
                    if (lv3 != null) {
                        lv3 = lv3.replaceAll("0*$", "");
                        if (lv3.isEmpty()) {
                            lv3 = null;
                        } else {
                            name += "." + lv3;
                        }
                    }
                }
            }

            nor.add(name);
            nor.add(lv1);
            nor.add(lv2);
            nor.add(lv3);
        } else {
            nor.add(str);
            nor.add(null);
            nor.add(null);
            nor.add(null);
        }
        return nor;
    }

    private static int addCount = 0;
    public static void addStream(InputStream is) throws Exception {
        USPatentClass uspc;
        String line, opc, text, oparent;
        int level;
        String[] cols;
        List<String> nor, norParent;
        DBCollection col = MappedClass.getMappedClass(USPatentClass.class).getCol();
        Date msgTime = new Date(new Date().getTime() + 5000);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ( (line = br.readLine()) != null ) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            if (line.startsWith("#")) {
                continue;
            }

            cols = line.split("<!>");
            if (cols.length < 3) {
                throw new Exception("Invalid line: " + line);
            }
            opc = cols[0].trim();
            nor = normalize(opc);
            level = Integer.parseInt(cols[1].trim()) + 1;
            text = cols[2].trim();
            if (cols.length > 3) {
                oparent = cols[3].trim();
                norParent = normalize(oparent);
            } else {
                oparent = null;
                norParent = null;
            }

            uspc = new USPatentClass();
            uspc.name = nor.get(0);
            uspc.level = level;
            uspc.text = new MultiLangString();
            uspc.text.en = text;
            if (norParent != null) {
                QueryHelp query = new QueryHelp();
                query.filter("name", norParent.get(0));
                uspc.parent = (BasePatentClass) USPatentClass.fromObject(USPatentClass.class, col.findOne(query));
            }

            uspc.save();
            addCount++;
            if (msgTime.before(new Date())) {
                msgTime = new Date(new Date().getTime() + 5000);
                log.debug("Added " + addCount + " USPC");
            }
        }
        br.close();
        log.debug("Added " + addCount + " USPC");
    }

}
