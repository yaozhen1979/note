#!/bin/bash

PN="${BASH_SOURCE[0]##*/}"
PD="${BASH_SOURCE[0]%/*}"

mainpage="selectnumwithtitle.htm"

pushd "${PD}" >/dev/null

if [ ! -f "${mainpage}" ] ; then
    wget "http://www.uspto.gov/web/patents/classification/selectnumwithtitle.htm"
fi

mainClassList="$(perl -ane 's|<font[^<>]+>([^<>]{3})</font>.+?<font[^<>]+>([^<>]+)</font>|print lc($1)," <!> ",$2,"\n"|e' < "${mainpage}")"

fname="result.txt"
if [ ! -f "${fname}" ] ; then
    while read line ; do
        mc="$(awk -F '<!>' '{print $1}' <<<"${line}" | sed 's/^\s*//; s/\s*$//')"
        text="$(awk -F '<!>' '{print $2}' <<<"${line}" | sed 's/^\s*//; s/\s*$//')"
        if [ ! -f "sched${mc}.htm" ] ; then
            wget "http://www.uspto.gov/web/patents/classification/uspc${mc}/sched${mc}.htm"
        fi

        echo "C${mc} <!> 0 <!> ${text} <!>" >> "${fname}"
        perl -ane '
$level[0] = "'C${mc}'";
sub trim($) {
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}
sub replace_star($) {
    my $string = shift;
    $string =~ s/\*/_/g;
    $string =~ s/\s/_/g;
    return $string;
}
s|<a name="(C.{3}S.{6})".+|
    $name = replace_star(trim($1));
    $lv = -1;
    $text = "";
    print $name;
    s~<big></big>([^<>]+?)</b>~
        $lv = 1;
        $text = trim($1);
    ~e;
    if ($lv == -1) {
        s~<big><img src="[^<>]+?(\d)_dots[^<>]+?"[^<>]+?></big>.*?([^<>]+?)</~
            $lv = trim($1) + 1;
            $text = trim($2);
        ~e;
    }
    if ($lv == -1) {
        s~<big></big>(.+?)</b>~
            $lv = 1;
            $text = trim($1);
        ~e;
    }
    if ($lv == -1) {
        print STDERR "Unknown level for line: ",$&,"\n";
    } else {
        $level[$lv] = $name;
    }
    print " <!> ",$lv," <!> ",$text;
    if ($lv > 0) {
        print " <!> ",$level[($lv-1)];
    }
    print "\n";
|ie;
        ' < "sched${mc}.htm" >> "${fname}"
    done <<<"${mainClassList}"
fi

popd >/dev/null

