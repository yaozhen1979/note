package patent.download;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * 
 * @author yingjieyang
 *
 */
public class USRawDownload {
    static String download_url ;
    static String proxy_ip ;
    static String proxy_port;
    static String sourcePath ;
    
    
    /**
     * US 下載zip檔文件
     * 
     * @param proxy_ip
     * @param proxy_port
     * @param sourcePath
     */
    public void downloadFile(String[] args){
        proxy_ip = args[0];
        proxy_port = args[1];
        sourcePath = args[2];
        Calendar cal = Calendar.getInstance();
        
        int year = cal.get(Calendar.YEAR);
        int day_of_week = cal.get(Calendar.DAY_OF_WEEK);
        //更換下載來源，從之前的Google切換到USPTO官網
        if(day_of_week==3){
            download_url = "http://patents.reedtech.com/downloads/GrantRedBookText/"+year+"/ipg"+getWeekDate(2).substring(2)+".zip";
        }else if(day_of_week==5){
            download_url = "http://patents.reedtech.com/downloads/ApplicationFullText/"+year+"/ipa"+getWeekDate(4).substring(2)+".zip";
        }
        System.setProperty("http.proxyHost", proxy_ip);
        System.setProperty("http.proxyPort",proxy_port );
        try {
            URL u = new URL(download_url);
            URLConnection conn = u.openConnection();
            InputStream is = conn.getInputStream();
            System.out.println("just waiting for a moment,just download files..");
            byte[] b = new byte[1024];
            int len=0;
            OutputStream os = new FileOutputStream(sourcePath+File.separator+download_url.substring(download_url.length()-13));
            while((len=is.read(b))!=-1){
                os.write(b, 0, len);
            }
            os.close();
            is.close();
            System.out.println(download_url.substring(download_url.length()-13)+" download success...");
        }catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public static String getWeekDate(int weekNumber){
        String weekDateStr=null;
        Calendar cal = Calendar.getInstance();
        int week = cal.get(Calendar.DAY_OF_WEEK) - 1;
        cal.add(Calendar.DATE, -week);
        cal.add(Calendar.DATE, weekNumber);
        weekDateStr=dateToStr(cal.getTime());
        return weekDateStr;
    }
    
    public static String dateToStr(java.util.Date dateDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String dateString = formatter.format(dateDate);
        return dateString;
    }
    
}
