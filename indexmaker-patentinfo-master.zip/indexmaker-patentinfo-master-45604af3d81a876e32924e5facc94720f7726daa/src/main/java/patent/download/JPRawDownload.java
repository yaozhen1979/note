package patent.download;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

public class JPRawDownload {

    private static String access_key = "AKIAJ2XCVX2233TLZTLQ";
    private static String secret_access_key = "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";

    private static String bucket_name = "forsynergytek";
    public static String key;
    public static String path;

    public boolean Download(String key, String path) {
        boolean flag = false;
        AWSCredentials basicCred = new BasicAWSCredentials(access_key,
                secret_access_key);
        ClientConfiguration clientCfg = new ClientConfiguration();

        // setup proxy connection:
        clientCfg.setProtocol(Protocol.HTTP);
        clientCfg.setProxyHost("10.60.94.41");
        clientCfg.setProxyPort(3128);
        AmazonS3 s3 = new AmazonS3Client(basicCred, clientCfg);

        System.out.println("Downloading the file:" + key);
        S3Object object = s3.getObject(new GetObjectRequest(bucket_name, key));
        InputStream reader = new BufferedInputStream(object.getObjectContent());
        File file = new File(path + key);
        OutputStream writer;
        byte[] b = new byte[1024];
        int len = 0;
        try {
            writer = new FileOutputStream(file);
            while ((len = reader.read(b)) != -1) {
                writer.write(b, 0, len);
            }
            flag = true;
            writer.close();
            reader.close();
            System.out.println("Download finshed:" + key);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public static void main(String args[]) {
        key = args[0];
        path = args[1];
        JPRawDownload download = new JPRawDownload();
        download.Download(key, path);

    }

}

