package patent.download;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class TipoRawDownload {

    private static String issueURL = "http://twpat.tipo.gov.tw/tipotwo/help/download/gfree/";

    private static String pubURL = "http://twpat.tipo.gov.tw/tipotwo/help/download/afree/";

    private static String proxy_ip = "10.60.94.21";
    private static String proxy_port = "3128";

    private static String downloadURL;

    public boolean downloadIssued(String path, String zipname) {
        boolean flag = false;
        downloadURL = issueURL + zipname;
        System.out.println(downloadURL);
        try {
            System.setProperty("http.proxyHost", proxy_ip);
            System.setProperty("http.proxyPort", proxy_port);
            URL u = new URL(downloadURL);
            URLConnection conn = u.openConnection();
            InputStream is = conn.getInputStream();
            byte[] b = new byte[1024];
            int len = 0;
            OutputStream os = new FileOutputStream(path + File.separator
                    + zipname);
            System.out.println(zipname + " downloading...");
            while ((len = is.read(b)) != -1) {
                os.write(b, 0, len);
            }
            os.close();
            is.close();
            flag = true;
            System.out.println(zipname + " download finish");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean downloadPub(String path, String zipname) {
        boolean flag = false;
        downloadURL = pubURL + zipname;
        System.out.println(downloadURL);
        try {
            System.setProperty("http.proxyHost", proxy_ip);
            System.setProperty("http.proxyPort", proxy_port);
            URL u = new URL(downloadURL);
            URLConnection conn = u.openConnection();
            InputStream is = conn.getInputStream();
            byte[] b = new byte[1024];
            int len = 0;
            OutputStream os = new FileOutputStream(path + File.separator
                    + zipname);
            System.out.println(zipname + " downloading...");
            while ((len = is.read(b)) != -1) {
                os.write(b, 0, len);
            }
            os.close();
            is.close();
            flag = true;
            System.out.println(zipname + " download finish");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public static void main(String args[]) {
        TipoRawDownload down = new TipoRawDownload();
        String path = args[0];
        String zipname = args[1];
        String pni = args[2];
        if (pni.contains("P")) {
            down.downloadPub(path, zipname);
        } else {
            down.downloadIssued(path, zipname);
        }
    }

}
