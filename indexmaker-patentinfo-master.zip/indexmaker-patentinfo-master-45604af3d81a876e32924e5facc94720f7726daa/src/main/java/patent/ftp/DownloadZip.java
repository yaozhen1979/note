package patent.ftp;

import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.tsaikd.java.utils.ArgParser;

import patent.update.utils.HttpClientTool;

public class DownloadZip {

    public static final String opt_proxy_host = "proxy.host";
    public static final String opt_proxy_host_default = "10.60.94.41";

    public static final String opt_proxy_port = "proxy.port";
    public static final String opt_proxy_port_default = "3128";    
    
    public static final String opt_proxy_user = "proxy.user";
    public static final String opt_proxy_user_default = "";
    
    public static final String opt_proxy_password = "proxy.password";
    public static final String opt_proxy_password_default = "";
    
    public static final String opt_netLogin_user = "login.user";
    public static final String opt_netLogin_user_default = "sherrylin@patentcloud.com";
    
    public static final String opt_netLogin_password = "login.password";
    public static final String opt_netLogin_password_default = "NU3q&TShn7:u";
    
    public static final String opt_index_url = "index.url";  
    public static final String opt_index_url_default = "https://publication.epo.org/raw-data/authentication";
    
    public static final String opt_second_index_url = "second_index.url";  
    public static final String opt_second_index_url_default = "https://publication.epo.org/raw-data/product?productId=29";
    
    public static final String opt_local_path = "local.path";
    public static final String opt_local_path_default = "F:\\EP_download";
    
    public static final String opt_year_week_string = "year.week.string";
    public static final String opt_year_week_string_default = "2015030";
    
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_proxy_host, true, opt_proxy_host_default, "downLoad zip proxy"),
        new ArgParser.Option(null, opt_proxy_port, true, opt_proxy_port_default, "port"),
        new ArgParser.Option(null, opt_proxy_user, true, opt_proxy_user_default, "proxy user"),
        new ArgParser.Option(null, opt_proxy_password, true, opt_proxy_password_default, "proxy password"),
        new ArgParser.Option(null, opt_netLogin_user, true, opt_netLogin_user_default, "login user"),
        new ArgParser.Option(null, opt_netLogin_password, true, opt_netLogin_password_default, "login password"),
        new ArgParser.Option(null, opt_index_url, true, opt_index_url_default, "index url"),
        new ArgParser.Option(null, opt_second_index_url, true, opt_second_index_url_default, "second_index url"),
        new ArgParser.Option(null, opt_local_path, true, opt_local_path_default, "local.path"),
        new ArgParser.Option(null, opt_year_week_string, true, opt_year_week_string_default, "year.week.string"),
    };
    
    public static void main(String[] args) throws Exception {
        DownloadZip downloadZip = new DownloadZip();
        downloadZip.worker(args);

    }

    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(DownloadZip.class).parse(args);
        String proxy_host = argParser.getOptString(opt_proxy_host);
        int proxy_port = Integer.parseInt(argParser.getOptString(opt_proxy_port));
        String proxy_user = argParser.getOptString(opt_proxy_user);
        String proxy_password = argParser.getOptString(opt_proxy_password);
        String netLogin_user = argParser.getOptString(opt_netLogin_user);
        String netLogin_password = argParser.getOptString(opt_netLogin_password);
        String index_url = argParser.getOptString(opt_index_url);
        String second_index_url = argParser.getOptString(opt_second_index_url);
        String local_path = argParser.getOptString(opt_local_path);
        String opt_year_week = argParser.getOptString(opt_year_week_string);
        
        Map<String , String> postParams = new HashMap<String , String>();
         postParams.put("login", netLogin_user);
         postParams.put("pwd", netLogin_password);
         postParams.put("action", "1");
         postParams.put("submit", "Log in");
        
        Calendar cal = Calendar.getInstance();
        local_path = local_path + File.separator +String.valueOf(cal.get(Calendar.YEAR)) + File.separator + "downloadTmp";
        
        HttpClientTool httpClientTool = new HttpClientTool(proxy_host, proxy_port, proxy_user, proxy_password, local_path);
        httpClientTool.configProxy(proxy_host, proxy_port, proxy_user, proxy_password);
        httpClientTool.downEPZip(index_url, second_index_url, postParams, local_path, opt_year_week);
    }

    
}
