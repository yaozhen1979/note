package patent.ftp;

import java.io.File;

import it.sauronsoftware.ftp4j.FTPClient;

import org.tsaikd.java.utils.ArgParser;

import patent.update.status.PatentUpdateStatus;
import patent.update.utils.FtpTool;

/**
 * 
 * @author luken
 * Download ftp file throw proxy
 *
 */
public class DownloadFtpFileKR {
    
    public static final String opt_ftp_host = "ftp.host";
    public static final String opt_ftp_host_default = "203.242.169.32";

    public static final String opt_ftp_port = "ftp.port";
    public static final String opt_ftp_port_default = "21";    
    
    public static final String opt_ftp_user = "ftp.user";
    public static final String opt_ftp_user_default = "kr_pat";
    
    public static final String opt_ftp_password = "ftp.password";
    public static final String opt_ftp_password_default = "kr_pat";
    
    public static final String opt_proxy_host = "proxy.host";
    public static final String opt_proxy_host_default = "10.60.94.41";

    public static final String opt_proxy_port = "proxy.port";
    public static final String opt_proxy_port_default = "3128";    
    
    public static final String opt_remote_path = "remote.path";  //More comma-separated paths available
    public static final String opt_remote_path_default = "null";
    
    public static final String opt_local_path = "local.path";
    public static final String opt_local_path_default = "c:\\";
    
    
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_ftp_host, true, opt_ftp_host_default, ""),
        new ArgParser.Option(null, opt_ftp_port, true, opt_ftp_port_default, ""),
        new ArgParser.Option(null, opt_ftp_user, true, opt_ftp_user_default, ""),
        new ArgParser.Option(null, opt_ftp_password, true, opt_ftp_password_default, ""),
        new ArgParser.Option(null, opt_proxy_host, true, opt_proxy_host_default, ""),
        new ArgParser.Option(null, opt_proxy_port, true, opt_proxy_port_default, ""),
        new ArgParser.Option(null, opt_remote_path, true, opt_remote_path_default, ""),
        new ArgParser.Option(null, opt_local_path, true, opt_local_path_default, ""),
    };
    
    
    public static void main(String[] args) throws Exception {
        DownloadFtpFileKR downloadFtpFileKR = new DownloadFtpFileKR();
        downloadFtpFileKR.worker(args);        
    }
    
    public void worker(String[] args) throws Exception{
        
        ArgParser argParser = new ArgParser().addOpt(DownloadFtpFileKR.class).parse(args);
        String ftpHost=argParser.getOptString(opt_ftp_host);
        int ftpPort=Integer.parseInt(argParser.getOptString(opt_ftp_port));
        String ftpUser=argParser.getOptString(opt_ftp_user);
        String ftpPassword=argParser.getOptString(opt_ftp_password);
        
        String proxyHost= argParser.getOptString(opt_proxy_host);
        int proxyPort= Integer.parseInt(argParser.getOptString(opt_proxy_port));
        
        String remotePath= argParser.getOptString(opt_remote_path);
        String localPath= argParser.getOptString(opt_local_path);
        
        File localFile = new File(localPath);
        if(!localFile.exists()){
            localFile.mkdirs();
        }
                
        String[] patList=remotePath.split(",");
        FtpTool patTool =new FtpTool(ftpUser, ftpPassword, ftpHost, ftpPort,proxyHost,proxyPort);
        FTPClient patClient = patTool.getFtpConnect();    
        patTool.downloadList(patClient, patList, localPath);        
    }

}
