package patent.ipc.en;

public enum ClassificationType {
    IPC, CPC
}
