package patent.ipc.en;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class IpcCpcFinder {

    private static Map<String, Ipc> ipcMap = new HashMap<String, Ipc>();
    private static Map<String, Ipc> cpcMap = new HashMap<String, Ipc>();

    public static void load() throws Exception {
        load("ipc", ipcMap);
        if (ipcMap.size() < 83486) {
            throw new Exception("ipc size less than 83486");
        }
        load("cpc", cpcMap);
        if (cpcMap.size() < 266838) {
            throw new Exception("cpc size less than 266838");
        }
    }
    
    private static void load(String table, Map<String, Ipc> ipcMap) throws Exception {
        
        Class.forName("net.sourceforge.jtds.jdbc.Driver");
        
        Connection conn = DriverManager.getConnection("jdbc:jtds:sqlserver://10.60.90.47:1433/PatentCloudDev", "sa", "itec.sql.123");
        
        ResultSet rs = conn.createStatement().executeQuery("select * from " + table);
        
        while (rs.next()) {
            Ipc ipc = new Ipc();
            ipc.id = rs.getString("id");
            ipc.parentId = rs.getString("parentId");
            ipc.symbol = rs.getString("symbol");
            ipc.title = rs.getString("title");
            ipc.level = rs.getInt("level");
            ipc.subGroup = rs.getString("subGroup");
            ipc.mainGroup = rs.getString("mainGroup");
            ipcMap.put(ipc.id, ipc);
        }
    }
    
    public static String getSubGroup(Enum<ClassificationType> type, String ipcId) {
        Ipc ipc = null;
        if (type == ClassificationType.IPC) {
            ipc = ipcMap.get(ipcId);
        } else {
            ipc = cpcMap.get(ipcId);
        }
        if (ipc != null) {
            return ipc.subGroup;
        }
        return null;
    }
    
    public static String getMainGroup(Enum<ClassificationType> type, String ipcId) {
        Ipc ipc = null;
        if (type == ClassificationType.IPC) {
            ipc = ipcMap.get(ipcId);
        } else {
            ipc = cpcMap.get(ipcId);
        }
        if (ipc != null) {
            return ipc.mainGroup;
        }
        return null;
    }
    
}
