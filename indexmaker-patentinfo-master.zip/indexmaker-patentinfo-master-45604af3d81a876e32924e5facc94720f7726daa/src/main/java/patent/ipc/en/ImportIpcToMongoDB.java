package patent.ipc.en;

import itec.patent.mongodb.InterPatentClass;
import itec.patent.mongodb.embed.MultiLangString;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

@Deprecated
public class ImportIpcToMongoDB {

    static Log log = LogFactory.getLog(ImportIpcToMongoDB.class);

    private static Pattern patternLine = Pattern.compile("^(\\S+)\\s+(.+)$");
    private static Pattern patternIpc = Pattern.compile("^(\\S)(\\S\\S)(\\S)(\\d{4})(\\d{3})(\\d{3})$");

    public static void main(String[] args) throws Exception {
        ConfigUtils.setSearchBase(ImportIpcToMongoDB.class);
        log.debug("Start");

        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_A_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_B_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_C_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_D_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_E_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_F_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_G_title_list_20120101.txt"));
        addStream(ImportIpcToMongoDB.class.getResourceAsStream("EN_ipc_section_H_title_list_20120101.txt"));

        log.debug("Finished");
    }

    private static int addCount = 0;
    public static void addStream(InputStream is) throws Exception {
        InterPatentClass ipc;
        String line, oipc, text, fipc, fipclv1, fipclv2, fipclv3, fipclv4, fipclv5;
        int level;
        Matcher matcherLine, matcherIpc;
        Date msgTime = new Date(new Date().getTime() + 5000);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ( (line = br.readLine()) != null ) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            if (line.startsWith("#")) {
                continue;
            }

            level = 0;
            matcherLine = patternLine.matcher(line);
            if (matcherLine.find()) {
                oipc = matcherLine.group(1);
                text = matcherLine.group(2);
                if (oipc.length() <= 4) {
                    fipc = oipc;
                    fipclv1 = oipc.substring(0, 1);
                    level = 1;
                    if (oipc.length() > 1) {
                        fipclv2 = oipc.substring(1, 3);
                        level = 2;
                    } else {
                        fipclv2 = null;
                    }
                    if (oipc.length() > 3) {
                        fipclv3 = oipc.substring(3, 4);
                        level = 3;
                    } else {
                        fipclv3 = null;
                    }
                    fipclv4 = null;
                    fipclv5 = null;
                } else {
                    matcherIpc = patternIpc.matcher(oipc);
                    if (!matcherIpc.find()) {
                        throw new Exception("Unknown IPC format: " + oipc);
                    }
                    fipclv1 = matcherIpc.group(1);
                    fipclv2 = matcherIpc.group(2);
                    fipclv3 = matcherIpc.group(3);
                    fipclv4 = matcherIpc.group(4);
                    fipclv4 = fipclv4.replaceAll("^0+", "");
                    if (fipclv4.isEmpty()) {
                        fipclv4 = "0";
                    }
                    fipclv5 = matcherIpc.group(5);
                    fipclv5 = fipclv5.replaceAll("0+$", "");
                    while (fipclv5.length() < 2) {
                        fipclv5 += "0";
                    }
                    if (fipclv5.equals("00")) {
                        level = 4;
                    } else {
                        level = 5;
                    }
                    String fipclv6 = matcherIpc.group(6);
                    fipclv6 = fipclv6.replaceAll("0+$", "");
                    if (!fipclv6.isEmpty()) {
                        fipclv5 += "." + fipclv6;
                    }
                    fipc = fipclv1 +
                            fipclv2 +
                            fipclv3 +
                            " " +
                            fipclv4 +
                            "/" +
                            fipclv5;
                }
            } else {
                throw new Exception("Unknown line format: " + line);
            }

            ipc = new InterPatentClass();
            ipc.name = fipc;
            ipc.text = new MultiLangString();
            ipc.text.en = text.trim();
            ipc.level = level;
            switch (ipc.level) {
            case 2:
                ipc.parent = InterPatentClass.findOne(fipclv1);
                break;
            case 3:
                ipc.parent = InterPatentClass.findOne(fipclv1 + fipclv2);
                break;
            case 4:
                ipc.parent = InterPatentClass.findOne(fipclv1 + fipclv2 + fipclv3);
                break;
            case 5:
                ipc.parent = InterPatentClass.findOne(fipclv1 + fipclv2 + fipclv3 + " " + fipclv4 + "/00");
                break;
            default:
                break;
            }

            ipc.save();
            addCount++;
            if (msgTime.before(new Date())) {
                msgTime = new Date(new Date().getTime() + 5000);
                log.debug("Added " + addCount + " IPC");
            }
        }
        br.close();
        log.debug("Added " + addCount + " IPC");
    }

}
