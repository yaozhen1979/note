package patent.ipc.en;



public class IpcHierarchInfo<T> {
    int level;
    String parId;
}

