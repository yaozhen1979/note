package patent.ipc.en;


public class IpcInfo {
    public String clazz;
    public String subClazz;
    public String group;
    public String subGroup;
    public String ipcNormal;
}
