package patent.ipc.en;

import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Scanner;

import org.tsaikd.java.mongodb.QueryHelp;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class IpcSubGroupFinder {

    private static MongoCredential credential;
    private static MongoClient mongoClient;
    private static DB db;
    private static DBCollection col;
    private static Hashtable<String, IpcHierarchInfo> ipcParHash = new Hashtable<String, IpcHierarchInfo>();

    public static void comupterIpcHierarchHash() throws UnknownHostException {
        credential = MongoCredential.createCredential("patentdata", "admin", "data.cloud.Abc12345".toCharArray());
        mongoClient = new MongoClient(new ServerAddress("10.60.90.101"), Arrays.asList(credential));
        db = mongoClient.getDB("admin").getSisterDB("ClassificationMap");
        col = db.getCollection("Ipc");
//        QueryHelp dateRangeQuery = new QueryHelp();
//        dateRangeQuery.filter("$gte", 6);
        QueryHelp query = new QueryHelp();
       // query.filter("Level", dateRangeQuery);
        DBCursor cursor= col.find(query);
        
        while(cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            String id = dbobj.get("_id").toString();
            int level = Integer.parseInt(dbobj.get("Level").toString());
            String parent ="";
            if(level !=1) {
                parent = dbobj.get("patentId").toString();
            }
            //System.out.println("id: " + id + " level: " + level + " parent:" + parent);
            IpcHierarchInfo ipcHier = new IpcHierarchInfo();
            ipcHier.level = level;
            ipcHier.parId = parent;
            ipcParHash.put(id, ipcHier);
        }
    }

    public static String getIpcSubGroup(String ipc) {
        String subGroup = "";
        IpcHierarchInfo ipcHier = ipcParHash.get(ipc);
            if(ipcHier != null) {
            switch(ipcHier.level) { 
            case 1: 
            case 2:
            case 3:
            case 4:
                return null;
            case 5: 
                return ipc;
            case 6: 
                return ipcHier.parId;
            default: 
                return getIpcSubGroup(ipcHier.parId);
            }
        } else {
            //System.out.println("can't find ipc at db: " + ipc);
            return null;
        }
    }
    public static void main(String[] args) throws UnknownHostException  {

        comupterIpcHierarchHash();
        Scanner scanner = new Scanner(System.in);
        System.out.println("input ipc");
        while(true) {
            String ipc = scanner.next();
            System.out.println("sub group: " + getIpcSubGroup(ipc));
        }
    }
}
