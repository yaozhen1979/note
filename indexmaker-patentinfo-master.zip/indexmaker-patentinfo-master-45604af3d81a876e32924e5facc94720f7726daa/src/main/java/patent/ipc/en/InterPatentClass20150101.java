package patent.ipc.en;

import itec.patent.mongodb.InterPatentClass;

public class InterPatentClass20150101 extends InterPatentClass {
}
