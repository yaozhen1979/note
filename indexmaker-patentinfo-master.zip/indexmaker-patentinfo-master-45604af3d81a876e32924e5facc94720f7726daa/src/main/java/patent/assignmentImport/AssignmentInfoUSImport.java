package patent.assignmentImport;

import itec.patent.assignment.us.AssignmentInfoUSPTO;
import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.AssignmentCountry;
import itec.patent.mongodb.embed.MongoSyncFlag;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class AssignmentInfoUSImport {

    static Log log = LogFactory.getLog(AssignmentInfoUSImport.class);
    static Log solr_log = LogFactory.getLog("solr_log");
    public static final String opt_pto = "pto";
    public static final String opt_pto_default = "us";
    public static final String opt_path_default = "ad20140715.zip";

    public static ArgParser.Option[] opts = {
                    new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
            new ArgParser.Option("path", null, true, "",
                    "Patent open/decision date rage\n"
                            + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                            + "Format: YYYYMMDD+n (20110101+31)\n"
                            + "Format: YYYYMM+n (201101+12)\n"
                            + "Format: YYYYMM+n (2011+1)\n"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    static {
        ConfigUtils.setSearchBase(AssignmentInfoUSImport.class);
    }

    public static void main(String[] args) throws Exception {
        AssignmentInfoUSImport worker = new AssignmentInfoUSImport();
        worker.worker(args);
    }

    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(AssignmentInfoUSImport.class)
                .parse(args);
        MongoAuthInitUtils.reload(argParser);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        AssignmentCountry pto = AssignmentCountry.valueOf(argParser.getOptString(opt_pto));

        String path = argParser.getOptString("path");
        //String pn = "US005998925";
        //QueryHelp query = new QueryHelp();
        //query.filter("patentNumber", pn);
        if (path != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + path);
        //    Thread.sleep(5000);
        }

        log.debug("counting total documents");
        BasicDBObject dbo=new BasicDBObject();
        dbo.put("patentNumber", "6054321");
        DBCollection col = AssignmentInfoUSPTO.getCollection(pto);
        DBCursor cursor = col.find(dbo);
        ProcessEstimater pe = new ProcessEstimater(cursor.count())
                .setFormatDefNum();
    //    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
         Date dt=new Date();
        log.debug("start import");
        MongoSyncFlag flag = new MongoSyncFlag();
        flag.last=dt;
        while (cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            try {
                AssignmentInfoUSPTO mongoInfo = (AssignmentInfoUSPTO) AssignmentInfoUSPTO.fromObject(pto, dbobj);
                String xml = (String) mongoInfo.conveyanceText;
                String relid = mongoInfo.id.toString();
                ArrayList<String> appnum = mongoInfo.appNumber;
                ArrayList<String> assigneename = mongoInfo.assigneeName;
                ArrayList<String> assigneeCity = mongoInfo.assigneeCity;
                ArrayList<String> assigneeState = mongoInfo.assigneeState;
                ArrayList<String> assigneecountry = mongoInfo.assigneeCountry;
                
                for(int m =0 ;m<assigneename.size(); m++){
                    String city = "";
                    String state = "";
                    String country = "";
                    if(assigneeCity.get(m)!=null){
                        city = assigneeCity.get(m);
                    }
                    if(assigneeState.get(m)!=null){
                        state = assigneeState.get(m);
                    }
                    if(assigneecountry.get(m)!=null){
                        country = assigneecountry.get(m);
                    }
                    System.out.println(assigneename.get(m)+" "+city+","+state+","+country);
                }
                
                pe.addNum().debug(log, 5000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        pe.debug(log);
        log.debug("finish");
    }

    private QueryHelp getDateRange(String date_range) {
        if (date_range == null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype,
                    calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }

}
