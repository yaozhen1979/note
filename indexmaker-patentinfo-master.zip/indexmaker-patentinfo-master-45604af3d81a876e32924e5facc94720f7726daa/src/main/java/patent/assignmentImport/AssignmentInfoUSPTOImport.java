package patent.assignmentImport;

import itec.patent.assignment.us.AssignmentInfoUSPTO;
import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.AssignmentCountry;
import itec.patent.mongodb.AssignmentRaw;
import itec.patent.mongodb.assignmentraw.AssignmentRawUSPTO;
import itec.patent.mongodb.embed.MongoSyncFlag;

import java.io.File;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import patetn.assignment.AnalysisAssignMent;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class AssignmentInfoUSPTOImport {

    static Log log = LogFactory.getLog(AssignmentInfoUSPTOImport.class);
    static Log solr_log = LogFactory.getLog("solr_log");
    public static final String opt_pto = "pto";
    public static final String opt_pto_default = "us";
    public static final String opt_path_default = "ad20131231-06.zip";

    public static ArgParser.Option[] opts = {
                    new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
            new ArgParser.Option("path", null, true, "",
                    "Patent open/decision date rage\n"
                            + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                            + "Format: YYYYMMDD+n (20110101+31)\n"
                            + "Format: YYYYMM+n (201101+12)\n"
                            + "Format: YYYYMM+n (2011+1)\n"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    static {
        ConfigUtils.setSearchBase(AssignmentInfoUSPTOImport.class);
    }

    public static void main(String[] args) throws Exception {
        AssignmentInfoUSPTOImport worker = new AssignmentInfoUSPTOImport();
        worker.worker(args);
    }

    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(AssignmentInfoUSPTOImport.class)
                .parse(args);
        MongoAuthInitUtils.reload(argParser);
    //    MongoInitUtils.reload();
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        AssignmentCountry pto = AssignmentCountry.valueOf(argParser.getOptString(opt_pto));
    //    String[] pathlist = {"ad20140101.zip","ad20140102.zip","ad20140103.zip","ad20140104.zip","ad20140105.zip","ad20140106.zip","ad20140107.zip","ad20140108.zip","ad20140109.zip","ad20140110.zip"};
        File f = new File("c:/us/");
        File file[];
        file = f.listFiles();
        if(file!=null){
            

        for (int i = 0; i < file.length; i++) {
            String path = file[i].getName();
        //String pn = "US005998925";
        //QueryHelp query = new QueryHelp();
        //query.filter("patentNumber", pn);
        if (path != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + path);
        //    Thread.sleep(5000);
        }

        log.debug("counting total documents");
        DBCollection col = AssignmentRaw.getCollection(pto);
        DBCursor cursor = col.find(new QueryHelp("path", path)).sort(new BasicDBObject("path", 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count())
                .setFormatDefNum();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
         Date dt=new Date();
        log.debug("start import");
        MongoSyncFlag flag = new MongoSyncFlag();
        flag.init=dt;
        flag.last=dt;
        AssignmentInfoUSPTO
        .remove(AssignmentInfoUSPTO.class, new QueryHelp("path",
                path));
        while (cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            try {
                 AssignmentRawUSPTO mongoInfo = (AssignmentRawUSPTO) AssignmentRawUSPTO.fromObject(pto, dbobj);
                String xml = (String) mongoInfo.data.get("xml");
                String relid = mongoInfo.id.toString();
                AnalysisAssignMent assignMent =new AnalysisAssignMent();
                AssignmentInfoUSPTO as = assignMent.parse(xml);
                if(as!=null){
                    as.setRel_id(relid);
                    as.setPath(path);
                    as.setDoDate(dt);
                    as.setMongoSyncFlag(flag);
                    as.save();
                    pe.addNum().debug(log, 5000);
                }else{
                    solr_log.error(path);
                }
                
            } catch (Exception e) {
                solr_log.error(path,e);
                e.printStackTrace();
            }
        }
        //pe.debug(log);
        log.debug("finish");
        }
        }
    }

    private QueryHelp getDateRange(String date_range) {
        if (date_range == null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype,
                    calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }

}
