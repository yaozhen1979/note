package patent.oracle2mongo;

import itec.indexmaker.IcmaDB;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@Deprecated
public class Oracle2Mongo {

    static Log log = LogFactory.getLog(Oracle2Mongo.class);

    protected Connection getOracleDB() throws ClassNotFoundException {
        return IcmaDB.getConnection();
    }

    /**
     * override this function, set info.mongoSyncFlag.basicInfo = new Date();
     */
    public void fillBasicInfo(PatentInfo2 info) throws ClassNotFoundException, SQLException {
        throw new RuntimeException("not implement");
    }

    public static Oracle2Mongo newInstance(Pto pto) {
        switch (pto) {
        case JP:
            return new Oracle2MongoJP();
        default:
            return null;
        }
    }

}
