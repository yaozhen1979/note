package patent.oracle2mongo;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.embed.MultiLangString;
import itec.patent.mongodb.embed.Person;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

@Deprecated
public class Oracle2MongoJP extends Oracle2Mongo {

    static Log log = LogFactory.getLog(Oracle2MongoJP.class);

    public String Text = null;
    public String xmlPath = null;

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
    }

    public Oracle2MongoJP() {
        xmlPath = ConfigUtils.get("xml.path").replace("/", "\\");

        if(xmlPath.substring(xmlPath.length() - 1).equals("\\"))
            xmlPath = xmlPath.substring(0, xmlPath.length() - 1);
    }

    @Override
    public void fillBasicInfo(PatentInfo2 info) throws ClassNotFoundException, SQLException {
        if (info.pto != Pto.JP) {
            throw new RuntimeException("invalid pto");
        }
        fillPatentInfo(info);
    }

    private void fillPatentInfo(PatentInfo2 info) throws ClassNotFoundException, SQLException {
        Text = null;
        String sql, sval;
        String[] _data = null;
        MultiLangString mstring = null;
        ArrayList<Person> _person = null;
        Person person= null;

        PreparedStatement pstmt;
        ResultSet resultSet;

        sql = "SELECT * FROM PATENT_INFO WHERE PATENT_ID = ?";
        pstmt = getOracleDB().prepareStatement(sql);
//        pstmt.setLong(1, info.id);
        resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            sval = resultSet.getString("APPLICATION_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                info.appNumber = toDBCwithoutMinus(sval);
            }

            sval = resultSet.getString("COUNTRY_ID");
            if (sval != null && !sval.isEmpty()) {
                if (info.pto != Pto.valueOf(sval)) {
                    throw new RuntimeException("invalid pto or COUNTRY_ID");
                }
            }

            sval = resultSet.getString("PATENT_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                info.patentNumber = toDBCwithoutMinus(sval);
            }

            info.stat = resultSet.getInt("P_I");

            sval = resultSet.getString("PATENT_NAME");
            if (sval != null && !sval.isEmpty()) {
                info.title = MultiLangString.getSet(info.title);
                info.title.origin = toDBCwithoutMinus(sval);
            }

            sval = resultSet.getString("PATENT_ABSTRACT");
            if (sval != null && !sval.isEmpty()) {
                info.brief = MultiLangString.getSet(info.brief);
                info.brief.origin = toDBCwithoutMinus(sval);
            }

            info.appDate = resultSet.getDate("APPLICATION_DATE");

            info.filePageNumber = resultSet.getInt("FILEPAGENUMBER");

            info.filePageClaim = resultSet.getInt("FILEPAGECLAIM");

            info.filePageDesc = resultSet.getInt("FILEPAGEDESC");

            info.filePageFig = resultSet.getInt("FILEPAGEFIG");

            info.filePageFirst = resultSet.getInt("FILEPAGEFIRST");

            info.decisionDate = resultSet.getDate("DECISION_DATE");

            sval = resultSet.getString("DECISION_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                info.decisionNumber = toDBCwithoutMinus(sval);
            }

            info.openDate = resultSet.getDate("OPEN_DATE");

            sval = resultSet.getString("OPEN_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                info.openNumber = toDBCwithoutMinus(sval);
            }

            info.certificateDate = resultSet.getDate("CERTIFICATE_DATE");

            sval = resultSet.getString("CERTIFICATE_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                info.certificateNumber = toDBCwithoutMinus(sval);
            }

            sval = resultSet.getString("PATENT_TYPE");
            if (sval != null && !sval.isEmpty()) {
                fillPatentType(info, sval);
            }

            sval = resultSet.getString("PATENT_STATUS");
            if (sval != null && !sval.isEmpty()) {
                info.kindcode = toDBCwithoutMinus(sval);
            }

//            sval = resultSet.getString("MAINIPC");
//            if (sval != null && !sval.isEmpty()) {
//                if (info.isLoc())
//                    info.mainLOC = sval;
//                else
//                    info.mainIPC = sval;
//            }

//            sval = resultSet.getString("MAINCPC");
//            if (sval != null && !sval.isEmpty()) {
//                if (info.isLoc())
//                    info.mainDI = sval;
//                else
//                    info.mainFI = sval;
//            }

//            if (info.patentType != null && !info.patentType.isEmpty()) {
//                if (info.kindcode != null && !info.kindcode.isEmpty()) {
//                    if((info.patentType.indexOf("意匠公報") != -1) || (info.kindcode.toLowerCase().indexOf("s") != -1)) {
//                        info.locs = getLOCs(info.id);
//                        info.dis = getDIs(info.id);
//                        info.dterms = getDTerms(info.id);
//                    }else {
//                        info.ipcs = getIPCs(info.id);
//                        info.fis = getFIs(info.id);
//                        info.fterms = getFTerms(info.id);
//                    }
//                }
//            }

            _person = new ArrayList<>();
            sval = resultSet.getString("PRIMARY_EXAMINER");
            if (sval != null && !sval.isEmpty()) {
                _data = sval.split(";");
                for(String name :  _data) {
                    if(name.isEmpty())
                        continue;
                    mstring = new MultiLangString();
                    mstring.origin = toDBCwithoutMinus(name);
                    person = new Person();
                    person.name = mstring;
                    _person.add(person);
                }
                info.examinerMasters = _person;
            }

            _person = new ArrayList<>();
            sval = resultSet.getString("ASSISTANT_EXAMINER");
            if (sval != null && !sval.isEmpty()) {
                _data = sval.split(";");
                for(String name :  _data) {
                    if(name.isEmpty())
                        continue;
                    mstring = new MultiLangString();
                    mstring.origin = toDBCwithoutMinus(name);
                    person = new Person();
                    person.name = mstring;
                    _person.add(person);
                }
                info.examinerSlaves = _person;
            }

//            info.inventors = getInventors(info.id);
//            info.assignees = getAssignees(info.id);
//            info.agentOperators = getAgentOperators(info.id);

//            Text = getFullText(info.id);
//            if(Text != null) {
//                info.patentClaim = getClaim();
//                info.patentDescription = getDescription();
//            }
        }
        pstmt.close();
        resultSet.close();
        info.mongoSyncFlag.last = new Date();
    }

    @SuppressWarnings("unused")
    private MultiLangString getClaim() throws ClassNotFoundException, SQLException {

        String claim = null;

        if((Text.indexOf("<patentClaim>") == -1) && (Text.indexOf("</patentClaim>") == -1))
            claim = null;
        else
            claim = Text.substring(Text.indexOf("<patentClaim>") + 13, Text.lastIndexOf("</patentClaim>"));    

        if(claim != null) {
            MultiLangString mls = new MultiLangString();
            mls.origin = toDBCwithoutMinus(claim);
            return mls;
        } else {
            return null;
        }
    }

    @SuppressWarnings("unused")
    private MultiLangString getDescription() throws ClassNotFoundException, SQLException {

        String des = null;

        if((Text.indexOf("<patentDescription>") == -1) && (Text.indexOf("</patentDescription>") == -1))
            des = null;
        else
            des = Text.substring(Text.indexOf("<patentDescription>") + 19, Text.lastIndexOf("</patentDescription>"));

        if(des != null) {
            MultiLangString mls = new MultiLangString();
            mls.origin = toDBCwithoutMinus(des);
            return mls;
        } else
            return null;
    }

    private String getXMLPath(long id) throws ClassNotFoundException, SQLException{
        String sql = null;
        String path = null;
        PreparedStatement pstmt;
        ResultSet resultSet;

        sql = "SELECT PATH FROM PATENT_INFO_FILE_INDEX " +
              " WHERE PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            path = resultSet.getString("PATH");
            path = path.replace("/", "\\");

            // *depend on the setting of share folder*
            path = path.substring(path.toLowerCase().indexOf("jp"));

            if(!path.substring(0, 1).equals("\\"))
                path = "\\" + path;
        }

        pstmt.close();
        resultSet.close();

        if (path != null && !path.isEmpty()) {
            return path;
        }else
            return null;

    }

    @SuppressWarnings("unused")
    private String getFullText(long id) throws ClassNotFoundException, SQLException {
        String path = getXMLPath(id);
        if(path == null || path.isEmpty())
            return null;

        path = xmlPath + path;

        File xmlfile = new File(path);
        if(!xmlfile.exists())
            return null;

        BufferedReader br = null;
        StringBuffer resBuffer = new StringBuffer();
        String temp = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(xmlfile), "UTF-8"));

            String str = null;

            while((str = br.readLine()) != null){
                //resBuffer.append(str + "\n");
                resBuffer.append(str);
            }

            temp = resBuffer.toString();

            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            resBuffer = null;
        }

        return temp;
    }

    private ArrayList<String> getIPCs(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;

        ArrayList<String> _ipc = new ArrayList<>();

        sql = "SELECT INTL_NUMBER FROM REL_PATENT_INC " +
              " WHERE PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {

            sval = resultSet.getString("INTL_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                _ipc.add(toDBCwithoutMinus(sval).trim());
            }
        }
        pstmt.close();
        resultSet.close();
        return _ipc;
    }

    @SuppressWarnings("unused")
    private ArrayList<String> getLOCs(long id) throws ClassNotFoundException, SQLException {
        return getIPCs(id);
    }

    private ArrayList<String> getFIs(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;

        ArrayList<String> _fdi = new ArrayList<>();

        sql = "SELECT COUNTRY_NUMBER FROM REL_PATENT_COUNTRY " +
              " WHERE PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {

            sval = resultSet.getString("COUNTRY_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                _fdi.add(toDBCwithoutMinus(sval).trim());
            }
        }
        pstmt.close();
        resultSet.close();
        return _fdi;
    }

    @SuppressWarnings("unused")
    private ArrayList<String> getDIs(long id) throws ClassNotFoundException, SQLException {
        return getFIs(id);
    }

    @SuppressWarnings("unused")
    private ArrayList<String> getFTerms(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;

        ArrayList<String> _fdterm = new ArrayList<>();

        sql = "SELECT COUNTRY_NUMBER FROM REL_PATENT_COUNTRY_1 " +
              " WHERE PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {

            sval = resultSet.getString("COUNTRY_NUMBER");
            if (sval != null && !sval.isEmpty()) {
                _fdterm.add(toDBCwithoutMinus(sval).trim());
            }
        }
        pstmt.close();
        resultSet.close();
        return _fdterm;
    }

    @SuppressWarnings("unused")
    private ArrayList<String> getDTerms(long id) throws ClassNotFoundException, SQLException {
        return getFIs(id);
    }

    @SuppressWarnings("unused")
    private ArrayList<Person> getInventors(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;
        Person data = null;
        ArrayList<Person> _person = new ArrayList<>();

        sql = "SELECT INVENTOR.INVENTOR_ID, INVENTOR.INVENTOR_NAME, INVENTOR.INVENTOR_ADDRESS, INVENTOR.COUNTRY " +
              "  FROM INVENTOR, REL_INVENTOR " +
              " WHERE INVENTOR.INVENTOR_ID = REL_INVENTOR.INVENTOR_ID " +
              "   AND REL_INVENTOR.PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {
            data = new Person();

            MultiLangString mstring = new MultiLangString();

            sval = resultSet.getString("INVENTOR_NAME");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.name = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("INVENTOR_ADDRESS");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.address = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("COUNTRY");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.country = mstring;
            }

            _person.add(data);
        }
        pstmt.close();
        resultSet.close();
        return _person;
    }

    @SuppressWarnings("unused")
    private ArrayList<Person> getAssignees(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;
        Person data = null;
        ArrayList<Person> _person = new ArrayList<>();

        sql = "SELECT ASSIGNEE_LIST.ASSIGNEE_ID, ASSIGNEE_LIST.ASSIGNEE_NAME, ASSIGNEE_LIST.ASSIGNEE_ADDRESS, ASSIGNEE_LIST.COUNTRY " +
              "  FROM ASSIGNEE_LIST, REL_ASSIGNEE " +
              " WHERE ASSIGNEE_LIST.ASSIGNEE_ID = REL_ASSIGNEE.ASSIGNEE_ID " +
              "   AND REL_ASSIGNEE.PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {
            data = new Person();

            MultiLangString mstring = new MultiLangString();

            sval = resultSet.getString("ASSIGNEE_NAME");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.name = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("ASSIGNEE_ADDRESS");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.address = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("COUNTRY");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.country = mstring;
            }

            _person.add(data);
        }
        pstmt.close();
        resultSet.close();
        return _person;
    }

    @SuppressWarnings("unused")
    private ArrayList<Person> getAgentOperators(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;
        Person data = null;
        ArrayList<Person> _person = new ArrayList<>();

        sql = "SELECT AGENTOPERATOR.ID, AGENTOPERATOR.NAME, AGENTOPERATOR.ADDRESS, AGENTOPERATOR.COUNTRY " +
              "  FROM AGENTOPERATOR, REL_AGENTOPERATOR " +
              " WHERE AGENTOPERATOR.ID = REL_AGENTOPERATOR.AGENTOPERATOR_ID " +
              "   AND REL_AGENTOPERATOR.PATENT_ID = ? ";

        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        while (resultSet.next()) {
            data = new Person();

            MultiLangString mstring = new MultiLangString();

            sval = resultSet.getString("NAME");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.name = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("ADDRESS");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.address = mstring;
            }
            mstring = new MultiLangString();
            sval = resultSet.getString("COUNTRY");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.country = mstring;
            }

            _person.add(data);
        }
        pstmt.close();
        resultSet.close();
        return _person;
    }

    private static Pattern patPatentType = Pattern.compile("^(.*?)(（(.*?)）)?$");
    private void fillPatentType(PatentInfo2 info, String type) {
        Matcher mat = patPatentType.matcher(type);
        if (mat.find()) {
            info.type = mat.group(1);
            if (mat.group(3) != null) {
                info.kindcode = fixKindCode(mat.group(3));
            }
        } else {
            throw new RuntimeException("invalid patent type: " + type);
        }
    }

    private String fixKindCode(String kindCode) {
        if (kindCode == null) {
            return null;
        }
        return toDBCwithoutMinus(kindCode);
    }

    /**
     * convert halfwidth into fullwidth
     */
    public static String toSBC(String input) {
        char c[] = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == ' ')
                c[i] = '\u3000';
            else if (c[i] < '\177')
                c[i] = (char) (c[i] + 65248);
        }
        return (new String(c)).trim();
    }

    /**
     * convert fullwidth into halfwidth
     */
    public static String toDBC(String input) {
        char c[] = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == '\u3000')
                c[i] = ' ';
            else if (c[i] > '\uFF00' && c[i] < '\uFF5F')
                c[i] = (char) (c[i] - 65248);
        }
        return (new String(c)).trim();
    }

    /**
     * convert fullwidth into halfwidth without minus
     */
    public static String toDBCwithoutMinus(String input) {
        return toDBC(input).replace("−", "-");
    }

    @SuppressWarnings("unused")
    private Person getAgent(long id) throws ClassNotFoundException, SQLException {
        String sql, sval;
        PreparedStatement pstmt;
        ResultSet resultSet;
        Person data = null;

        sql = "SELECT * FROM AGENT_LIST WHERE AGENT_ID = ?";
        pstmt = getOracleDB().prepareStatement(sql);
        pstmt.setLong(1, id);
        resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            data = new Person();

            MultiLangString mstring = new MultiLangString();

            sval = resultSet.getString("AGENT_NAME");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.name = mstring;
            }

            sval = resultSet.getString("ADDRESS");
            if (sval != null && !sval.isEmpty()) {
                mstring.origin = toDBCwithoutMinus(sval);
                data.address = mstring;
            }
        }
        pstmt.close();
        resultSet.close();
        return data;
    }

}
