package patent.imageImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.RelatedPatent;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * download WIPO patent firstImage png from http://patentscope.wipo.int/search/docservice_fpimage/
 * @author yiyun 2013/11/20
 */
public class WipoFirstImageDownload {
    
    static Log log = LogFactory.getLog(WipoFirstImageDownload.class);
    
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    
    private String url = "http://patentscope.wipo.int/search/docservice_fpimage/";
    
    public static final String opt_pto = "pto";
    public static final String opt_pto_default = "WO";
    
    public static final String opt_target_path = "target";
    public static final String opt_target_path_default = null;

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, ""),
        new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
        new ArgParser.Option("t", null, true, "", "Patent open/decision date rage\n" +
                "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n" +
                "Format: YYYYMMDD+n (20110101+31)\n" +
                "Format: YYYYMM+n (201101+12)\n" +
                "Format: YYYYMM+n (2011+1)\n"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    static {
        ConfigUtils.setSearchBase(WipoFirstImageDownload.class);
    }
    
    public static void main(String[] args) throws Exception {
        WipoFirstImageDownload download = new WipoFirstImageDownload();
        download.execute(args);
    }

    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(WipoFirstImageDownload.class).parse(args);
        MongoAuthInitUtils.reload(argParser);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        Pto pto = Pto.valueOf(argParser.getOptString(opt_pto).toUpperCase());
        String targetPath = argParser.getOptString(opt_target_path);

        String date_range = argParser.getOptString("t");
        QueryHelp query = getDateRange(date_range);
        if (query != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + query);
            Thread.sleep(5000);
        }
        
        log.debug("counting total documents");
        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        
        log.debug("start download firstImage");
        while (cursor.hasNext()) {
            DBObject dbobj = cursor.next();;
            PatentInfo2 patentInfo = PatentInfo2.fromObject(pto, dbobj);
            
            String firstImageUrl = url + "WO" + patentInfo.appNumber.replaceAll("/", "").replaceAll("PCT", "");
            String patentNumber = patentInfo.patentNumber;
            
            String k2FirstImagePath = targetPath 
                    + File.separator + "wo1" + patentInfo.kindcode.toLowerCase() 
                    + File.separator + dateFormat.format(patentInfo.doDate)
                    + File.separator + patentNumber.toLowerCase().replaceAll(" ", "").replace("/", "")
                    + File.separator + "firstImage.png";
            File firstImage = new File(k2FirstImagePath);
            if(firstImage.exists()) {    
                log.debug("patentNumber:" + patentNumber + " already exist" + ", url:" + firstImageUrl);
                continue;
            } else {
                firstImage.getParentFile().mkdirs();
            }
            
            try {
                byte[] content = executeGetMethod(firstImageUrl);
                
                if(content.length == 0 || content.length == 11525) {    // not exist or no image picture
                    log.debug("patentNumber:" + patentNumber + " no image" + ", url:" + firstImageUrl);
                    continue;
                }
                
                FileOutputStream fout = new FileOutputStream(new File(k2FirstImagePath));
                fout.write(content);
                fout.close();
                log.debug("patentNumber: " + patentNumber + " download success" + ", url: " + firstImageUrl);
            } catch (Exception e) {
                writeInfo(new File("." + File.separator + "firstImageError.txt"), 
                        "patentNumber:" + patentNumber + e.getMessage() + ", url:" + firstImageUrl);
                e.printStackTrace();
            }
        }
//        }
        log.debug("finish");
    }
    
    private String proxy_ip = ConfigUtils.get("proxyHost");
    private int proxy_port = ConfigUtils.getInt("proxyPort");
    private byte[] executeGetMethod(String url) throws ClientProtocolException, IOException {
        byte[] content = new byte[0];
        CloseableHttpClient client = HttpClients.createDefault();
        HttpGet method = new HttpGet(url);
        
        HttpHost proxy = new HttpHost(proxy_ip, proxy_port);
        RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
        method.setConfig(config);
        
        HttpResponse res = client.execute(method);
        int statusCode = res.getStatusLine().getStatusCode();
        if (statusCode == HttpStatus.SC_OK) {
            content = EntityUtils.toByteArray(res.getEntity());
        }
        return content;
    }

    private QueryHelp getDateRange(String date_range) {
        if (date_range == null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype, calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }
    
    public void writeInfo(File file, String info) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
