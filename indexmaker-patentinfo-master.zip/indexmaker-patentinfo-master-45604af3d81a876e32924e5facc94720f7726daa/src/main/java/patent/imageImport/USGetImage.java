package patent.imageImport;

import itec.patent.common.MongoInitUtils;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.tsaikd.java.utils.ConfigUtils;


public class USGetImage {    
    static Log log =LogFactory.getLog(USGetImage.class);
    static Log solr_log = LogFactory.getLog("solr_log");
    private static String proxy_ip;
    private static String proxy_port;
    private static String sourcePath;
    
    static List<String> list = new ArrayList<String>();
    
    private static String url = "http://pimg-fpiw.uspto.gov/fdd/";
    private static String url1="http://pimg-faiw.uspto.gov/fdd/";
    private static String usptoFullPDFpath;
    private static String target;
    static InputStream is ;
    static OutputStream os ; 
    public static final Class<?>[] optDep = {
        MongoInitUtils.class,
    };
    static {
        ConfigUtils.setSearchBase(USGetImage.class);
    }
    
    public void worker(String[] args) throws Exception{
        proxy_ip= args[0];
        proxy_port = args[1];
        sourcePath = args[2];
        target = args[3];
        FileReader reader = new FileReader(sourcePath);
        BufferedReader br = new BufferedReader(reader);
        String PN = null;
        while((PN=br.readLine())!=null){
        
            String patentNumber = PN.substring(0,11);
            String pnquery="";
            if(patentNumber.indexOf("D")>0){
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/D0"+patentNumber.substring(5,6);
            }else if (patentNumber.indexOf("PP")>0) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/PP0";
            }else if (patentNumber.indexOf("RE")>0) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/RE0";
            }else if (patentNumber.matches("US\\d+{9}")) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/0"+patentNumber.substring(4,6);
            }else if(patentNumber.matches("\\d+{11}")){
                pnquery=patentNumber.substring(9, 11)+"/"+patentNumber.substring(0,4)+"/"+patentNumber.substring(7,9)+"/"+patentNumber.substring(4,7);
            }
            if(patentNumber.matches("\\d+{11}")){
                usptoFullPDFpath=url1+pnquery+"/0.pdf";
            }else{
                usptoFullPDFpath=url+pnquery+"/0.pdf";
            }
            String k2FullPDFpath=target+File.separator+ PN.substring(11,16).toLowerCase()
                    +File.separator+PN.substring(16,20)+File.separator+PN.substring(21,23)+File.separator+PN.substring(24)
                    +File.separator+ PN.substring(0,11).toLowerCase().replaceAll(" ", "").replace("/", "")
                    +File.separator+ "fullPage.pdf";
            File fullPDF =new File(k2FullPDFpath);
            if (fullPDF.exists()) {
                log.debug("patentNumber:"+ patentNumber + " already exist" + " url:" + usptoFullPDFpath);
                continue;
            }else {
                fullPDF.getParentFile().mkdirs();
            }
        System.setProperty("http.proxyHost", proxy_ip);
        System.setProperty("http.proxyPort",proxy_port );
        try {
            URL u = new URL(usptoFullPDFpath);
            URLConnection conn = u.openConnection();
            is= conn.getInputStream();
            byte[] b = new byte[1024];
            int len=0;
            os= new FileOutputStream(k2FullPDFpath);
            while((len=is.read(b))!=-1){
                os.write(b, 0, len);
            }
            
            os.close();
            is.close();
            
        }  catch (Exception e) {
            worker(args);
        }
            log.debug("download "+patentNumber +" success.......");
        }
    }
    
    
    public static void main(String[] args)throws Exception {
        proxy_ip= args[0];
        proxy_port = args[1];
        sourcePath = args[2];
        target = args[3];
        USGetImage uspto = new USGetImage();
        uspto.worker(args);
    }    
        
}
