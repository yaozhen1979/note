package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/***
 * WIPO image import into mongoDB 
 * @author yiyun 2013/10/10
 */
public class WipoImageOracleToMongo {

    private static Log log = LogFactory.getLog(WipoImageOracleToMongo.class);
    private PatentInfo2 patentInfo;
    private ProcessEstimater pe;
    // args
    private static String mongoUri = "mongodb://10.57.145.105/PatentInfoWIPO";
    private static String startDate = "20120101";
    private static String endDate = "20130101";
    // tw oracle
    private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB = "jdbc:oracle:thin:@10.153.24.247:1521:szicma";        // lh
//    private static final String DB = "jdbc:oracle:thin:@10.57.144.61:1521:icma01";        // tw01
//    private static final String DB = "jdbc:oracle:thin:@10.57.144.63:1521:icma03";        // tw01
    private static final String USERNAME = "icma";
    private static final String PASSWORD = "critical";
    
    static {
        try {
            Class.forName(DRIVER); // 加載驅動程序
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public WipoImageOracleToMongo() throws UnknownHostException{
        Class<? extends PatentInfo2> infoClazz = PatentInfoWIPO.class;
        MongoClientURI mongoClientUri = new MongoClientURI(mongoUri);
        MongoClient mongoClient = new MongoClient(mongoClientUri);
        DB mongodb = mongoClient.getDB(mongoClientUri.getDatabase());
        MappedClass.getMappedClass(infoClazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");    
    }
    
    public static void main(String[] args) throws Exception{
        WipoImageOracleToMongo wipoImage = new WipoImageOracleToMongo();
        wipoImage.importImage();
    }
    
    /**
     * import image to target file and update patentInfo of mongoDB
     */
    public void importImage() throws Exception {
        // connection to Oracle datebase
        log.debug("connect to Oracle...");
        Connection conn = DriverManager.getConnection(DB, USERNAME, PASSWORD);
        String sql = "select patent_number, patent_status, open_date, filepagenumber, filepagefirst, filepageclaim, " +
                "filepagedesc, filepagefig  from patent_info " +
                "where country_id = 'WI' and filepagenumber > 0 and open_date between to_date(?,'yyyyMMdd') " +
                "and to_date(?,'yyyyMMdd') order by open_date asc";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, startDate);
        ps.setString(2, endDate);
        ResultSet rs = ps.executeQuery();
        
        log.debug("start import...");
        while(rs.next()) {
            String patentNumber = rs.getString("patent_number");
            try {
                // get patentInfo from mongoDB by patentNumber and kindCode
                patentInfo = PatentInfoWIPO.findPN(Pto.WIPO, patentNumber);
                if(patentInfo != null) {
                    int filePageNumber = rs.getInt("filepagenumber");
                    int filePageFirst = rs.getInt("filepagefirst");
                    int filePageCLaim = rs.getInt("filepageclaim");
                    int filePageDesc = rs.getInt("filepagedesc");
                    int filePageFig = rs.getInt("filepagefig");
                    patentInfo.filePageNumber = filePageNumber > 0 ? filePageNumber : null;
                    patentInfo.filePageFirst  = filePageFirst > 0  ? filePageFirst  : null;
                    patentInfo.filePageClaim  = filePageCLaim > 0  ? filePageCLaim  : null;
                    patentInfo.filePageDesc   = filePageDesc > 0   ? filePageDesc   : null;
                    patentInfo.filePageFig    = filePageFig > 0    ? filePageFig    : null;
                    
                    Date openDate = rs.getDate("open_date");
//                    save patentInfo into mongoDB
                    patentInfo.save();
                    pe.addNum().debug(log, 10000, "number: " + patentNumber + " date: " + openDate);
                } else {
                    log.info(patentNumber + " not find!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                writeInfo(patentNumber + "    " + e.getMessage(), "." + File.separator + "error.txt");
            }
        }
        ps.close();
        conn.close();
        log.debug("finish");
    }                    

    /**
     * wrtie info string into the file
     * @param     info      info string
     * @param    path    file path
     */
    public static void writeInfo(String info, String filePath) {
        File file = new File(filePath);
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
