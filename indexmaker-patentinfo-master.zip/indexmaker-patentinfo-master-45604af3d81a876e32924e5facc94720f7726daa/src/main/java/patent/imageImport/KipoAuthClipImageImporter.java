package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class KipoAuthClipImageImporter {
    static Log log = LogFactory.getLog(KipoAuthClipImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private static String sourcePath;  //文件原始路徑
    private static String targetPath;  //PDF保存路徑
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private String errFile = "./list/error_kr.txt";
    
    private static String fileType ="xml";
    
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = null;


    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "year or date of KIPO raw data, keep empty for kipo.path"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    public KipoAuthClipImageImporter() throws UnknownHostException{
        
        pe = new ProcessEstimater(0).setFormat("%2$d");    
        
    }
    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void firstImageImporter() throws IOException {        
        File source = new File(this.sourcePath);
        List<String> sourceFileList =  getFileList(source,fileType);
        for(String patentPath:sourceFileList){
            // 韓國專利文字信息存在SGM文檔 和XML文檔
            if (patentPath == null) {
                log.info("Error path : " + patentPath);
            } else {
                try {
                    boolean isSGMFile = false; // 判斷是否為SGM 文檔
                    if (patentPath.contains("SGM")) {
                        isSGMFile = true;
                    }
                    String document = readFileByChars(patentPath);
                    int stat = getStat(document, isSGMFile);
                    
                    String firstImagePath = getFirstImagePath(patentPath,document);

                    File firstImageFile = new File(firstImagePath);

                    if (firstImageFile.exists()) {
                        
                        File sourceFile = new File(patentPath);
                        
                        String sourceFileName = sourceFile.getName();
                        String patentNumber = sourceFileName.substring(0,sourceFileName.lastIndexOf(".")); //專利號
                        
                        try {
                            this.patentinfo = PatentInfoKIPO.findPN(
                                    Pto.KIPO, patentNumber, stat);
                        } catch (Exception e) {
                            log.info("err patentPath : " + patentPath);
                            writerFile("./errorImportImage_kr.txt", patentPath);

                            FileUtils.write(new File("errFile"), patentPath);
                        }
                        if (this.patentinfo != null) {
                            String type =firstImageFile.getName().substring(firstImageFile.getName().lastIndexOf("."));
                            String k2imagePath = this.targetPath
                                    + File.separator
                                    + "kr"
                                    + stat
                                    + File.separator
                                    + dateFormat
                                            .format(patentinfo.doDate)
                                    + File.separator
                                    + patentNumber.toLowerCase()
                                    + File.separator + "firstImage"+type;
                            copyFile(
                                    new File(firstImageFile.getAbsolutePath()),
                                    new File(k2imagePath));
                    
                            pe.addNum().debug(
                                    log,
                                    10000,
                                    "source:" + patentPath + ", dest:"
                                            + k2imagePath);
                        
                        } else {
                            log.info(patentPath + "'[" + stat + "]"
                                    + " not find!");
                        }
                    } else {
                        log.info(patentPath + "'[" + stat + "]"
                                + " no tif!");
                    }

                } catch (Exception e) {
                    writerFile("./errorImportImage.txt", patentPath);
                }
            }
        }
    }
    
    public void clipImageImporter() throws IOException {        
        File source = new File(this.sourcePath);
        List<String> sourceFileList =  getFileList(source,fileType);
        for(String patentPath:sourceFileList){
            // 韓國專利文字信息存在SGM文檔 和XML文檔
            if (patentPath == null) {
                log.info("Error path : " + patentPath);
            } else {
                try {
                    boolean isSGMFile = false; // 判斷是否為SGM 文檔
                    if (patentPath.contains("SGM")) {
                        isSGMFile = true;
                    }
                    String document = readFileByChars(patentPath);
                    int stat = getStat(document, isSGMFile);
                    
                    //首頁附圖
                    String firstImagePath = getFirstImagePath(patentPath,document);
                    
                    //內文插圖
                    List<String> figureImagePathList = getFigureImageListPath(patentPath,document);
                    
                    //其他附圖(clip image)
                    List<String> clipImagePathList = getDrawingsImageListPath(patentPath,document);
                    
                    //連接mongodb獲取對應這篇專利的信息
                    File sourceFile = new File(patentPath);
                    String sourceFileName = sourceFile.getName();
                    String patentNumber = sourceFileName.substring(0,sourceFileName.lastIndexOf(".")); //專利號
                    
                    try {
                        this.patentinfo = PatentInfoKIPO.findPN(
                                Pto.KIPO, patentNumber, stat);
                    } catch (Exception e) {
                        log.info("err patentPath : " + patentPath);
                        writerFile("./errorImportImage_kr.txt", patentPath);
                        FileUtils.write(new File("errFile"), patentPath);
                    }
                    
                    if(this.patentinfo != null){
                        String doDate = dateFormat.format(patentinfo.doDate);
                        //上傳首頁附圖
                        if(firstImagePath!=null){
                            File firstImageFile = new File(firstImagePath);
                            if (firstImageFile.exists()) {
                                String type =firstImageFile.getName().substring(firstImageFile.getName().lastIndexOf("."));
                                String k2imagePath = this.targetPath
                                        + File.separator
                                        + "kr"
                                        + stat
                                        + File.separator
                                        + doDate
                                        + File.separator
                                        + patentNumber.toLowerCase()
                                        + File.separator + "firstImage"+type;
                                copyFile(firstImageFile,new File(k2imagePath));
                        
                                pe.addNum().debug(
                                        log,
                                        10000,
                                        "source:" + patentPath + ", dest:"
                                                + k2imagePath);
                            }else {
                                log.info(patentPath + "'[" + stat + "]"
                                        + " no first tif!");
                            }
                        }else {
                            log.info(patentPath + "'[" + stat + "]"
                                    + " no first tif!");
                        }
                        
                        for(String figurePath:figureImagePathList){
                            System.out.println("figurePath : "+figurePath);
                            File figureFile = new File(figurePath);
                            String k2imagePath = this.targetPath
                                    + File.separator
                                    + "kr"
                                    + stat
                                    + File.separator
                                    + doDate
                                    + File.separator
                                    + patentNumber.toLowerCase()
                                    + File.separator 
                                    + "figure"
                                    + File.separator
                                    +figureFile.getName();
                            if(figureFile.exists()){
                                copyFile(figureFile,new File(k2imagePath));
                            }
                        }
                        
                        for(int i=0;i<clipImagePathList.size();i++){
                            System.out.println(i);
                            File clipImageFile = new File(clipImagePathList.get(i));
                            String type =clipImageFile.getName().substring(clipImageFile.getName().lastIndexOf("."));
                            String k2imagePath = this.targetPath
                                    + File.separator
                                    + "kr"
                                    + stat
                                    + File.separator
                                    + doDate
                                    + File.separator
                                    + patentNumber.toLowerCase()
                                    + File.separator 
                                    + "clip"
                                    + File.separator
                                    +(i+1)
                                    +type;
                            if(clipImageFile.exists()){
                                copyFile(clipImageFile,new File(k2imagePath));
                            }
                        }
                        
                    }else {
                        log.info(patentPath + "'[" + stat + "]"
                                + " not find!");
                    }



                } catch (Exception e) {
                    writerFile("./errorImportImage.txt", patentPath);
                }
            }
        }
    }
    
    /**
     * 
     * @param filePath  XML/SGM 文檔路徑
     * @param fileContent  XML/SGM 文檔內容
     * @return firstImagePath 構成首頁切圖路徑 
     */
    public static String getFirstImagePath(String filePath,String fileContent){
        String firstImagePath = null;
        
        String id = null;
        String fileName = null;
        
        if(filePath.endsWith("xml")){ // 獲取xml對應的首頁切圖
            //獲取 ID值
            List<String> idList =getFileContentList(fileContent,"<DrawReference idref\\s*=\\s*\"","/>");//此標籤對應值只有一個
            for(String e:idList){
                id = e;
            }
            //獲取文件名
            //  <Drawing id="10"><EMI file="112003034167929-pat00010.tif" height="180" id="10" width="136"/></Drawing>
            if(id !=null){
                String tag = "<Drawing id\\s*=\\s*\""+id+"\">";
                
                String drawingStr="";
                List<String> drawingList = getFileContentList(fileContent,tag,"</Drawing>");//對應的一文件路徑 
                for(String im:drawingList){
                    drawingStr = im;
                }
                
                if(!drawingStr.equals("")){                    
                    List<String> pathList = getFileContentList(drawingStr, "file\\s*=\\s*\"","\"");
                    for(String path:pathList){
                        fileName = path;
                    }
                }
            }else{
                //<AbstractFigure><EMI file="R1020030075913.tif" height="119" id="5" width="181"/></AbstractFigure>
                String abstractFigure = getTagValue(fileContent, "AbstractFigure");
                if(abstractFigure!=null){
                    List<String> pathList = getFileContentList(abstractFigure, "file\\s*=\\s*\"","\"");
                    for(String path:pathList){
                        fileName = path;
                    }
                }else{
                    List<String> pathList = getFileContentList(fileContent, "file\\s*=\\s*\"","\"");
                    for(String path:pathList){
                        fileName = path;
                        break;
                    }
                }
            }
            
        }else{ // 獲取SGM對應的首頁切圖
            //獲取 ID值  <DRAWREF IDREF="1">
            List<String> idList =getFileContentList(fileContent,"<DRAWREF IDREF\\s*=\\s*\"",">");//此標籤對應值只有一個
            for(String e:idList){
                id = e;
            }
            
            //獲取文件名
            //  <Drawing id="10"><EMI file="112003034167929-pat00010.tif" height="180" id="10" width="136"/></Drawing>
            if(id !=null){
                //  <DRAW ID="1"><EMI ID=1 HE=76 WI=154 FILE="utm00001.tif"></DRAW>
                String tag = "<DRAW ID\\s*=\\s*\""+id+"\">";
                
                String drawStr="";
                List<String> drawList = getFileContentList(fileContent,tag,"</DRAW>");//對應的一文件路徑 
                for(String im:drawList){
                    drawStr = im;
                }
                
                if(!drawStr.equals("")){                    
                    List<String> pathList = getFileContentList(drawStr, "file\\s*=\\s*\"","\"");
                    for(String path:pathList){
                        fileName = path;
                    }
                }
            }else{//沒有指首頁文件名，則獵取其中一個影像文件當作首頁
                //<EMI ID="1" HE=72 WI=59 FILE="1.JPG">
                List<String> pathList = getFileContentList(fileContent, "file\\s*=\\s*\"","\"");
                for(String path:pathList){
                    fileName = path;
                    break;
                }
            }
            
        }
         String parentPath = filePath.substring(0, filePath.lastIndexOf(File.separator)+1);
         if(fileName !=null){            
             firstImagePath = parentPath + fileName;
             File firstImageFile = new File(firstImagePath);
            //判斷文件是否存在，如果不存在，則獲取文件夾下的其中一篇影像檔文件當作首頁附圖
             if(!firstImageFile.exists()){
                 File file = new File(parentPath);
                 File[] files = file.listFiles();
                 for(File myFile:files){
                     if((!myFile.getName().endsWith(".xml"))
                             ||(!myFile.getName().endsWith(".XML"))
                             ||(!myFile.getName().endsWith(".sgm"))
                             ||(!myFile.getName().endsWith(".SGM"))){
                         firstImagePath = myFile.getAbsolutePath();
                         break;
                     }
                 }
             }
         }else{
             File file = new File(parentPath);
             File[] files = file.listFiles();
             for(File myFile:files){
                 if((!myFile.getName().endsWith(".xml"))
                         &&(!myFile.getName().endsWith(".XML"))
                         &&(!myFile.getName().endsWith(".sgm"))
                         &&(!myFile.getName().endsWith(".SGM"))){
                     firstImagePath = myFile.getAbsolutePath();
                     break;
                 }
             }
         }
        return firstImagePath;
        
    }
    
    public static List<String> getDrawingsImageListPath(String filePath,String fileContent){
        List<String> clipImageListPath = new ArrayList<String>();
        String drawingStr = null;
        if(filePath.endsWith("xml")){
            //發明和實用新型專利
            String str1 = getTagValue(fileContent, "Drawings");
            //外觀專利
            String str2 = getTagValue(fileContent, "CubicDesignDrawings");
            
            if(str1!=null){
                drawingStr = str1;
            }else if(str2!=null){
                drawingStr=str2;
            }
            
            if(drawingStr!=null){
                String parentPath = filePath.substring(0, filePath.lastIndexOf(File.separator)+1);
                List<String> pathList = getFileContentList(drawingStr, "file\\s*=\\s*\"","\"");
                for(String path:pathList){
                    clipImageListPath.add(parentPath + path);      
                }
            }
        }
        return clipImageListPath;
    }
    
    public static List<String> getFigureImageListPath(String filePath,String fileContent){
        List<String> figureImageListPath = new ArrayList<String>();
        String str="";
        
        String abst = null;
        String claims = null;
        String descript = null;
        //獲取摘要的內容
        String abst1 = getTagValue(fileContent, "abstract");
        String abst2 = getTagValue(fileContent, "PCTAbstract");
        String abst3 = getTagValue(fileContent, "DesignSummary");
        if(abst1!=null){
            abst = abst1;
        }else if(abst2!=null){
            abst = abst2;
        }else if(abst3!=null){
            abst = abst3;
        }
        
        //說明書
        String desc1 = getTagValue(fileContent,"PCTApplicationBody");            
        String desc2 = getTagValue(fileContent,"ApplicationBody");            
        String desc3 = getTagValue(fileContent,"description");
        String desc4 = getTagValue(fileContent,"DesignDescription");
        
        if(desc1!=null){
            descript = desc1;
        }else if(desc2!=null){
            descript = desc2;
        }else if(desc3!=null){
            descript = desc3;
        }else if(desc4!=null){
            descript = desc4;
        }
        
        //權利說明書
        claims = getTagValue(fileContent,"Claims");
        
        if(abst!=null){
            str = str + abst;
        }
        if(descript!=null){
            str = str + descript;
        }
        if(claims!=null){
            str = str + claims;
        }
        if(str.equals("")){
            return figureImageListPath;
        }
        
        String parentPath = filePath.substring(0, filePath.lastIndexOf(File.separator)+1);
        List<String> pathList = getFileContentList(str,"file\\s*=\\s*\"","\"");
        for(String imageName :pathList){
            figureImageListPath.add(parentPath + imageName);
        }
        
        return figureImageListPath;
    }
    /**
     * 通過PDF絕對路徑 構造出 韓國專利的 SGM/XML文檔路徑
     * @param pdfPath  PDF 文檔絕對路徑 
     * @return
     */
    public static String documentPath(String pdfPath){
        //kipo\Design\2001\20010115\3019960005927\B012\SGM\3019960005927.SGM
        String documentPath = null;
        //sgm 文檔存在與 ".sgm" 和 ".SGM" 文檔結尾的文檔
        String sgmPath1 = pdfPath.replaceAll("PDF", "SGM");
        sgmPath1 = sgmPath1.replaceAll("pdf", "sgm");
        String sgmPath2 = sgmPath1.replaceAll("pdf", "SGM");
        File sgmFile1 = new File(sgmPath1);
        File sgmFile2 = new File(sgmPath2);
        if(sgmFile1.exists()){//如何sgm文檔存在，則返回sgm 文檔路徑
            return sgmPath1;
        }else if(sgmFile2.exists()){
            return sgmPath2;
        }
        //如果不是SGM文檔，則為XML文檔
        //KIPO\Patent&UtilityModel_Registered\2006\20060109\1019997000116\B012\XML\1019997000116.xml
        String xmlPath =  pdfPath.replaceAll("PDF", "XML");
        xmlPath = xmlPath.replaceAll("pdf", "xml");
        File xmlFile = new File(xmlPath);
        if(xmlFile.exists()){
            return xmlPath;
        }
        
        return documentPath;
    }
    /**
     * get the file list of the source file and write the list into a txt file 
     * @param sourcePath    image source file  directory
     * @return                the file path of the list file
     */
    public static String createListFile2(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            
            bw.close();
            fw.close();
        }
        return listPath;
    }
    
    public static String createListFile(String sourcepath)throws IOException{
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String name = sourcepath.substring(sourcepath.lastIndexOf(File.separator));
        String listPath = "." + File.separator + "list"  + name + ".txt";
        
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }        
            File source = new File(sourcepath);
            if(!(source.isDirectory())) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
        
    }
    /**
     * 
     * @param file 父文件
     * @param fielType 文件類型/文件后序名
     * @return list
     */
    static List<String> fileList = new ArrayList<>();
    public static List<String> getFileList(File file, String fielType) {
        
        File[] files = file.listFiles();

        if (files != null && files.length > 0) {

            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    String path = files[i].getAbsolutePath();
                    if (path.endsWith(fielType)||path.endsWith(fielType.toUpperCase())) {
                        if(fielType.equals("sgm")){
                            File sgmFile = new File(path);
                            String sgmFileName = sgmFile.getName();
                            if(sgmFileName.startsWith("10")||sgmFileName.startsWith("20")||sgmFileName.startsWith("30")){
                                System.out.println(path);
                                fileList.add(path);
                            }
                        }else{
                            System.out.println(path);
                            fileList.add(path);    
                        }                        
                    }
                } else {
                    getFileList(files[i], fielType);
                }
            }
        }
        return fileList;
    }
    
    /**
     * 讀取文件內容
     * @param filePath 文件絕對路徑 
     * @return
     */
    public String readFileByChars(String filePath) {
         File file = new File(filePath);
         if( ! (file.exists()) ){
             System.out.println("file is not exists: "+filePath);
         }
         
         try {
             InputStreamReader ir = new InputStreamReader(new FileInputStream(file),"EUC_KR");
             BufferedReader br = new BufferedReader(ir);
             StringBuffer sb = new StringBuffer();
             
             String line;
             while( (line = br.readLine()) != null){
                 sb.append(line);
             }
             
             String result = sb.toString();
             return result;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;    
    }
    /**
     * 判斷分開公告
     * @param document  文檔內內
     * @param isSGMFile 
     * @return
     */
    public static int getStat(String document,boolean isSGMFile){
        int stat =1;
        if(isSGMFile){
            int Pn1 = document.indexOf("<RG");
            int Pn2 = document.indexOf("<ALLRG");
            if(Pn1 !=-1){
                stat=2;
            }else if(Pn2!=-1){
                stat=2;
            }else{
                stat=1;
            }
        }else{
            int Pn = document.indexOf("<KR_Register");
            if(Pn > 0){
                stat=2;
            }else{
                stat=1;
            }
        }
        return stat;
    }
    /**
     * writer the string to file
     * @param fileName File name
     * @param writerStr  writer string
     */
    public static void writerFile(String fileName, String writerStr) {
        File wFile = new File(fileName);
        try {
            if (!wFile.exists()) {
                wFile.createNewFile();
            }
            FileWriter wf = new FileWriter

            (wFile, true);
            BufferedWriter bw = new

            BufferedWriter(wf);
            byte[] buf = new byte[1024];
            int k = 0;
            bw.write(writerStr);
            bw.newLine();
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("寫文件出錯");
        }
    }
    
    /**
     * 獲取內容標籤間的值
     * @param contentString 內容
     * @param tagName 標籤名
     * @return
     */
    public static String getTagValue(String contentString,String tagName){
        String tagString = null;
        String myrexp ="<" +  tagName + ".*?>(.*?)" + "</" + tagName + ">";
        Pattern p = Pattern.compile(myrexp,Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(contentString);        
        while(m.find()) {            
            tagString = m.group(1);
         }    
        return tagString;
    }
    
    /**
     * 獲取開始與結束字串間的內容
     * @param contentString 內容
     * @param startStr 開始標籤或者字串
     * @param endStr 結束標籤或字串
     * @return
     */
    public static List<String> getFileContentList(String contentString,String startStr,String endStr){
        List<String> strList = new ArrayList<String>();
        String myrexp =startStr+"(.*?)" + endStr;
        Pattern p = Pattern.compile(myrexp,Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(contentString);        
        while(m.find()) {            
            strList.add(m.group(1));
         }
        return strList;
    }
    
    public static void main(String[] args) throws Exception {
        KipoAuthClipImageImporter KipoAuthClipImageImporter = new KipoAuthClipImageImporter();
        KipoAuthClipImageImporter.worker(args);
    }
    
    public void worker(String[] args) throws Exception {

        try {
            ArgParser argParser = new ArgParser().addOpt(KipoAuthClipImageImporter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
           
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);            
            if(sourcePath == null || sourcePath.isEmpty() ||
               targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            System.out.println("error config ...");
            return;
        }
        try {
             KipoAuthClipImageImporter kipoClipImageImporter = new KipoAuthClipImageImporter();
             System.out.println("begin import first image...");
             kipoClipImageImporter.clipImageImporter();
             System.out.println("import completed...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    
        
    }
}
