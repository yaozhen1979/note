package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/***
 * 
 * @author Genchi
 * 台灣說明書目前直接從官網下載
 * 本程式不再使用
 */

public class IcmaImageTipoImporter {

    static Log log = LogFactory.getLog(IcmaImageTipoImporter.class);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private String sourcePath;
    private String targetPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String createrList(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath);
        if(!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(listFileReader);
            String patentPath = "";
            if(startPath != null && !startPath.isEmpty())
            {
                while((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if(patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while((patentPath = listBufferedReader.readLine()) != null) {
                int stat = 2 ;
                File patentFile = new File(patentPath);
                File pdfFile = new File(patentFile.getAbsolutePath() + File.separator + "fullPage.pdf");
                if(!pdfFile.exists()) {
                    pdfFile = new File(patentFile.getAbsolutePath() + File.separator + "fullpage.pdf");
                }
                if(pdfFile.exists()) {
                    String patentNumber = patentFile.getName().toUpperCase();
                    if(patentNumber.startsWith("M") || patentNumber.startsWith("I") || patentNumber.startsWith("D")) {
                        stat = 2;
                    } else {
                        stat = 1;
                    }
                    try {
                        this.patentinfo = PatentInfoTIPO.findPN(Pto.TIPO, patentNumber);
                    } catch (Exception e) {
                        log.info("err patentPath : " + patentPath);
                        throw e;
                    }
                    if(this.patentinfo != null ) {
                        if(this.patentinfo.filePageNumber == null || this.patentinfo.filePageNumber == 0) {
                            String k2imagePath = this.targetPath +  File.separator +"tw" + stat + File.separator + dateFormat.format(patentinfo.doDate)
                                    + File.separator + patentNumber.toLowerCase() + File.separator + "fullPage.pdf";
                            copyFile(new File(pdfFile.getAbsolutePath()), new File(k2imagePath));
                            InputStream in = new FileInputStream(pdfFile);
                            PDFParser parser = new PDFParser(in);
                            parser.parse();
                            PDDocument pdfdocument = parser.getPDDocument();
                            this.patentinfo.filePageNumber = pdfdocument.getNumberOfPages();
                            this.patentinfo.save();
                            pdfdocument.close();
                            in.close();
                            pe.addNum().debug(log, 10000, "source:" + patentPath + ", dest:" + k2imagePath);
                        }
                    } else {
                        log.info(patentPath + "'[" + stat + "]" +" not find!");
                    }
                } else {
                    log.info(patentPath + "'[" + stat + "]" +" no pdf!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
    }
    
    public IcmaImageTipoImporter() {
        
    }
    
    public IcmaImageTipoImporter(String mongouriStr, String sourcePath, String targetPath) {
        try {
            Class<? extends PatentInfo2> infoclazz = PatentInfoTIPO.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;
            
            if(this.sourcePath.endsWith(File.separator)) {
                this.sourcePath = this.sourcePath.substring(0, this.sourcePath.length()-1);
            }
            pe = new ProcessEstimater(0).setFormat("%2$d");    
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } 
    }

    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        String mongouri ;
        String sourcePath;
        String targetPath;
        String startPath;
        try {
            cmd = parser.parse( options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
            if(mongouri == null || mongouri.isEmpty() || sourcePath == null || sourcePath.isEmpty() ||
               targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp( "IcmaTipoImporter", options );
            return;
        }
        IcmaImageTipoImporter imageImpoter = new  IcmaImageTipoImporter(mongouri, sourcePath, targetPath);
        try {
            imageImpoter.importImage(startPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
