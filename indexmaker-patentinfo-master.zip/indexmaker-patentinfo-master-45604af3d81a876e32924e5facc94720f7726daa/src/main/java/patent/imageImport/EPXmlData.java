package patent.imageImport;

public class EPXmlData {
    public static  String pubDate;
    public static  String patentNumber_B110;
    public static  String kindCode_B130;// A:public,1 B:issue,2
    public  int PnI;
    
    public String getPubDate() {
        return pubDate;
    }

    public  void setPubDate(String pubDate) {
        EPXmlData.pubDate = pubDate;
    }

    public  String getPatentNumber_B110() {
        return patentNumber_B110;
    }

    public  void setPatentNumber_B110(String patentNumber_B110) {
        EPXmlData.patentNumber_B110 = patentNumber_B110;
    }

    public  String getKindCode_B130() {
        return kindCode_B130;
    }

    public  void setKindCode_B130(String kindCode_B130) {
        EPXmlData.kindCode_B130 = kindCode_B130;
    }

    public  int getPnI() {
        return PnI;
    }

    public  void setPnI(int pnI) {
        PnI = pnI;
    }

    public EPXmlData() {
    }
}

