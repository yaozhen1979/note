package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/***
 * WIPO firstImage import 
 * @author yiyun 2013/10/28    
 */
public class WipoFirstImageImporter { 
    private static Log log = LogFactory.getLog(WipoFirstImageImporter.class);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private PatentInfo2 patentInfo;
    private ProcessEstimater pe;
    // args
    private static String mongoUri;            // mongo Uri
    private static String sourcePath;        // source file path
    private static String targetPath;        // target file path
    private String imageType = "png";        // file type
    
    /**
     * main class to config args
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        mongoUri = args[0];
        sourcePath = args[1];
        targetPath = args[2];
        WipoFirstImageImporter firstImageImporter = new WipoFirstImageImporter();
        firstImageImporter.importImage();
    }
    
    public WipoFirstImageImporter() throws UnknownHostException{
        Class<? extends PatentInfo2> infoClazz = PatentInfoWIPO.class;
        MongoClientURI mongoClientUri = new MongoClientURI(mongoUri);
        MongoClient mongoClient = new MongoClient(mongoClientUri);
        DB mongodb = mongoClient.getDB(mongoClientUri.getDatabase());
        MappedClass.getMappedClass(infoClazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");    
    }
    
    public void importImage() {
        // get the path list of source firstImage 
        List<String> filePathList = getFilePathList(sourcePath, imageType);
//        List<String> filePathList = new ArrayList<>();
        try {
            FileReader fr = new FileReader(new File(""));
            BufferedReader br = new BufferedReader(fr);
            String path = "";
            while((path = br.readLine()) != null) {
                filePathList.add(path);
            }
            br.close();
            fr.close();
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        
        for(Iterator<String> it = filePathList.iterator(); it.hasNext(); ) {
            String filePath = it.next();
            try {
                String pn = filePath.substring(filePath.lastIndexOf("\\")+1, filePath.lastIndexOf("_"));
                String kindCode = pn.substring(pn.length()-2);
                String year = "";
                switch(pn.length()) {
                    case 11:
                        year = pn.substring(2,4);
                        year = Integer.parseInt(year) > 70 ? "19" + year: "20" + year;
                        pn = pn.substring(0,2) + " " + year + "/0" + pn.substring(4,9) + " " + pn.substring(9);
                        break;
                    case 12:
                        year = pn.substring(2,4);
                        year = Integer.parseInt(year) > 70 ? "19" + year: "20" + year;
                        pn = pn.substring(0,2) + " " + year + "/" + pn.substring(4,10) + " " + pn.substring(10);;
                        break;
                    case 14:
                        pn = pn.substring(0,2) + " " + pn.substring(2,6) + "/" + pn.substring(6,12) + " " + pn.substring(12);;
                        break;
                }
                // get patentInfo from mongoDB by patentNumber
                patentInfo = PatentInfoWIPO.findPN(Pto.WIPO, pn);
                
                if(patentInfo != null) {
                    String k2FirstImagePath = targetPath 
                            + File.separator + "wo1" + kindCode.toLowerCase() 
                            + File.separator + dateFormat.format(patentInfo.openDate)
                            + File.separator + pn.toLowerCase().replaceAll(" ", "").replace("/", "")
                            + File.separator + "firstImage.png";
                    // copy source image file path to k2 image file path
                    copyFile(new File(filePath), new File(k2FirstImagePath));
                    pe.addNum().debug(log, 10000, "source: " + filePath);
                } else {
                    log.info(filePath + " not find!");
                }
            } catch (Exception e) {
                log.info(filePath);
                e.printStackTrace();
                writeInfo(filePath + "        " + e.getMessage(), "." + File.separator + "firstImageError.txt");
            }
        }
    }
    
    /** file list */
    private List<String> fileNames = new ArrayList<String>();
    /**
     * get listFiles from target file 
     * @param root             file path
     * @param endWith          file suffix
     * @return fileNames    file list
     */
    public List<String> getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else {
                        if (fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().endsWith(endWith)) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    
    /**
     * copy source file to destination file
     * @param src        source file 
     * @param des        destination file
     */
    private void copyFile(File src, File des) {
        try {
            File patentFile = des.getParentFile();
            if (!patentFile.exists()) {
                patentFile.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * wrtie info string into the file
     * @param     info      info string
     * @param    path    file path
     */
    public static void writeInfo(String info, String filePath) {
        File file = new File(filePath);
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
