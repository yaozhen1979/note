package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;



/***
 * @author Genchi 上傳tipo採購說明書(1990~2012)
 */

public class TipoImageImporter {

    static Log log = LogFactory.getLog(TipoImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy"
            + File.separator + "MM" + File.separator + "dd");
    private static String[] imageType = new String[] { "tif", "jpg" };// 影像檔類型
    private static String sourcePath;
    private static String targetPath;
    private static String startPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private Connection conn;
    private Statement stmt = null;

    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";

    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";

    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "00000000";

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_source_path, true,
                    opt_source_path_default,
                    "mongodb uri, start with mongodb://"),
            new ArgParser.Option(null, opt_target_path, true,
                    opt_target_path_default,
                    "JPO raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, opt_start_path, true,
                    opt_start_path_default,
                    "year or date of JPO raw data, keep empty for jpo.path"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(TipoImageImporter.class);
    }

    private static List<File> getImageFileList(String patentPath,
            String patentNumber) {
        List<File> imageFileListList = new ArrayList<File>();
        try {
            File file = new File(patentPath);
            File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) {
                if (fileList[i].isDirectory()) {
                    continue;
                } else {
                    for (int j = 0; j < imageType.length; j++) {
                        if (fileList[i].getName().toLowerCase()
                                .endsWith(imageType[j])
                                && fileList[i].getName().contains(patentNumber)
                                && fileList[i].getName().contains("-")) {
                            imageFileListList.add(fileList[i]);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return imageFileListList;
    }

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void uploadImage(String k2imagePath, String patentPath)
            throws Exception {
        File patentDesFile = new File(k2imagePath);
        if (!patentDesFile.exists() || !patentDesFile.isDirectory()) {
            patentDesFile.mkdirs();
        }
        List<File> imageFiles = getImageFileList(patentPath,
                this.patentinfo.patentNumber);
        List<String> allImageSortedList = new LinkedList<String>();
        // 標籤列表
        List<String> firstPageList = new LinkedList<String>();
        List<String> priorityList = new LinkedList<String>();
        List<String> abstractList = new LinkedList<String>();
        List<String> validCountryList = new LinkedList<String>();
        List<String> descriptionList = new LinkedList<String>();
        List<String> claimList = new LinkedList<String>();
        List<String> figureList = new LinkedList<String>();
        // 修正/更正國的標籤列表
        List<String> firstPageList_corrected = new LinkedList<String>();
        List<String> priorityList_corrected = new LinkedList<String>();
        List<String> abstractList_corrected = new LinkedList<String>();
        List<String> validCountryList_corrected = new LinkedList<String>();
        List<String> descriptionList_corrected = new LinkedList<String>();
        List<String> claimList_corrected = new LinkedList<String>();
        List<String> figureList_corrected = new LinkedList<String>();
        // 新式樣專利標籤列表
        List<String> newStyleName = new LinkedList<String>();
        List<String> newStyleDescription = new LinkedList<String>();
        List<String> newStyleFigure = new LinkedList<String>();
        List<String> newStyleName_corrected = new LinkedList<String>();
        List<String> newStyleDescription_corrected = new LinkedList<String>();
        List<String> newStyleFigure_corrected = new LinkedList<String>();
        String patentType = this.patentinfo.type;
        if (patentType == null) {
            for (File subfile : (new File(patentPath)).listFiles()) {
                if (subfile.getAbsolutePath().toLowerCase()
                        .contains("-011.txt")
                        || subfile.getAbsolutePath().toLowerCase()
                                .contains("-111.txt")) {
                    patentType = "新式樣";
                }
            }
        }
        if (patentType == null) {
            patentType = this.getpatentType(this.patentinfo.patentNumber,
                    Integer.toString(this.patentinfo.stat));
        }
        if (patentType == null) {
            log.info("no patent type : " + patentPath);
        }
        for (File imageFile : imageFiles) {
            String imageType = imageFile.getName().split("-")[1];
            if (patentType.equalsIgnoreCase("新式樣")) {
                if (imageType.equals("008")) {
                    newStyleName.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("009")) {
                    newStyleDescription.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("010")) {
                    newStyleFigure.add(imageFile.getAbsolutePath());
                }
                // 修正/更正
                else if (imageType.equals("108")) {
                    newStyleName_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("109")) {
                    newStyleDescription_corrected.add(imageFile
                            .getAbsolutePath());
                } else if (imageType.equals("110")) {
                    newStyleFigure_corrected.add(imageFile.getAbsolutePath());
                }
            } else {
                if (imageType.equals("001")) {
                    firstPageList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("002")) {
                    priorityList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("004")) {
                    abstractList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("008")) {
                    validCountryList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("003")) {
                    descriptionList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("005")) {
                    claimList.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("006")) {
                    figureList.add(imageFile.getAbsolutePath());
                }
                // 修正/更正
                else if (imageType.equals("101") || imageType.equals("301")) {
                    firstPageList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("102") || imageType.equals("302")) {
                    priorityList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("104") || imageType.equals("304")) {
                    abstractList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("108") || imageType.equals("308")) {
                    validCountryList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("103") || imageType.equals("303")) {
                    descriptionList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("105") || imageType.equals("305")) {
                    claimList_corrected.add(imageFile.getAbsolutePath());
                } else if (imageType.equals("106") || imageType.equals("306")) {
                    figureList_corrected.add(imageFile.getAbsolutePath());
                }
            }
        }
        // 新式樣專利
        allImageSortedList.addAll(newStyleName);
        if (newStyleDescription.size() > 0) {
            this.patentinfo.filePageDesc = allImageSortedList.size() + 1;
        }
        allImageSortedList.addAll(newStyleDescription);
        if (newStyleFigure.size() > 0) {
            this.patentinfo.filePageFig = allImageSortedList.size() + 1;
        }
        allImageSortedList.addAll(newStyleFigure);
        // 其他專利----未修正
        allImageSortedList.addAll(firstPageList);
        allImageSortedList.addAll(priorityList);
        allImageSortedList.addAll(abstractList);
        allImageSortedList.addAll(validCountryList);
        if (descriptionList.size() > 0) {
            this.patentinfo.filePageDesc = allImageSortedList.size() + 1;
        }
        allImageSortedList.addAll(descriptionList);
        if (claimList.size() > 0) {
            this.patentinfo.filePageClaim = allImageSortedList.size() + 1;
        }
        allImageSortedList.addAll(claimList);
        if (figureList.size() > 0) {
            this.patentinfo.filePageFig = allImageSortedList.size() + 1;
        }
        allImageSortedList.addAll(figureList);
        // 修正/更正
        allImageSortedList.addAll(firstPageList_corrected);
        allImageSortedList.addAll(priorityList_corrected);
        allImageSortedList.addAll(abstractList_corrected);
        allImageSortedList.addAll(validCountryList_corrected);
        allImageSortedList.addAll(descriptionList_corrected);
        allImageSortedList.addAll(claimList_corrected);
        allImageSortedList.addAll(figureList_corrected);
        this.patentinfo.filePageNumber = allImageSortedList.size();
        this.patentinfo.save();
        for (int i = 0; i < allImageSortedList.size(); i++) {
            String sourcefile = allImageSortedList.get(i);
            String fileType = sourcefile.substring(sourcefile.lastIndexOf("."));
            copyFile(new File(allImageSortedList.get(i)), new File(k2imagePath
                    + File.separator + Integer.toString(i + 1) + fileType));
        }
    }

    private String getpatentType(String patentnumber, String stat)
            throws Exception {
        if (this.conn == null) {
            // get patent type from icma
            String url = "jdbc:oracle:thin:@10.153.24.247:1521:szicma";
            String userName = "icma";
            String password = "critical";

            String driver = "oracle.jdbc.driver.OracleDriver";
            try {
                Class.forName(driver);
                this.conn = DriverManager
                        .getConnection(url, userName, password);
                this.stmt = conn.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        ResultSet rset = null;
        String tmp = null;
        String strSQL = null;

        strSQL = "SELECT PATENT_TYPE FROM PATENT_INFO WHERE COUNTRY_ID = 'TW' AND PATENT_NUMBER = '"
                + patentnumber + "' AND P_I = '" + stat + "'";

        rset = stmt.executeQuery(strSQL);

        if (rset.next()) {
            tmp = rset.getString("PATENT_TYPE").trim();
        }
        rset.close();
        return tmp;
    }

    public static String createrList(String sourcepath) throws IOException {
        if (sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        }
        //String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        String listPath =  sourcepath + ".txt";
        File file = new File(listPath.substring(0,
                listPath.lastIndexOf(File.separator)));
        log.info(file.getAbsoluteFile());
        if (!file.exists() || file.isDirectory()) {
            file.mkdirs();
        }
        File source = new File(sourcepath);

        if (!source.isDirectory()) {
            return "";
        }
        FileWriter fw = new FileWriter(listPath);
        BufferedWriter bw = new BufferedWriter(fw);
        List<String> l = getFilePathList(sourcepath, "pdf");
        for (int i = 0; i < l.size(); i++) {
            System.out.println("Writing" + l.get(i));
            bw.write(l.get(i));
            bw.newLine();
        }
        bw.close();
        fw.close();
        return listPath;
    }

    public TipoImageImporter() {

    }

    public TipoImageImporter(String mongouriStr, String sourcePath,
            String targetPath) {
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath);
        if (!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            String patentPath = "";
            if (startPath != null && !startPath.isEmpty()) {
                while ((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if (patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while ((patentPath = listBufferedReader.readLine()) != null) {
                int stat = 2;
                if (patentPath.contains(File.separator + "an" + File.separator)) {
                    stat = 1;
                } else if (patentPath.contains(File.separator + "gn"
                        + File.separator)) {
                    stat = 2;
                }
                File patentFile = new File(patentPath);
                String patentNumber = patentFile.getName();
                patentNumber = patentNumber.substring(patentNumber
                        .indexOf(patentFile.getParentFile().getName())
                        + patentFile.getParentFile().getName().length());
                // patentNumber =
                // patentNumber.replace(patentFile.getParentFile().getName(),
                // "");
                if (patentNumber.toLowerCase().startsWith("k")) {
                    patentNumber = patentNumber.substring(1);
                }
                try {
                    this.patentinfo = PatentInfoTIPO.findPN(Pto.TIPO,
                            patentNumber);
                } catch (Exception e) {
                    log.info("err patentPath : " + patentPath);
                    throw e;
                }
                if (this.patentinfo != null) {
                    // if(this.patentinfo.filePageNumber == null ||
                    // this.patentinfo.filePageNumber ==0) {
                    String k2imagePath = this.targetPath + File.separator
                            + "tw" + stat + File.separator
                            + dateFormat.format(patentinfo.doDate)
                            + File.separator + patentNumber.toLowerCase()
                            + File.separator + "fullImage";
                    this.uploadImage(k2imagePath, patentPath);
                    pe.addNum().debug(log, 10000,
                            "source:" + patentPath + ", dest:" + k2imagePath);
                    // }
                } else {
                    log.info(patentPath + "'[" + stat + "][" + patentNumber
                            + "]" + " not find!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
    }

    public void destory() throws IOException, SQLException {
        log.info("destory ...");
        if (this.conn != null) {
            this.conn.close();
            this.stmt.close();
        }
    }
    private static List<String> fileNames = new ArrayList<String>();
    public static List<String> getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        System.out.println(fileList[i].getAbsolutePath());
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else {
                        if (fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                            System.out.println(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().endsWith(endWith)) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    public void worker(String[] args) {

        ArgParser argParser;
        try {
            argParser = new ArgParser().addOpt(TipoImageImporter.class)
                    .parse(args);
            MongoAuthInitUtils.reload(argParser);
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
            startPath = argParser.getOptString(opt_start_path);
        } catch (ParseException | UnknownHostException e2) {
            e2.printStackTrace();
        }

        TipoImageImporter imageImpoter = new TipoImageImporter(
                sourcePath, targetPath, startPath);
        try {
            imageImpoter.importImage(startPath);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("exception! press any key to continue");
            try {
                imageImpoter.destory();
            } catch (IOException | SQLException e1) {
                e1.printStackTrace();
            }
        }

    }

    public static void main(String[] args) {
        TipoImageImporter importer = new TipoImageImporter();
        importer.worker(args);
    }
}
