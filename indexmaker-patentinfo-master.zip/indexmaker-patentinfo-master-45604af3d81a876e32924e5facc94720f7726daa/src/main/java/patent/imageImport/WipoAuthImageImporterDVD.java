package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.SimpleBookmark;

/***
 * WIPO DVD image import into mongoDB 
 * @author yiyun 2013/11/06      
 */
public class WipoAuthImageImporterDVD {
    
    private static Log log = LogFactory.getLog(WipoAuthImageImporterDVD.class);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    
    private PatentInfo2 patentInfo;
    private ProcessEstimater pe;
    
    private static String sourcePath;
    private static String targetPath;
    private static String startPath;
    
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = null;
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, "WIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "year or date of WIPO raw data, keep empty for wipo.path"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    static {
        ConfigUtils.setSearchBase(WipoAuthImageImporterDVD.class);
    }
    
    public WipoAuthImageImporterDVD() throws UnknownHostException {
        pe = new ProcessEstimater(0).setFormat("%2$d");    
    }
    
    public void execute(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(WipoAuthImageImporterDVD.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        
        sourcePath = argParser.getOptString(opt_source_path);
        targetPath = argParser.getOptString(opt_target_path);
        startPath = argParser.getOptString(opt_start_path);
         
        importImage();
    }
    
    public static void main(String[] args) throws Exception{
        WipoAuthImageImporterDVD woImport = new WipoAuthImageImporterDVD();
        woImport.importImage();
    }
    
    public void importImage() throws IOException {
        List<String> list = getFileList(new File(sourcePath), "pdf");
//        File listFile = new File("." + File.separator + "list" + sourcePath.replaceAll("E:", "") + ".txt");
//        FileUtils.writeLines(listFile, list);
//        
//        if(!listFile.exists()) {
//            return;
//        }
//        
//        FileReader fr = new FileReader(listFile);
//        BufferedReader br = new BufferedReader(fr);
//        String patentPath = "";
//        if (startPath != null && !startPath.isEmpty()) {
//            while ((patentPath = br.readLine()) != null) {
//                patentPath = patentPath.trim();
//                if (patentPath.equals(startPath.trim())) {
//                        break;
//                }
//            }
//            log.info("start upload from patent path : " + patentPath);
//        }
//        while ((patentPath = br.readLine()) != null) {
        for (String patentPath : list) {
            try {
                patentPath = patentPath.substring(0, patentPath.indexOf(".pdf")+4);
                
                // parse x ml to get the kindCode
                String xmlPath = new File(patentPath).getParent() + File.separator + "wo-published-application.xml";
                SAXReader reader = new SAXReader();
                Document document = reader.read(xmlPath);
                
                String patentNumber = "";
                String kindCode = "";
                String date = "";
                
                String doc_root = "/wo-published-application";
                String doc_openNumber = doc_root + "/wo-bibliographic-data/publication-reference/document-id/doc-number";;
                String doc_openDate = doc_root + "/wo-bibliographic-data/publication-reference/document-id/date";;
                String doc_currentDate = doc_root + "/wo-bibliographic-data/wo-publication-info/wo-correction/document-id/date";
                String doc_kindCode = doc_root + "/wo-bibliographic-data/publication-reference/document-id/kind";
                String[] xmlList = new String[]{doc_openNumber, doc_openDate, doc_kindCode};
                
                for(String s : xmlList) {
                    List<?> projects = document.selectNodes(s);
                    Iterator<?> it = projects.iterator();
                    while(it.hasNext()) {
                        Element elm = (Element) it.next();
                        if(s.equals(doc_openNumber)) {
                            patentNumber = "WO " + elm.getText();
                        } else if(s.equals(doc_openDate)) {
                            date = elm.getText();
                            List<?> nodes = document.selectNodes(doc_currentDate);
                            if(nodes.size() > 0) {
                                date = ((Element)nodes.get(0)).getText();
                            }
                        } else if(s.equals(doc_kindCode)) {
                            kindCode = elm.getText();
                        }
                    }
                }
                patentNumber = patentNumber + " " + kindCode;
                
                patentInfo = PatentInfoWIPO.findPN(Pto.WIPO, patentNumber);
                if(patentInfo != null) {
                    String k2imagePath = targetPath 
                            + File.separator + "wo1" + kindCode.toLowerCase()
                            + File.separator + dateFormat.format(dateTransfer(date))
                            + File.separator + patentNumber.toLowerCase().replaceAll(" ", "").replace("/", "")
                            + File.separator + "fullPage.pdf";
//                    if(new File(k2imagePath).exists()) {
//                        System.out.println(patentNumber + " pdf is exist");
//                        continue;
//                    }
                    FileUtils.copyFile(new File(patentPath), new File(k2imagePath));
                    
                    PdfReader pdfReader = new PdfReader(patentPath);
                    patentInfo.filePageNumber = pdfReader.getNumberOfPages();
                    List<?> bookmarks = SimpleBookmark.getBookmark(pdfReader);
                    if(bookmarks != null) {
                        for (Iterator<?> i = bookmarks.iterator (); i.hasNext ();) {
                             HashMap<?,?> bookMark = (HashMap<?,?>) i.next();
                             String title = (String) bookMark.get("Title");
                             String page = (String) bookMark.get("Page");
                             int pageNumber = Integer.parseInt(page.substring(0, page.indexOf("Fit")).trim());
                             if(title.equals("abstract")) {
                                 patentInfo.filePageFirst = pageNumber;
                             } else if(title.equals("description")) {
                                 patentInfo.filePageDesc = pageNumber;
                             } else if(title.equals("claims")) {
                                 patentInfo.filePageClaim = pageNumber;
                             } else if(title.equals("drawings")) {
                                 patentInfo.filePageFig = pageNumber;
                             } else if(title.equals("wo-search-report")) {
//                                 patentInfo.filePageSearchReport = pageNumber;
                             }
                          }
                    }
                    
                    patentInfo.save();
                    pe.addNum().debug(log, 10000, "source:" + patentPath);
                } else {
                    log.info(patentPath + " not find!");
                }
            } catch (Exception e) {
                log.info(patentPath);
                writeInfo(patentPath + "    " + e.getMessage(), "." + File.separator + "error.txt");
            }
        }
//        br.close();
//        fr.close();
        log.debug("finish");
    }
    
    public List<String> getFileList(File dir, String suffix) {
        if (dir.isDirectory()) {
            File[] fileList = dir.listFiles();
            for(File _file : fileList) {
                if(_file.isDirectory()) {
                    getFileList(_file, suffix);
                } else {
                    if(_file.getName().endsWith(suffix)) {
                        list.add(_file.getAbsolutePath());
                    }
                }
            }
        } else {
            if (dir.getName().endsWith(suffix)) {
                list.add(dir.getAbsolutePath());
            }
        }
        return list;
    }
    private static List<String> list = new ArrayList<String>();
    
    public static void writeInfo(String info, String filePath) {
        File file = new File(filePath);
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
    
    public java.util.Date dateTransfer(String date) {
        try  {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
            return sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
