package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class KipoFirstImageImporter {
    static Log log = LogFactory.getLog(KipoFirstImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private static String sourcePath;  //文件原始路徑
    private static String targetPath;  //PDF保存路徑
    private static String mongouri;    //mongodb uri
    private static String startPath;   //起始路徑，可防止程序斷開后，繼續接著斷開點開始運行
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private String errFile = "./list/error.txt";
    
    private static String fileType ="sgm";
    
    public KipoFirstImageImporter() throws UnknownHostException{
        Class<? extends PatentInfo2> infoClazz = PatentInfoKIPO.class;
        MongoClientURI mongoClientUri = new MongoClientURI(mongouri);
        MongoClient mongoClient = new MongoClient(mongoClientUri);
        DB mongodb = mongoClient.getDB(mongoClientUri.getDatabase());
        MappedClass.getMappedClass(infoClazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");    
        
    }
    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void firstImageImporter() throws IOException {
        String listPath = createListFile(this.sourcePath);
        if (!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            String patentPath = "";
            if (startPath != null && !startPath.isEmpty()) {
                while ((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if (patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }

            while ((patentPath = listBufferedReader.readLine()) != null) {
                // 韓國專利文字信息存在SGM文檔 和XML文檔
                //String documentPath = documentPath(patentPath);
                //String documentPath = documentPath(patentPath);

                if (patentPath == null) {
                    log.info("Error path : " + patentPath);
                } else {
                    try {
                        boolean isSGMFile = false; // 判斷是否為SGM 文檔
                        if (patentPath.contains("SGM")) {
                            isSGMFile = true;
                        }
                        String document = readFileByChars(patentPath);
                        int stat = getStat(document, isSGMFile);
                        
                        String firstImagePath = getFirstImagePath(patentPath,document);

                        File firstImageFile = new File(firstImagePath);

                        if (firstImageFile.exists()) {
                            
                            File sourceFile = new File(patentPath);
                            
                            String sourceFileName = sourceFile.getName();
                            String patentNumber = sourceFileName.substring(0,sourceFileName.lastIndexOf(".")); //專利號
                            
                            try {
                                this.patentinfo = PatentInfoKIPO.findPN(
                                        Pto.KIPO, patentNumber, stat);
                            } catch (Exception e) {
                                log.info("err patentPath : " + patentPath);
                                writerFile("./errorImportImage.txt", patentPath);
                                // e.printStackTrace();
                                // throw e;

                                FileUtils
                                        .write(new File("errFile"), patentPath);
                            }
                            if (this.patentinfo != null) {
                                String type =firstImageFile.getName().substring(firstImageFile.getName().lastIndexOf("."));
                                String k2imagePath = this.targetPath
                                        + File.separator
                                        + "kr"
                                        + stat
                                        + File.separator
                                        + dateFormat
                                                .format(patentinfo.doDate)
                                        + File.separator
                                        + patentNumber.toLowerCase()
                                        + File.separator + "firstImage"+type;
                                copyFile(
                                        new File(firstImageFile.getAbsolutePath()),
                                        new File(k2imagePath));
                        
                                pe.addNum().debug(
                                        log,
                                        10000,
                                        "source:" + patentPath + ", dest:"
                                                + k2imagePath);
                            
                            } else {
                                log.info(patentPath + "'[" + stat + "]"
                                        + " not find!");
                            }
                        } else {
                            log.info(patentPath + "'[" + stat + "]"
                                    + " no tif!");
                        }

                    } catch (Exception e) {
                        writerFile("./errorImportImage.txt", patentPath);
                    }

                }
            }

        }

    }
    
    /**
     * 
     * @param filePath  XML/SGM 文檔路徑
     * @param fileContent  XML/SGM 文檔內容
     * @return firstImagePath 構成首頁切圖路徑 
     */
    public static String getFirstImagePath(String filePath,String fileContent){
        String firstImagePath = null;
        
        String id = null;
        String fileName = null;
        
        if(filePath.endsWith("xml")){ // 獲取xml對應的首頁切圖
            //獲取 ID值
            Pattern p = Pattern.compile("<DrawReference idref=\"(.*?)\"/>");        
            Matcher m = p.matcher(fileContent);        
            while(m.find()) {            
                id = m.group(1);
             }

            //獲取文件名
            //  <Drawing id="10"><EMI file="112003034167929-pat00010.tif" height="180" id="10" width="136"/></Drawing>
            if(id !=null){
                String tag = "<Drawing id=\""+id+"\">";
                fileContent = fileContent.substring(fileContent.indexOf(tag));
                fileContent = fileContent.substring(0, fileContent.indexOf("</Drawing>"));
                
            //    String regex ="file=\""+"(.*?)";
                String regex = "(?i)file\\s*=\\s*\"(.*?)\"";
                
                Pattern p2 = Pattern.compile(regex);
                
                Matcher m2 = p2.matcher(fileContent);        
                while(m2.find()) {            
                    fileName = m2.group(1);
                    
                 }
            }else{
                //<AbstractFigure><EMI file="R1020030075913.tif" height="119" id="5" width="181"/></AbstractFigure>
                String regex = "<EMI.*\\s*(?i)file\\s*=\\s*\"(.*?)\"";
                
                Pattern p2 = Pattern.compile(regex);
                
                Matcher m2 = p2.matcher(fileContent);    
                                
                while(m2.find()) {            
                    fileName = m2.group(1);
                    break;
                 }
                if(fileName == null){
                    String regexImg = "<img.*\\s*(?i)file\\s*=\\s*\"(.*?)\"";
                    
                    Pattern p3 = Pattern.compile(regexImg);
                    
                    Matcher m3 = p3.matcher(fileContent);    
                                    
                    while(m3.find()) {            
                        fileName = m3.group(1);
                        break;
                     }
                }
            }
            
            if(fileName !=null){            
                String parentPath = filePath.substring(0, filePath.lastIndexOf(File.separator)+1);
                firstImagePath = parentPath + fileName;                       
            }
            
            
        }else{ // 獲取SGM對應的首頁切圖
            //獲取 ID值  <DRAWREF IDREF="1">
            Pattern p = Pattern.compile("<DRAWREF IDREF=\"(.*?)\"/>");        
            Matcher m = p.matcher(fileContent);        
            while(m.find()) {            
                id = m.group(1);
             }
            
            //獲取文件名
            //  <Drawing id="10"><EMI file="112003034167929-pat00010.tif" height="180" id="10" width="136"/></Drawing>
            if(id !=null){
                //  <DRAW ID="1"><EMI ID=1 HE=76 WI=154 FILE="utm00001.tif"></DRAW>
                String tag = "<DRAW ID=\""+id+"\">";
                fileContent = fileContent.substring(fileContent.indexOf(tag));
                fileContent = fileContent.substring(0, fileContent.indexOf("</DRAW"));
                String regex = "(?i)file\\s*=\\s*\"(.*?)\"";
                
                Pattern p2 = Pattern.compile(regex);
                
                Matcher m2 = p2.matcher(fileContent);        
                while(m2.find()) {            
                    fileName = m2.group(1);
                    
                 }
            }else{
                //<EMI ID="1" HE=72 WI=59 FILE="1.JPG">
                String regex = "<EMI.*\\s*(?i)file\\s*=\\s*\"(.*?)\"";
                
                Pattern p2 = Pattern.compile(regex);
                
                Matcher m2 = p2.matcher(fileContent);    
                                
                while(m2.find()) {            
                    fileName = m2.group(1);
                    break;
                 }
                if(fileName == null){
                    String regexImg = "<img.*\\s*(?i)file\\s*=\\s*\"(.*?)\"";
                    
                    Pattern p3 = Pattern.compile(regexImg);
                    
                    Matcher m3 = p3.matcher(fileContent);    
                                    
                    while(m3.find()) {            
                        fileName = m3.group(1);
                        break;
                     }
                }
                
                
                
            }
            
            if(fileName !=null){            
                String parentPath = filePath.substring(0, filePath.lastIndexOf(File.separator)+1);
                firstImagePath = parentPath + fileName;                       
            }        
            
        }
        
        return firstImagePath;
        
    }
    /**
     * 通過PDF絕對路徑 構造出 韓國專利的 SGM/XML文檔路徑
     * @param pdfPath  PDF 文檔絕對路徑 
     * @return
     */
    public static String documentPath(String pdfPath){
        //kipo\Design\2001\20010115\3019960005927\B012\SGM\3019960005927.SGM
        String documentPath = null;
        //sgm 文檔存在與 ".sgm" 和 ".SGM" 文檔結尾的文檔
        String sgmPath1 = pdfPath.replaceAll("PDF", "SGM");
        sgmPath1 = sgmPath1.replaceAll("pdf", "sgm");
        String sgmPath2 = sgmPath1.replaceAll("pdf", "SGM");
        File sgmFile1 = new File(sgmPath1);
        File sgmFile2 = new File(sgmPath2);
        if(sgmFile1.exists()){//如何sgm文檔存在，則返回sgm 文檔路徑
            return sgmPath1;
        }else if(sgmFile2.exists()){
            return sgmPath2;
        }
        //如果不是SGM文檔，則為XML文檔
        //KIPO\Patent&UtilityModel_Registered\2006\20060109\1019997000116\B012\XML\1019997000116.xml
        String xmlPath =  pdfPath.replaceAll("PDF", "XML");
        xmlPath = xmlPath.replaceAll("pdf", "xml");
        File xmlFile = new File(xmlPath);
        if(xmlFile.exists()){
            return xmlPath;
        }
        
        return documentPath;
    }
    /**
     * get the file list of the source file and write the list into a txt file 
     * @param sourcePath    image source file  directory
     * @return                the file path of the list file
     */
    public static String createListFile2(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            
            bw.close();
            fw.close();
        }
        return listPath;
    }
    
    public static String createListFile(String sourcepath)throws IOException{
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String name = sourcepath.substring(sourcepath.lastIndexOf(File.separator));
        String listPath = "." + File.separator + "list"  + name + ".txt";
        
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }        
            File source = new File(sourcepath);
            if(!(source.isDirectory())) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
        
    }
    /**
     * 
     * @param file 父文件
     * @param fielType 文件類型/文件后序名
     * @return list
     */
    static List<String> fileList = new ArrayList<>();
    public static List<String> getFileList(File file, String fielType) {
        
        File[] files = file.listFiles();

        if (files != null && files.length > 0) {

            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    String path = files[i].getAbsolutePath();
                    if (path.endsWith(fielType)||path.endsWith(fielType.toUpperCase())) {
                        if(fielType.equals("sgm")){
                            File sgmFile = new File(path);
                            String sgmFileName = sgmFile.getName();
                            if(sgmFileName.startsWith("10")||sgmFileName.startsWith("20")||sgmFileName.startsWith("30")){
                                System.out.println(path);
                                fileList.add(path);
                            }
                        }else{
                            System.out.println(path);
                            fileList.add(path);    
                        }                        
                    }
                } else {
                    
                    getFileList(files[i], fielType);
                    
                }
            }
        }
        return fileList;
    }
    
    /**
     * 讀取文件內容
     * @param filePath 文件絕對路徑 
     * @return
     */
    public String readFileByChars(String filePath) {
         File file = new File(filePath);
         if( ! (file.exists()) ){
             System.out.println("file is not exists: "+filePath);
         }
         
         try {
             InputStreamReader ir = new InputStreamReader(new FileInputStream(file),"EUC_KR");
             BufferedReader br = new BufferedReader(ir);
             StringBuffer sb = new StringBuffer();
             
             String line;
             while( (line = br.readLine()) != null){
                 sb.append(line);
             }
             
             String result = sb.toString();
             return result;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;    
    }
    /**
     * 判斷分開公告
     * @param document  文檔內內
     * @param isSGMFile 
     * @return
     */
    public static int getStat(String document,boolean isSGMFile){
        int stat =1;
        if(isSGMFile){
            int Pn1 = document.indexOf("<RG");
            int Pn2 = document.indexOf("<ALLRG");
            if(Pn1 !=-1){
                stat=2;
            }else if(Pn2!=-1){
                stat=2;
            }else{
                stat=1;
            }
        }else{
            int Pn = document.indexOf("<KR_Register");
            if(Pn > 0){
                stat=2;
            }else{
                stat=1;
            }
        }
        return stat;
    }
    /**
     * writer the string to file
     * @param fileName File name
     * @param writerStr  writer string
     */
    public static void writerFile(String fileName, String writerStr) {
        File wFile = new File(fileName);
        try {
            if (!wFile.exists()) {
                wFile.createNewFile();
            }
            FileWriter wf = new FileWriter

            (wFile, true);
            BufferedWriter bw = new

            BufferedWriter(wf);
            byte[] buf = new byte[1024];
            int k = 0;
            bw.write(writerStr);
            bw.newLine();
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("寫文件出錯");
        }
    }
    
    
    
    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;                  
        
        try {
            cmd = parser.parse( options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
           
            if(mongouri == null || mongouri.isEmpty() || sourcePath == null || sourcePath.isEmpty() ||
               targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp( "IcmaKipoImporter", options );
            return;
        }
        try {
             KipoFirstImageImporter kipoFirstImageImporter = new KipoFirstImageImporter();
             System.out.println("開始上傳首頁影像...");
             kipoFirstImageImporter.firstImageImporter();
             System.out.println("首頁影像上傳結束...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    
       
        
    }
}
