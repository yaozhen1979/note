package patent.imageImport;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.imageio.ImageIO;

//import org.icepdf.core.exceptions.PDFException;
//import org.icepdf.core.exceptions.PDFSecurityException;
//import org.icepdf.core.pobjects.Document;


public class JpoFirstImageGet1 {
    /**
     * @param pdfpath  pdf位置
     * @param filepath 目地目錄
     * @param outpath  目地檔案
     * @throws PDFException
     * @throws PDFSecurityException
     * @throws IOException
     */
//    private void ExtractFP(String pdfpath , String  filepath , String outpath) throws PDFException, PDFSecurityException, IOException
//    {
//        Document document = new Document();
//        document.setFile(pdfpath);
//        Enumeration tmpImages = document.getPageImages(0).elements();
//        int count = 0;
//        while (tmpImages.hasMoreElements())
//        {
//            Image image = (Image) tmpImages.nextElement();
//            if(count==1)
//            {    
//                   new File(filepath).mkdirs();
//                   BufferedImage bufferedImage = new BufferedImage(
//                      image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
//                   Graphics2D g2d = bufferedImage.createGraphics();
//                   g2d.drawImage(image, 0, 0, image.getWidth(null), image.getHeight(null), null);
//                   RenderedImage rendImage = bufferedImage;
//                   try {
//                      File file = new File(outpath);
//                      ImageIO.write(rendImage, "png", file);
//                   } catch (IOException e) {
//                      e.printStackTrace();
//                   }
//                   g2d.dispose();
//                   bufferedImage.flush();
//                break;
//            }
//            count++;
//        }
//        document.dispose();
//    }
//    public static void main(String args[]){
//        JpoFirstImageGet1 image = new JpoFirstImageGet1();
//        String sourcePath = "e:\\Harvey\\1995028573\\2011000023\\2011000023.pdf";
//        String filepath = "e:\\Harvey\\1995test";
//        String outpath = "e:\\Harvey\\1995test\\firstPage.png";
//        try {
//            image.ExtractFP(sourcePath, filepath, outpath);
//        } catch (PDFException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (PDFSecurityException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }

}
