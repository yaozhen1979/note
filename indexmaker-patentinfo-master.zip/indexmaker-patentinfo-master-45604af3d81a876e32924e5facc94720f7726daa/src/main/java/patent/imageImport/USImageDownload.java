package patent.imageImport;



import itec.patent.common.MongoInitUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.AuthCache;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;


@SuppressWarnings("deprecation")
public class USImageDownload {
    static Log log=LogFactory.getLog(USImageDownload.class);
    private String url = "http://pimg-fpiw.uspto.gov/fdd/";
    private String url1="http://pimg-faiw.uspto.gov/fdd/";
    
    public static final String opt_target_path = "target";
    public static final String opt_target_path_default = null;
    String usptoFullPDFpath=null;
    static File file= null;
    
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, ""),
        new ArgParser.Option("t", null, true, "", "Patent open/decision date rage\n" +
                "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n" +
                "Format: YYYYMMDD+n (20110101+31)\n" +
                "Format: YYYYMM+n (201101+12)\n" +
                "Format: YYYYMM+n (2011+1)\n"),
    };
    
    public static final Class<?>[] optDep = {
        MongoInitUtils.class,
    };
    
    static {
        ConfigUtils.setSearchBase(USImageDownload.class);
    }
    
    public static void main(String[] args) throws Exception {
        
        USImageDownload usImageDownload=new USImageDownload();
    }

    public void execute(String[] args) throws Exception {    
        
        ArgParser argParser = new ArgParser().addOpt(USgetPatentNumber.class).parse(args);
    

        FileReader reader = new FileReader(new File(ConfigUtils.get("us_save_patentNumber")));
        BufferedReader br = new BufferedReader(reader);
        String PN = null;
        while((PN=br.readLine())!=null){
        
            String patentNumber = PN.substring(0,11);
            String pnquery="";
            if(patentNumber.indexOf("D")>0){
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/D0"+patentNumber.substring(5,6);
            }else if (patentNumber.indexOf("PP")>0) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/PP0";
            }else if (patentNumber.indexOf("RE")>0) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/RE0";
            }else if (patentNumber.matches("US\\d+{9}")) {
                pnquery=patentNumber.substring(9,11)+"/"+patentNumber.substring(6,9)+"/0"+patentNumber.substring(4,6);
            }else if(patentNumber.matches("\\d+{11}")){
                pnquery=patentNumber.substring(9, 11)+"/"+patentNumber.substring(0,4)+"/"+patentNumber.substring(7,9)+"/"+patentNumber.substring(4,7);
            }
            if(patentNumber.matches("\\d+{11}")){
                usptoFullPDFpath=url1+pnquery+"/0.pdf";
            }else{
                usptoFullPDFpath=url+pnquery+"/0.pdf";
            }
            String k2FullPDFpath=ConfigUtils.get("us_save_image_target")+File.separator+ PN.substring(11,16).toLowerCase()
                    +File.separator+PN.substring(16,20)+File.separator+PN.substring(21,23)+File.separator+PN.substring(24)
                    +File.separator+ PN.substring(0,11).toLowerCase().replaceAll(" ", "").replace("/", "")
                    +File.separator+ "fullPage.pdf";
            File fullPDF =new File(k2FullPDFpath);
            if (fullPDF.exists()) {
                log.debug("patentNumber:"+ patentNumber + " already exist" + "url:" + usptoFullPDFpath);
                continue;
            }else {
                fullPDF.getParentFile().mkdirs();
            }
            
            if(executeGetMethod1(usptoFullPDFpath)==404){
                log.debug("patentNumber:"+patentNumber +"no PDF , url"+ usptoFullPDFpath);
                continue;
            }else{
                try {
                    byte[] pdfContent=executeGetMethod(usptoFullPDFpath);
                    /*if(pdfContent.length==0){
                    log.debug("patentNumber:"+patentNumber +"no PDF , url"+ usptoFullPDFpath);    
                    continue;
                }*/
                    
                    FileOutputStream fos=new FileOutputStream(new File(k2FullPDFpath));
                    fos.write(pdfContent);
                    fos.close();
                    //br.close();
                    log.debug("patentNumber:" +patentNumber+" download success , url:"+usptoFullPDFpath);
                } catch (Exception e) {
                    writeInfo(new File("."+File.separator+"FullPDFerror.txt"), "patentNumber:"+patentNumber+e.getMessage()+",url:"+usptoFullPDFpath);
                    e.printStackTrace();
                    Thread.sleep(5000);
                    execute(args);
                }    
            }
        }
    }
    
    private DefaultHttpClient getHttpClient(){
         DefaultHttpClient httpClient = null;
        if (httpClient==null) {
            PoolingClientConnectionManager cm=new PoolingClientConnectionManager();
            httpClient=new DefaultHttpClient(cm);
            
            HttpHost proxy = new HttpHost(ConfigUtils.get("proxyHost"), Integer.parseInt(ConfigUtils.get("proxyPort"))); 
            httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
            
            /*httpClient.getCredentialsProvider().setCredentials(
                    new AuthScope(proxy_ip, Integer.parseInt(proxy_port)),
                    new UsernamePasswordCredentials(username, password));*/
            AuthCache authCache = new BasicAuthCache();
            BasicScheme basicAuth = new BasicScheme();
            authCache.put(proxy, basicAuth);
            BasicHttpContext localcontext = new BasicHttpContext();
            localcontext.setAttribute(ClientContext.AUTH_CACHE, authCache);
        }
        return httpClient;
    }
    
    private void writeInfo(File file, String info) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
        
    }
    
    public static Date stringToDate(String s){
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
        try {
            Date date = format.parse(s);
            return date;
        } catch (ParseException e) {
            return null;
        } 
    }

    private byte[] executeGetMethod(String url) throws Exception{
        byte[] content =new byte[50*1024*1024];
        DefaultHttpClient httpClient=getHttpClient();
        HttpGet getMethod = new HttpGet(url);
        HttpResponse response = httpClient.execute(getMethod);
        
        int statusCode = response.getStatusLine().getStatusCode();
        //System.out.println(statusCode);
        if (statusCode==200) {
            HttpEntity entity =response.getEntity();
            if (entity!=null) {
                content=EntityUtils.toByteArray(entity);
            }
        }
        return content;
    }
    
    private int executeGetMethod1(String url) throws Exception{
        DefaultHttpClient httpClient=getHttpClient();
        HttpGet getMethod = new HttpGet(url);
        HttpResponse response = httpClient.execute(getMethod);
        
        int statusCode = response.getStatusLine().getStatusCode();
        return statusCode;
    }
    
        
    
}
