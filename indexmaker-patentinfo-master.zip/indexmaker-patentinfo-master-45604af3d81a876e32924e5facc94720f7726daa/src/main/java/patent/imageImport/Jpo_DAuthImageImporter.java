package patent.imageImport;

import com.mongodb.*;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import java.io.*;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.cli.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ProcessEstimater;

public class Jpo_DAuthImageImporter {

    static Log log = LogFactory.getLog(Jpo_DAuthImageImporter.class);
    private static SimpleDateFormat dateFormat;
    private static String sourcePath;
    private static String targetPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private static List fileNames = new ArrayList();

    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";

    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";

    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = null;

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_source_path, true,
                    opt_source_path_default,
                    "mongodb uri, start with mongodb://"),
            new ArgParser.Option(null, opt_target_path, true,
                    opt_target_path_default,
                    "JPO raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, opt_start_path, true,
                    opt_start_path_default,
                    "year or date of JPO raw data, keep empty for jpo.path"), };
    static {
        dateFormat = new SimpleDateFormat((new StringBuilder("yyyy"))
                .append(File.separator).append("MM").append(File.separator)
                .append("dd").toString());
    }

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists())
                pd.mkdirs();
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte buf[] = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0)
                out.write(buf, 0, len);
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File fileList[] = file.listFiles();
                for (int i = 0; i < fileList.length; i++)
                    if (fileList[i].isDirectory()) {
                        System.out.println(fileList[i].getAbsolutePath());
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else if (fileList[i].getName().endsWith(endWith)) {
                        fileNames.add(fileList[i].getPath());
                        System.out.println(fileList[i].getPath());
                    }

            } else if (file.getName().endsWith(endWith))
                fileNames.add(file.getPath());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }

    public static String createrList(String sourcepath) throws IOException {
        if (sourcepath.endsWith(File.separator))
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        File file = new File(listPath.substring(0,
                listPath.lastIndexOf(File.separator)));
        log.info(file.getAbsoluteFile());
        if (!file.exists() || file.isDirectory())
            file.mkdirs();
        File source = new File(sourcepath);
        if (!source.isDirectory())
            return "";
        FileWriter fw = new FileWriter(listPath);
        BufferedWriter bw = new BufferedWriter(fw);
        List l = getFilePathList(sourcepath, "pdf");
        for (int i = 0; i < l.size(); i++) {
            System.out.println((new StringBuilder("Writing")).append(
                    (String) l.get(i)).toString());
            bw.write((String) l.get(i));
            bw.newLine();
        }

        bw.close();
        fw.close();
        return listPath;
    }

    public String convertPatentNumber(String typecode, String num, String date) {
        if (num.indexOf("_") != -1)
            num = (new StringBuilder("\u610F\u5320\u985E\u4F3C")).append(
                    num.replace("_", "-")).toString();
        else
            num = (new StringBuilder("\u610F\u5320\u767B\u9332")).append(num)
                    .toString();
        return num;
    }

    public String getHeiseiYear(String year) {
        int temp = Integer.parseInt(year);
        if (temp - 1989 < 0)
            return null;
        temp = (temp - 1989) + 1;
        String heiseiYear = String.valueOf(temp);
        int i = heiseiYear.length();
        if (i < 2)
            heiseiYear = (new StringBuilder("0")).append(heiseiYear).toString();
        return heiseiYear;
    }

    public void importImage() throws Exception {
        String listPath = createrList(this.sourcePath);
        if (!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            for (String patentPath = ""; (patentPath = listBufferedReader
                    .readLine()) != null;) {
                patentPath = patentPath.trim();
                log.info((new StringBuilder("start upload from patent path : "))
                        .append(patentPath).toString());
                int stat = 2;
                File patentFile = new File(patentPath);
                String pdfname = patentPath.substring(
                        patentPath.lastIndexOf(File.separator) + 1,
                        patentPath.length());
                String path = patentPath.substring(patentPath.indexOf("jp"));
                String date = "";
                File pdfFile = new File(patentFile.getAbsolutePath());
                pdfname = pdfname.replace(".pdf", "");
                if (!pdfFile.exists())
                    pdfFile = new File((new StringBuilder(
                            String.valueOf(patentFile.getAbsolutePath())))
                            .append(File.separator).append(pdfname)
                            .append(".pdf").toString());
                if (pdfFile.exists()) {
                    String patentNumber = convertPatentNumber(patentPath,
                            pdfname, date);
                    if (patentPath.contains("P1") || patentPath.contains("U1")
                            || patentPath.contains("U3"))
                        stat = 1;
                    else
                        stat = 2;
                    try {
                        patentinfo = PatentInfoJPO
                                .findPN(Pto.JPO, patentNumber);
                    } catch (Exception e) {
                        log.info((new StringBuilder("err patentPath : "))
                                .append(patentPath).toString());
                        throw e;
                    }
                    if (patentinfo != null) {
                        String k2imagePath = (new StringBuilder(
                                String.valueOf(targetPath)))
                                .append(File.separator).append("jp")
                                .append(stat)
                                .append(patentinfo.kindcode.toLowerCase())
                                .append(File.separator)
                                .append(dateFormat.format(patentinfo.doDate))
                                .append(File.separator)
                                .append(patentNumber.toLowerCase())
                                .append(File.separator).append("fullPage.pdf")
                                .toString();
                        copyFile(new File(pdfFile.getAbsolutePath()), new File(
                                k2imagePath));
                        InputStream in = new FileInputStream(pdfFile);
                        PDFParser parser = new PDFParser(in);
                        parser.parse();
                        PDDocument pdfdocument = parser.getPDDocument();
                        patentinfo.filePageNumber = Integer.valueOf(pdfdocument
                                .getNumberOfPages());
                        patentinfo.save();
                        pdfdocument.close();
                        in.close();
                        pe.addNum().debug(
                                log,
                                10000L,
                                (new StringBuilder("source:"))
                                        .append(patentPath).append(", dest:")
                                        .append(k2imagePath).toString());
                    } else {
                        log.info((new StringBuilder(String.valueOf(patentPath)))
                                .append("'[").append(stat).append("]")
                                .append(" not find!").toString());
                    }
                } else {
                    log.info((new StringBuilder(String.valueOf(patentPath)))
                            .append("'[").append(stat).append("]")
                            .append(" no pdf!").toString());
                }
            }

            listFileReader.close();
            listBufferedReader.close();
        }
    }

    public Jpo_DAuthImageImporter() {
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    public Jpo_DAuthImageImporter(String mongouriStr, String sourcePath,
            String targetPath) {
        try {
            Class infoclazz = PatentInfoJPO.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;
            if (sourcePath.endsWith(File.separator))
                sourcePath = sourcePath.substring(0, sourcePath.length() - 1);
            pe = (new ProcessEstimater(0L)).setFormat("%2$d");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public void worker(String args[]) {
        try {
            ArgParser argParser = new ArgParser().addOpt(
                    JpoAuthImageImporter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
        } catch (UnknownHostException | ParseException e1) {
            e1.printStackTrace();
        }

        Jpo_DAuthImageImporter imageImporter = new Jpo_DAuthImageImporter();
        try {
            imageImporter.importImage();
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public static void main(String args[]) {
        Jpo_DAuthImageImporter importer = new Jpo_DAuthImageImporter();
        importer.worker(args);
    }

}
