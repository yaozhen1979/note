package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoEPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.MongoClient;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/***
 * 
 * @author yh
 * 從解壓文檔中上傳影像檔
 */
public class EpoAuthClipImageImporter {

    static Log log = LogFactory.getLog(EpoAuthClipImageImporter.class);
    private ProcessEstimater pe;
    private static List<String> fileNames = new ArrayList<String>();
    private BufferedReader listBufferedReader;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    DateFormat format = new SimpleDateFormat("yyyyMMdd");
    private PatentInfo2 patentinfo;
    
    private static String sourcePath;  //文件原始路徑
    private static String targetPath;  //PDF保存路徑
    private static String startPath;   //起始路徑，可防止程序斷開后，繼續接著斷開點開始運行
    
    
    //EPO image type
    private String imageTypeHead   = "";
    private String imageTypeTail   = "PDF";
    private static String fileHead = "DOC";//2006年之前EP，(2006-2013)之後DOC
    private static String country  = "EP";
    private static String fileTail = "xml";
    //EPO tif
    private String tifImageHead = "img";
    private String tifImageTail = "tif";
    //EPO clipImage type
    private String clipImageTypeHead  = "imgf";
    //EPO figure 内文嵌图
    private String figureHead = "imgb";
    //EPO Srep 调查报告
    private String drawingHead = "srep";
    
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "\\\\YH-PC\\epImageOriginData\\2014(29AB)";
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "\\\\YH-PC\\epImageOriginData\\test";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = null;


    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "year or date of KIPO raw data, keep empty for kipo.path"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(EpoAuthClipImageImporter.class);
    }
    
    public EpoAuthClipImageImporter() throws UnknownHostException{
    
        pe = new ProcessEstimater(0).setFormat("%2$d");    
        
    }
    
    private void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (Exception e) {
            copyString(src + " : " + "copy failed : " + e ,new File("." + File.separator + "log" + File.separator   + "error.txt"));
            e.printStackTrace();
        }
    }
    
    
    public  String createrList(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        /** get firstPage list*/
        /**修改讀取影像檔list寫入文件路徑modified by luken**/
       // String listPath = "." + File.separator + "list" + sourcepath + File.separator +"firstImage.txt";
        String listPath = sourcepath + File.separator +"clipImage.txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
        }
        /** get list of source file start with img ,endWith tif*/
        List<String> fileList = getFilePathList(sourcepath, tifImageHead, tifImageTail);
        FileWriter fw = new FileWriter(listPath);
        BufferedWriter bw = new BufferedWriter(fw);
        for(Iterator<String> it = fileList.iterator(); it.hasNext(); ) {
            bw.write(it.next());
            bw.newLine();
        }
        bw.close();
        fw.close();
        
        return listPath;
    }


    /**
     * get listFiles from target files
     * @param root
     * @param startWith
     * @param endWith
     * @return
     */
    public static List<String> getFilePathList(String root, String startWith, String endWith) {
        if(root.endsWith(File.separator)) {
            root = root.substring(0,root.length()-1);
        }
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        getFilePathList(fileList[i].getPath(), startWith, endWith);
                    } else {
                        if (fileList[i].getName().startsWith(startWith) && fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getParentFile().getPath());
                            System.out.println(fileList[i].getPath());
                            break;
                        }
                    }
                }
            } else {
                if (file.getName().startsWith(startWith) && file.getName().endsWith(endWith) ) {
                    fileNames.add(file.getPath());
                    System.out.println(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    
    

    public void importImage() throws Exception {
        String filePath = createrList(this.sourcePath);
        if (!filePath.isEmpty()) {
            FileReader listFileReader = new FileReader(filePath);
            listBufferedReader = new BufferedReader(listFileReader);
            String patentPath = "";
            if(startPath != null && !startPath.isEmpty())
            {
                while((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if(patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while((patentPath = listBufferedReader.readLine()) != null) {
                String patentNumber = "" , kindCode = "A1" , pubDate = null , xmlPath; 
                int stat = 2 , clipCount = 0, figureCount = 0; 
                File patentFile = new File(patentPath);
                File pdfFile = new File(patentFile.getAbsolutePath());
                if (pdfFile.exists()) {
                    
                    /** parser xml get Patent stat ,kindcode and no*/
                    xmlPath = getXmlOfImage(patentPath);
                    EPXmlData EPXmlData = null;
                    if (!xmlPath.equals("")) {
                        EPXmlData = parser(xmlPath);
                    if (!EPXmlData.equals(null) || EPXmlData!= null) {
                        patentNumber = country + EPXmlData.getPatentNumber_B110() + EPXmlData.getKindCode_B130();
                        kindCode = EPXmlData.getKindCode_B130();
                        stat = EPXmlData.getPnI();
                        pubDate = EPXmlData.getPubDate();
                    /** upload clipImage*/
                    DateFormat format = new SimpleDateFormat("yyyyMMdd"); 
                    Date date = format.parse(pubDate);
                    
                    List<String> imagesPath = getFiles(patentPath);
                    for (String imagePath : imagesPath) {
                        File imageFile = new File(imagePath);
                        File imagePathFile = new File(imageFile.getAbsolutePath());
                        
                        String clipNameTmp = imagePath.substring(imagePath.lastIndexOf(File.separator) + 1, imagePath.length());
                        //for cliam 和 description内插图
                        if (clipNameTmp.startsWith(figureHead)) {
                            String k2imagePath = this.targetPath +  (File.separator + "data" + File.separator +"ep" + stat + kindCode + File.separator + dateFormat.format(date)
                                    + File.separator + patentNumber + File.separator + "figure" + File.separator).toLowerCase() + clipNameTmp;
                            copyFile(imagePathFile , new File(k2imagePath));
                            ++figureCount;
                            pe.addNum().debug(log, 10000, "figure source:" + patentPath + ", dest:" + k2imagePath);
                        }
                        //srep image 暂不处理
                        if (clipNameTmp.startsWith(drawingHead)) {
                            //暂不处理
                        }
                        //for  clipImage
                        if (clipNameTmp.startsWith(clipImageTypeHead)) {
                            String clipNamePattern = "(\\d{1,5})";
                            Pattern pattern = Pattern.compile(clipNamePattern);
                            Matcher match = pattern.matcher(clipNameTmp);
                            int clipName = 1;
                            while(match.find()){
                                for (int i  = 0; i < match.groupCount(); i++) {
                                    clipName = Integer.parseInt(match.group(0));
                                }
                            } 
                            String k2imagePath = this.targetPath +  (File.separator + "data" + File.separator +"ep" + stat + kindCode + File.separator + dateFormat.format(date)
                                    + File.separator + patentNumber + File.separator + "clip" + File.separator).toLowerCase() + clipName + ".tif";
                            copyFile(imagePathFile , new File(k2imagePath));
                            ++clipCount;
                            pe.addNum().debug(log, 10000, "clip source:" + patentPath + ", dest:" + k2imagePath);
                        }
                    }
                    //上传 figureCount,clipCount
                    try {
                        this.patentinfo = PatentInfoEPO.findPN(Pto.EPO, patentNumber);
                    } catch (Exception e) {
                        log.info("err patentPath : " + patentPath);
                        copyString(patentPath +  " : " + patentNumber + " : no find patentInfo : " + e ,new File("." + File.separator + "log" + File.separator   + "error.txt"));
                    }
                    if (this.patentinfo != null) {
                        this.patentinfo.figurePageNumber = figureCount;
                        this.patentinfo.clipPageNumber = clipCount;
                        this.patentinfo.save();
                    }
                }
            }
            else {
                    log.info("no xml!");
                    copyString(patentPath + " : " + "no xml" ,new File("." + File.separator +  "log" + File.separator   + "error.txt"));
                    continue;
            }
        }
    }
}
    }
    


    private patent.imageImport.EPXmlData parser(
            String xmlPath) {
        SAXReader reader = new SAXReader();
        Document document;
        EPXmlData EPXmlData = new EPXmlData();
        try {
            reader.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            document = reader.read(new File(xmlPath));
            String[] xmlList = new String[] {
                    "/ep-patent-document",
                    "/ep-patent-document" + "/SDOBI/B100/B110",
                    "/ep-patent-document" + "/SDOBI/B100/B130",
                    };

            for (String s : xmlList) {
                List<?> projects = document.selectNodes(s);
                Iterator<?> it = projects.iterator();
                while (it.hasNext()) {
                    Element elm = (Element) it.next();
                    /** publish or decision Date*/
                    if (s.equals(xmlList[0])) {
                        String datePattern = "date-publ=\"([\\s\\S]*?)\"";
                        Pattern pattern = Pattern.compile(datePattern);
                        Matcher matcher = pattern.matcher(elm.asXML());
                        while(matcher.find()){
                            for (int i  = 0; i < matcher.groupCount(); i++) {
                                String tempDate = matcher.group(i);
                                EPXmlData.pubDate = tempDate.substring(tempDate.indexOf("\"") + 1, tempDate.lastIndexOf("\""));
                            }
                        } 
                    }
                    /** patentStatus*/
                    if(s.equals(xmlList[2])) 
                    {
                        String kind = elm.getTextTrim();
                        if (kind.startsWith("A")) {
                            EPXmlData.PnI = 1;
                        } else {
                            EPXmlData.PnI = 2;
                        }
                        EPXmlData.kindCode_B130 = kind;
                    }
                    /** publish or decision Number*/
                    else if(s.equals(xmlList[1]))
                    {
                            EPXmlData.patentNumber_B110 = elm.getTextTrim();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("error path==>" + xmlPath);
            e.printStackTrace();
        }
        return EPXmlData;
    }


    private String getXmlOfImage(String patentPath) {
        String imagePathes = "" ;
        /*String xmlParentPath = patentPath.substring(0,
                patentPath.lastIndexOf(File.separator));*/
        File xmlParentFile = new File(patentPath);
        if (xmlParentFile.isDirectory()) {
            File[] files = xmlParentFile.listFiles();
            for (File imgFile : files) {
                String imagePath = imgFile.getPath();
                if (imgFile.getName().startsWith(fileHead)
                        && imgFile.getName().endsWith(fileTail)) {
                    imagePathes = imagePath;
                    break;
                }
            }
        }
        return imagePathes;
    }
    
    
    private List<String> getFiles(String patentPath) {
        List<String> imagesPaths = new ArrayList<String>() ;
        File parentFile = new File(patentPath);
        if (parentFile.isDirectory()) {
            File[] files = parentFile.listFiles();
            for (File imgFile : files) {
                String imagePath = imgFile.getPath();
                if (imgFile.getName().startsWith(tifImageHead)
                        && imgFile.getName().endsWith(tifImageTail)) {
                    imagesPaths.add(imagePath);
                }
            }
        }
        return imagesPaths;
    }


    private void copyString(String string, File file) {
        if (!file.exists()) {
            new File(file.getParent()).mkdirs();
        }
        try {
            FileWriter fw = new FileWriter(file , true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(string);
            bw.newLine();
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
    }


    public List<String[]> getEPOPatentNumber(String patentNumber) {
        String patentNo , kindCode ,stat; List<String[]> list = new ArrayList<String[]>();
        if(patentNumber.indexOf("A") > 0) {
            patentNo = patentNumber.substring(0, patentNumber.indexOf("A") + "A1".length());
            kindCode = patentNumber.substring(patentNumber.indexOf("A"), patentNumber.indexOf("A") + "A1".length());
            stat = "1";
        } else {
            patentNo = patentNumber.substring(0, patentNumber.indexOf("B") + "A1".length());
            kindCode = patentNumber.substring(patentNumber.indexOf("B"), patentNumber.indexOf("B") + "B1".length());
            stat = "2";
        }
        list.add(new String[]{patentNo , kindCode , stat});
        return list;
    }

    
    /**
     * String mongouri = "mongodb://10.60.90.121/PatentInfoEPO";//10.57.145.82
        String sourcePath = "\\\\YH-PC\\epImageOriginData\\2014(29AB)";
        String targetPath = "\\\\10.62.41.250\\patent_ep";//10.62.41.250
        String startPath = "";
     * @param args
     * @throws Exception 
     */
    
    public static void main(String[] args) throws Exception {
        EpoAuthClipImageImporter importer = new EpoAuthClipImageImporter();
        importer.worker(args);
    }
    
    public void worker(String[] args) throws Exception {

        try {
            ArgParser argParser = new ArgParser().addOpt(EpoAuthClipImageImporter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
            
            if (log.isDebugEnabled()) {
                log.debug("start, opt: " + argParser.getParsedMap());
            }
            
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
            startPath = argParser.getOptString(opt_start_path);
            
            if(    sourcePath == null || sourcePath.isEmpty() ||
                targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            System.out.println("error config ...");
            return;
        }
        try {
            EpoAuthClipImageImporter epoAuthFirstImageImpoter = new EpoAuthClipImageImporter();
            System.out.println("begin import image...");
                epoAuthFirstImageImpoter.importImage();
            System.out.println("import completed...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
