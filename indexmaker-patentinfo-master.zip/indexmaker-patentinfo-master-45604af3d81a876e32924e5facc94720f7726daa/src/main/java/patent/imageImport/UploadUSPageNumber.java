package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/***
 * 
 * @author Genchi
 * 本程式已不使用
 */
public class UploadUSPageNumber {

    static Log log = LogFactory.getLog(UploadUSPageNumber.class);
    private static String[] imageType = new String[]{"tif", "jpg", "png"};
    private String sourcePath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;

    private static int getImageFileList(String patentPath)
    {
        List<File> imageFileListList = new ArrayList<File>();
        try
        {
            File file = new File(patentPath);
            File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) 
            {
                if (fileList[i].isDirectory()) 
                {
                    continue;
                } 
                else 
                {
                    for(int j = 0; j < imageType.length; j++)
                    {
                        if (fileList[i].getName().toLowerCase().endsWith(imageType[j])) {
                            imageFileListList.add(fileList[i]);
                        }
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
        return imageFileListList.size();
    }

    public UploadUSPageNumber() {
        
    }

    public static String createrList(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
    }

    public UploadUSPageNumber(String mongouriStr, String sourcePath) {
        try {
            Class<? extends PatentInfo2> infoclazz = PatentInfoUSPTO.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            
            if(this.sourcePath.endsWith(File.separator)) {
                this.sourcePath = this.sourcePath.substring(0, this.sourcePath.length()-1);
            }
            pe = new ProcessEstimater(0).setFormat("%2$d");    
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } 
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath);
        if(!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(listFileReader);
            String patentPath = "";
            if(startPath != null && !startPath.isEmpty())
            {
                while((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if(patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while((patentPath = listBufferedReader.readLine()) != null) {
                int stat = 2 ;
                if(patentPath.toLowerCase().contains("us1")) {
                    stat = 1;
                } else if(patentPath.toLowerCase().contains("us2")) {
                    stat = 2;
                }
                File patentFile = new File(patentPath);
                String patentNumber = patentFile.getName().toUpperCase();
                try {
                    this.patentinfo = PatentInfoUSPTO.findPN(Pto.USPTO, patentNumber);
                } catch (Exception e) {
                    log.info("err patentPath : " + patentPath);
                    throw e;
                }
                if(this.patentinfo != null) {
                    if(this.patentinfo.filePageNumber == null || this.patentinfo.filePageNumber ==0) {
                        int pagenumber = getImageFileList(patentPath + File.separator + "fullImage");
                        if(pagenumber > 0) {
                            this.patentinfo.filePageNumber = pagenumber;
                            this.patentinfo.save();
                        }
                        pe.addNum().debug(log, 10000, "patent:" + patentNumber + ", page:" + pagenumber);
                    }
                } else {
                    log.info(patentPath + "'[" + stat + "][" + patentNumber + "]" +" not find!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        String mongouri;
        String sourcePath;
        String startPath;
        try {
            cmd = parser.parse( options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            startPath = cmd.getOptionValue("p");
            if(mongouri == null || mongouri.isEmpty() || sourcePath == null || sourcePath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp( "UploadUSPageNumber.jar", options );
            return;
        }
        UploadUSPageNumber imageImpoter = new UploadUSPageNumber(mongouri, sourcePath);
        try{
            imageImpoter.importImage(startPath);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("err tpe any key to continue!");
            Scanner scan = new Scanner(System.in);
            scan.nextLine();
        }
    }

}
