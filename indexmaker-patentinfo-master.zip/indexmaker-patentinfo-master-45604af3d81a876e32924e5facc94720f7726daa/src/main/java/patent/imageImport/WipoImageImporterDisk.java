package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.SimpleBookmark;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/***
 * WIPO image import into mongoDB 
 * @author yiyun 2013/10/10
 */
public class WipoImageImporterDisk {

    private static Log log = LogFactory.getLog(WipoImageImporterDisk.class);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private PatentInfo2 patentInfo;
    private ProcessEstimater pe;
    // args
    private static String mongoUri;
    private static String sourcePath;
    private static String targetPath;
    private static String startPath;
    // wipo image type 
    private String imageType = "pdf";
    
    public WipoImageImporterDisk() throws UnknownHostException {
        Class<? extends PatentInfo2> infoClazz = PatentInfoWIPO.class;
        MongoClientURI mongoClientUri = new MongoClientURI(mongoUri);
        MongoClient mongoClient = new MongoClient(mongoClientUri);
        DB mongodb = mongoClient.getDB(mongoClientUri.getDatabase());
        MappedClass.getMappedClass(infoClazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");    
    }
    
    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        try {
            CommandLine cmd = parser.parse( options, args);
            mongoUri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
            if(mongoUri == null || mongoUri.isEmpty() 
                    || sourcePath == null || sourcePath.isEmpty() 
                    || targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp( "WipoImageImporter", options);
            return;
        }
        try {
            WipoImageImporterDisk wipoImageImporter = new WipoImageImporterDisk();
            wipoImageImporter.importImage();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * import image to target file and update patentInfo of mongoDB
     */
    public void importImage() throws IOException {
        // create file to recode source patent image path
        String listPath = createListFile(sourcePath);
        File listFile = new File(listPath);
//        File listFile = new File("." + File.separator + "1997_1998.txt");
        if(!listFile.exists()) {
            return;
        }
        FileReader fr = null;
        BufferedReader br = null;
        fr = new FileReader(listFile);
        br = new BufferedReader(fr);
        String patentPath = "";
        if (startPath != null && !startPath.isEmpty()) {
            while ((patentPath = br.readLine()) != null) {
                patentPath = patentPath.trim();
                if (patentPath.equals(startPath.trim())) {
                        break;
                }
            }
            log.info("start upload from patent path : " + patentPath);
        }
        while ((patentPath = br.readLine()) != null) {
            try {
                String fileName = new File(patentPath).getName();
                // get the patentNumber from file name
                String pn = fileName.substring(0, fileName.lastIndexOf("."));
                String kindCode = pn.substring(pn.length()-2);
                String year;
                switch(pn.length()) {
                case 11:
                    year = pn.substring(2,4);
                    year = Integer.parseInt(year) > 70 ? "19" + year: "20" + year;
                    pn = pn.substring(0,2) + " " + year + "/0" + pn.substring(4,9) + " " + pn.substring(9);
                    break;
                case 12:
                    year = pn.substring(2,4);
                    year = Integer.parseInt(year) > 70 ? "19" + year: "20" + year;
                    pn = pn.substring(0,2) + " " + year + "/" + pn.substring(4,10) + " " + pn.substring(10);
                    break;
                case 14:
                    pn = pn.substring(0,2) + " " + pn.substring(2,6) + "/" + pn.substring(6,12) + " " + pn.substring(12);
                    break;
                default:
                    pn = "";
                    break;
                }
                // get patentInfo from mongoDB by patentNumber and kindCode
                patentInfo = PatentInfoWIPO.findPN(Pto.WIPO, pn);
                
                if(patentInfo != null) {
                    String k2imagePath = targetPath 
                            + File.separator  + "wo1" + kindCode.toLowerCase() 
                            + File.separator + dateFormat.format(patentInfo.openDate) 
                            + File.separator + pn.toLowerCase().replaceAll(" ", "").replace("/", "")
                            + File.separator + "fullPage.pdf";
                    // copy source image file path to k2 image file path
                    copyFile(new File(patentPath), new File(k2imagePath));
                    // get bookmark from the pdf file
                    PdfReader reader = new PdfReader(patentPath);
                    patentInfo.filePageNumber = reader.getNumberOfPages();
                    // get pdf bookmark
                    List<?> list = SimpleBookmark.getBookmark(reader);
                    if(list != null) {
                        for (Iterator<?> i = list.iterator (); i.hasNext ();) {
                             HashMap<?,?> bookMark = (HashMap<?,?>) i.next();
                             String title = (String) bookMark.get("Title");
                             String page = (String) bookMark.get("Page");
                             // page maybe null
                             if(page == null) {    
                                 continue;
                             }
                             int pageNumber = -1;
                             if(page.indexOf("XYZ") != -1) {
                                 pageNumber = Integer.parseInt(page.substring(0, page.indexOf("XYZ")).trim());
                             } else if (page.indexOf("Fit") != -1) {
                                 pageNumber = Integer.parseInt(page.substring(0, page.indexOf("Fit")).trim());
                             }
                             if(title.equals("Abstract")) {
                                 patentInfo.filePageFirst = pageNumber;
                             } else if(title.equals("Description")) {
                                 patentInfo.filePageDesc = pageNumber;
                             } else if(title.equals("Claims")) {
                                 patentInfo.filePageClaim = pageNumber;
                             } else if(title.equals("Drawings")) {
                                 patentInfo.filePageFig = pageNumber;
                             } else if(title.equals("Search_Report") || title.equals("Search Report")) {
//                                 patentInfo.filePageSearchReport = pageNumber;
                             }
                          }
                    }
                    // save patentInfo into mongoDB
                    patentInfo.save();
                    pe.addNum().debug(log, 10000, "source:" + patentPath);
                } else {
                    log.info(patentPath + " not find!");
                }
            } catch (Exception e) {
                log.info(patentPath);
                e.printStackTrace();
                writeInfo(patentPath + "    " + e.getMessage(), "." + File.separator + "error.txt");
            }
        }
        // close stream
        br.close();
        fr.close();
    }
    
    /**
     * get the file list of the source file and write the list into a txt file 
     * @param sourcePath    image source file  directory
     * @return                the file path of the list file
     */
    public String createListFile(String sourcePath) {
        String listPath = "." + File.separator + "list" + sourcePath + ".txt";
        File file = new File(listPath);
        if(!file.exists()) {
            log.info(file.getParentFile());
            if(!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            // get list of source file
            List<String> fileList = getFilePathList(sourcePath, imageType);
            // write list to target txt file
            try {
                FileWriter fw = new FileWriter(file);
                BufferedWriter bw = new BufferedWriter(fw);
                for(Iterator<String> it = fileList.iterator(); it.hasNext(); ) {
                    bw.write(it.next());
                    bw.newLine();
                }
                bw.close();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return listPath;
    }
    
    /** file list */
    private List<String> fileNames = new ArrayList<String>();
    /**
     * get listFiles from target file 
     * @param root             file path
     * @param endWith          file suffix
     * @return fileNames    file list
     */
    public List<String> getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else {
                        if (fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().endsWith(endWith)) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    
    /**
     * copy source file to destination file
     * @param src        source file 
     * @param des        destination file
     */
    private void copyFile(File src, File des) {
        try {
            File patentFile = des.getParentFile();
            if (!patentFile.exists()) {
                patentFile.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * wrtie info string into the file
     * @param     info      info string
     * @param    path    file path
     */
    public static void writeInfo(String info, String filePath) {
        File file = new File(filePath);
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
