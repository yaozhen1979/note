package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;



public class CniprAutoImageImpoter {
    static Log log = LogFactory.getLog(CniprAutoImageImpoter.class);
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    static Pattern pattern = Pattern.compile("[1-9][\\d]*");
    private static String listPath;
    private static String sourcePath;
    private static String targetPath;
    private ProcessEstimater pe;
    private PatentInfo2 patentinfo;
    private static String startPath;
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "";

    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "";

    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "";
    
    public static final String opt_list_path = "list.path";
    public static final String opt_list_path_default = "";
    
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, "CNIPR raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, "do CNIPR raw data local path, keep empty for cnipr.path"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "Provider saved to DB"),
        new ArgParser.Option(null, opt_list_path, true, opt_list_path_default, "Provider saved to DB"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(CniprAutoImageImpoter.class);
    }
    
    public CniprAutoImageImpoter() throws UnknownHostException{
        pe = new ProcessEstimater(0).setFormat("%2$d");    
        
    }
    

    public static String createrList(String sourcepath, String listRootPath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = listRootPath + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
    }

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*public CniprImageImpoter(String mongouriStr, String sourcePath, String targetPath, String listPath) {
        try {
            Class<? extends PatentInfo2> infoclazz = PatentInfoCNIPR.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;
            this.listPath = listPath;
            if(this.sourcePath.endsWith(File.separator)) {
                this.sourcePath = this.sourcePath.substring(0, this.sourcePath.length()-1);
            }
            pe = new ProcessEstimater(0).setFormat("%2$d");
            
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } 
    }*/

    public void uploadImage(String k2imagePath, String patentPath) throws Exception
    {
        File patentSrcFile = new File(patentPath);
        File patentDesFile = new File(k2imagePath);
        if(!patentDesFile.exists() || !patentDesFile.isDirectory()) {
            patentDesFile.mkdirs();
        }
        File[] imageFiles = patentSrcFile.listFiles();
        int imageCount = 0;
        for(File imageFile:imageFiles) {
            String[] tmp = imageFile.getName().replace(patentSrcFile.getName() + "_", "").split("\\.");
            String page = tmp[0];
            String type = tmp[1];
            if(type.equalsIgnoreCase("jpg") || type.equalsIgnoreCase("tif")) {
                Matcher matcher = pattern.matcher(page);
                if(matcher.find()) {
                    page = matcher.group(0);
                    String destFilePath = k2imagePath + File.separator + page + "." + type.toLowerCase();
                    copyFile(new File(imageFile.getAbsolutePath()), new File(destFilePath));
                    imageCount++;
                }
            }
        }
        if(this.patentinfo.filePageNumber == null || this.patentinfo.filePageNumber != imageCount)
        {
            this.patentinfo.filePageNumber = imageCount;
            this.patentinfo.save();
        }
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath, this.listPath);
        if(!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(listFileReader);
            String patentPath = "";
            if(startPath != null && !startPath.isEmpty())
            {
                while((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if(patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while((patentPath = listBufferedReader.readLine()) != null) {
                patentPath = patentPath.trim();
                String patentNumber = patentPath.substring(patentPath.lastIndexOf(File.separator) + 1);
                int stat = 2 ;
                if(patentPath.contains("FM")) {
                    stat = 1;
                } else if (patentPath.contains("WG")) {
                    String newPatentNumber = patentNumber.substring(0, patentNumber.length()-1);
                    newPatentNumber = patentNumber.substring(0, patentNumber.length()-1).toUpperCase() + "." + patentNumber.substring(patentNumber.length()-1).toUpperCase();
                    patentNumber = newPatentNumber;
                }
                this.patentinfo = PatentInfoCNIPR.findPN(Pto.CNIPR, patentNumber, stat);
                if(this.patentinfo != null) {
                    String k2imagePath = this.targetPath +  File.separator +"cn" + stat + this.patentinfo.kindcode.toLowerCase() + File.separator + dateFormat.format(patentinfo.doDate)
                            + File.separator + patentNumber.toLowerCase() + File.separator + "fullImage";
                    pe.addNum().debug(log, 10000, "source:" + patentPath + ", dest:" + k2imagePath);
                    this.uploadImage(k2imagePath, patentPath);
                } else {
                    log.info("patentnumber:'" + patentNumber + "'[" + stat + "]" +" not find!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
    }
    
    public static void main(String[] args) throws Exception {
        CniprAutoImageImpoter cnipr = new CniprAutoImageImpoter();
        cnipr.worker(args);
    }


    public void worker(String[] args) throws Exception {
        
        try{
            ArgParser argParser = new ArgParser().addOpt(CniprAutoImageImpoter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
           
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
            listPath = argParser.getOptString(opt_list_path);
            startPath = argParser.getOptString(opt_start_path);
            if(sourcePath == null || sourcePath.isEmpty() ||
                    targetPath == null || targetPath.isEmpty()) {
                     throw new ParseException("");
                 }
             } catch (ParseException e) {
                 System.out.println("error ...");
                 return;
             }
        CniprAutoImageImpoter  cnipr = new CniprAutoImageImpoter();
        cnipr.importImage(startPath);
        
    }

}
