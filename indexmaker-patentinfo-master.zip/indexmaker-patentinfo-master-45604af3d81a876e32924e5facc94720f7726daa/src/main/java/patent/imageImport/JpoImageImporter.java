package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class JpoImageImporter {
    static Log log = LogFactory.getLog(JpoImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy"
            + File.separator + "MM" + File.separator + "dd");
    private String sourcePath;
    private String targetPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String createrList(String sourcepath) throws IOException {
        if (sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        // String listPath = sourcepath + File.separator + "1.txt";
        // if (!(new File(listPath)).exists()) {
        File file = new File(listPath.substring(0,
                listPath.lastIndexOf(File.separator)));
        log.info(file.getAbsoluteFile());
        if (!file.exists() || file.isDirectory()) {
            file.mkdirs();
        }
        File source = new File(sourcepath);

        if (!source.isDirectory()) {
            return "";
        }
        FileWriter fw = new FileWriter(listPath);
        BufferedWriter bw = new BufferedWriter(fw);
        File[] patents = source.listFiles();
        for (int i = 0; i < patents.length; i++) {
            File tpatent[] = patents[i].listFiles();
            for (File patent : tpatent) {
                System.out.println("Writing:" + patent.getAbsolutePath());
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
        }
        bw.close();
        fw.close();
        // }
        return listPath;
    }

    public String convertPatentNumber(String typecode, String num, String date) {
        int pubdate = Integer.parseInt(date);
        int temp = 0;
        if (typecode.contains("P1")) {
            // 特開平
            if (pubdate < 200001)
                num = "特開平" + getHeiseiYear(num.substring(0, 4)) + "-"
                        + num.substring(4, num.length());
            // 特開
            else if (pubdate >= 200001){
                num = "特開" + num.substring(0, 4) + "-"
                        + num.substring(4, num.length());}
        }
        if (typecode.contains("P2")) {
            // 特公平
            if (pubdate < 199605)
                num = "特公平" + getHeiseiYear(num.substring(0, 4)) + "-"
                        + num.substring(4, num.length());
            // 特許
            else if (pubdate >= 199606){
                temp = Integer.parseInt(num);
            num = temp + "";
            num = "特許" + num;
            }
        }
        if (typecode.contains("U1")) {
            // 実開平
            if (pubdate < 200001)
                num = "実開平" + getHeiseiYear(num.substring(0, 4)) + "-"
                        + num.substring(4, num.length());
            // 実開
            else if (pubdate >= 200001){
                num = "実開" + num.substring(0, 4) + "-"
                        + num.substring(4, num.length());}
        }
        if (typecode.contains("U2")) {
            // 実公平
            if (pubdate < 199604)
                num = "実公平" + getHeiseiYear(num.substring(0, 4)) + "-"
                        + num.substring(4, num.length());
            // 実登
            else if (pubdate >= 199605){
                temp = Integer.parseInt(num);
            num = temp + "";
            num = "実登" + num;}
        }
        if (typecode.contains("U3")) {
            // 実登
            temp = Integer.parseInt(num);
            num = temp + "";
            num = "実登" + num;
        }
        return num;
    }

    public String getHeiseiYear(String year) {
        String heiseiYear;
        int temp = Integer.parseInt(year);
        if ((temp - 1989) < 0) {
            return null;
        } else {
            temp = (temp - 1989) + 1;
            heiseiYear = String.valueOf(temp);
            int i = heiseiYear.length();
            if (i < 2) {
                heiseiYear = "0" + heiseiYear;
            }
            return heiseiYear;
        }
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath);
        if (!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            String patentPath = "";
//            if (startPath != null && !startPath.isEmpty()) {
//                while ((patentPath = listBufferedReader.readLine()) != null) {
//                    patentPath = patentPath.trim();
//                    if (patentPath.equals(startPath.trim())) {
//                        break;
//                    }
//                }
//                log.info("start upload from patent path : " + patentPath);
//            }
            while ((patentPath = listBufferedReader.readLine()) != null) {
                patentPath = patentPath.trim();
                log.info("start upload from patent path : " + patentPath);
                int stat = 2;
                File patentFile = new File(patentPath);
                String pdfname = patentPath.substring(
                        patentPath.lastIndexOf(File.separator) + 1,
                        patentPath.length());
                String path = patentPath.substring(patentPath.indexOf("jp"));
                String date = path.substring(path.lastIndexOf("m") - 5,
                        path.lastIndexOf("m") - 1)
                        + path.substring(path.lastIndexOf("m") + 1,
                                path.lastIndexOf("m") + 3);
                File pdfFile = new File(patentFile.getAbsolutePath()
                        + File.separator + pdfname + ".pdf");
                if (!pdfFile.exists()) {
                    pdfFile = new File(patentFile.getAbsolutePath()
                            + File.separator + pdfname + ".pdf");
                }
                if (pdfFile.exists()) {
                    // String patentNumber = patentFile.getName()
                    // .toUpperCase();
                    String patentNumber = convertPatentNumber(patentPath,
                            pdfname, date);

                    if (patentPath.contains("P1") || patentPath.contains("U1")
                            || patentPath.contains("U3")) {
                        stat = 1;
                    } else {
                        stat = 2;
                    }
                    try {
                        this.patentinfo = PatentInfoJPO.findPN(Pto.JPO,
                                patentNumber);
                    } catch (Exception e) {
                        log.info("err patentPath : " + patentPath);
                        throw e;
                    }
                    if (this.patentinfo != null) {
                        // if (this.patentinfo.filePageNumber == null
                        // || this.patentinfo.filePageNumber == 0) {
                        String k2imagePath = this.targetPath + File.separator
                                + "jp" + stat
                                + patentinfo.kindcode.toLowerCase()
                                + File.separator
                                + dateFormat.format(patentinfo.doDate)
                                + File.separator + patentNumber.toLowerCase()
                                + File.separator + "fullPage.pdf";
                         copyFile(new File(pdfFile.getAbsolutePath()),
                         new File(k2imagePath));
                        InputStream in = new FileInputStream(pdfFile);
                        PDFParser parser = new PDFParser(in);
                        parser.parse();
                        PDDocument pdfdocument = parser.getPDDocument();
                        this.patentinfo.filePageNumber = pdfdocument
                                .getNumberOfPages();
                        this.patentinfo.save();
                        pdfdocument.close();
                        in.close();
                        pe.addNum().debug(
                                log,
                                10000,
                                "source:" + patentPath + ", dest:"
                                        + k2imagePath);
                        // }
                    } else {
                        log.info(patentPath + "'[" + stat + "]" + " not find!");
                    }
                } else {
                    log.info(patentPath + "'[" + stat + "]" + " no pdf!");
                }
                if (patentPath.equals(startPath.trim())) {
                    break;
                }
            }
            // }
            listFileReader.close();
            listBufferedReader.close();
        }
    }

    public JpoImageImporter() {

    }

    public JpoImageImporter(String mongouriStr, String sourcePath,
            String targetPath) {
        try {
            Class<? extends PatentInfo2> infoclazz = PatentInfoJPO.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;

            if (sourcePath.endsWith(File.separator)) {
                sourcePath = sourcePath.substring(0, sourcePath.length() - 1);
            }
            pe = new ProcessEstimater(0).setFormat("%2$d");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        String mongouri;
        // = "mongodb://10.57.145.105/PatentInfoJPO";
        String sourcePath;
        // "\\\\10.62.41.206\\jp$\\Data\\P1\\1993";
        // String sourcePath = "E:\\Harvey\\tw_img_sm\\tw2\\2013\\10\\01";
        // //\\10.62.41.206\jp$\Data\P1\1993\m01
        String targetPath;
        // = "/mnt/patent_jp/data";
        String startPath;
        // = "\\\\10.62.41.206\\jp$\\Data\\P1\\1993";
        try {
            cmd = parser.parse(options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
            if (mongouri == null || mongouri.isEmpty() || sourcePath == null
                    || sourcePath.isEmpty() || targetPath == null
                    || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp("JpoImageImporter", options);
            return;
        }
        JpoImageImporter imageImporter = new JpoImageImporter(mongouri,
                sourcePath, targetPath);
        try {
            imageImporter.importImage(startPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
