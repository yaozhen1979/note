package patent.imageImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class USgetPatentNumber {
    static Log log = LogFactory.getLog(USgetPatentNumber.class);
    public static final String opt_pto = "pto";
    public static final String opt_pto_default = null;
    private String url = "http://pimg-fpiw.uspto.gov/fdd/";
    private String url1="http://pimg-faiw.uspto.gov/fdd/";
    int day_of_week;
    //public static final String opt_target_path = "target";
    //public static final String opt_target_path_default = null;
    FileOutputStream fos =null;
    String usptoFullPDFpath=null;
    List<String> list = new ArrayList<String>();
    PatentInfo2 patentInfo;
    @SuppressWarnings("unused")
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private String filename;
    private static String target;
    
    public static ArgParser.Option[] opts = {
        //new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, ""),
        new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
        new ArgParser.Option("t", null, true, "", "Patent open/decision date rage\n" +
                "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n" +
                "Format: YYYYMMDD+n (20110101+31)\n" +
                "Format: YYYYMM+n (201101+12)\n" +
                "Format: YYYYMM+n (2011+1)\n"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class,
    };
    
    static {
        ConfigUtils.setSearchBase(USgetPatentNumber.class);
    }
    
    public static void main(String[] args) throws Exception {
        target = args[0];
        USgetPatentNumber getPN = new USgetPatentNumber();
        getPN.excute(args);
    }
    
    public static String getWeekDate(int weekNumber){
        String weekDateStr=null;
        Calendar cal = Calendar.getInstance();
        int week = cal.get(Calendar.DAY_OF_WEEK) - 1;
        cal.add(Calendar.DATE, -week);
        cal.add(Calendar.DATE, weekNumber);
        weekDateStr=dateToStr(cal.getTime());
        return weekDateStr;
    }
    
    public static String dateToStr(java.util.Date dateDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        String dateString = formatter.format(dateDate);
        return dateString;
    }

    public void excute(String[] args) throws Exception {
        target = args[0];
        ArgParser argParser = new ArgParser().addOpt(USgetPatentNumber.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        
        Calendar cal = Calendar.getInstance();
        day_of_week = cal.get(Calendar.DAY_OF_WEEK);
        if(log.isDebugEnabled()){
            log.debug("start  ,  opt  "+argParser.getParsedMap());
        }
        
        Pto pto =Pto.valueOf(argParser.getOptString(opt_pto).toUpperCase());
        
        //String targetPath=argParser.getOptString(opt_target_path);
        
        //String date_range=argParser.getOptString("t");
        String date_range=getWeekDate(day_of_week-1)+"-"+getWeekDate(7);
        //String date_range="20140701-20140702";
        filename = date_range.substring(0,8)+".txt";
        QueryHelp query=getDateRange(date_range);
        if(query!=null&&log.isDebugEnabled()){
            log.debug("start in 5 seconds" + query);
            Thread.sleep(5000);
        }
        
        log.debug("counting total document...");
        DBCollection col=PatentInfo2.getCollection(pto);
        DBCursor cursor=col.find(query).sort(new BasicDBObject("doDate",1));
        log.debug("start download files...");
        File file = new File(target+File.separator+filename);
        fos = new FileOutputStream(file);
        while(cursor.hasNext()){
            DBObject dbobj = cursor.next();
            
            try {
                patentInfo = PatentInfo2.fromObject(pto, dbobj);
            } catch (Exception e) {
                log.debug(e.getMessage());
            }
            String patentNumber = patentInfo.patentNumber;
            String patent = patentNumber+"us"+patentInfo.stat+patentInfo.kindcode.toLowerCase()+dateFormat.format(patentInfo.doDate);
            //list.add(patentNumber+"us"+patentInfo.stat+patentInfo.kindcode.toLowerCase()+dateFormat.format(patentInfo.doDate));
            fos.write((patentNumber+"us"+patentInfo.stat+patentInfo.kindcode.toLowerCase()+dateFormat.format(patentInfo.doDate)+"\r\n").getBytes());
            //fos.write((patentNumber+"\r\n").getBytes());
            log.debug("patentNumber:"+patentNumber +" add success... ");
        }
        
        
        log.debug("finish");
        
        
    }

    private QueryHelp getDateRange(String date_range) {
        if (date_range==null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom=null;
        Date dateTo =null;
        
        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype, calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }
}
