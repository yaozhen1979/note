package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;



public class TipoAuthImageImporter {
    static Log log = LogFactory.getLog(TipoAuthImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy"
            + File.separator + "MM" + File.separator + "dd");
    private static String sourcePath;
    private static String targetPath;
    private static String startPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;

    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";

    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";

    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "00000000";

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_source_path, true,
                    opt_source_path_default,
                    "mongodb uri, start with mongodb://"),
            new ArgParser.Option(null, opt_target_path, true,
                    opt_target_path_default,
                    "JPO raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, opt_start_path, true,
                    opt_start_path_default,
                    "year or date of JPO raw data, keep empty for jpo.path"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(TipoAuthImageImporter.class);
    }

    public TipoAuthImageImporter() {

    }

    public static String createrList(String sourcepath) throws IOException {
        if (sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        }
        String listPath = sourcepath + ".txt";
        File file = new File(listPath.substring(0,
                listPath.lastIndexOf(File.separator)));
        log.info(file.getAbsoluteFile());
        if (!file.exists() || file.isDirectory()) {
            file.mkdirs();
        }
        File source = new File(sourcepath);

        if (!source.isDirectory()) {
            return "";
        }
        FileWriter fw = new FileWriter(listPath);
        BufferedWriter bw = new BufferedWriter(fw);
        List<String> l = getFilePathList(sourcepath, "pdf");
        for (int i = 0; i < l.size(); i++) {
            System.out.println("Writing" + l.get(i));
            bw.write(l.get(i));
            bw.newLine();
        }
        bw.close();
        fw.close();
        return listPath;
    }

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public TipoAuthImageImporter(String mongouriStr, String sourcePath) {
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    private static List<String> fileNames = new ArrayList<String>();

    public static List<String> getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        System.out.println(fileList[i].getAbsolutePath());
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else {
                        if (fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                            System.out.println(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().endsWith(endWith)) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }

    public void importImage(String startPath, String sourcePath)
            throws Exception {
        String listPath = createrList(this.sourcePath);
        FileWriter fw = new FileWriter("crash_pdf.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        if (!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            String patentPath = "";
//            if (startPath != null && !startPath.isEmpty()) {
//                while ((patentPath = listBufferedReader.readLine()) != null) {
//                    patentPath = patentPath.trim();
//                    if (patentPath.equals(startPath.trim())) {
//                        break;
//                    }
//                }
//                log.info("start upload from patent path : " + patentPath);
//            }
            while ((patentPath = listBufferedReader.readLine()) != null) {
                File patentFile = new File(patentPath);
                patentPath = patentPath.substring(0,patentPath.indexOf("fullPage.pdf") -1);
                String patentNumber = patentPath.substring(patentPath.lastIndexOf(File.separator) + 1,patentPath.length());
                try {
                    this.patentinfo = PatentInfoTIPO.findPN(Pto.TIPO,
                            patentNumber);
                } catch (Exception e) {
                    log.info("err patentPath : " + patentPath);
                    throw e;
                }
                File pdfFile = new File(patentFile.getAbsolutePath());
                if (this.patentinfo != null) {
                    if (this.patentinfo.filePageNumber == null
                            || this.patentinfo.filePageNumber == 0) {
                        try {
                            String date = dateFormat.format(patentinfo.doDate);
                            String k2imagePath = this.targetPath
                                    + File.separator + "tw" + patentinfo.stat
                                    + File.separator + dateFormat.format(patentinfo.doDate)
                                    + File.separator
                                    + patentNumber.toLowerCase()
                                    + File.separator + "fullPage.pdf";
                            copyFile(new File(pdfFile.getAbsolutePath()),
                                    new File(k2imagePath));
                            InputStream in = new FileInputStream(patentPath
                                    + File.separator + "fullPage.pdf");
                            PDFParser parser = new PDFParser(in);
                            parser.parse();
                            PDDocument pdfdocument = parser.getPDDocument();
                            this.patentinfo.filePageNumber = pdfdocument
                                    .getNumberOfPages();
                            this.patentinfo.save();
                            pdfdocument.close();
                            in.close();
                            pe.addNum().debug(
                                    log,
                                    10000,
                                    "patent:" + patentNumber + ", page:"
                                            + this.patentinfo.filePageNumber);
                        } catch (Exception e) {
                            bw.write(sourcePath + File.separator
                                    + this.patentinfo.patentNumber);
                            bw.newLine();
                        }
                    }
                } else {
                    log.info(patentPath + "[" + patentNumber + "]"
                            + " not find!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
        bw.close();
        fw.close();
    }

    public void worker(String[] args) {

        ArgParser argParser;
        try {
            argParser = new ArgParser().addOpt(TipoAuthImageImporter.class)
                    .parse(args);
            MongoAuthInitUtils.reload(argParser);
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
            startPath = argParser.getOptString(opt_start_path);
        } catch (ParseException | UnknownHostException e2) {
            e2.printStackTrace();
        }

        TipoAuthImageImporter imageImpoter = new TipoAuthImageImporter(
                sourcePath, targetPath);
        try {
            imageImpoter.importImage(startPath,sourcePath);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("exception! press any key to continue");
        }

    }

    public static void main(String[] args) {
        TipoAuthImageImporter importer = new TipoAuthImageImporter();
        importer.worker(args);
    }
}
