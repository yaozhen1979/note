package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import patent.mongoImport.KipoImporterSource;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.SimpleBookmark;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class KipoAuthImageImporter {
    static Log log = LogFactory.getLog(KipoAuthImageImporter.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private static String sourcePath;  //文件原始路徑
    private static String targetPath;  //PDF保存路徑
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private String errFile = "./list/error_kr.txt";
    
    private static String fileType ="pdf";
    
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "00000000";
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "00000000";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = null;


    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_source_path, true, opt_source_path_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_target_path, true, opt_target_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "year or date of KIPO raw data, keep empty for kipo.path"),
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(KipoAuthImageImporter.class);
        //MongoInitUtils.nothing();
    }
    
    public KipoAuthImageImporter() throws UnknownHostException{
        pe = new ProcessEstimater(0).setFormat("%2$d");    
        
    }
    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void imageImporter() throws IOException {
        
        File source = new File(this.sourcePath);
        List<String> sourceFileList = getFileList(source,fileType);
        
        for(String patentPath:sourceFileList){

            // 韓國專利文字信息存在SGM文檔 和XML文檔
            String documentPath = documentPath(patentPath);

            if (documentPath == null) {
                log.info("Error path : " + patentPath);
            } else {
                try {
                    boolean isSGMFile = false; // 判斷是否為SGM 文檔
                    if (documentPath.contains("SGM")) {
                        isSGMFile = true;
                    }
                    String document = readFileByChars(documentPath);
                    int stat = getStat(document, isSGMFile);

                    File pdfFile = new File(patentPath);

                    if (pdfFile.exists()) {
                
                        String patentNumber = pdfFile.getName();
                        
                        patentNumber = patentNumber.substring(0,patentNumber.lastIndexOf(".")); //專利號
                        
                        try {
                            this.patentinfo = PatentInfoKIPO.findPN(
                                    Pto.KIPO, patentNumber, stat);
                        } catch (Exception e) {
                            log.info("err patentPath : " + patentPath);
                            writerFile("./errorImportImage.txt", patentPath);

                            FileUtils
                                    .write(new File("errFile"), patentPath);
                        }
                        if (this.patentinfo != null) {
                            if (this.patentinfo.filePageNumber == null
                                    || this.patentinfo.filePageNumber == 0) {
                                String k2imagePath = this.targetPath
                                        + File.separator
                                        + "kr"
                                        + stat
                                        + File.separator
                                        + dateFormat
                                                .format(patentinfo.doDate)
                                        + File.separator
                                        + patentNumber.toLowerCase()
                                        + File.separator + "fullPage.pdf";
                                copyFile(
                                        new File(pdfFile.getAbsolutePath()),
                                        new File(k2imagePath));
                                PdfReader pdfReader = new PdfReader(patentPath);
                                patentinfo.filePageNumber = pdfReader.getNumberOfPages();
                                List<?> bookmarks = SimpleBookmark.getBookmark(pdfReader);
                                if(bookmarks != null) {
                                    for (Iterator<?> i = bookmarks.iterator (); i.hasNext ();) {
                                         HashMap<?,?> bookMark = (HashMap<?,?>) i.next();                            
                                         List<?> bookmarks2=(List<?>) bookMark.get("Kids");
                                         if(bookmarks2!=null){
                                             for (Iterator<?> j = bookmarks2.iterator (); j.hasNext ();) {
                                                 HashMap<?,?> bookMark2 = (HashMap<?,?>) j.next();    
                                                 String title = (String) bookMark2.get("Title");
                                                 title = title.replaceAll(" ", "");
                                                 String page = (String) bookMark2.get("Page");
                                                 int pageNumber = Integer.parseInt(page.split(" ")[0].trim());
                                                 if(title.equals("요약")) {//abst
                                                     patentinfo.filePageFirst = pageNumber;
                                                 } else if(title.equals("명세서")) {//desc
                                                     patentinfo.filePageDesc = pageNumber;
                                                 } else if(title.contains("청구의범위")) {//claims
                                                     patentinfo.filePageClaim = pageNumber;
                                                 } else if(title.equals("도면")) {//drawings
                                                     patentinfo.filePageFig = pageNumber;
                                                 }  
                                             }
                                         }
                                      }
                                }
                                this.patentinfo.save();
                                pe.addNum().debug(
                                        log,
                                        10000,
                                        "source:" + patentPath + ", dest:"
                                                + k2imagePath);
                            }
                        } else {
                            log.info(patentPath + "'[" + stat + "]"
                                    + " not find!");
                            writerFile("./NotFInd.txt", patentPath);
                        }
                    } else {
                        log.info(patentPath + "'[" + stat + "]"
                                + " no pdf!");
                        writerFile("./NotPDF.txt", patentPath);
                    }

                } catch (Exception e) {
                    writerFile("./errorImportImage.txt", patentPath);
                }

            }
            
        }
        

    }
    /**
     * 通過PDF絕對路徑 構造出 韓國專利的 SGM/XML文檔路徑
     * @param pdfPath  PDF 文檔絕對路徑 
     * @return
     */
    public static String documentPath(String pdfPath){
        //kipo\Design\2001\20010115\3019960005927\B012\SGM\3019960005927.SGM
        String documentPath = null;
        //sgm 文檔存在與 ".sgm" 和 ".SGM" 文檔結尾的文檔
        String sgmPath1 = pdfPath.replaceAll("PDF", "SGM");
        sgmPath1 = sgmPath1.replaceAll("pdf", "sgm");
        String sgmPath2 = sgmPath1.replaceAll("pdf", "SGM");
        File sgmFile1 = new File(sgmPath1);
        File sgmFile2 = new File(sgmPath2);
        if(sgmFile1.exists()){//如何sgm文檔存在，則返回sgm 文檔路徑
            return sgmPath1;
        }else if(sgmFile2.exists()){
            return sgmPath2;
        }
        //如果不是SGM文檔，則為XML文檔
        //KIPO\Patent&UtilityModel_Registered\2006\20060109\1019997000116\B012\XML\1019997000116.xml
        String xmlPath =  pdfPath.replaceAll("PDF", "XML");
        xmlPath = xmlPath.replaceAll("pdf", "xml");
        File xmlFile = new File(xmlPath);
        if(xmlFile.exists()){
            return xmlPath;
        }
        
        return documentPath;
    }
    /**
     * get the file list of the source file and write the list into a txt file 
     * @param sourcePath    image source file  directory
     * @return                the file path of the list file
     */
    public static String createListFile2(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            
            bw.close();
            fw.close();
        }
        return listPath;
    }
    
    public static String createListFile(String sourcepath)throws IOException{
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String name = sourcepath.substring(sourcepath.lastIndexOf(File.separator));
        String listPath = "." + File.separator + "list"  + name + ".txt";
        
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }        
            File source = new File(sourcepath);
            if(!(source.isDirectory())) {
                return "";
            }
            List<String> listFile =  getFileList(source,fileType);
            
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(String path:listFile){
                bw.write(path);
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
        
    }
    /**
     * 
     * @param file 父文件
     * @param fielType 文件類型/文件后序名
     * @return list
     */
    static List<String> fileList = new ArrayList<>();
    public static List<String> getFileList(File file, String fielType) {
        
        File[] files = file.listFiles();

        if (files != null && files.length > 0) {

            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    String path = files[i].getAbsolutePath();
                    if (path.endsWith(fielType)||path.endsWith(fielType.toUpperCase())) {
                        System.out.println(path);
                        fileList.add(path);
                    }
                } else {
                    
                    getFileList(files[i], fielType);
                    
                }
            }
        }
        return fileList;
    }
    
    /**
     * 讀取文件內容
     * @param filePath 文件絕對路徑 
     * @return
     */
    public String readFileByChars(String filePath) {
         File file = new File(filePath);
         if( ! (file.exists()) ){
             System.out.println("file is not exists: "+filePath);
         }
         
         try {
             InputStreamReader ir = new InputStreamReader(new FileInputStream(file),"EUC_KR");
             BufferedReader br = new BufferedReader(ir);
             StringBuffer sb = new StringBuffer();
             
             String line;
             while( (line = br.readLine()) != null){
                 sb.append(line);
             }
             
             String result = sb.toString();
             return result;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;    
    }
    /**
     * 判斷分開公告
     * @param document  文檔內內
     * @param isSGMFile 
     * @return
     */
    public static int getStat(String document,boolean isSGMFile){
        int stat =1;
        if(isSGMFile){
            int Pn1 = document.indexOf("<RG");
            int Pn2 = document.indexOf("<ALLRG");
            if(Pn1 !=-1){
                stat=2;
            }else if(Pn2!=-1){
                stat=2;
            }else{
                stat=1;
            }
        }else{
            int Pn = document.indexOf("<KR_Register");
            if(Pn > 0){
                stat=2;
            }else{
                stat=1;
            }
        }
        return stat;
    }
    /**
     * writer the string to file
     * @param fileName File name
     * @param writerStr  writer string
     */
    public static void writerFile(String fileName, String writerStr) {
        File wFile = new File(fileName);
        try {
            if (!wFile.exists()) {
                wFile.createNewFile();
            }
            FileWriter wf = new FileWriter

            (wFile, true);
            BufferedWriter bw = new

            BufferedWriter(wf);
            byte[] buf = new byte[1024];
            int k = 0;
            bw.write(writerStr);
            bw.newLine();
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("寫文件出錯");
        }
    }
    
    
    
    public static void main(String[] args) throws Exception {
        
        KipoAuthImageImporter importer = new KipoAuthImageImporter();
        importer.worker(args); 
        
    }
    
    public void worker(String[] args)  throws Exception{

        try {
            ArgParser argParser = new ArgParser().addOpt(KipoAuthImageImporter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
           
            sourcePath = argParser.getOptString(opt_source_path);
            targetPath = argParser.getOptString(opt_target_path);
            
            if(sourcePath == null || sourcePath.isEmpty() ||
               targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            System.out.println("error ...");
            return;
        }
        try {
             KipoAuthImageImporter kipoImageImporter = new KipoAuthImageImporter();
             System.out.println("begin import image......");
             kipoImageImporter.imageImporter();
             System.out.println("import completed...");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
}
