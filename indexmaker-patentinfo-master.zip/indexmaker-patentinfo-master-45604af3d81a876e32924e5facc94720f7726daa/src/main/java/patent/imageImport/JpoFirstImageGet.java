package patent.imageImport;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.imageio.ImageIO;

import org.icepdf.core.exceptions.PDFException;
import org.icepdf.core.exceptions.PDFSecurityException;
import org.icepdf.core.pobjects.Document;

public class JpoFirstImageGet {
    /**
     * @param pdfpath
     *            pdf位置
     * @param filepath
     *            目地目錄
     * @param outpath
     *            目地檔案
     * @throws PDFException
     * @throws PDFSecurityException
     * @throws IOException
     */
    private void ExtractFP(String pdfpath, String filepath) {
        Document document = new Document();
        try {
            document.setFile(pdfpath);
        } catch (PDFException | PDFSecurityException | IOException e1) {
            e1.printStackTrace();
        }
        Enumeration tmpImages = document.getPageImages(0).elements();
        int count = 0;
        while (tmpImages.hasMoreElements()) {
            Image image = (Image) tmpImages.nextElement();
            if (count == 1) {
                new File(filepath).mkdirs();
                BufferedImage bufferedImage = new BufferedImage(
                        image.getWidth(null), image.getHeight(null),
                        BufferedImage.TYPE_INT_RGB);
                Graphics2D g2d = bufferedImage.createGraphics();
                g2d.drawImage(image, 0, 0, image.getWidth(null),
                        image.getHeight(null), null);
                RenderedImage rendImage = bufferedImage;
                String filename = pdfpath.substring(
                        pdfpath.lastIndexOf(File.separator) + 1, pdfpath.length());
                filename = filename.replace(".pdf", "");
                try {
                    String outpath = filepath + File.separator + filename
                            + File.separator + "firstPage.png";
                    new File(outpath).mkdirs();
                    File file = new File(outpath);
                    ImageIO.write(rendImage, "png", file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                g2d.dispose();
                bufferedImage.flush();
                break;
            }
            count++;
        }
        document.dispose();
    }

    private List<String> fileNames = new ArrayList<String>();

    public List<String> getFilePathList(String root, String endWith) {
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        System.out.println(fileList[i].getAbsolutePath());
                        getFilePathList(fileList[i].getPath(), endWith);
                    } else {
                        if (fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                            System.out.println(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().endsWith(endWith)) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }

    public static void main(String args[]) {
        List<String> fileNames = new ArrayList<String>();
        JpoFirstImageGet image = new JpoFirstImageGet();
        String sourcePath = args[0];
        String filepath = args[1];
        fileNames = image.getFilePathList(sourcePath, "pdf");
        for (String file : fileNames) {
            System.out.println(file);
            image.ExtractFP(file, filepath);
        }
    }
}
