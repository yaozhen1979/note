package patent.imageImport;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/**
 * 
 * @author Genchi
 * 目前 CN 影像檔直接從原始檔案上傳，本程式已不再使用
 */

public class IcmaCniprImageImpoter {
    static Log log = LogFactory.getLog(IcmaCniprImageImpoter.class);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator + "MM" + File.separator + "dd");
    private String sourcePath;
    private String targetPath;
    private PatentInfo2 patentinfo;
    private ProcessEstimater pe;
    private Connection conn;
    private Statement stmt = null;

    public static String createrList(String sourcepath) throws IOException {
        if(sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0,sourcepath.length()-1);
        }
        String listPath = "." + File.separator + "list" + sourcepath + ".txt";
        if(!(new File(listPath)).exists()) {
            File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            log.info(file.getAbsoluteFile());
            if(!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            File source = new File(sourcepath);
            if(!source.isDirectory()) {
                return "";
            }
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for(File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        return listPath;
    }

    public IcmaCniprImageImpoter() {
        
    }

    public IcmaCniprImageImpoter(String mongouriStr, String sourcePath, String targetPath) {
        try {
            Class<? extends PatentInfo2> infoclazz = PatentInfoCNIPR.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;

            if(sourcePath.endsWith(File.separator)) {
                this.sourcePath = this.sourcePath.substring(0, this.sourcePath.length()-1);
            }
            pe = new ProcessEstimater(0).setFormat("%2$d");
            
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } 
    }

    public void destory() throws IOException, SQLException {
        log.info("destory ...");
//        this.errWriter.close();
//        this.errFileWriter.close();
        if(this.conn != null) {
            this.conn.close();
            this.stmt.close();
        }
    }

    public void importImage(String startPath) throws Exception {
        String listPath = createrList(this.sourcePath);
        if(!listPath.isEmpty()) {
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(listFileReader);
            String patentPath = "";
            if(startPath != null && !startPath.isEmpty())
            {
                while((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if(patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            while((patentPath = listBufferedReader.readLine()) != null) {
                patentPath = patentPath.trim();
                String patentNumber = patentPath.substring(patentPath.lastIndexOf(File.separator) + 1);
                int stat = 2 ;
                if(patentNumber.endsWith("@O")) {
                    patentNumber = patentNumber.replace("@O", "");
                    stat = 1;
                }
                this.patentinfo = PatentInfoCNIPR.findPN(Pto.CNIPR, patentNumber, stat);
                if(this.patentinfo != null) {
                    String k2imagePath = this.targetPath +  File.separator +"cn" + stat + File.separator + dateFormat.format(patentinfo.doDate)
                            + File.separator + patentNumber.toLowerCase() + File.separator + "fullImage";
                    pe.addNum().debug(log, 10000, "source:" + patentPath + ", dest:" + k2imagePath);
                    this.uploadImage(k2imagePath, patentPath);
                } else {
                    log.info("patentnumber:'" + patentNumber + "'[" + stat + "]" +" not find!");
                }
            }
            listFileReader.close();
            listBufferedReader.close();
        }
    }

    private void uploadImage(String k2imagePath, String patentPath) throws Exception
    {
        File patentSrcFile = new File(patentPath);
        File patentDesFile = new File(k2imagePath);
        if(!patentDesFile.exists() || !patentDesFile.isDirectory()) {
            patentDesFile.mkdirs();
        }
        File[] imageFiles = patentSrcFile.listFiles();
        int imageCount = 0;
//        boolean patentFileSomethingWring = false;
        for(File imageFile:imageFiles) {
            if(imageFile.getName().contains(patentSrcFile.getName())) {
                String[] tmp = imageFile.getName().replace(patentSrcFile.getName() + "_", "").split("\\.");
                String page = tmp[0];
                String type = tmp[1];
                String patentType = this.patentinfo.type;
                if(patentType == null) {
                    patentType = this.getpatentType(this.patentinfo.patentNumber, Integer.toString(this.patentinfo.stat));
                }
                if(patentType != null && patentType.equalsIgnoreCase("外观专利")) {
                    if(type.equalsIgnoreCase("jpg")) {
                        String destFilePath = k2imagePath + File.separator + page + "." + type.toLowerCase();
                        copyFile(new File(imageFile.getAbsolutePath()), new File(destFilePath));
                        imageCount++;
                    } else {
//                        patentFileSomethingWring = true;
                    }
                } else if(patentType != null && (patentType.equalsIgnoreCase("实用新型") || patentType.equalsIgnoreCase("发明专利"))){
                    if(type.equalsIgnoreCase("tif")) {
                        String destFilePath = k2imagePath + File.separator + page + "." + type.toLowerCase();
                        copyFile(new File(imageFile.getAbsolutePath()), new File(destFilePath));
                        imageCount++;
                    }
//                    } else {
//                        patentFileSomethingWring = true;
//                    }
                } else {
                    log.info(patentPath + " [patent type err!!]");
                    throw new Exception("");
                }
            }
        }
        if(this.patentinfo.filePageNumber == null || this.patentinfo.filePageNumber != imageCount)
        {
            this.patentinfo.filePageNumber = imageCount;
            this.patentinfo.save();
        }
//        if(patentFileSomethingWring)
//        {
//            this.errWriter.write(patentPath + "    " + this.patentinfo.type);
//            this.errWriter.newLine();
//        }
    }

    private String getpatentType(String patentnumber, String stat) throws Exception {
        if(this.conn == null) {
            //get patent type from icma
            String url = "jdbc:oracle:thin:@10.153.24.247:1521:szicma";
            String userName = "icma";
            String password = "critical";
            
            String driver = "oracle.jdbc.driver.OracleDriver";
            try {
                Class.forName(driver);
                this.conn = DriverManager.getConnection(url, userName, password);
                this.stmt = conn.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        ResultSet rset = null;
        String tmp = null;
        String strSQL = null;
 
        strSQL = "SELECT PATENT_TYPE FROM PATENT_INFO WHERE PATENT_NUMBER = '" + patentnumber +
                 "' AND P_I = '" + stat + "'";

        rset = stmt.executeQuery(strSQL);

        if(rset.next()) {
            tmp = rset.getString("PATENT_TYPE").trim();
        }
        rset.close();
        return tmp;
    }

    private static void copyFile(File src, File des) {
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        Options options = new Options();
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        String mongouri;
        String sourcePath;
        String targetPath;
        String startPath;
        try {
            cmd = parser.parse( options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
            if(mongouri == null || mongouri.isEmpty() || sourcePath == null || sourcePath.isEmpty() ||
               targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
        } catch (ParseException e) {
            formatter.printHelp( "IcmaCniprImageImpoter.jar", options );
            return;
        }
        IcmaCniprImageImpoter imageImpoter = new IcmaCniprImageImpoter(mongouri, sourcePath, targetPath);
        try {
            imageImpoter.importImage(startPath);
            imageImpoter.destory();
        } catch (Exception e) {
            e.printStackTrace();
            log.info("exception! press any key to continue");
            try {
                imageImpoter.destory();
            } catch (IOException | SQLException e1) {
                e1.printStackTrace();
            }
        }
    }
}
