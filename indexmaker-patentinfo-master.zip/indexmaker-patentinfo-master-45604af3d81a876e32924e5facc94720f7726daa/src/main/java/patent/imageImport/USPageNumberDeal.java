package patent.imageImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.TimeZone;
import java.util.zip.GZIPInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;


@SuppressWarnings("deprecation")
public class USPageNumberDeal {
    static Log log =LogFactory.getLog(USPageNumberDeal.class);
    private static String start_url_p = "http://pdfpiw.uspto.gov/.piw?docid=";
    private static String start_url_a = "http://pdfaiw.uspto.gov/.aiw?docid=";

private static Class<? extends PatentInfo2> rawclazz = PatentInfoUSPTO.class;
private static String sourcePath;
private static String error;
private static String proxy_ip;
private static String proxy_port;
static PatentInfo2 patentInfo;
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(USPageNumberDeal.class);
    }
    
    private static DefaultHttpClient getHttpClient(){
         DefaultHttpClient httpClient = null;
        if (httpClient==null) {
            PoolingClientConnectionManager cm=new PoolingClientConnectionManager();
            httpClient=new DefaultHttpClient(cm);
            
            HttpHost proxy = new HttpHost(proxy_ip, Integer.parseInt(proxy_port)); 
            httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
            
            /*httpClient.getCredentialsProvider().setCredentials(
                    new AuthScope(proxy_ip, Integer.parseInt(proxy_port)),
                    new UsernamePasswordCredentials(username, password));*/
            AuthCache authCache = new BasicAuthCache();
            BasicScheme basicAuth = new BasicScheme();
            authCache.put(proxy, basicAuth);
            BasicHttpContext localcontext = new BasicHttpContext();
            localcontext.setAttribute(ClientContext.AUTH_CACHE, authCache);
        }
        return httpClient;
    }

    
    public String getHtml(String url){
        HttpHost proxyHost = new HttpHost(ConfigUtils.get("proxyHost"),Integer.parseInt(ConfigUtils.get("proxyPort")));
        String html = getHtml(url,proxyHost);
        return html;
        
    }
    public String getHtml(String url,HttpHost proxyHost){
        String html="";
        HttpGet httpGet = new HttpGet(url);
        httpGet.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxyHost);
        try {
            HttpResponse httpResponse = getHttpClient().execute(httpGet);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            if(200!= statusCode){
                return html;
            }
            HttpEntity entity = httpResponse.getEntity();
            if(entity!=null){
                html = readHtmlContentFromEntity(entity);
            }
            
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(httpGet!=null){
                httpGet.releaseConnection();
            }
        }
        return html;
    }
    //從response返回的實體讀取頁面代碼
    private String readHtmlContentFromEntity(HttpEntity entity) throws ParseException, IOException {
        String html = "";
        Header header = entity.getContentEncoding();
        if(entity.getContentLength()<2147483647L){//entity 無法處理長度大於2147483647L的entity
            if(header!=null && "gzip".equals(header.getValue())){
                html = EntityUtils.toString(new GzipDecompressingEntity(entity));
            }else{
                html = EntityUtils.toString(entity);
            }
        }else{
            InputStream is = entity.getContent(); 
            if(header != null && "gzip".equals(header.getValue())){
                html = unZip(is, ContentType.getOrDefault(entity).getCharset().toString());
            } else {
                html = readInStreamToString(is, ContentType.getOrDefault(entity).getCharset().toString());
            }
            if(is != null){
                is.close();
            }
        }
            
        return html;
    }
    private String readInStreamToString(InputStream is, String charSet) throws IOException {
        StringBuilder str = new StringBuilder();
        String line;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is, charSet));
        while((line = bufferedReader.readLine()) != null){
            str.append(line);
            str.append("\n");
        }
        if(bufferedReader != null) {
            bufferedReader.close();
        }
        return str.toString();
    }

    
    private String unZip(InputStream is, String charSet) throws IOException {
         ByteArrayOutputStream bos = new ByteArrayOutputStream();
         GZIPInputStream  gis = null;
         String unzipString="";
         try {
            gis = new GZIPInputStream(is);
            byte[] b = new byte[1024];
            int len = 0;
             while ((len = gis.read(b)) != -1) {
                    bos.write(b, 0, len);
                }
                unzipString = new String(bos.toByteArray(), charSet);
                
         } catch (IOException e) {
            e.printStackTrace();
        }finally{
            if(gis!=null){
                gis.close();
            }
            if(bos!=null){
                bos.close();
            }
        }
         return unzipString;
    }
    
    
    
    private static void writeInfo(File file, String info) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write(info);
            bw.newLine();
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fw.close();
                bw.close();
            } catch(IOException ioe) {
                ioe.printStackTrace();
            }
        }
        
    }
    //<!-- PageNum=14  --><!-- NumPages=18 -->
    public static void main(String[] args) throws Exception {
        proxy_ip = args[0];
        proxy_port = args[1];
        sourcePath = args[2];
        error = args[3];
        ArgParser argParser = new ArgParser().addOpt(USPageNumberDeal.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        int filePageFirst = 0;
        int filePageDesc=0;
        int filePageFig=0;
        int filePageClaim = 0;
        int filePageNumber= 0;
        String patentNumber = null;
        String url_front =null;
        String url_draw = null;
        String url_spec = null;
        String url_claim=null;
        USPageNumberDeal uipn = new USPageNumberDeal();
        
        FileReader reader = new FileReader(sourcePath);
        BufferedReader br = new BufferedReader(reader);
        String PN = null;
        while((PN=br.readLine())!=null){
            patentNumber = PN.substring(0,11);
            try {
                patentInfo = PatentInfo2.findPN(Pto.USPTO, patentNumber);
            } catch (Exception e1) {
                log.debug("PatentNumber "+patentNumber+ " "+e1.getMessage());
                writeInfo(new File(error),patentNumber+" "+e1.getMessage());
            }
            if(patentInfo==null){
                log.debug("could not find patent:"+patentNumber+" in level2 DB...");
                continue;
            }
            String pnquery="";
            if(patentNumber.indexOf("D")>0){
                pnquery="D0"+patentNumber.substring(5,11);
            }else if (patentNumber.indexOf("PP")>0) {
                pnquery="PP0"+patentNumber.substring(6,11);
            }else if (patentNumber.indexOf("RE")>0) {
                pnquery="RE0"+patentNumber.substring(6,11);
            }else if (patentNumber.matches("US\\d+{9}")) {
                pnquery=patentNumber.substring(3,11);
            }else if(patentNumber.matches("\\d+{11}")){
                pnquery=patentNumber.substring(0,11);
            }
            //http://pdfpiw.uspto.gov/.piw?docid=RE044475&SectionNum=2
            if(patentNumber.matches("\\d+{11}")){
                url_front = start_url_a+pnquery +"&SectionNum=1";
                url_draw =start_url_a+pnquery +"&SectionNum=2";
                url_spec = start_url_a+pnquery +"&SectionNum=3";
                url_claim= start_url_a+pnquery +"&SectionNum=4";
            }else{
                url_front = start_url_p+pnquery +"&SectionNum=1";
                url_draw =start_url_p+pnquery +"&SectionNum=2";
                url_spec = start_url_p+pnquery +"&SectionNum=3";
                url_claim= start_url_p+pnquery +"&SectionNum=4";
            }
        
            try {
                String html_front = uipn.getHtml(url_front);
                html_front = html_front.replaceAll("\\r\\n", " ").replaceAll("\\s+", "").trim().toLowerCase();
                if(html_front.indexOf("<!--pagenum")!=-1){
                    html_front= html_front.substring(html_front.indexOf("<!--pagenum"));
                    //String s =html_front.replaceAll(".*?section:frontpage.*?<b>([^<]+).*", "$1");
                    String s = html_front.replaceAll(".*?<!--pagenum=([^<]+.*)", "$1");
                    //System.out.println(s.indexOf("-->", 0));
                    filePageFirst = Integer.parseInt(s.substring(0,s.indexOf("-->", 0)));
                    String s1 = html_front.replaceAll(".*?<!--numpages=([^<]+.*)", "$1");
                    
                    filePageNumber = Integer.parseInt(s1.substring(0,s1.indexOf("-->", 0)));
                }
                //獲取drawing頁碼
                String html_draw = uipn.getHtml(url_draw);
                html_draw = html_draw.replaceAll("\\r\\n", " ").replaceAll("\\s+", "").trim().toLowerCase();
                if(html_draw.indexOf("<!--pagenum")!=-1){
                    html_draw= html_draw.substring(html_draw.indexOf("<!--pagenum"));
                    String s = html_draw.replaceAll(".*?<!--pagenum=([^<]+.*)", "$1");
                    //System.out.println(s.indexOf("-->", 0));
                    filePageFig = Integer.parseInt(s.substring(0,s.indexOf("-->", 0)));
                }
                //獲取specifications頁碼
                String html_spec = uipn.getHtml(url_spec);
                html_spec = html_spec.replaceAll("\\r\\n", " ").replaceAll("\\s+", "").trim().toLowerCase();
                if(html_spec.indexOf("<!--pagenum")!=-1){
                    html_spec= html_spec.substring(html_spec.indexOf("<!--pagenum"));
                    String s = html_spec.replaceAll(".*?<!--pagenum=([^<]+.*)", "$1");
                    filePageDesc = Integer.parseInt(s.substring(0,s.indexOf("-->", 0)));
                }
                //獲取claim頁碼
                String html_claim = uipn.getHtml(url_claim);
                html_claim = html_claim.replaceAll("\\r\\n", " ").replaceAll("\\s+", "").trim().toLowerCase();
                if(html_claim.indexOf("<!--pagenum")!=-1){
                    html_claim= html_claim.substring(html_claim.indexOf("<!--pagenum"));
                    String s = html_claim.replaceAll(".*?<!--pagenum=([^<]+.*)", "$1");
                    filePageClaim = Integer.parseInt(s.substring(0,s.indexOf("-->", 0)));
                }
                
                if(filePageNumber==0 ||filePageNumber<filePageFirst || filePageNumber <filePageFig || filePageNumber<filePageDesc || filePageNumber<filePageClaim){
                    log.debug("this patent could not be found in offical website...or the download has some problems...");
                    writeInfo(new File(error),patentNumber);
                }else {
                    try {
                        patentInfo.filePageClaim= filePageClaim;
                        patentInfo.filePageDesc = filePageDesc;
                        patentInfo.filePageFig = filePageFig;
                        patentInfo.filePageFirst= filePageFirst;
                        patentInfo.filePageNumber = filePageNumber;
                        patentInfo.save();
                    } catch (Exception e) {
                        log.debug("patentNumber" + patentNumber +" "+ e.getMessage());
                        continue;
                    }
                }
                log.debug("patentNumber:"+patentNumber +" update pagenumber success ....");
                
            } catch (NumberFormatException e) {
                log.debug("patentNumber:"+patentNumber+" "+"did not hava all pages ");
                writeInfo(new File(error),patentNumber);
            }
            
        }
        br.close();
        log.debug("finish");
    }
}
