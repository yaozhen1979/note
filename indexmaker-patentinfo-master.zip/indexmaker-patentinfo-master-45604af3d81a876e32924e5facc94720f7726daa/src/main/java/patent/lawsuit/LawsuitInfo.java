package patent.lawsuit;

import java.util.ArrayList;
import java.util.Date;
import org.apache.solr.client.solrj.beans.Field;

public class LawsuitInfo{

    public String lawsuitId;

    public String lawsuitTitle;

    public String lawsuitDocketNumber;

    public String lawsuitCount;

    public Date lawsuitDateField;

    public String lawsuitCause;

    public String lawsuitPlaintiff;

    public ArrayList<String> lawsuitDefendant;

    public String lawsuitCases;

    public Date lawsuitDocketInfoDate;

    public String lawsuitType;

    public String lawsuitDesc;

    public String lawsuitRelatedCases;

    public String lawsuitCounterDefendant;

    public String lawsuitCounterClaimant;

    public String lawsuitAdditionalDefendant;

    public String lawsuitAdditionalDefendants;

    public String lawsuitThree;

    public String lawsuitConsolCounterClaimant;

    public String lawsuitMediator;

    public String lawsuitThirdPartyPlaintiff;

    public String lawsuitThirdPartyDefendant;

    public String lawsuitRegistrationNo;

    public String lawsuitContent;

    public ArrayList<PatentAtLawsuit> patents; 
}
