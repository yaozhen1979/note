package patent.lawsuit;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;


public class MongoToLawsuitInfo {
    private static DBCollection col;
    private static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    static {
        try {
            MongoCredential credential = MongoCredential.createCredential("patentdata", "admin", "data.cloud.Abc12345".toCharArray());
            MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.155"), Arrays.asList(credential));
            DB db = mongoClient.getDB("admin").getSisterDB("WestLaw");
            col = db.getCollection("WestLaw");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Pattern patentNumberPattern = Pattern.compile("(No\\.\\s+)(\\d+)");
    private static PatentAtLawsuit convertToPatents(DBObject dbobj) {
        PatentAtLawsuit patent = new PatentAtLawsuit();
        Set keys = dbobj.keySet();
        for(Object key: keys) {
            String keyStr = (String)key;
            if(keyStr.equalsIgnoreCase("Patent Number")) {
                Matcher matcher = patentNumberPattern.matcher(dbobj.get(keyStr).toString());
                if(matcher.find()) {
                    patent.patentNumber = matcher.group(2);
                } else {
                    System.out.println("can't match patent number");
                }
            } else if (keyStr.equalsIgnoreCase("Application Number")) {
                patent.applicationNumber = dbobj.get(keyStr).toString();
            } 
        }
        patent.content = dbobj.toString();
        return patent;
    }

    public static LawsuitInfo dbObjectToLawsuitInfo(DBObject dbobj) throws ParseException {
        Set keys = dbobj.keySet();
        LawsuitInfo lawsuitInfo = new LawsuitInfo();
        lawsuitInfo.lawsuitContent = dbobj.toString();
        for(Object key: keys) {
            String keyStr = (String)key;
            if(keyStr.equalsIgnoreCase("_id")) {
                lawsuitInfo.lawsuitId = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Title")) {
                lawsuitInfo.lawsuitTitle = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Type")) {
                lawsuitInfo.lawsuitType = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Desc")) {
                lawsuitInfo.lawsuitDesc = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Related Cases")) {
                lawsuitInfo.lawsuitRelatedCases = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Counter Defendant")) {
                lawsuitInfo.lawsuitCounterDefendant = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Counter Claimant")) {
                lawsuitInfo.lawsuitCounterClaimant = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Additional Defendant")) {
                lawsuitInfo.lawsuitAdditionalDefendant = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Consol Counter Claimant")) {
                lawsuitInfo.lawsuitConsolCounterClaimant = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Docket Number")) {
                lawsuitInfo.lawsuitDocketNumber = dbobj.get(keyStr).toString();
            } else if(keyStr.equalsIgnoreCase("Court")) {
                lawsuitInfo.lawsuitCount = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("Date Filed")) {
                lawsuitInfo.lawsuitDateField = sdf.parse(dbobj.get(keyStr).toString());
            } else if (keyStr.equalsIgnoreCase("Cause")) {
                lawsuitInfo.lawsuitCause = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("Mediator")) {
                lawsuitInfo.lawsuitMediator = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("ThirdParty Plaintiff")) {
                lawsuitInfo.lawsuitThirdPartyPlaintiff = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("ThirdParty Defendant")) {
                lawsuitInfo.lawsuitThirdPartyDefendant = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("Plaintiff")) {
                lawsuitInfo.lawsuitPlaintiff = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("Registration No")) {
                lawsuitInfo.lawsuitRegistrationNo = dbobj.get(keyStr).toString();
            } else if (keyStr.equalsIgnoreCase("Defendant")) {
                ArrayList<String> defendant = new ArrayList<String>();
                BasicDBList dblist = (BasicDBList) dbobj.get(keyStr);
                for(int i = 0; i < dblist.size(); i ++) {
                    defendant.add(dblist.get(i).toString());
                }
                lawsuitInfo.lawsuitDefendant = defendant;
            } else if (keyStr.equalsIgnoreCase("Cases")) {
                lawsuitInfo.lawsuitCases = (String) dbobj.get(keyStr);
            } else if (keyStr.equalsIgnoreCase("Docket Info Date")) {
                lawsuitInfo.lawsuitDocketInfoDate = sdf.parse(dbobj.get(keyStr).toString());
            } else if (keyStr.equalsIgnoreCase("Patents")) {
                ArrayList<PatentAtLawsuit> patents = new ArrayList<PatentAtLawsuit>();
                BasicDBList dblist = (BasicDBList) dbobj.get(keyStr);
                for(int i = 0; i < dblist.size(); i ++) {
                    patents.add(convertToPatents((DBObject)dblist.get(i)));
                }
                lawsuitInfo.patents = patents;
            }
            else {
                System.out.println("unknow field: " + keyStr + ", id:" + dbobj.get("_id").toString());
            }
        }
        return lawsuitInfo;
    }
    public static List<LawsuitInfo> findInfos() throws Exception {
        BasicDBObject doc = new BasicDBObject();
        ArrayList<LawsuitInfo> lawsuitInfos = new ArrayList<LawsuitInfo>();
        DBCursor cursor= col.find();
        while(cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            lawsuitInfos.add(dbObjectToLawsuitInfo(dbobj));
        }
        return lawsuitInfos;
        
    }

    public static void main(String[] args) throws Exception {
        List<LawsuitInfo> lawsuitInfos = findInfos();
        for(LawsuitInfo lawsuitInfo: lawsuitInfos) {
            if(lawsuitInfo.patents != null) {
                for(PatentAtLawsuit patent: lawsuitInfo.patents) {
                    System.out.println(patent.patentNumber);
                }
            }
        }
    }
}
