package patent.lawsuit;


public class PatentAtLawsuit {
    public String patentNumber;
    public String applicationNumber;
    public String content;

}
