package patent.mongoImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawWIPO;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;

/**
 * @author yiyun
 * import wo data (purchase) to level1 mongo db
 * WIPO资料来源  
 * WIPO Disk    硬碟
 * WIPO DVD        光碟
 * WIPO Ftp        Ftp
 */
public class WipoImporterDVD {        

    static Log log = LogFactory.getLog(WipoImporterDVD.class);
    private static Class<? extends PatentRaw> rawclazz = PatentRawWIPO.class;
    private static Pto pto = Pto.WIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.60.90.121/PatentRawWIPO";

    public static final String opt_wipo_path = "wipo.path";
    public static final String opt_wipo_path_default = "E:\\WIPO_uncompress\\2014\\DVD\\week37";    

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "WIPO DVD";
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_wipo_path, true, opt_wipo_path_default, "WIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
    };

    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(WipoImporterDVD.class);
//        MongoInitUtils.nothing();
    }
    private MongoClientURI mongouri;    
    private MongoClient mongo;
    private DB mongodb;
    private ProcessEstimater pe;
    private static String provider;
    
    public static void main(String[] args) throws Exception {
        /*ArgParser argParser = new ArgParser().addOpt(WipoImporterDVD.class).parse(args);    
        MongoAuthInitUtils.reload(argParser);
        
        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_wipo_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        new WipoImporterDVD(argMongo).importDir(new File(argPath));
        log.debug("finish");*/
        WipoImporterDVD wipoImporterDVD = new WipoImporterDVD();
        wipoImporterDVD.worker(args);
    }
    
    public WipoImporterDVD() {}

    public WipoImporterDVD(String mongouri) throws UnknownHostException {
        this.mongouri = new MongoClientURI(mongouri);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(WipoImporterDVD.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        
        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_wipo_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        new WipoImporterDVD(argMongo).importDir(new File(argPath));
        log.debug("finish");
    }
    
    public void importDir(File dir) throws IOException {
        if(dir.isDirectory()) {
            for(File subDir : dir.listFiles()) {
                importDir(subDir);
            }
        } else {
            String path = dir.toPath().toString();
            if(path.endsWith("pdf")) {
                return;
            }
            path = path.substring(path.indexOf("20"));
            path = path.replace('\\', '/');
            Date doDate = getDate(path);
            
            PatentRawWIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            PatentRawWIPO raw = new PatentRawWIPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;
            raw.doDate = doDate;
            raw.data.put("xml", FileUtils.readFileToString(dir, "UTF-8"));
            raw.save();
            pe.addNum().debug(log, 10000, "save: '" + path + "'");
        }
    }
    
    public Date getDate(String path) {
        try {
            String year = path.substring(0, 4);
            String week = path.substring(path.indexOf("week")+4, path.indexOf("week")+6);
            return getDateByWeek(year + "-" + week);
        } catch (Exception e) {
            return null;
        }
    }
    
    public Date getDateByWeek(String period) {    
        int year = Integer.parseInt(period.split("-")[0]);
        int week = Integer.parseInt(period.split("-")[1]);
        Calendar cal = Calendar.getInstance();
        switch(year) {
        case 2011:
            cal.set(2011, 0, 6, 0, 0, 0);
            break;
        case 2012:
            cal.set(2012, 0, 5, 0, 0, 0);
            break;
        case 2013:
            cal.set(2013, 0, 3, 0, 0, 0);
            break;
        case 2014:
            cal.set(2014, 0, 2, 0, 0, 0);
            break;
        case 2015:
            cal.set(2015, 0, 8, 0, 0, 0);
            break;
        case 2016:
            cal.set(2016, 0, 7, 0, 0, 0);
            break;
        default:
            return null;
        }
        int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
        cal.set(Calendar.DAY_OF_YEAR, dayOfYear + 7*(week-1));
        
        if (period.equals("2014-53")) {
            cal.set(2014, 11, 30, 0, 0, 0);
        }
        return cal.getTime();
    }
}
