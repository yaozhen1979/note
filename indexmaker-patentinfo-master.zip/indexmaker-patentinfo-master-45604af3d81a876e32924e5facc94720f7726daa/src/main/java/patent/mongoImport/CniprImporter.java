package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawCNIPR;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoURI;

public class CniprImporter {

    static Log log = LogFactory.getLog(CniprImporter.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawCNIPR.class;

    private static Pto pto = Pto.CNIPR;

    public static final String opt_cnipr_path = "cnipr.path";
    public static final String opt_cnipr_path_default = "";

    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "CNIPR";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_cnipr_path, true, opt_cnipr_path_default, "CNIPR raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default, "do CNIPR raw data local path, keep empty for cnipr.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
    };

    public static final Class<?>[] optDep = {
        MongoInitUtils.class,
    };

    static {
        ConfigUtils.setSearchBase(CniprImporter.class);
    }

    private File bookpath;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(CniprImporter.class).parse(args);
        MongoInitUtils.reload(argParser);

        String argPath = argParser.getOptString(opt_cnipr_path);
        String argDoPath = argParser.getOptString(opt_do_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        if (argDoPath.isEmpty()) {
            new CniprImporter(argPath).importDir();
        } else {
            new CniprImporter(argPath).importDir(new File(argDoPath));
        }
        log.debug("finish");
    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public CniprImporter(String bookpath) throws UnknownHostException {
        this.bookpath = new File(bookpath);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    public CniprImporter importDir() throws IOException {
        return importDir(bookpath);
    }

    public CniprImporter importDir(File dir) throws IOException {
        if (dir.isDirectory()) {
            File fileBiblio = dir.toPath().resolve("bibliography.html").toFile();
            if (fileBiblio.isFile()) {
                File fileClaim = dir.toPath().resolve("claim.xml").toFile();
                File fileDesc = dir.toPath().resolve("description.xml").toFile();
                String path = bookpath.toPath().relativize(dir.toPath()).toString().replaceAll("\\\\", "/");
                Date doDate = DateUtils.parseDate(dir.getParentFile().getName());

                if (doDate == null) {
                    // process special case
                    while (true) {
                        Matcher mat;
                        mat = Pattern.compile("(?i)^SD/1992/19921230Z/").matcher(path);
                        if (mat.find()) {
                            doDate = DateUtils.parseDate("19921230");
                            break;
                        }
                        mat = Pattern.compile("(?i)^WG/(\\d{4})/\\d{4}/").matcher(path);
                        if (mat.find()) {
                            doDate = DateUtils.parseDate(mat.group(1) + "0101");
                            break;
                        }
                        break;
                    }
                }

                PatentRawCNIPR.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
                PatentRawCNIPR raw = new PatentRawCNIPR();
                raw.pto = pto;
                raw.path = path;
                raw.data = new BasicDBObject();
                raw.type = "html/json-html";
                raw.provider = provider;
                raw.doDate = doDate;

                raw.data.put("bibliography", FileUtils.readFileToString(fileBiblio, "UTF-8"));
                if (fileClaim.isFile()) {
                    raw.data.put("claim", FileUtils.readFileToString(fileClaim, "UTF-8"));
                }
                if (fileDesc.isFile()) {
                    raw.data.put("description", FileUtils.readFileToString(fileDesc, "UTF-8"));
                }

                raw.save();
                pe.addNum().debug(log, 10000, "save: '" + path + "'");
            } else {
                for (File file : dir.listFiles()) {
                    if (file.isDirectory()) {
                        importDir(file);
                    }
                }
            }
        }
        return this;
    }

}
