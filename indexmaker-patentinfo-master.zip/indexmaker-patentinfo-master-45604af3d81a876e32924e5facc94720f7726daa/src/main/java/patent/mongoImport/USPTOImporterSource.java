package patent.mongoImport;

import itec.patent.common.MongoAuthInitUtils;

import java.io.File;
import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

public class USPTOImporterSource {
    Log log = LogFactory.getLog(USPTOImporterSource.class);
    
    public static final String opt_uspto_path = "uspto.path";
    public static final String opt_uspto_path_default = "H:/TDDOWNLOAD/PatentGrantFullText/2012";
    

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_uspto_path, true,opt_uspto_path_default,"USPTO raw data local path, like /mnt/kangaroo"),            
    };
    
    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(USPTOImporterSource.class);
        //MongoInitUtils.nothing();
    }
    
    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(USPTOImporter.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        String sourcePath = argParser.getOptString(opt_uspto_path);
        
        File file = new File(sourcePath);
        File f[] = file.listFiles();
        
        for(int i =0;i<f.length;i++){
            if(f[i].getName().indexOf("ipa")!=-1){
                USPTOImporter.worker(args);
            }else if(f[i].getName().indexOf("ipg")!=-1){
                USPTOImporter.worker(args);
            }
        }
        
    }
    public static void main(String[] args) throws Exception {
        
    }
}
