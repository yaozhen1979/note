package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawTIPO;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.ReadPreference;

/**
 * @author Genchi
 * import tw data (purchase or download) to level1 mongo db
 */
public class TipoImporter {

    static Log log = LogFactory.getLog(TipoImporter.class);
    static DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    private static Class<? extends PatentRaw> rawclazz = PatentRawTIPO.class;

    private static Pto pto = Pto.TIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/PatentRawTIPO";

    public static final String opt_tipo_path = "tipo.path";
    public static final String opt_tipo_path_default = "\\\\10.153.27.120\\tw_xml\\TIPO 資料\\公告_00000-37036\\iss";

    public static final String opt_do_vol = "do.path";
    public static final String opt_do_vol_default = "";

    public static final String opt_tipo_status = "tipo.status";
    public static final String opt_tipo_status_default = "issued";
    
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "TIPO Purchase";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_tipo_path, true, opt_tipo_path_default, "TIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_vol, true, opt_do_vol_default, "year of TIPO raw data, keep empty for tipo.path"),
        new ArgParser.Option(null, opt_tipo_status, true, opt_tipo_status_default, "issued or published, keep empty for tipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(TipoImporter.class);
        MongoInitUtils.nothing();
    }

    private File tipopath;

    private MongoClientURI mongouri;

    private MongoClient mongo;

    private DB mongodb;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(TipoImporter.class).parse(args);
        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_tipo_path);
        String argDoVol = argParser.getOptString(opt_do_vol);
        String argStatus = argParser.getOptString(opt_tipo_status);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        new TipoImporter(argPath, argMongo).importDir(argDoVol, argStatus);
        log.debug("finish");
    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public TipoImporter(String tipopath, String mongouri) throws UnknownHostException {
        this.tipopath = new File(tipopath);
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());

        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    public String ConvertYear2Vol(String argDoYear, String argStatus)
    {
        String volStr ="";
        if(argDoYear.isEmpty() || argStatus.isEmpty())
        {
            return volStr;
        }
        try
        {
            int startYear;
            if(argStatus.equalsIgnoreCase("issued"))
            {
                startYear = 1973;
            }
            else if(argStatus.equalsIgnoreCase("published"))
            {
                startYear = 2002;
            }
            else
            {
                log.debug("patent status err");
                throw new Exception("patent status err");
            }
            int yearInt = Integer.parseInt(argDoYear);
            int vol = yearInt -startYear;
            if((vol - 10) < 0)
            {
                volStr = "0" + Integer.toString(vol);
            }
            else
            {
                volStr = Integer.toString(vol);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return volStr;
    }

    public Date ConvertVol2Year(String vol, String argStatus)
    {
        Date date = null;
        String year = "";
        String month = "";
        String day = "";
        int vol2 = Integer.parseInt(vol.substring(vol.length()-2));
        int startYear = 0;
        try
        {
            if(argStatus.equalsIgnoreCase("issued"))
            {
                startYear = 1973;
                int m = vol2 / 3;
                int d = vol2 % 3;
                if( d == 0) {
                    day = "21";
                } else if (d == 1) {
                    m = m + 1;
                    day = "01";
                } else if (d == 2) {
                    m = m + 1;
                    day = "11";
                }
                if( m < 10) {
                    month = "0" + Integer.toString(m);
                } else {
                    month = Integer.toString(m);
                }
            }
            else if(argStatus.equalsIgnoreCase("published"))
            {
                startYear = 2002;
                int m = vol2 / 2;
                int d = vol2 % 2;
                if( d == 0) {
                    day = "16";
                } else if (d == 1) {
                    m = m + 1;
                    day = "01";
                }
                if( m < 10) {
                    month = "0" + Integer.toString(m);
                } else {
                    month = Integer.toString(m);
                }
            }
            else
            {
                throw new Exception("can't recognition tipo status : " + argStatus);
            }
            year = Integer.toString((startYear + Integer.parseInt(vol.substring(0, 2))));
            date = DateUtils.parseDate(year + "/" + month + "/" + day);
            //date = df.parse(year + "/" + month + "/" + day);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return date;
    }
    
    public TipoImporter importDir(String argDoVol, String argStatus) throws IOException {
        File[] dirs = tipopath.listFiles();
        //String volStr = ConvertYear2Vol(argDoYear, argStatus);
        //if(volStr.isEmpty())
        if(argDoVol.isEmpty())
        {
            for(File dir : dirs)
            {
                importDir(dir, argStatus);
            }
        }
        else
        {
            for(File dir : dirs)
            {
                if(dir.getName().startsWith(argDoVol))
                {
                    importDir(dir, argStatus);
                }
            }
        }
        return this;
    }

    public TipoImporter importDir(File dir, String argStatus) throws IOException {
        if (dir.isDirectory()) {
            File[] filesBiblio = dir.listFiles();
            for (File fileBiblio : filesBiblio) {
                String absolutePath = fileBiblio.toPath().toString();
                String path = absolutePath.substring(absolutePath.toLowerCase().indexOf("tipo")).replaceAll("\\\\", "/");
                Date doDate = ConvertVol2Year(dir.getName(), argStatus);
                if(doDate != null)
                {
                    PatentRawTIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
                    PatentRawTIPO raw = new PatentRawTIPO();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    raw.type = "text/text";
                    raw.provider = provider;
                    raw.doDate = doDate;
                    raw.data.put("text", FileUtils.readFileToString(fileBiblio, "UTF-8"));
                    raw.save();
                    pe.addNum().debug(log, 10000, "save: '" + path + "'");
                }
            }
        }
        return this;
    }

}
