package patent.mongoImport;

import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawWIPO;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;

/**
 * @author yiyun
 * import wo data (purchase) to level1 mongo db
 */
public class WipoImporterDisk {

    static Log log = LogFactory.getLog(WipoImporterDisk.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawWIPO.class;

    private static Pto pto = Pto.WIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/PatentRawWIPO";

    public static final String opt_wipo_path = "wipo.path";
    public static final String opt_wipo_path_default = "\\\\10.153.24.169\\wo$\\wo\\Xml";        // 硬碟资料路径
    /**
     * WIPO资料来源  
     * WIPO Disk    硬碟
     * WIPO DVD        光碟
     * WIPO Ftp        Ftp
     */
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "WIPO Disk";
    /** 文件起始年份 */
    public static final String startYear = "1999";        
    /**  文件结束年份 */
    public static final String endYear = "2008";        

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_wipo_path, true, opt_wipo_path_default, "WIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(WipoImporterDisk.class);
        //MongoInitUtils.nothing();
    }
    /** mongoDB 地址*/
    private MongoClientURI mongouri;
    /** mongoDB 客户端 */
    private MongoClient mongo;
    private DB mongodb;
    private ProcessEstimater pe;
    /** 来源 */
    private static String provider;
    
    public static void main(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(WipoImporterDisk.class).parse(args);    
        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_wipo_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        //new WipoImporter(argPath, argMongo).importDir(new File(argPath));
        new WipoImporterDisk(argPath, argMongo).importDir(new File(argPath), startYear, endYear);
        log.debug("finish");
    }

    /**
     * 构造函数
     * @param wipopath
     * @param mongouri
     * @throws UnknownHostException
     */
    public WipoImporterDisk(String wipopath, String mongouri) throws UnknownHostException {
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());
        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    /**
     * 导入指定文件范围内的文件
     * @param dir
     * @param startFileName
     * @param endFileName
     * @throws IOException
     */
    public void importDir(File dir, String startFileName, String endFileName) throws IOException {
        List<String> fileListNames = getFileListWithRange(dir, startFileName, endFileName);
        for(Iterator<String> it = fileListNames.iterator(); it.hasNext(); ) {
            importDir(new File(it.next()));
        }
    }
    
    /**
     * 导入指定文件中的所有文件
     * @param dir
     * @throws IOException
     */
    public void importDir(File dir) throws IOException {
        if(dir.isDirectory()) {
            for(File subDir : dir.listFiles()) {
                importDir(subDir);
            }
        } else {
            String path = dir.toPath().toString();
//            path = path.substring(path.indexOf("Xml")+4);
            path = path.substring(path.indexOf("WIPO_uncompress")+16);
            path = path.replace('\\', '/');
            Date doDate = getDate(path);
            
            PatentRawWIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            PatentRawWIPO raw = new PatentRawWIPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;
            raw.doDate = doDate;
            raw.data.put("xml", FileUtils.readFileToString(dir, "UTF-8"));
            raw.save();
            pe.addNum().debug(log, 10000, "save: '" + path + "'");
        }
    }
    
    /**
     * 获取doYear
     * @param path
     * @return
     */
    public Date getDate(String path) {
        try {
            String dateString = path.substring(0, 4);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
            return sdf.parse(dateString);
        } catch (Exception e) {
            return null;
        }
    }
    
    
    /**
     * 獲取指定範圍內的文件列表
     * @param root
     * @param starFileName
     * @param endFileName
     * @return
     */
    public List<String> getFileListWithRange(File root, String starFileName, String endFileName) {
        List<String> fileNameList = new ArrayList<String>();
        File[] fileList = root.listFiles();
        for(int i = 0; i < fileList.length; i++) {
            String fileName = fileList[i].getName();
            if(fileName.equals(starFileName)) {
                for(int j = i; j < fileList.length; j++) {
                    fileName = fileList[j].getName();
                    fileNameList.add(root + File.separator + fileName);
                    if(fileName.equals(endFileName)) {
                        break;
                    }
                }
            }
        }
        return fileNameList;
    }
}
