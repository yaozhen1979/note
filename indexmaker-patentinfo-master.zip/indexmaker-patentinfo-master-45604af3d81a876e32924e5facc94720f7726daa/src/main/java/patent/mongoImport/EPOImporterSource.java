package patent.mongoImport;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawEPO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;



public class EPOImporterSource {

    static Log log = LogFactory.getLog(EPOImporterSource.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawEPO.class;

    private static Pto pto = Pto.EPO;
    
    private ProcessEstimater pe;
    private static String provider;
//    private static List<String> fileNames = new ArrayList<String>();
    private List<String> fileNames = new ArrayList<String>();
    private static Calendar cal = Calendar.getInstance();
    private static String year = String.valueOf(cal.get(Calendar.YEAR));
    
    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.60.90.121/PatentRawEPO";

//    //從TXT導入
//    public static final String opt_epo_path = "epo.path";
//    public static final String opt_epo_path_default = "\\\\10.153.27.94\\ep_xml_zip\\MongoDB_EP_List\\2012.txt";
    //讀取文件
    public static final String opt_epo_path = "epo.path";
//    public static final String opt_epo_path_default = "\\\\10.153.27.94\\MongoDB_xml_path\\1978\\1978A";
    /*public static final String opt_epo_path_default = "E:\\epImageOriginData\\2014(37AB)";
    public static final String pathField = "2014(37AB)";//2014(12AB)for path
*/    public static final String opt_epo_path_default = "E:\\epImageOriginData\\" + year;//"E:\\epImageOriginData\\2014";
    
    //文件起始 
    public static final String startFileName = "DOC";//2006年之後是DOC,之前EP        
    //文件结束
    public static final String endFileName = "xml";
    
    public static final String opt_do_time = "do.path";
    public static final String opt_do_time_default = "";
    
    public static final String opt_do_path = "start.path";
    public static final String opt_do_path_default = "00000000";

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "EPO Download";//~~---2010 Purchase 2011---~~now Download
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_epo_path, true, opt_epo_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_time, true, opt_do_time_default, "year or date of KIPO raw data, keep empty for kipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default, "start do date"),
        
    };

    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(EPOImporterSource.class);
    }
    
    /**
     * -mongodb.host 10.60.90.121 
     * -mongodb.name PatentRawEPO 
     * -mongodb.ac cGF0ZW50ZGF0YQ== 
     * -mongodb.pd ZGF0YS5jbG91ZC5BYmMxMjM0NQ==  
     * -epo.path E:\epImageOriginData\2014(37AB)
     */
    public static void main(String[] args) throws Exception{
        
        EPOImporterSource epoImporterSource = new EPOImporterSource();
        epoImporterSource.worker(args);
        
    }
    
    public void worker(String[] args) throws Exception{
        try {
            ArgParser argParser = new ArgParser().addOpt(EPOImporterSource.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
            
            //String argMongo = argParser.getOptString(opt_mongo);
            String argPath = argParser.getOptString(opt_epo_path);
            provider = argParser.getOptString(opt_provider);
            //do_Date = argParser.getOptString(opt_do_path);
            
            if (log.isDebugEnabled()) {
                log.debug("start, opt: " + argParser.getParsedMap());
            }
//            new EPOImporter(argPath, argMongo).importDir(argPath);//從TXT導入
//            new EPOImporter(argPath, argMongo).importDir(new File(argPath));//讀取文件
//            new EPOImporterSource(argPath, argMongo).importDir(argPath, startFileName, endFileName);
            new EPOImporterSource().importDir(argPath, startFileName, endFileName);
            log.debug("finish");
        } catch (org.apache.commons.cli.ParseException e) {
            System.out.println(e.getMessage());
        }    
    }
    
    /**
     * 權限登陸管控
     * @param kipopath
     * @param mongoHost
     * @param dbName
     * @param username
     * @param password
     */
    public EPOImporterSource(){
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    
    private void importDir(String dir) throws ParseException, IOException {
        List<String> fileNames =  read(dir);
        int week = getWeekByFileName(dir);
        Date date =  getThirdDayOfWeek(Integer.valueOf(year), week);
        for (Iterator<String> iterator = fileNames.iterator(); iterator.hasNext();) {
            String filePath = (String) iterator.next();
            String path = filePath.substring(filePath.indexOf(year) + (year + File.separator).length() , filePath.lastIndexOf(File.separator));
            path = path.replace('\\', '/');
            PatentRawEPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            //Date date = df.parse(do_Date);
            //刪除整年
//            PatentRawEPO.remove(rawclazz, new QueryHelp("doDate", date).filter("pto", pto.toString()));
            PatentRawEPO raw = new PatentRawEPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;//2010 before Purchase
            raw.doDate = date;
            raw.data.put("xml", FileUtils.readFileToString(new File(filePath), "UTF-8"));
            try
            {
                raw.save();
            }
            catch (Exception e)
            {
                log.info("save raw data err : " + filePath);
                throw e;
            }
            pe.addNum().debug(log, 10000,
                    "save: '" + path + "'");
            }
        }

    
    /**
     * @param dir
     * @param startFileName
     * @param endFileName
     * @throws IOException
     * @throws ParseException 
     */
    public void importDir(String dir, String startFileName, String endFileName) throws IOException, ParseException
    {
        List<String> fileListNames = getFilePathList(dir, startFileName, endFileName);
        int week = getWeekByFileName(dir);
        Date date =  getThirdDayOfWeek(Integer.valueOf(year), week);
        log.info("num is : " + fileListNames.size());
        for(Iterator<String> it = fileListNames.iterator(); it.hasNext(); ) {
            importDir(new File(it.next()) , date);
        }
    }
    
    /**
     * 导入指定文件中的所有文件
     * @param dir
     * @throws IOException
     * @throws ParseException 
     */
    public void importDir(File dir , Date date) throws IOException, ParseException
    {
        if(dir.isDirectory())
        {
            for(File subDir : dir.listFiles()) {
                importDir(subDir, date);
            }
        }
        else
        {
            String filePath = dir.toPath().toString();
            String path = filePath.substring(filePath.indexOf(year) + (year+ File.separator).length() , filePath.lastIndexOf(File.separator));
            path = path.replace('\\', '/');
            //Date date = df.parse(do_Date);
            PatentRawEPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            PatentRawEPO raw = new PatentRawEPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;
            raw.doDate = date;
            raw.data.put("xml", FileUtils.readFileToString(dir, "UTF-8"));
            raw.save();
            pe.addNum().debug(log, 10000, "save: '" + path + "'");
        }
    }
    
    /**
     * 讀取TXT文件
     * @param dir
     * @return
     */
    private List<String> read(String dir) {
        List<String> list = new ArrayList<String>();
        int bufferSize = 20*1024*1024;
        FileInputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try 
        {
            File file = new File(dir);
            is = new FileInputStream(file);
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr,bufferSize);
            String line = "";
            while((line = br.readLine()) != null) 
            {
                list.add(line.trim());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                is.close();
                isr.close();
                br.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    /**
     * 獲取指定文件夾下的所有XML文件
     * @param root
     * @return fileNames
     */
    public List<String> getFilePathList(String root, String startWith, String endWith) {
        
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        getFilePathList(fileList[i].getPath(), startWith ,endWith);
                    } else {
                        if (fileList[i].getName().startsWith(startWith) && fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().startsWith(startWith) && file.getName().endsWith(endWith) ) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    
    /**  
     * 得到某年某周的週三  
     *  
     * @param year  
     * @param week  1:週日    7：週六
     * @return  
     */  
    public static Date getThirdDayOfWeek(int year, int week) {  
        Calendar c = Calendar.getInstance();  
        c.set(Calendar.YEAR, year);  
        c.set(Calendar.WEEK_OF_YEAR, week);  
        c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);//设置周一  
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek() + 2); // Sunday   
  
        return c.getTime();  
    } 
    
    /**
     * 根據指定路徑下檔案名稱，獲得週數   XEPA2014036--->36
     * @param path
     * @return
     */
    public static int getWeekByFileName(String path) {
        int week = 1;
        String fileName  = "";
        File file = new File(path);
        if (file.isDirectory()) {
            File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) {
                fileName =  fileList[0].getName();
                int length = fileName.length();
                week = Integer.valueOf(fileName.substring(length - 2, length));
                break;
            }
        }
        return week;
    }
    
}
