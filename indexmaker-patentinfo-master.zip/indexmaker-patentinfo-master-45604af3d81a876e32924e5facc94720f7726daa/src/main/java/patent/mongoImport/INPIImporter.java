package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawINPI;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.ReadPreference;

public class INPIImporter {

    static Log log = LogFactory.getLog(INPIImporter.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawINPI.class;

    private static Pto pto = Pto.INPI;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/PatentRawINPI";

    public static final String opt_inpi_path = "inpi.path";
    public static final String opt_inpi_path_default = "";

    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "\\\\10.153.27.10\\fr_xml\\FR\\";

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "INPI";

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_mongo, true, opt_mongo_default,
                    "mongodb uri, start with mongodb://"),
            new ArgParser.Option(null, opt_inpi_path, true,
                    opt_inpi_path_default,
                    "INPI raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, opt_do_path, true, opt_do_path_default,
                    "do INPI raw data local path, keep empty for inpi.path"),
            new ArgParser.Option(null, opt_provider, true,
                    opt_provider_default, "Provider saved to DB"), };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(INPIImporter.class);
        MongoInitUtils.nothing();
    }

    private File inpipath;

    private MongoClientURI mongouri;

    private MongoClient mongo;

    private DB mongodb;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(INPIImporter.class)
                .parse(args);

        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_inpi_path);
        String argDoPath = argParser.getOptString(opt_do_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        if (argDoPath.isEmpty()) {
            new INPIImporter(argPath, argMongo).importDir();
        } else {
            new INPIImporter(argPath, argMongo).importDir(new File(argDoPath));
        }
        log.debug("finish");
    }

    /**
     * @param mongouri
     *            {@link MongoURI}
     */
    public INPIImporter(String bookpath, String mongouri)
            throws UnknownHostException {
        this.inpipath = new File(bookpath);
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());

        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }

    public INPIImporter importDir() throws IOException {
        return importDir(inpipath);
    }

    public INPIImporter importDir(File dir) throws IOException {
        if (dir.isDirectory()) {
            log.debug(dir.getName());
            for (File file : dir.listFiles()) {
                if (file.isDirectory()) {
                    importDir(file);
                } else {
                    String path = file.getParentFile().getParentFile()
                            .getName()
                            + "/"
                            + file.getParentFile().getName()
                            + "/"
                            + file.getName();
                    String s = dir.toPath().toString();
                    String year=s.substring(s.lastIndexOf("\\")).substring(4,
                            8);
//                    String pac=s.substring(s.lastIndexOf("\\")).substring(9,11);
//                    if(Integer.valueOf(year)<2001) return null; //控制年份
//                    if(Integer.valueOf(year)==2001&&Integer.valueOf(pac)<2) return null; //控制包
                    String date = year
                            + "0101";
                    Date doDate = DateUtils.parseDate(date);
                    if (doDate == null) {
                         log.error("doDate parse error!");
                        return null;
                    }

                    PatentRawINPI.remove(
                            rawclazz,
                            new QueryHelp("path", path).filter("pto",
                                    pto.toString()));
                    PatentRawINPI raw = new PatentRawINPI();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    raw.type = "xml/xml";
                    raw.provider = provider;
                    raw.doDate = doDate;

                    raw.data.put("xml",
                            FileUtils.readFileToString(file, "UTF-8"));

                    raw.save();
                    pe.addNum().debug(log, 10000, "save: '" + path + "'");
                }
            }
        }
        return this;
    }
}
