package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawUSPTO;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Enumeration;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoURI;

public class USPTOImporter {

    static Log log = LogFactory.getLog(USPTOImporter.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawUSPTO.class;

    private static Pto pto = Pto.USPTO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.60.90.155/PatentRawUSPTO";
    public static final String opt_uspto_path = "uspto.path";
    public static final String opt_uspto_path_default = "H:/TDDOWNLOAD/PatentGrantFullText/2012";
    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";
    public static final String usptoRootPath = "PatentGrantFullText";
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "GooglePatent_ipg";
    
    
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default,"mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_uspto_path, true,opt_uspto_path_default,"USPTO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default,"do USPTO raw data local path, keep empty for uspto.path"),
        new ArgParser.Option(null, opt_provider, true,opt_provider_default, "Provider saved to DB"), 
            
    };

    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    public USPTOImporter() {

    }
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(USPTOImporter.class);
        //MongoInitUtils.nothing();
    }

    private File usptopath;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {
        USPTOImporter usptoImporter = new USPTOImporter();
        usptoImporter.worker(args);
    }
    
    public static void worker(String[] args) throws Exception{
        ArgParser argParser = new ArgParser().addOpt(USPTOImporter.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        
        String argMongo = argParser.getOptString(opt_mongo);
        String argDoPath = argParser.getOptString(opt_uspto_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        if (argDoPath.isEmpty()) {
            new USPTOImporter(argDoPath, argMongo).importDir();
        } else {
            new USPTOImporter(argDoPath, argMongo).importDir(new File(argDoPath));
        }
        log.debug("finish");
    }

    /**
     * @param mongouri
     *            {@link MongoURI}
     */

    
    public USPTOImporter(String usptopath,String mongouri){
        this.usptopath = new File(usptopath);
        pe = new ProcessEstimater(0).setFormat("%2$d");
        
    }

    

    public USPTOImporter importDir() throws IOException {
        return importDir(usptopath);
    }

    public USPTOImporter importDir(File dir) throws IOException {
        if (dir.isDirectory()) {
            File file[];
            file = dir.listFiles();
            if (file != null) {
                for (int i = 0; i < file.length; i++) {
                    ZipFile zf = new ZipFile(file[i].getPath());
                    Enumeration<? extends ZipEntry> entries = zf.entries();
                    while (entries.hasMoreElements()) {
                        ZipEntry ze = (ZipEntry) entries.nextElement();
                        long size = ze.getSize();
                        if (size > 0 && ze.getName().endsWith(".xml")) {
                            System.out.println("Read " + ze.getName() + "?");
                            Date doDate = DateUtils.parseDate("20"
                                    + getNumber(ze.getName()));
                            int year = doDate.getYear() + 1900;
                            String path = usptoRootPath + "/" + year + "/"
                                    + file[i].getName() + "/" + ze.getName();

                            PatentRawUSPTO
                                    .remove(rawclazz, new QueryHelp("path",
                                            path).filter("pto", pto.toString()));

                            BufferedReader br = new BufferedReader(
                                    new InputStreamReader(zf.getInputStream(ze)));
                            StringBuffer content = new StringBuffer();
                            String line;
                            while ((line = br.readLine()) != null) {
								// 正則匹配結束標籤(結束標籤只有一個)
								String regexTag = "</us-patent-grant>|</us-patent-application>|</patent-application-publication>|</PATDOC>";
								Pattern pattern = Pattern.compile(regexTag);
								Matcher matcher = pattern.matcher(line);
								String matcherTag = null;
								while (matcher.find()) {
									matcherTag = matcher.group();
									System.out.println("匹配標籤 ："
											+ matcher.group());
								}
								// 匹配標籤存在,則對content進行結束處理，否則，content繼續添加line
								if (matcherTag != null) {
									String[] strArray = line.split(matcherTag);
									// strArray.length==2的line情況格式為 "xxxTagxxx"
									// or "Tagxxx"
									if (strArray.length > 0
											&& strArray.length == 2) {
										// 分割數組第一個字串不為空，剛添加 到content
										if (strArray[0].length() != 0) {
											content.append(strArray[0]);
										}
										// 把結束標籤添加 到content
										content.append(matcherTag);

										/** 處理字串 **/
										if (doDate == null) {
											// process special case
											log.error("doDate parse error!");
											return null;
										}
										PatentRawUSPTO raw = new PatentRawUSPTO();
										raw.pto = pto;
										raw.path = path;
										raw.data = new BasicDBObject();
										raw.type = "xml/xml";
										raw.provider = provider;
										raw.doDate = doDate;
										raw.data.put("xml", content.toString());

										raw.save();
										pe.addNum().debug(log, 10000,
												"save: '" + path + "'");
										/** 處理字串結束 **/

										// 處理結束后，將content清空
										content.delete(0, content.length());
										// content添加
										content.append(strArray[1].trim());
									} else {
										// 只有一個標籤b
										content.append(line);
										/** 處理字串 **/
										if (doDate == null) {
											// process special case
											log.error("doDate parse error!");
											return null;
										}
										PatentRawUSPTO raw = new PatentRawUSPTO();
										raw.pto = pto;
										raw.path = path;
										raw.data = new BasicDBObject();
										raw.type = "xml/xml";
										raw.provider = provider;
										raw.doDate = doDate;
										raw.data.put("xml", content.toString());

										raw.save();
										pe.addNum().debug(log, 10000,
												"save: '" + path + "'");
										/** 處理字串結束 **/

										// 處理結束后，將content清空
										content.delete(0, content.length());
									}
								} else {
									content.append(line);
								}
                            }
                            br.close();

                        }
                    }
                    zf.close();
                }
            }
        }
        return this;
    }

    public static String getNumber(String input) {
        char c[] = input.toCharArray();
        String strNumber = "";
        for (int i = 0; i < c.length; i++) {
            if (Character.isDigit(c[i])) {
                strNumber = strNumber + String.valueOf(c[i]).trim();
            }
        }
        return strNumber.trim();
    }
}
