// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JPODImporter.java

package patent.mongoImport;

import com.mongodb.BasicDBObject;
import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawJPO;
import java.io.*;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.*;

// Referenced classes of package patent.mongoImport:
//            JPOImporter

public class JPODImporter
{

    public static void main(String args[])
        throws Exception
    {
        ArgParser argParser = (new ArgParser()).addOpt(JPODImporter.class).parse(args);
        MongoInitUtils.reload(argParser);
        String argPath = argParser.getOptString("jpo.path");
        String argDoPath = argParser.getOptString("do.path");
        provider = argParser.getOptString("provider");
        type = argParser.getOptString("type");
        doDate = argParser.getOptString("doDate");
        System.out.print(type);
        if(log.isDebugEnabled())
            log.debug((new StringBuilder("start, opt: ")).append(argParser.getParsedMap()).toString());
        if(!type.equals("update"))
        {
            if(argDoPath.isEmpty())
                (new JPODImporter(argPath)).importDir();
            else
                (new JPODImporter(argPath)).importDir(new File(argDoPath));
        } else
        {
            (new JPODImporter(argPath)).importUpdateDir(new File(argDoPath));
        }
        log.debug("finish");
    }

    public JPODImporter(String bookpath)
        throws UnknownHostException
    {
        jpopath = new File(bookpath);
        pe = (new ProcessEstimater(0L)).setFormat("%2$d");
    }

    public JPODImporter importDir()
        throws IOException
    {
        return importDir(jpopath);
    }

    public JPODImporter importDir(File dir)
        throws IOException
    {
        if(dir.isDirectory())
        {
            File fileBiblio = dir.toPath().resolve((new StringBuilder(String.valueOf(dir.getName()))).append(".xml").toString()).toFile();
            if(fileBiblio.isFile())
            {
                String path = jpopath.toPath().relativize(dir.toPath()).toString().replaceAll("\\\\", "/");
                Date doDate = DateUtils.parseDate((new StringBuilder(String.valueOf(dir.getParentFile().getParentFile().getName()))).append("/").append(getNumber(dir.getParentFile().getName())).append("/01").toString());
                if(doDate == null)
                {
                    log.error("doDate parse error!");
                    return null;
                }
                PatentRawJPO.remove(rawclazz, (new QueryHelp("path", path)).filter("pto", pto.toString()));
                PatentRawJPO raw = new PatentRawJPO();
                raw.pto = pto;
                raw.path = path;
                raw.data = new BasicDBObject();
                raw.type = "sgm/sgm";
                raw.provider = provider;
                raw.doDate = doDate;
                raw.data.put("sgm", FileUtils.readFileToString(fileBiblio, "UTF-8"));
                raw.save();
                pe.addNum().debug(log, 10000L, (new StringBuilder("save: '")).append(path).append("'").toString());
            } else
            {
                File afile[];
                int j = (afile = dir.listFiles()).length;
                for(int i = 0; i < j; i++)
                {
                    File file = afile[i];
                    if(file.isDirectory())
                        importDir(file);
                }

            }
        }
        return this;
    }

    public void importUpdateDir(File dir)
        throws IOException
    {
        File afile[];
        int j = (afile = dir.listFiles()).length;
        for(int i = 0; i < j; i++)
        {
            File fileBiblio = afile[i];
            if(fileBiblio.isFile())
            {
                String path = jpopath.toPath().relativize(fileBiblio.toPath()).toString().replaceAll("\\\\", "/");
                Date doDate = DateUtils.parseDate(this.doDate);
                if(doDate == null)
                {
                    log.error("doDate parse error!");
                    return;
                }
                PatentRawJPO.remove(rawclazz, (new QueryHelp("path", path)).filter("pto", pto.toString()));
                PatentRawJPO raw = new PatentRawJPO();
                raw.pto = pto;
                raw.path = path;
                raw.data = new BasicDBObject();
                raw.type = "sgm/sgm";
                raw.provider = provider;
                raw.doDate = doDate;
                raw.data.put("sgm", FileUtils.readFileToString(fileBiblio, "EUC-JP"));
                raw.save();
                pe.addNum().debug(log, 10000L, (new StringBuilder("save: '")).append(path).append("'").toString());
            }
        }

    }

    public static String getNumber(String input)
    {
        char c[] = input.toCharArray();
        String strNumber = "";
        for(int i = 0; i < c.length; i++)
            if(Character.isDigit(c[i]))
                strNumber = (new StringBuilder(String.valueOf(strNumber))).append(String.valueOf(c[i]).trim()).toString();

        return strNumber.trim();
    }

    static Log log = LogFactory.getLog(JPODImporter.class);
    private static Class rawclazz = PatentRawJPO.class;
    private static Pto pto;
    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/kangaroo";
    public static final String opt_jpo_path = "jpo.path";
    public static final String opt_jpo_path_default = "";
    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "JPO";
    public static final String opt_type = "type";
    public static final String opt_type_default = "";
    public static final String opt_doDate = "doDate";
    public static final String opt_doDate_default = "";
    public static org.tsaikd.java.utils.ArgParser.Option opts[] = {
        new org.tsaikd.java.utils.ArgParser.Option(null, "mongo", true, "mongodb://10.57.145.82/kangaroo", "mongodb uri, start with mongodb://"), new org.tsaikd.java.utils.ArgParser.Option(null, "jpo.path", true, "", "JPO raw data local path, like /mnt/kangaroo"), new org.tsaikd.java.utils.ArgParser.Option(null, "do.path", true, "", "do JPO raw data local path, keep empty for jpo.path"), new org.tsaikd.java.utils.ArgParser.Option(null, "provider", true, "JPO", "Provider saved to DB"), new org.tsaikd.java.utils.ArgParser.Option(null, "type", true, "", "update?"), new org.tsaikd.java.utils.ArgParser.Option(null, "doDate", true, "", "")
    };
    public static final Class optDep[] = {
     MongoInitUtils.class
    };
    private File jpopath;
    private ProcessEstimater pe;
    private static String provider;
    private static String type;
    private static String doDate;

    static 
    {
        pto = Pto.JPO;
        ConfigUtils.setSearchBase(JPODImporter.class);
    }
}
