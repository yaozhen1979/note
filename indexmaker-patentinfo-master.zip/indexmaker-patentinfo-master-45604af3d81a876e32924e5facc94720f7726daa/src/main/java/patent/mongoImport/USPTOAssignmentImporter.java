package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.AssignmentCountry;
import itec.patent.mongodb.AssignmentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.assignmentraw.AssignmentRawUSPTO;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import patetn.assignment.ZipTool;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoURI;

public class USPTOAssignmentImporter {

    static Log log = LogFactory.getLog(USPTOAssignmentImporter.class);

    private static Class<? extends AssignmentRaw> rawclazz = AssignmentRawUSPTO.class;

    private static AssignmentCountry pto = AssignmentCountry.us;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.60.90.155/AssignmentRawUSPTO";
    public static final String opt_uspto_path = "uspto.path";
    public static final String opt_uspto_path_default = "c:/us/";
    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";
    public static final String usptoRootPath = "PatentAssignment";
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "patents.reedtech.com";
    
    
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default,"mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_uspto_path, true,opt_uspto_path_default,"USPTO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default,"do USPTO raw data local path, keep empty for uspto.path"),
        new ArgParser.Option(null, opt_provider, true,opt_provider_default, "Provider saved to DB"), 
            
    };

    public static final Class<?>[] optDep = {
        MongoAuthInitUtils.class
    };

    public USPTOAssignmentImporter() {

    }
    
    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(USPTOAssignmentImporter.class);
        //MongoInitUtils.nothing();
    }

    private String usptopath;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {
        USPTOAssignmentImporter usptoImporter = new USPTOAssignmentImporter();
        usptoImporter.worker(args);
    }
    
    public static void worker(String[] args) throws Exception{
        ArgParser argParser = new ArgParser().addOpt(USPTOAssignmentImporter.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
//        MongoInitUtils.reload();
        String argMongo = argParser.getOptString(opt_mongo);
        String argDoPath = argParser.getOptString(opt_uspto_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        if (argDoPath.isEmpty()) {
            new USPTOAssignmentImporter(argDoPath, argMongo).importDir();
        } else {
            new USPTOAssignmentImporter(argDoPath, argMongo).importDir(argDoPath);
        }
        log.debug("finish");
    }

    /**
     * @param mongouri
     *            {@link MongoURI}
     */

    
    public USPTOAssignmentImporter(String usptopath,String mongouri){
        this.usptopath = usptopath;
        pe = new ProcessEstimater(0).setFormat("%2$d");
        
    }

    

    public USPTOAssignmentImporter importDir() throws IOException {
        return importDir(usptopath);
    }

    public USPTOAssignmentImporter importDir(String  path) throws IOException {
        File f = new File(path);
        File file[];
        file = f.listFiles();
        if(file!=null){
            

        for (int i = 0; i < file.length; i++) {
            String dir=path+file[i].getName();
            ZipTool zptool = new ZipTool();        
    //        List<String> list = zptool.unzip(dir);
            

            boolean flag = false;
            List<String> list = new ArrayList<String>();
            long num=0;
            String name="";
            try {

                ZipFile zf = new ZipFile(dir);
                Enumeration entries = zf.entries();

                while (entries.hasMoreElements()) {
                    ZipEntry ze = (ZipEntry) entries.nextElement();
                    long size = ze.getSize();
                    if (size > 0 && ze.getName().endsWith(".xml")) {
                        System.out.println("Read " + ze.getName() + "?");
                        BufferedReader br = new BufferedReader(
                                new InputStreamReader(zf.getInputStream(ze)));
                        StringBuffer content = new StringBuffer();
                        name = ze.getName().replace(".xml","");
                        String line;
                        while ((line = br.readLine()) != null) {
                        //    System.out.println(line);
                            if (line.trim().equalsIgnoreCase("<patent-assignment>")) {
                                flag = true;
                                content.append(line.trim());
                            }
                            if (line.trim().equalsIgnoreCase("</patent-assignment>")) {
                                flag = false;
                            }
                            if (flag && !line.trim().equalsIgnoreCase("<patent-assignment>")) {
                                content.append(line.trim());
                            }
                            if(line.trim().equalsIgnoreCase("</patent-assignment>")){
                                content.append(line.trim());
                                list.add(content.toString());
                                content = new StringBuffer();
                            }
                            if(!flag && line.trim().startsWith("<patent-assignment>")){
                                content.append(line.trim());
                                list.add(content.toString());
                                content = new StringBuffer();
                                
                            }
                            if(line.trim().contains("<data-available-code>N</data-available-code>")){
                                AssignmentRawUSPTO raw = new AssignmentRawUSPTO();
                                raw.country = pto;
                                raw.path = file[i].getName();
                                raw.data = new BasicDBObject();
                                raw.type = "xml/xml";
                                raw.size = 0;
                                raw.provider = provider;
                                raw.data.put("xml", "<data-available-code>N</data-available-code>");
                                raw.save();
                                break;
                            }
                            if(list.size()==1000005){
                                imoprt(list,file[i].getName());
                                list.clear();
                            }
                        }
                        
                        imoprt(list,file[i].getName());
                    }
                }
            
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        }
        return this;
    }

    public void imoprt (List<String> list,String name){
        for (String str : list){
            AssignmentRawUSPTO raw = new AssignmentRawUSPTO();
            raw.country = pto;
            raw.path = name;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.size =list.size();
            raw.provider = provider;
            raw.data.put("xml", str);
            raw.save();
            pe.addNum().debug(log, 10000,
                    "save: '" + name + "'");
        }
    }
    
    public static String getNumber(String input) {
        char c[] = input.toCharArray();
        String strNumber = "";
        for (int i = 0; i < c.length; i++) {
            if (Character.isDigit(c[i])) {
                strNumber = strNumber + String.valueOf(c[i]).trim();
            }
        }
        return strNumber.trim();
    }
}
