package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawTIPO;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;


/**
 * @author Genchi
 * import tw data (purchase or download) to level1 mongo db
 */
public class TipoWebImporter {

    static Log log = LogFactory.getLog(TipoWebImporter.class);
    DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    private static Class<? extends PatentRaw> rawclazz = PatentRawTIPO.class;

    private static Pto pto = Pto.TIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/PatentRawTIPO";

    public static final String opt_tipo_path = "tipo.path";
    public static final String opt_tipo_path_default = "\\\\10.153.27.120\\tw_xml\\TIPO 資料\\公告_00000-37036\\iss";

    public static final String opt_do_vol = "do.path";
    public static final String opt_do_vol_default = "";

    public static final String opt_tipo_status = "tipo.status";
    public static final String opt_tipo_status_default = "issued";
    
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "TIPO Purchase";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_tipo_path, true, opt_tipo_path_default, "TIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_vol, true, opt_do_vol_default, "year of TIPO raw data, keep empty for tipo.path"),
        new ArgParser.Option(null, opt_tipo_status, true, opt_tipo_status_default, "issued or published, keep empty for tipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
    };
       public static final Class<?>[] optDep = {
            MongoAuthInitUtils.class
        };

        static {
            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            ConfigUtils.setSearchBase(TipoWebImporter.class);
        }

    private File tipopath;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) {
        try {
            ArgParser argParser = new ArgParser().addOpt(TipoWebImporter.class).parse(args);
            MongoAuthInitUtils.reload(argParser);
            String argPath = argParser.getOptString(opt_tipo_path);
            provider = argParser.getOptString(opt_provider);
    
            if (log.isDebugEnabled()) {
                log.debug("start, opt: " + argParser.getParsedMap());
            }
            new TipoWebImporter(argPath).importDir();
            log.debug("finish");
        } catch (Exception e) {
            Scanner scanner = new Scanner(System.in);
            scanner.next();
            log.debug("press any key to continue...");
            e.printStackTrace();
        }
    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public TipoWebImporter(String tipopath) throws UnknownHostException {
        this.tipopath = new File(tipopath);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    public TipoWebImporter importDir() throws IOException {
        File[] monthDirs = tipopath.listFiles();
        for(File monthDir : monthDirs)
        {
            //File[] dateDirs = monthDir.listFiles();
            //for(File dateDir : dateDirs) {
                importDir(monthDir);
            //}
        }
        return this;
    }

    public TipoWebImporter importDir(File dir) throws IOException {
        //if (dir.isDirectory()) {
            //File[] filesBiblio = dir.listFiles();
            //for (File fileBiblio : filesBiblio) {
                String absolutePath = dir.toPath().toString();
                String path = absolutePath.substring(absolutePath.toLowerCase().indexOf("tipo_web_claim") + "tipo_web_claim".length() + 1).replaceAll("\\\\", "/");
                Date doDate =  DateUtils.parseDate(dir.getParentFile().getParentFile().getParentFile().getName() + "/" + dir.getParentFile().getParentFile().getName() + "/" + dir.getParentFile().getName());
                if(doDate != null)
                {
                    PatentRawTIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
                    PatentRawTIPO raw = new PatentRawTIPO();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    raw.type = "text/text";
                    raw.provider = provider;
                    raw.doDate = doDate;
                    raw.data.put("text", FileUtils.readFileToString(dir, "BIG5"));
                    raw.save();
                    pe.addNum().debug(log, 10000, "save: '" + path + "'");
                }
            //}
        //}
        return this;
    }

}
