package patent.mongoImport;

import com.mongodb.BasicDBObject;
import itec.patent.common.DateUtils;
import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawJPO;
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.*;

public class JPOImporter
{

    public static void main(String args[])
        throws Exception
    {
        ArgParser argParser = (new ArgParser()).addOpt(JPOImporter.class).parse(args);
        MongoInitUtils.reload(argParser);
        String argPath = argParser.getOptString("jpo.path");
        String argDoPath = argParser.getOptString("do.path");
        date = argParser.getOptString("doDate");
        provider = "JPO";
        type = argParser.getOptString("type");
        if(log.isDebugEnabled())
            log.debug((new StringBuilder("start, opt: ")).append(argParser.getParsedMap()).toString());
        if(!type.equals("update"))
        {
            if(argDoPath.isEmpty())
                (new JPOImporter(argPath)).importDir();
            else
                (new JPOImporter(argPath)).importDir(new File(argDoPath));
        } else
        {
            (new JPOImporter(argPath)).importUpdateDir(new File(argDoPath));
        }
        log.debug("finish");
    }

    public JPOImporter(String bookpath)
        throws UnknownHostException
    {
        jpopath = new File(bookpath);
        pe = (new ProcessEstimater(0L)).setFormat("%2$d");
    }

    public JPOImporter importDir()
        throws IOException
    {
        return importDir(jpopath);
    }

    public JPOImporter importDir(File dir)
        throws IOException
    {
        if(dir.isDirectory())
        {
            File fileBiblio = dir.toPath().resolve((new StringBuilder(String.valueOf(dir.getName()))).append(".xml").toString()).toFile();
            if(fileBiblio.isFile())
            {
                String path = jpopath.toPath().relativize(dir.toPath()).toString().replaceAll("\\\\", "/");
                Date doDate = DateUtils.parseDate((new StringBuilder(String.valueOf(dir.getParentFile().getParentFile().getName()))).append("/").append(getNumber(dir.getParentFile().getName())).append("/01").toString());
                if(doDate == null)
                {
                    log.error("doDate parse error!");
                    return null;
                }
                PatentRawJPO.remove(rawclazz, (new QueryHelp("path", path)).filter("pto", pto.toString()));
                PatentRawJPO raw = new PatentRawJPO();
                raw.pto = pto;
                raw.path = path;
                raw.data = new BasicDBObject();
                raw.type = "xml/xml";
                raw.provider = provider;
                raw.doDate = doDate;
                raw.data.put("xml", FileUtils.readFileToString(fileBiblio, "UTF-8"));
                raw.save();
                pe.addNum().debug(log, 10000L, (new StringBuilder("save: '")).append(path).append("'").toString());
            } else
            {
                File afile[];
                int j = (afile = dir.listFiles()).length;
                for(int i = 0; i < j; i++)
                {
                    File file = afile[i];
                    if(file.isDirectory())
                        importDir(file);
                }

            }
        }
        return this;
    }

    public void importUpdateDir(File dir)
        throws IOException
    {
        List list = getFilePath(dir);
        for(Iterator iterator = list.iterator(); iterator.hasNext();)
        {
            File file = (File)iterator.next();
            File afile[];
            int j = (afile = file.listFiles()).length;
            for(int i = 0; i < j; i++)
            {
                File fileBiblio = afile[i];
                if(fileBiblio.isFile())
                {
                    String path = jpopath.toPath().relativize(fileBiblio.toPath()).toString().replaceAll("\\\\", "/");
                    Date doDate = DateUtils.parseDate(date);
                    if(doDate == null)
                    {
                        log.error("doDate parse error!");
                        return;
                    }
                    PatentRawJPO.remove(rawclazz, (new QueryHelp("path", path)).filter("pto", pto.toString()));
                    PatentRawJPO raw = new PatentRawJPO();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    raw.type = "xml/xml";
                    raw.provider = provider;
                    raw.doDate = doDate;
                    raw.data.put("xml", FileUtils.readFileToString(fileBiblio, "EUC-JP"));
                    raw.save();
                    pe.addNum().debug(log, 10000L, (new StringBuilder("save: '")).append(path).append("'").toString());
                }
            }

        }

    }

    public static String getNumber(String input)
    {
        char c[] = input.toCharArray();
        String strNumber = "";
        for(int i = 0; i < c.length; i++)
            if(Character.isDigit(c[i]))
                strNumber = (new StringBuilder(String.valueOf(strNumber))).append(String.valueOf(c[i]).trim()).toString();

        return strNumber.trim();
    }

    public List getFilePath(File dir)
    {
        List path = new ArrayList();
        if(dir.getPath().contains("P1"))
        {
            String fileA = (new StringBuilder(String.valueOf(dir.getPath()))).append(File.separator).append("A").toString();
            String fileT = (new StringBuilder(String.valueOf(dir.getPath()))).append(File.separator).append("T").toString();
            File a = new File(fileA);
            File b = new File(fileT);
            if(a.isDirectory())
            {
                File afile2[];
                int k1 = (afile2 = a.listFiles()).length;
                for(int i1 = 0; i1 < k1; i1++)
                {
                    File file = afile2[i1];
                    if(file.getPath().contains("XML"))
                        path.add(file);
                }

            }
            if(b.isDirectory())
            {
                File afile3[];
                int l1 = (afile3 = a.listFiles()).length;
                for(int j1 = 0; j1 < l1; j1++)
                {
                    File file = afile3[j1];
                    if(file.getPath().contains("XML"))
                        path.add(file);
                }

            }
        } else
        if(dir.getPath().contains("P2"))
        {
            String fileB = (new StringBuilder(String.valueOf(dir.getPath()))).append(File.separator).append("B9").toString();
            File a = new File(fileB);
            if(a.isDirectory())
            {
                File afile[];
                int k = (afile = a.listFiles()).length;
                for(int i = 0; i < k; i++)
                {
                    File file = afile[i];
                    if(file.getPath().contains("XML"))
                        path.add(file);
                }

            }
        } else
        if(dir.getPath().contains("U3"))
        {
            String fileU = (new StringBuilder(String.valueOf(dir.getPath()))).append(File.separator).append("U9").toString();
            File a = new File(fileU);
            if(a.isDirectory())
            {
                File afile1[];
                int l = (afile1 = a.listFiles()).length;
                for(int j = 0; j < l; j++)
                {
                    File file = afile1[j];
                    if(file.getPath().contains("XML"))
                        path.add(file);
                }

            }
        }
        return path;
    }

    static Log log = LogFactory.getLog(JPOImporter.class);
    private static Class rawclazz = PatentRawJPO.class;
    private static Pto pto;
    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/kangaroo";
    public static final String opt_jpo_path = "jpo.path";
    public static final String opt_jpo_path_default = "";
    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";
    public static final String opt_doDate = "doDate";
    public static final String opt_doDate_default = "";
    public static final String opt_type = "type";
    public static final String opt_type_default = "";
    public static org.tsaikd.java.utils.ArgParser.Option opts[] = {
        new org.tsaikd.java.utils.ArgParser.Option(null, "mongo", true, "mongodb://10.57.145.82/kangaroo", "mongodb uri, start with mongodb://"), new org.tsaikd.java.utils.ArgParser.Option(null, "jpo.path", true, "", "JPO raw data local path, like /mnt/kangaroo"), new org.tsaikd.java.utils.ArgParser.Option(null, "do.path", true, "", "do JPO raw data local path, keep empty for jpo.path"), new org.tsaikd.java.utils.ArgParser.Option(null, "doDate", true, "", ""), new org.tsaikd.java.utils.ArgParser.Option(null, "type", true, "", "update?")
    };
    public static final Class optDep[] = {
      MongoInitUtils.class
    };
    private File jpopath;
    private ProcessEstimater pe;
    private static String provider;
    private static String type;
    private static String date;

    static 
    {
        pto = Pto.JPO;
        ConfigUtils.setSearchBase(JPOImporter.class);
    }
}
