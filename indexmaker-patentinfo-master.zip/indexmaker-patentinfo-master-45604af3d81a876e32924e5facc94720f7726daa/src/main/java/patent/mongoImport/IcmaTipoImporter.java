package patent.mongoImport;

import itec.patent.common.MongoInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawTIPO;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.ReadPreference;

/**
 * @author Genchi
 * import tw data (from icma) to level1 mongo db
 */
public class IcmaTipoImporter {

    static Log log = LogFactory.getLog(IcmaTipoImporter.class);
    DateFormat df = new SimpleDateFormat("yyyy");
    private static Class<? extends PatentRaw> rawclazz = PatentRawTIPO.class;

    private static Pto pto = Pto.TIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.82/PatentRawTIPO";

    public static final String opt_tipo_path = "tipo.path";
    public static final String opt_tipo_path_default = "\\\\10.153.24.169\\h$\\patentinfo\\TW";

    public static final String opt_do_path = "do.path";
    public static final String opt_do_path_default = "";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "";
    
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "ICMA";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_tipo_path, true, opt_tipo_path_default, "ICMA TIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default, "year of TIPO raw data, keep empty for tipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "start do date"),
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(IcmaTipoImporter.class);
        MongoInitUtils.nothing();
    }

    private File tipopath;

    private MongoClientURI mongouri;

    private MongoClient mongo;

    private DB mongodb;

    private ProcessEstimater pe;

    private static String provider;

    public static void main(String[] args) throws Exception {        
        ArgParser argParser = new ArgParser().addOpt(IcmaTipoImporter.class).parse(args);

        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_tipo_path);
        String argDoPath = argParser.getOptString(opt_do_path);
        String argStartDoPath = argParser.getOptString(opt_start_path);
        provider = argParser.getOptString(opt_provider);

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
        new IcmaTipoImporter(argPath, argMongo).importDir(argDoPath, argStartDoPath);
        log.debug("finish");
    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public IcmaTipoImporter(String tipopath, String mongouri) throws UnknownHostException {
        this.tipopath = new File(tipopath);
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());

        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    public IcmaTipoImporter importDir(String argDoPath, String argStartDoPath) throws IOException {
        if(argDoPath.isEmpty())
        {
            File[] dirs = tipopath.listFiles();
            for(File dir:dirs)
            {
                if(argStartDoPath.isEmpty() || 
                        (!argStartDoPath.isEmpty() && Integer.parseInt(dir.getName()) >= Integer.parseInt(argStartDoPath)))
                {
                    importDir(dir);
                }
            }
        }
        else
        {
            File dir = tipopath.toPath().resolve(argDoPath).toFile();
            if(dir.isDirectory())
            {
                importDir(dir);
            }
        }
        return this;
    }

    public IcmaTipoImporter importDir(File dir) throws IOException {
        if (dir.isDirectory()) {
            File[] patentDirs = dir.listFiles();
            for (File patentDir : patentDirs) {
                if(patentDir.isDirectory())
                {
                    File xmlFile = patentDir.toPath().resolve(patentDir.getName() + ".xml").toFile();
                    if(xmlFile.isFile())
                    {
                        String path = dir.getParentFile().toPath().relativize(patentDir.toPath()).toString().replaceAll("\\\\", "/");
                        Date doDate = null;
                        try {
                            doDate = df.parse(dir.getName().substring(0,4));
                        } catch (ParseException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        if(doDate != null)
                        {
                            PatentRawTIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
                            PatentRawTIPO raw = new PatentRawTIPO();
                            raw.pto = pto;
                            raw.path = path;
                            raw.data = new BasicDBObject();
                            raw.type = "xml/xml";
                            raw.provider = provider;
                            raw.doDate = doDate;
                            raw.data.put("xml", FileUtils.readFileToString(xmlFile, "UTF-8"));
                            raw.save();
                            pe.addNum().debug(log, 10000, "save: '" + path + "'");
                        }
                    }
                }
            }
        }
        return this;
    }

}
