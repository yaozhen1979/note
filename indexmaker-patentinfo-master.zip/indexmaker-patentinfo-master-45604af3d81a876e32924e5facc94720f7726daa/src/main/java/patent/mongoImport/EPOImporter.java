package patent.mongoImport;

import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawEPO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;



public class EPOImporter {

    static Log log = LogFactory.getLog(EPOImporter.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawEPO.class;

    private static Pto pto = Pto.EPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.105/PatentRawEPO";

//    //從TXT導入
//    public static final String opt_epo_path = "epo.path";
//    public static final String opt_epo_path_default = "\\\\10.153.27.94\\ep_xml_zip\\MongoDB_EP_List\\2012.txt";
//    public static final String doDate = "2012";//special for epo need change everyyear   88-89
    //讀取文件
    public static final String opt_epo_path = "epo.path";
//    public static final String opt_epo_path_default = "\\\\10.153.27.94\\MongoDB_xml_path\\1978\\1978A";
    public static final String opt_epo_path_default = "E:\\MongoDB_xml_path\\2013\\2013(50AB)";
    public static final String doDate = "20131211";//special for epo need change everyyear
    //文件起始 
    public static final String startFileName = "DOC";//2006年之後是DOC        
    //文件结束
    public static final String endFileName = "xml";
    
    public static final String opt_do_time = "do.path";
    public static final String opt_do_time_default = "";
    
    public static final String opt_do_path = "start.path";
    public static final String opt_do_path_default = "00000000";

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "EPO Download";//~~---2010 Purchase 2011---~~now netDownload
    

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_epo_path, true, opt_epo_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_time, true, opt_do_time_default, "year or date of KIPO raw data, keep empty for kipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
        new ArgParser.Option(null, opt_do_path, true, opt_do_path_default, "start do date"),
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(EPOImporter.class);
        //MongoInitUtils.nothing();
    }

    private MongoClientURI mongouri;
    private MongoClient mongo;
    private DB mongodb;
    private ProcessEstimater pe;
    private static String provider;
    private DateFormat df = new SimpleDateFormat("yyyyMMdd");
    private static List<String> fileNames = new ArrayList<String>();
    
    
    public static void main(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(EPOImporter.class).parse(args);    
        String argMongo = argParser.getOptString(opt_mongo);
        String argPath = argParser.getOptString(opt_epo_path);
        provider = argParser.getOptString(opt_provider);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }
//        new EPOImporter(argPath, argMongo).importDir(argPath);//從TXT導入
//        new EPOImporter(argPath, argMongo).importDir(new File(argPath));//讀取文件
        new EPOImporter(argPath, argMongo).importDir(argPath, startFileName, endFileName);
        log.debug("finish");
        
    }
    
    

    /**
     * @param epoPath
     * @param mongouri
     * @throws UnknownHostException
     */
    public EPOImporter(String epoPath, String mongouri) throws UnknownHostException {
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());
        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    
    private void importDir(String dir) throws ParseException, IOException {
        List<String> fileNames =  read(dir);
        for (Iterator<String> iterator = fileNames.iterator(); iterator.hasNext();) {
            String filePath = (String) iterator.next();
            String path = filePath.substring(filePath.indexOf("path") + "path\\".length() , filePath.lastIndexOf("\\"));
            path = path.replace('\\', '/');
            PatentRawEPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            Date date = df.parse(doDate);
            //刪除整年
//            PatentRawEPO.remove(rawclazz, new QueryHelp("doDate", date).filter("pto", pto.toString()));
            PatentRawEPO raw = new PatentRawEPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;//2010 before Purchase
            raw.doDate = date;
            raw.data.put("xml", FileUtils.readFileToString(new File(filePath), "UTF-8"));
            try
            {
                raw.save();
            }
            catch (Exception e)
            {
                log.info("save raw data err : " + filePath);
                throw e;
            }
            pe.addNum().debug(log, 10000,
                    "save: '" + path + "'");
            }
        }

    
    /**
     * @param dir
     * @param startFileName
     * @param endFileName
     * @throws IOException
     * @throws ParseException 
     */
    public void importDir(String dir, String startFileName, String endFileName) throws IOException, ParseException
    {
        List<String> fileListNames = getFilePathList(dir, startFileName, endFileName);
        for(Iterator<String> it = fileListNames.iterator(); it.hasNext(); ) {
            importDir(new File(it.next()));
        }
    }
    
    /**
     * 导入指定文件中的所有文件
     * @param dir
     * @throws IOException
     * @throws ParseException 
     */
    public void importDir(File dir) throws IOException, ParseException
    {
        if(dir.isDirectory())
        {
            for(File subDir : dir.listFiles()) {
                importDir(subDir);
            }
        }
        else
        {
            String filePath = dir.toPath().toString();
            String path = filePath.substring(filePath.indexOf("path") + "path\\".length() , filePath.lastIndexOf("\\"));
            path = path.replace('\\', '/');
            Date date = df.parse(doDate);
            PatentRawEPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
            PatentRawEPO raw = new PatentRawEPO();
            raw.pto = pto;
            raw.path = path;
            raw.data = new BasicDBObject();
            raw.type = "xml/xml";
            raw.provider = provider;
            raw.doDate = date;
            raw.data.put("xml", FileUtils.readFileToString(dir, "UTF-8"));
            raw.save();
            pe.addNum().debug(log, 10000, "save: '" + path + "'");
        }
    }
    
    /**
     * 讀取TXT文件
     * @param dir
     * @return
     */
    private List<String> read(String dir) {
        List<String> list = new ArrayList<String>();
        int bufferSize = 20*1024*1024;
        FileInputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try 
        {
            File file = new File(dir);
            is = new FileInputStream(file);
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr,bufferSize);
            String line = "";
            while((line = br.readLine()) != null) 
            {
                list.add(line.trim());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try{
                is.close();
                isr.close();
                br.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return list;
    }
    
    
    /**
     * 獲取指定文件夾下的所有XML文件
     * @param root
     * @return fileNames
     */
    public static List<String> getFilePathList(String root, String startWith, String endWith) {
        
        try {
            File file = new File(root);
            if (file.isDirectory()) {
                File[] fileList = file.listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileList[i].isDirectory()) {
                        getFilePathList(fileList[i].getPath(), startWith ,endWith);
                    } else {
                        if (fileList[i].getName().startsWith(startWith) && fileList[i].getName().endsWith(endWith)) {
                            fileNames.add(fileList[i].getPath());
                        }
                    }
                }
            } else {
                if (file.getName().startsWith(startWith) && file.getName().endsWith(endWith) ) {
                    fileNames.add(file.getPath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return fileNames;
    }
    
}
