package patent.mongoImport;

import itec.patent.common.DateUtils;
import itec.patent.mongodb.InterPatentClass;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.embed.MongoSyncFlag;
import itec.patent.mongodb.embed.MultiLangString;
import itec.patent.mongodb.embed.Person;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.MongoObjectObjId;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.mongodb.annotations.IndexEntity;
import org.tsaikd.java.mongodb.annotations.IndexField;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.ReadPreference;

@Deprecated
public class CniprParser {

    static Log log = LogFactory.getLog(CniprParser.class);

    private File bookpath;

    private MongoClientURI mongouri;

    private MongoClient mongo;

    private DB mongodb;

    @IndexEntity(fields = {
        @IndexField(name = "msg"),
        @IndexField(name = "doDate"),
    })
    public class ErrorParseCNIPR extends MongoObjectObjId {

        public String msg;

        public String arg1;

        public String path;

        public Date doDate = new Date();

        public ErrorParseCNIPR(String msg, File path) {
            this.msg = msg;
            this.path = bookpath.toPath().relativize(path.toPath()).toString();
            save();
        }

        public ErrorParseCNIPR(String msg, String arg1, File path) {
            this.msg = msg;
            this.arg1 = arg1;
            this.path = bookpath.toPath().relativize(path.toPath()).toString();
            save();
        }

    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public CniprParser(String bookpath, String mongouri) throws UnknownHostException {
        this.bookpath = new File(bookpath);
        this.mongouri = new MongoClientURI(mongouri);
        this.mongo = new MongoClient(this.mongouri);
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());

        MappedClass.getMappedClass(PatentInfoCNIPR.class).setDB(mongodb);
    }

    public CniprParser parse() {
        return parseDir(bookpath);
    }

    public CniprParser parseDir(File dir) {
        if (dir.isDirectory()) {
            File fileBiblio = dir.toPath().resolve("bibliography.html").toFile();
            if (fileBiblio.exists()) {
                parseBiblio(fileBiblio);
            } else {
                for (File file : dir.listFiles()) {
                    if (file.isDirectory()) {
                        parseDir(file);
                    }
                }
            }
        }
        return this;
    }

    @SuppressWarnings("serial")
    private static Map<String, String> mapCniprPatentType = new HashMap<String, String>() {{
        put("FM", "发明专利");        // 公開
        put("SD", "发明专利");        // 公告
        put("SQ", "发明专利");        // 公告
        put("XX", "实用新型");        // 公告
        put("XK", "实用新型");        // 公告
        put("WG", "外观专利");        // 公告
    }};
    public CniprParser parseBiblio(File fileBiblio) {
        if (fileBiblio.isFile()) {
            File dir = fileBiblio.getParentFile();
            File fileClaim = dir.toPath().resolve("claim.xml").toFile();
            File fileDesc = dir.toPath().resolve("description.xml").toFile();
            PatentInfo2 info;
            Pattern pat;
            Matcher mat;

            String cniprTypeName = dir.getParentFile().getParentFile().getParentFile().getName().toUpperCase();
            if (!mapCniprPatentType.containsKey(cniprTypeName)) {
                new ErrorParseCNIPR("invalid patent type", fileBiblio);
                return this;
            }

            String patentNumber = dir.getName();
            int stat = cniprTypeName.equals("FM") ? 1 : 2;
            String biblio;
            try {
                biblio = FileUtils.readFileToString(fileBiblio, "UTF-8");
            } catch (IOException e) {
                new ErrorParseCNIPR("read biblio failed", fileBiblio);
                return this;
            }

            // patentNumber == appNumber
            pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"an\"\\s+value=\"(cn)?([^\"]+)\">");
            mat = pat.matcher(biblio);
            if (!mat.find()) {
                new ErrorParseCNIPR("no appNumber", fileBiblio);
                return this;
            } else {
                String raw = mat.group(2).trim();
                if (!raw.equals(patentNumber)) {
                    new ErrorParseCNIPR("mismatch appNumber", fileBiblio);
                    return this;
                }
            }

            info = PatentInfo2.findPN(Pto.CNIPR, patentNumber, stat);
            if (info == null) {
                info = PatentInfo2.newInfo(Pto.CNIPR);
                info.patentNumber = patentNumber;
                info.stat = stat;
                info.mongoSyncFlag = new MongoSyncFlag();
                info.mongoSyncFlag.init = new Date();
            }

            QueryHelp update = new QueryHelp();

            try {
                // appNumber == patentNumber
                updateField(info, update, "appNumber", patentNumber);

                // applicationDate
                pat = Pattern.compile("(?i)<span id=\"appDate\">(.+?)</span>");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replace(".", "-").trim();
                    Date draw = DateUtils.parseDate(raw);
                    updateField(info, update, "appDate", draw);
                }

                // openNumber, decisionNumber, kindcode
                pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"pn\"\\s+value=\"([^\"]+?)(\\D+)?\">");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).trim();
                    if (stat == 1) {
                        updateField(info, update, "openNumber", raw);
                        updateField(info, update, "decisionNumber", null);
                    } else {
                        updateField(info, update, "openNumber", null);
                        updateField(info, update, "decisionNumber", raw);
                    }

                    raw = mat.group(2).trim();
                    updateField(info, update, "kindcode", raw);
                }

                // openDate, decisionDate
                pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"pd\"\\s+value=\"([^\"]+)\">");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replace(".", "-").trim();
                    Date draw = DateUtils.parseDate(raw);
                    if (stat == 1) {
                        updateField(info, update, "openDate", draw);
                        updateField(info, update, "decisionDate", null);
                    } else {
                        updateField(info, update, "openDate", null);
                        updateField(info, update, "decisionDate", draw);
                    }
                }

                // mainIPC
                pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"strIPC\"\\s+value=\"([^\"]+)\">");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replaceAll("\\(.+?\\).*", "").trim();
                    List<String> pc = InterPatentClass.normalize(raw);
                    updateField(info, update, "mainIPC", pc.get(0));
                }

                // ipcs
                pat = Pattern.compile("(?i)\\b分类号:\\s*</td>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    raw = raw.replaceAll("\\(.+?\\)\\D+", "").trim();
                    String[] raws = raw.split("[;；]");
                    ArrayList<String> pcs = new ArrayList<>();
                    for (int i=0 ; i<raws.length ; i++) {
                        raw = raws[i];
                        if (raw.isEmpty() || raw.startsWith("//")) {
                            continue;
                        }
                        List<String> pc = InterPatentClass.normalize(raw);
                        pcs.add(pc.get(0));
                    }
                    updateField(info, update, "ipcs", pcs);
                }

                // assignees
                ArrayList<Person> persons = new ArrayList<>();
                pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"strANN\"\\s+value=\"([^\"]+)\">");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    String[] raws = raw.split("[;；]");
                    for (int i=0 ; i<raws.length ; i++) {
                        raw = raws[i].trim();
                        if (raw.isEmpty()) {
                            continue;
                        }
                        Person person = new Person();
                        person.name = new MultiLangString();
                        person.name.origin = raw;
                        persons.add(person);
                    }
                }
                // assignees address
                pat = Pattern.compile("(?i)\\b地址:\\s*</td>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (!persons.isEmpty() && mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    String[] raws = raw.split("[;；]");
                    if (raws.length > 1) {
                        if (persons.size() > 1) {
                            new ErrorParseCNIPR("assignee address count > 1", fileBiblio);
                            return this;
                        }
                    }
                    raw = raws[0].trim();
                    if (!raw.isEmpty()) {
                        persons.get(0).address = new MultiLangString();
                        persons.get(0).address.origin = raw;
                    }
                }
                // assignees country
                pat = Pattern.compile("(?i)\\b国省代码:\\s*</td>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (!persons.isEmpty() && mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    if (!raw.isEmpty()) {
                        String[] raws = raw.split("[;；]");
                        if (raws.length != 2) {
                            if (raws.length == 1 && raws[0].equalsIgnoreCase("待定")) {
                                raws = new String[] {"", "待定"};
                            } else {
                                new ErrorParseCNIPR("assignee country count != 2", fileBiblio);
                            }
                        }
                        raw = raws[1].trim();
                        if (!raw.isEmpty()) {
                            persons.get(0).country = new MultiLangString();
                            if (raw.matches("^\\d+$")) {
                                persons.get(0).country.origin = "CN";
                            } else {
                                persons.get(0).country.origin = raw.toUpperCase();
                            }
                        }
                    }
                }
                updateField(info, update, "assignees", persons);

                // inventors
                persons = new ArrayList<>();
                pat = Pattern.compile("(?i)发明（设计）人:\\s*</td>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    String[] raws = raw.split("[;；]");
                    for (int i=0 ; i<raws.length ; i++) {
                        raw = raws[i].trim();
                        if (raw.isEmpty()) {
                            continue;
                        }
                        Person person = new Person();
                        person.name = new MultiLangString();
                        person.name.origin = raw;
                        persons.add(person);
                    }
                    updateField(info, update, "inventors", persons);
                }

                // agent
                persons = new ArrayList<>();
                pat = Pattern.compile("(?i)专利代理机构:\\s*</td>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).replaceAll("&nbsp;", "").trim();
                    if (!raw.isEmpty()) {
                        Person person = new Person();
                        person.name = new MultiLangString();
                        person.name.origin = raw;
                        persons.add(person);
                    }
                    updateField(info, update, "agents", persons);
                }

                // filePageNumber ... etc
                pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"strPage\"\\s+value=\"(\\d+)\">");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    int filePageNumber = Integer.parseInt(mat.group(1));
                    int filePageFirst = 1;
                    int filePageClaim = filePageFirst + 1;

                    pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"CLM_Page\"\\s+value=\"(\\d+)\">");
                    mat = pat.matcher(biblio);
                    if (mat.find()) {
                        int filePageDesc = filePageClaim + Integer.parseInt(mat.group(1));

                        pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"DES_Page\"\\s+value=\"(\\d+)\">");
                        mat = pat.matcher(biblio);
                        if (mat.find()) {
                            int filePageFig = filePageDesc + Integer.parseInt(mat.group(1));
                            int totalPage = filePageFig - 1;

                            pat = Pattern.compile("(?i)<input\\s+type=\"hidden\"\\s+name=\"DRA_Page\"\\s+value=\"(\\d+)\">");
                            mat = pat.matcher(biblio);
                            if (mat.find()) {
                                totalPage = filePageFig + Integer.parseInt(mat.group(1)) - 1;
                            } else {
                                filePageFig = -1;
                            }

                            if (filePageNumber != totalPage) {
                                log.warn("filePage total not match: CN " + patentNumber + " , diff: " + (filePageNumber - totalPage));
                                filePageNumber = totalPage;
                            }
                            updateField(info, update, "filePageDesc", filePageDesc);
                        } else {
                            filePageDesc = -1;
                            log.warn("no DES_Page found: CN " + patentNumber);
                        }
                        updateField(info, update, "filePageClaim", filePageClaim);
                    } else {
                        filePageClaim = -1;
                        log.warn("no CLM_Page found: CN " + patentNumber);
                    }
                    updateField(info, update, "filePageNumber", filePageNumber);
                } else {
                    log.warn("no strPage found: CN " + patentNumber);
                }

                // brief
                pat = Pattern.compile("(?i)摘要:\\s*</td>\\s*</tr>\\s*<tr[^>]*>\\s*<td[^>]*>\\s*</td>\\s*</tr>\\s*<tr[^>]*>\\s*<td[^>]*>\\s*(.*?)\\s*</td>");
                mat = pat.matcher(biblio);
                if (mat.find()) {
                    String raw = mat.group(1).trim();
                    if (!raw.isEmpty()) {
                        MultiLangString mls = new MultiLangString();
                        mls.origin = raw;
                        updateField(info, update, "brief", mls);
                    }
                }

                // fileClaim
                if (fileClaim.exists()) {
                    String claimdata;
                    try {
                        claimdata = FileUtils.readFileToString(fileClaim, "UTF-8");
                    } catch (IOException e) {
                        new ErrorParseCNIPR("read claim failed", fileClaim);
                        return this;
                    }

                    // claim
                    pat = Pattern.compile("(?i)<claims>\\s*(<claim[^>]*>.*</claim>)\\s*</claims>");
                    mat = pat.matcher(claimdata);
                    if (mat.find()) {
                        String raw = mat.group(1).trim();
                        if (!raw.isEmpty()) {
                            MultiLangString mls = new MultiLangString();
                            mls.origin = raw;
                            updateField(info, update, "claim", mls);
                        }
                    }
                }

                // fileDescription
                if (fileDesc.exists()) {
                    String descdata;
                    try {
                        descdata = FileUtils.readFileToString(fileDesc, "UTF-8");
                    } catch (IOException e) {
                        new ErrorParseCNIPR("read description failed", fileDesc);
                        return this;
                    }

                    // description
                    pat = Pattern.compile("(?i)(<description><cn-patent-document><application-body>)?<description>\\s*(.*)\\s*</description>(</application-body></cn-patent-document></description>)?");
                    mat = pat.matcher(descdata);
                    if (mat.find()) {
                        String raw = mat.group(2).trim();
                        if (!raw.isEmpty()) {
                            MultiLangString mls = new MultiLangString();
                            mls.origin = raw;
                            updateField(info, update, "description", mls);
                        }
                    }
                }

            } catch (IllegalArgumentException | IllegalAccessException
                    | NoSuchFieldException | SecurityException e) {
                new ErrorParseCNIPR("updateField failed", e.getMessage(), fileBiblio);
                return this;
            }

            // save to DB
            if (info.id == null) {
                info.mongoSyncFlag.last = new Date();
                info.save();
            } else if (!update.isEmpty()) {
                info.setField(update);
            }
        }
        return this;
    }

    private void updateField(PatentInfo2 info, QueryHelp update, String key, Object value) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
        Field field = PatentInfo2.class.getField(key);
        Object old = field.get(info);
        if (old == null) {
            if (value != null) {
                field.set(info, value);
                update.filterSetSmart(key, value);
            }
        } else {
            if (!old.equals(value)) {
                field.set(info, value);
                update.filterSetSmart(key, value);
            }
        }
    }

}
