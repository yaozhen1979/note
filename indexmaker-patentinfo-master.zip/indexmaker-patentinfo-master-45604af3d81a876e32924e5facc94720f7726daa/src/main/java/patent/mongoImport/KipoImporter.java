package patent.mongoImport;

import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawKIPO;

import java.io.File;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.ReadPreference;

/**
 * @author luken
 * import kr data (purchase or download) to level1 mongo db
 */
public class KipoImporter {

    static Log log = LogFactory.getLog(KipoImporter.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawKIPO.class;

    private static Pto pto = Pto.KIPO;

    public static final String opt_mongo = "mongo";
    public static final String opt_mongo_default = "mongodb://10.57.145.105/PatentRawKIPO";

    public static final String opt_kipo_path = "kipo.path";
    //public static final String opt_kipo_path_default = "\\\\10.153.27.10\\kr2\\pat&utl\\2012";
    public static final String opt_kipo_path_default = "E:\\pat&u";
    
    public static final String opt_do_time = "do.path";
    public static final String opt_do_time_default = "";
    
    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "00000000";

    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "KIPO Purchase";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongo, true, opt_mongo_default, "mongodb uri, start with mongodb://"),
        new ArgParser.Option(null, opt_kipo_path, true, opt_kipo_path_default, "KIPO raw data local path, like /mnt/kangaroo"),
        new ArgParser.Option(null, opt_do_time, true, opt_do_time_default, "year or date of KIPO raw data, keep empty for kipo.path"),
        new ArgParser.Option(null, opt_provider, true, opt_provider_default, "Provider saved to DB"),
        new ArgParser.Option(null, opt_start_path, true, opt_start_path_default, "start do date"),
    };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(KipoImporter.class);
        //MongoInitUtils.nothing();
    }

    private File kipopath;

    private MongoClientURI mongouri;

    private MongoClient mongo;

    private DB mongodb;

    private ProcessEstimater pe;

    private static String provider;

    private static Pattern yearPattern = Pattern.compile("(\\d{4}?)");
     
    private SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
    public static void main(String[] args){
        ArgParser argParser;
        try {
            argParser = new ArgParser().addOpt(KipoImporter.class).parse(args);
            String argMongo = argParser.getOptString(opt_mongo);
            String argPath = argParser.getOptString(opt_kipo_path);
            String argDoTime = argParser.getOptString(opt_do_time);
            String argStartPath = argParser.getOptString(opt_start_path);
            provider = argParser.getOptString(opt_provider);

            if (log.isDebugEnabled()) {
                log.debug("start, opt: " + argParser.getParsedMap());
            }
            new KipoImporter(argPath, argMongo).importDir(argDoTime, argStartPath);
            log.debug("finish");
        } catch (org.apache.commons.cli.ParseException e) {
            System.out.println(e.getMessage());
        }    
        
    }

    /**
     * @param mongouri {@link MongoURI}
     */
    public KipoImporter(String kipopath, String mongouri){
        this.kipopath = new File(kipopath);
        this.mongouri = new MongoClientURI(mongouri);
        try {
            this.mongo = new MongoClient(this.mongouri);
        } catch (UnknownHostException e) {
            System.out.println(e.getMessage());
        }
        this.mongo.setReadPreference(ReadPreference.nearest());
        this.mongodb = this.mongo.getDB(this.mongouri.getDatabase());

        MappedClass.getMappedClass(rawclazz).setDB(mongodb);
        pe = new ProcessEstimater(0).setFormat("%2$d");
    }
    
    public KipoImporter importDir(String argDoTime, String argStartPath) 
    {
        String year = "";
        String date = "";
        if(!argDoTime.isEmpty())
        {
            if(argDoTime.length() > 4)
            {
                year = argDoTime.substring(0, 4);
                date = argDoTime;
            }
            else
            {
                year = argDoTime;    
            }
        }
        if(!year.isEmpty())
        {
            File yearDir = kipopath.toPath().resolve(year).toFile();
            if(!date.isEmpty())
            {
                File dateDir = kipopath.toPath().resolve(date).toFile();
                importDir(dateDir);
            }
            else
            {
                File[] dateDirs = yearDir.listFiles();
                for(File dateDir : dateDirs)
                {
                    importDir(dateDir);
                }
            }
        }
        else
        {
            int startYear = 0;
            int startDate = 0;
            if(!argStartPath.isEmpty())
            {
                if(argStartPath.length() > 4)
                {
                    startYear = Integer.parseInt(argStartPath.substring(0, 4));
                    startDate = Integer.parseInt(argStartPath);
                }
                else
                {
                    startYear = Integer.parseInt(argStartPath);
                }
            }
            File[] yearDirs = kipopath.listFiles();
            Arrays.sort(yearDirs, new KipoImporter.CompratorByName());
            for(File yearDir : yearDirs)
            {
                if(yearPattern.matcher(yearDir.getName()).find() && Integer.parseInt(yearDir.getName()) >= startYear)
                {
                    File[] dateDirs = yearDir.listFiles();
                    Arrays.sort(dateDirs, new KipoImporter.CompratorByName());  
                    for(File dateDir : dateDirs)
                    {
                        if(Integer.parseInt(dateDir.getName()) >= startDate)
                        {
                            importDir(dateDir);
                        }
                    }
                }
            }
        }
        year = null;
        date = null;
        return this;
    }

    public KipoImporter importDir(File dir) {
        if (dir.isDirectory()) {
            Date date;
            try {
                date = df.parse(dir.getName());
                File[] patentDirs = dir.listFiles();
                for (File patentDir : patentDirs) {
                    String patentNumber = patentDir.getName();
                    importPatent(patentDir, patentNumber, date);
                    patentNumber = null;
                }
            } catch (ParseException e) {
                System.out.println(e.getMessage());
                log.info("save raw data err : " + dir.toPath().toString());
            }
            
        }
        return this;
    }

    public KipoImporter importPatent(File dir, String patentNumber, Date date)
    {
        if(dir.isDirectory())
        {
            for(File subDir:dir.listFiles())
            {
                importPatent(subDir, patentNumber, date);
            }
        }
        else
        {
            if(dir.getName().equalsIgnoreCase(patentNumber + ".sgm")
                    || dir.getName().equalsIgnoreCase(patentNumber + ".xml"))
            {
                try{
                    
                    String path = dir.toPath().getParent().toString();
                    path = path.substring(path.toLowerCase().indexOf("kipo\\")+5);
                    path = path.replaceAll("\\\\", "/");
                    PatentRawKIPO.remove(rawclazz, new QueryHelp("path", path).filter("pto", pto.toString()));
                    PatentRawKIPO raw = new PatentRawKIPO();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    String type = dir.getName();
                    type = type.substring(type.lastIndexOf(".")+1);
                    raw.type = type + "/" + type;
                    raw.provider = provider;
                    raw.doDate = date;
                    raw.data.put(type, FileUtils.readFileToString(dir, "EUC-KR"));
                    try
                    {
                        raw.save();
                    }
                    catch (Exception e)
                    {
                        log.info("save raw data err : " + dir.toPath().toString());
                        //throw e; //只記錄出錯的 信息，不對其進么拋出 change by luken 20131107
                    }
                    pe.addNum().debug(log, 10000, "save: '" + path + "'");
                    path = null;
                    type = null;
                    
                }catch(Exception e){
                    log.info("save raw data err : " + dir.toPath().toString());
                }
            }
        }
        return this;
    }
    public static class CompratorByName implements Comparator<File>  
    {  
        public int compare(File f1, File f2)
        {  
            int f1_int=0;
            int f2_int=0;
            try
            {
                f1_int = Integer.parseInt(f1.getName());
                f2_int = Integer.parseInt(f2.getName());
            }
            catch (Exception e)
            {
                
            }
            int diff = f1_int - f2_int;
            if(diff>0)
            {
                return 1;
            }
            else if(diff==0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    } 
}
