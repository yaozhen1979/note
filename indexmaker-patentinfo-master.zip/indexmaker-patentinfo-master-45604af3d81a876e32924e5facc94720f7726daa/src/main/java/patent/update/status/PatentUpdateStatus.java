package patent.update.status;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.tsaikd.java.utils.ArgParser;

import patent.update.utils.ConnectSqlserver;

/**
 * 
 * @author luken
 * Save the status when update patent original source
 *
 */

public class PatentUpdateStatus {
    
    public static final String opt_release_date = "releasedate";
    public static final String opt_release_date_default = null;

    public static final String opt_pto = "pto";
    public static final String opt_pto_default = null;    
    
    public static final String opt_progress = "progress";
    public static final String opt_progress_default = null;
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_release_date, true, opt_release_date_default, ""),
        new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
        new ArgParser.Option(null, opt_progress, true, opt_progress_default, "")
    };
    

    Connection connection = null;
    PreparedStatement pst = null;
    ResultSet resultSet = null;

    private Connection getConnection() throws ClassNotFoundException, SQLException  {
        Connection conn;
        conn = ConnectSqlserver.getInstance().openConnection();
        return conn;
    }
    
    
    public void addPatentUpdateStatu(String releaseDate,String pto,String process) {
        
        try {
            
            String queryString = "INSERT INTO PatentUpdateStatu(pto, process, modifiedDate,releaseDate) VALUES(?,?,?,?)";
            connection = getConnection();
            pst = connection.prepareStatement(queryString);
            pst.setString(1, pto);
            pst.setString(2, process);
            
            pst.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            
            pst.setString(4, releaseDate);
        
            pst.executeUpdate();
            System.out.println("Data Added Successfully");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pst != null)
                    pst.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
    
    public static void main(String[] args) throws Exception{
        PatentUpdateStatus patentUpdateStatus = new PatentUpdateStatus();
        patentUpdateStatus.worker(args);
    }
    
    public void worker(String[] args) throws Exception{
        ArgParser argParser = new ArgParser().addOpt(PatentUpdateStatus.class).parse(args);
        String pto=argParser.getOptString(opt_pto);
        String releaseDate=argParser.getOptString(opt_release_date);
        String process=argParser.getOptString(opt_progress);
    
        PatentUpdateStatus patentUpdateStatu= new PatentUpdateStatus();
        patentUpdateStatu.addPatentUpdateStatu(releaseDate, pto, process);
        
    }

}
