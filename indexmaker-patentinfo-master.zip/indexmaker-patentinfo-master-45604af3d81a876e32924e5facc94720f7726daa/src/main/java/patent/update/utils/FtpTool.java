package patent.update.utils;

import it.sauronsoftware.ftp4j.FTPAbortedException;
import it.sauronsoftware.ftp4j.FTPClient;
import it.sauronsoftware.ftp4j.FTPDataTransferException;
import it.sauronsoftware.ftp4j.FTPException;
import it.sauronsoftware.ftp4j.FTPIllegalReplyException;
import it.sauronsoftware.ftp4j.connectors.HTTPTunnelConnector;

import java.io.File;
import java.io.IOException;

/**
 * connect to the ftp and download file
 * @author XingTuoLu
 *
 */

public class FtpTool {
    
    private String ftpUserName;
    
    private String ftpPassword;
    
    private String ftpHost;
    
    private int ftpPort;
    
    private String proxyHost;
    
    private int proxyPort;
    
    
    
    public FtpTool(String ftpUserName, String ftpPassword, String ftpHost,
            int ftpPort) {
        super();
        this.ftpUserName = ftpUserName;
        this.ftpPassword = ftpPassword;
        this.ftpHost = ftpHost;
        this.ftpPort = ftpPort;
    }
    

    public FtpTool(String ftpUserName, String ftpPassword, String ftpHost,
            int ftpPort, String proxyHost, int proxyPort) {
        super();
        this.ftpUserName = ftpUserName;
        this.ftpPassword = ftpPassword;
        this.ftpHost = ftpHost;
        this.ftpPort = ftpPort;
        this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
    }

    public FTPClient getFtpConnect(){
        FTPClient client = new FTPClient();
        
        try {
            if(proxyHost!=""&&proxyHost!=null){                
                HTTPTunnelConnector http = new HTTPTunnelConnector(proxyHost, proxyPort);
                client.setConnector(http);
            }
            client.connect(ftpHost, ftpPort);
            client.login(ftpUserName, ftpPassword);
        } catch (IllegalStateException | IOException | FTPIllegalReplyException
                | FTPException e) {
            e.printStackTrace();
        }    
        return client;
    }
    
    public void download(FTPClient client,String remoteFile,String localFilePath){
        long localFileLength=0;
        
        try {
            File localFile = new File(localFilePath);
            if(localFile.exists()){
                localFileLength=localFile.length();
            }
            if(localFileLength>0){
                long ftpFileSize = client.fileSize(remoteFile);
                System.out.println("local file size :" + localFileLength);
                System.out.println("ftp file size :" + ftpFileSize);
                if(ftpFileSize>localFileLength){
                    client.download(remoteFile, localFile, localFileLength,new MyTransferListener());
                }            
            }else{
                client.download(remoteFile, new java.io.File(localFilePath),new MyTransferListener());
            }
            
        } catch (IllegalStateException | IOException
                | FTPIllegalReplyException | FTPException
                | FTPDataTransferException | FTPAbortedException e) {
            FTPClient client2 = getFtpConnect();
            download(client2, remoteFile, localFilePath);        
        }
    }
    
    /**
     * 簡單的判斷ftp文件是否存在：如果遠端ftp文件大小大于0，則文件存在
     * @param client tfpclient
     * @param remoteFilePath  ftp文件絕對路徑 
     * @return
     */
    public boolean isExit(String remoteFilePath) {
        try {
            FTPClient client=getFtpConnect();
            long ftpFileSize = client.fileSize(remoteFilePath);
            if(ftpFileSize>0){
                return true;
            }
        } catch (IllegalStateException | IOException | FTPIllegalReplyException
                | FTPException e) {
            return false;
        }
        return false;
    }
    
    public void downloadList(FTPClient client,String[] remoteFileList,String localFilePath){
        
        for(String path:remoteFileList){

            boolean remoteFileIsExit=isExit(path);
            System.out.println(remoteFileIsExit);
            if(remoteFileIsExit){
                File myFile = new File(path);
                String fileName = myFile.getName();
                System.out.println("Begin download : " + fileName);
                String localPath = localFilePath+File.separator+fileName;
                download(client, path, localPath);
                System.out.println("Download completed : " + fileName);        
            }        
        }
    }
    
    /**
     * 簡單的判斷ftp文件是否存在：如果遠端ftp文件大小大于0，則文件存在
     * @param client tfpclient
     * @param remoteFilePath  ftp文件絕對路徑 
     * @return
     */
    public boolean isExit(FTPClient client, String remoteFilePath) {
        try {
            long ftpFileSize = client.fileSize(remoteFilePath);
            if(ftpFileSize>0){
                return true;
            }
        } catch (IllegalStateException | IOException | FTPIllegalReplyException
                | FTPException e) {
            return false;
        }
        return false;
    }
    

    public String getFtpUserName() {
        return ftpUserName;
    }

    public void setFtpUserName(String ftpUserName) {
        this.ftpUserName = ftpUserName;
    }

    public String getFtpPassword() {
        return ftpPassword;
    }

    public void setFtpPassword(String ftpPassword) {
        this.ftpPassword = ftpPassword;
    }

    public String getFtpHost() {
        return ftpHost;
    }

    public void setFtpHost(String ftpHost) {
        this.ftpHost = ftpHost;
    }

    public int getFtpPort() {
        return ftpPort;
    }

    public void setFtpPort(int ftpPort) {
        this.ftpPort = ftpPort;
    }
    
    public String getProxyHost() {
        return proxyHost;
    }

    public void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }
}
