package patent.update.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.tsaikd.java.utils.ConfigUtils;

/**
 * 
 * @author luken
 * 
 * Connect to the sql server
 *
 */
public class ConnectSqlserver {

    private String driverClass = "net.sourceforge.jtds.jdbc.Driver";

    private String url = ConfigUtils.get("pims.jdbc.url");

    private String user = ConfigUtils.get("pims.jdbc.user");

    private String password = ConfigUtils.get("pims.jdbc.password");;

    private Connection connection;

    private static ConnectSqlserver connectSqlserver = null;
    

    public ConnectSqlserver() {
        
    }

    public ConnectSqlserver(String url, String user, String password) {
        super();
        this.url = url;
        this.user = user;
        this.password = password;
    }

    public Connection openConnection() throws ClassNotFoundException, SQLException  {
        Class.forName(driverClass);
        connection = DriverManager.getConnection(url, user, password);
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null)
                connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ConnectSqlserver getInstance() {
        if (connectSqlserver == null) {
            connectSqlserver = new ConnectSqlserver();
        }
        return connectSqlserver;
    }
    
    public static ConnectSqlserver getInstance(String url, String user, String password) {
        if (connectSqlserver == null) {
            connectSqlserver = new ConnectSqlserver(url, user, password);
        }
        return connectSqlserver;
    }

}