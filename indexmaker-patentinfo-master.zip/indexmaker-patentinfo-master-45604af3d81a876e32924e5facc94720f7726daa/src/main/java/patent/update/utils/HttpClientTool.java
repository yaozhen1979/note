package patent.update.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class HttpClientTool {

    static Log log = LogFactory.getLog(HttpClientTool.class);
    private static CloseableHttpClient httpClient = null;
    private static PoolingHttpClientConnectionManager cm = null;
    
    private String proxy_host;
    private int proxy_port;
    private String proxy_user;
    private String proxy_password;
    private String local_path;
    
    
    public String getProxy_host() {
        return proxy_host;
    }

    public void setProxy_host(String proxy_host) {
        this.proxy_host = proxy_host;
    }

    public int getProxy_port() {
        return proxy_port;
    }

    public void setProxy_port(int proxy_port) {
        this.proxy_port = proxy_port;
    }

    public String getProxy_user() {
        return proxy_user;
    }

    public void setProxy_user(String proxy_user) {
        this.proxy_user = proxy_user;
    }

    public String getProxy_password() {
        return proxy_password;
    }

    public void setProxy_password(String proxy_password) {
        this.proxy_password = proxy_password;
    }

    public String getLocal_path() {
        return local_path;
    }

    public void setLocal_path(String local_path) {
        this.local_path = local_path;
    }

    public HttpClientTool() {
    }
    
    public HttpClientTool(String proxy_host, int proxy_port, String proxy_user,
            String proxy_password,  String local_path) {
        super();
        this.proxy_host = proxy_host;
        this.proxy_port = proxy_port;
        this.proxy_user = proxy_user;
        this.proxy_password = proxy_password;
        this.local_path = local_path;
    }
    
    public void downEPZip(String index_url , String second_index_url , Map<String, String> postParams , String download_local_path, String date_string) throws Exception {
        ByteArrayOutputStream bOut = null;
        String tar_file_name = "";
        String head_url = "https://publication.epo.org/raw-data/";
        bOut = createPostConnect(index_url, postParams);
        bOut = executeGetMethod(second_index_url);
        if (date_string == "" || date_string == null) {
            tar_file_name = getYearAndWeekByDate();
        }
        else {
            tar_file_name = date_string;
        }
        String pattern = "href=.*(download.*?"+ tar_file_name + "\\.zip)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(new String(bOut.toByteArray()));
        while (m.find())
        {
            final String url = head_url + m.group(1);
            String fileName = getFileName(url);
            File file_path = new File(download_local_path);
            if (!file_path.exists()) {
                file_path.mkdirs();
            }
            final File file = new File(download_local_path + File.separator + fileName);
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    executeGetFile(url , file);
                }
            });
            t.start();
        }
    }
    
    public  String  getFileName(String result_url) {
        String fileName ;
        if(result_url.endsWith(File.separator)) {
            fileName = result_url.substring(0,result_url.length()-1);
        }
        fileName = result_url.substring(result_url.lastIndexOf('/') + 1, result_url.length());
        log.info(fileName);
        return fileName;
    }

    protected String byteToString(ByteArrayOutputStream out) {
        byte[] newBits = out.toByteArray();
        String sTotal = LToU(newBits);
        return sTotal;
    }
    
    String LToU(byte[] bits) {
        try {
            return new String(bits);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * @param buf
     * @return ByteArrayOutputStream
     */
    public static ByteArrayOutputStream byteToOutputStream(byte[] buf) {
        ByteArrayInputStream in = new ByteArrayInputStream(buf);
        ByteArrayOutputStream OS = new ByteArrayOutputStream();
        byte[] buff = new byte[5024 * 1000];
        int rc = 0;
        while ((rc = in.read(buff, 0, 1024)) > 0) {
            OS.write(buff, 0, rc);
        }
        return OS;
    }
    
    /**
     * 將HTTP POST Str 方法相關的參數轉換成所需的形式
     * 
     * @param postParams
     * @return
     * @throws Exception 
     */
    public static List<NameValuePair> convertPostParams(Map<String, String> postParams){
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        Iterator<Entry<String, String>> iter = postParams.entrySet().iterator();
        while(iter.hasNext()){
            Entry<String, String> entry = iter.next();
            String name = entry.getKey();
            String value = (String)entry.getValue();
            params.add(new BasicNameValuePair(name, value));
        }
        return params;
    }
    
    /**
     * @param url
     * @return
     * @throws Exception
     */
    public ByteArrayOutputStream createPostConnect(String url, Map<String, String> postData) throws Exception {
        log.info("start get data from net");
        ByteArrayOutputStream bOut = null;
        while (true) {
            try {
                bOut = executePostMethod(url, postData);
                if (bOut == null) {
                    log.info("route the bOut=null to create it ");
                    continue;
                }
                log.info("end get data from net at break");
                break;
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
        log.info("end get data from net at endpoint");
        return bOut;
    }
    
    /**
     * 執行HTTP Post方法 
     * @param String url
     * @return ByteArrayOutputStream
     * @throws Exception
     */
    public ByteArrayOutputStream executePostMethod(String url, Map<String, String> postParams) throws Exception {
        ByteArrayOutputStream OS = new ByteArrayOutputStream();
        if(url == null || url.equals("")){ return null; }
        HttpPost postMethod = new HttpPost(url);
        List<NameValuePair> params = convertPostParams(postParams);
        UrlEncodedFormEntity postParamsEntity = new UrlEncodedFormEntity(params, Consts.UTF_8);
        postMethod.setEntity(postParamsEntity);
        
        try {
            CloseableHttpResponse response = httpClient.execute(postMethod);
            System.out.println(">>execute result: " + response.getStatusLine());
            int statusCode = response.getStatusLine().getStatusCode();
            if(statusCode == 200){
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    OS = byteToOutputStream(EntityUtils.toByteArray(entity));
                }
                else {
                }
            }
            else if(statusCode >= 300 && statusCode < 400)
            {
                System.err.println("Network error. response code:" + statusCode);
                String redirectUrl = response.getFirstHeader("Location").getValue();
                System.out.println(">>redirect to: " + redirectUrl);
                return executeGetMethod(redirectUrl);
                //OS.write(redirectUrl.getBytes());
            }
            else if(statusCode >400)
            {
                System.err.println("Network error. response code:" + statusCode);
                try {
                    throw new Exception("Network error. response code:" + statusCode);                                
                } catch (Exception e) {
                       throw e;
                }
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            postMethod.abort();
            postMethod.releaseConnection();
            httpClient.getConnectionManager().closeExpiredConnections();
        }
        return OS;
    }
    
    /**
     * 執行HTTP get方法
     * @param String url
     * @return ByteArrayOutputStream
     * @throws Exception
     */
    public static ByteArrayOutputStream executeGetMethod(String url) throws Exception {
        ByteArrayOutputStream OS = new ByteArrayOutputStream();
        
        HttpGet httpGet = new HttpGet(url);
        
        try {
            CloseableHttpResponse response = httpClient.execute(httpGet);
            
            System.out.println(">>execute result: " + response.getStatusLine());
            int statusCode = response.getStatusLine().getStatusCode();
            if(statusCode == 200){
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    OS = byteToOutputStream(EntityUtils.toByteArray(entity));
                }                
            }
            else if(statusCode >= 300 && statusCode < 400)
            {
                System.err.println("Network error. response code:" + statusCode);
                String redirectUrl = response.getFirstHeader("Location").getValue();
                System.out.println(">>redirect to: " + redirectUrl);
                return executeGetMethod(redirectUrl);
                //OS.write(redirectUrl.getBytes());
            }
            else if(statusCode >400)
            {
                System.err.println("Network error. response code:" + statusCode);
                try {
                    throw new Exception("Network error. response code:" + statusCode);                                
                } catch (Exception e) {
                       throw e;
                }
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            httpGet.abort();
            httpGet.releaseConnection();
            httpClient.getConnectionManager().closeExpiredConnections();
        }
        return OS;
    }
    
    /**
     * 下载大数据文件
     * 執行HTTP get方法
     * @param source_url
     * @param file
     */
    public static void executeGetFile(String source_url, File file) {
        InputStream is = null;
        HttpEntity entity = null;
        FileOutputStream fos = null;
        HttpGet httpGet = new HttpGet(source_url);
        try {
            fos = new FileOutputStream(file);
            if (!file.exists()) {
                new File(file.getParent()).mkdirs();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            CloseableHttpResponse response = httpClient.execute(httpGet);
            System.out.println(">>execute result: " + response.getStatusLine());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                entity = response.getEntity();
                if (entity != null) {
                    is = entity.getContent();
                    log.info("begin");
                    // 将输入流is写入文件输出流fos中
                    int ch = 0;
                    byte[] buf = new byte[2048*1024];
                    while ((ch = is.read(buf)) != -1) {
                        fos.write(buf, 0, ch);
                        //log.info("continue....");
                    }
                }
            }
        } catch (Exception e) {

        } finally {
            try {
                is.close();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            log.info("success end");
        }
    }
    
    public  void configProxy(String host, int port, String username, String password){
        cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(100);
        httpClient = HttpClients.custom()
                .setConnectionManager(cm)
                .build();
        if(host != null && host.length() > 0 && port  > 0){
            // 設置代理
            HttpHost proxy = new HttpHost(host, port);
            DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
            httpClient = HttpClients.custom()
                    .setRoutePlanner(routePlanner)
                    .build();
            /*CredentialsProvider credsProvider = new BasicCredentialsProvider();
            credsProvider.setCredentials(
                    new AuthScope(host, port),
                    new UsernamePasswordCredentials(username, password));
            CloseableHttpClient httpclient = HttpClients.custom()
                    .setDefaultCredentialsProvider(credsProvider).build();*/
        }else{
            httpClient = HttpClients.custom()
                    .setConnectionManager(cm)
                    .build();
        }
    }
    
    /**
     * 下载不超过jave heap space（20M）的文件
     * @param bOutStream
     * @param file
     * @return
     */
    public boolean byteStreamToFile(ByteArrayOutputStream bOutStream , File file) {
        java.io.FileOutputStream fos;
        boolean flag = false;
        if (!file.exists()) {
            new File(file.getParent()).mkdirs();
        }
        
        try {
            fos = new java.io.FileOutputStream(file);
            try {
                log.info("continue...");
                fos.write(bOutStream.toByteArray());
                flag = true;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                flag = false;
                e.printStackTrace();
            }
            try {
                fos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }  
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return flag; 
        
        }
    
    /**
     * 通过当下日期拼成zip下载文件路径名称XEPB2014038
     * @return
     */
    public String getYearAndWeekByDate()  {
        Calendar cl = Calendar.getInstance();
        int year_now = cl.get(Calendar.YEAR);
        int week = cl.get(Calendar.WEEK_OF_YEAR); 
        cl.add(Calendar.DAY_OF_MONTH, -7);
        int year = cl.get(Calendar.YEAR);
        if (cl.get(Calendar.WEEK_OF_YEAR) == 1 && year < year_now) {
            year = year_now;
        }
        if(week < cl.get(Calendar.WEEK_OF_YEAR)){
            year+=1;
        }
        System.out.println(year+"年第"+week+"周");
        if ((String.valueOf(week)).length() == 1) {
            return year + "00" + week;
        }
        return year + "0" + week;
    }
    
    /**
     * 20121231    通过指定日期拼成zip下载文件路径名称XEPB2014038
     * 根据7天前的周数来做一下对比，如果7天前的周数小于当日周数，则表示为正常周数和正常年份，如果7天前的周数大于当日周数，表示当日在年尾,并且当日周数被计算在下一年，此时要在得到的年份是+1
     * @param dateStr
     * @return
     */
    public String getYearAndWeekByDateStr(String dateStr)  {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd"); 
        Calendar cl = Calendar.getInstance(); 
        try {
            cl.setTime(sdf.parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int week = cl.get(Calendar.WEEK_OF_YEAR); 
        int year_now = cl.get(Calendar.YEAR);
        cl.add(Calendar.DAY_OF_MONTH, -7);
        int year = cl.get(Calendar.YEAR);
        if (cl.get(Calendar.WEEK_OF_YEAR) == 1 && year < year_now) {
            year = year_now;
        }
        if(week < cl.get(Calendar.WEEK_OF_YEAR)){
            year+=1;
        }
        System.out.println(year+"年第"+week+"周");
        if ((String.valueOf(week)).length() == 1) {
            return year + "00" + week;
        }
        return year + "0" + week;
    }
    
}


