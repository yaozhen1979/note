package patent.update.queue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.tsaikd.java.utils.ConfigUtils;

import patent.update.utils.ConnectSqlserver;

/**
 * A Patent Update holder, which Records patents have been updated with Patentcloud DB
 *
 * @Genchi
 */

public class PatentUpdateHolder {

    Connection connection = null;
    ConnectSqlserver pt_sql = null;
    PreparedStatement pst = null;

    //private cloud for sbp
    Connection connection_sbp = null;
    ConnectSqlserver pt_sql_sbp = null;
    PreparedStatement pst_sbp = null;

    //private cloud for wp
    Connection connection_wp = null;
    ConnectSqlserver pt_sql_wp = null;
    PreparedStatement pst_wp = null;

    private static String queryString = "INSERT INTO PatentIndexUpdateQueue(PatentCloudID, Pto," +
            " Action, CreatedDateTime, Status) VALUES(?, ?, ?, ?, ?)";

    private static void executeSQLUpdate(PreparedStatement pst_tmp, Connection connection_tmp, String id, String pto) throws SQLException {
        pst_tmp = connection_tmp.prepareStatement(queryString);
        pst_tmp.setString(1, id);
        pst_tmp.setString(2, pto);
        pst_tmp.setInt(3, 0);
        pst_tmp.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
        pst_tmp.setInt(5, 0);
        pst_tmp.executeUpdate();
    }
    public PatentUpdateHolder() {
        pt_sql = new ConnectSqlserver(
                ConfigUtils.get("patentcloud.jdbc.url"),
                ConfigUtils.get("patentcloud.jdbc.user"),
                ConfigUtils.get("patentcloud.jdbc.password"));
        pt_sql_sbp = new ConnectSqlserver(
                ConfigUtils.get("patentcloudsbp.jdbc.url"),
                ConfigUtils.get("patentcloudsbp.jdbc.user"),
                ConfigUtils.get("patentcloudsbp.jdbc.password"));
        pt_sql_wp = new ConnectSqlserver(
                ConfigUtils.get("patentcloudwp.jdbc.url"),
                ConfigUtils.get("patentcloudwp.jdbc.user"),
                ConfigUtils.get("patentcloudwp.jdbc.password"));
        try {
            connection = pt_sql.openConnection();
            connection_sbp = pt_sql_sbp.openConnection();
            connection_wp = pt_sql_wp.openConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void addUpdatePatent(String id, String pto) {
        try{
            executeSQLUpdate(pst, connection, id, pto);
            executeSQLUpdate(pst_sbp, connection_sbp, id, pto);
            executeSQLUpdate(pst_wp, connection_wp, id, pto);
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
    
    public void destory () {
        try {
            connection.close();
            connection_sbp.close();
            connection_wp.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
