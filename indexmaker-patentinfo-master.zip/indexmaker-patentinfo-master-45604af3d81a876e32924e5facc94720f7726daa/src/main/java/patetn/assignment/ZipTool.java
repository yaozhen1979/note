package patetn.assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ZipTool {
    public static String url="C:\\us\\";
    /**
     * @param args
     */
    public static void main(String[] args) {
    

    }

    public List<String> unzip(String filePath){
        boolean flag = false;
        List<String> list = new ArrayList<String>();
        long num=0;
        String name="";
        try {

            ZipFile zf = new ZipFile(filePath);
            Enumeration entries = zf.entries();

            while (entries.hasMoreElements()) {
                ZipEntry ze = (ZipEntry) entries.nextElement();
                long size = ze.getSize();
                if (size > 0 && ze.getName().endsWith(".xml")) {
                    System.out.println("Read " + ze.getName() + "?");
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(zf.getInputStream(ze)));
                    StringBuffer content = new StringBuffer();
                    name = ze.getName().replace(".xml","");
                    String line;
                    while ((line = br.readLine()) != null) {
                    
                        if (line.trim().equalsIgnoreCase("<patent-assignment>")) {
                            flag = true;
                        }
                        if (line.trim().equalsIgnoreCase("</patent-assignment>")) {
                            flag = false;
                        }
                        if (flag && !line.trim().equalsIgnoreCase("<patent-assignment>")) {
                            content.append(line.trim());
                        }
                        if(line.trim().equalsIgnoreCase("</patent-assignment>")){
                            content.append(line.trim());
                            list.add(content.toString());
                            content = new StringBuffer();
                        }
                        if(line.trim().startsWith("<patent-assignment>")){
                            content.append(line.trim());
                            
                        }
                    
                    }
                    

                }
            }
        
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return list;
    }
    private DocumentBuilder getDocumentBuilder() {
        DocumentBuilder db = null;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            db = dbf.newDocumentBuilder();
            db.setEntityResolver(new IgnoreDTDEntityResolver()); // ignore dt
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return db;

    }
    public static BufferedWriter getBufferedWriter(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(path);
            BufferedWriter bw = new BufferedWriter(fw);

            return bw;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
