package patetn.assignment;

import itec.patent.assignment.us.AssignmentInfoUSPTO;
import itec.patent.assignment.us.AssignmentRecord;
import itec.patent.assignment.us.AssignmentText;
import itec.patent.assignment.us.Correspondent;
import itec.patent.assignment.us.DocumentID;
import itec.patent.assignment.us.PatentAssignee;
import itec.patent.assignment.us.PatentAssignor;
import itec.patent.assignment.us.PatentProperty;

import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class AnalysisAssignMent {
    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
    public AssignmentInfoUSPTO parse(String xml) throws SAXException,
            IOException {
        AssignmentInfoUSPTO assignMentData =null;
        dateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
    //    List<AssignmentText> assigneeMentList = new ArrayList<AssignmentText>();
//        SolrServer server =new HttpSolrServer("http://10.153.25.171:8080/solr");
        NodeList list = null;
        Node currNode, tmpNode = null;
        String valueStr = "";
        InputSource inSource = new InputSource(new StringReader(xml));
        Document doc = getDocumentBuilder().parse(inSource);
        Element root = doc.getDocumentElement();
/*        if (root.getNodeName().equals("patent-assignments")) {
            list = root.getChildNodes();
            if (list != null && list.getLength() > 0) {
                for (int i = 0; i < list.getLength(); i++) {
                    currNode = list.item(i);*/
                    currNode = root;
                    if (currNode.getNodeName().equals("patent-assignment")) {
                         assignMentData = new AssignmentInfoUSPTO();
                        for (int j = 0; j < currNode.getChildNodes()
                                .getLength(); j++) {
                            tmpNode = currNode.getChildNodes().item(j);
                            if (tmpNode.getNodeName().equals(
                                    "assignment-record")) {
                                AssignmentRecord assignmentrecord = paserAssignmentRecord(tmpNode);
                                if (assignmentrecord != null) {
                                    assignMentData.setReelNo(assignmentrecord
                                            .getReelNo());
                                    assignMentData.setFrameNo(assignmentrecord
                                            .getFrameNo());
                                    assignMentData.setReelframeNo(assignmentrecord
                                            .getReelNo()+assignmentrecord
                                            .getFrameNo());
                                    assignMentData
                                            .setLastUpdate(assignmentrecord
                                                    .getLastUpdate());
                                    assignMentData
                                            .setPurgeIndicator(assignmentrecord
                                                    .getPurgeIndicator());
                                    assignMentData
                                            .setRecordedDate(assignmentrecord
                                                    .getRecordedDate());
                                    assignMentData
                                            .setPageCount(assignmentrecord
                                                    .getPageCount());
                                    if (assignmentrecord.getCorrespondent() != null) {
                                        assignMentData
                                                .setCorrespondentname(assignmentrecord
                                                        .getCorrespondent()
                                                        .getName());
                                        assignMentData
                                                .setCorrespondentaddress1(assignmentrecord
                                                        .getCorrespondent()
                                                        .getAddress1());
                                        assignMentData
                                                .setCorrespondentaddress2(assignmentrecord
                                                        .getCorrespondent()
                                                        .getAddress2());
                                        assignMentData
                                                .setCorrespondentaddress3(assignmentrecord
                                                        .getCorrespondent()
                                                        .getAddress3());
                                        assignMentData
                                                .setCorrespondentaddress4(assignmentrecord
                                                        .getCorrespondent()
                                                        .getAddress4());
                                    }
                                    assignMentData
                                            .setConveyanceText(assignmentrecord
                                                    .getConveyanceText());
                                }
                            } else if (tmpNode.getNodeName().equals(
                                    "patent-assignors")) {
                                ArrayList<PatentAssignor> patentAssignor = getPatentAssignorList(tmpNode);
                                if (patentAssignor != null
                                        && patentAssignor.size() > 0) {
                                    ArrayList<String> patentAssignors = new ArrayList();
                                    ArrayList<String> assignorName = new ArrayList();
                                    ArrayList<Date> executionDate = new ArrayList();
                                    ArrayList<String> assignorAddress1 = new ArrayList();
                                    ArrayList<String> assignorAddress2 = new ArrayList();
                                    ArrayList<Date> dateAcknowledged = new ArrayList();
                                    for (PatentAssignor assignor : patentAssignor) {
                                        patentAssignors.add(assignor.getPatentAssignorJson());
                                        assignorName.add(assignor.getAssignorName());
                                        executionDate.add(assignor.getExecutionDate());
                                        assignorAddress1.add(assignor.getAssignorAddress1());
                                        assignorAddress2.add(assignor.getAssignorAddress2());
                                        dateAcknowledged.add(assignor.getDateAcknowledged());
                                    }
                                    assignMentData.setPatentAssignor(patentAssignors);
                                    assignMentData.setAssignorName(assignorName);
                                    assignMentData.setAssignorAddress1(assignorAddress1);
                                    assignMentData.setAssignorAddress2(assignorAddress2);
                                    assignMentData.setExecutionDate(executionDate);
                                    assignMentData.setDateAcknowledged(dateAcknowledged);
                                    
                                }
                            } else if (tmpNode.getNodeName().equals(
                                    "patent-assignees")) {
                                List<PatentAssignee> patentAssignee = getPatentAssigneeList(tmpNode);
                                if(patentAssignee!=null&&patentAssignee.size()>0){
                                    ArrayList<String> patentAssignees= new ArrayList();
                                    ArrayList<String> assigneeName= new ArrayList();
                                    ArrayList<String> assigneeAddress1= new ArrayList();
                                    ArrayList<String> assigneeAddress2= new ArrayList();
                                    ArrayList<String> assigneeCity= new ArrayList();
                                    ArrayList<String> assigneeState= new ArrayList();
                                    ArrayList<String> assigneeCountry= new ArrayList();
                                    ArrayList<String> assigneePostcode= new ArrayList();

                                    for(PatentAssignee assignee:patentAssignee){
                                        patentAssignees.add(assignee.getPatentAssigneeJson());
                                        assigneeName.add(assignee.getAssigneeName());
                                        assigneeAddress1.add(assignee.getAssigneeAddress1());
                                        assigneeAddress2.add(assignee.getAssigneeAddress2());
                                        assigneeCity.add(assignee.getAssigneeCity());
                                        assigneeState.add(assignee.getAssigneeState());
                                        assigneeCountry.add(assignee.getAssigneeCountry());
                                        assigneePostcode.add(assignee.getAssigneePostcode());
                                    }
                                    assignMentData.setPatentAssignee(patentAssignees);
                                    assignMentData.setAssigneeName(assigneeName);
                                    assignMentData.setAssigneeAddress1(assigneeAddress1);
                                    assignMentData.setAssigneeAddress2(assigneeAddress2);
                                    assignMentData.setAssigneeCity(assigneeCity);
                                    assignMentData.setAssigneeState(assigneeState);
                                    assignMentData.setAssigneeCountry(assigneeCountry);
                                    assignMentData.setAssigneePostcode(assigneePostcode);
                                }
                            } else if (tmpNode.getNodeName().equals(
                                    "patent-properties")) {
                                List<PatentProperty> patentProperty = getPatentProperties(tmpNode);
                                if(patentProperty!=null&&patentProperty.size()>0){
                                    ArrayList<String> patentProperties= new ArrayList();
                                    ArrayList<String> kind= new ArrayList();
                                    ArrayList<Date> appDate= new ArrayList();
                                    ArrayList<String> appNumber= new ArrayList();
                                    ArrayList<Date> openDate= new ArrayList();
                                    ArrayList<String> openNumber= new ArrayList();
                                    ArrayList<String> openKind= new ArrayList();
                                    ArrayList<Date> decisionDate= new ArrayList();
                                    ArrayList<String> decisionNumber= new ArrayList();
                                    ArrayList<String> decisionKind= new ArrayList();
                                    ArrayList<String> inventionTitle= new ArrayList();
                                    ArrayList<String> country= new ArrayList();
                                     for(PatentProperty patent :patentProperty){
                                         patentProperties.add(patent.getPatentPropertyJson());
                                         kind.add(patent.getKind());
                                         appDate.add(patent.getAppDate());
                                         appNumber.add(patent.getAppNumber());
                                         openDate.add(patent.getOpenDate());
                                         openNumber.add(patent.getOpenNumber());
                                         openKind.add(patent.getOpenKind());
                                         decisionDate.add(patent.getDecisionDate());
                                         decisionNumber.add(patent.getDecisionNumber());
                                         decisionKind.add(patent.getDecisionKind());
                                         inventionTitle.add(patent.getInventionTitle());
                                         country.add("US");
                                     }
                                     assignMentData.setPatentProperty(patentProperties);
                                     assignMentData.setKind(kind);
                                     assignMentData.setAppDate(appDate);
                                     assignMentData.setAppNumber(appNumber);
                                     assignMentData.setPublicationDate(openDate);
                                     assignMentData.setPublicationNumber(openNumber);
                                     assignMentData.setPublicationKind(openKind);
                                     assignMentData.setIssueDate(decisionDate);
                                     assignMentData.setPatentNumber(decisionNumber);
                                     assignMentData.setIssueKind(decisionKind);
                                     assignMentData.setInventionTitle(inventionTitle);
                                     assignMentData.setCountry(country);
                                }
                            }

                        }
                        if(assignMentData.getReelframeNo()!=null){
                            
                        }
                    
                }

/*                }

            }
        }*/
        return assignMentData;
    }

    public AssignmentRecord paserAssignmentRecord(Node node) {
        AssignmentRecord assignmentRecord = new AssignmentRecord();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("reel-no")) {
                assignmentRecord.setReelNo(n.getTextContent().trim());
            } else if (n.getNodeName().equals("frame-no")) {
                assignmentRecord.setFrameNo(n.getTextContent().trim());
            } else if (n.getNodeName().equals("purge-indicator")) {
                assignmentRecord.setPurgeIndicator(n.getTextContent().trim());
            } else if (n.getNodeName().equals("page-count")) {
                assignmentRecord.setPageCount(n.getTextContent().trim());
            } else if (n.getNodeName().equals("last-update-date")) {
                try {
                    assignmentRecord.setLastUpdate((Date) dateFormatter
                            .parseObject(n.getTextContent().trim()));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else if (n.getNodeName().equals("recorded-date")) {
                try {
                    assignmentRecord.setRecordedDate((Date) dateFormatter
                            .parseObject(n.getTextContent().trim().trim()));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else if (n.getNodeName().equals("correspondent")) {
                assignmentRecord.setCorrespondent(paserCorrespondent(n));
            } else if (n.getNodeName().equals("conveyance-text")) {
                assignmentRecord.setConveyanceText(n.getTextContent().trim());
            }

        }
        return assignmentRecord;
    }

    public Correspondent paserCorrespondent(Node node) {
        Correspondent correspondent = new Correspondent();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("name")) {
                correspondent.setName(n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-1")) {
                correspondent.setAddress1(n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-2")) {
                correspondent.setAddress2(n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-3")) {
                correspondent.setAddress3(n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-4")) {
                correspondent.setAddress4(n.getTextContent().trim());
            }
        }
        return correspondent;
    }

    private ArrayList<PatentAssignor> getPatentAssignorList(Node node) {
        ArrayList<PatentAssignor> patentAssignorList = new ArrayList<PatentAssignor>();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("patent-assignor")) {
                try {
                    patentAssignorList.add(paserPatentAssignor(n));
                } catch (DOMException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
        return patentAssignorList;
    }

    private PatentAssignor paserPatentAssignor(Node node) throws DOMException, JSONException {
        PatentAssignor patentAssignor = new PatentAssignor();
        JSONObject jsobj =new JSONObject();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("name")) {
                patentAssignor.setAssignorName(n.getTextContent().trim());
                jsobj.put("name", n.getTextContent().trim());
                
            } else if (n.getNodeName().equals("address-1")) {
                
                patentAssignor.setAssignorAddress1(n.getTextContent().trim());
                jsobj.put("address1", n.getTextContent().trim());
                
            } else if (n.getNodeName().equals("address-2")) {
                
                patentAssignor.setAssignorAddress2(n.getTextContent().trim());
                jsobj.put("address2", n.getTextContent().trim());
                
                
            } else if (n.getNodeName().equals("execution-date")) {
                try {
                    
                    patentAssignor.setExecutionDate((Date) dateFormatter
                            .parseObject(n.getTextContent().trim()));
                    jsobj.put("executiondate", n.getTextContent().trim());
                    
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else if (n.getNodeName().equals("date-acknowledged")) {
                try {
                    
                    patentAssignor.setDateAcknowledged((Date) dateFormatter
                            .parseObject(n.getTextContent().trim()));
                    jsobj.put("dateacknowledged", n.getTextContent().trim());
                    
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }
        patentAssignor.setPatentAssignorJson(jsobj.toString());
        
        return patentAssignor;
    }

    private List<PatentAssignee> getPatentAssigneeList(Node node) {
        List<PatentAssignee> patentAssigneeList = new ArrayList<PatentAssignee>();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("patent-assignee")) {
                try {
                    patentAssigneeList.add(paserPatentAssignee(n));
                } catch (DOMException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
        return patentAssigneeList;
    }

    private PatentAssignee paserPatentAssignee(Node node) throws DOMException, JSONException {
        PatentAssignee patentAssignee = new PatentAssignee();
        patentAssignee.setAssigneeCountry("US");
        JSONObject jsobj =new JSONObject();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("name")) {
                patentAssignee.setAssigneeName(n.getTextContent().trim());
                jsobj.put("name", n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-1")) {
                patentAssignee.setAssigneeAddress1(n.getTextContent().trim());
                jsobj.put("address1", n.getTextContent().trim());
            } else if (n.getNodeName().equals("address-2")) {
                patentAssignee.setAssigneeAddress2(n.getTextContent().trim());
                jsobj.put("address2", n.getTextContent().trim());
            } else if (n.getNodeName().equals("city")) {
                patentAssignee.setAssigneeCity(n.getTextContent().trim());
                jsobj.put("city", n.getTextContent().trim());
            } else if (n.getNodeName().equals("state")) {
                patentAssignee.setAssigneeState(n.getTextContent().trim());
                jsobj.put("state", n.getTextContent().trim());
            } else if (n.getNodeName().equals("country-name")) {
                patentAssignee.setAssigneeCountry(n.getTextContent().trim());
            } else if (n.getNodeName().equals("postcode")) {
                patentAssignee.setAssigneePostcode(n.getTextContent().trim());
                jsobj.put("postcode", n.getTextContent().trim());
            }

        }
        jsobj.put("countryname", patentAssignee.getAssigneeCountry());
        patentAssignee.setPatentAssigneeJson(jsobj.toString());
        return patentAssignee;
    }

    private List<PatentProperty> getPatentProperties(Node node) {
        List<PatentProperty> patentPropertyList = new ArrayList<PatentProperty>();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("patent-property")) {
                try {
                    patentPropertyList.add(paserPatentProperty(n));
                } catch (DOMException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
        return patentPropertyList;
    }

    private PatentProperty paserPatentProperty(Node node) throws DOMException, JSONException {
        PatentProperty patentProperty = new PatentProperty();
        List<DocumentID> documentIDList = new ArrayList<DocumentID>();
        JSONObject jsobj =new JSONObject();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("document-id")) {
                documentIDList.add(paserDocumentID(n));

            } else if (n.getNodeName().equals("invention-title")) {
                patentProperty.setInventionTitle(n.getTextContent().trim());
                jsobj.put("patentName", n.getTextContent().trim());
            }

        }
        if (documentIDList != null && documentIDList.size() > 0) {

            for (int m = 0; m < documentIDList.size(); m++) {
                jsobj.put("country","US");
                DocumentID documentID = documentIDList.get(m);
                if (documentID.getAppDate() != null) {
                    patentProperty.setAppDate(documentID.getAppDate());
                    patentProperty.setDocumentCountry(documentID
                            .getDocumentCountry());
                    jsobj.put("applicationDate",documentID.getAppDateString());
                }
                if (documentID.getAppNumber() != null
                        && documentID.getAppNumber().length() > 0) {
                    patentProperty.setAppNumber(documentID.getAppNumber());
                    jsobj.put("applicationNumber",documentID.getAppNumber());
                }
                if (documentID.getOpenDate() != null) {
                    patentProperty.setOpenDate(documentID.getOpenDate());
                    jsobj.put("publicationDate",documentID.getOpenDateString());
                }
                if (documentID.getOpenNumber() != null
                        && documentID.getOpenNumber().length() > 0) {
                    patentProperty.setOpenNumber(documentID.getOpenNumber());
                    jsobj.put("publicationNumber",documentID.getOpenNumber());
                }
                if (documentID.getOpedKind() != null
                        && documentID.getOpedKind().length() > 0) {
                    patentProperty.setOpenKind(documentID.getOpedKind());
                    jsobj.put("publicationKind",documentID.getOpedKind());
                }
                if (documentID.getDecisionDate() != null) {
                    patentProperty
                            .setDecisionDate(documentID.getDecisionDate());
                    jsobj.put("issueDate",documentID.getDecisionDateString());
                }
                if (documentID.getDecisionNumber() != null
                        && documentID.getDecisionNumber().length() > 0) {
                    patentProperty.setDecisionNumber(documentID
                            .getDecisionNumber());
                    jsobj.put("patentNumber",documentID.getDecisionNumber());
                }
                if (documentID.getDecisionKind() != null
                        && documentID.getDecisionKind().length() > 0) {
                    patentProperty
                            .setDecisionKind(documentID.getDecisionKind());
                    jsobj.put("issueKind",documentID.getDecisionKind());
                }
            }

        }
        patentProperty.setPatentPropertyJson(jsobj.toString());
        return patentProperty;
    }

    private DocumentID paserDocumentID(Node node) {
        DocumentID documentID = new DocumentID();
        Node n = null;
        for (int i = 0; i < node.getChildNodes().getLength(); i++) {
            n = node.getChildNodes().item(i);
            if (n.getNodeName().equals("country")) {
                documentID.setDocumentCountry(n.getTextContent().trim());
            } else if (n.getNodeName().equals("doc-number")) {
                documentID.setDocumentNumber(n.getTextContent().trim());
            } else if (n.getNodeName().equals("kind")) {
                documentID.setKind(n.getTextContent().trim());
            } else if (n.getNodeName().equals("date")) {
                try {
                    documentID.setDocumentDate((Date) dateFormatter
                            .parseObject(n.getTextContent().trim()));
                    documentID.setDocumentDateString(n.getTextContent().trim());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }
        if (documentID.getKind() != null && documentID.getKind().length() > 0) {
            if (documentID.getKind().equals("X0")) {
                documentID.setAppDate(documentID.getDocumentDate());
                documentID.setAppDateString(documentID.getDocumentDateString());
                documentID.setAppNumber(documentID.getDocumentNumber());
            } else if (documentID.getDocumentNumber().length() == 7) {
                documentID.setDecisionDate(documentID.getDocumentDate());
                documentID.setDecisionDateString(documentID.getDocumentDateString());
                documentID.setDecisionNumber(documentID.getDocumentNumber());
                documentID.setDecisionKind(documentID.getKind());
            } else {
                documentID.setOpenDate(documentID.getDocumentDate());
                documentID.setOpenDateString(documentID.getDocumentDateString());
                documentID.setOpenNumber(documentID.getDocumentNumber());
                documentID.setOpedKind(documentID.getKind());

            }
        }
        return documentID;

    }

    private DocumentBuilder getDocumentBuilder() {
        DocumentBuilder db = null;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            db = dbf.newDocumentBuilder();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return db;

    }
}
