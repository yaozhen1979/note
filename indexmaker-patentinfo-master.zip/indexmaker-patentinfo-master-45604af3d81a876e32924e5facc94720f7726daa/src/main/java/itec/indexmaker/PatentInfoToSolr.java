package itec.indexmaker;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.RelatedPatent;
import itec.patent.mongodb.embed.MultiLangString;
import itec.patent.mongodb.embed.MultiLangString.LangFilter;
import itec.patent.mongodb.embed.Person;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import patent.ipc.en.ClassificationType;
import patent.ipc.en.FiInfo;
import patent.ipc.en.IpcCpcFinder;
import patent.ipc.en.IpcInfo;
import patent.loc.en.LocInfo;



public class PatentInfoToSolr {

    static Log log = LogFactory.getLog(PatentInfoToSolr.class);

    private static HashMap<Pto, String> ptoMap = new HashMap<>();
    static {
        ptoMap.put(Pto.USPTO,    "US");
        ptoMap.put(Pto.US,        "US");
        ptoMap.put(Pto.TIPO,    "TW");
        ptoMap.put(Pto.TW,        "TW");
        ptoMap.put(Pto.CNIPR,    "CN");
        ptoMap.put(Pto.CN,        "CN");
        ptoMap.put(Pto.JPO,        "JP");
        ptoMap.put(Pto.JP,        "JP");
        ptoMap.put(Pto.KIPO,    "KR");
        ptoMap.put(Pto.KR,        "KR");
        ptoMap.put(Pto.EPO,        "EP");
        ptoMap.put(Pto.EP,        "EP");
        ptoMap.put(Pto.WIPO,    "WO");
        ptoMap.put(Pto.WO,        "WO");
        ptoMap.put(Pto.DPMA,    "DE");
        ptoMap.put(Pto.DE,        "DE");
        ptoMap.put(Pto.INPI,    "FR");
        ptoMap.put(Pto.FR,        "FR");
        ptoMap.put(Pto.UKIPO,    "GB");
        ptoMap.put(Pto.GB,        "GB");
        ptoMap.put(Pto.IGE,        "CH");
        ptoMap.put(Pto.CH,        "CH");
        ptoMap.put(Pto.EC,      "EC");
        ptoMap.put(Pto.DOCDB,      "DOCDB");
        ptoMap.put(Pto.IN,      "IN");
    }

    //為日本資料雜訊額外撰寫的規則，碰到 01/01 這樣的會找前一個 subClass 來補
    private static Pattern rePatentIpcNormal4JPSubClass = Pattern.compile("^([A-Z])[\\s]*([0-9]{2})[\\s]*([A-Z])");
    private static Pattern rePatentIpcNormal4JPGroup = Pattern.compile("^([0-9]+)/([0-9]+)(.*$)");
    public static SolrPatentInfo Mongo2Solr(PatentInfo2 mongoInfo) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        SolrPatentInfo solrInfo = new SolrPatentInfo();

        solrInfo.ptopid = mongoInfo.pto.toString().toUpperCase() + "." + mongoInfo.id.toString().toLowerCase();

        solrInfo.id = mongoInfo.id.toString();

        solrInfo.pto = mongoInfo.pto.toString();

        solrInfo.country = mongoInfo.country.toUpperCase();

        fillDate(mongoInfo.appDate, solrInfo, "app");

        fillDate(mongoInfo.certificateDate, solrInfo, "certificate");

        fillDate(mongoInfo.decisionDate, solrInfo, "decision");

        fillDate(mongoInfo.examDate, solrInfo, "exam");

        fillDate(mongoInfo.openDate, solrInfo, "open");

        fillDate(mongoInfo.pctAppDate, solrInfo, "pctApp");

        fillDate(mongoInfo.pctOpenDate, solrInfo, "pctOpen");

        String country = ptoMap.get(mongoInfo.pto);
        if(country == "DOCDB") {
            country = mongoInfo.country;
        }

        fillNumber(mongoInfo.appNumber, solrInfo, "app", country, mongoInfo.kindcode);

        if(mongoInfo.type != "Reissue") {
            if(!isEmpty(mongoInfo.appNumber)) {
                solrInfo.appNumberGroup = (mongoInfo.country + mongoInfo.appNumber).toUpperCase();
            } else {
                solrInfo.appNumberGroup = solrInfo.ptopid;
            }
        }

        fillNumber(mongoInfo.certificateNumber, solrInfo, "certificate", country, mongoInfo.kindcode);

        fillNumber(mongoInfo.decisionNumber, solrInfo, "decision", country, mongoInfo.kindcode);

        fillNumber(mongoInfo.openNumber, solrInfo, "open", country, mongoInfo.kindcode);

        fillNumber(mongoInfo.patentNumber, solrInfo, "patent", country, mongoInfo.kindcode);

        fillNumber(mongoInfo.pctAppNumber, solrInfo, "pctApp", country, mongoInfo.kindcode);
        
        fillNumber(mongoInfo.pctOpenNumber, solrInfo, "pctOpen", country, mongoInfo.kindcode);

        if(!mongoInfo.pto.equals(Pto.KIPO)) {
            if(mongoInfo.mainCPC != null) {
                solrInfo.mainCPC = mongoInfo.mainCPC.toUpperCase();
                IpcInfo ipcInfo = normalizeIpcAndCpc(ClassificationType.CPC, solrInfo.mainCPC , solrInfo);
                solrInfo.mainCPCNormal = ipcInfo.ipcNormal;
                solrInfo.mainCPCClass = ipcInfo.clazz;
                solrInfo.mainCPCSubClass = ipcInfo.subClazz;
                solrInfo.mainCPCGroup = ipcInfo.group;
                solrInfo.mainCPCSubGroup = ipcInfo.subGroup;
            } else {
                solrInfo.mainCPC = mongoInfo.mainCPC;
            }
        }

        if(mongoInfo.mainIPC != null) {
            solrInfo.mainIPC = mongoInfo.mainIPC.toUpperCase();
            IpcInfo ipcInfo = normalizeIpcAndCpc(ClassificationType.IPC, solrInfo.mainIPC, solrInfo);
            solrInfo.mainIPCNormal = ipcInfo.ipcNormal;
            solrInfo.mainIPCClass = ipcInfo.clazz;
            solrInfo.mainIPCSubClass = ipcInfo.subClazz;
            solrInfo.mainIPCGroup = ipcInfo.group;
            solrInfo.mainIPCSubGroup = ipcInfo.subGroup;
        } else {
            solrInfo.mainIPC = mongoInfo.mainIPC;
        }

        if(mongoInfo.mainIPCR != null) {
            solrInfo.mainIPCR = mongoInfo.mainIPCR.toUpperCase();
            solrInfo.mainIPCRNormal = normalizeIpcAndCpc(ClassificationType.IPC, solrInfo.mainIPCR, solrInfo).ipcNormal;
        } else {
            solrInfo.mainIPCR = mongoInfo.mainIPCR;
        }

        if(mongoInfo.mainLOC != null) {
            LocInfo locInfo = normalizeLoc(mongoInfo.mainLOC.toUpperCase(), solrInfo);
            solrInfo.mainLOCClass = locInfo.clazz;
            solrInfo.mainLOC= locInfo.locNormal;
        } else {
            solrInfo.mainLOC = mongoInfo.mainLOC;
        }

        if(mongoInfo.mainUSPC != null) {
            solrInfo.mainUSPC = mongoInfo.mainUSPC.toUpperCase();
        } else {
            solrInfo.mainUSPC = mongoInfo.mainUSPC;
        }

        if(mongoInfo.mainFI != null) {
            //Matcher fiMatcher = rePatentFISubDivision.matcher(mongoInfo.mainFI);
            FiInfo fiInfo = normalizeFI(mongoInfo.mainFI.toUpperCase(), solrInfo);
            solrInfo.mainFI = fiInfo.fiNormal;
            solrInfo.mainFIClass = fiInfo.clazz;
            solrInfo.mainFISubClass = fiInfo.subClazz;
            solrInfo.mainFIGroup = fiInfo.group;
            solrInfo.mainFISubGroup = fiInfo.subGroup;
            solrInfo.mainFIAll = fiInfo.fiAll;
        } else {
            solrInfo.mainFI = mongoInfo.mainFI;
        }

        if(mongoInfo.mainFTerm != null) {
            solrInfo.mainFterm = mongoInfo.mainFTerm.toUpperCase();
        } else {
            solrInfo.mainFterm = mongoInfo.mainFTerm;
        }

        if(mongoInfo.mainDI != null) {
            solrInfo.mainDI = mongoInfo.mainDI.toUpperCase();
        } else {
            solrInfo.mainDI = mongoInfo.mainDI;
        }

        if(mongoInfo.mainDTerm != null) {
            solrInfo.mainDTerm = mongoInfo.mainDTerm.toUpperCase();
        } else {
            solrInfo.mainDTerm = mongoInfo.mainDTerm;
        }

        if(!mongoInfo.pto.equals(Pto.KIPO)) {
            if(mongoInfo.cpcs != null) {
                solrInfo.cpcs = upperCaseStrList(mongoInfo.cpcs);
                List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.CPC, solrInfo.cpcs, solrInfo);
                for(IpcInfo ipcInfo: ipcInfos) {
                    solrInfo.cpcsNormal.add(ipcInfo.ipcNormal);
                    solrInfo.cpcsClass.add(ipcInfo.clazz);
                    solrInfo.cpcsSubClass.add(ipcInfo.subClazz);
                    solrInfo.cpcsGroup.add(ipcInfo.group);
                    solrInfo.cpcsSubGroup.add(ipcInfo.subGroup);
                }
            }
        }

        if(mongoInfo.ipcs != null) {
            solrInfo.ipcs = upperCaseStrList(mongoInfo.ipcs);
            //only for JP case, ex: [H01L 29/784, 21/76] -> [H01L 29/784, H01L 21/76]
            if(mongoInfo.pto.equals(Pto.JPO)) {
                String ipcSubClass = "";
                for(int i = 0; i< solrInfo.ipcs.size();i++) {
                    Matcher matcher4JPSubClass = rePatentIpcNormal4JPSubClass.matcher(solrInfo.ipcs.get(i));
                    if(matcher4JPSubClass.find()) {
                        ipcSubClass = matcher4JPSubClass.group(1) + matcher4JPSubClass.group(2) + matcher4JPSubClass.group(3);
                    } else if (rePatentIpcNormal4JPGroup.matcher(solrInfo.ipcs.get(i)).find()){
                        solrInfo.ipcs.set(i, ipcSubClass + " " + solrInfo.ipcs.get(i));
                    }
                }
            }
            List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.IPC, solrInfo.ipcs, solrInfo);
            for(IpcInfo ipcInfo: ipcInfos) {
                solrInfo.ipcsNormal.add(ipcInfo.ipcNormal);
                solrInfo.ipcsClass.add(ipcInfo.clazz);
                solrInfo.ipcsSubClass.add(ipcInfo.subClazz);
                solrInfo.ipcsGroup.add(ipcInfo.group);
                solrInfo.ipcsSubGroup.add(ipcInfo.subGroup);
            }
        }

        if(mongoInfo.ipcrs != null) {
            solrInfo.ipcrs = upperCaseStrList(mongoInfo.ipcrs);
            List<IpcInfo> ipcInfos = normalizeIpcsAndCpcs(ClassificationType.IPC, solrInfo.ipcrs, solrInfo);
            for(IpcInfo ipcInfo: ipcInfos) {
                solrInfo.ipcrsNormal.add(ipcInfo.ipcNormal);
            }
        }

        if(mongoInfo.locs != null) {
            List<LocInfo> loccInfos = normalizeLocs(upperCaseStrList(mongoInfo.locs), solrInfo);
            for(LocInfo loccInfo: loccInfos) {
                solrInfo.locs.add(loccInfo.locNormal);
                solrInfo.locsClass.add(loccInfo.clazz);
            }
        }

        if(mongoInfo.uspcs != null) {
            solrInfo.uspcs = upperCaseStrList(mongoInfo.uspcs);
        }

        if(mongoInfo.fis != null) {
            //only for JP case, ex: [H01L 29/784, 21/76] -> [H01L 29/784, H01L 21/76]
            solrInfo.fis = upperCaseStrList(mongoInfo.fis);
            String fiSubClass = "";
            for(int i = 0; i< solrInfo.fis.size();i++) {
                Matcher matcher4JPSubClass = rePatentIpcNormal4JPSubClass.matcher(solrInfo.fis.get(i));
                if(matcher4JPSubClass.find()) {
                    fiSubClass = matcher4JPSubClass.group(1) + matcher4JPSubClass.group(2) + matcher4JPSubClass.group(3);
                } else if (rePatentIpcNormal4JPGroup.matcher(solrInfo.fis.get(i)).find()){
                    solrInfo.fis.set(i, fiSubClass + " " + solrInfo.fis.get(i));
                }
            }
            List<FiInfo> fiInfos = normalizeFis(solrInfo.fis, solrInfo);
            solrInfo.fis = new ArrayList<String>();
            for(FiInfo fiInfo: fiInfos) {;
                solrInfo.fis.add(fiInfo.fiNormal);
                solrInfo.fisClass.add(fiInfo.clazz);
                solrInfo.fisSubClass.add(fiInfo.subClazz);
                solrInfo.fisGroup.add(fiInfo.group);
                solrInfo.fisSubGroup.add(fiInfo.subGroup);
                solrInfo.fisAll.addAll(fiInfo.fiAll);
            }
        }

        if(mongoInfo.fterms != null) {
            solrInfo.fterms = upperCaseStrList(mongoInfo.fterms);
        }

        if(mongoInfo.dis != null) {
            solrInfo.dis = upperCaseStrList(mongoInfo.dis);
        }

        if(mongoInfo.dterms != null) {
            solrInfo.dterms = upperCaseStrList(mongoInfo.dterms);
        }

        if(mongoInfo.eclas != null) {
            solrInfo.eclas = upperCaseStrList(mongoInfo.eclas);
        }

        for (Person person : mongoInfo.agents) {
            fillPerson(person, solrInfo, "agents");
        }

        for (Person person : mongoInfo.agentOperators) {
            fillPerson(person, solrInfo, "agentOperators");
        }

        for (Person person : mongoInfo.applicants) {
            fillPerson(person, solrInfo, "applicants");
        }

        for (Person person : mongoInfo.assignees) {
            fillPerson(person, solrInfo, "assignees");
        }

        //USPTO add original assignee to current assignee
        if(mongoInfo.pto == Pto.USPTO) {
            solrInfo.currentAssigneesName = (ArrayList<String>)solrInfo.assigneesName.clone();
            solrInfo.currentAssigneesFacetname = (ArrayList<String>)solrInfo.assigneesFacetname.clone();
        }

        for (Person person : mongoInfo.docdbAssignees) {
            fillPerson(person, solrInfo, "docdbAssignees");
        }

        for (Person person : mongoInfo.docdbaAssignees) {
            fillPerson(person, solrInfo, "docdbaAssignees");
        }

        for (Person person : mongoInfo.inventors) {
            fillPerson(person, solrInfo, "inventors");
        }

        for (Person person : mongoInfo.docdbInventors) {
            fillPerson(person, solrInfo, "docdbInventors");
        }

        for (Person person : mongoInfo.docdbaInventors) {
            fillPerson(person, solrInfo, "docdbaInventors");
        }

        for (Person person : mongoInfo.examinerMasters) {
            fillPerson(person, solrInfo, "examinerMasters");
        }

        for (Person person : mongoInfo.examinerSlaves) {
            fillPerson(person, solrInfo, "examinerSlaves");
        }

        solrInfo.filePageClaim = mongoInfo.filePageClaim;
        solrInfo.filePageDesc = mongoInfo.filePageDesc;
        solrInfo.filePageFig = mongoInfo.filePageFig;
        solrInfo.filePageFirst = mongoInfo.filePageFirst;
        solrInfo.filePageNumber = mongoInfo.filePageNumber;
        solrInfo.gazettePageNumber = mongoInfo.gazettePageNumber;
        solrInfo.clipPageNumber = mongoInfo.clipPageNumber;
        solrInfo.figurePageNumber = mongoInfo.figurePageNumber;
        solrInfo.firstImagePageFlag = mongoInfo.firstImagePageFlag;

        for (String otherReferences : mongoInfo.otherReferences) {
            addUnique(solrInfo.otherReferences, otherReferences);
        }

        for (RelatedPatent pat : mongoInfo.priorityPatents) {
            if(pat.appNumber!=null) {
                addUnique(solrInfo.priorityPatentsNumberAll, pat.appNumber);
            } else {
                addUnique(solrInfo.priorityPatentsNumberAll, pat.patentNumber);
            }
            solrInfo.priorityPatents.add(pat.toString().replaceAll("\"pto\"", "\"country\""));
        }

        for (RelatedPatent pat : mongoInfo.citedPatents) {
            addUnique(solrInfo.citedPatentsNumberAll, pat.patentNumber);
            solrInfo.citedPatents.add(pat.toString().replaceAll("\"pto\"", "\"country\""));
        }

        for (RelatedPatent pat : mongoInfo.relatedPatents) {
            solrInfo.relatedPatents.add(pat.toString().replaceAll("\"pto\"", "\"country\""));
            if(pat.relation !=null && pat.relation.equals("ReissueOf")) {
                solrInfo.appNumberGroup = (mongoInfo.country + pat.appNumber).toUpperCase();
            }
        }

        if(mongoInfo.dividedPatent != null) {
            solrInfo.dividedPatent = mongoInfo.dividedPatent.toString().replaceAll("\"pto\"", "\"country\"");
        }

        if(mongoInfo.kindcode == null) {
            solrInfo.kindcode = "";
        } else {
            solrInfo.kindcode = mongoInfo.kindcode.toUpperCase();
        }
        
        solrInfo.type = mongoInfo.type;
        if(mongoInfo.pto.equals(Pto.WIPO) || mongoInfo.pto.equals(Pto.EPO)) {
            solrInfo.type = "Utility";
        }
        if(!isEmpty(solrInfo.type)) {
            solrInfo.typeCode = getTypeCode(solrInfo.type);
        }

        if(mongoInfo.stat != 3) {
            solrInfo.stats = new Integer[1];
            solrInfo.stats[0] = mongoInfo.stat;
        } else {
            solrInfo.stats = new Integer[2];
            solrInfo.stats[0] = 1;
            solrInfo.stats[0] = 2;
        }

        solrInfo.familyId = mongoInfo.familyId;
        if(mongoInfo.familyId != null) {
            solrInfo.familyIdGroup = mongoInfo.familyId.toString().toUpperCase();
        } else {
            String familyId = solrInfo.appNumberGroup;
            if (isEmpty(familyId)) {
                familyId = solrInfo.ptopid;
            }
            solrInfo.familyIdGroup = familyId.toUpperCase();
        }

        if(!isEmpty(mongoInfo.brief)) {
            solrInfo.brief = getMultiLang(mongoInfo.brief, "");
        }

        if(!isEmpty(mongoInfo.claim)) {
            solrInfo.claim = getMultiLang(mongoInfo.claim, "");
        }

        if(!isEmpty(mongoInfo.description)) {
            solrInfo.description = getMultiLang(mongoInfo.description, "");
        }

        if(!isEmpty(mongoInfo.title)) {
            solrInfo.title = getMultiLang(mongoInfo.title, "");
        }

        fillDate(mongoInfo.doDate, solrInfo, "do");
        fillDate(mongoInfo.docdbDoDate, solrInfo, "docdbDo");

        solrInfo.truncate = mongoInfo.truncate;

        return solrInfo;
    }

    protected static ArrayList<IpcInfo> normalizeIpcsAndCpcs(Enum<ClassificationType> classificationType, List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<IpcInfo> IpcInfos = new ArrayList<IpcInfo>();
        for(String pc: pcs) {
            IpcInfos.add(normalizeIpcAndCpc(classificationType, pc, solrInfo));
        }
        return IpcInfos;
    }

    //pattern original ipc or cpc format
    private static Pattern rePatentIpcAndCpc1 = Pattern.compile("^([A-Z])([0-9]{2})([A-Z])[\\s]*([0-9]+)/{1,2}([0-9]+)(.*$)");
    //for special case like "C 10 M 1/ 7/12"
    private static Pattern rePatentIpcAndCpc2 = Pattern.compile("^([A-Z])[\\s]+([0-9]{2})[\\s]+([A-Z])[\\s]+([0-9]+)/[\\s]+([0-9]+)/([0-9]+)");
    //pattern for ipc format after normalize
    private static Pattern rePatentIpcAndCpcNormal = Pattern.compile("^([A-Z])([0-9]{2})([A-Z])([0-9]{4})([0-9]{6})");
    protected static IpcInfo normalizeIpcAndCpc(Enum<ClassificationType> classificationType, String pc, SolrPatentInfo solrInfo) {
        IpcInfo ipcInfo = new IpcInfo();

        Matcher matcher1 = rePatentIpcAndCpc1.matcher(pc);
        if(matcher1.find()) {
            String section = matcher1.group(1);
            String clazz = matcher1.group(2);
            String subClazz = matcher1.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher1.group(4)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher1.group(5)).replace(' ', '0');

            ipcInfo.clazz = section + clazz;
            ipcInfo.subClazz = ipcInfo.clazz + subClazz;
            ipcInfo.group = ipcInfo.subClazz + group;
            String subGroupVal = IpcCpcFinder.getSubGroup(classificationType, ipcInfo.group + subGroupOri);
            if(subGroupVal != null) {
                ipcInfo.subGroup = subGroupVal;
            }
            ipcInfo.ipcNormal = ipcInfo.group + subGroupOri;
            String mainGroupVal = IpcCpcFinder.getMainGroup(classificationType, ipcInfo.group + subGroupOri);
            if(mainGroupVal != null) {
                ipcInfo.group = mainGroupVal;
            } else {
                ipcInfo.group = ipcInfo.group + "000000";
            }
            return ipcInfo;
        }
        
        Matcher matcherNormal = rePatentIpcAndCpcNormal.matcher(pc);
        if (matcherNormal.find()){
            String section = matcherNormal.group(1);
            String clazz = matcherNormal.group(2);
            String subClazz = matcherNormal.group(3);
            String group = matcherNormal.group(4);
            String subGroupOri = matcherNormal.group(5);

            ipcInfo.clazz = section + clazz;
            ipcInfo.subClazz = ipcInfo.clazz + subClazz;
            ipcInfo.group = ipcInfo.subClazz + group;
            String subGroupVal = IpcCpcFinder.getSubGroup(classificationType, ipcInfo.group + subGroupOri);
            if(subGroupVal != null) {
                ipcInfo.subGroup = subGroupVal;
            }
            ipcInfo.ipcNormal = ipcInfo.group + subGroupOri;
            String mainGroupVal = IpcCpcFinder.getMainGroup(classificationType, ipcInfo.group + subGroupOri);
            if(mainGroupVal != null) {
                ipcInfo.group = mainGroupVal;
            } else {
                ipcInfo.group = ipcInfo.group + "000000";
            }
            return ipcInfo;
        }

        Matcher matcher2 = rePatentIpcAndCpc2.matcher(pc);
        if(matcher2.find()) {
            String section = matcher2.group(1);
            String clazz = matcher2.group(2);
            String subClazz = matcher2.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher2.group(4) + matcher2.group(5)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher2.group(6)).replace(' ', '0');

            ipcInfo.clazz = section + clazz;
            ipcInfo.subClazz = ipcInfo.clazz + subClazz;
            ipcInfo.group = ipcInfo.subClazz + group;
            String subGroupVal = IpcCpcFinder.getSubGroup(classificationType, ipcInfo.group + subGroupOri);
            if(subGroupVal != null) {
                ipcInfo.subGroup = subGroupVal;
            }
            ipcInfo.ipcNormal = ipcInfo.group + subGroupOri;
            String mainGroupVal = IpcCpcFinder.getMainGroup(classificationType, ipcInfo.group + subGroupOri);
            if(mainGroupVal != null) {
                ipcInfo.group = mainGroupVal;
            } else {
                ipcInfo.group = ipcInfo.group + "000000";
            }
            return ipcInfo;
        }
        solrInfo.isPcNormal = false;
        ipcInfo.ipcNormal = pc;
        return ipcInfo;
    }

    protected static ArrayList<FiInfo> normalizeFis(List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<FiInfo> fiInfos = new ArrayList<FiInfo>();
        for(String pc: pcs) {
            fiInfos.add(normalizeFI(pc, solrInfo));
        }
        return fiInfos;
    }

    //日本 fi
    private static Pattern rePatentFI = Pattern.compile("^([A-Z])[\\s]*([0-9]{2})[\\s]*([A-Z])[\\s]*([0-9]+)/([0-9]+)[\\s]*(.*)");
    //"G01F 21/01 301" or "G01F 21/01 301 A"
    private static Pattern rePatentFISubDivision = Pattern.compile("^([0-9]{3})\\s*([A-Z]?)");
    //"G01F 21/01 A"
    private static Pattern rePatentFIFileDiscrimination = Pattern.compile("^([A-Z])");
    protected static FiInfo normalizeFI(String pc, SolrPatentInfo solrInfo) {
        FiInfo fiInfo = new FiInfo();
        fiInfo.fiAll = new ArrayList<String>();
        Matcher matcher = rePatentFI.matcher(pc);
        if(matcher.find()) {
            String section = matcher.group(1);
            String clazz = matcher.group(2);
            String subClazz = matcher.group(3);
            String group = String.format("%04d", Integer.parseInt(matcher.group(4)));
            String subGroupOri = String.format("%1$-" + 6 + "s", matcher.group(5)).replace(' ', '0');
            String others = matcher.group(6);

            fiInfo.clazz = section + clazz;
            fiInfo.subClazz = fiInfo.clazz + subClazz;
            fiInfo.group = fiInfo.subClazz + group;
            String subGroupVal = IpcCpcFinder.getSubGroup(ClassificationType.IPC, fiInfo.group + subGroupOri);
            if(subGroupVal != null) {
                fiInfo.subGroup = subGroupVal;
            }
            fiInfo.fiNormal = fiInfo.group + subGroupOri;
            fiInfo.fiAll.add(fiInfo.fiNormal);
            Matcher fiMatcher1 = rePatentFISubDivision.matcher(others);
            if(fiMatcher1.find()) {
                if(!fiMatcher1.group(2).isEmpty()) {
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1) + fiMatcher1.group(2));
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1));
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(2));
                    fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher1.group(1) + fiMatcher1.group(2);
                } else {
                    fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher1.group(1));
                    fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher1.group(1);
                }
            }
            Matcher fiMatcher2 = rePatentFIFileDiscrimination.matcher(others);
            if(fiMatcher2.find()) {
                fiInfo.fiAll.add(fiInfo.fiNormal + fiMatcher2.group(1));
                fiInfo.fiNormal = fiInfo.fiNormal + fiMatcher2.group(1);
            }
            fiInfo.group = fiInfo.group + "000000";
            return fiInfo;
        }
        
        solrInfo.isPcNormal = false;
        fiInfo.fiNormal = pc;
        return fiInfo;
    }

    protected static ArrayList<LocInfo> normalizeLocs(List<String> pcs, SolrPatentInfo solrInfo) {
        ArrayList<LocInfo> LocInfos = new ArrayList<LocInfo>();
        for(String pc: pcs) {
            LocInfos.add(normalizeLoc(pc, solrInfo));
        }
        return LocInfos;
    }

    private static Pattern rePatentLoc1 = Pattern.compile("^([0-9]{1,2})([\\s/-−]0?)([0-9]{1,2})(.*$)");
    //for 0805/
    private static Pattern rePatentLoc2 = Pattern.compile("^([0-9]{1,2})([0-9]{1,2})/");
    protected static LocInfo normalizeLoc(String loc, SolrPatentInfo solrInfo) {
        LocInfo locInfo = new LocInfo();

        Matcher matcher1 = rePatentLoc1.matcher(loc);
        if(matcher1.find()) {
            String clazz = String.format("%02d", Integer.parseInt(matcher1.group(1)));
            String subClazz = String.format("%02d", Integer.parseInt(matcher1.group(3)));


            locInfo.clazz = clazz;
            locInfo.locNormal = clazz + "-" + subClazz;
            return locInfo;
        }

        Matcher matcher2 = rePatentLoc2.matcher(loc);
        if(matcher2.find()) {
            String clazz = String.format("%02d", Integer.parseInt(matcher2.group(1)));
            String subClazz = String.format("%02d", Integer.parseInt(matcher2.group(2)));

            locInfo.clazz = clazz;
            locInfo.locNormal = clazz + "-" + subClazz;
            return locInfo;
        }

        solrInfo.isPcNormal = false;
        locInfo.locNormal = loc;
        return locInfo;
    }

    protected static ArrayList<String> upperCaseStrList(List<String> list) {
        ArrayList<String> upperList = new ArrayList<String>();
        for(String str : list)
        {
            upperList.add(str);
        }
        return upperList;
    }

    protected static boolean isEmpty(String value) {
        if (value == null) {
            return true;
        }
        if (value.trim().isEmpty()) {
            return true;
        }
        return false;
    }

    protected static boolean isEmpty(MultiLangString value) {
        if (value == null) {
            return true;
        }
        return isEmpty(getMultiLang(value, null));
    }

    protected static void addUnique(List<String> field, String value) {
        if (isEmpty(value)) {
            return;
        }
        if (!field.contains(value)) {
            field.add(value);
        }
    }

    protected static String genString(String... args) {
        StringBuffer sb = new StringBuffer();
        for (String s : args) {
            if (!isEmpty(s)) {
                sb.append(s);
            }
        }
        return sb.toString();
    }

    protected static String getMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        String ret = data.toDBObject().toString();
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    protected static Class<?> clazz = MultiLangString.class;
    protected static String getPersonNameMultiLang(MultiLangString data, String defValue) {
        if (data == null) {
            return defValue;
        }
        data = MultiLangString.fromObject(MultiLangString.class, data);
        data.filter(new LangFilter() {
            @Override
            public String filter(String lang, String value, MultiLangString context) {
                return value.toLowerCase().replaceAll("[\\s`~!@#$%^&*()\\-_=+\\[{\\]};:'\",<.>/?]+", "");
            }
        });

        String ret = data.toDBObject().toString();
        if (ret == null) {
            return defValue;
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    protected static void fillPerson(Person person, SolrPatentInfo solr, String solrFieldName) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        if (person == null) {
            return;
        }

        //為了解決 facet search bug 的治標方法，強行將語系都轉成 origin，避免 facet search 因為語系不同分成不同組
        //目前應該只有 WIPO 和 DOCDB 會遇到此問題
        if(person.name != null && person.name.origin == null && person.name.toDBObject().keySet().size() == 1) {
            String lang = person.name.toDBObject().keySet().iterator().next();
            Field field = clazz.getField(lang);
            String value = (String) field.get(person.name);
            person.name.origin = value;
            field.set(person.name, null);
        }

        try {
            Field fperson = solr.getClass().getField(solrFieldName);
            ArrayList<String> pperson = (ArrayList<String>) fperson.get(solr);
            if(person != null) {
                pperson.add(person.toString());
            }

            Field ffacetname = solr.getClass().getField(solrFieldName + "Facetname");
            ArrayList<String> pfacetname = (ArrayList<String>) ffacetname.get(solr);
            if(!isEmpty(getPersonNameMultiLang(person.name, null))) {
                pfacetname.add(getPersonNameMultiLang(person.name, null));
            }

            if(solrFieldName.startsWith("docdba")) {
                solrFieldName = solrFieldName.replaceAll("docdba", "").toLowerCase();
            } else if(solrFieldName.startsWith("docdb")) {
                solrFieldName = solrFieldName.replaceAll("docdb", "").toLowerCase();
            }
            Field fname = solr.getClass().getField(solrFieldName + "Name");
            ArrayList<String> pname = (ArrayList<String>) fname.get(solr);
            if(!isEmpty(person.name)) {
                pname.add(getMultiLang(person.name, null));
            }

            Field faddress = solr.getClass().getField(solrFieldName + "Address");
            ArrayList<String> paddress = (ArrayList<String>) faddress.get(solr);
            if(!isEmpty(person.name)) {
                paddress.add(getMultiLang(person.address, null));
            }

            Field fcountry = solr.getClass().getField(solrFieldName + "Country");
            ArrayList<String> pcountry = (ArrayList<String>) fcountry.get(solr);
            if(!isEmpty(person.name) && person.country != null) {
                //國家代碼不分語言，抓第一個值
                Iterator<String> it = person.country.toDBObject().keySet().iterator();
                while (it.hasNext()) {
                    String lang = it.next();
                    Field field = clazz.getField(lang);
                    String value = (String) field.get(person.country);
                    if(!isEmpty(value)) {
                        pcountry.add(value);
                        break;
                    }
                }
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    protected static void fillDate(Date date, SolrPatentInfo solr, String solrFieldName) {
        if (date == null) {
            return;
        }

        try {
            Field fdate = solr.getClass().getField(solrFieldName + "Date");
            fdate.set(solr, date);

            Field fdateYear = solr.getClass().getField(solrFieldName + "Year");
            SimpleDateFormat fmtYear = new SimpleDateFormat("yyyy");
            fdateYear.set(solr, Integer.parseInt(fmtYear.format(date)));

            Field fdateYearMon = solr.getClass().getField(solrFieldName + "Yearmon");
            SimpleDateFormat fmtYearMon = new SimpleDateFormat("yyyyMM");
            fdateYearMon.set(solr, Integer.parseInt(fmtYearMon.format(date)));
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

    protected static int getTypeCode(String type) {
        int typeCode = 0;
        List<String> type1 = new ArrayList<String>();
        type1.add("Utility");
        type1.add("发明专利");
        type1.add("發明");
        type1.add("특허");
        type1.add("特許");

        List<String> type2 = new ArrayList<String>();
        type2.add("实用新型");
        type2.add("新型");
        type2.add("실용신안");
        type2.add("実用新案");
        type2.add("Model");

        List<String> type3 = new ArrayList<String>();
        type3.add("Design");
        type3.add("外观专利");
        type3.add("設計");
        type3.add("디자인");
        type3.add("意匠公報");

        List<String> type4 = new ArrayList<String>();
        type4.add("Plant");

        List<String> type5 = new ArrayList<String>();
        type5.add("Reissue");

        List<String> type6 = new ArrayList<String>();
        type6.add("SIR");

        List<String> type7 = new ArrayList<String>();
        type7.add("公表");
        type7.add("再公表");

        List<String> type9 = new ArrayList<String>();
        type9.add("Others");

        Hashtable typeHash = new Hashtable();
        typeHash.put(type1, 1);
        typeHash.put(type2, 2);
        typeHash.put(type3, 3);
        typeHash.put(type4, 4);
        typeHash.put(type5, 5);
        typeHash.put(type6, 6);
        typeHash.put(type7, 7);
        typeHash.put(type9, 9);

        Enumeration en = typeHash.keys();
        while (en.hasMoreElements()) {
            List list = (List) en.nextElement();
            if(list.contains(type)) {
                typeCode = (int)typeHash.get(list);
            }
        }
        return typeCode;
    }

    // US1: US008295630 US00D242762 US000PP3994 US00RE28691 US0000H1443
    private static Pattern rePatentNumberUS1 = Pattern.compile("^(US)?0*((D|PP|RE|H|T)?\\d+)$");
    // US2: 12/575,551
    private static Pattern rePatentNumberUS2 = Pattern.compile("^(US)?(\\d+)/(\\d*),?(\\d*)$");
    // US3: 20040095078 2004095078, EPDOC use secondary
    private static Pattern rePatentNumberUS3 = Pattern.compile("^(\\d{4})0(\\d{6})$");
    // TW1: 079100883 I319544 M363691 D138757
    private static Pattern rePatentNumberTW1 = Pattern.compile("^(TW)?0*((I|M|D)?\\d+)$");
    // CN1: 200810306395.2 CN200810306395
    private static Pattern rePatentNumberCN1 = Pattern.compile("^(CN)?(\\d{12})(\\.\\S+)?$");
    // CN2: CN101751575A 101751575 
    private static Pattern rePatentNumberCN2 = Pattern.compile("^(CN)?(\\d{7,9})(\\D)?$");

    private static Pattern rePatentNumberTail = Pattern.compile("^(\\S+)(\\d\\d\\d)$");
    // added by yiyun for WO 2013/10/31        WO: WO 2012/000001
    private static Pattern rePatentNumberWO = Pattern.compile("^WO(\\s)(\\d{4})/(\\d{6})$");
    // added by yiyun for WO 2014/04/08     APN: PCT/US2007/022037
    private static Pattern rePatentNumberWO1 = Pattern.compile("^PCT/(\\w{6})/0?(\\d*)$");
    // added by yh
    // EP1: appNo: 11165961.1
    private static Pattern rePatentNumberEP1 = Pattern.compile("^(\\d{8})(\\.\\S+)?$");
    // EP2: pn/openNo : EP2398401
    private static Pattern rePatentNumberEP2 = Pattern.compile("^(EP)(\\d{7})?$");
    //added by luken 20131109
    private static Pattern rePatentNumberKR1 = Pattern.compile("^(\\d{13})?$");
    //added end

    @SuppressWarnings("unchecked")
    protected static void fillNumber(String number, SolrPatentInfo solr, String solrFieldName, 
                                        String country, String kindcode) {
        if (isEmpty(number)) {
            return;
        }

        ArrayList<String> numberall = new ArrayList<>();
        numberall.add(number);

        String fix;
        Matcher matcher;

        matcher = rePatentNumberUS1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberUS2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);

            fix = genString(matcher.group(3), matcher.group(4));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberUS3.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberTW1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberCN1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }

        matcher = rePatentNumberCN2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }
        
        // added by yiyun for WO 2013/10/31
        matcher = rePatentNumberWO.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2), "/", matcher.group(3));
            addUnique(numberall, fix);

            fix = genString(matcher.group(2), matcher.group(3));
            addUnique(numberall, fix);
        }
        // added by yiyun for WO 2014/04/08
        matcher = rePatentNumberWO1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
            
            fix = genString("PCT/", matcher.group(1), "/", matcher.group(2));
            addUnique(numberall, fix);
        }
        
        // added by yh
        matcher = rePatentNumberEP1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);

            fix = genString(matcher.group(1), matcher.group(2));
            addUnique(numberall, fix);
        }
        
        matcher = rePatentNumberEP2.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(2));
            addUnique(numberall, fix);
        }
        // add end
        
        //added by luken 20131129
        matcher = rePatentNumberKR1.matcher(number);
        if (matcher.find()) {
            fix = genString(matcher.group(1));
            addUnique(numberall, fix);
        }
        
        //added end
        
        // added by hanyao 20140624
        if (country.contains("JP")) {
            if (number.contains("(") || number.contains(")")) {
                String temNumber = number.substring(0, number.indexOf("("));
                addUnique(numberall, temNumber);
            }
            String regx = "\\d{1,}-?\\d{1,}";
            Pattern reNumberJP = Pattern.compile(regx);
            matcher = reNumberJP.matcher(number);
            if (matcher.find()) {
                String temp = matcher.group(0);
                if (temp.contains("-")) {
                    String preTemp = temp.substring(0, temp.indexOf("-"));
                    String aftTemp = temp.substring(temp.indexOf("-") + 1);
                    if (preTemp.length() < 2) {
                        preTemp = "0" + preTemp;
                    }
                    temp = preTemp + "-" + aftTemp;
                    addUnique(numberall, temp);
                    if (aftTemp.length() < 6) {
                        int i = 6 - aftTemp.length();
                        switch (i) {
                        case 1:
                            aftTemp = "0" + aftTemp;
                            break;
                        case 2:
                            aftTemp = "00" + aftTemp;
                            break;
                        case 3:
                            aftTemp = "000" + aftTemp;
                            break;
                        case 4:
                            aftTemp = "0000" + aftTemp;
                            break;
                        case 5:
                            aftTemp = "00000" + aftTemp;
                            break;
                        }
                        temp = preTemp + "-" + aftTemp;
                        addUnique(numberall, temp);
                    }
                    String num = temp.substring(temp.indexOf("-") + 1);
                    String year = temp.substring(0,temp.indexOf("-"));
                    String jpNum = "";
                    int j = Integer.parseInt(num);
                    num = j + "";
                    num = temp.substring(0, temp.indexOf("-") + 1) + num;
                    addUnique(numberall, num);
                    addUnique(numberall, "JP" + num);
                    if (number.contains("平")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1988) + temp.substring(temp.indexOf("-"));
                        num = "H" + num;
                        temp = "H" + temp;
                        //addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    if (number.contains("昭")) {
                        int i = Integer.parseInt(year);
                        jpNum = "" + (i + 1925) + temp.substring(temp.indexOf("-"));
                        num = "S" + num;
                        temp = "S" + temp;
                        //addUnique(numberall, "JP" + jpNum);
                        addUnique(numberall, jpNum);
                    }
                    //addUnique(numberall, "JP" + num);
                    //addUnique(numberall, "JP" + temp);
                    addUnique(numberall, temp);
                    addUnique(numberall, num);
                } else {
                    addUnique(numberall, temp);
                    //addUnique(numberall, "JP" + temp);
                }
            }
        }

        //Add country + to number
        for (String n : (ArrayList<String>) numberall.clone()) {
            if (!n.startsWith(country)) {
                fix = country + n;
                addUnique(numberall, fix);
            }
        }

        //besides appNumber, add kindcode to all number's tail
        if(!solrFieldName.contains("appNumber") && kindcode != null) {
            for (String n : (ArrayList<String>) numberall.clone()) {
                if (!n.endsWith(kindcode)) {
                    fix = n + kindcode;
                    addUnique(numberall, fix);
                }
            }
        }
        try {
            if(solrFieldName.contains("decision")) {
                number = number.replaceAll("^(US)0*", "");
            }
            Field fnumber = solr.getClass().getField(solrFieldName + "Number");
            fnumber.set(solr, number);
            if(!solrFieldName.contains("patent")) {
                Field fnumberall = solr.getClass().getField(solrFieldName + "NumberAll");
                fnumberall.set(solr, numberall);
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
    }

}
