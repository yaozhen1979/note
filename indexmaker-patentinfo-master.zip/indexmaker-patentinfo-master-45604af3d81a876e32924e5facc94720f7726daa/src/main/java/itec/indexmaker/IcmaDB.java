package itec.indexmaker;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

public class IcmaDB {

    static Log log = LogFactory.getLog(IcmaDB.class);

    public static final String config_dbsite = "icma.db.site";
    public static final String config_dbsite_default = "tpe01";

    public static final ArgParser.Option[] opts = {
        new ArgParser.Option(null, config_dbsite
            , true, config_dbsite_default, ""),
    };

    public static final Class<?>[] optDep = {
    };

    private static Connection conn = null;
    public static Connection getConnection() throws ClassNotFoundException {
        if (conn == null) {
            int connRetry = 0;
            String dbsite = ConfigUtils.get(config_dbsite, config_dbsite_default);
            String url = ConfigUtils.get("db." + dbsite + ".url");
            String user = ConfigUtils.get("db." + dbsite + ".user");
            String password = ConfigUtils.get("db." + dbsite + ".password");
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            log.debug("DB connect to " + url);
            while (++connRetry <= 24) {
                try {
                    conn = DriverManager.getConnection(url, user, password);
                    return conn;
                } catch (SQLException e) {
                    e.printStackTrace();
                    try {
                        Thread.sleep(5*60*1000);
                    } catch (InterruptedException e1) {
                        e1.printStackTrace();
                    }
                    log.debug("Retry");
                }
            }
        }

        return conn;
    }

}
