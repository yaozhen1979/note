package itec.indexmaker;

import itec.patent.common.DateUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.ConcurrentUpdateSolrServer;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.common.SolrInputDocument;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Bytes;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class CurAssigneeInfoSolrIndex {

    public static final String opt_solr_url = "solr.url";
    public static final String opt_solr_url_default = "http://10.62.41.134:5566/solr/us";

    public static final String opt_mongo_ip = "mongo.ip";
    public static final String opt_mongo_ip_default = "10.60.90.121";

    public static final String opt_date_range = "date.range";
    public static final String opt_date_range_default = "19000101-20151231";

    public static final String bucket_size = "bucket.size";
    public static final String bucket_size_default = "100";

    public static final String start_point = "start.point";
    public static final String start_point_default = "0";

    public static final String process_count = "process.count";
    public static final String process_count_default = "100";

    static Log log = LogFactory.getLog(CurAssigneeInfoSolrIndex.class);

    private static void setUpdateValue(SolrInputDocument sdoc, Object value, 
        String fieldName) throws IllegalArgumentException, IllegalAccessException {
        Map partialUpdate = new HashMap();
        if(value != null) {
            partialUpdate.put("set", value);
            sdoc.addField(fieldName, partialUpdate);
        }
    }

    private static void appendUpdateValue(SolrInputDocument sdoc, Object value, 
            String fieldName) throws IllegalArgumentException, IllegalAccessException {
            Map partialUpdate = new HashMap();
            if(value != null) {
                partialUpdate.put("add", value);
                sdoc.addField(fieldName, partialUpdate);
            }
        }

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_solr_url, true, opt_solr_url_default, ""),
        new ArgParser.Option(null, opt_mongo_ip, true, opt_mongo_ip_default, ""),
        new ArgParser.Option(null, opt_date_range, true, opt_date_range_default, ""),
        new ArgParser.Option(null, bucket_size, true, bucket_size_default, ""),
        new ArgParser.Option(null, start_point, true, start_point_default, ""),
        new ArgParser.Option(null, process_count, true, process_count_default, "")};

    public static void main(String[] args) throws ParseException, SolrServerException, IOException, IllegalArgumentException, IllegalAccessException {
        ArgParser argParser = new ArgParser().addOpt(CurAssigneeInfoSolrIndex.class).parse(args);

        String solrur = argParser.getOptString(opt_solr_url);
        String mongoip = argParser.getOptString(opt_mongo_ip);
        String daterange = argParser.getOptString(opt_date_range);
        int bucketSize = Integer.parseInt(argParser.getOptString(bucket_size));
        int startPoint = Integer.parseInt(argParser.getOptString(start_point));
        int processCount = Integer.parseInt(argParser.getOptString(process_count));
        ConcurrentUpdateSolrServer solrindex = 
                new ConcurrentUpdateSolrServer(solrur, bucketSize, 1);
        HttpSolrServer solr = new HttpSolrServer(solrur);

        MongoCredential credential = MongoCredential.createCredential("patentdata", "admin", "data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress(mongoip), Arrays.asList(credential));
        DB db = mongoClient.getDB("admin").getSisterDB("USPTO_CurrentAssignee_Lab");
        DB patdb = mongoClient.getDB("admin").getSisterDB("PatentInfoUSPTO");
        DBCollection col = db.getCollection("USPTO_CurrentAssignee_Lab");
        DBCollection patcol = patdb.getCollection("PatentInfoUSPTO");
        QueryHelp dateRangeQuery = new QueryHelp();
        dateRangeQuery.filter("$gte", DateUtils.parseDate(daterange.split("-")[0]));
        dateRangeQuery.filter("$lte", DateUtils.parseDate(daterange.split("-")[1]));
        QueryHelp query = new QueryHelp();
        query.filter("update_log", dateRangeQuery);

        //QueryHelp query = new QueryHelp();
        //query.filter("app_number", "13/888165");
        
        DBCursor cursor = col.find(query).limit(processCount).addOption(Bytes.QUERYOPTION_NOTIMEOUT);
        cursor.skip(startPoint);
        log.debug(query);
        log.info("total " + cursor.size());
        ProcessEstimater pe = new ProcessEstimater(cursor.size()).setFormatDefNum();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        while(cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            String appNumber = dbobj.get("app_number").toString();
            Date update_log = (Date)dbobj.get("update_log");
            ArrayList<String> patetNumbers = new ArrayList<String>();
            BasicDBList pnlist = (BasicDBList) dbobj.get("patentnumberall");
            for(int i = 0; i < pnlist.size(); i ++) {
                patetNumbers.add(pnlist.get(i).toString());
            }

            ArrayList<String> currentAssigneesName = new ArrayList<String>();
            ArrayList<String> currentAssigneesFacetname = new ArrayList<String>();
            //ArrayList<String> totalAssigneesName = new ArrayList<String>();
            BasicDBList curAsgList = (BasicDBList) dbobj.get("Current_Assignee");
            for(int i = 0; i < curAsgList.size(); i ++) {
                BasicDBObject currentAssigneesNameObj = new BasicDBObject();
                currentAssigneesNameObj.put("origin", curAsgList.get(i).toString());
                currentAssigneesName.add(currentAssigneesNameObj.toString());

                BasicDBObject currentAssigneesFacetnameObj = new BasicDBObject();
                currentAssigneesFacetnameObj.put("origin", 
                        curAsgList.get(i).toString().toLowerCase().replaceAll("[\\s`~!@#$%^&*()\\-_=+\\[{\\]};:'\",<.>/?]+", ""));
                currentAssigneesFacetname.add(currentAssigneesFacetnameObj.toString());
            }
            
            for(String patentnumber: patetNumbers) {
                String mongopn = patentnumber;
                if(mongopn.length()==7) {
                    mongopn = "US00" + mongopn;
                }
                BasicDBObject patobj = (BasicDBObject)patcol.findOne(new BasicDBObject("patentNumber", mongopn), new BasicDBObject("_id", 1));
                String ptopid = "";
                if(patobj != null) {
                    ptopid = "USPTO." + patobj.get("_id").toString();
                }
                if(!ptopid.isEmpty()) {
                    //log.info("index cur assignee apn: " + appNumber + ", pn: " + patentnumber);
                    SolrInputDocument sdoc = new SolrInputDocument();
                    sdoc.addField("ptopid", ptopid);
                    setUpdateValue(sdoc, currentAssigneesName, "currentAssigneesName");
                    setUpdateValue(sdoc, currentAssigneesFacetname, "currentAssigneesFacetname");
                    setUpdateValue(sdoc, update_log, "currentAssigneesUpdateDate");
                    solrindex.add(sdoc);
                    //solrindex.commit();
                }
                else {
                    log.info("error while search in solr, apn: " + appNumber + ", pn: " + patentnumber);
                }
            }
            
            pe.addNum().debug(log, 10000, dbobj.get("update_log").toString());
        }
        log.info("finish");
        solrindex.commit();
        solrindex.close();
    }

}
