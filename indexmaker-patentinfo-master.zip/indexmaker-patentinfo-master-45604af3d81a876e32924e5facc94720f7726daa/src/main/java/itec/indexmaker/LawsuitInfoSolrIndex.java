package itec.indexmaker;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.IOException;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.ConcurrentUpdateSolrServer;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.bson.types.ObjectId;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import patent.lawsuit.LawsuitInfo;
import patent.lawsuit.MongoToLawsuitInfo;
import patent.lawsuit.PatentAtLawsuit;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;



public class LawsuitInfoSolrIndex {
    static Log log = LogFactory.getLog(LawsuitInfoSolrIndex.class);

    public static final String opt_solr_info_url = "solr.url";
    public static final String opt_solr_info_url_default = "http://127.0.0.1:8983/solr/core0";
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_solr_info_url, true,
                opt_solr_info_url_default, "")};

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    private static HttpSolrServer solr;

    static {
        ConfigUtils.setSearchBase(LawsuitInfoSolrIndex.class);
    }

    private static List<LawsuitInfo> getOriginalLawsuitInfos(String pn, SolrPatentInfo solrinfo) throws ParseException, SolrServerException, IOException {
        List<LawsuitInfo> originLawsuitInfos = null;
        SolrQuery query = new SolrQuery();
        query.setQuery("pto:USPTO AND patentNumberAll:" + pn);
        QueryResponse response = solr.query(query);
        SolrDocumentList results = response.getResults();
        switch (results.size()) {
        case 0:
            System.out.println("can't find patent");
            break;
        case 1:
        	originLawsuitInfos = new ArrayList<LawsuitInfo>();
            SolrDocument soledoc = results.get(0);
            if(soledoc.get("lawsuitContent") != null) {
                DBObject dbobj = (DBObject) JSON.parse(soledoc.get("lawsuitContent").toString());
                originLawsuitInfos.add(MongoToLawsuitInfo.dbObjectToLawsuitInfo(dbobj));
            }
            solrinfo.ptopid = soledoc.get("ptopid").toString();
            break;
        default:
            System.out.println("find multi patents");
        }
        return originLawsuitInfos;
    }

    private static void addLawsuitInfoToSolrPatentInfo (LawsuitInfo lawsuitInfo, SolrPatentInfo solrInfo) {
        if(lawsuitInfo.lawsuitId != null) {
            if(solrInfo.lawsuitIds == null) {
                solrInfo.lawsuitIds = new ArrayList<String>();
            }
            solrInfo.lawsuitIds.add(lawsuitInfo.lawsuitId);
        }

        if(lawsuitInfo.lawsuitTitle != null) {
            if(solrInfo.lawsuitTitles == null) {
                solrInfo.lawsuitTitles = new ArrayList<String>();
            }
            solrInfo.lawsuitTitles.add(lawsuitInfo.lawsuitTitle);
        }

        if(lawsuitInfo.lawsuitDocketNumber != null) {
            if(solrInfo.lawsuitDocketNumbers == null) {
                solrInfo.lawsuitDocketNumbers = new ArrayList<String>();
            }
            solrInfo.lawsuitDocketNumbers.add(lawsuitInfo.lawsuitDocketNumber);
        }

        if(lawsuitInfo.lawsuitCount != null) {
            if(solrInfo.lawsuitCounts == null) {
                solrInfo.lawsuitCounts = new ArrayList<String>();
            }
            solrInfo.lawsuitCounts.add(lawsuitInfo.lawsuitCount);
        }

        if(lawsuitInfo.lawsuitDateField != null) {
            if(solrInfo.lawsuitDatesField == null) {
                solrInfo.lawsuitDatesField = new ArrayList<Date>();
            }
            solrInfo.lawsuitDatesField.add(lawsuitInfo.lawsuitDateField);
        }

        if(lawsuitInfo.lawsuitCause != null) {
            if(solrInfo.lawsuitCauses == null) {
                solrInfo.lawsuitCauses = new ArrayList<String>();
            }
            solrInfo.lawsuitCauses.add(lawsuitInfo.lawsuitCause);
        }

        if(lawsuitInfo.lawsuitPlaintiff != null) {
            if(solrInfo.lawsuitPlaintiffs == null) {
                solrInfo.lawsuitPlaintiffs = new ArrayList<String>();
            }
            solrInfo.lawsuitPlaintiffs.add(lawsuitInfo.lawsuitPlaintiff);
        }

        if(lawsuitInfo.lawsuitDefendant != null) {
            if(solrInfo.lawsuitDefendants == null) {
                solrInfo.lawsuitDefendants = new ArrayList<String>();
            }
            solrInfo.lawsuitDefendants.addAll(lawsuitInfo.lawsuitDefendant);
        }

        if(lawsuitInfo.lawsuitCases != null) {
            if(solrInfo.lawsuitCases == null) {
                solrInfo.lawsuitCases = new ArrayList<String>();
            }
            solrInfo.lawsuitCases.add(lawsuitInfo.lawsuitCases);
        }

        if(lawsuitInfo.lawsuitDocketInfoDate != null) {
            if(solrInfo.lawsuitDocketInfoDates == null) {
                solrInfo.lawsuitDocketInfoDates = new ArrayList<Date>();
            }
            solrInfo.lawsuitDocketInfoDates.add(lawsuitInfo.lawsuitDocketInfoDate);
        }

        if(lawsuitInfo.lawsuitType != null) {
            if(solrInfo.lawsuitTypes == null) {
                solrInfo.lawsuitTypes = new ArrayList<String>();
            }
            solrInfo.lawsuitTypes.add(lawsuitInfo.lawsuitType);
        }

        if(lawsuitInfo.lawsuitDesc != null) {
            if(solrInfo.lawsuitDescs == null) {
                solrInfo.lawsuitDescs = new ArrayList<String>();
            }
            solrInfo.lawsuitDescs.add(lawsuitInfo.lawsuitDesc);
        }

        if(lawsuitInfo.lawsuitRelatedCases != null) {
            if(solrInfo.lawsuitRelatedCases == null) {
                solrInfo.lawsuitRelatedCases = new ArrayList<String>();
            }
            solrInfo.lawsuitRelatedCases.add(lawsuitInfo.lawsuitRelatedCases);
        }

        if(lawsuitInfo.lawsuitCounterDefendant != null) {
            if(solrInfo.lawsuitCounterDefendants == null) {
                solrInfo.lawsuitCounterDefendants = new ArrayList<String>();
            }
            solrInfo.lawsuitCounterDefendants.add(lawsuitInfo.lawsuitCounterDefendant);
        }

        if(lawsuitInfo.lawsuitCounterClaimant != null) {
            if(solrInfo.lawsuitCounterClaimants == null) {
                solrInfo.lawsuitCounterClaimants = new ArrayList<String>();
            }
            solrInfo.lawsuitCounterClaimants.add(lawsuitInfo.lawsuitCounterClaimant);
        }

        if(lawsuitInfo.lawsuitAdditionalDefendant != null) {
            if(solrInfo.lawsuitAdditionalDefendants == null) {
                solrInfo.lawsuitAdditionalDefendants = new ArrayList<String>();
            }
            solrInfo.lawsuitAdditionalDefendants.add(lawsuitInfo.lawsuitAdditionalDefendant);
        }
 
        if(lawsuitInfo.lawsuitAdditionalDefendants != null) {
            if(solrInfo.lawsuitAdditionalDefendants == null) {
                solrInfo.lawsuitAdditionalDefendants = new ArrayList<String>();
            }
            solrInfo.lawsuitAdditionalDefendants.add(lawsuitInfo.lawsuitAdditionalDefendants);
        }

        if(lawsuitInfo.lawsuitConsolCounterClaimant != null) {
            if(solrInfo.lawsuitConsolCounterClaimants == null) {
                solrInfo.lawsuitConsolCounterClaimants = new ArrayList<String>();
            }
            solrInfo.lawsuitConsolCounterClaimants.add(lawsuitInfo.lawsuitConsolCounterClaimant);
        }

        if(lawsuitInfo.lawsuitMediator != null) {
            if(solrInfo.lawsuitMediators == null) {
                solrInfo.lawsuitMediators = new ArrayList<String>();
            }
            solrInfo.lawsuitMediators.add(lawsuitInfo.lawsuitMediator);
        }

        if(lawsuitInfo.lawsuitThirdPartyPlaintiff != null) {
            if(solrInfo.lawsuitThirdPartyPlaintiffs == null) {
                solrInfo.lawsuitThirdPartyPlaintiffs = new ArrayList<String>();
            }
            solrInfo.lawsuitThirdPartyPlaintiffs.add(lawsuitInfo.lawsuitThirdPartyPlaintiff);
        }

        if(lawsuitInfo.lawsuitThirdPartyDefendant != null) {
            if(solrInfo.lawsuitThirdPartyDefendants == null) {
                solrInfo.lawsuitThirdPartyDefendants = new ArrayList<String>();
            }
            solrInfo.lawsuitThirdPartyDefendants.add(lawsuitInfo.lawsuitThirdPartyDefendant);
        }

        if(lawsuitInfo.lawsuitRegistrationNo != null) {
            if(solrInfo.lawsuitRegistrationNos == null) {
                solrInfo.lawsuitRegistrationNos = new ArrayList<String>();
            }
            solrInfo.lawsuitRegistrationNos.add(lawsuitInfo.lawsuitRegistrationNo);
        }

        if(lawsuitInfo.lawsuitContent != null) {
            if(solrInfo.lawsuitContents == null) {
                solrInfo.lawsuitContents = new ArrayList<String>();
            }
            solrInfo.lawsuitContents.add(lawsuitInfo.lawsuitContent);
        }
    }

    private static void setUpdateValue(SolrInputDocument sdoc, SolrPatentInfo solrInfo, 
            Field field) throws IllegalArgumentException, IllegalAccessException {
        Map partialUpdate = new HashMap();
        Object value = field.get(solrInfo);
        if(value != null) {
            partialUpdate.put("set", field.get(solrInfo));
            sdoc.addField(field.getName(), partialUpdate);
        }
    }

    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        ArgParser argParser = new ArgParser().addOpt(LawsuitInfoSolrIndex.class)
                .parse(args);
        MongoAuthInitUtils.reload(argParser);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }

        ConcurrentUpdateSolrServer solrindex = 
                new ConcurrentUpdateSolrServer(argParser.getOptString(opt_solr_info_url), 100, 1);
        solr = new HttpSolrServer(argParser.getOptString(opt_solr_info_url));
	
        List<LawsuitInfo> lawsuitInfos = MongoToLawsuitInfo.findInfos();
        System.out.println("total count :" + lawsuitInfos.size());
        for(LawsuitInfo lawsuitInfo: lawsuitInfos) {
            if(lawsuitInfo.patents != null) {
                for(PatentAtLawsuit patent: lawsuitInfo.patents) {
                    String pn;
                    if(patent.patentNumber.length() != 11) {
                        pn = String.format("US%09d", Integer.parseInt(patent.patentNumber));
                    } else {
                        pn = patent.patentNumber;
                    }
                    System.out.println(pn);
                    PatentInfo2 mongoInfo = new PatentInfo2();
                    mongoInfo.country = "US";
                    mongoInfo.pto = Pto.USPTO;
                    mongoInfo.id = new ObjectId("55399cbede3816c7bdd2ca6d");
                    mongoInfo.stat = 3;
                    SolrPatentInfo solrInfo = PatentInfoToSolr.Mongo2Solr(mongoInfo);
                    List<LawsuitInfo> originLawsuitInfos = getOriginalLawsuitInfos(pn, solrInfo);
                    if (originLawsuitInfos != null) {
	                    for(LawsuitInfo originLawsuitInfo: originLawsuitInfos) {
	                        if(originLawsuitInfo.lawsuitId == lawsuitInfo.lawsuitId) {
	                            originLawsuitInfos.remove(originLawsuitInfo);
	                            break;
	                        }
	                    }
	                    originLawsuitInfos.add(lawsuitInfo);
	
	                    for(LawsuitInfo originLawsuitInfo: originLawsuitInfos) {
	                        addLawsuitInfoToSolrPatentInfo(originLawsuitInfo, solrInfo);
	                        solrInfo.lawsuitTotalCount = solrInfo.lawsuitContents.size();
	                    }
	                    
	                    SolrInputDocument sdoc = new SolrInputDocument();
	                    Field[] fields = SolrPatentInfo.class.getDeclaredFields();
	                    sdoc.addField("ptopid", solrInfo.ptopid);
	                    for(Field field: fields) {
	                        String fieldName = field.getName();
                            if (fieldName.startsWith("lawsuit")) {
                                setUpdateValue(sdoc, solrInfo, field);
                            }
	                    }
	                    solrindex.add(sdoc);
	                    //solrindex.commit();
                    }
                }
            }
        }
        solrindex.commit();
        solrindex.close();
    }
}
