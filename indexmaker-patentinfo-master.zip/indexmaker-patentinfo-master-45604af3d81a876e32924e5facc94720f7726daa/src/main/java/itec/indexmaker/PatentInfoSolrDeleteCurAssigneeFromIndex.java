package itec.indexmaker;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.impl.ConcurrentUpdateSolrServer;
import org.apache.solr.common.SolrInputDocument;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class PatentInfoSolrDeleteCurAssigneeFromIndex {

    static Log log = LogFactory.getLog(PatentInfoSolrDeleteCurAssigneeFromIndex.class);

    public static final String opt_solr_info_url = "solr.url";
    public static final String opt_solr_info_url_default = "http://127.0.0.1:8983/solr/core0";

    public static final String opt_pto = "pto";
    public static final String opt_pto_default = null;

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_solr_info_url, true,
                    opt_solr_info_url_default, ""),
            new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
            new ArgParser.Option("t", null, true, "",
                    "Patent open/decision date rage\n"
                            + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                            + "Format: YYYYMMDD+n (20110101+31)\n"
                            + "Format: YYYYMM+n (201101+12)\n"
                            + "Format: YYYYMM+n (2011+1)\n"), 
            new ArgParser.Option("b", null, true, "", "bulk size")};

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    static {
        ConfigUtils.setSearchBase(PatentInfoSolrDeleteCurAssigneeFromIndex.class);
    }

    private static void setUpdateValue(SolrInputDocument sdoc, Object value, 
        String fieldName) throws IllegalArgumentException, IllegalAccessException {
        Map partialUpdate = new HashMap();
        if(value != null) {
            partialUpdate.put("set", value);
            sdoc.addField(fieldName, partialUpdate);
        }
    }

    public static void main(String[] args) throws Exception {
        PatentInfoSolrDeleteCurAssigneeFromIndex worker = new PatentInfoSolrDeleteCurAssigneeFromIndex();
        worker.worker(args);
    }

    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(PatentInfoSolrDeleteCurAssigneeFromIndex.class)
                .parse(args);
        MongoAuthInitUtils.reload(argParser);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }

        log.debug("testing solr server");
        String date_range = argParser.getOptString("t");
        int sizeOfBulk = Integer.parseInt(argParser.getOptString("b"));

        ConcurrentUpdateSolrServer solrindex = 
                new ConcurrentUpdateSolrServer(argParser.getOptString(opt_solr_info_url), sizeOfBulk, 2);
        Pto pto = Pto.valueOf(argParser.getOptString(opt_pto).toUpperCase());

        QueryHelp query = getDateRange(date_range);
        //String pn = "096117000";
        //QueryHelp query = new QueryHelp();
        //query.filter("appNumber", pn);
        if (query != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + query);
            Thread.sleep(5000);
        }

        log.debug("counting total documents");

        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject("doDate", 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count())
                .setFormatDefNum();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        log.debug("start index");
        int count = 0;
        while (cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            String ptopid = dbobj.get("pto").toString() + "." + dbobj.get("_id").toString();

            SolrInputDocument sdoc = new SolrInputDocument();
            sdoc.addField("ptopid", ptopid);
            Map partialUpdate = new HashMap();
            partialUpdate.put("set", null);
            sdoc.addField("currentAssigneesName", partialUpdate);
            sdoc.addField("currentAssigneesFacetname", partialUpdate);
            solrindex.add(sdoc);

            pe.addNum().debug(log, 10000, dbobj.get("doDate").toString());
            //solrindex.commit();
        }
        solrindex.commit();
        solrindex.close();
        pe.debug(log);
        log.debug("finish");
    }

    private QueryHelp getDateRange(String date_range) {
        if (date_range == null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype,
                    calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp doDate = new QueryHelp();
        doDate.filter("$gte", dateFrom);
        doDate.filter("$lt", dateTo);
        return new QueryHelp("doDate", doDate);
    }
}
