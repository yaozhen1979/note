package itec.indexmaker;

import java.io.File;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

public class ExtractAllFiles
{

    public ExtractAllFiles()
    {
        try
        {
            ZipFile zipFile = new ZipFile("F:/zip/abcd.zip");
            zipFile.extractAll("F:/ziptar");
        }
        catch(ZipException e)
        {
            e.printStackTrace();
        }
    }

    public ExtractAllFiles(String zipFilePath, String unzipTarPath)
    {
        try
        {
            ZipFile zipFile = new ZipFile(zipFilePath);
            zipFile.extractAll(unzipTarPath);
        }
        catch(ZipException e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String args[])
    {
        String arrayStr = args[0];
        String unzipTarPath = args[1];
        String zipArray[] = arrayStr.split(",");
        for(int i = 0; i < zipArray.length; i++)
        {
            System.out.println((new StringBuilder("Begin unzip path : ")).append(zipArray[i]).toString());
            String tarPath = tarPath(zipArray[i], unzipTarPath);
            new ExtractAllFiles(zipArray[i], tarPath);
        }

    }

    public static String tarPath(String zipFilePaht, String unzipTarPath)
    {
        String fileName = (new File(zipFilePaht)).getName();
        fileName = fileName.substring(0, fileName.lastIndexOf("."));
        String tarPath = (new StringBuilder(String.valueOf(unzipTarPath))).append("/").toString();
        return tarPath;
    }
}

