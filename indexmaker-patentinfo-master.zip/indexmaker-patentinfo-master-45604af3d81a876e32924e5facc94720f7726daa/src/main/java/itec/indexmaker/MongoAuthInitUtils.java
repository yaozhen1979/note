package itec.indexmaker;

import itec.patent.mongodb.patentinfo2.PatentInfoCN;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;
import itec.patent.mongodb.patentinfo2.PatentInfoEP;
import itec.patent.mongodb.patentinfo2.PatentInfoEPO;
import itec.patent.mongodb.patentinfo2.PatentInfoJP;
import itec.patent.mongodb.patentinfo2.PatentInfoJPO;
import itec.patent.mongodb.patentinfo2.PatentInfoKIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoKR;
import itec.patent.mongodb.patentinfo2.PatentInfoTIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoTW;
import itec.patent.mongodb.patentinfo2.PatentInfoUS;
import itec.patent.mongodb.patentinfo2.PatentInfoUSPTO;
import itec.patent.mongodb.patentinfo2.PatentInfoWIPO;
import itec.patent.mongodb.patentinfo2.PatentInfoWO;
import itec.patent.mongodb.patentraw.PatentRawCNIPR;
import itec.patent.mongodb.patentraw.PatentRawEPO;
import itec.patent.mongodb.patentraw.PatentRawJPO;
import itec.patent.mongodb.patentraw.PatentRawKIPO;
import itec.patent.mongodb.patentraw.PatentRawTIPO;
import itec.patent.mongodb.patentraw.PatentRawUSPTO;
import itec.patent.mongodb.patentraw.PatentRawWIPO;

import java.net.UnknownHostException;
import java.util.Arrays;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.MappedClass;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;

/**
 * MongoAuthInitUtils for patentinfo to solr index
 * @author luxungtuo
 * 
 * 20140723
 *
 */
public class MongoAuthInitUtils {

    static Log log = LogFactory.getLog(MongoAuthInitUtils.class);

    public static final String opt_mongodb_ac = "mongodb.ac";
    public static final String opt_mongodb_pd = "mongodb.pd";
    public static final String opt_mongodb_name = "mongodb.name";
    public static final String opt_mongodb_host = "mongodb.host";
    
    public static final String opt_mongodb_ac_default = "username";
    public static final String opt_mongodb_pd_default = "password";
    public static final String opt_mongodb_name_default = "PatentInfoKR";
    public static final String opt_mongodb_host_default = "10.60.90.155";

    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_mongodb_ac, true, opt_mongodb_ac_default, "mongodb username,login mongodb"),
        new ArgParser.Option(null, opt_mongodb_pd, true, opt_mongodb_pd_default, "mongodb password,login mongodb"),
        new ArgParser.Option(null, opt_mongodb_name, true, opt_mongodb_name_default, "mongodb name, db name"),
        new ArgParser.Option(null, opt_mongodb_host, true, opt_mongodb_host_default, "mongodb host, mongodb uri"),
    };

    public static Builder mongoopt = MongoClientOptions.builder()
            .readPreference(ReadPreference.secondaryPreferred());

    public static void initMongoClass(Class<?> clazz, String config_name, String defuri) throws UnknownHostException {
        String uriString = ConfigUtils.get(config_name, defuri);
        if (log.isDebugEnabled()) {
            if (!uriString.equals(defuri)) {
                log.debug(ClassUtils.getShortCanonicalName(clazz) + ": " + uriString);
            }
        }
        
        MongoCredential credential = MongoCredential.createMongoCRCredential(ConfigUtils.get(opt_mongodb_ac), "admin", ConfigUtils.get(opt_mongodb_pd).toCharArray());
        MongoClient mongo = new MongoClient(new ServerAddress(ConfigUtils.get(opt_mongodb_host), 27017), Arrays.asList(credential));
        MappedClass.getMappedClass(clazz, mongo.getDB(clazz.getSimpleName()));
    }

    public static void initMongoClass(Class<?> clazz, String config_name) throws UnknownHostException {
        String defuri = ConfigUtils.get(opt_mongodb_host, opt_mongodb_host_default);
        initMongoClass(clazz, config_name, defuri);
    }

    public static void nothing() {}

    private static void reload(String defhost) throws UnknownHostException {
        log.debug("reload opt_mongodb_uri: " + ConfigUtils.get(opt_mongodb_host)+"/"+ ConfigUtils.get(opt_mongodb_name));
        
        MongoCredential credential = MongoCredential.createMongoCRCredential(ConfigUtils.get(opt_mongodb_ac), "admin", ConfigUtils.get(opt_mongodb_pd).toCharArray());
        MongoClient mongo = new MongoClient(new ServerAddress(ConfigUtils.get(opt_mongodb_host), 27017), Arrays.asList(credential));
        MappedClass.db = mongo.getDB("admin");

        initMongoClass(PatentRawUSPTO.class, "mongodb.PatentRawUSPTO.uri"    , defhost);
        initMongoClass(PatentRawTIPO.class, "mongodb.PatentRawTIPO.uri"    , defhost);
        initMongoClass(PatentRawCNIPR.class, "mongodb.PatentRawCNIPR.uri"    , defhost);
        initMongoClass(PatentRawJPO.class, "mongodb.PatentRawJPO.uri"    , defhost);
        initMongoClass(PatentRawKIPO.class, "mongodb.PatentRawKIPO.uri"    , defhost);
        initMongoClass(PatentRawWIPO.class, "mongodb.PatentRawWIPO.uri"    , defhost);
        initMongoClass(PatentRawEPO.class , "mongodb.PatentRawEPO.uri"    , defhost);
        
        initMongoClass(PatentInfoUSPTO.class, "mongodb.PatentInfoUSPTO.uri"    , defhost);
        initMongoClass(PatentInfoTIPO.class, "mongodb.PatentInfoTIPO.uri"    , defhost);
        initMongoClass(PatentInfoCNIPR.class, "mongodb.PatentInfoCNIPR.uri"    , defhost);
        initMongoClass(PatentInfoJPO.class, "mongodb.PatentInfoJPO.uri"    , defhost);
        initMongoClass(PatentInfoKIPO.class, "mongodb.PatentInfoKIPO.uri"    , defhost);
        initMongoClass(PatentInfoWIPO.class, "mongodb.PatentInfoWIPO.uri"    , defhost);
        initMongoClass(PatentInfoEPO.class, "mongodb.PatentInfoEPO.uri"    , defhost);
        
        initMongoClass(PatentInfoUS.class, "mongodb.PatentInfoUS.uri"    , defhost);
        initMongoClass(PatentInfoTW.class, "mongodb.PatentInfoTW.uri"    , defhost);
        initMongoClass(PatentInfoCN.class, "mongodb.PatentInfoCN.uri"    , defhost);
        initMongoClass(PatentInfoJP.class, "mongodb.PatentInfoJP.uri"    , defhost);
        initMongoClass(PatentInfoKR.class, "mongodb.PatentInfoKR.uri"    , defhost);
        initMongoClass(PatentInfoWO.class, "mongodb.PatentInfoWO.uri"    , defhost);
        initMongoClass(PatentInfoEP.class, "mongodb.PatentInfoEP.uri"    , defhost);
    }

    public static void reload(ArgParser argParser) throws UnknownHostException {
        String defhost = argParser.getOptString(opt_mongodb_host);
        reload(defhost);
    }

}
