package itec.indexmaker;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.impl.ConcurrentUpdateSolrServer;
import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import patent.ipc.en.IpcCpcFinder;

public class PatentInfoSolrIndex {

    static Log log = LogFactory.getLog(PatentInfoSolrIndex.class);
    static Log solr_log = LogFactory.getLog("solr_log");

    public static final String opt_solr_info_url = "solr.url";
    public static final String opt_solr_info_url_default = "http://127.0.0.1:8983/solr/core0";

    public static final String opt_pto = "pto";
    public static final String opt_pto_default = null;

    public static final String opt_cc = "cc";
    public static final String opt_force = "force";
    public static final String opt_docdb_status = "status";
    
    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_solr_info_url, true,
                    opt_solr_info_url_default, ""),
            new ArgParser.Option(null, opt_pto, true, opt_pto_default, ""),
            new ArgParser.Option("t", null, true, "",
                    "Patent open/decision date rage\n"
                            + "Format: YYYYMMDD-YYYYMMDD (20110101-20111231)\n"
                            + "Format: YYYYMMDD+n (20110101+31)\n"
                            + "Format: YYYYMM+n (201101+12)\n"
                            + "Format: YYYYMM+n (2011+1)\n"), 
            new ArgParser.Option("k", null, true, "",
                    "Patent ObjectId"
                            + "Format: 52b2bcbc97d80a7436d55c11,52b33abc97d80a7436f59e2d\n"), 
            new ArgParser.Option("f", null, true, "",
                    "field of query date : doDate or docdbDoDate"),
            new ArgParser.Option("b", null, true, "",
                     "bulk size"),
            new ArgParser.Option(opt_cc, null, true, "", 
                    "country for docdb backfile"),
            new ArgParser.Option(opt_force, null, false, false, 
                    "force update docdb backfile to index"),
            new ArgParser.Option(opt_docdb_status, null, true, "", 
                            "status of dbcdb document")};
    

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class, };

    static {
        ConfigUtils.setSearchBase(PatentInfoSolrIndex.class);
    }

    public static void main(String[] args) throws Exception {
        PatentInfoSolrIndex worker = new PatentInfoSolrIndex();
        worker.worker(args);
    }

    public void worker(String[] args) throws Exception {
        ArgParser argParser = new ArgParser().addOpt(PatentInfoSolrIndex.class)
                .parse(args);
        MongoAuthInitUtils.reload(argParser);
        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }

        IpcCpcFinder.load();

        Pto pto = Pto.valueOf(argParser.getOptString(opt_pto).toUpperCase());

        String date_range = argParser.getOptString("t");
        String ids = argParser.getOptString("k");
        String field_date = argParser.getOptString("f");
        int sizeOfBulk = Integer.parseInt(argParser.getOptString("b"));

        ConcurrentUpdateSolrServer solrindex = 
                new ConcurrentUpdateSolrServer(argParser.getOptString(opt_solr_info_url), sizeOfBulk, 2);

        QueryHelp query = new QueryHelp();
        if (StringUtils.isNotBlank(ids)) {
            ArrayList<ObjectId> idSet = new ArrayList<ObjectId>();
            String[] allIds = ids.split(",");
            for (String id : allIds) {
                idSet.add(new ObjectId(id));
            }
            query.filter("_id", new BasicDBObject("$in", idSet));
        } else {
            if(field_date.equals("history.docdbDoDate")) {
                query.filter(field_date, DateUtils.parseDate(date_range));
            } else {
                query = getDateRange(date_range, field_date);
            }
        }
        //docdb backfile
        if (StringUtils.isNotBlank(argParser.getOptString(opt_cc))) {
            query.filter("country", argParser.getOptString(opt_cc));
        }
        if (StringUtils.isNotBlank(argParser.getOptString(opt_docdb_status))) {
            query.filter("history.status", argParser.getOptString(opt_docdb_status));
        }

        //query = new QueryHelp();
        //query.filter("appNumber", "特願2006-132750(P2006-132750)");

        if (query != null && log.isDebugEnabled()) {
            log.debug("query in 5 seconds: " + query);
            Thread.sleep(5000);
        }

        log.debug("counting total documents");

        DBCollection col = PatentInfo2.getCollection(pto);
        DBCursor cursor = col.find(query).sort(new BasicDBObject(field_date, 1));
        ProcessEstimater pe = new ProcessEstimater(cursor.count())
                .setFormatDefNum();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        log.debug("start index");
        while (cursor.hasNext()) {
            DBObject dbobj = cursor.next();
            try {
                PatentInfo2 mongoInfo = PatentInfo2.fromObject(pto, dbobj);
                String kindcode = mongoInfo.kindcode;
                if (pto.name().contains("JP")){
                    if (kindcode.contains("P")) {
                        mongoInfo.type = "\u7279\u8A31";
                    } else if (kindcode.contains("U")) {
                        mongoInfo.type = "\u5B9F\u7528\u65B0\u6848";
                    } else if (kindcode.contains("D")){
                        mongoInfo.type = "\u610F\u5320\u516C\u5831";
                    }
                }

                if(pto.equals(Pto.DOCDB)) {
                    Set existPTO = new HashSet<>();
                    existPTO.add("US");
                    existPTO.add("CN");
                    existPTO.add("TW");
                    existPTO.add("JP");
                    existPTO.add("KR");
                    existPTO.add("EP");
                    existPTO.add("WO");
                    if (!argParser.getOptBoolean(opt_force)) {
                        if(existPTO.contains(mongoInfo.country)) {
                            continue;
                        }
                    }
                }
                if(mongoInfo.country == null) {
                    switch(pto) {
                    case USPTO:
                        mongoInfo.country = "US";
                        break;
                    case CNIPR:
                        mongoInfo.country = "CN";
                        break;
                    case TIPO:
                        mongoInfo.country = "TW";
                        break;
                    case JPO:
                        mongoInfo.country = "JP";
                        break;
                    case WIPO:
                        mongoInfo.country = "WO";
                        break;
                    case EPO:
                        mongoInfo.country = "EP";
                        break;
                    case KIPO:
                        mongoInfo.country = "KR";
                        break;
                    default:
                        break;
                    }
                }
                SolrPatentInfo solrInfo = PatentInfoToSolr.Mongo2Solr(mongoInfo);
                solrindex.addBean(solrInfo);
                solrindex.commit();
                pe.addNum().debug(log, 10000, sdf.format(mongoInfo.doDate));
            } catch (Exception e) {
                e.printStackTrace();
                log.debug("error id: " + dbobj.get("_id"));
            }
        }
        solrindex.commit();
        solrindex.close();
        pe.debug(log);
        log.debug("finish");
    }

    private QueryHelp getDateRange(String date_range, String field_date) {
        if (date_range == null || date_range.isEmpty()) {
            return null;
        }
        Date dateFrom = null;
        Date dateTo = null;

        if (date_range.contains("-")) {
            String[] tParts = date_range.split("-");
            dateFrom = DateUtils.parseDate(tParts[0]);
            dateTo = DateUtils.parseDate(tParts[1]);
        } else if (date_range.contains("+")) {
            int caltype;
            String[] tParts = date_range.split("\\+");
            switch (tParts[0].length()) {
            case 4:
                caltype = Calendar.YEAR;
                tParts[0] += "0101";
                break;
            case 6:
                caltype = Calendar.MONTH;
                tParts[0] += "01";
                break;
            case 8:
                caltype = Calendar.DATE;
                break;
            default:
                throw new IllegalArgumentException("Invalid date format");
            }

            dateFrom = DateUtils.parseDate(tParts[0]);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(dateFrom);

            Calendar calTo = Calendar.getInstance();
            calTo.setTime(dateFrom);
            calTo.set(caltype,
                    calFrom.get(caltype) + Integer.parseInt(tParts[1]));
            dateTo = new Date(calTo.getTimeInMillis());
        }

        QueryHelp qdate = new QueryHelp();
        qdate.filter("$gte", dateFrom);
        qdate.filter("$lt", dateTo);
        return new QueryHelp(field_date, qdate);
    }

}
