package itec.patent.solr.us;

import java.util.Date;

import org.apache.solr.client.solrj.beans.Field;

@Deprecated
public class Ipc {

    @Field
    public String id;

    @Field
    public String name;

    @Field
    public String text;

    @Field
    public Date solrIndexTime = new Date();

}
