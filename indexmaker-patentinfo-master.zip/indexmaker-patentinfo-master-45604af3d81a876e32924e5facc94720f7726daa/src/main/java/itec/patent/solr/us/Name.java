package itec.patent.solr.us;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.apache.solr.client.solrj.beans.Field;

@Deprecated
public class Name {

    @Field
    public long id;

    @Field
    public Collection<String> name = new HashSet<String>();

    @Field
    public String text;

    @Field
    public Collection<String> texts = new HashSet<String>();

    @Field
    public Date solrIndexTime = new Date();

}
