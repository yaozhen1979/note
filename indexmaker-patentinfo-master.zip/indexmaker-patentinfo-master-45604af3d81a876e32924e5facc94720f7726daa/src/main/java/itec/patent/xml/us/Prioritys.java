package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class Prioritys {

    @XmlElement
    public ArrayList<Priority> priority;

}
