package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class Assignees {

    @XmlElement
    public ArrayList<Assignee> assignee;

    @Override
    public String toString() {
        return assignee.toString();
    }

}
