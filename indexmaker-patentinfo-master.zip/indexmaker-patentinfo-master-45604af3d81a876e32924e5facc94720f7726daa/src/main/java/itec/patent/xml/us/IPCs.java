package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class IPCs {

    @XmlElement(name="IPC")
    public ArrayList<String> ipc;

}
