package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class CPCs {

    @XmlElement(name="CPC")
    public ArrayList<String> cpc;

}
