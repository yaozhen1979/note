package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;

public class Priority {

    @XmlElement
    public String number;

    @XmlElement
    public String priorityDate;

    @XmlElement
    public String country;

}
