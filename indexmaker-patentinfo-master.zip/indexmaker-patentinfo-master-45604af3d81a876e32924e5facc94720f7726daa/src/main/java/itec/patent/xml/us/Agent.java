package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;

public class Agent {

    @XmlElement(name="ID")
    public int id;

    @XmlElement
    public String name;

    @Override
    public String toString() {
        return name;
    }

}
