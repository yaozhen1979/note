package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;

public class PatentCited {

    @XmlElement
    public String patentNumber;

    @XmlElement
    public String citedPatentNumber;

}
