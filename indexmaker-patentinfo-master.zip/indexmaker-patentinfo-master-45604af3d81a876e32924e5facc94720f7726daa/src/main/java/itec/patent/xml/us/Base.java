package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;

public class Base {

    @XmlElement
    public String applicationNumber;

    @XmlElement
    public String countryID;

    @XmlElement
    public String applicationDate;

    @XmlElement
    public String claimDep;

    @XmlElement
    public int claimIndep;

    @XmlElement
    public int claimNumber;

    @XmlElement
    public String decisionDate;

    @XmlElement
    public String decisionNumber;

    @XmlElement
    public int filePageClaim;

    @XmlElement
    public int filePageDescription;

    @XmlElement
    public int filePageFigure;

    @XmlElement
    public int filePageFirst;

    @XmlElement
    public int filePageNumber;

    @XmlElement
    public String legalStatus;

    @XmlElement
    public String mainCPC;

    @XmlElement
    public String mainIPC;

    @XmlElement
    public String openDate;

    @XmlElement
    public String openNumber;

    @XmlElement
    public String patentAbstract;

    @XmlElement
    public String patentNumber;

    @XmlElement
    public String patentName;

    @XmlElement
    public String patentType;

    @XmlElement
    public String primaryExaminer;

    @XmlElement
    public String patentClaim;

    @XmlElement
    public String patentDescription;

}
