package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class Inventors {

    @XmlElement
    public ArrayList<Inventor> inventor;

    @Override
    public String toString() {
        return inventor.toString();
    }

}
