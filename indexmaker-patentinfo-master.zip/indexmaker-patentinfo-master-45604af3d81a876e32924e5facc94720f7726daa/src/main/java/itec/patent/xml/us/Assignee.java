package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;

public class Assignee {

    @XmlElement(name="ID")
    public int id;

    @XmlElement
    public String name;

    @XmlElement
    public String address;

    @XmlElement
    public String country;

    @Override
    public String toString() {
        return name;
    }

}
