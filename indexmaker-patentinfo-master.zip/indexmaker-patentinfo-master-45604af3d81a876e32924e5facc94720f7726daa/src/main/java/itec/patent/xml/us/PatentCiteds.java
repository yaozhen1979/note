package itec.patent.xml.us;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class PatentCiteds {

    @XmlElement
    public ArrayList<PatentCited> patentCited;

}
