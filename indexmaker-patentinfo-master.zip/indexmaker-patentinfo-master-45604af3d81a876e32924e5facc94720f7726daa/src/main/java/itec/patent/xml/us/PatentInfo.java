package itec.patent.xml.us;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PatentInfo {

    @XmlElement
    public Base base;

    @XmlElement(name="CPCs")
    public CPCs cpcs;

    @XmlElement
    public Assignees assignees;

    @XmlElement
    public Inventors inventors;

    @XmlElement
    public PatentCiteds patentCiteds;

    @XmlElement
    public Agent agent;

    @XmlElement(name="IPCs")
    public IPCs ipcs;

    @XmlElement
    public Prioritys prioritys;

}
