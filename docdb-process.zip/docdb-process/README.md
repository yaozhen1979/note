docdb-process 說明
===

### 更新流程 ###

1.  每週四時, 從[EPO Download][url_1]下戴當期資料.

        * Cr-Del file
        * Amend file  
    
    登入資訊:  
  
  
        login info  
        name: 
        pwd:  

2.  把下戴下來的``zip file``解壓縮至指定位置.  

        * 可參考``sh/``中的bash script, 或將來以java zip4j改寫.(已廢棄)  
        * 目前做法為: 執行org.unzip.ExtractDocdbData.java, 並已指定期數來解壓縮zip file至
          D:\share\docdb\Cr-Del\2015XX or D:\share\docdb\Amend\2015XX.(XX 表期數)           
        * 2015-10-29 補充: 因目前的的zip檔是先放在windows檔案結構下, 在掛到linux NFS下面
        
                // mount window share folder
                sudo mount -t cifs //10.60.80.31/share /mnt/share -o username=tonykuo
                
          and 完成後, 再使用rsync至指定目錄下後才執行import Lv1的程式. (可改進 ???)

3.  執行Lv1程式: ``patent.docdb.importer.DocdbImporterByConfig.groovy``  

        * 為在執行時, 加入[-config.path xxxxx], xxxxx為properties file path, 並依設定檔內的參數來執行insert LV1程式.
        * check query by mongo shell script
              
              use PatentRawDOCDB  
              // fileType: 1 or 2
              db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-10-22T00:00:000Z"), fileType: 1}).count()
              // doc.path: 201543-CreateDelete or 201543-Amend, 依期數決定查詢條件 
              db.ErrorPatentRawDOCDB.find({'doc.path': /201543-CreateDelete/, 'doc.country': 'US'}).count()
              
          and 檢核出來的數量, 應附合從zip檔中的[statistics_201543_CreateDelete_001.csv]其中各status[C, A, D, CV, DV]的加總
        
4.  執行Lv2程式: ``DocdbInfoProcessRefactor.groovy`` or ``DocdbInfoProcess.groovy``  

        * DocdbInfoProcessRefactor.groovy: 為了防此資料流順序的問題, 有特別使用[Write Concern]  
        * DocdbInfoProcess.groovy: 則是可個別執行單筆資料 insert or update

    ref: [Write Concern][url_2]  

5.  建Solr Index: ``indexmaker-tony => itec.indexmaker.tony.PatentInfoSolrIndexByTony.groovy`` 利用build.gradle fatJar建出jar file,  
    再linux環境下執行
    
        * java -jar [jar file] -pto DOCDB -mongodb.host 10.60.90.101 -mongodb.name PatentInfoDOCDB -mongodb.ac cGF0ZW50ZGF0YQ== -mongodb.pd ZGF0YS5jbG91ZC5BYmMxMjM0NQ== -b 500 > [yyyyMMdd].log &  
        
    => 當期或是全刷皆可

### 重新 insert docdb step

1.  copy 一份 Lv2._id 為備份資料  

2.  以history中, 最早的``rawDataId``來執行``RecoveryDataToOrigin.groovy``  

3.  執行``DocdbInfoProcessRecovery.groovy``  

4.  依原本資料中的``history.rawDataId``, 依續持行``DocdbInfoProcess.groovy``  


### Docdb Regular Process 相關程式

1.  DocdbRawRegular-batch.groovy  
2.  DocdbRawRegular.groovy
3.  patent.docdb.importer.MongoUtil.groovy  
     
        TODO: 該隻為 mike coding, 將來可統一改用``org.utils.MongoUtil.groovy``  

### kindcode 相關

1.   ``KindCodeMapImporter.groovy`` 依``doc/kindcode_update.csv``中的資料為主.  
     如果是要個別更新的話, 可以使用``test.csv``

### Check 相關程式

1.  Docdb LV1和Raw Data間的差異, 目前是和每期中的``statistics_201501_Amend_[期數].csv``or``statistics_201501_CreateDelete_[期數].csv``  
    來做數量比對(二個csv file皆為解壓縮而得).
2.  ``CheckHistoryStatusCount.groovy`` 為檢查每一期Docdb中history中status的數量, 是否和Lv1中的該期數量一致.
3.  ``CheckIndexByCountryUpdate.groovy`` 為檢查目前Docdb LV2 Data和Solr Index中, 各國間的差異數量.

### Query 相關程式

1. ``Lv1QueryByCountry.groovy`` 依國家別來統計DOCDB中每一期的資料數量

### Merge 相關程式

1. 參考``js/``  

    主要為``mongodb_test_merge.js``和``mongodb_test_merge_After2015.js``

    ``mongodb_test_merge.js``負責處理back file data

    ``mongodb_test_merge_After2015.js``負責處理front file data

### 2015-10-25 Update

1.  從 2015-03-12 開始的每期, LV1都有和每期的所提供的統計數量做相互比對且數量皆已OK(status=C,D,A),  
 現有問題的資料只有status=DV時, 會出現和LV1 Err Colection的數量不一致的資料出現, 只都只有個位數且目前是不處理status=CV,DV的資料, 所以可暫時忽略不處理.

2.  已下列二LV1, LV2查詢條件為列時:
    
     db.PatentRawDOCDB.find({country: 'WO', 'docdbDoDate': ISODate('2015-10-08T00:00:000Z'), fileType:2, kindCode:'A8', 'data.xml': /<doc-number>2010057947/})
     db.PatentInfoDOCDB.find({country: 'WO', patentNumber: '2010057947', kindcode: 'A8'})
     
      在WO一定會查詢出多筆資料, 則經由EPO WorldWild查詢後, 也證實出該筆資料同時存在二筆kindcode=A8的資料,  經差異比對後, 發現主要只有[publication date]不一樣, 其餘資料也大同小異...
     
     所以決定lv2Query,再放入[openDate, decisionDate]來當做判斷是否為惟一一筆資料的查詢條件.  

### TODO LIST  

1.  unset LV2 PatentInfoDOCDB 中的``isUpdateTitleAndBrief``欄位資料.

2.  自動化更新流程

3.  目前只有和LV2和LV1的數量檢核, 尚未檢核和EPO每期所提供的數據資料來檢核 => 從 2015-03-12 開始的每期, LV1都有和每期的所提供的統計數量做相互比對且數量皆已OK(status=C,D,A), 現有問題的資料只有status=DV時, 會出現和LV1 Err Colection的數量不一致的資料出現, 只都只有個位數且目前是不處理status=CV,DV的資料, 所以可暫時忽略不處理.

4.  Merge 改為整合層.

5. 處理LV1 PatentRawDOCDB中的Error Collection


[url_1]: https://publication.epo.org/raw-data/product-list?lg=en "EPO Download"  
[url_2]: http://api.mongodb.org/java/current/com/mongodb/WriteConcern.html "write concern"
