package taskScript.temp.yao

import org.utils.MongoUtil
import org.utils.RestTimeProcess

class FamilyIdCount {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def queryCursor = patentInfoDOCDB.find([country: "US"])
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        def existFamilyIdCount = 0
        def noExistFamilyIdCount = 0
        
        File fileLog = new File("logs/FamilyIdCount.log")
        
        patentInfoDOCDB.find([country: "US"]).limit(0).each { it -> 
            
            // println "familyId = ${it.familyId}"
            
            if (!!it.familyId) {
                existFamilyIdCount++
            } else {
                noExistFamilyIdCount++
                fileLog << it._id << ln
            }
            
            restTimeProcess.process()
        }
        
        fileLog << "existFamilyId count = ${existFamilyIdCount}" << ln
        fileLog << "noExistFamilyId count = ${noExistFamilyIdCount}" << ln
        
        println "existFamilyId count = ${existFamilyIdCount}"
        println "noExistFamilyId count = ${noExistFamilyIdCount}"
        println "finished..."
        
    }

}
