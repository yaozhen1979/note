package taskScript.temp.gr

import java.text.Format
import java.text.SimpleDateFormat

class UpdateDateFormat {
    
//    // 24/8/89
//    Format formatter = new SimpleDateFormat("dd/MM/yy");
//    String string = formatter.format(new Date());
//    
//    Format formatter2 = new SimpleDateFormat("yyyy/MM/dd")
//    
//    println "date = " + formatter.parse("24/08/89")
//    println formatter2.format(formatter.parse("24/08/89"))
    
    static main(args) {
        
        def count = 0
        
        new File("logs/valid_xml/GR_valid.log").eachLine { line, number -> 
            //
            if (!!line.find(/(\d{1,2}\/\d{1,2}\/\d{2}|\d{1,2}-\d{1,2}-\d{2})/)) {
                def id = line.split(",")[0].split("=")[1].trim()
                println "_id = ${id}"
                println "date = " + line.find(/(\d{1,2}\/\d{1,2}\/\d{2}|\d{1,2}-\d{1,2}-\d{2})/)
                println "count = ${++count}"
            }
            println "=============================="
        }
        
    }

}
