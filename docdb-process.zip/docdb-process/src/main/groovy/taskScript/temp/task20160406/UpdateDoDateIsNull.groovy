package taskScript.temp.task20160406

import java.text.SimpleDateFormat

import org.utils.DateUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess

import com.mongodb.DB

/**
 * if doDate is null
 * then update doDate eq docdbDoDate
 * 
 * NOTE: 2016.04.06: 目前只改kindcode=U2
 * 
 * @author tonykuo
 *
 */
class UpdateDoDateIsNull {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        DB db = dbClient.getDB("PatentMarshallDOCDB");
        
        // // db.PatentMarshallDE.find({kindcode: "U1", doDate: null, docdbDoDate: ISODate("1970-01-01T00:00:00.000Z")}).limit(5)
        def queryCursor = db.PatentMarshallDE.find([kindcode: "U1", doDate: null]).limit(0)
        println "query count = ${queryCursor.size()}"
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.size(), this.class.getSimpleName())
        
        queryCursor.each { it -> 
            
            println "_id = ${it._id}"
            // println "doDate = ${it.doDate}"
            // println "docdbDoDate = ${it.docdbDoDate}"
            int doDate = new SimpleDateFormat("yyyyMMdd").format(it.docdbDoDate) as int;
            // println "doDate = ${doDate}"
            
            db.PatentMarshallDE.update(_id: it._id, [$set: [doDate: doDate]])
            
            restTimeProcess.process();
        }
        
        println "finished..."
    }

}
