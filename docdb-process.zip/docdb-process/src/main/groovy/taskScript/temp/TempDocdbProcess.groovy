package taskScript.temp

import org.slf4j.Logger;
import org.utils.MongoUtil
import org.utils.PatentInfoUtil
import org.utils.DateUtil
import org.utils.ErrInfoUtil
import org.utils.KindcodeUtil
import org.utils.CountryUtil
import org.utils.MailUtil

import static jodd.jerry.Jerry.jerry as $

import org.utils.RestTimeProcess
import org.bson.types.ObjectId

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.DocdbInfoProcessRefactor3

class TempDocdbProcess {
    
    private static Logger logger = LoggerFactory.getLogger(this.class);
    
    static main(args) {
        
        // db.TEMP_DOCDB_20151127
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        def rawDB = client.getDB("PatentRawDOCDB")
        def patentRawDOCDB = rawDB.getCollection("PatentRawDOCDB")
        
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def tonyDB = client.getDB("TonyDB")
        def tempCollection = tonyDB.getCollection("TEMP_DOCDB_20151127")
        
        def tagAndJsfile = ['file': 'DocdbInfoProcess.groovy', 'tag': 'v0.2.0']
        
        tempCollection.find().limit(0).each { it -> 
            
            def country = it.country
            def patentNumber = it.patentNumber
            def kindcode = it.kindcode
            
            // println it.history
            patentInfoDOCDB.remove(it)
            
//            patentInfoDOCDB.find([country:country, patentNumber: patentNumber, kindcode: kindcode]).each { it2 -> 
//                println it2.history
//            }
            
            // update infoDocdb
            it.history.each { data -> 
                def rawDataId = data.rawDataId
                def query = [_id: rawDataId]
                try {
                    DocdbInfoProcessRefactor3.processInfoData(query, rawDB, db, tagAndJsfile, logger)
                } catch(e) {
                    MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", "query = ${query}, exception = " + e.toString())
                    throw new Exception(e)
                }
            }
            
            // update TEMP_DOCDB_20151127 flag
            tempCollection.update([_id: it._id], [$set: [update: true]])
            
        }
        
        println "finished..."
    }

}
