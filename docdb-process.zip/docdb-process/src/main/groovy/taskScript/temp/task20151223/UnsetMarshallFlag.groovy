package taskScript.temp.task20151223

import org.utils.CountryUtil
import org.utils.JaxbUtil
import org.utils.MailUtil
import org.utils.MiscUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess

class UnsetMarshallFlag {
    
    static void process(def dbClient, def queryMap) {
        
        def db = dbClient.getDB("PatentRawDOCDB")
        def patentRawDOCDB = db.getCollection("PatentRawDOCDB")
        def queryCursor = patentRawDOCDB.find(queryMap).limit(0)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        def count = queryCursor.count()
        if (count == 0) {
            println "queryMap = ${queryMap}, find count = 0"
            return
        }
        
        def cc = queryMap.country
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "${this.class.getSimpleName()} - ${queryMap.country}")
        
        def rawDataid = null;
        
        try {
            
            queryCursor.each { rawData ->
                
                // println "unset id = ${rawData._id}"
                patentRawDOCDB.update([_id: rawData._id], [$unset: [marshallFlag: ""]])
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            println "Exception: rawDataid = ${rawDataid}, ${e}"
            MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Data Exception Error", "rawDataid = ${rawDataid} = ${e}")
            throw new Exception("Exception: rawDataid = ${rawDataid}, ${e}")
        }
        
    }
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        try {
            
            CountryUtil.getMarshallCountryList().each { cc ->
                
                def queryMap = [country: cc, marshallFlag: true]
                process(dbClient, queryMap);
                
                // MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "unset Docdb Marshall Data => ${cc} complete", "${cc} marshall completed...")
                
            }
            
        } catch(e) {
            println e
        } finally {
            dbClient.close()
        }
        
        println "finished..."
        
    }

}
