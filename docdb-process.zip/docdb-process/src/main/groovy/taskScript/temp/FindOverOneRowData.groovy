package taskScript.temp

import org.utils.MongoUtil
import org.utils.PatentInfoUtil
import org.utils.DateUtil
import org.utils.ErrInfoUtil
import org.utils.KindcodeUtil
import org.utils.CountryUtil
import org.utils.MailUtil

import org.bson.types.ObjectId

import static jodd.jerry.Jerry.jerry as $
import org.utils.RestTimeProcess
import org.bson.types.ObjectId
import org.utils.MongoUtil

class FindOverOneRowData {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        def rawDB = client.getDB("PatentRawDOCDB")
        def patentRawDOCDB = rawDB.getCollection("PatentRawDOCDB")
        
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def tonyDB = client.getDB("TonyDB")
        def tempCollection = tonyDB.getCollection("TEMP_DOCDB_20151127")
        
        File fileLog = new File("log_for_replicated_data/process_merge_history_20151126.txt")
        
        // File fileLog2 = new File("log_for_replicated_data/raw_data_id_with_one_data.txt")
        
        CountryUtil.getSomeCountryList().each { cc ->
            //
            def query = [docdbDoDate: DateUtil.parseDate("2015-11-26"), fileType: 2, country: cc]
            def queryRawDataCursor = patentRawDOCDB.find(query)
            queryRawDataCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(queryRawDataCursor.count(), this.class.name)
            
            queryRawDataCursor.each { queryData -> 
                
                def output = queryData.data.xml
                def dom = $(output)
                def dataMap = PatentInfoUtil.parseData(dom)
                def patentNumber = dataMap.patentNumber
                
                def queryAgainCursor = patentInfoDOCDB.find([country: queryData.country, patentNumber: patentNumber, kindcode: queryData.kindCode])
                // queryAgainCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
                
                if (queryAgainCursor.count() > 1) {
                    
                    def originId = queryAgainCursor[0]._id
                    def originHistory = queryAgainCursor[0].history
                    
                    for (def i = 1 ; i < queryAgainCursor.count() ; i++) {
                        
                        try {
                            queryAgainCursor[i].history.each { it ->
                                originHistory << it
                            }
                            
                            fileLog << "query = ${query}, originId = ${originId}, remove id = ${queryAgainCursor[i]._id}" << ln
                            tempCollection.save(queryAgainCursor[i])
                            patentInfoDOCDB.remove([_id: queryAgainCursor[i]._id])
                        } catch (e) {
                            throw new Exception("exception = " + e)
                        }
                        
                    }
                    
                    println "originHistory = ${originHistory}"
                    println "docdbDoDate = ${originHistory.history[-1].docdbDoDate}"
                    
                    // patentInfoDOCDB.update([_id: originId], [$set: [history: originHistory]])
                    
                }
                
                restTimeProcess.process()
                
            }
            
        }
        
        println "finished..."
        
    }

}
