package taskScript.temp

import org.utils.MongoUtil
import org.bson.types.ObjectId 

class FindStat2 {

    static main(args) {
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        File fileLog  = new File("logs/FindHistorySize_2015-10-08.log")
        
        fileLog.eachLine { line -> 
            if (!!line.toString().trim()) {
                def id = line.toString().split(",")[1].split("=")[1].trim()
                // println "id = ${id}"
                def queryData = patentInfoDOCDB.findOne([_id: new ObjectId(id)])
                def stat = queryData.stat
                if (stat == 2) {
                    println "id = ${id}"
                }
            }
        }
        
        println "finished..."
    }

}
