package taskScript.temp

import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

class SolrIndexDeleteClient {
    
    static querySolr(def queryStr) {
        def xml = ("http://10.60.90.112/solr/cn/select?q=${queryStr}&wt=json&indent=true").toURL().text
        def jsonSlurper = new JsonSlurper();
        def object = jsonSlurper.parseText(xml)
        return object;
    }
    
    static deleteSolrIndex(def queryStr) {
        def xml = ("http://10.60.90.112:5566/solr/cn/update?stream.body=<delete><query>${queryStr}</query></delete>&commit=true").toURL().text
        return xml;
    }
    
    static main(args) {
        
        // http://10.60.90.112/solr/cn/select?q=pto%3AKIPO&wt=json&indent=true
        
        // println querySolr("pto%3AKIPO")
        
        def xmlStr = deleteSolrIndex("pto%3AKIPO")
        def response = new XmlSlurper().parseText(xmlStr)
        
        if (response.lst.int[0].text() == '0') {
            println "delete data ok"
        } else {
            println "delete data no good"
        }
        
    }

}
