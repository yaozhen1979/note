package taskScript.temp.check20160307

import org.utils.MongoUtil
import org.utils.RestTimeProcess

/**
 * @deprecated
 * 
 * @author tonykuo
 *
 */
class CheckDocdbAppNoAndCnAppNo {
    
    static main(args) {
        
        File fileLog = new File("logs/20160307/CheckDocdbAppNoAndCnAppNo.log");
        
        def ln = System.getProperty('line.separator')
        
        def _121Client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
        
        def _101Client = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        def _121DB = _121Client.getDB("PatentInfoCNIPR");
        def _101DB = _101Client.getDB("PatentInfoDOCDB")
        
        def count = _121DB.PatentInfoCNIPR.count();
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "CheckDocdbAppNoAndCnAppNo")
        
        _121DB.PatentInfoCNIPR.find().limit(10).each { it -> 
            
            // if (it.kindcode != "S") {

            def cnAppNo = it.appNumber.replaceAll(/\./, "")
            println "cnAppNo = ${cnAppNo}"
            
            if (!!_101DB.PatentInfoDOCDB.find([country: "CN", appNumber: cnAppNo])) {
                println "query by appNo, data found"
            } else {
                println "query by appNo, data no found, ${it._id}"
                fileLog << "query by appNo, data no found, ${it._id}" << ln
            }
            
            restTimeProcess.process()
        }
        
        println "finished..."
    }

}
