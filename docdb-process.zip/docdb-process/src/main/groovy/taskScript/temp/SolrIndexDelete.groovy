package taskScript.temp

import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

class SolrIndexDelete {
    
    // TODO: delete docdb solr index = ptopid:DOCDB.562c5669f3b4f2eb93b1ddab
    
    /**
     *
     * @param start
     * @param rows
     * @return
     */
    static querySolr(def id) {
        def xml = ("http://10.60.90.176/solr/cn/select?q=ptopid%3A+DOCDB.${id}&fl=ptopid%2Cid&wt=json").toURL().text
        def jsonSlurper = new JsonSlurper();
        def object = jsonSlurper.parseText(xml)
        return object;
    }
    
    /**
     * http://10.60.90.176/solr/cn/select?q=doDate%3A+%222016-02-17T00%3A00%3A00Z%22+AND+kindcode%3A+%22S%22&wt=json&indent=true
     * http://10.180.131.194/solr/cn/select?q=doDate%3A+%222016-02-17T00%3A00%3A00Z%22+AND+kindcode+%3A+%22S%22&wt=json&indent=true
     * 
     * @param solrIp
     * @return
     */
    static querySolrCnData1(String solrIp) {
        def xml = ("http://${solrIp}/solr/cn/select?q=doDate%3A+%222016-02-17T00%3A00%3A00Z%22+AND+kindcode%3A+%22S%22&wt=json").toURL().text
        def jsonSlurper = new JsonSlurper();
        def object = jsonSlurper.parseText(xml)
        return object;
    }
    
    static queryDeleteSolrCnData1(String solrIp) {
        def xml = ("http://${solrIp}:8983/solr/docdb/update?stream.body=<delete><query>doDate%3A+%222016-02-17T00%3A00%3A00Z%22+AND+kindcode%3A+%22S%22</query></delete>&commit=true").toURL().text
        return xml;
    }
    
    static deleteCnSolrIndex(String, solrIp, String id) {
        // 10.60.90.178:5566/solr/cn/update?stream.body=<delete><query>pto:"CNIPR"</query></delete>&commit=true
        def xml = ("http://${solrIp}:8983/solr/docdb/update?stream.body=<delete><query>ptopid%3ACNIPR.${id}</query></delete>&commit=true").toURL().text
        return xml;
    }
    
    static deleteDocdbSolrIndex(def id) {
        // 10.60.90.178:5566/solr/cn/update?stream.body=<delete><query>pto:"CNIPR"</query></delete>&commit=true
        def xml = ("http://10.60.90.113:5566/solr/docdb/update?stream.body=<delete><query>ptopid%3ADOCDB.${id}</query></delete>&commit=true").toURL().text
        return xml;
    }
    
    static history1() {
        
        def dirPath = "log_for_replicated_data"
        
        def fileList = [
            "update_2015-10-08.txt",
            "update_2015-10-15.txt",
            "update_2015-10-22.txt",
            "update_2015-10-29.txt",
            "update_2015-11-05.txt",
        ]
        
        fileList.each { fileName ->
            new File(dirPath + "/" + fileName).eachLine { line ->
                if (!!line.toString().trim()) {
                    def id = line.toString().split(",")[1].split("=")[1].trim()
                    // println "id = ${id}"
                    // def xmlStr = SolrIndexDelete.deleteSolrIndex(id)
                    def xmlStr = '''<?xml version="1.0" encoding="UTF-8"?>
                        <response>
                        <lst name="responseHeader">
                            <int name="status">0</int>
                            <int name="QTime">189</int>
                        </lst>
                        </response>
                    '''
                    def response = new XmlSlurper().parseText(xmlStr)
                    if (response.lst.int[0].text() == '0') {
                        println "delete id = ${id}, ok"
                    } else {
                        println "delete id = ${id}, no good"
                    }
                    
                }
            }
        }
        
    }
    
    static main(args) {
        
        // println querySolrCnData1("10.60.90.176");
        
        // println queryDeleteSolrCnData1("10.60.90.176");
        
        println deleteCnSolrIndex("10.60.90.176", "56e6227d5eeec7a8ba302888")
        
        println "finished..."
    }

}
