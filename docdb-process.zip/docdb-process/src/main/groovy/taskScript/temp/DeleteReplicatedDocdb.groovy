package taskScript.temp

import org.utils.RestTimeProcess
import org.bson.types.ObjectId
import org.utils.MongoUtil

class DeleteReplicatedDocdb {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def dirPath = "log_for_replicated_data"
        
        def fileList = [
            "update_2015-10-08.txt",
            "update_2015-10-15.txt",
            "update_2015-10-22.txt",
            "update_2015-10-29.txt",
            "update_2015-11-05.txt",
        ]
        
        fileList.each { fileName ->
            
            def lines = 0
            new File(dirPath + "/" + fileName).eachLine { line ->
                if (!!line.toString().trim()) {
                    lines++;
                }
            }
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(lines, this.class.name)
            
            /**
             * before remove data = 95833958
             * after remove data(expected) = 95833958 - 485470 = 95348488
             * 
             */
            new File(dirPath + "/" + fileName).eachLine { line ->
                if (!!line.toString().trim()) {
                    def id = line.toString().split(",")[1].split("=")[1].trim()
                    patentInfoDOCDB.remove([_id: new ObjectId(id)])
                    restTimeProcess.process()
                }
            }
        }
        
        println "finished..."
        
    }

}
