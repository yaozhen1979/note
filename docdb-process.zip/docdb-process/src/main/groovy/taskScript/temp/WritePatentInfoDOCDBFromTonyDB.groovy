package taskScript.temp

import org.utils.MongoUtil
import org.utils.RestTimeProcess

class WritePatentInfoDOCDBFromTonyDB {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        def tonyDB = client.getDB("TonyDB")
        def tempCollection = tonyDB.getCollection("PatentInfoDOCDB")
        
        File fileLog = new File("log_for_replicated_data/delete_id_from_docdb_to_ihow")
        
        def queryCursor = tempCollection.find()
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it -> 
            fileLog << it._id.toString() << ln
            restTimeProcess.process()
        }
        
        println "finished..."
    }

}
