package taskScript.temp


import org.utils.PatentInfoUtil
import org.utils.DateUtil
import org.utils.CountryUtil
import org.utils.MailUtil

import org.bson.types.ObjectId

import org.utils.RestTimeProcess
import org.bson.types.ObjectId
import org.utils.MongoUtil

class UpdateDocdbDoDate {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        CountryUtil.getOtherCountryList().each { cc -> 
            
            // docdbDoDate: DateUtil.parseDate("2015-11-26")
            def query = [country: cc]
            def queryInfoDataCursor = patentInfoDOCDB.find(query)
            queryInfoDataCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(queryInfoDataCursor.count(), this.class.name)
            
            queryInfoDataCursor.each { queryData -> 
                
                def lastDocdbDoDate = queryData.history[-1].docdbDoDate
                def originDocdbDoDate = queryData.docdbDoDate ?: new Date()
                
                if (lastDocdbDoDate.compareTo(originDocdbDoDate) != 0) {
                    // println "docdbDoDate are not the same"
                    def id = queryData._id
                    println "cc = ${cc}, update id = ${id}"
                    patentInfoDOCDB.update([_id: id], [$set : [docdbDoDate : lastDocdbDoDate]])
                } else {
                    // println "docdbDoDate no problem"
                }
                
                restTimeProcess.process()
            }
            
        }
        
        println "finished..."
    }

}
