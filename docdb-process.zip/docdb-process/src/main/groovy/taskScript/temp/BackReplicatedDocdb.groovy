package taskScript.temp

import org.utils.RestTimeProcess
import org.bson.types.ObjectId
import org.utils.MongoUtil

class BackReplicatedDocdb {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def backupDB = client.getDB("TonyDB")
        def backupPatentInfoDOCDB = backupDB.getCollection("PatentInfoDOCDB")
        
        def dirPath = "log_for_replicated_data"
        
        def fileList = [
            "update_2015-10-08.txt",
            "update_2015-10-15.txt",
            "update_2015-10-22.txt",
            "update_2015-10-29.txt",
            "update_2015-11-05.txt",
        ]
        
        fileList.each { fileName ->
            
            File fileLog = new File("log_for_replicated_data/" + fileName + "_rawData_id")
            
            def lines = 0
            new File(dirPath + "/" + fileName).eachLine { line -> 
                if (!!line.toString().trim()) {
                    lines++;
                }
            }
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(lines, this.class.name)
            
            new File(dirPath + "/" + fileName).eachLine { line ->
                if (!!line.toString().trim()) {
                    def id = line.toString().split(",")[1].split("=")[1].trim()
                    
                    def backupCursor = patentInfoDOCDB.find([_id: new ObjectId(id)])
                    backupCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
                    
                    if (backupCursor.size() == 1) {
                        fileLog << backupCursor[0]._id << ln
                        backupPatentInfoDOCDB.save(backupCursor[0])
                    } else {
                        throw new Exception("file name = ${fileName}, id = ${id}, query over 1 document...")
                    }
                    
                    restTimeProcess.process()
                }
            }
        }
        
        println "finished..."
        
    }

}
