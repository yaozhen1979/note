package taskScript.temp

import org.bson.types.ObjectId
import org.utils.MongoUtil
import org.utils.DateUtil

class Delete20151111AmendData {

    static main(args) {
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        // FindHistorySize_2015-11-12.log
        File fileLog = new File("logs/FindHistorySize_2015-11-12.log");
        
        fileLog.eachLine { line, number ->
            if (!!line.toString()) {
                def id = line.toString().trim()
                patentInfoDOCDB.remove([_id: new ObjectId(id)])
                println "remove count = ${number}"
            } 
            
        }
        
        println "finished..."
    }

}
