package taskScript.temp

import org.utils.MongoUtil
import org.utils.DateUtil
import org.utils.CountryUtil
import org.utils.MailUtil
import org.utils.RestTimeProcess

/**
 * TODO: 找出2015-11-04中history只有一筆且status=A的資料
 * 
 * @author tonykuo
 *
 */
class FindHistorySize {
    
    def void process(String date) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def docdbDoDate = DateUtil.parseDate(date)
        
        File fileLog = new File("logs/FindHistorySize_${date}.log")
        // File fileLog = new File("logs/FindHistorySize_other_country.log")
        
        // getDocdbCountryList
        CountryUtil.getDocdbCountryList().each { cc -> 
            
            def queryMap = [docdbDoDate : docdbDoDate, country: cc]
            def queryCursor = patentInfoDOCDB.find(queryMap)
            queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
            
            RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
            
            queryCursor.each { it -> 
                
                def stat = it.stat
                def historyCount = it.history.size()
                // println "history size = ${it.history.size()}"    
                
                if (historyCount == 1)  {
                    it.history.each { history ->  
                        if (history.status == "A") {
                            fileLog << it._id << ln
                        }
                    }
                }
                
                restTimeProcess.process()
            }
            
               
        }
        
    }
    
    static main(args) {
        
        /*
         * 待測期數  = 2015-11-05,
         * 待測期數 = 2015-10-29
         * 待測期數 = 2015-10-22
         * 待測期數 = 2015-10-15
         * 待測期數 = 2015-10-08
         * 待測期數 = 2015-10-01 => OK
         *
         */
        
        def queryDateList = [
//            "2015-10-08",
//            "2015-10-15",
//            "2015-10-22",
//            "2015-10-29",
//            "2015-11-05",
            "2015-11-12"
        ]
        
        queryDateList.each { date -> 
            new FindHistorySize().process(date)
        }
        
        println "finished..."
        
    }

}
