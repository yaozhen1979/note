package taskScript.temp

class IDParser20151112 {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        File fileLog = new File("logs/20151112/delete_id.txt");
        
        new File("logs/20151112/20151112_Amend_ERR.log").eachLine { line -> 
            
            // lv1._id = 564d15c5f3b4fab87cccc211
            if (!!line.toString()) {
                def id = line.toString().split(",")[1].split("=")[1].trim()
                fileLog << id << ln
            }
            
        }
        
        println "finished..."
        
    }

}
