package taskScript.temp

import org.utils.MongoUtil
import org.utils.PatentInfoUtil
import org.utils.DateUtil
import org.utils.ErrInfoUtil
import org.utils.KindcodeUtil
import org.utils.CountryUtil
import org.utils.MailUtil

import org.bson.types.ObjectId

import static jodd.jerry.Jerry.jerry as $

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class MergeHistory20151112 {
    
    private static Logger logger = LoggerFactory.getLogger(this.class);
    
    static main(args) {

        // parse raw data to info data by country
        CountryUtil.getDocdbCountryList().each { cc ->
            //
            def query = [docdbDoDate: DateUtil.parseDate("2015-11-12"), fileType: 2, country: cc]

            try {
                processInfoData(query, lv1DB, lv2DB, tagAndJsfile, logger)
            } catch(e) {
                MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", e.toString())
                throw new Exception(e)
            }

        }

        logger.info "finished..."

    }

}
