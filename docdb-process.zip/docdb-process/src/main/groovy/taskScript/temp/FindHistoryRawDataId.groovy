package taskScript.temp

import org.utils.RestTimeProcess
import org.bson.types.ObjectId
import org.utils.MongoUtil

class FindHistoryRawDataId {
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("TonyDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        def queryCursor = patentInfoDOCDB.find()
        
        File fileLog = new File("log_for_replicated_data/raw_data_id.txt")
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it -> 
            
            def history = it.history
            
            if (history.size() == 1) {
                fileLog << history[0].rawDataId << ln
            } else {
                throw new Exception("")
            }
            
            restTimeProcess.process()
            
        }
        
        println "finished..."
        
    }

}
