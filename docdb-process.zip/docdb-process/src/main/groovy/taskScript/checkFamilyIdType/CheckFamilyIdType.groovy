/**
 * 工具程式
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

File checkLog = new File("log/checkUpdateTitleAndBrief.log")

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

// "AP", "AR"
def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE", "KG", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT",
    "UA", "UY", "UZ",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

def testList = ["AM"]

// def count = db.PatentInfoDOCDB.find([country:"AM", isUpdateTitleAndBrief:[$exists: true]]).count()

println "countryList size = ${countryList.size()}"

testList.each { cc ->
    
    File file = new File("log/CheckFamilyIdType/CheckFamilyIdType-${cc}.log")
    
    def errCount = 0
    
    // def currentCount = 0
    db.PatentInfoDOCDB.find([country:cc]).each { data ->
        
        if (!!data.familyId && data.familyId.class == String) {
            
            errCount++
            
            println "${cc}, data._id = ${data._id}, family data type is wrong..."
            
            file << "${cc}, data._id = ${data._id}, family data type is wrong..." << ln
            
        }
        
    }
    
    if (errCount > 0) {
        file << "=========================================" << ln
        file << "${cc}, errCount = ${errCount}" << ln
    }

}    

println "finished..."
 