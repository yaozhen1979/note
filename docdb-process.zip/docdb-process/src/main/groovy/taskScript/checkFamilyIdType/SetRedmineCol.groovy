/**
 * 工具程式
 */
import org.utils.MongoUtil
import org.utils.PatentInfoUtil
import org.utils.KindcodeUtil
import org.utils.ErrInfoUtil
import org.bson.types.ObjectId

import static jodd.jerry.Jerry.jerry as $

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv1DB = client.getDB("PatentRawDOCDB")

/*
 *  TODO:
 *  Test: TestInfoDOCDB
 *  Prod: PatentInfoDOCDB
 */
def lv2DB = client.getDB("PatentInfoDOCDB")

def dataList = []

new File("log/CheckFamilyIdType/CheckFamilyIdType-DE.log").eachLine { line, nu -> 
    
    // println "${nu}:" + line.toString()
    
    // def lineStr = line.toString()
    
    if (line.toString().contains("data._id")) {
        def lv2Id = line.toString().split(",")[1].split("=")[1].trim()
        // println "lv2Id = $lv2Id"
        dataList << lv2Id
        // println "match..."
    }
    
}

// println dataList
// println dataList.size()

// def testList = ["557ea13bb4411f24f11163cb"]

dataList.eachWithIndex { id, index -> 
    
    lv2DB.PatentInfoDOCDB.update([_id: new ObjectId(id)], [$set: ['redmine':['bug':99999, 'status':'in progress']]])
    
    println "${index + 1}, $id, update completed..."
}

println "finished..."
    