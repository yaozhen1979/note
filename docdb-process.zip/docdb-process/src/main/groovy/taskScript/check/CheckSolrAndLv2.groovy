/**
 * check solr 和 PatentInfoDOCDB Lv2 中的資料差異.
 * 
 * 2015-10-10 : check DE
 * DE count =  7359388
 * 7360214 NOT MATCH! 826
 * 
 */
import groovy.json.JsonSlurper

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import jodd.jerry.Jerry
import static jodd.jerry.Jerry.jerry as $
import org.utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentInfoDOCDB")

// 532183 / 532238 => diff 55

File fileLog = new File("log/CheckSolrAndLv2.log")

db.PatentInfoDOCDB.find().sort([_id: -1]).limit(1).eachWithIndex { it, index -> 
    
    def id = it._id
    def solrData = querySolr(id)
    
    if (solrData.response.numFound == 1) {
        println "_id = ${it._id} : data exists"
        fileLog << "_id = ${it._id} : data exists" << ln
    } else {
        println "_id = ${it._id} : data dont exist"
        fileLog << "_id = ${it._id} : data dont exist" << ln
    }
    
    println "process data ${index + 1} / 7360214"
    
}

println 'finished!'

/**
 * http://10.60.90.113:5566/solr/docdb/select?q=ptopid%3A+DOCDB.55786df1b4411f24f1693bd0&fl=ptopid%2Cid&wt=json
 * 
 * @param start
 * @param rows
 * @return
 */
def querySolr(id) {
    
    def xml = ("http://10.60.90.113:5566/solr/docdb/select?q=ptopid%3A+DOCDB.${id}&fl=ptopid%2Cid&wt=json").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
