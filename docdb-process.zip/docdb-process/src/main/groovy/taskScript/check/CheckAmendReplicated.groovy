/**
 * 工具程式: 依傳入的檔案log, 找出重複的Lv2 id.
 */
long startTime = System.currentTimeMillis();

File checkFile  = new File("nodejs/log_for_amend_cr-del/docdb_20150305_amend.txt");
def ln = System.getProperty('line.separator')
def checkList = []

println "checking"

checkFile.eachLine { line ->
        
    if (line.contains("update PatentInfoDOCDB.id")) {
        def objectId = line.substring(55).trim()
        // println "objectId = ${objectId}"
        
        checkList << objectId
    }
    
}

checkList.sort()

println checkList.size()

for (int i = 1; i < checkList.size(); i++) {
    // println test[i]
    if (checkList[i - 1] == checkList[i]) {
        println "duplicate data = ${checkList[i]}"
    }
    
}

long endTime = System.currentTimeMillis();

println("That took " + (endTime - startTime) + " milliseconds");
