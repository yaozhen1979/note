/**
 * 找出DOCDB某一期的 LV1 ID 和 LV2 ID, 並寫入檔案.
 */
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// 10.60.90.101 / 127.0.0.1
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// TonyDB / PatentInfoDOCDB
def lv1DB = client.getDB("PatentRawDOCDB")
def lv2DB = client.getDB("PatentInfoDOCDB")

def checkDate = "2015-03-12"

def queryMap = ['history.docdbDoDate':DateUtil.parseDate(checkDate), 'history.status': 'A']

def lv1Data = lv1DB.PatentRawDOCDB.find([docdbDoDate: DateUtil.parseDate(checkDate), 'fileType': 2])
def lv1TotalCount = lv1Data.count()
println "lv1Data = ${lv1TotalCount}"

File checkLv1Log = new File("log/checkLv1AndLv2/lv1Id.log") 

lv1Data.eachWithIndex { it, index -> 
    checkLv1Log << it._id <<ln
    println "process ${index + 1} / ${lv1TotalCount}"
}

def lv2Data = lv2DB.PatentInfoDOCDB.find(queryMap)
def lv2TotalCount = lv2Data.count()
println "lv2Data = ${lv2TotalCount}"

File checkLv2Log = new File("log/checkLv1AndLv2/lv2Id.log")

lv2Data.eachWithIndex { it, index -> 
    checkLv2Log << it.history[-1].rawDataId <<ln
    println "process ${index + 1} / ${lv2TotalCount}"
}

println "finished..."

