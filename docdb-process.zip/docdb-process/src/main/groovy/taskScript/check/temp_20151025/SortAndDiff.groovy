def ln = System.getProperty('line.separator')

def amendLogSort = []

println "to start"

new File("logs/20151025/DE_20151008_amendLog.log").eachLine { line ->
    amendLogSort << line.toString().trim()
}

File amendSortLog = new File("logs/20151025/DE_20151008_amendLog_sort.log")

amendLogSort.sort().each { amend -> 
    amendSortLog << amend << ln
}

println "finished"