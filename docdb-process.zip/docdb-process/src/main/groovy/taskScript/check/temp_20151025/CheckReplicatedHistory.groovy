/**
 * check history 每期修改的數量 (Cr-Del, Amend)
 */
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// 10.60.90.101 / 127.0.0.1
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// TonyDB / PatentInfoDOCDB
def lv2DB = client.getDB("PatentInfoDOCDB")

def lv1DB = client.getDB("PatentRawDOCDB");

def amendCount = 0
def createCount = 0
def deleteCount = 0
def backfileCount = 0
def otherCount = 0

def checkDate = "20151008"

File filgLog = new File("logs/check_status_${checkDate}.log")
File amendLog = new File("logs/20151025/DE_20151008_amendLog.log")

// 2015-03-12 createCount = 91851
//            deleteCount = 3
// 55a8090cb4411f24f119a639

// 2015-10-08 => US, JP, DD, AU, RO, TW, KR, CN, CA
//               GE, SE, ES, BA, BY, BR, => chechk OK
def queryMap = ['history.docdbDoDate':DateUtil.parseDate(checkDate), country: 'DE']
// def queryMap = [_id: new ObjectId("55a8090cb4411f24f119a639")]

lv2DB.PatentInfoDOCDB.find(queryMap).limit(0).eachWithIndex { it, index ->
    
    println "process ${index + 1} ..."
    
    it.history.each { history ->
        
        //
        def docdbDoDate = DateUtil.toISODate(history.docdbDoDate, "yyyyMMdd")
        
        
        if (history.status == 'C' && docdbDoDate == checkDate) {
            //
            createCount++
            
        } else if (history.status == 'A' && docdbDoDate == checkDate) {
            //
            amendCount++
            
            amendLog << history.rawDataId << ln
            // amendList << history.rawDataId
            
//            def queryLv1Data = lv1DB.PatentRawDOCDB.findOne([_id: history.rawDataId])
//            if (!queryLv1Data) {
//                println "lv2 id = ${it._id} is not exist in lv1"
//            }
            
        } else if (history.status == 'D' && docdbDoDate == checkDate) {
            
            deleteCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
            
        } else if (history.status == 'B' && docdbDoDate == checkDate) {
            
            backfileCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
            
        } else if(docdbDoDate == checkDate) {
            
            otherCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
        
        }
        
    }
    
}

println "amendCount = ${amendCount}"
println "createCount = ${createCount}"
println "deleteCount = ${deleteCount}"
println "backfileCount = ${backfileCount}"
println "otherCount = ${otherCount}"

println "finished..."
