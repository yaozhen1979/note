// tool script
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// 10.60.90.101 / 127.0.0.1
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// TonyDB / PatentInfoDOCDB
def lv2DB = client.getDB("PatentInfoDOCDB")

def lv1DB = client.getDB("PatentRawDOCDB");

File fileLog = new File("logs/20151025/20151008_DE_sort_lv1_id.log")

println "to start..."

def idList = []

lv1DB.PatentRawDOCDB.find([country: 'DE', docdbDoDate: DateUtil.parseDate("2015-10-08"), fileType: 2]).each { lv1 ->
    idList << lv1._id
}

idList.sort().each { it -> 
    fileLog << it << ln
}

println "finished..."
