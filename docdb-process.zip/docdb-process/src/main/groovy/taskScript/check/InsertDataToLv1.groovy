/**
 * 工具程式, 用完即丟.
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

File checkLog = new File("log/checkUpdateTitleAndBrief.log")

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentRawDOCDB")

def count = db.PatentRawDOCDB.count()

println "count = ${count}"

// def insertData = ['docdbDoDate': DateUtil.parseDate("2015-10-14")]
// db.PatentRawDOCDB.insert(insertData)

println "finished..."
