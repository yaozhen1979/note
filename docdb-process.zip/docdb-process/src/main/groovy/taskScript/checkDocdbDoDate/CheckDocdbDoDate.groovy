/**
 * tool script, 檢查DOCDB LV2 PatentInfoDOCDB 是否有 docdbDoDate.
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE", "KG", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT",
    "UA", "UY", "UZ",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

def testList = ["US"]

def originCountry = ["CN", "US", "EP", "KR", "JP", "WO", "TW"]

// def count = db.PatentInfoDOCDB.find([country:"AM", isUpdateTitleAndBrief:[$exists: true]]).count()

println "countryList size = ${countryList.size()}"

countryList.each { cc ->
    
    File file = new File("log/checkDocdbDoDate/checkDocdbDoDate-${cc}.log")
    
    println "to parse ${cc}..."
    
    def errCount = 0
    
    def count = db.PatentInfoDOCDB.count([country:cc, docdbDoDate: [$exists: false]])
    
    println "${cc} docdbDoDate no exists data count = ${count}"
    
    db.PatentInfoDOCDB.find([country:cc, docdbDoDate: [$exists: false]]).each { it ->
        println "lv2._id = ${it._id}"
        println "history = ${it.history}"
    }
    
}

println "finished..."
 