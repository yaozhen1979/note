/**
 * 依國家別來統計DOCDB中每一期的資料數量
 */
import org.utils.MongoUtil

import org.bson.types.ObjectId
import org.utils.DateUtil

def client = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentRawDOCDB")

// 2015-03-19 V
// Cr-Del count = 65100
// Amend  count = 605585

// 2015-03-26 V
// Cr-Del count = 76565
// Amend  count = 387816

// 2015-04-02 V
// Cr-Del count = 66505
// Amend  count = 403283

// 2015-04-09 V
// Cr-Del count = 98425
// Amend  count = 418472

// 2015-04-16 V
// Cr-Del count = 65383
// Amend  count = 853132

// 2015-04-23 V
// Cr-Del count = 69260
// Amend  count = 1486977

// 2015-04-30 V
// Cr-Del count = 121171
// Amend  count = 434688

// 2015-05-07 V
// Cr-Del count = 180072
// Amend  count = 1335115

// 2015-05-14 V
// Cr-Del count = 34524
// Amend  count = 736109

// 2015-05-21 V
// Cr-Del count = 73689
// Amend  count = 778707

// 2015-05-28 V
// Cr-Del count = 206371
// Amend  count = 487693

// 2015-06-04 V
// Cr-Del count = 23397
// Amend  count = 275540

// 2015-06-11 V
// Cr-Del count = 150701
// Amend  count = 375081

// 2015-06-18 V
// Cr-Del count = 33164
// Amend  count = 340880

// 2015-06-25 V
// Cr-Del count = 177622
// Amend  count = 431451

// 2015-07-2 V
// Cr-Del count = 114837
// Amend  count = 752439

// 2015-07-9 V
// Cr-Del count = 103842
// Amend  count = 814185

// 2015-07-16 V
// Cr-Del count = 39782
// Amend  count = 472150

// 2015-07-23 V
// Cr-Del count = 118150
// Amend  count = 410813

// 2015-07-30 V
// Cr-Del count = 70270
// Amend  count = 499903

// 2015-08-06 V
// Cr-Del count = 259281
// Amend  count = 235793

// 2015-08-13 V
// Cr-Del count = 99032
// Amend  count = 237024

// 2015-08-20 V
// Cr-Del count = 48616
// Amend  count = 334320

// 2015-08-27 V
// Cr-Del count = 94149
// Amend  count = 305305

// 2015-09-03 => 期數 201536 V
// Cr-Del count = 134756
// Amend  count = 551502

// 2015-09-10 V
// Cr-Del count = 190256
// Amend  count = 352089

// 2015-09-17 V
// Cr-Del count = 80394
// Amend  count = 512852

// 2015-09-24 V
// Cr-Del count = 43858
// Amend  count = 363640

// 2015-10-01 V
// Cr-Del count = 115452
// Amend  count = 298469

// 2015-10-08 V
// Cr-Del count = 113522 -> 112593 + 929
// Amend  count = 461793 -> 461803 -> diff = 10

// 2015-10-15 V
// Cr-Del count = 896939
// Amend  count = 565876

// 2015-10-22 V
// Cr-Del count = 53087
// Amend  count = 449311

// 2015-10-29 V
// Cr-Del count = 103226
// Amend  count = 950519

// 2015-11-05 V 
// Cr-Del count = 42893
// Amend  count = 393992

// 2015-11-12
// Cr-Del count = 73496
// Amend  count = 1118250

// 2015-11-19
// Cr-Del count =
// Amend  count =

// 2015-11-26
// Cr-Del count =
// Amend  count =

// 2016-05-12
// Cr-Del count = 115161
// Amend  count = 1064748

// 2015-MM-dd
// Cr-Del count = 
// Amend  count = 

def query = "2016-05-12"

def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES", "EP",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO", "JP",
    "KE", "KG", "KR", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT", "TW",
    "UA", "US", "UY", "UZ",
    "VN",
    "WO",
    "YU",
    "ZA", "ZM", "ZW"
]

println "countryList = ${countryList.size()}"

def fileType1TotalCount = 0
def fileType2TotalCount = 0

countryList.each { cc -> 
    
    println "query country = ${cc}"
    
    def checkDocdbDate = DateUtil.parseDate(query)
    
    def fileType1Count = queryCountryCount(db, checkDocdbDate, 1, cc)
    fileType1TotalCount = fileType1TotalCount + fileType1Count
    println "${cc}, checkDate = ${query}, fileType 1 count = ${fileType1Count}"
    //
    
    def fileType2Count = queryCountryCount(db, checkDocdbDate, 2, cc)
    fileType2TotalCount = fileType2TotalCount + fileType2Count
    println "${cc}, checkDate = ${query}, fileType 2 count = ${fileType2Count}"
    
}

println "================================================"
println "fileType1TotalCount = ${fileType1TotalCount}"
println "fileType2TotalCount = ${fileType2TotalCount}"

/**
 * 
 * @param db
 * @param checkDocdbDate
 * @param type
 * @param cc
 * @return
 */
def queryCountryCount (db, checkDocdbDate, type, cc) {
    
    return db.PatentRawDOCDB.count([docdbDoDate: checkDocdbDate, fileType:type, country: cc])
}

// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-03-26T00:00:00Z"), fileType:1, 'data.xml':{$regex: /status=\"C\"/}}).count();
// def createCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"C\"/]])
// println "createCount = ${createCount}"

// def deleteCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"D\"/]])
// println "deleteCount = ${deleteCount}"

println "finished..."
