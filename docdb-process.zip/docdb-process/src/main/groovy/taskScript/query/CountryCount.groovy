/**
 * 查詢各國在Lv2的數量
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

// db.PatentInfoDOCDB.find({_id: ObjectId("558bc101b4411f24f1e1de14")})

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

// other country = 95 (solr other country = 90), 即有PTO = 7
// BA count = 0
// DO count = 0
// KZ count = 0
// TT count = 0
// UZ count = 0
def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE", "KG", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT",
    "UA", "UY", "UZ",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

println "to start..."

countryList.each { cc ->
    
    def country = db.PatentInfoDOCDB.count(country:cc)
    
    if (country == 0) {
        
        println "${cc} count = 0"
    }
        
}

println "finished..."

