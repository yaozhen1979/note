/**
 * 依國別分別來查詢Lv1和Docdb Regular DB 數量是否match.
 */
import org.utils.MongoUtil

import org.bson.types.ObjectId

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv1Db = client.getDB("PatentRawDOCDB")
def db = client.getDB("PatentRegularDOCDB")

// ccList size = 102
def ccList =  [
//    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY", 
//    "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ", 
//    "DD", "DE", "DK", "DO", "DZ", "EA", "EC", "EE", "EG", "EP", 
//    "ES", "FI", "FR", "GB", "GC", "GE", "GR", "GT", "HK", "HN", 
//    "HR", "HU", "ID", "IE", "IL", "IN", "IS", "IT", "JO", 
//    "JP", "KE", "KG", "KR", "KZ", "LT", "LU", "LV", 
//    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY", 
//    "NI", "NL", "NO", "NZ", "OA", "PA", "PE", "PH", "PL", "PT", 
//    "RO", "RS", "RU", "SE", "SG", "SI", "SK", "SM", "SU", "SV", 
//    "TH", "TJ", "TN", "TR", "TT", "TW", "UA", "US", "UY", "UZ", "VN", 
//    "WO", "YU", "ZA", "ZM", 
    "ZW"
]

println "ccList count = ${ccList.size()}"

def totalCount = 0

ccList.each { cc ->
    //
    def count = db.getCollection("PatentRegularDOCDB${cc}").count()
    // regularFlag:true ???
    def lv1Count = lv1Db.PatentRawDOCDB.count([country:cc, regularFlag:true])

    def msg = (count == lv1Count ? "MATCH !!!" : "NO MATCH !!!")
    println "country: ${cc}, lv1Count = ${lv1Count}, regularCount = ${count}, ${msg}"
    //
    totalCount += count
}

def rawDataCount = lv1Db.PatentRawDOCDB.count()
//
println "lv1 totoal count = ${rawDataCount}"
println "regular db count = ${totalCount}"

println "finished..."
