import java.text.SimpleDateFormat
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

// test ip : 127.0.0.1
// prod ip : 10.60.90.101
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// 測試DB = TestInfoDOCDB / TonyDB
// Prod DB = PatentInfoDOCDB
def lv2Db = client.getDB("PatentInfoDOCDB")

println "start parsing kindcode.csv"

/**
 * 2015-07-19 -> doc/kindcode.csv 為重新整理過的kindcode規則
 * 2015-08-21 -> doc/kindcode_update.csv 為更新Others: XXXX => Others
 * 2015-08-21 -> 個別更新, 則可以使用test.csv
 * 2015-08-24 -> 當startDate = null時, default date = DateUtil.parseDate("17000101 12:00:00", "yyyyMMdd hh:mm:ss")
 *               當endDate = null時, default date = DateUtil.parseDate("99991231 23:59:59", "yyyyMMdd hh:mm:ss")
 */
new File("doc/test.csv").eachLine { line ->
    
    def data = line.split(",")
    // println "data = ${data}"
    
    def insertData = [:]
    insertData << [country: data[0]]
    insertData << [kindcode: data[1]]
    //
    insertData << [startDate:  DateUtil.parseDate(data[2]) ?: DateUtil.parseDate("1700-01-01 12:00:00")]
    insertData << [endDate: DateUtil.parseDate(data[3]) ?: DateUtil.parseDate("9999-12-31 23:59:59")]
    //
    insertData << [number: data[4]]
    insertData << [patentType: data[5]]
    insertData << [stat: parseStat(data[6])]
    insertData << [ruleFlag: Integer.parseInt(data[7])]
    
    // println "insertData = ${insertData}"
    
    lv2Db.getCollection("KindCodeMap").insert(insertData)
    
}

def parseStat(stat) {
    //
    if (stat == 'Publication') {
        return 1;
    } else if (stat == 'Issued') {
        return 2;
    } else {
        //state : Both
        return 3;
    }
}

println "finished..."
