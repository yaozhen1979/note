/**
 * 恢復資料到最早一筆的資料狀態, 且保留ObjectId.
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

// db.PatentInfoDOCDB.find({_id: ObjectId("558bc101b4411f24f1e1de14")})

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

/*
 *  TODO:
 *  Test: TestInfoDOCDB
 *  Prod: PatentInfoDOCDB
 */
def db = client.getDB("PatentInfoDOCDB")

// GR lv2._id = 55a4dd86b4411f24f116d6a8
def findData = db.PatentInfoDOCDB.findOne([_id: new ObjectId("55865bf2b4411f24f1d552c8")])

println "findData.history[0] = ${findData.history[0]}"

def lv2Id = findData._id
def firstRawDataId = findData.history[0].rawDataId

println "lv2Id = ${lv2Id}"
println "firstRawDataId = ${firstRawDataId}"

//country: dataMap.country,
//patentNumber: dataMap.patentNumber,
//kindcode: dataMap.kindcode
//stat: dataMap.stat

def saveOriginDataMap = [
    _id:findData._id, 
    country:findData.country, 
    patentNumber: findData.patentNumber,
    kindcode: findData.kindcode
    // stat: findData.stat
]

println "recovery data to saveOriginDataMap = ${saveOriginDataMap}"

// db.PatentInfoDOCDB.update([_id: new ObjectId(findData._id)], saveOriginDataMap)
db.PatentInfoDOCDB.save(saveOriginDataMap)

println "finished..."
