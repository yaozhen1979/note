/**
 *  工具程式:
 *  
 *  unset docdb lv2 redmine
 *  
 *  2015-09-11:已完成
 *  
 *  test lv2._id = 557e1d6ba28219ce5ef30b90
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil
import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE", "KG", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT",
    "UA", "UY", "UZ",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

println "countryList = ${countryList.size()}"

countryList.each { cc ->
    
    def queryMap = [country: cc, 'redmine.bug':[$exists: true]]
    unsetRedmine(db, queryMap)
}

// def queryMap = [_id: new ObjectId("557e1d6ba28219ce5ef30b90")]
// unsetRedmine(db, queryMap)

println "finished..."


def unsetRedmine(db, queryMap) {
    //
    
    // batch process
    BulkWriteOperation infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
    
    // 目前處理筆數
    def currentCount = 0
    // 目前bulk筆數
    def countOfBulk = 0
    // 每次bulk execute總筆數
    def sizeOfBulk = 500
    
    def errCount = 0
    
    db.PatentInfoDOCDB.find(queryMap).each { it ->
        
        def unsetMap = [$unset: [redmine: ""]]
        infoDOCDBBulk.find(new BasicDBObject("_id", it._id)).updateOne(new BasicDBObject(unsetMap))
        countOfBulk++;
        
        // countOfBulk == sizeOfBulk 時, 則執行bulk execute.
        if (countOfBulk.mod(sizeOfBulk) == 0) {
            //
            println "batch execute ...."
            //
            infoDOCDBBulk.execute()
            // init bulk again
            infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
            countOfBulk = 0
        }
        
        println "${it.country} process / ${++currentCount}"
        
    }   // end find query
    
    // execute rest bulk count
    if (countOfBulk > 0) {
        //
        println "rest batch execute ...."
        infoDOCDBBulk.execute()
    }
    
}
