package taskScript.mike

import org.bson.types.ObjectId
import org.utils.MongoUtil

class RecoveryData {

    static main(args) {
        
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = dbClient.getDB("TonyDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def db101 = dbClient.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB101 = db101.getCollection("PatentInfoDOCDB")
        
        int count = 0
        
        new File("doc/docdbNotFount.txt").eachLine { line ->
            
            // println line.toString()
            // patentInfoDOCDB101.remove([_id: new ObjectId(line.toString().trim())])
            
            //
            
        }
        
        println "finished..."
        
    }

}
