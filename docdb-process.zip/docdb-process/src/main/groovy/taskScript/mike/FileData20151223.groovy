package taskScript.mike

import org.bson.types.ObjectId
import org.utils.MongoUtil

class FileData20151223 {

    static main(args) {
        
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = dbClient.getDB("TonyDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def db101 = dbClient.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB101 = db101.getCollection("PatentInfoDOCDB")
        
        int count = 0
        
        new File("doc/docdbNotFount_02.txt").eachLine { line -> 
            
            // println line.toString()
            
            def queryData = patentInfoDOCDB.findOne([_id : new ObjectId(line.toString().trim())])
            
            if (!queryData) {
                println "_id = ${line.toString()}, no exist"
            }
            
            def country = queryData.country
            def patentNumber = queryData.patentNumber
            def kindcode = queryData.kindcode
            def doDate = queryData.doDate
            
            def queryMap = [country:country, patentNumber:patentNumber, kindcode:kindcode, doDate:doDate]
            def query101Cursor = patentInfoDOCDB101.find(queryMap)
            
            if (query101Cursor.count() == 0) {
                println "_id = ${line.toString()}, queryMap = ${queryMap} no exist"
            } else if (query101Cursor.count() > 1) {
                println "_id = ${line.toString()}, queryMap = ${queryMap} query over 1 size"
            } else {
            
                def saveData = query101Cursor[0]
                
                println "count = ${++count}"
                println "_id = ${saveData._id}"
                patentInfoDOCDB.save(saveData)
                patentInfoDOCDB101.remove([_id: saveData._id])
                saveData._id = new ObjectId(line.toString().trim())
                patentInfoDOCDB101.save(saveData)
            }
            
            //
            
            
        }
        
        println "finished..."
    }

}
