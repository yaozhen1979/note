package org.utils

import jodd.jerry.Jerry
import static jodd.jerry.Jerry.jerry as $

import org.utils.DateUtil
import org.utils.StringUtil

class PatentInfoUtil {
    
    /**
     * 
     * @param dom
     * @return
     * @throws Exception
     */
    static parseData(Jerry dom) throws Exception {
        
        def dataMap = [:]
        
        dataMap << ["pto" : "DOCDB"]
        
        dataMap << ["patentNumber" : getPatentNumber(dom)]
        dataMap << ["familyId" : getFamilyId(dom)]
        dataMap << ["kindcode" : getKindcode(dom)]
        
        dataMap << ["country" : getCountry(dom)]
        dataMap << ["appNumber" : getAppNo(dom)]
        dataMap << ["appDate" : DateUtil.parseDate(getAppDate(dom))]
        dataMap << ["doDate" : DateUtil.parseDate(getDoDate(dom))]
        
        dataMap << ["title" : getTitleMap(dom)]
        dataMap << ["brief" : getBriefMap(dom)]
        
        dataMap << ["ipcs" : getIpcs(dom)]
        dataMap << ["ipcsNormal" : getIpcsNormal(dom)]
        dataMap << ["mainIPC" : getMainIpc(dom)]
        dataMap << ["mainIPCNormal" : getMainIpcNormal(dom)]
        
        dataMap << ["cpcs" : getCpcs(dom)]
        dataMap << ["cpcsNormal" : getCpcsNormal(dom)]
        dataMap << ["mainCPC" : getMainCPC(dom)]
        dataMap << ["mainCPCNormal" : getMainCPCNormal(dom)]
        
        // TODO: only for JP
        dataMap << ["fis" : getFis(dom)]
        dataMap << ["mainFI" : getMainFI(dom)]
        dataMap << ["fterms" : getFterms(dom)]
        dataMap << ["mainFTerm" : getMainFTerm(dom)]
        
        // TODO: only for US
        dataMap << ["uspcs" : getDocus(dom)]
        dataMap << ["mainUSPC" : getMainDocu(dom)]
        
        dataMap << ["docdbAssignees" : getApplicants(dom, "docdb")]
        dataMap << ["docdbAAssignees" : getApplicants(dom, "docdba")]
        dataMap << ["assignees" : getApplicants(dom, "docdb")]
        
        dataMap << ["docdbInventors" : getInventors(dom, "docdb")]
        dataMap << ["docdbAInventors" : getInventors(dom, "docdba")]
        dataMap << ["inventors" : getInventors(dom, "docdb")]
        
        dataMap << ["lang" : getLang(dom)]
        
        dataMap << ["priorityPatents" : getPriorityPatents(dom)]
        dataMap << ["citedPatents" : getCitedPatents(dom)]
        dataMap << ["otherReferences" : getOtherReferences(dom)]
        
        // remove value is empty
        dataMap.iterator().with { it ->
            it.each { entry ->
                if( !entry.value ) it.remove()
            }
        }
        
        // println "dataMap = ${dataMap}"
        
        return dataMap
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getPatentNumber(Jerry dom) {
        return dom.find('exch\\:bibliographic-data > exch\\:publication-reference[data-format="docdb"]').find("doc-number").text()
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getFamilyId(Jerry dom) {
        
        def familyId = dom.find('exch\\:exchange-document').attr('family-id')
        
        if (familyId == "") {
            return ""
        } else {
            return Integer.valueOf(familyId)
        }
        
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getKindcode(Jerry dom) {
        return dom.find('exch\\:exchange-document').attr('kind')
    }
    
    /**
     * 
     * backfile status = null
     * Create status = C
     * Del status = D
     * Amend status = A
     * 
     * 取得檔案來源
     * 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
     * 
     * @param dom
     * @return
     */
    static getStatus(Jerry dom, fileType) {
        
        def status = dom.find('exch\\:exchange-document').attr('status')
        
        if (fileType == 0) {
            status = "B"    
        } else if (fileType == 1) {
            status = status
        } else if (fileType == 2) {
            status = status
        } else if (fileType == 3) {
            // 因目前為此, 皆還未對Replacement來做資料處理, 所以先定status為"R".
            status = "R"
        }
        
        return status
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getCountry(Jerry dom) {
        return dom.find('exch\\:exchange-document').attr('country');
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getAppNo(Jerry dom) {
        
        def cc = dom.find('exch\\:exchange-document').attr('country');
        
        def originPto = ["CN", "US", "JP", "KR", "EP", "WO", "TW"];
        
        if (originPto.indexOf(cc) > -1) {
            //
            return dom.find('exch\\:bibliographic-data > exch\\:application-reference[data-format=original]').find('doc-number').text();
        } else {
            //
            def appNo = dom.find('exch\\:bibliographic-data > exch\\:application-reference[data-format=epodoc]').find('doc-number').text();
            
            // 因應前台要求, 取得的appNo中前二碼的國碼去除.
            return appNo.replaceAll(~/^${cc}/, "")
        }
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getAppDate(Jerry dom) {
        return dom.find('exch\\:bibliographic-data > exch\\:application-reference[data-format=docdb] > document-id > date').text();
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getDoDate(Jerry dom) {
        // 有國家會有出現 data-publ 無此欄位的情況, 所以改取 date-added-docdb, 例如 DE
        return (!!dom.find('exch\\:exchange-document').attr('date-publ') ? dom.find('exch\\:exchange-document').attr('date-publ') : dom.find('exch\\:exchange-document').attr('date-added-docdb'));
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getTitleMap(Jerry dom) {
        
        def titleList = dom.find('exch\\:invention-title')
        
        def titleMap = titleList.inject([:]) { result, title ->
            
            if (title.attr('lang') != null) {
                result.put(title.attr('lang'), StringUtil.unwrap(title.text(), "\""))
            }
            
            if (title.attr('data-format') == 'original') {
                result.put("original", StringUtil.unwrap(title.text(), "\""))
            }
            
            return result
        }
        
        return titleMap
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getBriefMap(Jerry dom) {
        
        def briefList = dom.find('exch\\:abstract')
        
        /*
         *  判斷 data-format = "docdba" 的 abstract-source 是否為 translation,
         *  否則通常為 national office,
         *  但如果以[translation]和[national office]同時存在, 則以[translation]為主
         */
        def isTranslation = false;

        def briefMap = briefList.inject([:]) { result, brief ->

            if (brief.attr('lang') != null) {

                if (brief.attr('abstract-source') == 'translation') {
                    isTranslation = true;
                    result.put(brief.attr('lang'), StringUtil.unwrap(brief.text(), "\""))
                } else if (isTranslation == false) {
                    result.put(brief.attr('lang'), StringUtil.unwrap(brief.text(), "\""))
                }

            }

            if (brief.attr('data-format') == 'original') {
                result.put("original", StringUtil.unwrap(brief.text(), "\""))
            }

            return result
        }
        
        return briefMap
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getIpcs(Jerry dom) {
            
        def ipcs = []
        dom.find("exch\\:classifications-ipcr > classification-ipcr > text").each{element ->
            def ipc = element.text();
            def text = ipc.split(/(?i)\s+/);
            if (ipc.trim() != '' && text.length > 1) {
                ipcs.push(text[0] + " " + text[1]);
            } else {
                // TODO: special case: ???
                def specialCpcFmt = text[0].split("/")
                if (specialCpcFmt.length == 2) {
                    //
                    ipcs.push(text[0].substring(0, 4) + " " + text[0].substring(4));
                } else {
                    throw new Exception("ipc error format")
                }
            
            }
    
        };
        
        return ipcs;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainIpc(Jerry dom) {
        return !!getIpcs(dom) ? getIpcs(dom)[0] : "";
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getIpcsNormal(Jerry dom) {
            
        def ipcs = []
        dom.find("exch\\:classifications-ipcr > classification-ipcr > text").each{element ->
            def ipc = element.text();
            def text = ipc.split(/(?i)\s+/);
            if (ipc.trim() != '' && text.length > 1) {
                ipcs.push(getIPCNormal(text[0] + " " + text[1]));
            } else {
                // TODO: special case: ???
                def specialCpcFmt = text[0].split("/")
                if (specialCpcFmt.length == 2) {
                    //
                    ipcs.push(getIPCNormal(text[0].substring(0, 4) + " " + text[0].substring(4)));
                } else {
                    throw new Exception("ipc error format")
                }
            
            }
    
        };
        
        return ipcs;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainIpcNormal(Jerry dom) {
        return !!getIpcsNormal(dom) ? getIpcsNormal(dom)[0] : "";
    }
    
    /*
     * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
     *
     * EX: E02B 15/10 => E02B0015100000
     *
     */
    static String getIPCNormal(String ipc) {
        
        // 如已正規化後, 則return原值.
        if (ipc ==~ /^\w{4}\d{4}\d{6}$/) {
            return ipc;
        }
        
        // 未正規化 pattern
        def ipcGroup1 = ipc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
        def ipcGroup2 = ipc.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
        
        if (ipcGroup1.size() > 0) {
            
            if (!ipcGroup1[0][1] || !ipcGroup1[0][2] || !ipcGroup1[0][3]) {
                //
                throw new Exception("ipc = ${ipc} normal pattern error")
            } else {
                return ipcGroup1[0][1] + StringUtil.leftPad(ipcGroup1[0][2], 4, '0') + StringUtil.rightPad(ipcGroup1[0][3], 6, '0')
            }
            
        } else if (ipcGroup2.size() > 0) {
        
            if (!ipcGroup2[0][1] || !ipcGroup2[0][2]) {
                //
                throw new Exception("ipc = ${ipc} normal pattern error")
            } else {
                //
                return ipcGroup2[0][1] + StringUtil.leftPad('', 10, '0')
            }
        
        } else {
            //
            // println "no match pattern..."
            throw new Exception("ipc = ${ipc} no match pattern")
        }
    }
    
    /**
     * useless
     * 
     * @deprecated
     * @param dom
     * @return
     */
    static getOriginPcs(Jerry dom) {

        def originPcs = [];
        dom.find("exch\\:classification-national > text").each{element ->
            def originPc = element.text();
            originPcs.push(originPc.trim());
        };

        return originPcs;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getCpcs(Jerry dom) {
        
        def cpcs = [];
        dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=CPC]").each{ element ->
    
            def cpc = element.parent().find("classification-symbol").text();
            def text = cpc.split(/(?i)\s+/);
            // println "cpc = ${text}"
            
            if (cpc.trim() != '' && text.length > 1) {
                cpcs.push(text[0] + " " + text[1]);
            } else {
                // special case: lv2._id = 557a98a1b4411f24f16dcf11 => cpc = G01N2291/044
                def specialCpcFmt = text[0].split("/")
                if (specialCpcFmt.length == 2) {
                    //
                    cpcs.push(text[0].substring(0, 4) + " " + text[0].substring(4));
                } else {
                    throw new Exception("cpc error format")
                }
            
            }
    
        }

        return !cpcs ? "" : cpcs;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainCPC(Jerry dom) {
        return !!getCpcs(dom) ? getCpcs(dom)[0] : "";
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getCpcsNormal(Jerry dom) {
        
        def cpcs = [];
        dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=CPC]").each{ element ->
    
            def cpc = element.parent().find("classification-symbol").text();
            def text = cpc.split(/(?i)\s+/);
            // println "cpc = ${text}"
            
            if (cpc.trim() != '' && text.length > 1) {
                cpcs.push(getCPCNormal(text[0] + " " + text[1]));
            } else {
                // special case: lv2._id = 557a98a1b4411f24f16dcf11 => cpc = G01N2291/044
                def specialCpcFmt = text[0].split("/")
                if (specialCpcFmt.length == 2) {
                    //
                    cpcs.push(getCPCNormal(text[0].substring(0, 4) + " " + text[0].substring(4)));
                } else {
                    throw new Exception("cpc error format")
                }
            
            }
    
        }

        return !cpcs ? "" : cpcs;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainCPCNormal(Jerry dom) {
        return !!getCpcsNormal(dom) ? getCpcsNormal(dom)[0] : "";
    }
    
    /*
     * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
     *
     * EX: E02B 15/10 => E02B0015100000
     *
     */
    static String getCPCNormal(String cpc) {
        
        // 如已正規化後, 則return原值.
        if (cpc ==~ /^\w{4}\d{4}\d{6}$/) {
            return cpc;
        }
        
        // 未正規化 pattern
        def cpcGroup1 = cpc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
        def cpcGroup2 = cpc.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
        
        if (cpcGroup1.size() > 0) {
            
            if (!cpcGroup1[0][1] || !cpcGroup1[0][2] || !cpcGroup1[0][3]) {
                //
                throw new Exception("cpc = ${cpc} normal pattern error")
            } else {
                
                return cpcGroup1[0][1] + StringUtil.leftPad(cpcGroup1[0][2], 4, '0') + StringUtil.rightPad(cpcGroup1[0][3], 6, '0')
            }
            
        } else if (cpcGroup2.size() > 0) {
        
            if (!cpcGroup2[0][1] || !cpcGroup2[0][2]) {
                //
                throw new Exception("cpc = ${cpc} normal pattern error")
            } else {
                //
                return cpcGroup2[0][1] + StringUtil.leftPad('', 10, '0')
            }
        
        } else {
            //
            // println "no match pattern..."
            throw new Exception("cpc = ${cpc} no match pattern")
        }
    }
    
    /**
     * TODO: 待測, 及正規化.
     * 
     * only for JP
     * 
     * @param dom
     * @return
     */
    static getFis(Jerry dom) {
        
        def fis = [];
        
        dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=FI]").each{ element ->

            def fi = element.parent().find("classification-symbol").text();
            def text = fi.split(/(?i)\s+/);
            if (fi.trim() != '' && text.length > 1) {
                fis.push(text[0] + " " + text[1]);
            } else {
                fis.push(fi);
            }

        }

        return !fis ? "" : fis;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainFI(Jerry dom) {
        return !!getFis(dom) ? getFis(dom)[0] : "";
    }
    
    /**
     * TODO: 待測, 及正規化.
     * 
     * only for JP
     * 
     * @param dom
     * @return
     */
    static getFterms(Jerry dom) {
        
        def fterms = [];
        dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=FTERM]").each{ element ->

            def fterm = element.parent().find("classification-symbol").text();
            def text = fterm.split(/(?i)\s+/);
            if (fterm.trim() != '' && text.length > 1) {
                fterms.push(text[0] + " " + text[1]);
            } else {
                fterms.push(fterm);
            }

        }

        return !fterms ? "" : fterms;
        
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainFTerm(Jerry dom) {
        return !!getFterms(dom) ? getFterms(dom)[0] : "";
    }
    
    /**
     * TODO: 待測, 及正規化.
     * 
     * only for US
     * 
     * @param dom
     * @return
     */
    static getDocus(Jerry dom) {
        
        def docus = [];
        
        dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=DOCUS]").each{ element ->

            def doc = element.parent().find("classification-symbol").text();
            def text = doc.split(/(?i)\s+/);
            if (doc.trim() != '' && text.length > 1) {
                docus.push(text[0] + " " + text[1]);
            } else {
                docus.push(doc);
            }

        }

        return !docus ? "" : docus;;
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getMainDocu(Jerry dom) {
        return !!getDocus(dom) ? getDocus(dom)[0] : "";
    }
    
    /**
     * 
     * @param dom
     * @param dataFmt docdb or docdba
     * @return
     */
    static getApplicants(Jerry dom, dataFmt) {
        
        def applicants = [];
        
        dom.find("exch\\:parties > exch\\:applicants > exch\\:applicant[data-format=" + dataFmt + "]").each{ element ->

            def applicant = [:]

            def name = element.find("exch\\:applicant-name").text();
            def address = element.find("address").text();
            def country = element.find("residence").text();
            def sequence = element.attr("sequence");

            if (!!name) {
                applicant << [
                    name : [origin: name.trim()]
                ]
            }

            if (!!address) {
                applicant << [
                    address : [origin: address.trim()]
                ]
            }

            if (!!country) {
                applicant << [
                    country : [origin: country.trim()]
                ]
            }
            
            applicant << [sequence : Integer.parseInt(sequence)]

            applicants << applicant

        }

        return applicants;
        
    }
    
    /**
     * 
     * @param dom
     * @param dataFmt docdb or docdba
     * @return
     */
    static getInventors(Jerry dom, dataFmt) {
        
        def inventors = [];
        
        dom.find("exch\\:parties > exch\\:inventors > exch\\:inventor[data-format=" + dataFmt + "]").each{ element ->

            def inventor = [:];

            def name = element.find("exch\\:inventor-name").text();
            def address = element.find("address").text();
            def country = element.find("residence").text();
            def sequence = element.attr("sequence");

            if (!!name) {
                inventor << [
                    name : [origin: name.trim()]
                ]
            }

            if (!!address) {
                inventor << [
                    address : [origin: address.trim()]
                ]
            }

            if (!!country) {
                inventor << [
                    country : [origin: country.trim()]
                ]
            }

            inventor << [sequence : Integer.parseInt(sequence)]

            inventors << inventor

        }

        return inventors;
        
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getLang(Jerry dom) {
        return dom.find('exch\\:language-of-publication').text();
    }
    
    /**
     * 
     * @param dom
     * @return
     */
    static getPriorityPatents(Jerry dom) {
        
        def priorityPatents = [];
        
        def originalData = dom.find('exch\\:priority-claims > exch\\:priority-claim[data-format=docdb]').each{ element ->

            def priorityPatent = [:];
            def country = element.find('country').text();
            // def docdbDocNumber = element.find('doc-number').text();
            def kindcode = element.find('kind').text();
            def sequence = element.attr("sequence");
            
            def epodocDocNumber = element.parent().find("exch\\:priority-claim[data-format='epodoc'][sequence='" + sequence + "'] > document-id > doc-number").text();
            // println "epodocDocNumber = ${epodocDocNumber}"
            
            // def docdbData = element.parent().find('exch\\:priority-claim[data-format=docdb][sequence=' + sequence + ']');
            // def country = docdbData.find('country').text();

            priorityPatent.pto = country;
            priorityPatent.appNumber = epodocDocNumber;
            priorityPatent.kindcode = kindcode;

            priorityPatents.push(priorityPatent);

        }

        return priorityPatents;
    }
    
    /**
     * ref: lv1._id = 5594ec1060b2b8c548cfb2ba
     * ref: db.getCollection('PatentInfoUSPTO').find({patentNumber: 'US008697693'})
     * 
     * @param dom
     * @return
     */
    static getCitedPatents(Jerry dom) {
        
        def citedPatents = [];
        
        dom.find("exch\\:references-cited > exch\\:citation").each{ element ->
    
            if (element.find("patcit").size() > 0) {
    
                def citedPatent = [:];
                def patcitData = element.find("patcit");
                def country = patcitData.find("document-id > country").text();
                def docNumber = patcitData.find("document-id > doc-number").text();
    
                if (!!docNumber) {
                    citedPatent.patentNumber = docNumber;
                }
    
                if (!!country) {
                    citedPatent.pto = country;
                }
    
                if (!!docNumber || !!country) {
                    citedPatents.push(citedPatent);
                }
    
            }
    
        }
    
        return citedPatents;
    }
    
    /**
     * ref: lv1._id = 5594ec1060b2b8c548cfb2ba
     * ref: db.getCollection('PatentInfoUSPTO').find({patentNumber: 'US008697693'})
     * 
     * @param dom
     * @return
     */
    static getOtherReferences(Jerry dom) {
        
        def otherReferences = [];
        
        dom.find("exch\\:references-cited > exch\\:citation").each{ element ->

            if (element.find("nplcit").size() > 0) {

                def otherReference = element.find("text").text();

                if (!!otherReference) {
                    otherReferences.push(otherReference);
                }

            }

        }

        return otherReferences;
    }
    
    /**
     * 2015-10-25: => 10月資料開始有問題...
     * 
     * 已下列二LV1, LV2查詢條件為列時:
     * 
     * db.PatentRawDOCDB.find({country: 'WO', 'docdbDoDate': ISODate('2015-10-08T00:00:000Z'), fileType:2, kindCode:'A8', 'data.xml': /<doc-number>2010057947/})
     * db.PatentInfoDOCDB.find({country: 'WO', patentNumber: '2010057947', kindcode: 'A8'})
     * 
     * 在WO一定會查詢出多筆資料, 則經由EPO WorldWild查詢後, 也證實出該筆資料同時存在二筆kindcode=A8的資料,
     * 經差異比對後, 發現主要只有[publication date]不一樣, 其餘資料也大同小異...
     * 
     * 所以決定lv2Query,再放入[doDate]來當做判斷是否為惟一一筆資料的查詢條件.
     * 
     * 
     * @param dataMap
     * @return
     */
    static lv2Query(dataMap, status) {
        
        def lv2Query;
        
//        lv2Query = [
//            country: dataMap.country,
//            patentNumber: dataMap.patentNumber,
//            kindcode: dataMap.kindcode
//        ]
        
        if (status == "D" || status == "CV" || status == "DV") {
            lv2Query = [
                country: dataMap.country,
                patentNumber: dataMap.patentNumber,
                kindcode: dataMap.kindcode
            ]
        } else {
            lv2Query = [
                country: dataMap.country,
                patentNumber: dataMap.patentNumber,
                kindcode: dataMap.kindcode,
                doDate: dataMap.doDate
            ]
        }
        
        return lv2Query
    }
    
    /**
     * stat = 1 為[公開], stat = 2為[公告], stat = 3為[公開/公告]
     * 
     * 並依stat來決定openNumber/openDate or decisionNumber/decisionDate
     * 
     * @param dataMap
     * @return
     */
    static getStat(dataMap) {
        
        if (dataMap.stat == 1) {
            //
            dataMap << ["openNumber" : dataMap.patentNumber]
            dataMap << ["openDate" : dataMap.doDate]
            
        } else if (dataMap.stat == 2) {
            //
            dataMap << ["decisionNumber" : dataMap.patentNumber]
            dataMap << ["decisionDate" : dataMap.doDate]
        
        } else if (dataMap.stat == 3) {
            //
            dataMap << ["openNumber" : dataMap.patentNumber]
            dataMap << ["openDate" : dataMap.doDate]
            //
            dataMap << ["decisionNumber" : dataMap.patentNumber]
            dataMap << ["decisionDate" : dataMap.doDate]
        }
        
        return dataMap
    }
    
}