package org.utils

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient

import org.bson.types.ObjectId

class CountryUtil {
    
    /**
     * 取得 Docdb 全部國家的 Country Code [包含即有PTO]
     * 
     * @return
     */
    static List<String> getDocdbCountryList() {
        
        def countryList = [
            "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
            "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ",
            "DD", "DE", "DZ", "DK", "DO",
            "EA", "EC", "EE", "EG", "ES", "EP",
            "FI", "FR",
            "GB", "GC", "GE", "GR", "GT",
            "HK", "HN", "HR", "HU",
            "ID", "IE", "IL", "IN", "IS", "IT",
            "JO", 
            "JP",
            "KE", "KG", "KR", "KZ",
            "LT", "LU", "LV",
            "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
            "NI", "NL", "NO", "NZ",
            "OA",
            "PA", "PE", "PH", "PL", "PT",
            "RO", "RS", "RU",
            "SE", "SG", "SI", "SK", "SM", "SU", "SV",
            "TH", "TJ", "TN", "TR", "TT", "TW",
            "UA", "US", "UY", 
            // "UZ",
            "VN",
            "WO",
            "YU",
            "ZA", "ZM", "ZW"
        ]
        
        // println "countryList = ${countryList.size()}"
        
        return countryList
    }
    
    /**
     * 取得即有 PTO Country Code
     * 
     * @return
     */
    static List<String> getOriginPTOList() {
        
        def originPTOList = ["CN", "EP", "JP", "KR", "US", "TW", "WO"]
        
        return originPTOList
    }
    
    /**
     * 取得 Docdb 中其它國家的 Country Code.
     * 
     * @return
     */
    static List<String> getOtherCountryList() {
        
        def docdbCountryList = getDocdbCountryList();
        
        def originPTOList = getOriginPTOList();
        
        return  docdbCountryList - originPTOList;
    }
    
    /**
     * 取得 Docdb 特定的 Country Code, 可依發生 Exception 的國家來指定.
     * 
     * @return
     */
    static List<String> getSomeCountryList() {
        
        def countryList = [
        ]
        
        // println "countryList = ${countryList.size()}"
        
        return countryList
    }
    
    static List<String> getTestCountryList() {
        
        def countryList = [
            "IL"
        ]
        
        // println "countryList = ${countryList.size()}"
        
        return countryList
    }
    
    static List<String> getMarshallCountryList() {
        
        def countryList = [
        
        ]
        
        return countryList
    }
    
    static List<String> getTransferCountryList() {
        
        def countryList = [
            
        ]
        
        return countryList
    }
    
}
