package org.utils

class MiscUtil {
    
    /**
     * 判斷是否為重複的relRawdatas._id
     * 
     * @param newData
     * @param existData
     * @param patentNumber 只有WG會有傳patentNumber進來
     * @return
     */
    static getRelRawdatas(def newData, def existData) {
        
        def dataMap = [:]
        
        if (!!existData?.relRawdatas) {
            // 排除重複insert or update的資料
            if (existData.relRawdatas[-1]._id != newData._id) {
                dataMap << [
                    "relRawdatas" : existData.relRawdatas << [
                        _id: newData._id
                    ]
                ]
            } else {
                dataMap << ["relRawdatas" : existData.relRawdatas]
            }
            
        } else {
            def relRawdatas = [] << [_id: newData._id]
            dataMap << ["relRawdatas" : relRawdatas]
        }
        
        return dataMap
    }
    
    /**
     * 判斷是否為重的tagAndFile 
     * 
     * @param existData
     * @param codeLevel rawLevel, marshallLevel, infoLevel
     * @return
     */
    static getTagAndFile(def existData, String codeLevel) {
        
        def dataMap = [:]
        
        def codeName = null
        if (codeLevel == "rawLevel") {
            codeName = PropertiesUtil.getRawLevelCode()
        } else if (codeLevel == "marshallLevel") {
            codeName = PropertiesUtil.getMarshallLevelCode()
        } else if (codeLevel == "infoLevel") {
            codeName = PropertiesUtil.getInfoLevelCode()
        } else {
            throw new Exception("tagAndFile codeLevel error")
        }
        
        def tag = PropertiesUtil.getVersionTag()
        
        if (!!existData?.tagAndFile) {
            
            if (existData.tagAndFile[-1].file != codeName || 
                existData.tagAndFile[-1].tag != tag) {
                
                dataMap << ["tagAndFile" : existData.tagAndFile <<
                    [
                        "file" : codeName,
                        "tag" : tag
                    ]
                ]
                
            } else {
                dataMap << ["tagAndFile" : existData.tagAndFile]
            }
            
        } else {
            //
            dataMap << ["tagAndFile" : [] << 
                [
                    "file" : codeName,
                    "tag" : tag
                ]
            ]
        }  // end existData.tagAndFile
        
        return dataMap
    }
    
    static getMongoSyncFlag(def existData) {
        
        def dataMap = [:]
        if (!!existData) {
            def mongoSyncFlagData = existData.mongoSyncFlag
            mongoSyncFlagData.last = new Date()
            dataMap << ["mongoSyncFlag": mongoSyncFlagData]
        } else {
            def now = new Date()
            def mongoSyncFlagData = ["init" : now, "last" : now]
            dataMap << ["mongoSyncFlag" : mongoSyncFlagData]
        }
        
        return dataMap
    }
    
    /**
     * @deprecated
     * 
     * 去除map中value為null
     * 
     * @param map
     * @return
     */
    static removeMapNullValue(data) {
        
        def newMap = [:]
        
        if (data.getClass() == java.util.LinkedHashMap) {
            //
            data.each { key, value ->
                if (value.getClass() == java.util.LinkedHashMap || value.getClass() == java.util.ArrayList) {
                    removeMapNullValue(value)
                } else {
                    if (!!value) {
                        newMap[key] = value
                    }
                }
                
            }
            
        } else if (data.getClass() == java.util.ArrayList || data.getClass() == com.mongodb.BasicDBList) {
            
            data.each { value -> 
                removeMapNullValue(value)
            }
        
        }
        
        return (newMap.size() > 0) ? newMap : null
    }  // end removeMapNullValue
    
    /**
     * replace <residence><country>0T</country></residence> = ""
     * 以0為開頭的country
     * 
     * AT rawDataid = 5576c75760b232df3c4ac0a9
     * 
     * @param xml
     * @return
     */
    static removeResidenceCountry(String xml) {
        // return xml.replaceAll("<residence>[\\s]*?<country>0[\\S\\s]*?</country>[\\s]*?</residence>", "")
        return xml.replaceAll("<residence>[\\s]*?<country>(0\\S*?|KK|XX|ZZ|UK|us|TA|NN)</country>[\\s]*?</residence>", "")
    }
    
}
