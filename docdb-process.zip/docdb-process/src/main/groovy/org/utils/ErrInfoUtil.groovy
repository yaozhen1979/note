package org.utils

class ErrInfoUtil {
    
        static writeKindcodeErrDoc(lv1) throws Exception {
            
            def errData = [:]
            errData << ['doDate': new Date()]
            errData << ['doc': ['country': lv1.country, 'lv1Id': lv1._id]]
            errData << ['msg': ['kindcode': lv1.kindCode, 'desc': "kindcode not found"]]
            
            return errData
        }
        
        /**
         * TODO: errCodeMap ???
         * "dataNotFound": 1
         * "errFormat": 2
         * "errKindcode": 3
         * "errNumber": 4
         */ 
        
}
