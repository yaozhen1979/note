package org.utils

import org.utils.PropertiesUtil

import docdb.importer.marshalldata.DocdbEntityResolver
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.w3c.dom.Document;
import org.xml.sax.SAXException
import javax.xml.bind.JAXBContext;

import org.eclipse.persistence.jaxb.JAXBContextProperties;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.oxm.MediaType;

import org.jaxb.ExchangeDocument

class JaxbUtil {
    
    private static boolean validInited;
    private static boolean inited;
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    //
    private static DocumentBuilder documentBuilder
    private static Validator validator
    
    /**
     * verify xml data
     *
     * @throws Exception
     */
    private static void jaxbInit() throws Exception {

        if (inited) {
            return;
        }

        JAXBContext jc = JAXBContext.newInstance("org.jaxb");
        unmarshaller = jc.createUnmarshaller();

        Map<String, Object> props = new HashMap<>();

        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        JAXBContext jc1 = JAXBContext.newInstance("org.jaxb",
                ExchangeDocument.class.getClassLoader(), props);

        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        inited = true;
    }
    
    public static void initValidate() {
        
        if (validInited) {
            return
        }
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setValidating(false);
        dbf.setNamespaceAware(true);
        documentBuilder = dbf.newDocumentBuilder();
        
        SchemaFactory factory = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        factory.setResourceResolver(new DocdbEntityResolver())
        
        String xsdPath = PropertiesUtil.getXsdFile()
        File schemaLocation = new File(xsdPath);
        Schema schema = factory.newSchema(schemaLocation);
        validator = schema.newValidator(); 
        
        validInited = true 
    }
    
    /**
     * 
     * @param xml
     * @param xsd
     * @return
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public static boolean isValidate(String xml) throws SAXException, IOException,
        ParserConfigurationException {
        
        initValidate()
            
        InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8"));
        Document doc = documentBuilder.parse(is);

        validator.validate(new DOMSource(doc));

        return true
    }
    
    /**
     * 
     * @param xml
     * @return
     */
    public static xml2Json(String xml) {
        
        jaxbInit();

        InputStream xmlStream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
        Object elem = unmarshaller.unmarshal(xmlStream);
        StringWriter sw = new StringWriter();
        marshaller.marshal(elem, sw);
        
        return sw.toString()
    }
    
}
