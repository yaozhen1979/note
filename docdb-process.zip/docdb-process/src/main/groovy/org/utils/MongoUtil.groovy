package org.utils

import com.mongodb.MongoClientOptions
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient

import org.bson.types.ObjectId

class MongoUtil {
    
    static GMongoClient connect3X(userId, userPwd, ip, port,  defaultCollection) {
        
        /*
         * https://api.mongodb.org/java/2.13/com/mongodb/MongoClientOptions.html
         * https://api.mongodb.org/java/2.13/com/mongodb/MongoClientOptions.Builder.html
         */
        MongoClientOptions options = MongoClientOptions.builder()
            .connectionsPerHost(20)
            .alwaysUseMBeans(true)
            .writeConcern(com.mongodb.WriteConcern.ACKNOWLEDGED)
            // .autoConnectRetry(true)
            .build();
        
        def auth = MongoCredential.createCredential(userId, defaultCollection, userPwd as char[])
        def client = new GMongoClient(new ServerAddress(ip, port), [auth], options)
        return client
    }
    
    static GMongoClient connect2X(userId, userPwd, ip, port,  defaultCollection) {
        
        def auth = MongoCredential.createMongoCRCredential(userId, defaultCollection, userPwd as char[])
        def client = new GMongoClient(new ServerAddress(ip, port), [auth])
        
        return client
    }
    
}