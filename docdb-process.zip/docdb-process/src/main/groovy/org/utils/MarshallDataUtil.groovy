package org.utils

import org.common.Constants

class MarshallDataUtil {
    
    /**
     * marshall id = country + patentNumber + doDate + kindcode
     * 
     * @param jsonStr
     * @return
     */
    static generateId(def jsonObject) {
        def marshallId = null
        jsonObject."exchange-document"."bibliographic-data"."publication-reference".each { it -> 
            if (it."data-format" == "docdb") {
                def country = it."document-id".country
                def patentNumber = it."document-id"."doc-number"
                def kindcode = it."document-id".kind
                def doDate = it."document-id".date
                marshallId = country + patentNumber + kindcode + doDate
            }
        }
        return marshallId
    }
    
    static getPatentNumber(def jsonObject) {
        def patentNumber = null
        jsonObject."exchange-document"."bibliographic-data"."publication-reference".each { it ->
            if (it."data-format" == "docdb") {
                patentNumber = it."document-id"."doc-number"
            }
        }
        return patentNumber
    }
    
    static getDoDate(def jsonObject) {
        def doDate = null
        jsonObject."exchange-document"."bibliographic-data"."publication-reference".each { it ->
            if (it."data-format" == "docdb") {
                doDate = it."document-id".date
            }
        }
        return doDate
    }
    
    /**
     * 
     * @param expansionDataMap
     * @param doDate
     * @param patentType
     * @param existData = null
     * @return
     */
    static generateMarshallData(def expansionDataMap, def rawData, def existData = null) {
        
        def marshallData = [:]
        
        if (!!existData) {
            
            // 保留原有objectId
            marshallData << ["_id" : existData._id]
            def dataMap = existData.data
            dataMap.expansion = expansionDataMap
            marshallData << ["data": dataMap]
            
        } else {
            // marshallData << ["_id" : generateId(expansionDataMap)]
            marshallData << ["_id" : rawData._id]
            def dataMap = [:] << ["expansion" : expansionDataMap]
            marshallData << ["data" : dataMap]
        }
        
        marshallData << [country : rawData.country]
        marshallData << [patentNumber : getPatentNumber(expansionDataMap)]
        marshallData << [kindcode : rawData.kindcode]
        marshallData << [doDate : getDoDate(expansionDataMap)]
        //
        marshallData << [fileType : rawData.fileType]
        marshallData << ["docdbDoDate" : rawData.docdbDoDate]
        marshallData << ["pto" : Constants.PTO]
        marshallData << ["xsd" : rawData.xsd]
        //
        marshallData << MiscUtil.getRelRawdatas(rawData, existData)
        marshallData << MiscUtil.getTagAndFile(existData, "marshallLevel")
        marshallData << MiscUtil.getMongoSyncFlag(existData)

        return marshallData
        
    }  // end generateRawData function
    
}
