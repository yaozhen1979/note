package org.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {
    
    private static Properties properties = PropertiesUtil.load("config.properties")
    
    /**
     * 
     * @param fileName 設定檔名稱
     * @return
     */
    private static Properties load(final String fileName) {

        Properties prop = new Properties();
        InputStream is = null;

        try {
            // TODO: hard code...
            is = PropertiesUtil.getMetaClass().getTheClass().getResourceAsStream("../../${fileName}")
            // load a properties file
            prop.load(is);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return prop;
    }
    
    public static String getXsdFile() {
        return properties.getProperty("xsd_file")
    }
    
    public static String getRawLevelCode() {
        return properties.getProperty("raw_level_code")
    }
    
    public static String getMarshallLevelCode() {
        return properties.getProperty("marshall_level_code")
    }
    
    public static String getInfoLevelCode() {
        return properties.getProperty("info_level_code")
    }
    
    public static String getVersionTag() {
        return properties.getProperty("version_tag")
    }
    
    public static void main(String[] args) {
        
        // Properties properties = PropertiesUtil.load("src/main/resources/config.properties");
        // System.out.println(properties.getProperty("user_mail"));
        
        // println PropertiesUtil.getMetaClass().getTheClass().getResourceAsStream("../../config.properties")
        
        println PropertiesUtil.getXsdFile()
        
    }
    
}
