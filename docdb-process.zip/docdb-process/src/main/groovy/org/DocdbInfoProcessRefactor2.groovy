package org

/**
 * fileType => 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
 */
import org.utils.MongoUtil
import org.utils.PatentInfoUtil
import org.utils.DateUtil
import org.utils.ErrInfoUtil
import org.utils.KindcodeUtil
import org.utils.CountryUtil
import org.utils.MailUtil

import org.bson.types.ObjectId

import static jodd.jerry.Jerry.jerry as $

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class DocdbInfoProcessRefactor2 {
    
    private static Logger logger = LoggerFactory.getLogger(this.class);
    
    /**
     *
     * @param query
     * @param lv1DB
     * @param lv2DB
     * @return
     */
    static processInfoData (query, lv1DB, lv2DB, tagAndJsfile, logger) throws Exception {
        
        def ln = System.getProperty('line.separator')
        
        // TODO: 每個國家皆都調整 ... log 輸出也要有所調整...
        File fileLog = new File("log_for_replicated_data/2015-11-27-update.log")
        // File fileLog = new File("log/20150312_AMEND_ERR.log")
        //
        def lv1Cursor = lv1DB.PatentRawDOCDB.find(query)
        lv1Cursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        def totalCount = lv1Cursor.count()
        
        // TODO:目前處理筆數
        def currentCount = 0
        
        lv1Cursor.skip(0).each { lv1 ->
            
            // println lv1
            
            // parse lv1 xml to lv2
            def output = lv1.data.xml
            def dom = $(output)
            def dataMap = PatentInfoUtil.parseData(dom)
            
            // find kindCodeMap by country && kindCodeg
            def kindcodeData = KindcodeUtil.getKindcodeData(lv1, dataMap, lv2DB)
            // logger.info "kindcodeData = ${kindcodeData}"
            
            if (kindcodeData.size() == 0) {
                
                // kindcode 找不到時, 要寫入 err collection
                def errData = lv2DB.ErrorPatentInfoDOCDB.findOne([
                    'doc.country': lv1.country,
                    'doc.lv1Id': lv1._id
                ])
                if (!errData) {
                    errData = ErrInfoUtil.writeKindcodeErrDoc(lv1)
                } else {
                    errData.doDate = new Date()
                }
                //
                // println "errData = ${errData}"
                logger.info "country = ${lv1.country}, kindcode = ${lv1.kindCode} not found..."
                //
                lv2DB.ErrorPatentInfoDOCDB.save(errData)
                // throw new Exception("country = ${lv1.country}, kindcode = ${lv1.kindCode} not found...")
                
            } else {
                //
                dataMap << kindcodeData
                
                // stat = 1 為[公開], stat = 2為[公告], stat = 3為[公開/公告]
                dataMap = PatentInfoUtil.getStat(dataMap)
                
                def lv2QueryMap = PatentInfoUtil.lv2Query(dataMap)
                
                // lv2 unique key => country, patentNumber, kindcode, stat
                def lv2Count = lv2DB.PatentInfoDOCDB.count(lv2QueryMap)
                
                def lv2 = lv2DB.PatentInfoDOCDB.findOne(lv2QueryMap)
                
                // docdbDoDate: 在LV2存入該欄位, 是方便即有PTO在做merge時的查詢條件.
                dataMap << [docdbDoDate: lv1.docdbDoDate]
                
                if (lv2Count == 0) {
                    
                    logger.info "create data..."
                    
                    //
                    // history array => history:[[rawDataId:5578130760b204d67fc0e647, docdbDoDate:Wed Jul 13 08:00:00 CST 1988, status:B]]
                    def status = PatentInfoUtil.getStatus(dom, lv1.fileType)
                    
                    /*
                     *  如果是LV1 Amend資料, 但卻查詢LV2資料時, 要如何處理 ??? 新增 or 報錯 ???
                     *        => 目前規畫為, 新增且寫入log...
                     */
                    if (status == 'A') {
                        fileLog << "docdbDoDate = ${lv1.docdbDoDate} ,lv1._id = ${lv1._id}, status = ${status}, create new data by Amend..." << ln
                    }
                    
                    def historyList = [] << ['rawDataId':lv1._id, 'docdbDoDate':lv1.docdbDoDate, 'status':status]
                    dataMap << [history: historyList]
                    
                    // relRawdatas array
                    def relRawdatasList = [] << ['_id': lv1._id]
                    dataMap << [relRawdatas: relRawdatasList]
                    
                    // tagAndJsfile array
                    def tagAndJsfileList = [] <<  ['file': tagAndJsfile.file, 'tag': tagAndJsfile.tag]
                    dataMap << [tagAndJsfile: tagAndJsfileList]
                    
                    // mongoSyncFlag init, basicInfo(???), last
                    def mongoSyncFlagMap = [:] << ['init': new Date(), 'basicInfo': new Date(), 'last': new Date()]
                    dataMap << [mongoSyncFlag: mongoSyncFlagMap]
                    
                    // println "dataMap = ${dataMap}"
                    
                    // bulk insert new document
                    lv2DB.PatentInfoDOCDB.insert(dataMap)
                    
                } else if (lv2Count == 1) {
                    
                    logger.info "update data..."
                    
                    // 重複更新同一筆LV1資料
                    if (lv1._id == lv2.history[-1].rawDataId) {
                        
                        logger.info "update replicated data..."
                        
                        dataMap << [history: lv2.history]
                        dataMap << [relRawdatas: lv2.relRawdatas]
                        
                    } else {
                    
                        logger.info "update new data..."
                    
                        // 更新新的一筆LV1資料
                        def status = PatentInfoUtil.getStatus(dom, lv1.fileType)
                        def updateHistory = ['rawDataId':lv1._id, 'docdbDoDate':lv1.docdbDoDate, 'status':status]
                        dataMap << [history: lv2.history << updateHistory]
                        
                        dataMap << [relRawdatas: lv2.relRawdatas << ['_id': lv1._id]]
                        
                    }
                    
                    // 特別判斷處理程式是否有所變更
                    if (lv2.tagAndJsfile[-1].file != tagAndJsfile.file || lv2.tagAndJsfile[-1].tag != tagAndJsfile.tag) {
                        dataMap << [tagAndJsfile: lv2.tagAndJsfile << ['file': tagAndJsfile.file, 'tag': tagAndJsfile.tag]]
                    } else {
                        dataMap << [tagAndJsfile: lv2.tagAndJsfile]
                    }
                    
                    def mongoSyncFlagMap = [:] << ['init': lv2.mongoSyncFlag.init, 'basicInfo': lv2.mongoSyncFlag.basicInfo, 'last': new Date()]
                    dataMap << [mongoSyncFlag: mongoSyncFlagMap]
                    
                    // println "dataMap = ${dataMap}"
                    
                    // bulk update
                    // 因為[status=D]時, 有可能會缺少大多少的欄位資料, 而導至資料出現被洗掉的情況出現, 所以一定要用$set來避免前述情況出現.
                    /*
                     * DBObject query,
                     * DBObject update,
                     * boolean upsert,
                     * boolean multi,
                     * WriteConcern aWriteConcern => countries.setWriteConcern(WriteConcern.JOURNALED);
                     */
                    // new BasicDBObject(["_id" : d._id]), new BasicDBObject('$set', new BasicDBObject(set))
                    // lv2DB.PatentInfoDOCDB.update(new BasicDBObject(["_id" : lv2._id]), new BasicDBObject('$set', new BasicDBObject(dataMap)))
                    def updatePatentInfoDOCDB = lv2DB.PatentInfoDOCDB
                    // updatePatentInfoDOCDB.setWriteConcern(new com.mongodb.WriteConcern.Majority());
                    updatePatentInfoDOCDB.update([_id: lv2._id], [$set: dataMap], false, false, com.mongodb.WriteConcern.ACKNOWLEDGED)
                    
                } else if (lv2Count > 1) {
                    //
                    throw new Exception("lv1._id = ${lv1._id}, lv2QueryMap = ${lv2QueryMap},  query more than one row data...")
                }
                
            }
            
            logger.info "process data => country = ${dataMap.country}, patentNumber = ${dataMap.patentNumber}, kindcode = ${dataMap.kindcode}, stat = ${dataMap.stat} | ${++currentCount} / ${totalCount} ..."
            
        }
        
    }  // end processInfoData function
    
    static main(args) {
        
        //
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        // TODO: for local test => TonyDB
        // def localClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "127.0.0.1", 27017, 'admin')
        
        def lv1DB = client.getDB("PatentRawDOCDB")
        
        /*
         *  TODO:
         *  Test: TestInfoDOCDB / TonyDB
         *  Prod: PatentInfoDOCDB
         */
        def lv2DB = client.getDB("PatentInfoDOCDB")
        
        // 資料處理記錄 = ['file': 'DocdbInfoProcess.groovy', 'tag': 'v1.0.0']
        def tagAndJsfile = ['file': 'DocdbInfoProcess.groovy', 'tag': 'v0.2.0']
        
        // TODO: query condition
        
        /*
         * TODO: ???
         * use TonyDB
         * 328 + 29 != 493
         * 173 size = 1
         * 316 size = 2
         * 4 size = 3
         * db.TEMP_DOCDB_20151127.find({history: {$size: 1}})
         * 
         * => 上面的資料經該都是要刪除索引, 且還有人工做的29筆資料待刪...
         * 
         */
        
        new File("log_for_replicated_data/raw_data_id_with_one_data.txt").eachLine { it -> 
            def query = [_id: new ObjectId(it.toString())]
            try {
                DocdbInfoProcessRefactor2.processInfoData(query, lv1DB, lv2DB, tagAndJsfile, logger)
            } catch(e) {
                MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", "query = ${query}, exception = " + e.toString())
                throw new Exception(e)
            }
        }
        
//        // parse raw data to info data by country
//        CountryUtil.getDocdbCountryList().each { cc ->
//            //
//            def query = [docdbDoDate: DateUtil.parseDate(""), fileType: 1, country: cc]
//            
//            try {
//                processInfoData(query, lv1DB, lv2DB, tagAndJsfile, logger)
//            } catch(e) {
//                MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", e.toString())
//                throw new Exception(e)
//            }
//            
//        }
        
        logger.info "finished..."
        
    }

}
