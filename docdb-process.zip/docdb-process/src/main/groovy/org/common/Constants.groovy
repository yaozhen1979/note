package org.common

class Constants {
    
    public final static String PTO = "DOCDB"
    
}
