package docdb.importer.marshalldata;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.w3c.dom.ls.LSInput;
import org.w3c.dom.ls.LSResourceResolver;

/**
 * ref: http://stackoverflow.com/questions/2342808/problem-validating-an-xml-file-using-java-with-an-xsd-having-an-include
 * 
 * @author tonykuo
 *
 */
public class DocdbEntityResolver implements LSResourceResolver  {
    
    @Override
    public LSInput resolveResource(String type, String namespaceURI,
            String publicId, String systemId, String baseURI) {
        
        // System.out.println("systemId = " + systemId);
        InputStream resourceAsStream = null;
        
        try {
            
            if (systemId.equals("xlink.xsd")) {
                resourceAsStream =  new FileInputStream(new File("xsd/xlink.xsd"));
            } else if (systemId.equals("xml.xsd")) {
                resourceAsStream = new FileInputStream(new File("xsd/xml.xsd"));
            } else if (systemId.equals("XMLSchema.dtd")) {
                resourceAsStream = new FileInputStream(new File("xsd/XMLSchema.dtd"));
            } else if (systemId.equals("datatypes.dtd")) {
                resourceAsStream = new FileInputStream(new File("xsd/datatypes.dtd"));
            } else {
                throw new Exception("systemId dont match = " + systemId);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return new Input(publicId, systemId, resourceAsStream);
    }
    
}
