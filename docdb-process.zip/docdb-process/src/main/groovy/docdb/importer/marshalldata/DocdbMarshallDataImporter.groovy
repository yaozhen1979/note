package docdb.importer.marshalldata

import groovy.json.JsonSlurper

import org.bson.types.ObjectId
import org.utils.CountryUtil
import org.utils.JaxbUtil
import org.utils.MailUtil
import org.utils.MarshallDataUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.MiscUtil
import org.utils.DateUtil

/**
 * 
 * @author tonykuo
 *
 */
class DocdbMarshallDataImporter {
    
    /**
     * xml valid和marshall importer依序執行, 但目前因傾向先執行驗證程式, 再執行marshall import.
     * 
     * @param dbClient
     * @param queryMap
     * @param country
     */
    static void process(def dbClient, def queryMap, def country) {
        
        def cc = country
        
        def db = dbClient.getDB("DocdbRawData")
        def patentRawDOCDB = db.getCollection("DocdbRawData${cc}")
        // def db = dbClient.getDB("PatentRawDOCDB")
        // def patentRawDOCDB = db.getCollection("PatentRawDOCDB")
        
        def queryCursor = patentRawDOCDB.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        def count = queryCursor.size()
        if (count == 0) {
            println "cc = ${cc}, queryMap = ${queryMap}, find count = 0"
            return
        }
        
        def marshallDB = dbClient.getDB("PatentMarshallDOCDB")
        def marshallCollection = marshallDB.getCollection("PatentMarshall${cc}")
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "${this.class.getSimpleName()} - ${cc}")
        
        def rawDataid = null;
        
        try {
            
            queryCursor.each { rawData ->
                
                // marshallFlag 可應需求隨時改變 => !rawData.marshallFlag
                // if (!rawData.marshallFlag) {
                if (true) {
                    
                    rawDataid = rawData._id
                    def xml = MiscUtil.removeResidenceCountry(rawData.data.xml)
                    
                    // TODO: 可依情況, 變更驗證條件
                    // if (JaxbUtil.isValidate(xml)) {
                    if (true) {
                        
                        def jsonStr = JaxbUtil.xml2Json(xml)
                        def jsonObject = new JsonSlurper().parseText(jsonStr)
                        
                        def queryMarshallData = marshallCollection.find([_id: rawData.path])
                        queryMarshallData.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
                        def marshallCount = queryMarshallData.count()
                        if (marshallCount > 1) {
                            throw new Exception("country = ${rawData.country}, rawDataId = ${rawData._id} query over 1 data...")
                        } else {
                            // println "insert or update data..."
                            def marshallData = MarshallDataUtil.generateMarshallData(jsonObject, rawData, queryMarshallData[0])
                            marshallCollection.save(marshallData, com.mongodb.WriteConcern.ACKNOWLEDGED)
                        }
                        
                        // marshall flag => set PatentRawDOCDB
                        patentRawDOCDB.update([_id: rawData._id], [$set: [marshallFlag: true]])
                        
                    }
                    
                }
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            println "Exception: rawDataid = ${rawDataid}, ${e}"
            MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Data Exception Error", "rawDataid = ${rawDataid} = ${e}")
            throw new Exception("Exception: rawDataid = ${rawDataid}, ${e}")
        }
        
    }
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        // [_id: new ObjectId("5670abd68df6cc5919660861")]
        
        println "to start..."
        
        try {
            
            CountryUtil.getDocdbCountryList().each { cc ->
                
                // def queryMap = [country: cc];
                // def queryMap = [country: "WO", _id : new ObjectId("5628d82df3b4976d401563b9")]
                // def queryMap = [country: "WO", _id : "DOCDB-201540-Amend-PubDate20150925AndBefore-WO-0001.xml/304643087"]
                // def queryMap = [country: "DE", _id : "DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513608"]
                def queryMap = [fileType: 2, docdbDoDate: DateUtil.parseDate("2016-02-25")]
                // def queryMap = [fileType: 2, docdbDoDate: DateUtil.parseDate("2015-12-10")]
                process(dbClient, queryMap, cc);
                
                // MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Marshall Data => ${cc} complete", "${cc} marshall completed...")
                
            }
            
//            def queryMap = [country: "DE", _id : "DOCDB-201550-CreateDelete-PubDate20151210-DE-0001.xml/446513349"]
//            process(dbClient, queryMap, "DE");
            
        } catch(e) {
            println e
        } finally {
            dbClient.close()
        }
        
        println "finished..."
    }

}
