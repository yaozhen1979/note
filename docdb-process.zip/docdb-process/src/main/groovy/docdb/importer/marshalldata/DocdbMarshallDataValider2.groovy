package docdb.importer.marshalldata

import org.utils.JaxbUtil
import org.utils.MailUtil
import org.utils.MiscUtil
import org.utils.MongoUtil
import org.utils.CountryUtil
import org.utils.RestTimeProcess
import org.utils.DateUtil

/**
 * process 傳入參數為[dbClient][queryMap][cc]
 * 
 * @author tonykuo
 *
 */
class DocdbMarshallDataValider2 {
    
    /**
     * 
     * @param dbClient
     * @param queryMap
     * @param cc
     */
    static void process(def dbClient, def queryMap, def cc) {
        
        File fileLog = new File("logs/valid_xml/${cc}_valid.log")
        def ln = System.getProperty('line.separator')
        
        def db = dbClient.getDB("DocdbRawData")
        def docdbRawData = db.getCollection("DocdbRawData${cc}")
        
        def queryCursor
        if (queryMap.size() > 0) {
            queryCursor = docdbRawData.find(queryMap)
        } else {
            queryCursor = docdbRawData.find()
        }
        
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        def count = queryCursor.count()
        if (count == 0) {
            println "queryMap = ${queryMap}, find count = 0"
            return
        }
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "${DocdbMarshallDataValider2} - ${cc}")
        
        def rawDataId = null;
        
        try {
            
            queryCursor.each { rawData ->
                
                // marshallFlag 可應需求隨時改變 => !rawData.marshallFlag
                // if (!rawData.marshallFlag) {
                // if (!rawData.validFlag) {
                if (true) {
                    rawDataId = rawData._id
                    def xml = MiscUtil.removeResidenceCountry(rawData.data.xml)
                    
                    try {
                        JaxbUtil.isValidate(xml)
                    } catch(e) {
                        fileLog << "rawData id = ${rawData._id}, " + e << ln
                    }
                    
                    // valid flag
                    // patentRawDOCDB.update([_id: rawData._id], [$set: [validFlag: true]])
                }
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            println "Exception: DocdbRaw${cc}._id = ${rawDataId}, ${e}"
            // MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Data Exception Error", "rawDataId = ${rawDataId} = ${e}")
            throw new Exception("Exception: DocdbRaw${cc}._id = ${rawDataId}, ${e}")
        }
        
    }
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        try {
            
            // def queryMap = [country: "LV", _id: new ObjectId("557bec8160b2dce14006b90e")]
//            def cc = "CH"
//            def queryMap = []
//            process(dbClient, queryMap, cc);
            
            CountryUtil.getDocdbCountryList().each { cc ->
                
                // def queryMap = [country: cc]
                def queryMap = [docdbDoDate: DateUtil.parseDate("2016-03-03")]
                process(dbClient, queryMap, cc);
                
                // MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Valid Docdb Marshall Data => ${cc} complete", "${cc} marshall completed...")
                
            }
            
        } catch(e) {
            println e
        } finally {
            dbClient.close()
        }
        
        println "finished..."
    }

}
