package docdb.importer.marshalldata

import groovy.json.JsonSlurper

import org.bson.types.ObjectId
import org.utils.CountryUtil
import org.utils.JaxbUtil
import org.utils.MailUtil
import org.utils.MarshallDataUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.MiscUtil

/**
 * process 傳入參數為[dbClient][queryMap]
 * 
 * @author tonykuo
 *
 */
class DocdbMarshallDataValider {
    
    /**
     * 
     * @param dbClient
     * @param queryMap 其中一定要帶country的查詢條件
     */
    static void process(def dbClient, def queryMap) {
        
        File fileLog = new File("logs/valid_xml/${queryMap.country}_valid.log")
        def ln = System.getProperty('line.separator')
        
        def db = dbClient.getDB("PatentRawDOCDB")
        def patentRawDOCDB = db.getCollection("PatentRawDOCDB")
        def queryCursor = patentRawDOCDB.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        def count = queryCursor.count()
        if (count == 0) {
            println "queryMap = ${queryMap}, find count = 0"
            return
        }
        
        def cc = queryMap.country
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "${this.class.getSimpleName()} - ${queryMap.country}")
        
        def rawDataid = null;
        
        try {
            
            queryCursor.each { rawData ->
                
                // marshallFlag 可應需求隨時改變 => !rawData.marshallFlag
                // if (!rawData.validFlag) {
                if (true) {
                    rawDataid = rawData._id
                    def xml = MiscUtil.removeResidenceCountry(rawData.data.xml)
                    
                    try {
                        JaxbUtil.isValidate(xml)
                    } catch(e) {
                        fileLog << "rawData id = ${rawData._id}, path = ${rawData.path}" + e << ln
                    }
                    
                    // valid flag
                    // patentRawDOCDB.update([_id: rawData._id], [$set: [validFlag: true]])
                }
                
                restTimeProcess.process()
            }
            
        } catch (e) {
            println "Exception: rawDataid = ${rawDataid}, ${e}"
            MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Data Exception Error", "rawDataid = ${rawDataid} = ${e}")
            throw new Exception("Exception: rawDataid = ${rawDataid}, ${e}")
        }
        
    }
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        try {
            
            // def queryMap = [country: "LV", _id: new ObjectId("557bec8160b2dce14006b90e")]
            def queryMap = [country: "CH"]
            process(dbClient, queryMap);
            
//            CountryUtil.getMarshallCountryList().each { cc ->
//                
//                def queryMap = [country: cc]
//                process(dbClient, queryMap);
//                
//                MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Valid Docdb Marshall Data => ${cc} complete", "${cc} marshall completed...")
//                
//            }
            
        } catch(e) {
            println e
        } finally {
            dbClient.close()
        }
        
        println "finished..."
    }
    
}
