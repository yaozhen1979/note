package docdb.importer.rawdata;


import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

// import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.utils.DateUtil;
import org.utils.PropertyUtil;
import org.utils.RestTimeProcess;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * 
 * @deprecated
 * @author tonykuo
 *
 */
public class DocdbRawDataImporter2 {
    
static Logger logger = LoggerFactory.getLogger(DocdbRawDataImporter2.class);
    
    private static final Date v244EndDate = DateUtil.parseDate("2015-05-08");
    private static final Date v253EndDate = DateUtil.parseDate("2015-10-08");
    
    // private static final String XSD_VERSION = "v2.4.4"
    private static final String DOCDB_PTO = "DOCDB";
    private static final String DATA_XPATH = "exch:exchange-documents/exch:exchange-document";

    private static final String SYSTEM_ID = "docdb-entities.dtd";
    private static final String DATE_OF_EXCHANGE = "date-of-exchange";
    private static final String DOC_ID = "doc-id";
    //
    // private static final String CONFIG_PATH = "config.path";

    private static Element root;

    /**
     * entry point
     *
     * @param args
     * @throws Exception
     */
    public void parseXml(String[] args) throws Exception {

        Properties properties = PropertyUtil.load("src/main/resources/config.properties");

        String dbIp = properties.getProperty("host");
        String ac = properties.getProperty("ac");
        String pd = properties.getProperty("pd");
        logger.debug(ac +", " + pd);

        File dataDir = new File(properties.getProperty("xmlDir"));

        boolean removeFlag = true;

        MongoClient mongoClient = mongoConnect(dbIp, ac, pd);
        
        // SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");

        Date today = new Date();

        // String parseLogPath = properties.getProperty("logDir") + File.separator + sf2.format(today) + "_parse.log";
        String errorLogPath = properties.getProperty("logDir") + File.separator + sf2.format(today) + "_error.log";
        String unzipListPath = properties.getProperty("unzipFileListDir") + File.separator + "unzip_list.log";

        int totalCnt = 0;

        if (dataDir.exists()) {

            File[] fileList = dataDir.listFiles();

            if (fileList != null && fileList.length > 0) {

                for (File file : fileList) {
                    
                    logger.debug("start parse file: " + file.getAbsolutePath());
                    
                    if(FilenameUtils.isExtension(file.getName(), "xml")) {

                        File unzipListFile = new File(unzipListPath);

                        if (!unzipListFile.exists()) {
                            logger.info(unzipListPath + " does not exists, build it");
                            writeLog(unzipListPath, "");
                        }

                        // find parsed xml file
                        boolean isParsed = false;
                        for (String unzipFile : FileUtils.readLines(unzipListFile)) {
                            if(StringUtils.equals(unzipFile, file.getName())) {
                                logger.debug("file " + file.getName() + " has already unzip!");
                                isParsed = true;
                            }
                        }

                        if (isParsed) {
                            continue;
                        }
                        
                        System.out.println("file name = " + file.getName());
                        String cc =  file.getName().split("-")[4];
                        if (cc.length() != 2) {
                            throw new Exception(cc + " = country code error");
                        }
                        System.out.println("country = " + cc);
                        
                        DBCollection collection = mongoClient.getDB("DocdbRawData").getCollection("DocdbRawData" + cc);
                        DBCollection errCollection = mongoClient.getDB("DocdbRawData").getCollection("ErrorDocdbRawData");
                
                        // BulkWriteOperation
                        BulkWriteOperation builder = collection.initializeOrderedBulkOperation();
                        
                        try {
                            
                            Document doc = loadXMLFile(file);

                            // After execution, you cannot re-execute the Bulk() object without reinitializing
                            builder = collection.initializeOrderedBulkOperation();

                            // DocDbDoDate parse
                            Date docdbDoDate = getDocDbDodate();

                            @SuppressWarnings("unchecked")
                            List<Element> nodes = doc.selectNodes(DATA_XPATH);

                            totalCnt = nodes.size();
                            
                            RestTimeProcess restTimeProcess = new RestTimeProcess(totalCnt, "${this.class.getSimpleName()} - ${file.name}");

                            if (nodes != null && nodes.size() > 0) {

                                for (int i = 0; i < nodes.size(); i++) {

                                    Element ele = nodes.get(i);

                                    // when doc-id is null, write into error collection
                                    if (ele.attributeValue(DOC_ID) == null) {

                                        String errMsg = file.getName() + "'s " + (i + 1) + " data does not have doc-id, skip it and write into ErrorPatentRawDOCDB";

                                        logger.error("error: " + errMsg);
                                        writeLog(errorLogPath, file.getName()
                                                + " : " + errMsg + System.getProperty("line.separator"));

                                        // process replicated error data
                                        Map<String, Object> errorMap = getErrorMap(ele, file.getName(), docdbDoDate);
                                        @SuppressWarnings("unchecked")
                                        Map<String, Object> errorDocMap = (Map<String, Object>) errorMap.get("doc");
                                        DBObject removeData = errCollection.findOne(new BasicDBObject("doc", errorDocMap));
                                        if (removeData != null) {
                                            errCollection.save(removeData);
                                        } else {
                                            errCollection.insert(new BasicDBObject(errorMap));
                                        }

                                        continue;

                                    }  // end if (ele.attributeValue(DOC_ID) == null)

                                    // TODO: path = file name + / + docId = LV1 PK
                                    String path = file.getName() + "/" + ele.attributeValue(DOC_ID);

                                    // remove origin data, avoid to replicate
                                    if (removeFlag) {
                                        collection.remove(new BasicDBObject("path", path));
                                    }

                                    builder.insert(new BasicDBObject(getDataMap(ele, file.getName(), path, docdbDoDate)));

                                    restTimeProcess.process();

                                }  // end: for loop

                            }  // end: nodes != null && nodes.size() > 0

                            logger.debug("bulk processing, please wait ...");
                            builder.execute();
                            logger.debug("bulk processing, ok ...");

                            // when all data insert to DB, then write record to unzip_list.log
                            writeLog(unzipListFile.getAbsolutePath(), file.getName() + System.getProperty("line.separator"));

                        } catch (DocumentException dex) {
                            logger.error("error: " + dex);
                            writeLog(errorLogPath, file.getName() + " : " + dex.getMessage() + System.getProperty("line.separator"));
                        } catch (Exception ex) {
                            logger.error("error: " + ex);
                            writeLog(errorLogPath, file.getName() + " : " + ex.getMessage() + System.getProperty("line.separator"));
                        } finally {
                            // FileUtils.deleteQuietly(file);
                        }

                    } else {
                        String errorMsg = file.getName() +" is not xml file!";
                        logger.error(errorMsg);
                        writeLog(errorLogPath, errorMsg + System.getProperty("line.separator"));
                        continue;
                    }

                }

            } else {
                logger.debug(dataDir.getAbsolutePath() + " is empty");
            }

        } else {

            logger.debug(dataDir.getAbsolutePath() + " folder not exists~!");
        }
        
        mongoClient.close();
        
        logger.debug("parse xml finish ~!");

    }  // end parseXml function
    
    /**
     *
     * @param dbIp
     * @param ac
     * @param pd
     * @return
     * @throws UnknownHostException
     */
    private MongoClient mongoConnect(String dbIp, String ac, String pd)
            throws UnknownHostException {
        MongoCredential credential = MongoCredential.createCredential(ac, "admin", pd.toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress(dbIp, 27017), Arrays.asList(credential));
        return mongoClient;
    }
            
    /**
     * File Type
     *
     * 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
     *
     * @param fileName
     * @return
     */
    public int getFileType(String fileName){
        
        int fileType = 0;
        
        if (fileName.contains("CreateDelete")) {
            fileType = 1;
        }
        if (fileName.contains("Amend")) {
            fileType = 2;
        }
        if (fileName.contains("REPLACEMENT")) {
            fileType = 3;
        }
        return fileType;
    }
    
    /**
     * get docDodate from root
     *
     * @return
     */
    public Date getDocDbDodate() {
        String docdbDodate = "";
        
        if (root.attribute(DATE_OF_EXCHANGE) == null) {
            docdbDodate = "00000000";
        } else {
            docdbDodate = root.attribute(DATE_OF_EXCHANGE).getText();
        }
        
        // IF DATE_OF_EXCHANGE = 00000000 return 19700101
        if (docdbDodate.equals("00000000")){
            return DateUtil.parseDate("19700101");
        } else {
            return DateUtil.parseDate(docdbDodate);
        }

    }
    
    /**
     *
     * @param logFilePath
     * @param msg
     * @throws IOException
     */
    public void writeLog(String logFilePath, String msg) throws IOException {
        File logFile = new File(logFilePath);
        FileUtils.writeStringToFile(logFile, msg , logFile.exists());
    }
    
    /**
     *
     * @throws DocumentException
     *
     */
    public static Document loadXMLFile(File xmlFile) throws DocumentException {
        
        Document doc = null;
        SAXReader saxReader = new SAXReader();
        
        /*
         * ref: http://www.saxproject.org/apidoc/org/xml/sax/EntityResolver.html
         */
        saxReader.setEntityResolver(new EntityResolver() {
            @Override
            public InputSource resolveEntity(String publicId, String systemId)
                    throws SAXException, IOException {
                if (systemId.contains(SYSTEM_ID)) {
                    return new InputSource(new StringReader(""));
                } else {
                    return null;
                }
            }
        });
        
        doc = saxReader.read(xmlFile);
        root = doc.getRootElement();
        return doc;
    }
    
    /**
     *
     * @param ele
     * @param fileName
     * @param path
     * @param docdbDoDate
     * @return
     */
    private Map<String, Object> getDataMap(Element ele, String fileName, String path, Date docdbDoDate) {
        
        Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
        
        dataMap.put("_id", path);
        
        dataMap.put("pto", DOCDB_PTO);
        // dataMap.put("path", path);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        dataMap.put("data", data);
        
        dataMap.put("type", "xml/xml");
        dataMap.put("provider", "EPO Purchase");
        dataMap.put("docdbDoDate", docdbDoDate);
        
        // hard code: truncate : false,
        dataMap.put("truncate", false);
        dataMap.put("country", ele.attributeValue("country"));
        dataMap.put("fileType", getFileType(fileName));
        
        BasicDBObject mongoSyncData = new BasicDBObject();
        mongoSyncData.put("init", new Date());
        mongoSyncData.put("last", new Date());
        dataMap.put("mongoSyncFlag", mongoSyncData);
        
        // add kindCode
        dataMap.put("kindcode", ele.attributeValue("kind"));
        
        // TODO: refactor
        BasicDBObject tag = new BasicDBObject();
        tag.put("file", "DocdbRawDataImport.groovy");
        tag.put("version", "v1.0.0");
        dataMap.put("tag", tag);
        
        // TODO: 查看docdbDoDate = 2015-05-07 的xsd是否為v2.4.4 ???
        // Cr-Del\Amend 201501 ~ 201519 v2.4.4 => ~ 20150508
        if (docdbDoDate.compareTo(v244EndDate) <= 0) {
            dataMap.put("xsd", "v2.4.4");
        } else if (docdbDoDate.compareTo(v244EndDate) > 0 && docdbDoDate.compareTo(v253EndDate) <= 0) {
            // Cr-Del\Amend 201520 ~ 201541 v2.5.3 => 20150508 ~ 20151008
            dataMap.put("xsd", "v2.5.3");
        } else {
            // Cr-Del\Amend 201542 ~ 201551 v2.5.4 => 20151009 ~
            dataMap.put("xsd", "v2.5.4");
        }
        
        return dataMap;
    }
    
    /**
     * TODO: 待測
     * 
     * @param ele
     * @param fileName
     * @return
     */
    private Map<String, Object> getErrorMap(Element ele, String fileName, Date docdbDoDate) {
        
        Map<String, Object> errorMap = new LinkedHashMap<String, Object>();
        
        String cc = ele.attributeValue("country");
        
        String docNumber = "";
        if (ele.attributeValue("doc-number") != null) {
            docNumber = ele.attributeValue("doc-number");
        }
        
        String kindcode = "";
        if (ele.attributeValue("kind") != null) {
            kindcode = ele.attributeValue("kind");
        }
        
        String path = fileName + "/" + cc + docNumber + kindcode;
        
        errorMap.put("_id", path);
        
        errorMap.put("doDate", new Date());
        errorMap.put("errHandle", false);
        //
        BasicDBObject errDoc = new BasicDBObject();
        errDoc.put("country", ele.attributeValue("country"));
        errDoc.put("path", path);
        errDoc.put("docNumber", ele.attributeValue("doc-number"));
        errDoc.put("kindcode", ele.attributeValue("kind"));
        errorMap.put("doc", errDoc);
        //
        errorMap.put("country", cc);
        errorMap.put("docdbDoDate", docdbDoDate);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        errorMap.put("data", data);
        
        errorMap.put("fileType", getFileType(fileName));
        
        // TODO: refactor
        BasicDBObject tag = new BasicDBObject();
        tag.put("file", "DocdbRawDataImport.groovy");
        tag.put("version", "v1.0.0");
        errorMap.put("tag", tag);
        
        // TODO: refactor ???
        if (docdbDoDate.compareTo(v244EndDate) <= 0) {
            errorMap.put("xsd", "v2.4.4");
        } else if (docdbDoDate.compareTo(v244EndDate) > 0 && docdbDoDate.compareTo(v253EndDate) <= 0) {
            // Cr-Del\Amend 201520 ~ 201541 v2.5.3 => 20150508 ~ 20151008
            errorMap.put("xsd", "v2.5.3");
        } else {
            // Cr-Del\Amend 201542 ~ 201551 v2.5.4 => 20151009 ~
            errorMap.put("xsd", "v2.5.4");
        }
        
        BasicDBObject mongoSyncData = new BasicDBObject();
        mongoSyncData.put("init", new Date());
        mongoSyncData.put("last", new Date());
        errorMap.put("mongoSyncFlag", mongoSyncData);
        
        return errorMap;
    }
    
    public static void main(String[] args) throws Exception {
        DocdbRawDataImporter2 rdPaser = new DocdbRawDataImporter2();
        rdPaser.parseXml(args);
    }

}
