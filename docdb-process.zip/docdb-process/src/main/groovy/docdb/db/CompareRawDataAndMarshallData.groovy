package docdb.db

import org.utils.CountryUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.DateUtil
import org.utils.MailUtil

/**
 *  to start...
    country = CA, diff = -72
    country = EP, diff = 1
    country = HU, diff = 1
    country = KR, diff = 1
    country = TW, diff = 1
    finished...
 * 
 * @author tonykuo
 *
 */
class CompareRawDataAndMarshallData {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        def rawDB = dbClient.getDB("DocdbRawData")
        def marshallDB = dbClient.getDB("PatentMarshallDOCDB")
        
        CountryUtil.getDocdbCountryList().each { cc -> 
            
            def rawCount = rawDB.getCollection("DocdbRawData${cc}").count()
            def marshallCount = marshallDB.getCollection("PatentMarshall${cc}").count()
            
            def diff = rawCount - marshallCount
            
            if (diff != 0) {
                println "country = ${cc}, diff = ${diff}"
            }
            
        }
        
        println "finished..."
        
    }

}
