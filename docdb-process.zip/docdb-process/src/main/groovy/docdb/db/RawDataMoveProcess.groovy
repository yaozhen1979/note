package docdb.db

import org.utils.CountryUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.DateUtil
import org.utils.MailUtil

/**
 * 將PatentRawDOCDB中的資料, move to DocdbRawData
 * 
 * @author tonykuo
 *
 */
class RawDataMoveProcess {
    
    static Date v244EndDate = DateUtil.parseDate("2015-05-07")
    static Date v253EndDate = DateUtil.parseDate("2015-10-08")
    
    static process(def dbClient, def queryMap) {
        
        def cc = queryMap.country
        
        def db = dbClient.getDB("PatentRawDOCDB")
        def srcCol = db.PatentRawDOCDB
        
        def remoteDB = dbClient.getDB("DocdbRawData")
        def tarCol = remoteDB.getCollection("DocdbRawData${cc}")
        
        def errCol = remoteDB.getCollection("ErrorDocdbRawData")
        
        def queryCursor = srcCol.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), "RawDataMoveProcess - ${cc}")
        
        queryCursor.each { it ->
            
            def existData = tarCol.find(_id: it.path)
            
            if (!!existData) {
                return false
            }
            
            def path = it.path
            it._id = path
            
            it.kindcode = it.kindCode
            it.tag = [file: "DocdbRawDataImport.groovy", version: "v1.0.0"]
            it.mongoSyncFlag.last = new Date()
            
            it.remove("path")
            it.remove("validFlag")
            it.remove("regularFlag")
            it.remove("kindCode")
            
            if (it.fileType == 0) {
                it.xsd = "v2.4.4"
            } else {
            
                // Cr-Del\Amend 201501 ~ 201519 v2.4.4 => ~ 20150507
                if (it.docdbDoDate.compareTo(v244EndDate) <= 0) {
                    it.xsd = "v2.4.4"
                } else if (it.docdbDoDate.compareTo(v244EndDate) > 0 && it.docdbDoDate.compareTo(v253EndDate) <= 0) {
                    // Cr-Del\Amend 201520 ~ 201541 v2.5.3 => 20150508 ~ 20151008
                    it.xsd = "v2.5.3"
                } else {
                    // Cr-Del\Amend 201542 ~ 201551 v2.5.4 => 20151009 ~
                    it.xsd = "v2.5.4"
                }
                 
            }
            
            if (path.contains("null")) {
                errCol.save(it)
            } else {
                tarCol.save(it)
            }
            
            restTimeProcess.process()
        }
        
    }
    
    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        try {
            
            CountryUtil.getTransferCountryList().each { cc ->
                
                def queryMap = [country: cc]
                process(dbClient, queryMap);
                
                // MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Transfer Docdb Raw Data => ${cc} complete", "${cc} transfer completed...")
                
            }
            
        } catch(e) {
            println e
        } finally {
            dbClient.close()
        }
        
        println "finished..."
        
    }
    
}
