package docdb.db


import org.utils.CountryUtil
import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.DateUtil
import org.utils.MailUtil
import docdb.importer.marshalldata.DocdbMarshallDataImporter;

class RecoveryMarshallData {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        println "to start..."
        
        def rawDB = dbClient.getDB("DocdbRawData")
        def marshallDB = dbClient.getDB("PatentMarshallDOCDB")
        
        def cc = "DE"
        
        def queryRawData = rawDB.getCollection("DocdbRawData${cc}").find().limit(0)
        queryRawData.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        def count = queryRawData.size()
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(count, "${this.class.getSimpleName()} - ${cc}")
        
        queryRawData.each { it -> 
            
            def queryMap = [_id: it._id]
            def marshallData = marshallDB.getCollection("PatentMarshall${cc}").findOne(queryMap)
            
            if (!marshallData) {
                // println "process marshall data"
                DocdbMarshallDataImporter.process(dbClient, queryMap, cc)
            }
            
            restTimeProcess.process()
        }
        
        
    }

}
