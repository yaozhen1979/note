package docdb.db

import org.utils.CountryUtil;
import org.utils.MongoUtil;

class QueryRawDataAndMarshallData {

    static main(args) {

        def ln = System.getProperty('line.separator')
        def dbClient = MongoUtil.connect3X('datateamdocdb', 'whsfciaewms', "10.60.90.101", 27017, 'admin')
        
        def totalCount = 0;
        
        println "to start..."

        // def rawDB = dbClient.getDB("DocdbRawData")
        def marshallDB = dbClient.getDB("PatentMarshallDOCDB")
        
        // CountryUtil.getDocdbCountryList().each { cc ->
        CountryUtil.getSomeCountryList().each { cc ->
            
            // def rawCount = rawDB.getCollection("DocdbRawData${cc}").count()
            def marshallCount = marshallDB.getCollection("PatentMarshall${cc}").count()
            println "country = ${cc}, marshallCount = ${marshallCount}"
            totalCount = totalCount + marshallCount
            
        }
        
        println "total count = ${totalCount}"
        println "finished..."
    }
}
