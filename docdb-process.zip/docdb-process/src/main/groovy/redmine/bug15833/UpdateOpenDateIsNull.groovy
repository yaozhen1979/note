package redmine.bug15833

import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.bson.types.ObjectId

class UpdateOpenDateIsNull {
    
    static void process (String cc = null) {
        
        def ln = System.getProperty('line.separator')
        File fileLog = new File("logs/UpdateOpenDateisNull/20151217.log")
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
        def db = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = db.getCollection("PatentInfoDOCDB")
        
        def tonyDB = client.getDB("TonyDB")
        def backPatentInfoDOCDB = tonyDB.getCollection("PatentInfoDOCDB")
        
        // TODO: query condition
        // def queryMap = [country: cc]
        def queryMap = [_id: new ObjectId("567008378df6f7a7f8f89a51")]
        def queryCursor = patentInfoDOCDB.find(queryMap)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), this.class.name)
        
        queryCursor.each { it ->
            
            if (it.openDate == null && it.history.size() == 1) {
                //
                def historyData = it.history[0]
                def relRawdata = it.relRawdatas[0]
                
                def country = it.country
                def patentNumber = it.patentNumber
                def kindcode = it.kindcode
                
                def queryMap2 = [country: country, patentNumber: patentNumber, kindcode: kindcode]
                def queryCursor2 = patentInfoDOCDB.find(queryMap2)
                queryCursor2.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
                
                // println "queryCursor2 count = ${queryCursor2.count()}"
                
                queryCursor2.each { it2 ->
                    
                    if (!!it2.openDate && it2.history[-1].rawDataId != it.history[-1].rawDataId) {
                        
                        def updateHistory = it2.history << historyData
                        def updateRelRawdatas = it2.relRawdatas << relRawdata
                        // println "updateHistory = ${updateHistory}"
                        // println "relRawdatas = ${updateRelRawdatas}"
                        
                        // update db
                        db.PatentInfoDOCDB.update([_id: it2._id], [$set : [history: updateHistory, relRawdatas: updateRelRawdatas]])
                    }
                    
                }
                
                // TODO: delete status = D data and backup to tonyDB
                fileLog << "queryMap = ${queryMap2}, remove id = ${it._id}" << ln
                backPatentInfoDOCDB.save(it)
                db.PatentInfoDOCDB.remove([_id: it._id])
                
            }  // end it.openDate == null && it.history.size() == 1
            
            restTimeProcess.process()
        }
        
    }
    
    static main(args) {
        
        def countryList = [
            "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
            "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ",
            "DD", "DE", "DZ", "DK", "DO",
            "EA", "EC", "EE", "EG", "ES", "EP",
            "FI", "FR",
            "GB", "GC", "GE", "GR", "GT",
            "HK", "HN", "HR", "HU",
            "ID", "IE", "IL", "IN", "IS", "IT",
            "JO", "JP",
            "KE", "KG", "KR", "KZ",
            "LT", "LU", "LV",
            "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
            "NI", "NL", "NO", "NZ",
            "OA",
            "PA", "PE", "PH", "PL", "PT",
            "RO", "RS", "RU",
            "SE", "SG", "SI", "SK", "SM", "SU", "SV",
            "TH", "TJ", "TN", "TR", "TT", "TW",
            "UA", 
            // "US", 
            "UY", "UZ",
            "VN",
            "WO",
            "YU",
            "ZA", "ZM", "ZW"
        ]
        
        def testList = ["AM"]
        
//        testList.each { cc -> 
//            process(cc)
//        }
        
        process()
        
        println "finished..."
    }

}
