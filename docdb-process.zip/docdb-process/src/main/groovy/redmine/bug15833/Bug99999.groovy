package redmine.bug15833

import org.utils.MongoUtil
import org.utils.RestTimeProcess
import org.utils.MailUtil
import org.bson.types.ObjectId

import org.DocdbInfoProcessRefactor3

class Bug99999 {

    static main(args) {
        
        def ln = System.getProperty('line.separator')
        def tagAndJsfile = ['file': 'DocdbInfoProcessRefactor3.groovy', 'tag': 'v0.3.0']
        def fileLogPath = "logs/Bug99999/20151222.log"
        
        def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

        def lv1DB = client.getDB("PatentRawDOCDB")
        
        def lv2DB = client.getDB("PatentInfoDOCDB")
        def patentInfoDOCDB = lv2DB.getCollection("PatentInfoDOCDB")
        
        def tonyDB = client.getDB("TonyDB")
        def backPatentInfoDOCDB = tonyDB.getCollection("PatentInfoDOCDB")
        
        // bug99999
        def queryCursor = backPatentInfoDOCDB.find([bug99999 : [$exists : false]]).limit(0)
        queryCursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT)
        
        RestTimeProcess restTimeProcess = new RestTimeProcess(queryCursor.count(), "Bug99999")
        
        queryCursor.each { it -> 
            
            def updateRawDataId= it.history[-1].rawDataId
            Date docdbDoDate = it.history[-1].docdbDoDate
            
            def country = it.country
            def patentNumber = it.patentNumber
            def kindcode = it.kindcode
            def doDate = it.doDate
            //
            def queryMap = [country: country, patentNumber: patentNumber, kindcode:kindcode, doDate:doDate]
            // println "docdbDoDate = ${docdbDoDate}"
            // println "queryMap = ${queryMap}"
            
            def query101Cursor = patentInfoDOCDB.find(queryMap)
            
            if (query101Cursor.count() == 0) {
                
                // throw new Exception("queryMap = ${queryMap} query 0 data...")
                def query = [_id: updateRawDataId]
                
                try {
                    
                    DocdbInfoProcessRefactor3.processInfoData(query, lv1DB, lv2DB, tagAndJsfile, fileLogPath)
                    
                    // update flag
                    backPatentInfoDOCDB.update([_id: it._id], [$set: [bug99999 : true]])
                    
                } catch(e) {
                    MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", e.toString())
                    throw new Exception(e)
                }
                
            } else if (query101Cursor.count() > 1) {
            
                // throw new Exception("queryMap = ${queryMap} query 1 data...")
                //
                def deleteList = []
                def historyList = []
                query101Cursor.each { it3 ->
                    
                    deleteList << it3._id
                    it3.history.each { history ->
                        historyList << history
                    }
                    
                    backPatentInfoDOCDB.save(it3)
                    patentInfoDOCDB.remove([_id: it3._id])
                }
            
                it.history.each { history -> 
                    historyList << history
                }
                // println "historyList = ${historyList}"
                
                historyList.sort {a, b -> a.docdbDoDate.compareTo(b.docdbDoDate)}.each { it3 -> 
                    
                    def query = [_id: it3.rawDataId]
                    // println "query = ${query}"
                    try {
                        DocdbInfoProcessRefactor3.processInfoData(query, lv1DB, lv2DB, tagAndJsfile, fileLogPath)
                        // update flag
                        backPatentInfoDOCDB.update([_id: it._id], [$set: [bug99999 : true]])
                    } catch(e) {
                        MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", e.toString())
                        throw new Exception(e)
                    }
                    
                }
                
            } else {
            
                query101Cursor.each { it2 -> 
                    
                    def lastHistory = it2.history[-1]
                    Date lastDocdbDoDate = lastHistory.docdbDoDate
                    // println "lastDocdbDoDate = ${lastDocdbDoDate}"
                    // println lastDocdbDoDate.compareTo(docdbDoDate)
                    
                    if (lastDocdbDoDate.compareTo(docdbDoDate) >= 0) {
                        // println "do nothing"
                        return false
                    }  else {
                        
                        def query = [_id: updateRawDataId]
                        
                        try {
                            
                            DocdbInfoProcessRefactor3.processInfoData(query, lv1DB, lv2DB, tagAndJsfile, fileLogPath)
                            
                            // update flag
                            backPatentInfoDOCDB.update([_id: it._id], [$set: [bug99999 : true]])
                            
                        } catch(e) {
                            MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "Docdb Error", e.toString())
                            throw new Exception(e)
                        }
                    }
                    
                }  // end query101Cursor.each
            }
            
            restTimeProcess.process()
            
        }  // end queryCursor.each
        
        println "finished..."
        
    }  // end main

}
