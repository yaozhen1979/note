/**
 *  工具程式
 */
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// 10.60.90.101 / 127.0.0.1
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// TonyDB / PatentInfoDOCDB
def lv2DB = client.getDB("PatentInfoDOCDB")

// lv2 56278561f3b4f27dc1be7c8a => history, relRawdatas 中 unset 5628f126f3b41772647fbc66  

def queryLv2Id = "558bb2e5b4411f24f1d755c2"
def unsetLv1Id = "5628ef95f3b41772647eb392"

def queryLv2Data = lv2DB.PatentInfoDOCDB.findOne([_id: new ObjectId(queryLv2Id)])

// 
def updateHistory = []

queryLv2Data.history.each { history -> 
    
    if (history.rawDataId.toString() != unsetLv1Id) {
        updateHistory << history
    }
    
}

queryLv2Data.history = updateHistory

// println "queryLv2Data = ${queryLv2Data.history}"

//
def updateRelRawdatas = []

queryLv2Data.relRawdatas.each { relRawdata -> 
    if (relRawdata._id.toString() != unsetLv1Id) {
        updateRelRawdatas << relRawdata
    }
}
queryLv2Data.relRawdatas = updateRelRawdatas

// println "relRawdatas = ${queryLv2Data.relRawdatas}"

// println queryLv2Data

lv2DB.PatentInfoDOCDB.save(queryLv2Data)

println "unset finished..."
