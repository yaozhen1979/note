/**
 * redmine 12771
 * 
 * 先更新 other country, 再來更新即有PTO
 * 
 * 2015.08.20: 程式執行前, 共有[813632]筆資料
 * 
 */

import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

// db.PatentInfoDOCDB.find({_id: ObjectId("558bc101b4411f24f1e1de14")})

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

// other country = 95 (solr other country = 90), 即有PTO = 7
def countryList = [
    "AM", "AP", "AR", 
    // "AT", => AT 有問題... lv2Id = 558789feb4411f24f13e21ea => update ok => update type ok
    "AU", "BA", 
    // "BE", => BE 有問題... lv2Id = 557e996eb4411f24f1086ae0 => update ok => 應有60筆... => update type ok
    //             有問題... lv2Id = 557e9974b4411f24f10871a7 => update ok
    //             有問題... lv2Id = 557e9974b4411f24f10872bd => update ok
    //             有問題... lv2Id = 557e997fb4411f24f1087ced => update ok
    //             有問題... lv2Id = 557e9986b4411f24f108840b => update ok
    //             有問題... lv2Id = 557e99bbb4411f24f108b999 => update ok
    //             有問題... lv2Id = 557e99bbb4411f24f108b9a5 => update ok
    //             有問題... lv2Id = 557e99bdb4411f24f108bc1c => update ok
    //             有問題... lv2Id = 557e99bdb4411f24f108bc14 => update ok
    //             有問題... lv2Id = 557e99bdb4411f24f108bc19 => update ok
    //             有問題... lv2Id = 557e99beb4411f24f108bc57 => update ok
    //             有問題... lv2Id = 557e99beb4411f24f108bc59 => update ok
    //             有問題... lv2Id = 557e99beb4411f24f108bc5e => update ok
    //             有問題... lv2Id = 557e99bfb4411f24f108bcb6 => update ok
    //             有問題... lv2Id = 557e99bfb4411f24f108bc9f => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd1e => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd0d => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd12 => update ok
    //             有問題... lv2Id = 557e99bfb4411f24f108bcba => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd97 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd25 => update ok
    //             有問題... lv2Id = 557e99bfb4411f24f108bcab => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd19 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bda7 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bdb1 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bdc3 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bde7 => update ok
    //             有問題... lv2Id = 557e99bfb4411f24f108bcbe => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bdeb => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd10 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd4a => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd72 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bdf2 => update ok
    //             有問題... lv2Id = 557e99c0b4411f24f108bd88 => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108bfb1 => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108c020 => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108bfee => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108c030 => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108bfbb => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108bfa3 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c0aa => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108bfb6 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c0a6 => update ok
    //             有問題... lv2Id = 557e99c1b4411f24f108c064 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c096 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c0a1 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c0a5 => update ok
    //             有問題... lv2Id = 557e99c2b4411f24f108c090 => update ok
    //             有問題... lv2Id = 557e99deb4411f24f108dbb7 => update ok
    //             有問題... lv2Id = 557e99dfb4411f24f108de19 => update ok
    //             有問題... lv2Id = 557e99ebb4411f24f108e835 => update ok
    //             有問題... lv2Id = 557e99f3b4411f24f108f160 => update ok
    //             有問題... lv2Id = 557e99f4b4411f24f108f1ae => update ok
    //             有問題... lv2Id = 557e99f5b4411f24f108f2c4 => update ok
    //             有問題... lv2Id = 557e99f8b4411f24f108f5fa => update ok
    //             有問題... lv2Id = 557e99f9b4411f24f108f6ec => update ok
    //             有問題... lv2Id = 557e9a26b4411f24f109265d => update ok
    //             有問題... lv2Id = 557e9a29b4411f24f10929af => update ok
    //             有問題... lv2Id = 557e9a2bb4411f24f1092c63 => update ok
    //             有問題... lv2Id = 557ea13bb4411f24f11163cb => update ok
    //
    "BG", "BR", "BY",
    // "CA", => CA 有問題... lv2Id = 558af9bdb4411f24f173209f => kindcode = 1, 有問題資料, 待刪 => update type ok => 但錯誤資料仍未處理
    //             有問題... lv2Id = 558b0b16b4411f24f17e6436 => kindcode = 1, 有問題資料, 待刪
    //             有問題... lv2Id = 558b0b17b4411f24f17e64a6 => kindcode = 1, 有問題資料, 待刪
    //             有問題... lv2Id = 558b0b18b4411f24f17e6518 => kindcode = 1, 有問題資料, 待刪
    //             有問題... lv2Id = 558b0b18b4411f24f17e658b => kindcode = 1, 有問題資料, 待刪
    "CH", "CL", 
    // "CO", => CO 有問題... lv2Id = 558c8995b4411f24f12fe405 => update ok => update type ok
    "CR", "CS", "CU", "CY", "CZ",      
    "DD", 
    // "DE", => DE 有問題... lv2Id = 558a5ef0b4411f24f136752f => update ok => update type ok
    //             有問題... lv2Id = 558a5f23b4411f24f13696c9 => update ok
    //             有問題... lv2Id = 558a5f23b4411f24f1369719 => update ok
    //             有問題... lv2Id = 558a5f24b4411f24f1369789 => update ok
    //             有問題... lv2Id = 558a5f25b4411f24f1369862 => update ok
    //             有問題... lv2Id = 558a5f25b4411f24f13698f5 => update ok
    //             有問題... lv2Id = 558a5f25b4411f24f13698e1 => update ok
    //             有問題... lv2Id = 558a5f25b4411f24f13698fe => update ok
    //             有問題... lv2Id = 558a5f2ab4411f24f1369b08 => update ok
    //             有問題... lv2Id = 558a5f2bb4411f24f1369cb3 => update ok
    "DZ", "DK", "DO",                              
    "EA", "EC", "EE", "EG", "ES",                              
    "FI", "FR",                                                
    // "GB", => GB 有問題... lv2Id = 55890bdcb4411f24f1ca7e3b => kindcode = 13, 有問題資料, 待刪  => update type ok => 但錯誤資料仍未處理
    //             有問題... lv2Id = 55890bdfb4411f24f1ca8332 => kindcode = 13, 有問題資料, 待刪
    //             有問題... lv2Id = 55890be0b4411f24f1ca8387 => kindcode = 13, 有問題資料, 待刪
    //             有問題... lv2Id = 55890be0b4411f24f1ca83cf => kindcode = 13, 有問題資料, 待刪
    //             有問題... lv2Id = 55898ed2b4411f24f1dbe270 => kindcode = E, 有問題資料, 待刪
    "GC", "GE", 
    // "GR", => GR 有問題... lv2Id = 55a4dd86b4411f24f116d6a8 => history 流程有問題 => update ok => update type ok
    //             有問題... lv2Id = 55a4dd87b4411f24f116d6a9 => history 流程有問題 => update ok
    //             有問題... lv2Id = 55a4dd87b4411f24f116d6aa => history 流程有問題 => update ok
    //             有問題... lv2Id = 55a4dd87b4411f24f116d6ac => history 流程有問題 => update ok
    //             有問題... lv2Id = 55a4dd87b4411f24f116d6ad => history 流程有問題 => update ok
    "GT",                              
    "HK", "HN", "HR", 
    // "HU", => HU 有問題... lv2Id = 5591a7f7b4411f24f1e7eedb => update ok => ruleFlag = 2
    // "HU", => HU 有問題... lv2Id = 5591a800b4411f24f1e7f26c => update ok
    // "HU", => HU 有問題... lv2Id = 5591a812b4411f24f1e7f7b9 => update ok
    // "HU", => HU 有問題... lv2Id = 5591a812b4411f24f1e7f7ce => update ok
    // "HU", => HU 有問題... lv2Id = 5591a812b4411f24f1e7f78e => update ok
    // "HU", => HU 有問題... lv2Id = 5591a814b4411f24f1e7f89a => update ok
    // "HU", => HU 有問題... lv2Id = 5591a815b4411f24f1e7fa2f => update ok
    // "HU", => HU 有問題... lv2Id = 5591a815b4411f24f1e7fa79 => update ok
    // "HU", => HU 有問題... lv2Id = 5591a815b4411f24f1e7fa29 => update ok
    // "HU", => HU 有問題... lv2Id = 5591a815b4411f24f1e7fa4d => update ok
    // "ID", 
    // "IE", => IE 有問題... lv2Id = 55903914b4411f24f1bf3b4a => ruleFlag = 3 => update type ok
    "IL", "IN", "IS", "IT",                        
    "JO",                                                      
    "KE", 
    // "KG", => KG 有問題... lv2Id = 55a360d7b4411f24f116ae3a => update ok
    "KZ",                                          
    "LT", "LU", "LV",                                      
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",      
    "NI", 
    // "NL", => NL 有問題... lv2Id = 558c8d0ab4411f24f1324360 => update ok => update type ok
    "NO", "NZ",                                    
    "OA",                                                      
    "PA", "PE", "PH", "PL", 
    // "PT", => PT 有問題... lv2Id = 55907082b4411f24f1d06e78 => update ok => update type ok
    //             有問題... lv2Id = 55907161b4411f24f1d11a23 => update ok
    //
    "RO", "RS", "RU",                                          
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",                  
    "TH", "TJ", "TN", "TR", "TT",                              
    "UA", "UY", "UZ",                                          
    "VN",                                                      
    "YU",                                                      
    "ZA", "ZM", "ZW"                                           
]

def originPto = ["CN", "EP", "JP", "US", "KR", "TW", "WO"]

// WO, TW, KR, EP, CN
// db.PatentInfoDOCDB.find({country:'US', patentNumber:'H452'}) => 2015-09-02 還未更新

/*
 * skip(8074152)
 * JP => 55813df0b4411f24f11aa211 type = null
 */
def test = ["JP"]

def totolCount = 0

println "to start..."

test.each { cc ->
    
    // db.PatentInfoDOCDB.find(country:cc).each { data -> }
    
    // 目前處理筆數
    // def currentCount = 0
    // 目前bulk筆數
    def countOfBulk = 0
    // 每次bulk execute總筆數
    def sizeOfBulk = 500
    
    // batch process
    BulkWriteOperation infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
    
    def newType = "Others"
    
    // 558bc101b4411f24f1e1de14 / 558bc0bfb4411f24f1e1b862
    db.PatentInfoDOCDB.find([country:cc]).eachWithIndex { data, index ->
        
        println "${cc} process count -> ${index + 1}"
        
        // println "type = ${data.type}"
        
        if (!!data.type) {
            
            if (data.type.startsWith("Others:")) {
                
                // println "type contains [Others]"
                
                // db.PatentInfoDOCDB.update([_id: data._id], [$set: [type: newType, 'redmine':['bug':12771, 'status':'in progress']]])
                
                // bulk update
                // 增加 redmine, 是為了標記查詢而用, 也方便solr來更新索引, 但在更新索完之後, 要記得刪除該欄位.
                // def updateMap = [$set: [type: newType, 'redmine':['bug':12771, 'status':'in progress']]]
                def updateMap = [$set: [type: newType]]
                infoDOCDBBulk.find(new BasicDBObject("_id", data._id)).updateOne(new BasicDBObject(updateMap))
                countOfBulk++;
                totolCount++;
                
                // countOfBulk == sizeOfBulk 時, 則執行bulk execute.
                if (countOfBulk.mod(sizeOfBulk) == 0) {
                    //
                    println "${cc} batch execute ...."
                    //
                    infoDOCDBBulk.execute()
                    // init bulk again
                    infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
                    countOfBulk = 0
                }
                
                
            }
        
        } else if (data._id.toString() == "558af9bdb4411f24f173209f" || data._id.toString() == "558b0b16b4411f24f17e6436" ||
            data._id.toString() == "558b0b17b4411f24f17e64a6" ||
            data._id.toString() == "558b0b18b4411f24f17e6518" ||
            data._id.toString() == "558b0b18b4411f24f17e658b" ||
            data._id.toString() == "55890bdcb4411f24f1ca7e3b" ||
            data._id.toString() == "55890bdfb4411f24f1ca8332" ||
            data._id.toString() == "55890be0b4411f24f1ca8387" ||
            data._id.toString() == "55890be0b4411f24f1ca83cf" ||
            data._id.toString() == "55898ed2b4411f24f1dbe270"
            ) {
            
            // TODO: CA kindcode = 1 && GB data, do nothing...
        
        } else {
            throw new Exception("${data._id} type = null")
        }
        
    }  // end find function
    
    // execute rest bulk count
    if (countOfBulk > 0) {
        //
        println "${cc} rest batch execute ...."
        infoDOCDBBulk.execute()
    }
        
    
}

println "totolCount = ${totolCount++}"
println "finished..."

