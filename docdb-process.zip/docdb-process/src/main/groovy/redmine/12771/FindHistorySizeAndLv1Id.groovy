import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

//
println "to start..."

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

// TODO: query lv2 id
def id = "558789feb4411f24f13e21ea"

def data = db.PatentInfoDOCDB.findOne([_id: new ObjectId(id)])

println "history = ${data.history.size()}"

println "history = ${data.history[0]}"

println "type = ${data.type}"

println "mongoSyncFlag = ${data.mongoSyncFlag}"

println "finished..."