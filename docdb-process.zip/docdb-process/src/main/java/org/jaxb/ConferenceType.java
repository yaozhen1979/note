//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>conferenceType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="conferenceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="conftitle" type="{http://www.epo.org/exchange}conftitleType"/&gt;
 *           &lt;element name="date" type="{http://www.epo.org/exchange}ICE-date-type" minOccurs="0"/&gt;
 *           &lt;element name="confdate" type="{http://www.epo.org/exchange}confdateType" minOccurs="0"/&gt;
 *           &lt;element name="confno" type="{http://www.epo.org/exchange}confnoType" minOccurs="0"/&gt;
 *           &lt;element name="confplace" type="{http://www.epo.org/exchange}confplaceType" minOccurs="0"/&gt;
 *           &lt;element name="confsponsor" type="{http://www.epo.org/exchange}confsponsorType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "conferenceType", propOrder = {
    "text",
    "conftitle",
    "date",
    "confdate",
    "confno",
    "confplace",
    "confsponsor"
})
public class ConferenceType {

    protected TextType text;
    protected ConftitleType conftitle;
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger date;
    protected ConfdateType confdate;
    protected ConfnoType confno;
    protected ConfplaceType confplace;
    protected List<ConfsponsorType> confsponsor;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * 取得 conftitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ConftitleType }
     *     
     */
    public ConftitleType getConftitle() {
        return conftitle;
    }

    /**
     * 設定 conftitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ConftitleType }
     *     
     */
    public void setConftitle(ConftitleType value) {
        this.conftitle = value;
    }

    /**
     * 取得 date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDate() {
        return date;
    }

    /**
     * 設定 date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDate(BigInteger value) {
        this.date = value;
    }

    /**
     * 取得 confdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ConfdateType }
     *     
     */
    public ConfdateType getConfdate() {
        return confdate;
    }

    /**
     * 設定 confdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ConfdateType }
     *     
     */
    public void setConfdate(ConfdateType value) {
        this.confdate = value;
    }

    /**
     * 取得 confno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ConfnoType }
     *     
     */
    public ConfnoType getConfno() {
        return confno;
    }

    /**
     * 設定 confno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ConfnoType }
     *     
     */
    public void setConfno(ConfnoType value) {
        this.confno = value;
    }

    /**
     * 取得 confplace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ConfplaceType }
     *     
     */
    public ConfplaceType getConfplace() {
        return confplace;
    }

    /**
     * 設定 confplace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ConfplaceType }
     *     
     */
    public void setConfplace(ConfplaceType value) {
        this.confplace = value;
    }

    /**
     * Gets the value of the confsponsor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the confsponsor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConfsponsor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConfsponsorType }
     * 
     * 
     */
    public List<ConfsponsorType> getConfsponsor() {
        if (confsponsor == null) {
            confsponsor = new ArrayList<ConfsponsorType>();
        }
        return this.confsponsor;
    }

}
