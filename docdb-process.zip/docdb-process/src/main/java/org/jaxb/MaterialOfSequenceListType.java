//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>material-of-sequence-listType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="material-of-sequence-listType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="sequence-listing-material-type" type="{http://www.epo.org/exchange}sequence-listing-material-typeType"/&gt;
 *         &lt;element name="sequence-listing-material-format" type="{http://www.epo.org/exchange}sequence-listing-material-formatType"/&gt;
 *         &lt;element name="sequence-listing-filing-time" type="{http://www.epo.org/exchange}sequence-listing-filing-timeType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "material-of-sequence-listType", propOrder = {
    "sequenceListingMaterialType",
    "sequenceListingMaterialFormat",
    "sequenceListingFilingTime"
})
public class MaterialOfSequenceListType {

    @XmlElement(name = "sequence-listing-material-type", required = true)
    protected SequenceListingMaterialTypeType sequenceListingMaterialType;
    @XmlElement(name = "sequence-listing-material-format", required = true)
    protected SequenceListingMaterialFormatType sequenceListingMaterialFormat;
    @XmlElement(name = "sequence-listing-filing-time", required = true)
    protected SequenceListingFilingTimeType sequenceListingFilingTime;

    /**
     * 取得 sequenceListingMaterialType 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListingMaterialTypeType }
     *     
     */
    public SequenceListingMaterialTypeType getSequenceListingMaterialType() {
        return sequenceListingMaterialType;
    }

    /**
     * 設定 sequenceListingMaterialType 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListingMaterialTypeType }
     *     
     */
    public void setSequenceListingMaterialType(SequenceListingMaterialTypeType value) {
        this.sequenceListingMaterialType = value;
    }

    /**
     * 取得 sequenceListingMaterialFormat 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListingMaterialFormatType }
     *     
     */
    public SequenceListingMaterialFormatType getSequenceListingMaterialFormat() {
        return sequenceListingMaterialFormat;
    }

    /**
     * 設定 sequenceListingMaterialFormat 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListingMaterialFormatType }
     *     
     */
    public void setSequenceListingMaterialFormat(SequenceListingMaterialFormatType value) {
        this.sequenceListingMaterialFormat = value;
    }

    /**
     * 取得 sequenceListingFilingTime 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListingFilingTimeType }
     *     
     */
    public SequenceListingFilingTimeType getSequenceListingFilingTime() {
        return sequenceListingFilingTime;
    }

    /**
     * 設定 sequenceListingFilingTime 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListingFilingTimeType }
     *     
     */
    public void setSequenceListingFilingTime(SequenceListingFilingTimeType value) {
        this.sequenceListingFilingTime = value;
    }

}
