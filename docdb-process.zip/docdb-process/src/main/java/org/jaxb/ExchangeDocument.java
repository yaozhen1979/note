//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}bibliographic-data"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}abstract" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}patent-family" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}search-report-data" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="correction-code" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="country" use="required" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="date-produced" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="date-added-docdb" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="date-of-previous-exchange" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="date-of-last-exchange" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="date-publ" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="doc-number" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="file" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="file-reference-id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="family-id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="doc-id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="is-representative"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;enumeration value="YES"/&gt;
 *             &lt;enumeration value="NO"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="kind" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}language" /&gt;
 *       &lt;attribute name="originating-office" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="system" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bibliographicData",
    "_abstract",
    "patentFamily",
    "searchReportData"
})
@XmlRootElement(name = "exchange-document")
public class ExchangeDocument {

    @XmlElement(name = "bibliographic-data", namespace = "http://www.epo.org/exchange", required = true)
    protected BibliographicDataType bibliographicData;
    @XmlElement(name = "abstract", namespace = "http://www.epo.org/exchange")
    protected List<AbstractType> _abstract;
    @XmlElement(name = "patent-family", namespace = "http://www.epo.org/exchange")
    protected PatentFamilyType patentFamily;
    @XmlElement(name = "search-report-data", namespace = "http://www.epo.org/exchange")
    protected SearchReportDataType searchReportData;
    @XmlAttribute(name = "correction-code")
    protected String correctionCode;
    @XmlAttribute(name = "country", required = true)
    protected CountryType country;
    @XmlAttribute(name = "date-produced")
    protected BigInteger dateProduced;
    @XmlAttribute(name = "date-added-docdb")
    protected BigInteger dateAddedDocdb;
    @XmlAttribute(name = "date-of-previous-exchange")
    protected BigInteger dateOfPreviousExchange;
    @XmlAttribute(name = "date-of-last-exchange")
    protected BigInteger dateOfLastExchange;
    @XmlAttribute(name = "date-publ")
    protected BigInteger datePubl;
    @XmlAttribute(name = "doc-number")
    protected String docNumber;
    @XmlAttribute(name = "dtd-version")
    protected String dtdVersion;
    @XmlAttribute(name = "file")
    protected String file;
    @XmlAttribute(name = "file-reference-id")
    protected String fileReferenceId;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "family-id")
    protected String familyId;
    @XmlAttribute(name = "doc-id")
    protected String docId;
    @XmlAttribute(name = "is-representative")
    protected String isRepresentative;
    @XmlAttribute(name = "kind")
    protected String kind;
    @XmlAttribute(name = "lang")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String lang;
    @XmlAttribute(name = "originating-office")
    protected CountryType originatingOffice;
    @XmlAttribute(name = "status")
    protected String status;
    @XmlAttribute(name = "system")
    protected String system;

    /**
     * 取得 bibliographicData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BibliographicDataType }
     *     
     */
    public BibliographicDataType getBibliographicData() {
        return bibliographicData;
    }

    /**
     * 設定 bibliographicData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BibliographicDataType }
     *     
     */
    public void setBibliographicData(BibliographicDataType value) {
        this.bibliographicData = value;
    }

    /**
     * Gets the value of the abstract property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the abstract property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAbstract().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AbstractType }
     * 
     * 
     */
    public List<AbstractType> getAbstract() {
        if (_abstract == null) {
            _abstract = new ArrayList<AbstractType>();
        }
        return this._abstract;
    }

    /**
     * 取得 patentFamily 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentFamilyType }
     *     
     */
    public PatentFamilyType getPatentFamily() {
        return patentFamily;
    }

    /**
     * 設定 patentFamily 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentFamilyType }
     *     
     */
    public void setPatentFamily(PatentFamilyType value) {
        this.patentFamily = value;
    }

    /**
     * 取得 searchReportData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SearchReportDataType }
     *     
     */
    public SearchReportDataType getSearchReportData() {
        return searchReportData;
    }

    /**
     * 設定 searchReportData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchReportDataType }
     *     
     */
    public void setSearchReportData(SearchReportDataType value) {
        this.searchReportData = value;
    }

    /**
     * 取得 correctionCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrectionCode() {
        return correctionCode;
    }

    /**
     * 設定 correctionCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrectionCode(String value) {
        this.correctionCode = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setCountry(CountryType value) {
        this.country = value;
    }

    /**
     * 取得 dateProduced 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateProduced() {
        return dateProduced;
    }

    /**
     * 設定 dateProduced 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateProduced(BigInteger value) {
        this.dateProduced = value;
    }

    /**
     * 取得 dateAddedDocdb 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateAddedDocdb() {
        return dateAddedDocdb;
    }

    /**
     * 設定 dateAddedDocdb 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateAddedDocdb(BigInteger value) {
        this.dateAddedDocdb = value;
    }

    /**
     * 取得 dateOfPreviousExchange 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateOfPreviousExchange() {
        return dateOfPreviousExchange;
    }

    /**
     * 設定 dateOfPreviousExchange 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateOfPreviousExchange(BigInteger value) {
        this.dateOfPreviousExchange = value;
    }

    /**
     * 取得 dateOfLastExchange 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateOfLastExchange() {
        return dateOfLastExchange;
    }

    /**
     * 設定 dateOfLastExchange 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateOfLastExchange(BigInteger value) {
        this.dateOfLastExchange = value;
    }

    /**
     * 取得 datePubl 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDatePubl() {
        return datePubl;
    }

    /**
     * 設定 datePubl 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDatePubl(BigInteger value) {
        this.datePubl = value;
    }

    /**
     * 取得 docNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocNumber() {
        return docNumber;
    }

    /**
     * 設定 docNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocNumber(String value) {
        this.docNumber = value;
    }

    /**
     * 取得 dtdVersion 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * 設定 dtdVersion 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * 取得 file 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFile() {
        return file;
    }

    /**
     * 設定 file 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFile(String value) {
        this.file = value;
    }

    /**
     * 取得 fileReferenceId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileReferenceId() {
        return fileReferenceId;
    }

    /**
     * 設定 fileReferenceId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileReferenceId(String value) {
        this.fileReferenceId = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 familyId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     * 設定 familyId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFamilyId(String value) {
        this.familyId = value;
    }

    /**
     * 取得 docId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocId() {
        return docId;
    }

    /**
     * 設定 docId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocId(String value) {
        this.docId = value;
    }

    /**
     * 取得 isRepresentative 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsRepresentative() {
        return isRepresentative;
    }

    /**
     * 設定 isRepresentative 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsRepresentative(String value) {
        this.isRepresentative = value;
    }

    /**
     * 取得 kind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * 設定 kind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 originatingOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getOriginatingOffice() {
        return originatingOffice;
    }

    /**
     * 設定 originatingOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setOriginatingOffice(CountryType value) {
        this.originatingOffice = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * 取得 system 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystem() {
        return system;
    }

    /**
     * 設定 system 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystem(String value) {
        this.system = value;
    }

}
