//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>abstractType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="abstractType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="doc-page" type="{http://www.epo.org/exchange}doc-pageType" maxOccurs="unbounded"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="abst-problem" type="{http://www.epo.org/exchange}abst-problemType"/&gt;
 *           &lt;element name="abst-solution" type="{http://www.epo.org/exchange}abst-solutionType"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}p" maxOccurs="unbounded"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}language" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="country" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="doc-number" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="kind" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="date" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="data-format" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="abstract-source" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "abstractType", propOrder = {
    "docPage",
    "abstProblem",
    "abstSolution",
    "p"
})
public class AbstractType {

    @XmlElement(name = "doc-page")
    protected List<DocPageType> docPage;
    @XmlElement(name = "abst-problem")
    protected AbstProblemType abstProblem;
    @XmlElement(name = "abst-solution")
    protected AbstSolutionType abstSolution;
    @XmlElement(namespace = "http://www.epo.org/exchange")
    protected List<ExchPType> p;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String lang;
    @XmlAttribute(name = "status")
    protected String status;
    @XmlAttribute(name = "country")
    protected CountryType country;
    @XmlAttribute(name = "doc-number")
    protected String docNumber;
    @XmlAttribute(name = "kind")
    protected String kind;
    @XmlAttribute(name = "date")
    protected BigInteger date;
    @XmlAttribute(name = "data-format")
    protected String dataFormat;
    @XmlAttribute(name = "abstract-source")
    protected String abstractSource;

    /**
     * Gets the value of the docPage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docPage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocPage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocPageType }
     * 
     * 
     */
    public List<DocPageType> getDocPage() {
        if (docPage == null) {
            docPage = new ArrayList<DocPageType>();
        }
        return this.docPage;
    }

    /**
     * 取得 abstProblem 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbstProblemType }
     *     
     */
    public AbstProblemType getAbstProblem() {
        return abstProblem;
    }

    /**
     * 設定 abstProblem 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbstProblemType }
     *     
     */
    public void setAbstProblem(AbstProblemType value) {
        this.abstProblem = value;
    }

    /**
     * 取得 abstSolution 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbstSolutionType }
     *     
     */
    public AbstSolutionType getAbstSolution() {
        return abstSolution;
    }

    /**
     * 設定 abstSolution 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbstSolutionType }
     *     
     */
    public void setAbstSolution(AbstSolutionType value) {
        this.abstSolution = value;
    }

    /**
     * Gets the value of the p property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the p property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getP().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExchPType }
     * 
     * 
     */
    public List<ExchPType> getP() {
        if (p == null) {
            p = new ArrayList<ExchPType>();
        }
        return this.p;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setCountry(CountryType value) {
        this.country = value;
    }

    /**
     * 取得 docNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocNumber() {
        return docNumber;
    }

    /**
     * 設定 docNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocNumber(String value) {
        this.docNumber = value;
    }

    /**
     * 取得 kind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * 設定 kind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * 取得 date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDate() {
        return date;
    }

    /**
     * 設定 date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDate(BigInteger value) {
        this.date = value;
    }

    /**
     * 取得 dataFormat 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFormat() {
        return dataFormat;
    }

    /**
     * 設定 dataFormat 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFormat(String value) {
        this.dataFormat = value;
    }

    /**
     * 取得 abstractSource 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAbstractSource() {
        return abstractSource;
    }

    /**
     * 設定 abstractSource 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAbstractSource(String value) {
        this.abstractSource = value;
    }

}
