//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>citationType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="citationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="patcit" type="{http://www.epo.org/exchange}patcitType"/&gt;
 *           &lt;element name="nplcit" type="{http://www.epo.org/exchange}nplcitType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element name="rel-passage" type="{http://www.epo.org/exchange}rel-passageType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="category" type="{http://www.epo.org/exchange}categoryType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="rel-claims" type="{http://www.epo.org/exchange}rel-claimsType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}corresponding-docs" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="srep-phase" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="cited-phase" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="cited-date" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="cited-by" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="srep-office" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="sequence" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "citationType", propOrder = {
    "patcit",
    "nplcit",
    "relPassageAndCategoryAndRelClaims",
    "correspondingDocs"
})
public class CitationType {

    protected PatcitType patcit;
    protected NplcitType nplcit;
    @XmlElements({
        @XmlElement(name = "rel-passage", type = RelPassageType.class),
        @XmlElement(name = "category", type = CategoryType.class),
        @XmlElement(name = "rel-claims", type = RelClaimsType.class)
    })
    protected List<Object> relPassageAndCategoryAndRelClaims;
    @XmlElement(name = "corresponding-docs", namespace = "http://www.epo.org/exchange")
    protected List<CorrespondingDocsType> correspondingDocs;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "srep-phase")
    protected String srepPhase;
    @XmlAttribute(name = "cited-phase")
    protected String citedPhase;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "cited-date")
    protected BigInteger citedDate;
    @XmlAttribute(name = "cited-by")
    protected String citedBy;
    @XmlAttribute(name = "srep-office")
    protected CountryType srepOffice;
    @XmlAttribute(name = "sequence")
    protected String sequence;

    /**
     * 取得 patcit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatcitType }
     *     
     */
    public PatcitType getPatcit() {
        return patcit;
    }

    /**
     * 設定 patcit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatcitType }
     *     
     */
    public void setPatcit(PatcitType value) {
        this.patcit = value;
    }

    /**
     * 取得 nplcit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NplcitType }
     *     
     */
    public NplcitType getNplcit() {
        return nplcit;
    }

    /**
     * 設定 nplcit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NplcitType }
     *     
     */
    public void setNplcit(NplcitType value) {
        this.nplcit = value;
    }

    /**
     * Gets the value of the relPassageAndCategoryAndRelClaims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relPassageAndCategoryAndRelClaims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelPassageAndCategoryAndRelClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelPassageType }
     * {@link CategoryType }
     * {@link RelClaimsType }
     * 
     * 
     */
    public List<Object> getRelPassageAndCategoryAndRelClaims() {
        if (relPassageAndCategoryAndRelClaims == null) {
            relPassageAndCategoryAndRelClaims = new ArrayList<Object>();
        }
        return this.relPassageAndCategoryAndRelClaims;
    }

    /**
     * Gets the value of the correspondingDocs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the correspondingDocs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCorrespondingDocs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CorrespondingDocsType }
     * 
     * 
     */
    public List<CorrespondingDocsType> getCorrespondingDocs() {
        if (correspondingDocs == null) {
            correspondingDocs = new ArrayList<CorrespondingDocsType>();
        }
        return this.correspondingDocs;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 srepPhase 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrepPhase() {
        return srepPhase;
    }

    /**
     * 設定 srepPhase 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrepPhase(String value) {
        this.srepPhase = value;
    }

    /**
     * 取得 citedPhase 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCitedPhase() {
        return citedPhase;
    }

    /**
     * 設定 citedPhase 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCitedPhase(String value) {
        this.citedPhase = value;
    }

    /**
     * 取得 name 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * 設定 name 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * 取得 citedDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCitedDate() {
        return citedDate;
    }

    /**
     * 設定 citedDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCitedDate(BigInteger value) {
        this.citedDate = value;
    }

    /**
     * 取得 citedBy 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCitedBy() {
        return citedBy;
    }

    /**
     * 設定 citedBy 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCitedBy(String value) {
        this.citedBy = value;
    }

    /**
     * 取得 srepOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getSrepOffice() {
        return srepOffice;
    }

    /**
     * 設定 srepOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setSrepOffice(CountryType value) {
        this.srepOffice = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

}
