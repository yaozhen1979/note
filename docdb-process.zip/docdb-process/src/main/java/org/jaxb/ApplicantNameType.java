//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>applicant-nameType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="applicant-nameType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;group ref="{http://www.epo.org/exchange}nameGroup"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}language" /&gt;
 *       &lt;attribute name="data-format" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "applicant-nameType", propOrder = {
    "content"
})
public class ApplicantNameType {

    @XmlElementRefs({
        @XmlElementRef(name = "middle-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "synonym", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "orgname", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "department", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "iid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "role", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "prefix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "last-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "first-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "registered-number", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "suffix", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<?>> content;
    @XmlAttribute(name = "lang")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String lang;
    @XmlAttribute(name = "data-format")
    protected String dataFormat;

    /**
     * 取得其餘的內容模型. 
     * 
     * <p>
     * 基於下列原因, 您取得此 "catch-all" 特性: 
     * 綱要的兩個不同部分均使用欄位名稱 "Orgname". 請參閱: 
     * file:/D:/workspace/pc/docdb-process/xsd/final/exchange-documents-v2.5.4-for-generate-jaxb.xsd 的第 10953 行
     * file:/D:/workspace/pc/docdb-process/xsd/final/exchange-documents-v2.5.4-for-generate-jaxb.xsd 的第 10946 行
     * <p>
     * 為去除此特性, 請將特性自訂項目套用至下列兩個宣告的
     * 其中之一, 以變更它們的名稱: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}
     * {@link JAXBElement }{@code <}{@link SynonymType }{@code >}
     * {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}
     * {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}
     * {@link JAXBElement }{@code <}{@link IidType }{@code >}
     * {@link JAXBElement }{@code <}{@link RoleType }{@code >}
     * {@link JAXBElement }{@code <}{@link PrefixType }{@code >}
     * {@link JAXBElement }{@code <}{@link LastNameType }{@code >}
     * {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}
     * {@link JAXBElement }{@code <}{@link NameType }{@code >}
     * {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}
     * {@link JAXBElement }{@code <}{@link SuffixType }{@code >}
     * 
     * 
     */
    public List<JAXBElement<?>> getContent() {
        if (content == null) {
            content = new ArrayList<JAXBElement<?>>();
        }
        return this.content;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 dataFormat 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFormat() {
        return dataFormat;
    }

    /**
     * 設定 dataFormat 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFormat(String value) {
        this.dataFormat = value;
    }

}
