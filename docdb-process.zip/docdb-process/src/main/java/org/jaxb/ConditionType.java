//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>conditionType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="conditionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;group ref="{http://www.epo.org/exchange}ContentExpression"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "conditionType", propOrder = {
    "csymbolOrCiOrCn"
})
public class ConditionType {

    @XmlElements({
        @XmlElement(name = "csymbol", type = CsymbolType.class),
        @XmlElement(name = "ci", type = CiType.class),
        @XmlElement(name = "cn", type = CnType.class),
        @XmlElement(name = "apply", type = ApplyType.class),
        @XmlElement(name = "reln", type = RelnType.class),
        @XmlElement(name = "lambda", type = LambdaType.class),
        @XmlElement(name = "condition", type = ConditionType.class),
        @XmlElement(name = "declare", type = DeclareType.class),
        @XmlElement(name = "sep", type = SepType.class),
        @XmlElement(name = "semantics", type = SemanticsType.class),
        @XmlElement(name = "annotation", type = AnnotationType.class),
        @XmlElement(name = "annotation-xml", type = AnnotationXmlType.class),
        @XmlElement(name = "integers", type = IntegersType.class),
        @XmlElement(name = "reals", type = RealsType.class),
        @XmlElement(name = "rationals", type = RationalsType.class),
        @XmlElement(name = "naturalnumbers", type = NaturalnumbersType.class),
        @XmlElement(name = "complexes", type = ComplexesType.class),
        @XmlElement(name = "primes", type = PrimesType.class),
        @XmlElement(name = "exponentiale", type = ExponentialeType.class),
        @XmlElement(name = "imaginaryi", type = ImaginaryiType.class),
        @XmlElement(name = "notanumber", type = NotanumberType.class),
        @XmlElement(name = "true", type = TrueType.class),
        @XmlElement(name = "false", type = FalseType.class),
        @XmlElement(name = "emptyset", type = EmptysetType.class),
        @XmlElement(name = "pi", type = PiType.class),
        @XmlElement(name = "eulergamma", type = EulergammaType.class),
        @XmlElement(name = "infinity", type = InfinityType.class),
        @XmlElement(name = "interval", type = IntervalType.class),
        @XmlElement(name = "list", type = ListType.class),
        @XmlElement(name = "matrix", type = MatrixType.class),
        @XmlElement(name = "matrixrow", type = MatrixrowType.class),
        @XmlElement(name = "set", type = SetType.class),
        @XmlElement(name = "vector", type = VectorType.class),
        @XmlElement(name = "piecewise", type = PiecewiseType.class),
        @XmlElement(name = "lowlimit", type = LowlimitType.class),
        @XmlElement(name = "uplimit", type = UplimitType.class),
        @XmlElement(name = "bvar", type = BvarType.class),
        @XmlElement(name = "degree", type = DegreeType.class),
        @XmlElement(name = "logbase", type = LogbaseType.class),
        @XmlElement(name = "momentabout", type = MomentaboutType.class),
        @XmlElement(name = "domainofapplication", type = DomainofapplicationType.class),
        @XmlElement(name = "inverse", type = InverseType.class),
        @XmlElement(name = "ident", type = IdentType.class),
        @XmlElement(name = "domain", type = DomainType.class),
        @XmlElement(name = "codomain", type = CodomainType.class),
        @XmlElement(name = "image", type = ImageType.class),
        @XmlElement(name = "abs", type = AbsType.class),
        @XmlElement(name = "conjugate", type = ConjugateType.class),
        @XmlElement(name = "exp", type = ExpType.class),
        @XmlElement(name = "factorial", type = FactorialType.class),
        @XmlElement(name = "arg", type = ArgType.class),
        @XmlElement(name = "real", type = RealType.class),
        @XmlElement(name = "imaginary", type = ImaginaryType.class),
        @XmlElement(name = "floor", type = FloorType.class),
        @XmlElement(name = "ceiling", type = CeilingType.class),
        @XmlElement(name = "not", type = NotType.class),
        @XmlElement(name = "ln", type = LnType.class),
        @XmlElement(name = "sin", type = SinType.class),
        @XmlElement(name = "cos", type = CosType.class),
        @XmlElement(name = "tan", type = TanType.class),
        @XmlElement(name = "sec", type = SecType.class),
        @XmlElement(name = "csc", type = CscType.class),
        @XmlElement(name = "cot", type = CotType.class),
        @XmlElement(name = "sinh", type = SinhType.class),
        @XmlElement(name = "cosh", type = CoshType.class),
        @XmlElement(name = "tanh", type = TanhType.class),
        @XmlElement(name = "sech", type = SechType.class),
        @XmlElement(name = "csch", type = CschType.class),
        @XmlElement(name = "coth", type = CothType.class),
        @XmlElement(name = "arcsin", type = ArcsinType.class),
        @XmlElement(name = "arccos", type = ArccosType.class),
        @XmlElement(name = "arctan", type = ArctanType.class),
        @XmlElement(name = "arccosh", type = ArccoshType.class),
        @XmlElement(name = "arccot", type = ArccotType.class),
        @XmlElement(name = "arccoth", type = ArccothType.class),
        @XmlElement(name = "arccsc", type = ArccscType.class),
        @XmlElement(name = "arccsch", type = ArccschType.class),
        @XmlElement(name = "arcsec", type = ArcsecType.class),
        @XmlElement(name = "arcsech", type = ArcsechType.class),
        @XmlElement(name = "arcsinh", type = ArcsinhType.class),
        @XmlElement(name = "arctanh", type = ArctanhType.class),
        @XmlElement(name = "determinant", type = DeterminantType.class),
        @XmlElement(name = "transpose", type = TransposeType.class),
        @XmlElement(name = "card", type = CardType.class),
        @XmlElement(name = "quotient", type = QuotientType.class),
        @XmlElement(name = "divide", type = DivideType.class),
        @XmlElement(name = "power", type = PowerType.class),
        @XmlElement(name = "rem", type = RemType.class),
        @XmlElement(name = "implies", type = ImpliesType.class),
        @XmlElement(name = "vectorproduct", type = VectorproductType.class),
        @XmlElement(name = "scalarproduct", type = ScalarproductType.class),
        @XmlElement(name = "outerproduct", type = OuterproductType.class),
        @XmlElement(name = "setdiff", type = SetdiffType.class),
        @XmlElement(name = "fn", type = FnType.class),
        @XmlElement(name = "compose", type = ComposeType.class),
        @XmlElement(name = "plus", type = PlusType.class),
        @XmlElement(name = "times", type = TimesType.class),
        @XmlElement(name = "max", type = MaxType.class),
        @XmlElement(name = "min", type = MinType.class),
        @XmlElement(name = "gcd", type = GcdType.class),
        @XmlElement(name = "lcm", type = LcmType.class),
        @XmlElement(name = "and", type = AndType.class),
        @XmlElement(name = "or", type = OrType.class),
        @XmlElement(name = "xor", type = XorType.class),
        @XmlElement(name = "union", type = UnionType.class),
        @XmlElement(name = "intersect", type = IntersectType.class),
        @XmlElement(name = "cartesianproduct", type = CartesianproductType.class),
        @XmlElement(name = "mean", type = MeanType.class),
        @XmlElement(name = "sdev", type = SdevType.class),
        @XmlElement(name = "variance", type = VarianceType.class),
        @XmlElement(name = "median", type = MedianType.class),
        @XmlElement(name = "mode", type = ModeType.class),
        @XmlElement(name = "selector", type = SelectorType.class),
        @XmlElement(name = "root", type = RootType.class),
        @XmlElement(name = "minus", type = MinusType.class),
        @XmlElement(name = "log", type = LogType.class),
        @XmlElement(name = "int", type = IntType.class),
        @XmlElement(name = "diff", type = DiffType.class),
        @XmlElement(name = "partialdiff", type = PartialdiffType.class),
        @XmlElement(name = "divergence", type = DivergenceType.class),
        @XmlElement(name = "grad", type = GradType.class),
        @XmlElement(name = "curl", type = CurlType.class),
        @XmlElement(name = "laplacian", type = LaplacianType.class),
        @XmlElement(name = "sum", type = SumType.class),
        @XmlElement(name = "product", type = ProductType.class),
        @XmlElement(name = "limit", type = LimitType.class),
        @XmlElement(name = "moment", type = MomentType.class),
        @XmlElement(name = "exists", type = ExistsType.class),
        @XmlElement(name = "forall", type = ForallType.class),
        @XmlElement(name = "neq", type = NeqType.class),
        @XmlElement(name = "factorof", type = FactorofType.class),
        @XmlElement(name = "in", type = InType.class),
        @XmlElement(name = "notin", type = NotinType.class),
        @XmlElement(name = "notsubset", type = NotsubsetType.class),
        @XmlElement(name = "notprsubset", type = NotprsubsetType.class),
        @XmlElement(name = "tendsto", type = TendstoType.class),
        @XmlElement(name = "eq", type = EqType.class),
        @XmlElement(name = "leq", type = LeqType.class),
        @XmlElement(name = "lt", type = LtType.class),
        @XmlElement(name = "geq", type = GeqType.class),
        @XmlElement(name = "gt", type = GtType.class),
        @XmlElement(name = "equivalent", type = EquivalentType.class),
        @XmlElement(name = "approx", type = ApproxType.class),
        @XmlElement(name = "subset", type = SubsetType.class),
        @XmlElement(name = "prsubset", type = PrsubsetType.class),
        @XmlElement(name = "mi", type = MiType.class),
        @XmlElement(name = "mn", type = MnType.class),
        @XmlElement(name = "mo", type = MoType.class),
        @XmlElement(name = "mtext", type = MtextType.class),
        @XmlElement(name = "ms", type = MsType.class),
        @XmlElement(name = "mspace", type = MspaceType.class),
        @XmlElement(name = "mrow", type = MrowType.class),
        @XmlElement(name = "mfrac", type = MfracType.class),
        @XmlElement(name = "msqrt", type = MsqrtType.class),
        @XmlElement(name = "mroot", type = MrootType.class),
        @XmlElement(name = "menclose", type = MencloseType.class),
        @XmlElement(name = "mstyle", type = MstyleType.class),
        @XmlElement(name = "merror", type = MerrorType.class),
        @XmlElement(name = "mpadded", type = MpaddedType.class),
        @XmlElement(name = "mphantom", type = MphantomType.class),
        @XmlElement(name = "mfenced", type = MfencedType.class),
        @XmlElement(name = "msub", type = MsubType.class),
        @XmlElement(name = "msup", type = MsupType.class),
        @XmlElement(name = "msubsup", type = MsubsupType.class),
        @XmlElement(name = "munder", type = MunderType.class),
        @XmlElement(name = "mover", type = MoverType.class),
        @XmlElement(name = "munderover", type = MunderoverType.class),
        @XmlElement(name = "mmultiscripts", type = MmultiscriptsType.class),
        @XmlElement(name = "mtable", type = MtableType.class),
        @XmlElement(name = "mtr", type = MtrType.class),
        @XmlElement(name = "mlabeledtr", type = MlabeledtrType.class),
        @XmlElement(name = "mtd", type = MtdType.class),
        @XmlElement(name = "maligngroup", type = MaligngroupType.class),
        @XmlElement(name = "malignmark", type = MalignmarkType.class),
        @XmlElement(name = "maction", type = MactionType.class)
    })
    protected List<Object> csymbolOrCiOrCn;
    @XmlAttribute(name = "class")
    protected String clazz;
    @XmlAttribute(name = "style")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    protected String other;

    /**
     * Gets the value of the csymbolOrCiOrCn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the csymbolOrCiOrCn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCsymbolOrCiOrCn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CsymbolType }
     * {@link CiType }
     * {@link CnType }
     * {@link ApplyType }
     * {@link RelnType }
     * {@link LambdaType }
     * {@link ConditionType }
     * {@link DeclareType }
     * {@link SepType }
     * {@link SemanticsType }
     * {@link AnnotationType }
     * {@link AnnotationXmlType }
     * {@link IntegersType }
     * {@link RealsType }
     * {@link RationalsType }
     * {@link NaturalnumbersType }
     * {@link ComplexesType }
     * {@link PrimesType }
     * {@link ExponentialeType }
     * {@link ImaginaryiType }
     * {@link NotanumberType }
     * {@link TrueType }
     * {@link FalseType }
     * {@link EmptysetType }
     * {@link PiType }
     * {@link EulergammaType }
     * {@link InfinityType }
     * {@link IntervalType }
     * {@link ListType }
     * {@link MatrixType }
     * {@link MatrixrowType }
     * {@link SetType }
     * {@link VectorType }
     * {@link PiecewiseType }
     * {@link LowlimitType }
     * {@link UplimitType }
     * {@link BvarType }
     * {@link DegreeType }
     * {@link LogbaseType }
     * {@link MomentaboutType }
     * {@link DomainofapplicationType }
     * {@link InverseType }
     * {@link IdentType }
     * {@link DomainType }
     * {@link CodomainType }
     * {@link ImageType }
     * {@link AbsType }
     * {@link ConjugateType }
     * {@link ExpType }
     * {@link FactorialType }
     * {@link ArgType }
     * {@link RealType }
     * {@link ImaginaryType }
     * {@link FloorType }
     * {@link CeilingType }
     * {@link NotType }
     * {@link LnType }
     * {@link SinType }
     * {@link CosType }
     * {@link TanType }
     * {@link SecType }
     * {@link CscType }
     * {@link CotType }
     * {@link SinhType }
     * {@link CoshType }
     * {@link TanhType }
     * {@link SechType }
     * {@link CschType }
     * {@link CothType }
     * {@link ArcsinType }
     * {@link ArccosType }
     * {@link ArctanType }
     * {@link ArccoshType }
     * {@link ArccotType }
     * {@link ArccothType }
     * {@link ArccscType }
     * {@link ArccschType }
     * {@link ArcsecType }
     * {@link ArcsechType }
     * {@link ArcsinhType }
     * {@link ArctanhType }
     * {@link DeterminantType }
     * {@link TransposeType }
     * {@link CardType }
     * {@link QuotientType }
     * {@link DivideType }
     * {@link PowerType }
     * {@link RemType }
     * {@link ImpliesType }
     * {@link VectorproductType }
     * {@link ScalarproductType }
     * {@link OuterproductType }
     * {@link SetdiffType }
     * {@link FnType }
     * {@link ComposeType }
     * {@link PlusType }
     * {@link TimesType }
     * {@link MaxType }
     * {@link MinType }
     * {@link GcdType }
     * {@link LcmType }
     * {@link AndType }
     * {@link OrType }
     * {@link XorType }
     * {@link UnionType }
     * {@link IntersectType }
     * {@link CartesianproductType }
     * {@link MeanType }
     * {@link SdevType }
     * {@link VarianceType }
     * {@link MedianType }
     * {@link ModeType }
     * {@link SelectorType }
     * {@link RootType }
     * {@link MinusType }
     * {@link LogType }
     * {@link IntType }
     * {@link DiffType }
     * {@link PartialdiffType }
     * {@link DivergenceType }
     * {@link GradType }
     * {@link CurlType }
     * {@link LaplacianType }
     * {@link SumType }
     * {@link ProductType }
     * {@link LimitType }
     * {@link MomentType }
     * {@link ExistsType }
     * {@link ForallType }
     * {@link NeqType }
     * {@link FactorofType }
     * {@link InType }
     * {@link NotinType }
     * {@link NotsubsetType }
     * {@link NotprsubsetType }
     * {@link TendstoType }
     * {@link EqType }
     * {@link LeqType }
     * {@link LtType }
     * {@link GeqType }
     * {@link GtType }
     * {@link EquivalentType }
     * {@link ApproxType }
     * {@link SubsetType }
     * {@link PrsubsetType }
     * {@link MiType }
     * {@link MnType }
     * {@link MoType }
     * {@link MtextType }
     * {@link MsType }
     * {@link MspaceType }
     * {@link MrowType }
     * {@link MfracType }
     * {@link MsqrtType }
     * {@link MrootType }
     * {@link MencloseType }
     * {@link MstyleType }
     * {@link MerrorType }
     * {@link MpaddedType }
     * {@link MphantomType }
     * {@link MfencedType }
     * {@link MsubType }
     * {@link MsupType }
     * {@link MsubsupType }
     * {@link MunderType }
     * {@link MoverType }
     * {@link MunderoverType }
     * {@link MmultiscriptsType }
     * {@link MtableType }
     * {@link MtrType }
     * {@link MlabeledtrType }
     * {@link MtdType }
     * {@link MaligngroupType }
     * {@link MalignmarkType }
     * {@link MactionType }
     * 
     * 
     */
    public List<Object> getCsymbolOrCiOrCn() {
        if (csymbolOrCiOrCn == null) {
            csymbolOrCiOrCn = new ArrayList<Object>();
        }
        return this.csymbolOrCiOrCn;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

}
