//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>mtableType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="mtableType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;group ref="{http://www.epo.org/exchange}mtrPresExpression"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rowalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnwidth" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="groupalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="alignmentscope" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="side"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="left"/&gt;
 *             &lt;enumeration value="right"/&gt;
 *             &lt;enumeration value="leftoverlap"/&gt;
 *             &lt;enumeration value="rightoverlap"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="rowspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rowlines" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnlines" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="width" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="frame"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="none"/&gt;
 *             &lt;enumeration value="solid"/&gt;
 *             &lt;enumeration value="dashed"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="framespacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="minlabelspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="equalrows" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="equalcolumns" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="displaystyle"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mtableType", propOrder = {
    "miOrMnOrMo"
})
public class MtableType {

    @XmlElements({
        @XmlElement(name = "mi", type = MiType.class),
        @XmlElement(name = "mn", type = MnType.class),
        @XmlElement(name = "mo", type = MoType.class),
        @XmlElement(name = "mtext", type = MtextType.class),
        @XmlElement(name = "ms", type = MsType.class),
        @XmlElement(name = "mspace", type = MspaceType.class),
        @XmlElement(name = "mprescripts", type = MprescriptsType.class),
        @XmlElement(name = "none", type = NoneType.class),
        @XmlElement(name = "mrow", type = MrowType.class),
        @XmlElement(name = "mfrac", type = MfracType.class),
        @XmlElement(name = "msqrt", type = MsqrtType.class),
        @XmlElement(name = "mroot", type = MrootType.class),
        @XmlElement(name = "menclose", type = MencloseType.class),
        @XmlElement(name = "mstyle", type = MstyleType.class),
        @XmlElement(name = "merror", type = MerrorType.class),
        @XmlElement(name = "mpadded", type = MpaddedType.class),
        @XmlElement(name = "mphantom", type = MphantomType.class),
        @XmlElement(name = "mfenced", type = MfencedType.class),
        @XmlElement(name = "msub", type = MsubType.class),
        @XmlElement(name = "msup", type = MsupType.class),
        @XmlElement(name = "msubsup", type = MsubsupType.class),
        @XmlElement(name = "munder", type = MunderType.class),
        @XmlElement(name = "mover", type = MoverType.class),
        @XmlElement(name = "munderover", type = MunderoverType.class),
        @XmlElement(name = "mmultiscripts", type = MmultiscriptsType.class),
        @XmlElement(name = "mtable", type = MtableType.class),
        @XmlElement(name = "mtr", type = MtrType.class),
        @XmlElement(name = "mlabeledtr", type = MlabeledtrType.class),
        @XmlElement(name = "mtd", type = MtdType.class),
        @XmlElement(name = "maligngroup", type = MaligngroupType.class),
        @XmlElement(name = "malignmark", type = MalignmarkType.class),
        @XmlElement(name = "maction", type = MactionType.class),
        @XmlElement(name = "ci", type = CiType.class),
        @XmlElement(name = "csymbol", type = CsymbolType.class),
        @XmlElement(name = "cn", type = CnType.class),
        @XmlElement(name = "integers", type = IntegersType.class),
        @XmlElement(name = "reals", type = RealsType.class),
        @XmlElement(name = "rationals", type = RationalsType.class),
        @XmlElement(name = "naturalnumbers", type = NaturalnumbersType.class),
        @XmlElement(name = "complexes", type = ComplexesType.class),
        @XmlElement(name = "primes", type = PrimesType.class),
        @XmlElement(name = "exponentiale", type = ExponentialeType.class),
        @XmlElement(name = "imaginaryi", type = ImaginaryiType.class),
        @XmlElement(name = "notanumber", type = NotanumberType.class),
        @XmlElement(name = "true", type = TrueType.class),
        @XmlElement(name = "false", type = FalseType.class),
        @XmlElement(name = "emptyset", type = EmptysetType.class),
        @XmlElement(name = "pi", type = PiType.class),
        @XmlElement(name = "eulergamma", type = EulergammaType.class),
        @XmlElement(name = "infinity", type = InfinityType.class),
        @XmlElement(name = "apply", type = ApplyType.class),
        @XmlElement(name = "fn", type = FnType.class),
        @XmlElement(name = "lambda", type = LambdaType.class),
        @XmlElement(name = "reln", type = RelnType.class),
        @XmlElement(name = "interval", type = IntervalType.class),
        @XmlElement(name = "list", type = ListType.class),
        @XmlElement(name = "matrix", type = MatrixType.class),
        @XmlElement(name = "matrixrow", type = MatrixrowType.class),
        @XmlElement(name = "set", type = SetType.class),
        @XmlElement(name = "vector", type = VectorType.class),
        @XmlElement(name = "piecewise", type = PiecewiseType.class),
        @XmlElement(name = "semantics", type = SemanticsType.class),
        @XmlElement(name = "declare", type = DeclareType.class)
    })
    protected List<Object> miOrMnOrMo;
    @XmlAttribute(name = "class")
    protected String clazz;
    @XmlAttribute(name = "style")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    protected String other;
    @XmlAttribute(name = "align")
    protected String align;
    @XmlAttribute(name = "rowalign")
    protected String rowalign;
    @XmlAttribute(name = "columnalign")
    protected String columnalign;
    @XmlAttribute(name = "columnwidth")
    protected String columnwidth;
    @XmlAttribute(name = "groupalign")
    protected String groupalign;
    @XmlAttribute(name = "alignmentscope")
    protected String alignmentscope;
    @XmlAttribute(name = "side")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String side;
    @XmlAttribute(name = "rowspacing")
    protected String rowspacing;
    @XmlAttribute(name = "columnspacing")
    protected String columnspacing;
    @XmlAttribute(name = "rowlines")
    protected String rowlines;
    @XmlAttribute(name = "columnlines")
    protected String columnlines;
    @XmlAttribute(name = "width")
    protected String width;
    @XmlAttribute(name = "frame")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String frame;
    @XmlAttribute(name = "framespacing")
    protected String framespacing;
    @XmlAttribute(name = "minlabelspacing")
    protected String minlabelspacing;
    @XmlAttribute(name = "equalrows")
    protected String equalrows;
    @XmlAttribute(name = "equalcolumns")
    protected String equalcolumns;
    @XmlAttribute(name = "displaystyle")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String displaystyle;

    /**
     * Gets the value of the miOrMnOrMo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miOrMnOrMo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiOrMnOrMo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MiType }
     * {@link MnType }
     * {@link MoType }
     * {@link MtextType }
     * {@link MsType }
     * {@link MspaceType }
     * {@link MprescriptsType }
     * {@link NoneType }
     * {@link MrowType }
     * {@link MfracType }
     * {@link MsqrtType }
     * {@link MrootType }
     * {@link MencloseType }
     * {@link MstyleType }
     * {@link MerrorType }
     * {@link MpaddedType }
     * {@link MphantomType }
     * {@link MfencedType }
     * {@link MsubType }
     * {@link MsupType }
     * {@link MsubsupType }
     * {@link MunderType }
     * {@link MoverType }
     * {@link MunderoverType }
     * {@link MmultiscriptsType }
     * {@link MtableType }
     * {@link MtrType }
     * {@link MlabeledtrType }
     * {@link MtdType }
     * {@link MaligngroupType }
     * {@link MalignmarkType }
     * {@link MactionType }
     * {@link CiType }
     * {@link CsymbolType }
     * {@link CnType }
     * {@link IntegersType }
     * {@link RealsType }
     * {@link RationalsType }
     * {@link NaturalnumbersType }
     * {@link ComplexesType }
     * {@link PrimesType }
     * {@link ExponentialeType }
     * {@link ImaginaryiType }
     * {@link NotanumberType }
     * {@link TrueType }
     * {@link FalseType }
     * {@link EmptysetType }
     * {@link PiType }
     * {@link EulergammaType }
     * {@link InfinityType }
     * {@link ApplyType }
     * {@link FnType }
     * {@link LambdaType }
     * {@link RelnType }
     * {@link IntervalType }
     * {@link ListType }
     * {@link MatrixType }
     * {@link MatrixrowType }
     * {@link SetType }
     * {@link VectorType }
     * {@link PiecewiseType }
     * {@link SemanticsType }
     * {@link DeclareType }
     * 
     * 
     */
    public List<Object> getMiOrMnOrMo() {
        if (miOrMnOrMo == null) {
            miOrMnOrMo = new ArrayList<Object>();
        }
        return this.miOrMnOrMo;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 align 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlign() {
        return align;
    }

    /**
     * 設定 align 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlign(String value) {
        this.align = value;
    }

    /**
     * 取得 rowalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowalign() {
        return rowalign;
    }

    /**
     * 設定 rowalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowalign(String value) {
        this.rowalign = value;
    }

    /**
     * 取得 columnalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnalign() {
        return columnalign;
    }

    /**
     * 設定 columnalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnalign(String value) {
        this.columnalign = value;
    }

    /**
     * 取得 columnwidth 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnwidth() {
        return columnwidth;
    }

    /**
     * 設定 columnwidth 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnwidth(String value) {
        this.columnwidth = value;
    }

    /**
     * 取得 groupalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupalign() {
        return groupalign;
    }

    /**
     * 設定 groupalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupalign(String value) {
        this.groupalign = value;
    }

    /**
     * 取得 alignmentscope 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlignmentscope() {
        return alignmentscope;
    }

    /**
     * 設定 alignmentscope 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlignmentscope(String value) {
        this.alignmentscope = value;
    }

    /**
     * 取得 side 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSide() {
        return side;
    }

    /**
     * 設定 side 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSide(String value) {
        this.side = value;
    }

    /**
     * 取得 rowspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowspacing() {
        return rowspacing;
    }

    /**
     * 設定 rowspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowspacing(String value) {
        this.rowspacing = value;
    }

    /**
     * 取得 columnspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnspacing() {
        return columnspacing;
    }

    /**
     * 設定 columnspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnspacing(String value) {
        this.columnspacing = value;
    }

    /**
     * 取得 rowlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowlines() {
        return rowlines;
    }

    /**
     * 設定 rowlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowlines(String value) {
        this.rowlines = value;
    }

    /**
     * 取得 columnlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnlines() {
        return columnlines;
    }

    /**
     * 設定 columnlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnlines(String value) {
        this.columnlines = value;
    }

    /**
     * 取得 width 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWidth() {
        return width;
    }

    /**
     * 設定 width 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWidth(String value) {
        this.width = value;
    }

    /**
     * 取得 frame 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrame() {
        return frame;
    }

    /**
     * 設定 frame 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrame(String value) {
        this.frame = value;
    }

    /**
     * 取得 framespacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFramespacing() {
        return framespacing;
    }

    /**
     * 設定 framespacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFramespacing(String value) {
        this.framespacing = value;
    }

    /**
     * 取得 minlabelspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinlabelspacing() {
        return minlabelspacing;
    }

    /**
     * 設定 minlabelspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinlabelspacing(String value) {
        this.minlabelspacing = value;
    }

    /**
     * 取得 equalrows 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualrows() {
        return equalrows;
    }

    /**
     * 設定 equalrows 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualrows(String value) {
        this.equalrows = value;
    }

    /**
     * 取得 equalcolumns 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualcolumns() {
        return equalcolumns;
    }

    /**
     * 設定 equalcolumns 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualcolumns(String value) {
        this.equalcolumns = value;
    }

    /**
     * 取得 displaystyle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplaystyle() {
        return displaystyle;
    }

    /**
     * 設定 displaystyle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplaystyle(String value) {
        this.displaystyle = value;
    }

}
