//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>classification-ipcType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="classification-ipcType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="edition" type="{http://www.epo.org/exchange}editionType" minOccurs="0"/&gt;
 *         &lt;element name="main-classification" type="{http://www.epo.org/exchange}main-classificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="further-classification" type="{http://www.epo.org/exchange}further-classificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element name="additional-info" type="{http://www.epo.org/exchange}additional-infoType"/&gt;
 *           &lt;element name="linked-indexing-code-group" type="{http://www.epo.org/exchange}linked-indexing-code-groupType"/&gt;
 *           &lt;element name="unlinked-indexing-code" type="{http://www.epo.org/exchange}unlinked-indexing-codeType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classification-ipcType", propOrder = {
    "edition",
    "mainClassification",
    "furtherClassification",
    "additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode",
    "text"
})
public class ClassificationIpcType {

    protected EditionType edition;
    @XmlElement(name = "main-classification")
    protected List<MainClassificationType> mainClassification;
    @XmlElement(name = "further-classification")
    protected List<FurtherClassificationType> furtherClassification;
    @XmlElements({
        @XmlElement(name = "additional-info", type = AdditionalInfoType.class),
        @XmlElement(name = "linked-indexing-code-group", type = LinkedIndexingCodeGroupType.class),
        @XmlElement(name = "unlinked-indexing-code", type = UnlinkedIndexingCodeType.class)
    })
    protected List<Object> additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;
    protected List<TextType> text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EditionType }
     *     
     */
    public EditionType getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EditionType }
     *     
     */
    public void setEdition(EditionType value) {
        this.edition = value;
    }

    /**
     * Gets the value of the mainClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mainClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMainClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MainClassificationType }
     * 
     * 
     */
    public List<MainClassificationType> getMainClassification() {
        if (mainClassification == null) {
            mainClassification = new ArrayList<MainClassificationType>();
        }
        return this.mainClassification;
    }

    /**
     * Gets the value of the furtherClassification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the furtherClassification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFurtherClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FurtherClassificationType }
     * 
     * 
     */
    public List<FurtherClassificationType> getFurtherClassification() {
        if (furtherClassification == null) {
            furtherClassification = new ArrayList<FurtherClassificationType>();
        }
        return this.furtherClassification;
    }

    /**
     * Gets the value of the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInfoType }
     * {@link LinkedIndexingCodeGroupType }
     * {@link UnlinkedIndexingCodeType }
     * 
     * 
     */
    public List<Object> getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode() {
        if (additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode == null) {
            additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode = new ArrayList<Object>();
        }
        return this.additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;
    }

    /**
     * Gets the value of the text property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the text property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getText().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TextType }
     * 
     * 
     */
    public List<TextType> getText() {
        if (text == null) {
            text = new ArrayList<TextType>();
        }
        return this.text;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
