//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>non-establishment-of-opinionType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="non-establishment-of-opinionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="invention-not-examined" type="{http://www.epo.org/exchange}invention-not-examinedType"/&gt;
 *         &lt;element name="not-annex-c-compliant" type="{http://www.epo.org/exchange}not-annex-c-compliantType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "non-establishment-of-opinionType", propOrder = {
    "inventionNotExamined",
    "notAnnexCCompliant"
})
public class NonEstablishmentOfOpinionType {

    @XmlElement(name = "invention-not-examined", required = true)
    protected InventionNotExaminedType inventionNotExamined;
    @XmlElement(name = "not-annex-c-compliant", required = true)
    protected NotAnnexCCompliantType notAnnexCCompliant;

    /**
     * 取得 inventionNotExamined 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InventionNotExaminedType }
     *     
     */
    public InventionNotExaminedType getInventionNotExamined() {
        return inventionNotExamined;
    }

    /**
     * 設定 inventionNotExamined 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InventionNotExaminedType }
     *     
     */
    public void setInventionNotExamined(InventionNotExaminedType value) {
        this.inventionNotExamined = value;
    }

    /**
     * 取得 notAnnexCCompliant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NotAnnexCCompliantType }
     *     
     */
    public NotAnnexCCompliantType getNotAnnexCCompliant() {
        return notAnnexCCompliant;
    }

    /**
     * 設定 notAnnexCCompliant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NotAnnexCCompliantType }
     *     
     */
    public void setNotAnnexCCompliant(NotAnnexCCompliantType value) {
        this.notAnnexCCompliant = value;
    }

}
