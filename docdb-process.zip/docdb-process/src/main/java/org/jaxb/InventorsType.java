//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>inventorsType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="inventorsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}inventor"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}deceased-inventor"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "inventorsType", propOrder = {
    "inventorOrDeceasedInventor"
})
public class InventorsType {

    @XmlElements({
        @XmlElement(name = "inventor", namespace = "http://www.epo.org/exchange", type = InventorType.class),
        @XmlElement(name = "deceased-inventor", namespace = "http://www.epo.org/exchange", type = DeceasedInventorType.class)
    })
    protected List<Object> inventorOrDeceasedInventor;

    /**
     * Gets the value of the inventorOrDeceasedInventor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inventorOrDeceasedInventor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInventorOrDeceasedInventor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InventorType }
     * {@link DeceasedInventorType }
     * 
     * 
     */
    public List<Object> getInventorOrDeceasedInventor() {
        if (inventorOrDeceasedInventor == null) {
            inventorOrDeceasedInventor = new ArrayList<Object>();
        }
        return this.inventorOrDeceasedInventor;
    }

}
