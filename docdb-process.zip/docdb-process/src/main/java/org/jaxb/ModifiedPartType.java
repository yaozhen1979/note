//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>modified-partType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="modified-partType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="modified-part-name" type="{http://www.epo.org/exchange}modified-part-nameType"/&gt;
 *         &lt;element name="modified-item" type="{http://www.epo.org/exchange}modified-itemType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "modified-partType", propOrder = {
    "modifiedPartName",
    "modifiedItem"
})
public class ModifiedPartType {

    @XmlElement(name = "modified-part-name", required = true)
    protected ModifiedPartNameType modifiedPartName;
    @XmlElement(name = "modified-item")
    protected List<ModifiedItemType> modifiedItem;
    @XmlAttribute(name = "sequence")
    protected String sequence;
    @XmlAttribute(name = "lang")
    protected String lang;

    /**
     * 取得 modifiedPartName 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ModifiedPartNameType }
     *     
     */
    public ModifiedPartNameType getModifiedPartName() {
        return modifiedPartName;
    }

    /**
     * 設定 modifiedPartName 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ModifiedPartNameType }
     *     
     */
    public void setModifiedPartName(ModifiedPartNameType value) {
        this.modifiedPartName = value;
    }

    /**
     * Gets the value of the modifiedItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modifiedItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModifiedItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModifiedItemType }
     * 
     * 
     */
    public List<ModifiedItemType> getModifiedItem() {
        if (modifiedItem == null) {
            modifiedItem = new ArrayList<ModifiedItemType>();
        }
        return this.modifiedItem;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

}
