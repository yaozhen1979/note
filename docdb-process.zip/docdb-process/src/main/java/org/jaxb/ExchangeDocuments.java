//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}exchange-document" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="country" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="date-produced" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="date-of-exchange" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="file" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="no-of-documents" type="{http://www.w3.org/2001/XMLSchema}integer" /&gt;
 *       &lt;attribute name="originating-office" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "exchangeDocument"
})
@XmlRootElement(name = "exchange-documents")
public class ExchangeDocuments {

    @XmlElement(name = "exchange-document", namespace = "http://www.epo.org/exchange", required = true)
    protected List<ExchangeDocument> exchangeDocument;
    @XmlAttribute(name = "country")
    protected CountryType country;
    @XmlAttribute(name = "date-produced")
    protected BigInteger dateProduced;
    @XmlAttribute(name = "date-of-exchange")
    protected BigInteger dateOfExchange;
    @XmlAttribute(name = "dtd-version")
    protected String dtdVersion;
    @XmlAttribute(name = "file")
    protected String file;
    @XmlAttribute(name = "no-of-documents")
    protected BigInteger noOfDocuments;
    @XmlAttribute(name = "originating-office")
    protected CountryType originatingOffice;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * Gets the value of the exchangeDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exchangeDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExchangeDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExchangeDocument }
     * 
     * 
     */
    public List<ExchangeDocument> getExchangeDocument() {
        if (exchangeDocument == null) {
            exchangeDocument = new ArrayList<ExchangeDocument>();
        }
        return this.exchangeDocument;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setCountry(CountryType value) {
        this.country = value;
    }

    /**
     * 取得 dateProduced 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateProduced() {
        return dateProduced;
    }

    /**
     * 設定 dateProduced 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateProduced(BigInteger value) {
        this.dateProduced = value;
    }

    /**
     * 取得 dateOfExchange 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDateOfExchange() {
        return dateOfExchange;
    }

    /**
     * 設定 dateOfExchange 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDateOfExchange(BigInteger value) {
        this.dateOfExchange = value;
    }

    /**
     * 取得 dtdVersion 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * 設定 dtdVersion 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * 取得 file 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFile() {
        return file;
    }

    /**
     * 設定 file 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFile(String value) {
        this.file = value;
    }

    /**
     * 取得 noOfDocuments 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNoOfDocuments() {
        return noOfDocuments;
    }

    /**
     * 設定 noOfDocuments 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNoOfDocuments(BigInteger value) {
        this.noOfDocuments = value;
    }

    /**
     * 取得 originatingOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getOriginatingOffice() {
        return originatingOffice;
    }

    /**
     * 設定 originatingOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setOriginatingOffice(CountryType value) {
        this.originatingOffice = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
