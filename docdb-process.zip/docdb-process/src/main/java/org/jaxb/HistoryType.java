//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>historyType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="historyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *         &lt;choice&gt;
 *           &lt;element name="received" type="{http://www.epo.org/exchange}receivedType"/&gt;
 *           &lt;element name="accepted" type="{http://www.epo.org/exchange}acceptedType"/&gt;
 *           &lt;element name="revised" type="{http://www.epo.org/exchange}revisedType"/&gt;
 *           &lt;element name="misc" type="{http://www.epo.org/exchange}miscType"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "historyType", propOrder = {
    "text",
    "received",
    "accepted",
    "revised",
    "misc"
})
public class HistoryType {

    protected TextType text;
    protected ReceivedType received;
    protected AcceptedType accepted;
    protected RevisedType revised;
    protected MiscType misc;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * 取得 received 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ReceivedType }
     *     
     */
    public ReceivedType getReceived() {
        return received;
    }

    /**
     * 設定 received 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ReceivedType }
     *     
     */
    public void setReceived(ReceivedType value) {
        this.received = value;
    }

    /**
     * 取得 accepted 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AcceptedType }
     *     
     */
    public AcceptedType getAccepted() {
        return accepted;
    }

    /**
     * 設定 accepted 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AcceptedType }
     *     
     */
    public void setAccepted(AcceptedType value) {
        this.accepted = value;
    }

    /**
     * 取得 revised 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link RevisedType }
     *     
     */
    public RevisedType getRevised() {
        return revised;
    }

    /**
     * 設定 revised 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link RevisedType }
     *     
     */
    public void setRevised(RevisedType value) {
        this.revised = value;
    }

    /**
     * 取得 misc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MiscType }
     *     
     */
    public MiscType getMisc() {
        return misc;
    }

    /**
     * 設定 misc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MiscType }
     *     
     */
    public void setMisc(MiscType value) {
        this.misc = value;
    }

}
