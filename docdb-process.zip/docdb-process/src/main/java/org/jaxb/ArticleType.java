//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>articleType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="articleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="author" type="{http://www.epo.org/exchange}authorType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="atl" type="{http://www.epo.org/exchange}atlType" minOccurs="0"/&gt;
 *           &lt;element name="subname" type="{http://www.epo.org/exchange}subnameType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;choice&gt;
 *             &lt;element name="serial" type="{http://www.epo.org/exchange}serialType"/&gt;
 *             &lt;element name="book" type="{http://www.epo.org/exchange}bookType"/&gt;
 *           &lt;/choice&gt;
 *           &lt;element name="absno" type="{http://www.epo.org/exchange}absnoType" minOccurs="0"/&gt;
 *           &lt;element name="location" type="{http://www.epo.org/exchange}locationType" minOccurs="0"/&gt;
 *           &lt;element name="class" type="{http://www.epo.org/exchange}classType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="keyword" type="{http://www.epo.org/exchange}keywordType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="cpyrt" type="{http://www.epo.org/exchange}cpyrtType" minOccurs="0"/&gt;
 *           &lt;element name="artid" type="{http://www.epo.org/exchange}artidType" minOccurs="0"/&gt;
 *           &lt;element name="srchdate" type="{http://www.epo.org/exchange}srchdateType" minOccurs="0"/&gt;
 *           &lt;element name="refno" type="{http://www.epo.org/exchange}refnoType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "articleType", propOrder = {
    "text",
    "author",
    "atl",
    "subname",
    "serial",
    "book",
    "absno",
    "location",
    "clazz",
    "keyword",
    "cpyrt",
    "artid",
    "srchdate",
    "refno"
})
public class ArticleType {

    protected TextType text;
    protected List<AuthorType> author;
    protected AtlType atl;
    protected List<SubnameType> subname;
    protected SerialType serial;
    protected BookType book;
    protected AbsnoType absno;
    protected LocationType location;
    @XmlElement(name = "class")
    protected List<ClassType> clazz;
    protected List<KeywordType> keyword;
    protected CpyrtType cpyrt;
    protected ArtidType artid;
    protected SrchdateType srchdate;
    protected List<RefnoType> refno;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the author property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AuthorType }
     * 
     * 
     */
    public List<AuthorType> getAuthor() {
        if (author == null) {
            author = new ArrayList<AuthorType>();
        }
        return this.author;
    }

    /**
     * 取得 atl 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AtlType }
     *     
     */
    public AtlType getAtl() {
        return atl;
    }

    /**
     * 設定 atl 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AtlType }
     *     
     */
    public void setAtl(AtlType value) {
        this.atl = value;
    }

    /**
     * Gets the value of the subname property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subname property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubname().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubnameType }
     * 
     * 
     */
    public List<SubnameType> getSubname() {
        if (subname == null) {
            subname = new ArrayList<SubnameType>();
        }
        return this.subname;
    }

    /**
     * 取得 serial 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SerialType }
     *     
     */
    public SerialType getSerial() {
        return serial;
    }

    /**
     * 設定 serial 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SerialType }
     *     
     */
    public void setSerial(SerialType value) {
        this.serial = value;
    }

    /**
     * 取得 book 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BookType }
     *     
     */
    public BookType getBook() {
        return book;
    }

    /**
     * 設定 book 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BookType }
     *     
     */
    public void setBook(BookType value) {
        this.book = value;
    }

    /**
     * 取得 absno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbsnoType }
     *     
     */
    public AbsnoType getAbsno() {
        return absno;
    }

    /**
     * 設定 absno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbsnoType }
     *     
     */
    public void setAbsno(AbsnoType value) {
        this.absno = value;
    }

    /**
     * 取得 location 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link LocationType }
     *     
     */
    public LocationType getLocation() {
        return location;
    }

    /**
     * 設定 location 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationType }
     *     
     */
    public void setLocation(LocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clazz property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClazz().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClassType }
     * 
     * 
     */
    public List<ClassType> getClazz() {
        if (clazz == null) {
            clazz = new ArrayList<ClassType>();
        }
        return this.clazz;
    }

    /**
     * Gets the value of the keyword property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyword property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyword().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeywordType }
     * 
     * 
     */
    public List<KeywordType> getKeyword() {
        if (keyword == null) {
            keyword = new ArrayList<KeywordType>();
        }
        return this.keyword;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CpyrtType }
     *     
     */
    public CpyrtType getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CpyrtType }
     *     
     */
    public void setCpyrt(CpyrtType value) {
        this.cpyrt = value;
    }

    /**
     * 取得 artid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ArtidType }
     *     
     */
    public ArtidType getArtid() {
        return artid;
    }

    /**
     * 設定 artid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ArtidType }
     *     
     */
    public void setArtid(ArtidType value) {
        this.artid = value;
    }

    /**
     * 取得 srchdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SrchdateType }
     *     
     */
    public SrchdateType getSrchdate() {
        return srchdate;
    }

    /**
     * 設定 srchdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SrchdateType }
     *     
     */
    public void setSrchdate(SrchdateType value) {
        this.srchdate = value;
    }

    /**
     * Gets the value of the refno property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refno property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefno().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RefnoType }
     * 
     * 
     */
    public List<RefnoType> getRefno() {
        if (refno == null) {
            refno = new ArrayList<RefnoType>();
        }
        return this.refno;
    }

}
