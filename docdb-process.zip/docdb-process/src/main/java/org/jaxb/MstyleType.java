//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>mstyleType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="mstyleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;group ref="{http://www.epo.org/exchange}PresExpression"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fontsize" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fontweight"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="normal"/&gt;
 *             &lt;enumeration value="bold"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fontstyle"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="normal"/&gt;
 *             &lt;enumeration value="italic"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fontfamily" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="color" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mathvariant" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mathsize" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mathcolor" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mathbackground" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="form"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="prefix"/&gt;
 *             &lt;enumeration value="infix"/&gt;
 *             &lt;enumeration value="postfix"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fence"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="separator"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="lspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="stretchy"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="symmetric"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="maxsize" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="minsize" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="largeop"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="movablelimits"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="accent"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="lquote" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rquote" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="linethickness" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="scriptlevel" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="scriptsizemultiplier" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="scriptminsize" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="background" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="veryverythinmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="verythinmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="thinmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mediummathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="thickmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="verythickmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="veryverythickmathspace" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="open" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="close" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="separators" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="subscriptshift" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="superscriptshift" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="accentunder"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rowalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnwidth" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="groupalign" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="alignmentscope" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="side"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="left"/&gt;
 *             &lt;enumeration value="right"/&gt;
 *             &lt;enumeration value="leftoverlap"/&gt;
 *             &lt;enumeration value="rightoverlap"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="rowspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rowlines" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnlines" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="width" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="frame"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="none"/&gt;
 *             &lt;enumeration value="solid"/&gt;
 *             &lt;enumeration value="dashed"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="framespacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="minlabelspacing" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="equalrows" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="equalcolumns" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="displaystyle"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="rowspan" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="columnspan" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="edge"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="left"/&gt;
 *             &lt;enumeration value="right"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="selection" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="bevelled" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="height" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="depth" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mstyleType", propOrder = {
    "miOrMnOrMo"
})
public class MstyleType {

    @XmlElements({
        @XmlElement(name = "mi", type = MiType.class),
        @XmlElement(name = "mn", type = MnType.class),
        @XmlElement(name = "mo", type = MoType.class),
        @XmlElement(name = "mtext", type = MtextType.class),
        @XmlElement(name = "ms", type = MsType.class),
        @XmlElement(name = "mspace", type = MspaceType.class),
        @XmlElement(name = "mprescripts", type = MprescriptsType.class),
        @XmlElement(name = "none", type = NoneType.class),
        @XmlElement(name = "mrow", type = MrowType.class),
        @XmlElement(name = "mfrac", type = MfracType.class),
        @XmlElement(name = "msqrt", type = MsqrtType.class),
        @XmlElement(name = "mroot", type = MrootType.class),
        @XmlElement(name = "menclose", type = MencloseType.class),
        @XmlElement(name = "mstyle", type = MstyleType.class),
        @XmlElement(name = "merror", type = MerrorType.class),
        @XmlElement(name = "mpadded", type = MpaddedType.class),
        @XmlElement(name = "mphantom", type = MphantomType.class),
        @XmlElement(name = "mfenced", type = MfencedType.class),
        @XmlElement(name = "msub", type = MsubType.class),
        @XmlElement(name = "msup", type = MsupType.class),
        @XmlElement(name = "msubsup", type = MsubsupType.class),
        @XmlElement(name = "munder", type = MunderType.class),
        @XmlElement(name = "mover", type = MoverType.class),
        @XmlElement(name = "munderover", type = MunderoverType.class),
        @XmlElement(name = "mmultiscripts", type = MmultiscriptsType.class),
        @XmlElement(name = "mtable", type = MtableType.class),
        @XmlElement(name = "mtr", type = MtrType.class),
        @XmlElement(name = "mlabeledtr", type = MlabeledtrType.class),
        @XmlElement(name = "mtd", type = MtdType.class),
        @XmlElement(name = "maligngroup", type = MaligngroupType.class),
        @XmlElement(name = "malignmark", type = MalignmarkType.class),
        @XmlElement(name = "maction", type = MactionType.class),
        @XmlElement(name = "ci", type = CiType.class),
        @XmlElement(name = "csymbol", type = CsymbolType.class),
        @XmlElement(name = "cn", type = CnType.class),
        @XmlElement(name = "integers", type = IntegersType.class),
        @XmlElement(name = "reals", type = RealsType.class),
        @XmlElement(name = "rationals", type = RationalsType.class),
        @XmlElement(name = "naturalnumbers", type = NaturalnumbersType.class),
        @XmlElement(name = "complexes", type = ComplexesType.class),
        @XmlElement(name = "primes", type = PrimesType.class),
        @XmlElement(name = "exponentiale", type = ExponentialeType.class),
        @XmlElement(name = "imaginaryi", type = ImaginaryiType.class),
        @XmlElement(name = "notanumber", type = NotanumberType.class),
        @XmlElement(name = "true", type = TrueType.class),
        @XmlElement(name = "false", type = FalseType.class),
        @XmlElement(name = "emptyset", type = EmptysetType.class),
        @XmlElement(name = "pi", type = PiType.class),
        @XmlElement(name = "eulergamma", type = EulergammaType.class),
        @XmlElement(name = "infinity", type = InfinityType.class),
        @XmlElement(name = "apply", type = ApplyType.class),
        @XmlElement(name = "fn", type = FnType.class),
        @XmlElement(name = "lambda", type = LambdaType.class),
        @XmlElement(name = "reln", type = RelnType.class),
        @XmlElement(name = "interval", type = IntervalType.class),
        @XmlElement(name = "list", type = ListType.class),
        @XmlElement(name = "matrix", type = MatrixType.class),
        @XmlElement(name = "matrixrow", type = MatrixrowType.class),
        @XmlElement(name = "set", type = SetType.class),
        @XmlElement(name = "vector", type = VectorType.class),
        @XmlElement(name = "piecewise", type = PiecewiseType.class),
        @XmlElement(name = "semantics", type = SemanticsType.class),
        @XmlElement(name = "declare", type = DeclareType.class)
    })
    protected List<Object> miOrMnOrMo;
    @XmlAttribute(name = "class")
    protected String clazz;
    @XmlAttribute(name = "style")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    protected String other;
    @XmlAttribute(name = "fontsize")
    protected String fontsize;
    @XmlAttribute(name = "fontweight")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fontweight;
    @XmlAttribute(name = "fontstyle")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fontstyle;
    @XmlAttribute(name = "fontfamily")
    protected String fontfamily;
    @XmlAttribute(name = "color")
    protected String color;
    @XmlAttribute(name = "mathvariant")
    protected String mathvariant;
    @XmlAttribute(name = "mathsize")
    protected String mathsize;
    @XmlAttribute(name = "mathcolor")
    protected String mathcolor;
    @XmlAttribute(name = "mathbackground")
    protected String mathbackground;
    @XmlAttribute(name = "form")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String form;
    @XmlAttribute(name = "fence")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fence;
    @XmlAttribute(name = "separator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String separator;
    @XmlAttribute(name = "lspace")
    protected String lspace;
    @XmlAttribute(name = "rspace")
    protected String rspace;
    @XmlAttribute(name = "stretchy")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String stretchy;
    @XmlAttribute(name = "symmetric")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String symmetric;
    @XmlAttribute(name = "maxsize")
    protected String maxsize;
    @XmlAttribute(name = "minsize")
    protected String minsize;
    @XmlAttribute(name = "largeop")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String largeop;
    @XmlAttribute(name = "movablelimits")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String movablelimits;
    @XmlAttribute(name = "accent")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String accent;
    @XmlAttribute(name = "lquote")
    protected String lquote;
    @XmlAttribute(name = "rquote")
    protected String rquote;
    @XmlAttribute(name = "linethickness")
    protected String linethickness;
    @XmlAttribute(name = "scriptlevel")
    protected String scriptlevel;
    @XmlAttribute(name = "scriptsizemultiplier")
    protected String scriptsizemultiplier;
    @XmlAttribute(name = "scriptminsize")
    protected String scriptminsize;
    @XmlAttribute(name = "background")
    protected String background;
    @XmlAttribute(name = "veryverythinmathspace")
    protected String veryverythinmathspace;
    @XmlAttribute(name = "verythinmathspace")
    protected String verythinmathspace;
    @XmlAttribute(name = "thinmathspace")
    protected String thinmathspace;
    @XmlAttribute(name = "mediummathspace")
    protected String mediummathspace;
    @XmlAttribute(name = "thickmathspace")
    protected String thickmathspace;
    @XmlAttribute(name = "verythickmathspace")
    protected String verythickmathspace;
    @XmlAttribute(name = "veryverythickmathspace")
    protected String veryverythickmathspace;
    @XmlAttribute(name = "open")
    protected String open;
    @XmlAttribute(name = "close")
    protected String close;
    @XmlAttribute(name = "separators")
    protected String separators;
    @XmlAttribute(name = "subscriptshift")
    protected String subscriptshift;
    @XmlAttribute(name = "superscriptshift")
    protected String superscriptshift;
    @XmlAttribute(name = "accentunder")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String accentunder;
    @XmlAttribute(name = "align")
    protected String align;
    @XmlAttribute(name = "rowalign")
    protected String rowalign;
    @XmlAttribute(name = "columnalign")
    protected String columnalign;
    @XmlAttribute(name = "columnwidth")
    protected String columnwidth;
    @XmlAttribute(name = "groupalign")
    protected String groupalign;
    @XmlAttribute(name = "alignmentscope")
    protected String alignmentscope;
    @XmlAttribute(name = "side")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String side;
    @XmlAttribute(name = "rowspacing")
    protected String rowspacing;
    @XmlAttribute(name = "columnspacing")
    protected String columnspacing;
    @XmlAttribute(name = "rowlines")
    protected String rowlines;
    @XmlAttribute(name = "columnlines")
    protected String columnlines;
    @XmlAttribute(name = "width")
    protected String width;
    @XmlAttribute(name = "frame")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String frame;
    @XmlAttribute(name = "framespacing")
    protected String framespacing;
    @XmlAttribute(name = "minlabelspacing")
    protected String minlabelspacing;
    @XmlAttribute(name = "equalrows")
    protected String equalrows;
    @XmlAttribute(name = "equalcolumns")
    protected String equalcolumns;
    @XmlAttribute(name = "displaystyle")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String displaystyle;
    @XmlAttribute(name = "rowspan")
    protected String rowspan;
    @XmlAttribute(name = "columnspan")
    protected String columnspan;
    @XmlAttribute(name = "edge")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String edge;
    @XmlAttribute(name = "selection")
    protected String selection;
    @XmlAttribute(name = "bevelled")
    protected String bevelled;
    @XmlAttribute(name = "height")
    protected String height;
    @XmlAttribute(name = "depth")
    protected String depth;

    /**
     * Gets the value of the miOrMnOrMo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miOrMnOrMo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiOrMnOrMo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MiType }
     * {@link MnType }
     * {@link MoType }
     * {@link MtextType }
     * {@link MsType }
     * {@link MspaceType }
     * {@link MprescriptsType }
     * {@link NoneType }
     * {@link MrowType }
     * {@link MfracType }
     * {@link MsqrtType }
     * {@link MrootType }
     * {@link MencloseType }
     * {@link MstyleType }
     * {@link MerrorType }
     * {@link MpaddedType }
     * {@link MphantomType }
     * {@link MfencedType }
     * {@link MsubType }
     * {@link MsupType }
     * {@link MsubsupType }
     * {@link MunderType }
     * {@link MoverType }
     * {@link MunderoverType }
     * {@link MmultiscriptsType }
     * {@link MtableType }
     * {@link MtrType }
     * {@link MlabeledtrType }
     * {@link MtdType }
     * {@link MaligngroupType }
     * {@link MalignmarkType }
     * {@link MactionType }
     * {@link CiType }
     * {@link CsymbolType }
     * {@link CnType }
     * {@link IntegersType }
     * {@link RealsType }
     * {@link RationalsType }
     * {@link NaturalnumbersType }
     * {@link ComplexesType }
     * {@link PrimesType }
     * {@link ExponentialeType }
     * {@link ImaginaryiType }
     * {@link NotanumberType }
     * {@link TrueType }
     * {@link FalseType }
     * {@link EmptysetType }
     * {@link PiType }
     * {@link EulergammaType }
     * {@link InfinityType }
     * {@link ApplyType }
     * {@link FnType }
     * {@link LambdaType }
     * {@link RelnType }
     * {@link IntervalType }
     * {@link ListType }
     * {@link MatrixType }
     * {@link MatrixrowType }
     * {@link SetType }
     * {@link VectorType }
     * {@link PiecewiseType }
     * {@link SemanticsType }
     * {@link DeclareType }
     * 
     * 
     */
    public List<Object> getMiOrMnOrMo() {
        if (miOrMnOrMo == null) {
            miOrMnOrMo = new ArrayList<Object>();
        }
        return this.miOrMnOrMo;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 fontsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontsize() {
        return fontsize;
    }

    /**
     * 設定 fontsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontsize(String value) {
        this.fontsize = value;
    }

    /**
     * 取得 fontweight 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontweight() {
        return fontweight;
    }

    /**
     * 設定 fontweight 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontweight(String value) {
        this.fontweight = value;
    }

    /**
     * 取得 fontstyle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontstyle() {
        return fontstyle;
    }

    /**
     * 設定 fontstyle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontstyle(String value) {
        this.fontstyle = value;
    }

    /**
     * 取得 fontfamily 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontfamily() {
        return fontfamily;
    }

    /**
     * 設定 fontfamily 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontfamily(String value) {
        this.fontfamily = value;
    }

    /**
     * 取得 color 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColor() {
        return color;
    }

    /**
     * 設定 color 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColor(String value) {
        this.color = value;
    }

    /**
     * 取得 mathvariant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathvariant() {
        return mathvariant;
    }

    /**
     * 設定 mathvariant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathvariant(String value) {
        this.mathvariant = value;
    }

    /**
     * 取得 mathsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathsize() {
        return mathsize;
    }

    /**
     * 設定 mathsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathsize(String value) {
        this.mathsize = value;
    }

    /**
     * 取得 mathcolor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathcolor() {
        return mathcolor;
    }

    /**
     * 設定 mathcolor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathcolor(String value) {
        this.mathcolor = value;
    }

    /**
     * 取得 mathbackground 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathbackground() {
        return mathbackground;
    }

    /**
     * 設定 mathbackground 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathbackground(String value) {
        this.mathbackground = value;
    }

    /**
     * 取得 form 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForm() {
        return form;
    }

    /**
     * 設定 form 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForm(String value) {
        this.form = value;
    }

    /**
     * 取得 fence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFence() {
        return fence;
    }

    /**
     * 設定 fence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFence(String value) {
        this.fence = value;
    }

    /**
     * 取得 separator 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * 設定 separator 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeparator(String value) {
        this.separator = value;
    }

    /**
     * 取得 lspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLspace() {
        return lspace;
    }

    /**
     * 設定 lspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLspace(String value) {
        this.lspace = value;
    }

    /**
     * 取得 rspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRspace() {
        return rspace;
    }

    /**
     * 設定 rspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRspace(String value) {
        this.rspace = value;
    }

    /**
     * 取得 stretchy 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStretchy() {
        return stretchy;
    }

    /**
     * 設定 stretchy 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStretchy(String value) {
        this.stretchy = value;
    }

    /**
     * 取得 symmetric 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymmetric() {
        return symmetric;
    }

    /**
     * 設定 symmetric 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymmetric(String value) {
        this.symmetric = value;
    }

    /**
     * 取得 maxsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxsize() {
        return maxsize;
    }

    /**
     * 設定 maxsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxsize(String value) {
        this.maxsize = value;
    }

    /**
     * 取得 minsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinsize() {
        return minsize;
    }

    /**
     * 設定 minsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinsize(String value) {
        this.minsize = value;
    }

    /**
     * 取得 largeop 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLargeop() {
        return largeop;
    }

    /**
     * 設定 largeop 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLargeop(String value) {
        this.largeop = value;
    }

    /**
     * 取得 movablelimits 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovablelimits() {
        return movablelimits;
    }

    /**
     * 設定 movablelimits 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovablelimits(String value) {
        this.movablelimits = value;
    }

    /**
     * 取得 accent 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccent() {
        return accent;
    }

    /**
     * 設定 accent 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccent(String value) {
        this.accent = value;
    }

    /**
     * 取得 lquote 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLquote() {
        return lquote;
    }

    /**
     * 設定 lquote 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLquote(String value) {
        this.lquote = value;
    }

    /**
     * 取得 rquote 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRquote() {
        return rquote;
    }

    /**
     * 設定 rquote 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRquote(String value) {
        this.rquote = value;
    }

    /**
     * 取得 linethickness 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinethickness() {
        return linethickness;
    }

    /**
     * 設定 linethickness 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinethickness(String value) {
        this.linethickness = value;
    }

    /**
     * 取得 scriptlevel 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptlevel() {
        return scriptlevel;
    }

    /**
     * 設定 scriptlevel 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptlevel(String value) {
        this.scriptlevel = value;
    }

    /**
     * 取得 scriptsizemultiplier 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptsizemultiplier() {
        return scriptsizemultiplier;
    }

    /**
     * 設定 scriptsizemultiplier 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptsizemultiplier(String value) {
        this.scriptsizemultiplier = value;
    }

    /**
     * 取得 scriptminsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptminsize() {
        return scriptminsize;
    }

    /**
     * 設定 scriptminsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptminsize(String value) {
        this.scriptminsize = value;
    }

    /**
     * 取得 background 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackground() {
        return background;
    }

    /**
     * 設定 background 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackground(String value) {
        this.background = value;
    }

    /**
     * 取得 veryverythinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVeryverythinmathspace() {
        return veryverythinmathspace;
    }

    /**
     * 設定 veryverythinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVeryverythinmathspace(String value) {
        this.veryverythinmathspace = value;
    }

    /**
     * 取得 verythinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerythinmathspace() {
        return verythinmathspace;
    }

    /**
     * 設定 verythinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerythinmathspace(String value) {
        this.verythinmathspace = value;
    }

    /**
     * 取得 thinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThinmathspace() {
        return thinmathspace;
    }

    /**
     * 設定 thinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThinmathspace(String value) {
        this.thinmathspace = value;
    }

    /**
     * 取得 mediummathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMediummathspace() {
        return mediummathspace;
    }

    /**
     * 設定 mediummathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMediummathspace(String value) {
        this.mediummathspace = value;
    }

    /**
     * 取得 thickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThickmathspace() {
        return thickmathspace;
    }

    /**
     * 設定 thickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThickmathspace(String value) {
        this.thickmathspace = value;
    }

    /**
     * 取得 verythickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerythickmathspace() {
        return verythickmathspace;
    }

    /**
     * 設定 verythickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerythickmathspace(String value) {
        this.verythickmathspace = value;
    }

    /**
     * 取得 veryverythickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVeryverythickmathspace() {
        return veryverythickmathspace;
    }

    /**
     * 設定 veryverythickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVeryverythickmathspace(String value) {
        this.veryverythickmathspace = value;
    }

    /**
     * 取得 open 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpen() {
        return open;
    }

    /**
     * 設定 open 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpen(String value) {
        this.open = value;
    }

    /**
     * 取得 close 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClose() {
        return close;
    }

    /**
     * 設定 close 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClose(String value) {
        this.close = value;
    }

    /**
     * 取得 separators 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeparators() {
        return separators;
    }

    /**
     * 設定 separators 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeparators(String value) {
        this.separators = value;
    }

    /**
     * 取得 subscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptshift() {
        return subscriptshift;
    }

    /**
     * 設定 subscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptshift(String value) {
        this.subscriptshift = value;
    }

    /**
     * 取得 superscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperscriptshift() {
        return superscriptshift;
    }

    /**
     * 設定 superscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperscriptshift(String value) {
        this.superscriptshift = value;
    }

    /**
     * 取得 accentunder 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccentunder() {
        return accentunder;
    }

    /**
     * 設定 accentunder 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccentunder(String value) {
        this.accentunder = value;
    }

    /**
     * 取得 align 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlign() {
        return align;
    }

    /**
     * 設定 align 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlign(String value) {
        this.align = value;
    }

    /**
     * 取得 rowalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowalign() {
        return rowalign;
    }

    /**
     * 設定 rowalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowalign(String value) {
        this.rowalign = value;
    }

    /**
     * 取得 columnalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnalign() {
        return columnalign;
    }

    /**
     * 設定 columnalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnalign(String value) {
        this.columnalign = value;
    }

    /**
     * 取得 columnwidth 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnwidth() {
        return columnwidth;
    }

    /**
     * 設定 columnwidth 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnwidth(String value) {
        this.columnwidth = value;
    }

    /**
     * 取得 groupalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupalign() {
        return groupalign;
    }

    /**
     * 設定 groupalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupalign(String value) {
        this.groupalign = value;
    }

    /**
     * 取得 alignmentscope 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlignmentscope() {
        return alignmentscope;
    }

    /**
     * 設定 alignmentscope 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlignmentscope(String value) {
        this.alignmentscope = value;
    }

    /**
     * 取得 side 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSide() {
        return side;
    }

    /**
     * 設定 side 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSide(String value) {
        this.side = value;
    }

    /**
     * 取得 rowspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowspacing() {
        return rowspacing;
    }

    /**
     * 設定 rowspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowspacing(String value) {
        this.rowspacing = value;
    }

    /**
     * 取得 columnspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnspacing() {
        return columnspacing;
    }

    /**
     * 設定 columnspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnspacing(String value) {
        this.columnspacing = value;
    }

    /**
     * 取得 rowlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowlines() {
        return rowlines;
    }

    /**
     * 設定 rowlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowlines(String value) {
        this.rowlines = value;
    }

    /**
     * 取得 columnlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnlines() {
        return columnlines;
    }

    /**
     * 設定 columnlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnlines(String value) {
        this.columnlines = value;
    }

    /**
     * 取得 width 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWidth() {
        return width;
    }

    /**
     * 設定 width 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWidth(String value) {
        this.width = value;
    }

    /**
     * 取得 frame 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrame() {
        return frame;
    }

    /**
     * 設定 frame 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrame(String value) {
        this.frame = value;
    }

    /**
     * 取得 framespacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFramespacing() {
        return framespacing;
    }

    /**
     * 設定 framespacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFramespacing(String value) {
        this.framespacing = value;
    }

    /**
     * 取得 minlabelspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinlabelspacing() {
        return minlabelspacing;
    }

    /**
     * 設定 minlabelspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinlabelspacing(String value) {
        this.minlabelspacing = value;
    }

    /**
     * 取得 equalrows 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualrows() {
        return equalrows;
    }

    /**
     * 設定 equalrows 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualrows(String value) {
        this.equalrows = value;
    }

    /**
     * 取得 equalcolumns 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualcolumns() {
        return equalcolumns;
    }

    /**
     * 設定 equalcolumns 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualcolumns(String value) {
        this.equalcolumns = value;
    }

    /**
     * 取得 displaystyle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplaystyle() {
        return displaystyle;
    }

    /**
     * 設定 displaystyle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplaystyle(String value) {
        this.displaystyle = value;
    }

    /**
     * 取得 rowspan 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowspan() {
        return rowspan;
    }

    /**
     * 設定 rowspan 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowspan(String value) {
        this.rowspan = value;
    }

    /**
     * 取得 columnspan 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnspan() {
        return columnspan;
    }

    /**
     * 設定 columnspan 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnspan(String value) {
        this.columnspan = value;
    }

    /**
     * 取得 edge 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEdge() {
        return edge;
    }

    /**
     * 設定 edge 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEdge(String value) {
        this.edge = value;
    }

    /**
     * 取得 selection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelection() {
        return selection;
    }

    /**
     * 設定 selection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelection(String value) {
        this.selection = value;
    }

    /**
     * 取得 bevelled 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBevelled() {
        return bevelled;
    }

    /**
     * 設定 bevelled 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBevelled(String value) {
        this.bevelled = value;
    }

    /**
     * 取得 height 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeight() {
        return height;
    }

    /**
     * 設定 height 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeight(String value) {
        this.height = value;
    }

    /**
     * 取得 depth 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepth() {
        return depth;
    }

    /**
     * 設定 depth 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepth(String value) {
        this.depth = value;
    }

}
