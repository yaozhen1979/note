//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>bookType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="bookType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="author" type="{http://www.epo.org/exchange}authorType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;choice&gt;
 *             &lt;element name="book-title" type="{http://www.epo.org/exchange}book-titleType" maxOccurs="unbounded"/&gt;
 *             &lt;element name="conference" type="{http://www.epo.org/exchange}conferenceType"/&gt;
 *           &lt;/choice&gt;
 *           &lt;sequence&gt;
 *             &lt;element name="subtitle" type="{http://www.epo.org/exchange}subtitleType" minOccurs="0"/&gt;
 *             &lt;element name="subname" type="{http://www.epo.org/exchange}subnameType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="edition" type="{http://www.epo.org/exchange}editionType" minOccurs="0"/&gt;
 *             &lt;element name="imprint" type="{http://www.epo.org/exchange}imprintType" minOccurs="0"/&gt;
 *             &lt;element name="vid" type="{http://www.epo.org/exchange}vidType" minOccurs="0"/&gt;
 *             &lt;element name="ino" type="{http://www.epo.org/exchange}inoType" minOccurs="0"/&gt;
 *             &lt;element name="descrip" type="{http://www.epo.org/exchange}descripType" minOccurs="0"/&gt;
 *             &lt;element name="series" type="{http://www.epo.org/exchange}seriesType" minOccurs="0"/&gt;
 *             &lt;element name="notes" type="{http://www.epo.org/exchange}notesType" minOccurs="0"/&gt;
 *             &lt;element name="absno" type="{http://www.epo.org/exchange}absnoType" minOccurs="0"/&gt;
 *             &lt;element name="location" type="{http://www.epo.org/exchange}locationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="pubid" type="{http://www.epo.org/exchange}pubidType" minOccurs="0"/&gt;
 *             &lt;element name="bookno" type="{http://www.epo.org/exchange}booknoType" minOccurs="0"/&gt;
 *             &lt;element name="class" type="{http://www.epo.org/exchange}classType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="keyword" type="{http://www.epo.org/exchange}keywordType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="cpyrt" type="{http://www.epo.org/exchange}cpyrtType" minOccurs="0"/&gt;
 *             &lt;element name="doi" type="{http://www.epo.org/exchange}doiType" minOccurs="0"/&gt;
 *             &lt;element name="issn" type="{http://www.epo.org/exchange}issnType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="isbn" type="{http://www.epo.org/exchange}isbnType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element name="refno" type="{http://www.epo.org/exchange}refnoType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;/sequence&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bookType", propOrder = {
    "text",
    "author",
    "bookTitle",
    "conference",
    "subtitle",
    "subname",
    "edition",
    "imprint",
    "vid",
    "ino",
    "descrip",
    "series",
    "notes",
    "absno",
    "location",
    "pubid",
    "bookno",
    "clazz",
    "keyword",
    "cpyrt",
    "doi",
    "issn",
    "isbn",
    "refno"
})
public class BookType {

    protected TextType text;
    protected List<AuthorType> author;
    @XmlElement(name = "book-title")
    protected List<BookTitleType> bookTitle;
    protected ConferenceType conference;
    protected SubtitleType subtitle;
    protected List<SubnameType> subname;
    protected EditionType edition;
    protected ImprintType imprint;
    protected VidType vid;
    protected InoType ino;
    protected DescripType descrip;
    protected SeriesType series;
    protected NotesType notes;
    protected AbsnoType absno;
    protected List<LocationType> location;
    protected PubidType pubid;
    protected BooknoType bookno;
    @XmlElement(name = "class")
    protected List<ClassType> clazz;
    protected List<KeywordType> keyword;
    protected CpyrtType cpyrt;
    protected DoiType doi;
    protected List<IssnType> issn;
    protected List<IsbnType> isbn;
    protected List<RefnoType> refno;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the author property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AuthorType }
     * 
     * 
     */
    public List<AuthorType> getAuthor() {
        if (author == null) {
            author = new ArrayList<AuthorType>();
        }
        return this.author;
    }

    /**
     * Gets the value of the bookTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bookTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBookTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BookTitleType }
     * 
     * 
     */
    public List<BookTitleType> getBookTitle() {
        if (bookTitle == null) {
            bookTitle = new ArrayList<BookTitleType>();
        }
        return this.bookTitle;
    }

    /**
     * 取得 conference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ConferenceType }
     *     
     */
    public ConferenceType getConference() {
        return conference;
    }

    /**
     * 設定 conference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ConferenceType }
     *     
     */
    public void setConference(ConferenceType value) {
        this.conference = value;
    }

    /**
     * 取得 subtitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SubtitleType }
     *     
     */
    public SubtitleType getSubtitle() {
        return subtitle;
    }

    /**
     * 設定 subtitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SubtitleType }
     *     
     */
    public void setSubtitle(SubtitleType value) {
        this.subtitle = value;
    }

    /**
     * Gets the value of the subname property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subname property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubname().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubnameType }
     * 
     * 
     */
    public List<SubnameType> getSubname() {
        if (subname == null) {
            subname = new ArrayList<SubnameType>();
        }
        return this.subname;
    }

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EditionType }
     *     
     */
    public EditionType getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EditionType }
     *     
     */
    public void setEdition(EditionType value) {
        this.edition = value;
    }

    /**
     * 取得 imprint 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ImprintType }
     *     
     */
    public ImprintType getImprint() {
        return imprint;
    }

    /**
     * 設定 imprint 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ImprintType }
     *     
     */
    public void setImprint(ImprintType value) {
        this.imprint = value;
    }

    /**
     * 取得 vid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link VidType }
     *     
     */
    public VidType getVid() {
        return vid;
    }

    /**
     * 設定 vid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link VidType }
     *     
     */
    public void setVid(VidType value) {
        this.vid = value;
    }

    /**
     * 取得 ino 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InoType }
     *     
     */
    public InoType getIno() {
        return ino;
    }

    /**
     * 設定 ino 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InoType }
     *     
     */
    public void setIno(InoType value) {
        this.ino = value;
    }

    /**
     * 取得 descrip 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DescripType }
     *     
     */
    public DescripType getDescrip() {
        return descrip;
    }

    /**
     * 設定 descrip 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DescripType }
     *     
     */
    public void setDescrip(DescripType value) {
        this.descrip = value;
    }

    /**
     * 取得 series 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SeriesType }
     *     
     */
    public SeriesType getSeries() {
        return series;
    }

    /**
     * 設定 series 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SeriesType }
     *     
     */
    public void setSeries(SeriesType value) {
        this.series = value;
    }

    /**
     * 取得 notes 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NotesType }
     *     
     */
    public NotesType getNotes() {
        return notes;
    }

    /**
     * 設定 notes 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NotesType }
     *     
     */
    public void setNotes(NotesType value) {
        this.notes = value;
    }

    /**
     * 取得 absno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbsnoType }
     *     
     */
    public AbsnoType getAbsno() {
        return absno;
    }

    /**
     * 設定 absno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbsnoType }
     *     
     */
    public void setAbsno(AbsnoType value) {
        this.absno = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the location property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocationType }
     * 
     * 
     */
    public List<LocationType> getLocation() {
        if (location == null) {
            location = new ArrayList<LocationType>();
        }
        return this.location;
    }

    /**
     * 取得 pubid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PubidType }
     *     
     */
    public PubidType getPubid() {
        return pubid;
    }

    /**
     * 設定 pubid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PubidType }
     *     
     */
    public void setPubid(PubidType value) {
        this.pubid = value;
    }

    /**
     * 取得 bookno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BooknoType }
     *     
     */
    public BooknoType getBookno() {
        return bookno;
    }

    /**
     * 設定 bookno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BooknoType }
     *     
     */
    public void setBookno(BooknoType value) {
        this.bookno = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clazz property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClazz().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClassType }
     * 
     * 
     */
    public List<ClassType> getClazz() {
        if (clazz == null) {
            clazz = new ArrayList<ClassType>();
        }
        return this.clazz;
    }

    /**
     * Gets the value of the keyword property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyword property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyword().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeywordType }
     * 
     * 
     */
    public List<KeywordType> getKeyword() {
        if (keyword == null) {
            keyword = new ArrayList<KeywordType>();
        }
        return this.keyword;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CpyrtType }
     *     
     */
    public CpyrtType getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CpyrtType }
     *     
     */
    public void setCpyrt(CpyrtType value) {
        this.cpyrt = value;
    }

    /**
     * 取得 doi 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DoiType }
     *     
     */
    public DoiType getDoi() {
        return doi;
    }

    /**
     * 設定 doi 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DoiType }
     *     
     */
    public void setDoi(DoiType value) {
        this.doi = value;
    }

    /**
     * Gets the value of the issn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the issn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIssn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IssnType }
     * 
     * 
     */
    public List<IssnType> getIssn() {
        if (issn == null) {
            issn = new ArrayList<IssnType>();
        }
        return this.issn;
    }

    /**
     * Gets the value of the isbn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the isbn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIsbn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IsbnType }
     * 
     * 
     */
    public List<IsbnType> getIsbn() {
        if (isbn == null) {
            isbn = new ArrayList<IsbnType>();
        }
        return this.isbn;
    }

    /**
     * Gets the value of the refno property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refno property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefno().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RefnoType }
     * 
     * 
     */
    public List<RefnoType> getRefno() {
        if (refno == null) {
            refno = new ArrayList<RefnoType>();
        }
        return this.refno;
    }

}
