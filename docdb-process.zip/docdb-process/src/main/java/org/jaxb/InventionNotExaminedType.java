//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>invention-not-examinedType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="invention-not-examinedType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="entire-application" type="{http://www.epo.org/exchange}entire-applicationType"/&gt;
 *           &lt;element name="claim-num" type="{http://www.epo.org/exchange}claim-numType" maxOccurs="unbounded"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="non-estab-reason-1" type="{http://www.epo.org/exchange}non-estab-reason-1Type" minOccurs="0"/&gt;
 *         &lt;element name="non-estab-reason-2" type="{http://www.epo.org/exchange}non-estab-reason-2Type" minOccurs="0"/&gt;
 *         &lt;element name="non-estab-reason-3" type="{http://www.epo.org/exchange}non-estab-reason-3Type" minOccurs="0"/&gt;
 *         &lt;element name="non-estab-reason-4" type="{http://www.epo.org/exchange}non-estab-reason-4Type" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "invention-not-examinedType", propOrder = {
    "entireApplication",
    "claimNum",
    "nonEstabReason1",
    "nonEstabReason2",
    "nonEstabReason3",
    "nonEstabReason4"
})
public class InventionNotExaminedType {

    @XmlElement(name = "entire-application")
    protected EntireApplicationType entireApplication;
    @XmlElement(name = "claim-num")
    protected List<ClaimNumType> claimNum;
    @XmlElement(name = "non-estab-reason-1")
    protected NonEstabReason1Type nonEstabReason1;
    @XmlElement(name = "non-estab-reason-2")
    protected NonEstabReason2Type nonEstabReason2;
    @XmlElement(name = "non-estab-reason-3")
    protected NonEstabReason3Type nonEstabReason3;
    @XmlElement(name = "non-estab-reason-4")
    protected NonEstabReason4Type nonEstabReason4;

    /**
     * 取得 entireApplication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EntireApplicationType }
     *     
     */
    public EntireApplicationType getEntireApplication() {
        return entireApplication;
    }

    /**
     * 設定 entireApplication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EntireApplicationType }
     *     
     */
    public void setEntireApplication(EntireApplicationType value) {
        this.entireApplication = value;
    }

    /**
     * Gets the value of the claimNum property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimNum property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClaimNum().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimNumType }
     * 
     * 
     */
    public List<ClaimNumType> getClaimNum() {
        if (claimNum == null) {
            claimNum = new ArrayList<ClaimNumType>();
        }
        return this.claimNum;
    }

    /**
     * 取得 nonEstabReason1 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NonEstabReason1Type }
     *     
     */
    public NonEstabReason1Type getNonEstabReason1() {
        return nonEstabReason1;
    }

    /**
     * 設定 nonEstabReason1 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NonEstabReason1Type }
     *     
     */
    public void setNonEstabReason1(NonEstabReason1Type value) {
        this.nonEstabReason1 = value;
    }

    /**
     * 取得 nonEstabReason2 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NonEstabReason2Type }
     *     
     */
    public NonEstabReason2Type getNonEstabReason2() {
        return nonEstabReason2;
    }

    /**
     * 設定 nonEstabReason2 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NonEstabReason2Type }
     *     
     */
    public void setNonEstabReason2(NonEstabReason2Type value) {
        this.nonEstabReason2 = value;
    }

    /**
     * 取得 nonEstabReason3 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NonEstabReason3Type }
     *     
     */
    public NonEstabReason3Type getNonEstabReason3() {
        return nonEstabReason3;
    }

    /**
     * 設定 nonEstabReason3 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NonEstabReason3Type }
     *     
     */
    public void setNonEstabReason3(NonEstabReason3Type value) {
        this.nonEstabReason3 = value;
    }

    /**
     * 取得 nonEstabReason4 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NonEstabReason4Type }
     *     
     */
    public NonEstabReason4Type getNonEstabReason4() {
        return nonEstabReason4;
    }

    /**
     * 設定 nonEstabReason4 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NonEstabReason4Type }
     *     
     */
    public void setNonEstabReason4(NonEstabReason4Type value) {
        this.nonEstabReason4 = value;
    }

}
