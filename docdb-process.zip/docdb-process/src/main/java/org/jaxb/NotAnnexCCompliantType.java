//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>not-annex-c-compliantType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="not-annex-c-compliantType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="annex-c" type="{http://www.epo.org/exchange}annex-cType" minOccurs="0"/&gt;
 *         &lt;element name="annex-c-bis" type="{http://www.epo.org/exchange}annex-c-bisType" minOccurs="0"/&gt;
 *         &lt;element name="additional-info" type="{http://www.epo.org/exchange}additional-infoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "not-annex-c-compliantType", propOrder = {
    "annexC",
    "annexCBis",
    "additionalInfo"
})
public class NotAnnexCCompliantType {

    @XmlElement(name = "annex-c")
    protected AnnexCType annexC;
    @XmlElement(name = "annex-c-bis")
    protected AnnexCBisType annexCBis;
    @XmlElement(name = "additional-info")
    protected AdditionalInfoType additionalInfo;

    /**
     * 取得 annexC 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AnnexCType }
     *     
     */
    public AnnexCType getAnnexC() {
        return annexC;
    }

    /**
     * 設定 annexC 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AnnexCType }
     *     
     */
    public void setAnnexC(AnnexCType value) {
        this.annexC = value;
    }

    /**
     * 取得 annexCBis 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AnnexCBisType }
     *     
     */
    public AnnexCBisType getAnnexCBis() {
        return annexCBis;
    }

    /**
     * 設定 annexCBis 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AnnexCBisType }
     *     
     */
    public void setAnnexCBis(AnnexCBisType value) {
        this.annexCBis = value;
    }

    /**
     * 取得 additionalInfo 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoType }
     *     
     */
    public AdditionalInfoType getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * 設定 additionalInfo 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoType }
     *     
     */
    public void setAdditionalInfo(AdditionalInfoType value) {
        this.additionalInfo = value;
    }

}
