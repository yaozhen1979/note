//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>electronic-signatureType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="electronic-signatureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="basic-signature" type="{http://www.epo.org/exchange}basic-signatureType"/&gt;
 *         &lt;element name="enhanced-signature" type="{http://www.epo.org/exchange}enhanced-signatureType"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="date" use="required" type="{http://www.epo.org/exchange}ICE-date-type" /&gt;
 *       &lt;attribute name="place-signed" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "electronic-signatureType", propOrder = {
    "basicSignature",
    "enhancedSignature"
})
public class ElectronicSignatureType {

    @XmlElement(name = "basic-signature")
    protected BasicSignatureType basicSignature;
    @XmlElement(name = "enhanced-signature")
    protected EnhancedSignatureType enhancedSignature;
    @XmlAttribute(name = "date", required = true)
    protected BigInteger date;
    @XmlAttribute(name = "place-signed")
    protected String placeSigned;

    /**
     * 取得 basicSignature 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BasicSignatureType }
     *     
     */
    public BasicSignatureType getBasicSignature() {
        return basicSignature;
    }

    /**
     * 設定 basicSignature 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BasicSignatureType }
     *     
     */
    public void setBasicSignature(BasicSignatureType value) {
        this.basicSignature = value;
    }

    /**
     * 取得 enhancedSignature 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EnhancedSignatureType }
     *     
     */
    public EnhancedSignatureType getEnhancedSignature() {
        return enhancedSignature;
    }

    /**
     * 設定 enhancedSignature 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EnhancedSignatureType }
     *     
     */
    public void setEnhancedSignature(EnhancedSignatureType value) {
        this.enhancedSignature = value;
    }

    /**
     * 取得 date 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDate() {
        return date;
    }

    /**
     * 設定 date 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDate(BigInteger value) {
        this.date = value;
    }

    /**
     * 取得 placeSigned 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceSigned() {
        return placeSigned;
    }

    /**
     * 設定 placeSigned 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceSigned(String value) {
        this.placeSigned = value;
    }

}
