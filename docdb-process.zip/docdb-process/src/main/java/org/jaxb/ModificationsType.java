//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>modificationsType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="modificationsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="modified-bibliography" type="{http://www.epo.org/exchange}modified-bibliographyType" minOccurs="0"/&gt;
 *         &lt;element name="modified-part" type="{http://www.epo.org/exchange}modified-partType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "modificationsType", propOrder = {
    "modifiedBibliography",
    "modifiedPart"
})
public class ModificationsType {

    @XmlElement(name = "modified-bibliography")
    protected ModifiedBibliographyType modifiedBibliography;
    @XmlElement(name = "modified-part")
    protected List<ModifiedPartType> modifiedPart;

    /**
     * 取得 modifiedBibliography 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ModifiedBibliographyType }
     *     
     */
    public ModifiedBibliographyType getModifiedBibliography() {
        return modifiedBibliography;
    }

    /**
     * 設定 modifiedBibliography 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ModifiedBibliographyType }
     *     
     */
    public void setModifiedBibliography(ModifiedBibliographyType value) {
        this.modifiedBibliography = value;
    }

    /**
     * Gets the value of the modifiedPart property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modifiedPart property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModifiedPart().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModifiedPartType }
     * 
     * 
     */
    public List<ModifiedPartType> getModifiedPart() {
        if (modifiedPart == null) {
            modifiedPart = new ArrayList<ModifiedPartType>();
        }
        return this.modifiedPart;
    }

}
