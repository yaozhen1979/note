//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>certain-published-documentsType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="certain-published-documentsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{http://www.epo.org/exchange}citation" maxOccurs="unbounded"/&gt;
 *           &lt;element name="filing-date" type="{http://www.epo.org/exchange}filing-dateType"/&gt;
 *           &lt;element name="priority-date" type="{http://www.epo.org/exchange}priority-dateType" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "certain-published-documentsType", propOrder = {
    "citation",
    "filingDate",
    "priorityDate",
    "text"
})
public class CertainPublishedDocumentsType {

    @XmlElement(namespace = "http://www.epo.org/exchange")
    protected List<CitationType> citation;
    @XmlElement(name = "filing-date")
    protected FilingDateType filingDate;
    @XmlElement(name = "priority-date")
    protected PriorityDateType priorityDate;
    protected TextType text;

    /**
     * Gets the value of the citation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the citation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCitation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CitationType }
     * 
     * 
     */
    public List<CitationType> getCitation() {
        if (citation == null) {
            citation = new ArrayList<CitationType>();
        }
        return this.citation;
    }

    /**
     * 取得 filingDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FilingDateType }
     *     
     */
    public FilingDateType getFilingDate() {
        return filingDate;
    }

    /**
     * 設定 filingDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FilingDateType }
     *     
     */
    public void setFilingDate(FilingDateType value) {
        this.filingDate = value;
    }

    /**
     * 取得 priorityDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PriorityDateType }
     *     
     */
    public PriorityDateType getPriorityDate() {
        return priorityDate;
    }

    /**
     * 設定 priorityDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityDateType }
     *     
     */
    public void setPriorityDate(PriorityDateType value) {
        this.priorityDate = value;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

}
