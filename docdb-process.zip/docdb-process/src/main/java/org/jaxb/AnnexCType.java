//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>annex-cType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="annex-cType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="sequence-listing-written-form" type="{http://www.epo.org/exchange}sequence-listing-written-formType" minOccurs="0"/&gt;
 *         &lt;element name="sequence-listing-computer-readable-form" type="{http://www.epo.org/exchange}sequence-listing-computer-readable-formType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "annex-cType", propOrder = {
    "sequenceListingWrittenForm",
    "sequenceListingComputerReadableForm"
})
public class AnnexCType {

    @XmlElement(name = "sequence-listing-written-form")
    protected SequenceListingWrittenFormType sequenceListingWrittenForm;
    @XmlElement(name = "sequence-listing-computer-readable-form")
    protected SequenceListingComputerReadableFormType sequenceListingComputerReadableForm;

    /**
     * 取得 sequenceListingWrittenForm 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListingWrittenFormType }
     *     
     */
    public SequenceListingWrittenFormType getSequenceListingWrittenForm() {
        return sequenceListingWrittenForm;
    }

    /**
     * 設定 sequenceListingWrittenForm 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListingWrittenFormType }
     *     
     */
    public void setSequenceListingWrittenForm(SequenceListingWrittenFormType value) {
        this.sequenceListingWrittenForm = value;
    }

    /**
     * 取得 sequenceListingComputerReadableForm 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListingComputerReadableFormType }
     *     
     */
    public SequenceListingComputerReadableFormType getSequenceListingComputerReadableForm() {
        return sequenceListingComputerReadableForm;
    }

    /**
     * 設定 sequenceListingComputerReadableForm 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListingComputerReadableFormType }
     *     
     */
    public void setSequenceListingComputerReadableForm(SequenceListingComputerReadableFormType value) {
        this.sequenceListingComputerReadableForm = value;
    }

}
