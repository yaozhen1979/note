//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>corresponding-docsType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="corresponding-docsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element name="document-id" type="{http://www.epo.org/exchange}document-idType"/&gt;
 *           &lt;element name="refno" type="{http://www.epo.org/exchange}refnoType"/&gt;
 *           &lt;element name="patcit" type="{http://www.epo.org/exchange}patcitType"/&gt;
 *           &lt;element name="nplcit" type="{http://www.epo.org/exchange}nplcitType"/&gt;
 *         &lt;/choice&gt;
 *         &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element name="rel-passage" type="{http://www.epo.org/exchange}rel-passageType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="category" type="{http://www.epo.org/exchange}categoryType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;element name="rel-claims" type="{http://www.epo.org/exchange}rel-claimsType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "corresponding-docsType", propOrder = {
    "documentIdOrRefnoOrPatcit",
    "relPassageAndCategoryAndRelClaims"
})
public class CorrespondingDocsType {

    @XmlElements({
        @XmlElement(name = "document-id", type = DocumentIdType.class),
        @XmlElement(name = "refno", type = RefnoType.class),
        @XmlElement(name = "patcit", type = PatcitType.class),
        @XmlElement(name = "nplcit", type = NplcitType.class)
    })
    protected List<Object> documentIdOrRefnoOrPatcit;
    @XmlElements({
        @XmlElement(name = "rel-passage", type = RelPassageType.class),
        @XmlElement(name = "category", type = CategoryType.class),
        @XmlElement(name = "rel-claims", type = RelClaimsType.class)
    })
    protected List<Object> relPassageAndCategoryAndRelClaims;

    /**
     * Gets the value of the documentIdOrRefnoOrPatcit property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentIdOrRefnoOrPatcit property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentIdOrRefnoOrPatcit().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentIdType }
     * {@link RefnoType }
     * {@link PatcitType }
     * {@link NplcitType }
     * 
     * 
     */
    public List<Object> getDocumentIdOrRefnoOrPatcit() {
        if (documentIdOrRefnoOrPatcit == null) {
            documentIdOrRefnoOrPatcit = new ArrayList<Object>();
        }
        return this.documentIdOrRefnoOrPatcit;
    }

    /**
     * Gets the value of the relPassageAndCategoryAndRelClaims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relPassageAndCategoryAndRelClaims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelPassageAndCategoryAndRelClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelPassageType }
     * {@link CategoryType }
     * {@link RelClaimsType }
     * 
     * 
     */
    public List<Object> getRelPassageAndCategoryAndRelClaims() {
        if (relPassageAndCategoryAndRelClaims == null) {
            relPassageAndCategoryAndRelClaims = new ArrayList<Object>();
        }
        return this.relPassageAndCategoryAndRelClaims;
    }

}
