//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>msubsupType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="msubsupType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;group ref="{http://www.epo.org/exchange}threePresExpression"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="subscriptshift" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="superscriptshift" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "msubsupType", propOrder = {
    "miOrMnOrMo"
})
public class MsubsupType {

    @XmlElements({
        @XmlElement(name = "mi", type = MiType.class),
        @XmlElement(name = "mn", type = MnType.class),
        @XmlElement(name = "mo", type = MoType.class),
        @XmlElement(name = "mtext", type = MtextType.class),
        @XmlElement(name = "ms", type = MsType.class),
        @XmlElement(name = "mspace", type = MspaceType.class),
        @XmlElement(name = "mprescripts", type = MprescriptsType.class),
        @XmlElement(name = "none", type = NoneType.class),
        @XmlElement(name = "mrow", type = MrowType.class),
        @XmlElement(name = "mfrac", type = MfracType.class),
        @XmlElement(name = "msqrt", type = MsqrtType.class),
        @XmlElement(name = "mroot", type = MrootType.class),
        @XmlElement(name = "menclose", type = MencloseType.class),
        @XmlElement(name = "mstyle", type = MstyleType.class),
        @XmlElement(name = "merror", type = MerrorType.class),
        @XmlElement(name = "mpadded", type = MpaddedType.class),
        @XmlElement(name = "mphantom", type = MphantomType.class),
        @XmlElement(name = "mfenced", type = MfencedType.class),
        @XmlElement(name = "msub", type = MsubType.class),
        @XmlElement(name = "msup", type = MsupType.class),
        @XmlElement(name = "msubsup", type = MsubsupType.class),
        @XmlElement(name = "munder", type = MunderType.class),
        @XmlElement(name = "mover", type = MoverType.class),
        @XmlElement(name = "munderover", type = MunderoverType.class),
        @XmlElement(name = "mmultiscripts", type = MmultiscriptsType.class),
        @XmlElement(name = "mtable", type = MtableType.class),
        @XmlElement(name = "mtr", type = MtrType.class),
        @XmlElement(name = "mlabeledtr", type = MlabeledtrType.class),
        @XmlElement(name = "mtd", type = MtdType.class),
        @XmlElement(name = "maligngroup", type = MaligngroupType.class),
        @XmlElement(name = "malignmark", type = MalignmarkType.class),
        @XmlElement(name = "maction", type = MactionType.class),
        @XmlElement(name = "ci", type = CiType.class),
        @XmlElement(name = "csymbol", type = CsymbolType.class),
        @XmlElement(name = "cn", type = CnType.class),
        @XmlElement(name = "integers", type = IntegersType.class),
        @XmlElement(name = "reals", type = RealsType.class),
        @XmlElement(name = "rationals", type = RationalsType.class),
        @XmlElement(name = "naturalnumbers", type = NaturalnumbersType.class),
        @XmlElement(name = "complexes", type = ComplexesType.class),
        @XmlElement(name = "primes", type = PrimesType.class),
        @XmlElement(name = "exponentiale", type = ExponentialeType.class),
        @XmlElement(name = "imaginaryi", type = ImaginaryiType.class),
        @XmlElement(name = "notanumber", type = NotanumberType.class),
        @XmlElement(name = "true", type = TrueType.class),
        @XmlElement(name = "false", type = FalseType.class),
        @XmlElement(name = "emptyset", type = EmptysetType.class),
        @XmlElement(name = "pi", type = PiType.class),
        @XmlElement(name = "eulergamma", type = EulergammaType.class),
        @XmlElement(name = "infinity", type = InfinityType.class),
        @XmlElement(name = "apply", type = ApplyType.class),
        @XmlElement(name = "fn", type = FnType.class),
        @XmlElement(name = "lambda", type = LambdaType.class),
        @XmlElement(name = "reln", type = RelnType.class),
        @XmlElement(name = "interval", type = IntervalType.class),
        @XmlElement(name = "list", type = ListType.class),
        @XmlElement(name = "matrix", type = MatrixType.class),
        @XmlElement(name = "matrixrow", type = MatrixrowType.class),
        @XmlElement(name = "set", type = SetType.class),
        @XmlElement(name = "vector", type = VectorType.class),
        @XmlElement(name = "piecewise", type = PiecewiseType.class),
        @XmlElement(name = "semantics", type = SemanticsType.class),
        @XmlElement(name = "declare", type = DeclareType.class)
    })
    protected List<Object> miOrMnOrMo;
    @XmlAttribute(name = "class")
    protected String clazz;
    @XmlAttribute(name = "style")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    protected String other;
    @XmlAttribute(name = "subscriptshift")
    protected String subscriptshift;
    @XmlAttribute(name = "superscriptshift")
    protected String superscriptshift;

    /**
     * Gets the value of the miOrMnOrMo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miOrMnOrMo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiOrMnOrMo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MiType }
     * {@link MnType }
     * {@link MoType }
     * {@link MtextType }
     * {@link MsType }
     * {@link MspaceType }
     * {@link MprescriptsType }
     * {@link NoneType }
     * {@link MrowType }
     * {@link MfracType }
     * {@link MsqrtType }
     * {@link MrootType }
     * {@link MencloseType }
     * {@link MstyleType }
     * {@link MerrorType }
     * {@link MpaddedType }
     * {@link MphantomType }
     * {@link MfencedType }
     * {@link MsubType }
     * {@link MsupType }
     * {@link MsubsupType }
     * {@link MunderType }
     * {@link MoverType }
     * {@link MunderoverType }
     * {@link MmultiscriptsType }
     * {@link MtableType }
     * {@link MtrType }
     * {@link MlabeledtrType }
     * {@link MtdType }
     * {@link MaligngroupType }
     * {@link MalignmarkType }
     * {@link MactionType }
     * {@link CiType }
     * {@link CsymbolType }
     * {@link CnType }
     * {@link IntegersType }
     * {@link RealsType }
     * {@link RationalsType }
     * {@link NaturalnumbersType }
     * {@link ComplexesType }
     * {@link PrimesType }
     * {@link ExponentialeType }
     * {@link ImaginaryiType }
     * {@link NotanumberType }
     * {@link TrueType }
     * {@link FalseType }
     * {@link EmptysetType }
     * {@link PiType }
     * {@link EulergammaType }
     * {@link InfinityType }
     * {@link ApplyType }
     * {@link FnType }
     * {@link LambdaType }
     * {@link RelnType }
     * {@link IntervalType }
     * {@link ListType }
     * {@link MatrixType }
     * {@link MatrixrowType }
     * {@link SetType }
     * {@link VectorType }
     * {@link PiecewiseType }
     * {@link SemanticsType }
     * {@link DeclareType }
     * 
     * 
     */
    public List<Object> getMiOrMnOrMo() {
        if (miOrMnOrMo == null) {
            miOrMnOrMo = new ArrayList<Object>();
        }
        return this.miOrMnOrMo;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 subscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptshift() {
        return subscriptshift;
    }

    /**
     * 設定 subscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptshift(String value) {
        this.subscriptshift = value;
    }

    /**
     * 取得 superscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperscriptshift() {
        return superscriptshift;
    }

    /**
     * 設定 superscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperscriptshift(String value) {
        this.superscriptshift = value;
    }

}
