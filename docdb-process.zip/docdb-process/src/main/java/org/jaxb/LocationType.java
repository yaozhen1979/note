//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>locationType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="locationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="serpart" type="{http://www.epo.org/exchange}serpartType" minOccurs="0"/&gt;
 *           &lt;element name="sersect" type="{http://www.epo.org/exchange}sersectType" minOccurs="0"/&gt;
 *           &lt;element name="chapter" type="{http://www.epo.org/exchange}chapterType" minOccurs="0"/&gt;
 *           &lt;element name="pp" type="{http://www.epo.org/exchange}ppType" minOccurs="0"/&gt;
 *           &lt;element name="column" type="{http://www.epo.org/exchange}columnType" minOccurs="0"/&gt;
 *           &lt;element name="para" type="{http://www.epo.org/exchange}paraType" minOccurs="0"/&gt;
 *           &lt;element name="line" type="{http://www.epo.org/exchange}lineType" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "locationType", propOrder = {
    "text",
    "serpart",
    "sersect",
    "chapter",
    "pp",
    "column",
    "para",
    "line"
})
public class LocationType {

    protected TextType text;
    protected SerpartType serpart;
    protected SersectType sersect;
    protected ChapterType chapter;
    protected PpType pp;
    protected ColumnType column;
    protected ParaType para;
    protected LineType line;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * 取得 serpart 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SerpartType }
     *     
     */
    public SerpartType getSerpart() {
        return serpart;
    }

    /**
     * 設定 serpart 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SerpartType }
     *     
     */
    public void setSerpart(SerpartType value) {
        this.serpart = value;
    }

    /**
     * 取得 sersect 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SersectType }
     *     
     */
    public SersectType getSersect() {
        return sersect;
    }

    /**
     * 設定 sersect 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SersectType }
     *     
     */
    public void setSersect(SersectType value) {
        this.sersect = value;
    }

    /**
     * 取得 chapter 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ChapterType }
     *     
     */
    public ChapterType getChapter() {
        return chapter;
    }

    /**
     * 設定 chapter 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ChapterType }
     *     
     */
    public void setChapter(ChapterType value) {
        this.chapter = value;
    }

    /**
     * 取得 pp 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PpType }
     *     
     */
    public PpType getPp() {
        return pp;
    }

    /**
     * 設定 pp 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PpType }
     *     
     */
    public void setPp(PpType value) {
        this.pp = value;
    }

    /**
     * 取得 column 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ColumnType }
     *     
     */
    public ColumnType getColumn() {
        return column;
    }

    /**
     * 設定 column 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ColumnType }
     *     
     */
    public void setColumn(ColumnType value) {
        this.column = value;
    }

    /**
     * 取得 para 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ParaType }
     *     
     */
    public ParaType getPara() {
        return para;
    }

    /**
     * 設定 para 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ParaType }
     *     
     */
    public void setPara(ParaType value) {
        this.para = value;
    }

    /**
     * 取得 line 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link LineType }
     *     
     */
    public LineType getLine() {
        return line;
    }

    /**
     * 設定 line 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link LineType }
     *     
     */
    public void setLine(LineType value) {
        this.line = value;
    }

}
