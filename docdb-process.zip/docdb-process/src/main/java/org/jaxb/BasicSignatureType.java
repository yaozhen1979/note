//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>basic-signatureType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="basic-signatureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="fax-image" type="{http://www.epo.org/exchange}fax-imageType"/&gt;
 *         &lt;element name="text-string" type="{http://www.epo.org/exchange}text-stringType"/&gt;
 *         &lt;element name="click-wrap" type="{http://www.epo.org/exchange}click-wrapType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "basic-signatureType", propOrder = {
    "faxImage",
    "textString",
    "clickWrap"
})
public class BasicSignatureType {

    @XmlElement(name = "fax-image")
    protected FaxImageType faxImage;
    @XmlElement(name = "text-string")
    protected TextStringType textString;
    @XmlElement(name = "click-wrap")
    protected ClickWrapType clickWrap;

    /**
     * 取得 faxImage 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FaxImageType }
     *     
     */
    public FaxImageType getFaxImage() {
        return faxImage;
    }

    /**
     * 設定 faxImage 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FaxImageType }
     *     
     */
    public void setFaxImage(FaxImageType value) {
        this.faxImage = value;
    }

    /**
     * 取得 textString 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextStringType }
     *     
     */
    public TextStringType getTextString() {
        return textString;
    }

    /**
     * 設定 textString 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextStringType }
     *     
     */
    public void setTextString(TextStringType value) {
        this.textString = value;
    }

    /**
     * 取得 clickWrap 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClickWrapType }
     *     
     */
    public ClickWrapType getClickWrap() {
        return clickWrap;
    }

    /**
     * 設定 clickWrap 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClickWrapType }
     *     
     */
    public void setClickWrap(ClickWrapType value) {
        this.clickWrap = value;
    }

}
