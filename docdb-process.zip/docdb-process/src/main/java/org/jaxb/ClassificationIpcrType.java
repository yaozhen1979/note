//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>classification-ipcrType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="classification-ipcrType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="ipc-version-indicator" type="{http://www.epo.org/exchange}ipc-version-indicatorType"/&gt;
 *           &lt;element name="classification-level" type="{http://www.epo.org/exchange}classification-levelType" minOccurs="0"/&gt;
 *           &lt;element name="section" type="{http://www.epo.org/exchange}sectionType"/&gt;
 *           &lt;element name="class" type="{http://www.epo.org/exchange}classType"/&gt;
 *           &lt;element name="subclass" type="{http://www.epo.org/exchange}subclassType"/&gt;
 *           &lt;element name="main-group" type="{http://www.epo.org/exchange}main-groupType" minOccurs="0"/&gt;
 *           &lt;element name="subgroup" type="{http://www.epo.org/exchange}subgroupType" minOccurs="0"/&gt;
 *           &lt;element name="symbol-position" type="{http://www.epo.org/exchange}symbol-positionType" minOccurs="0"/&gt;
 *           &lt;element name="classification-value" type="{http://www.epo.org/exchange}classification-valueType" minOccurs="0"/&gt;
 *           &lt;element name="action-date" type="{http://www.epo.org/exchange}action-dateType" minOccurs="0"/&gt;
 *           &lt;element name="generating-office" type="{http://www.epo.org/exchange}generating-officeType" minOccurs="0"/&gt;
 *           &lt;element name="classification-status" type="{http://www.epo.org/exchange}classification-statusType" minOccurs="0"/&gt;
 *           &lt;element name="classification-data-source" type="{http://www.epo.org/exchange}classification-data-sourceType" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="sequence" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classification-ipcrType", propOrder = {
    "ipcVersionIndicator",
    "classificationLevel",
    "section",
    "clazz",
    "subclass",
    "mainGroup",
    "subgroup",
    "symbolPosition",
    "classificationValue",
    "actionDate",
    "generatingOffice",
    "classificationStatus",
    "classificationDataSource",
    "text"
})
public class ClassificationIpcrType {

    @XmlElement(name = "ipc-version-indicator")
    protected IpcVersionIndicatorType ipcVersionIndicator;
    @XmlElement(name = "classification-level")
    protected ClassificationLevelType classificationLevel;
    protected SectionType section;
    @XmlElement(name = "class")
    protected ClassType clazz;
    protected SubclassType subclass;
    @XmlElement(name = "main-group")
    protected MainGroupType mainGroup;
    protected SubgroupType subgroup;
    @XmlElement(name = "symbol-position")
    protected SymbolPositionType symbolPosition;
    @XmlElement(name = "classification-value")
    protected ClassificationValueType classificationValue;
    @XmlElement(name = "action-date")
    protected ActionDateType actionDate;
    @XmlElement(name = "generating-office")
    protected GeneratingOfficeType generatingOffice;
    @XmlElement(name = "classification-status")
    protected ClassificationStatusType classificationStatus;
    @XmlElement(name = "classification-data-source")
    protected ClassificationDataSourceType classificationDataSource;
    protected TextType text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "sequence")
    protected String sequence;

    /**
     * 取得 ipcVersionIndicator 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link IpcVersionIndicatorType }
     *     
     */
    public IpcVersionIndicatorType getIpcVersionIndicator() {
        return ipcVersionIndicator;
    }

    /**
     * 設定 ipcVersionIndicator 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link IpcVersionIndicatorType }
     *     
     */
    public void setIpcVersionIndicator(IpcVersionIndicatorType value) {
        this.ipcVersionIndicator = value;
    }

    /**
     * 取得 classificationLevel 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationLevelType }
     *     
     */
    public ClassificationLevelType getClassificationLevel() {
        return classificationLevel;
    }

    /**
     * 設定 classificationLevel 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationLevelType }
     *     
     */
    public void setClassificationLevel(ClassificationLevelType value) {
        this.classificationLevel = value;
    }

    /**
     * 取得 section 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SectionType }
     *     
     */
    public SectionType getSection() {
        return section;
    }

    /**
     * 設定 section 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SectionType }
     *     
     */
    public void setSection(SectionType value) {
        this.section = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassType }
     *     
     */
    public ClassType getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassType }
     *     
     */
    public void setClazz(ClassType value) {
        this.clazz = value;
    }

    /**
     * 取得 subclass 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SubclassType }
     *     
     */
    public SubclassType getSubclass() {
        return subclass;
    }

    /**
     * 設定 subclass 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SubclassType }
     *     
     */
    public void setSubclass(SubclassType value) {
        this.subclass = value;
    }

    /**
     * 取得 mainGroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainGroupType }
     *     
     */
    public MainGroupType getMainGroup() {
        return mainGroup;
    }

    /**
     * 設定 mainGroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainGroupType }
     *     
     */
    public void setMainGroup(MainGroupType value) {
        this.mainGroup = value;
    }

    /**
     * 取得 subgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SubgroupType }
     *     
     */
    public SubgroupType getSubgroup() {
        return subgroup;
    }

    /**
     * 設定 subgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SubgroupType }
     *     
     */
    public void setSubgroup(SubgroupType value) {
        this.subgroup = value;
    }

    /**
     * 取得 symbolPosition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SymbolPositionType }
     *     
     */
    public SymbolPositionType getSymbolPosition() {
        return symbolPosition;
    }

    /**
     * 設定 symbolPosition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SymbolPositionType }
     *     
     */
    public void setSymbolPosition(SymbolPositionType value) {
        this.symbolPosition = value;
    }

    /**
     * 取得 classificationValue 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationValueType }
     *     
     */
    public ClassificationValueType getClassificationValue() {
        return classificationValue;
    }

    /**
     * 設定 classificationValue 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationValueType }
     *     
     */
    public void setClassificationValue(ClassificationValueType value) {
        this.classificationValue = value;
    }

    /**
     * 取得 actionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ActionDateType }
     *     
     */
    public ActionDateType getActionDate() {
        return actionDate;
    }

    /**
     * 設定 actionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionDateType }
     *     
     */
    public void setActionDate(ActionDateType value) {
        this.actionDate = value;
    }

    /**
     * 取得 generatingOffice 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link GeneratingOfficeType }
     *     
     */
    public GeneratingOfficeType getGeneratingOffice() {
        return generatingOffice;
    }

    /**
     * 設定 generatingOffice 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link GeneratingOfficeType }
     *     
     */
    public void setGeneratingOffice(GeneratingOfficeType value) {
        this.generatingOffice = value;
    }

    /**
     * 取得 classificationStatus 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationStatusType }
     *     
     */
    public ClassificationStatusType getClassificationStatus() {
        return classificationStatus;
    }

    /**
     * 設定 classificationStatus 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationStatusType }
     *     
     */
    public void setClassificationStatus(ClassificationStatusType value) {
        this.classificationStatus = value;
    }

    /**
     * 取得 classificationDataSource 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationDataSourceType }
     *     
     */
    public ClassificationDataSourceType getClassificationDataSource() {
        return classificationDataSource;
    }

    /**
     * 設定 classificationDataSource 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationDataSourceType }
     *     
     */
    public void setClassificationDataSource(ClassificationDataSourceType value) {
        this.classificationDataSource = value;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

}
