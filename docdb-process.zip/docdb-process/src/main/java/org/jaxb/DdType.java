//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ddType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="ddType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element name="b" type="{http://www.epo.org/exchange}bType"/&gt;
 *         &lt;element name="i" type="{http://www.epo.org/exchange}iType"/&gt;
 *         &lt;element name="u" type="{http://www.epo.org/exchange}uType"/&gt;
 *         &lt;element name="o" type="{http://www.epo.org/exchange}oType"/&gt;
 *         &lt;element name="sup" type="{http://www.epo.org/exchange}supType"/&gt;
 *         &lt;element name="sub" type="{http://www.epo.org/exchange}subType"/&gt;
 *         &lt;element name="smallcaps" type="{http://www.epo.org/exchange}smallcapsType"/&gt;
 *         &lt;element name="br" type="{http://www.epo.org/exchange}brType"/&gt;
 *         &lt;element name="pre" type="{http://www.epo.org/exchange}preType"/&gt;
 *         &lt;element name="patcit" type="{http://www.epo.org/exchange}patcitType"/&gt;
 *         &lt;element name="nplcit" type="{http://www.epo.org/exchange}nplcitType"/&gt;
 *         &lt;element name="bio-deposit" type="{http://www.epo.org/exchange}bio-depositType"/&gt;
 *         &lt;element name="crossref" type="{http://www.epo.org/exchange}crossrefType"/&gt;
 *         &lt;element name="figref" type="{http://www.epo.org/exchange}figrefType"/&gt;
 *         &lt;element name="img" type="{http://www.epo.org/exchange}imgType"/&gt;
 *         &lt;element name="ul" type="{http://www.epo.org/exchange}ulType"/&gt;
 *         &lt;element name="ol" type="{http://www.epo.org/exchange}olType"/&gt;
 *         &lt;element name="chemistry" type="{http://www.epo.org/exchange}chemistryType"/&gt;
 *         &lt;element name="maths" type="{http://www.epo.org/exchange}mathsType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ddType", propOrder = {
    "content"
})
public class DdType {

    @XmlElementRefs({
        @XmlElementRef(name = "sub", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "img", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ul", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "sup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ol", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "smallcaps", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "u", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "bio-deposit", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "br", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "patcit", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "i", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "crossref", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "maths", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "nplcit", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "figref", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "o", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "chemistry", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "pre", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "b", type = JAXBElement.class, required = false)
    })
    @XmlMixed
    protected List<Serializable> content;

    /**
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link SubType }{@code >}
     * {@link JAXBElement }{@code <}{@link ImgType }{@code >}
     * {@link JAXBElement }{@code <}{@link UlType }{@code >}
     * {@link String }
     * {@link JAXBElement }{@code <}{@link SupType }{@code >}
     * {@link JAXBElement }{@code <}{@link OlType }{@code >}
     * {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}
     * {@link JAXBElement }{@code <}{@link UType }{@code >}
     * {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}
     * {@link JAXBElement }{@code <}{@link BrType }{@code >}
     * {@link JAXBElement }{@code <}{@link PatcitType }{@code >}
     * {@link JAXBElement }{@code <}{@link IType }{@code >}
     * {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}
     * {@link JAXBElement }{@code <}{@link MathsType }{@code >}
     * {@link JAXBElement }{@code <}{@link NplcitType }{@code >}
     * {@link JAXBElement }{@code <}{@link FigrefType }{@code >}
     * {@link JAXBElement }{@code <}{@link OType }{@code >}
     * {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}
     * {@link JAXBElement }{@code <}{@link PreType }{@code >}
     * {@link JAXBElement }{@code <}{@link BType }{@code >}
     * 
     * 
     */
    public List<Serializable> getContent() {
        if (content == null) {
            content = new ArrayList<Serializable>();
        }
        return this.content;
    }

}
