//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>designation-pctType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="designation-pctType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}regional" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}national" minOccurs="0"/&gt;
 *         &lt;element name="new-designation-country" type="{http://www.epo.org/exchange}new-designation-countryType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "designation-pctType", propOrder = {
    "regional",
    "national",
    "newDesignationCountry"
})
public class DesignationPctType {

    @XmlElement(namespace = "http://www.epo.org/exchange")
    protected List<RegionalType> regional;
    @XmlElement(namespace = "http://www.epo.org/exchange")
    protected NationalType national;
    @XmlElement(name = "new-designation-country")
    protected List<NewDesignationCountryType> newDesignationCountry;

    /**
     * Gets the value of the regional property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the regional property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegional().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegionalType }
     * 
     * 
     */
    public List<RegionalType> getRegional() {
        if (regional == null) {
            regional = new ArrayList<RegionalType>();
        }
        return this.regional;
    }

    /**
     * 取得 national 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NationalType }
     *     
     */
    public NationalType getNational() {
        return national;
    }

    /**
     * 設定 national 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NationalType }
     *     
     */
    public void setNational(NationalType value) {
        this.national = value;
    }

    /**
     * Gets the value of the newDesignationCountry property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the newDesignationCountry property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNewDesignationCountry().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NewDesignationCountryType }
     * 
     * 
     */
    public List<NewDesignationCountryType> getNewDesignationCountry() {
        if (newDesignationCountry == null) {
            newDesignationCountry = new ArrayList<NewDesignationCountryType>();
        }
        return this.newDesignationCountry;
    }

}
