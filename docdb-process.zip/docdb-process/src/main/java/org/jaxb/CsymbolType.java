//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>csymbolType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="csymbolType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element name="mglyph" type="{http://www.epo.org/exchange}mglyphType"/&gt;
 *         &lt;element name="mi" type="{http://www.epo.org/exchange}miType"/&gt;
 *         &lt;element name="mn" type="{http://www.epo.org/exchange}mnType"/&gt;
 *         &lt;element name="mo" type="{http://www.epo.org/exchange}moType"/&gt;
 *         &lt;element name="mtext" type="{http://www.epo.org/exchange}mtextType"/&gt;
 *         &lt;element name="ms" type="{http://www.epo.org/exchange}msType"/&gt;
 *         &lt;element name="mspace" type="{http://www.epo.org/exchange}mspaceType"/&gt;
 *         &lt;element name="mrow" type="{http://www.epo.org/exchange}mrowType"/&gt;
 *         &lt;element name="mfrac" type="{http://www.epo.org/exchange}mfracType"/&gt;
 *         &lt;element name="msqrt" type="{http://www.epo.org/exchange}msqrtType"/&gt;
 *         &lt;element name="mroot" type="{http://www.epo.org/exchange}mrootType"/&gt;
 *         &lt;element name="menclose" type="{http://www.epo.org/exchange}mencloseType"/&gt;
 *         &lt;element name="mstyle" type="{http://www.epo.org/exchange}mstyleType"/&gt;
 *         &lt;element name="merror" type="{http://www.epo.org/exchange}merrorType"/&gt;
 *         &lt;element name="mpadded" type="{http://www.epo.org/exchange}mpaddedType"/&gt;
 *         &lt;element name="mphantom" type="{http://www.epo.org/exchange}mphantomType"/&gt;
 *         &lt;element name="mfenced" type="{http://www.epo.org/exchange}mfencedType"/&gt;
 *         &lt;element name="msub" type="{http://www.epo.org/exchange}msubType"/&gt;
 *         &lt;element name="msup" type="{http://www.epo.org/exchange}msupType"/&gt;
 *         &lt;element name="msubsup" type="{http://www.epo.org/exchange}msubsupType"/&gt;
 *         &lt;element name="munder" type="{http://www.epo.org/exchange}munderType"/&gt;
 *         &lt;element name="mover" type="{http://www.epo.org/exchange}moverType"/&gt;
 *         &lt;element name="munderover" type="{http://www.epo.org/exchange}munderoverType"/&gt;
 *         &lt;element name="mmultiscripts" type="{http://www.epo.org/exchange}mmultiscriptsType"/&gt;
 *         &lt;element name="mtable" type="{http://www.epo.org/exchange}mtableType"/&gt;
 *         &lt;element name="mtr" type="{http://www.epo.org/exchange}mtrType"/&gt;
 *         &lt;element name="mlabeledtr" type="{http://www.epo.org/exchange}mlabeledtrType"/&gt;
 *         &lt;element name="mtd" type="{http://www.epo.org/exchange}mtdType"/&gt;
 *         &lt;element name="maligngroup" type="{http://www.epo.org/exchange}maligngroupType"/&gt;
 *         &lt;element name="malignmark" type="{http://www.epo.org/exchange}malignmarkType"/&gt;
 *         &lt;element name="maction" type="{http://www.epo.org/exchange}mactionType"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="encoding" type="{http://www.w3.org/2001/XMLSchema}string" default="" /&gt;
 *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="definitionURL" type="{http://www.w3.org/2001/XMLSchema}string" default="" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "csymbolType", propOrder = {
    "content"
})
public class CsymbolType {

    @XmlElementRefs({
        @XmlElementRef(name = "mmultiscripts", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "munderover", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "msub", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mtd", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "msqrt", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mroot", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mi", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mlabeledtr", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mspace", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ms", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "malignmark", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "munder", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mover", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mtr", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "maction", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mtable", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mstyle", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "menclose", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mn", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mtext", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mfrac", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "maligngroup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mpadded", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mphantom", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mfenced", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mrow", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "merror", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "msubsup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "msup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "mglyph", type = JAXBElement.class, required = false)
    })
    @XmlMixed
    protected List<Serializable> content;
    @XmlAttribute(name = "class")
    protected String clazz;
    @XmlAttribute(name = "style")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    protected String other;
    @XmlAttribute(name = "encoding")
    protected String encoding;
    @XmlAttribute(name = "type")
    protected String type;
    @XmlAttribute(name = "definitionURL")
    protected String definitionURL;

    /**
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link MmultiscriptsType }{@code >}
     * {@link JAXBElement }{@code <}{@link MunderoverType }{@code >}
     * {@link JAXBElement }{@code <}{@link MsubType }{@code >}
     * {@link JAXBElement }{@code <}{@link MtdType }{@code >}
     * {@link JAXBElement }{@code <}{@link MsqrtType }{@code >}
     * {@link JAXBElement }{@code <}{@link MrootType }{@code >}
     * {@link JAXBElement }{@code <}{@link MiType }{@code >}
     * {@link JAXBElement }{@code <}{@link MlabeledtrType }{@code >}
     * {@link JAXBElement }{@code <}{@link MspaceType }{@code >}
     * {@link JAXBElement }{@code <}{@link MoType }{@code >}
     * {@link JAXBElement }{@code <}{@link MsType }{@code >}
     * {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}
     * {@link JAXBElement }{@code <}{@link MunderType }{@code >}
     * {@link JAXBElement }{@code <}{@link MoverType }{@code >}
     * {@link JAXBElement }{@code <}{@link MtrType }{@code >}
     * {@link String }
     * {@link JAXBElement }{@code <}{@link MactionType }{@code >}
     * {@link JAXBElement }{@code <}{@link MtableType }{@code >}
     * {@link JAXBElement }{@code <}{@link MstyleType }{@code >}
     * {@link JAXBElement }{@code <}{@link MencloseType }{@code >}
     * {@link JAXBElement }{@code <}{@link MnType }{@code >}
     * {@link JAXBElement }{@code <}{@link MtextType }{@code >}
     * {@link JAXBElement }{@code <}{@link MfracType }{@code >}
     * {@link JAXBElement }{@code <}{@link MaligngroupType }{@code >}
     * {@link JAXBElement }{@code <}{@link MpaddedType }{@code >}
     * {@link JAXBElement }{@code <}{@link MphantomType }{@code >}
     * {@link JAXBElement }{@code <}{@link MfencedType }{@code >}
     * {@link JAXBElement }{@code <}{@link MrowType }{@code >}
     * {@link JAXBElement }{@code <}{@link MerrorType }{@code >}
     * {@link JAXBElement }{@code <}{@link MsubsupType }{@code >}
     * {@link JAXBElement }{@code <}{@link MsupType }{@code >}
     * {@link JAXBElement }{@code <}{@link MglyphType }{@code >}
     * 
     * 
     */
    public List<Serializable> getContent() {
        if (content == null) {
            content = new ArrayList<Serializable>();
        }
        return this.content;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 encoding 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncoding() {
        if (encoding == null) {
            return "";
        } else {
            return encoding;
        }
    }

    /**
     * 設定 encoding 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncoding(String value) {
        this.encoding = value;
    }

    /**
     * 取得 type 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * 設定 type 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * 取得 definitionURL 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefinitionURL() {
        if (definitionURL == null) {
            return "";
        } else {
            return definitionURL;
        }
    }

    /**
     * 設定 definitionURL 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefinitionURL(String value) {
        this.definitionURL = value;
    }

}
