//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>opinion-citationsType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="opinion-citationsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}certain-published-documents"/&gt;
 *         &lt;element name="non-written-disclosures" type="{http://www.epo.org/exchange}non-written-disclosuresType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "opinion-citationsType", propOrder = {
    "certainPublishedDocumentsOrNonWrittenDisclosures"
})
public class OpinionCitationsType {

    @XmlElements({
        @XmlElement(name = "certain-published-documents", namespace = "http://www.epo.org/exchange", type = CertainPublishedDocumentsType.class),
        @XmlElement(name = "non-written-disclosures", type = NonWrittenDisclosuresType.class)
    })
    protected List<Object> certainPublishedDocumentsOrNonWrittenDisclosures;

    /**
     * Gets the value of the certainPublishedDocumentsOrNonWrittenDisclosures property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the certainPublishedDocumentsOrNonWrittenDisclosures property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCertainPublishedDocumentsOrNonWrittenDisclosures().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CertainPublishedDocumentsType }
     * {@link NonWrittenDisclosuresType }
     * 
     * 
     */
    public List<Object> getCertainPublishedDocumentsOrNonWrittenDisclosures() {
        if (certainPublishedDocumentsOrNonWrittenDisclosures == null) {
            certainPublishedDocumentsOrNonWrittenDisclosures = new ArrayList<Object>();
        }
        return this.certainPublishedDocumentsOrNonWrittenDisclosures;
    }

}
