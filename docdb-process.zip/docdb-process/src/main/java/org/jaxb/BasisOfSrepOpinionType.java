//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>basis-of-srep-opinionType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="basis-of-srep-opinionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="translation-of-appl" type="{http://www.epo.org/exchange}translation-of-applType" minOccurs="0"/&gt;
 *         &lt;element name="sequence-list-basis" type="{http://www.epo.org/exchange}sequence-list-basisType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "basis-of-srep-opinionType", propOrder = {
    "translationOfAppl",
    "sequenceListBasis"
})
public class BasisOfSrepOpinionType {

    @XmlElement(name = "translation-of-appl")
    protected TranslationOfApplType translationOfAppl;
    @XmlElement(name = "sequence-list-basis")
    protected SequenceListBasisType sequenceListBasis;

    /**
     * 取得 translationOfAppl 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TranslationOfApplType }
     *     
     */
    public TranslationOfApplType getTranslationOfAppl() {
        return translationOfAppl;
    }

    /**
     * 設定 translationOfAppl 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslationOfApplType }
     *     
     */
    public void setTranslationOfAppl(TranslationOfApplType value) {
        this.translationOfAppl = value;
    }

    /**
     * 取得 sequenceListBasis 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SequenceListBasisType }
     *     
     */
    public SequenceListBasisType getSequenceListBasis() {
        return sequenceListBasis;
    }

    /**
     * 設定 sequenceListBasis 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SequenceListBasisType }
     *     
     */
    public void setSequenceListBasis(SequenceListBasisType value) {
        this.sequenceListBasis = value;
    }

}
