//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>inventorType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="inventorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}inventor-name" maxOccurs="unbounded"/&gt;
 *         &lt;element name="address" type="{http://www.epo.org/exchange}addressType" minOccurs="0"/&gt;
 *         &lt;element name="residence" type="{http://www.epo.org/exchange}residenceType" minOccurs="0"/&gt;
 *         &lt;element name="designated-states" type="{http://www.epo.org/exchange}designated-statesType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="designation"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;enumeration value="all"/&gt;
 *             &lt;enumeration value="all-except-us"/&gt;
 *             &lt;enumeration value="us-only"/&gt;
 *             &lt;enumeration value="as-indicated"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="data-format" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "inventorType", propOrder = {
    "inventorName",
    "address",
    "residence",
    "designatedStates"
})
public class InventorType {

    @XmlElement(name = "inventor-name", namespace = "http://www.epo.org/exchange", required = true)
    protected List<InventorNameType> inventorName;
    protected AddressType address;
    protected ResidenceType residence;
    @XmlElement(name = "designated-states")
    protected DesignatedStatesType designatedStates;
    @XmlAttribute(name = "sequence")
    protected String sequence;
    @XmlAttribute(name = "designation")
    protected String designation;
    @XmlAttribute(name = "data-format")
    protected String dataFormat;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * Gets the value of the inventorName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inventorName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInventorName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InventorNameType }
     * 
     * 
     */
    public List<InventorNameType> getInventorName() {
        if (inventorName == null) {
            inventorName = new ArrayList<InventorNameType>();
        }
        return this.inventorName;
    }

    /**
     * 取得 address 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AddressType }
     *     
     */
    public AddressType getAddress() {
        return address;
    }

    /**
     * 設定 address 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressType }
     *     
     */
    public void setAddress(AddressType value) {
        this.address = value;
    }

    /**
     * 取得 residence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ResidenceType }
     *     
     */
    public ResidenceType getResidence() {
        return residence;
    }

    /**
     * 設定 residence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ResidenceType }
     *     
     */
    public void setResidence(ResidenceType value) {
        this.residence = value;
    }

    /**
     * 取得 designatedStates 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignatedStatesType }
     *     
     */
    public DesignatedStatesType getDesignatedStates() {
        return designatedStates;
    }

    /**
     * 設定 designatedStates 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignatedStatesType }
     *     
     */
    public void setDesignatedStates(DesignatedStatesType value) {
        this.designatedStates = value;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

    /**
     * 取得 designation 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * 設定 designation 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesignation(String value) {
        this.designation = value;
    }

    /**
     * 取得 dataFormat 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataFormat() {
        return dataFormat;
    }

    /**
     * 設定 dataFormat 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataFormat(String value) {
        this.dataFormat = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
