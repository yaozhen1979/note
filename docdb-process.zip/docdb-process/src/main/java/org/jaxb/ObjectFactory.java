//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.jaxb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BibliographicData_QNAME = new QName("http://www.epo.org/exchange", "bibliographic-data");
    private final static QName _Abstract_QNAME = new QName("http://www.epo.org/exchange", "abstract");
    private final static QName _PatentFamily_QNAME = new QName("http://www.epo.org/exchange", "patent-family");
    private final static QName _SearchReportData_QNAME = new QName("http://www.epo.org/exchange", "search-report-data");
    private final static QName _PriorityDate_QNAME = new QName("http://www.epo.org/exchange", "priority-date");
    private final static QName _ComplianceUnityInvention_QNAME = new QName("http://www.epo.org/exchange", "compliance-unity-invention");
    private final static QName _InvitationPayAdditionalFees_QNAME = new QName("http://www.epo.org/exchange", "invitation-pay-additional-fees");
    private final static QName _SequenceListingComputerReadableForm_QNAME = new QName("http://www.epo.org/exchange", "sequence-listing-computer-readable-form");
    private final static QName _SequenceListingWrittenForm_QNAME = new QName("http://www.epo.org/exchange", "sequence-listing-written-form");
    private final static QName _PriorityOpinion_QNAME = new QName("http://www.epo.org/exchange", "priority-opinion");
    private final static QName _EarlierAppl_QNAME = new QName("http://www.epo.org/exchange", "earlier-appl");
    private final static QName _TranslationOfAppl_QNAME = new QName("http://www.epo.org/exchange", "translation-of-appl");
    private final static QName _SrepPatentFamily_QNAME = new QName("http://www.epo.org/exchange", "srep-patent-family");
    private final static QName _SrepInformation_QNAME = new QName("http://www.epo.org/exchange", "srep-information");
    private final static QName _ElectronicSignature_QNAME = new QName("http://www.epo.org/exchange", "electronic-signature");
    private final static QName _FaxImage_QNAME = new QName("http://www.epo.org/exchange", "fax-image");
    private final static QName _SrepFigureToPublish_QNAME = new QName("http://www.epo.org/exchange", "srep-figure-to-publish");
    private final static QName _SearchFeeProtest_QNAME = new QName("http://www.epo.org/exchange", "search-fee-protest");
    private final static QName _SequenceListingFilingTime_QNAME = new QName("http://www.epo.org/exchange", "sequence-listing-filing-time");
    private final static QName _SequenceListingMaterialFormat_QNAME = new QName("http://www.epo.org/exchange", "sequence-listing-material-format");
    private final static QName _SequenceListingMaterialType_QNAME = new QName("http://www.epo.org/exchange", "sequence-listing-material-type");
    private final static QName _BasisLanguageForSearch_QNAME = new QName("http://www.epo.org/exchange", "basis-language-for-search");
    private final static QName _SrepPriorArtDocs_QNAME = new QName("http://www.epo.org/exchange", "srep-prior-art-docs");
    private final static QName _PriorArtXmlDoc_QNAME = new QName("http://www.epo.org/exchange", "prior-art-xml-doc");
    private final static QName _SrepProtestFees_QNAME = new QName("http://www.epo.org/exchange", "srep-protest-fees");
    private final static QName _SrepEstablished_QNAME = new QName("http://www.epo.org/exchange", "srep-established");
    private final static QName _St50Republication_QNAME = new QName("http://www.epo.org/exchange", "st50-republication");
    private final static QName _RepublicationNote_QNAME = new QName("http://www.epo.org/exchange", "republication-note");
    private final static QName _ModifiedPart_QNAME = new QName("http://www.epo.org/exchange", "modified-part");
    private final static QName _ModifiedItem_QNAME = new QName("http://www.epo.org/exchange", "modified-item");
    private final static QName _InidCode_QNAME = new QName("http://www.epo.org/exchange", "inid-code");
    private final static QName _ReferencesCited_QNAME = new QName("http://www.epo.org/exchange", "references-cited");
    private final static QName _Citation_QNAME = new QName("http://www.epo.org/exchange", "citation");
    private final static QName _PriorityClaim_QNAME = new QName("http://www.epo.org/exchange", "priority-claim");
    private final static QName _Agent_QNAME = new QName("http://www.epo.org/exchange", "agent");
    private final static QName _DeceasedInventor_QNAME = new QName("http://www.epo.org/exchange", "deceased-inventor");
    private final static QName _InventorName_QNAME = new QName("http://www.epo.org/exchange", "inventor-name");
    private final static QName _Applicant_QNAME = new QName("http://www.epo.org/exchange", "applicant");
    private final static QName _UsRights_QNAME = new QName("http://www.epo.org/exchange", "us-rights");
    private final static QName _ApplicantName_QNAME = new QName("http://www.epo.org/exchange", "applicant-name");
    private final static QName _InventionTitle_QNAME = new QName("http://www.epo.org/exchange", "invention-title");
    private final static QName _DesignationOfStates_QNAME = new QName("http://www.epo.org/exchange", "designation-of-states");
    private final static QName _GazetteReference_QNAME = new QName("http://www.epo.org/exchange", "gazette-reference");
    private final static QName _AbstractReference_QNAME = new QName("http://www.epo.org/exchange", "abstract-reference");
    private final static QName _SrepNum_QNAME = new QName("http://www.epo.org/exchange", "srep-num");
    private final static QName _Date_QNAME = new QName("http://www.epo.org/exchange", "date");
    private final static QName _GazetteNum_QNAME = new QName("http://www.epo.org/exchange", "gazette-num");
    private final static QName _Text_QNAME = new QName("http://www.epo.org/exchange", "text");
    private final static QName _ModifiedFirstPagePub_QNAME = new QName("http://www.epo.org/exchange", "modified-first-page-pub");
    private final static QName _ModifiedCompleteSpecPub_QNAME = new QName("http://www.epo.org/exchange", "modified-complete-spec-pub");
    private final static QName _UnexaminedNotPrintedWithoutGrant_QNAME = new QName("http://www.epo.org/exchange", "unexamined-not-printed-without-grant");
    private final static QName _ExaminedNotPrintedWithoutGrant_QNAME = new QName("http://www.epo.org/exchange", "examined-not-printed-without-grant");
    private final static QName _UnexaminedPrintedWithoutGrant_QNAME = new QName("http://www.epo.org/exchange", "unexamined-printed-without-grant");
    private final static QName _ExaminedPrintedWithoutGrant_QNAME = new QName("http://www.epo.org/exchange", "examined-printed-without-grant");
    private final static QName _PrintedWithGrant_QNAME = new QName("http://www.epo.org/exchange", "printed-with-grant");
    private final static QName _ClaimsOnlyAvailable_QNAME = new QName("http://www.epo.org/exchange", "claims-only-available");
    private final static QName _NotPrintedWithGrant_QNAME = new QName("http://www.epo.org/exchange", "not-printed-with-grant");
    private final static QName _InvalidationOfPatent_QNAME = new QName("http://www.epo.org/exchange", "invalidation-of-patent");
    private final static QName _PrintedAsAmended_QNAME = new QName("http://www.epo.org/exchange", "printed-as-amended");
    private final static QName _PatentClassifications_QNAME = new QName("http://www.epo.org/exchange", "patent-classifications");
    private final static QName _CombinationSet_QNAME = new QName("http://www.epo.org/exchange", "combination-set");
    private final static QName _PatentClassification_QNAME = new QName("http://www.epo.org/exchange", "patent-classification");
    private final static QName _ClassificationIpc_QNAME = new QName("http://www.epo.org/exchange", "classification-ipc");
    private final static QName _ApplicationReference_QNAME = new QName("http://www.epo.org/exchange", "application-reference");
    private final static QName _PreviouslyFiledApp_QNAME = new QName("http://www.epo.org/exchange", "previously-filed-app");
    private final static QName _DateOfComingIntoForce_QNAME = new QName("http://www.epo.org/exchange", "date-of-coming-into-force");
    private final static QName _PrecedingPublicationDate_QNAME = new QName("http://www.epo.org/exchange", "preceding-publication-date");
    private final static QName _LanguageOfPublication_QNAME = new QName("http://www.epo.org/exchange", "language-of-publication");
    private final static QName _LanguageOfFiling_QNAME = new QName("http://www.epo.org/exchange", "language-of-filing");
    private final static QName _ClassificationNational_QNAME = new QName("http://www.epo.org/exchange", "classification-national");
    private final static QName _FurtherClassification_QNAME = new QName("http://www.epo.org/exchange", "further-classification");
    private final static QName _ClassificationsIpcr_QNAME = new QName("http://www.epo.org/exchange", "classifications-ipcr");
    private final static QName _ClassificationIpcr_QNAME = new QName("http://www.epo.org/exchange", "classification-ipcr");
    private final static QName _PublicationReference_QNAME = new QName("http://www.epo.org/exchange", "publication-reference");
    private final static QName _TableExternalDoc_QNAME = new QName("http://www.epo.org/exchange", "table-external-doc");
    private final static QName _Tables_QNAME = new QName("http://www.epo.org/exchange", "tables");
    private final static QName _Title_QNAME = new QName("http://www.epo.org/exchange", "title");
    private final static QName _Tgroup_QNAME = new QName("http://www.epo.org/exchange", "tgroup");
    private final static QName _Colspec_QNAME = new QName("http://www.epo.org/exchange", "colspec");
    private final static QName _Thead_QNAME = new QName("http://www.epo.org/exchange", "thead");
    private final static QName _Tbody_QNAME = new QName("http://www.epo.org/exchange", "tbody");
    private final static QName _Row_QNAME = new QName("http://www.epo.org/exchange", "row");
    private final static QName _Entry_QNAME = new QName("http://www.epo.org/exchange", "entry");
    private final static QName _Table_QNAME = new QName("http://www.epo.org/exchange", "table");
    private final static QName _Dl_QNAME = new QName("http://www.epo.org/exchange", "dl");
    private final static QName _Ul_QNAME = new QName("http://www.epo.org/exchange", "ul");
    private final static QName _Li_QNAME = new QName("http://www.epo.org/exchange", "li");
    private final static QName _Maths_QNAME = new QName("http://www.epo.org/exchange", "maths");
    private final static QName _Mi_QNAME = new QName("http://www.epo.org/exchange", "mi");
    private final static QName _Mglyph_QNAME = new QName("http://www.epo.org/exchange", "mglyph");
    private final static QName _Malignmark_QNAME = new QName("http://www.epo.org/exchange", "malignmark");
    private final static QName _Mn_QNAME = new QName("http://www.epo.org/exchange", "mn");
    private final static QName _Mo_QNAME = new QName("http://www.epo.org/exchange", "mo");
    private final static QName _Mtext_QNAME = new QName("http://www.epo.org/exchange", "mtext");
    private final static QName _Ms_QNAME = new QName("http://www.epo.org/exchange", "ms");
    private final static QName _Mspace_QNAME = new QName("http://www.epo.org/exchange", "mspace");
    private final static QName _Mrow_QNAME = new QName("http://www.epo.org/exchange", "mrow");
    private final static QName _Mprescripts_QNAME = new QName("http://www.epo.org/exchange", "mprescripts");
    private final static QName _None_QNAME = new QName("http://www.epo.org/exchange", "none");
    private final static QName _Mfrac_QNAME = new QName("http://www.epo.org/exchange", "mfrac");
    private final static QName _Msqrt_QNAME = new QName("http://www.epo.org/exchange", "msqrt");
    private final static QName _Mroot_QNAME = new QName("http://www.epo.org/exchange", "mroot");
    private final static QName _Menclose_QNAME = new QName("http://www.epo.org/exchange", "menclose");
    private final static QName _Mstyle_QNAME = new QName("http://www.epo.org/exchange", "mstyle");
    private final static QName _Merror_QNAME = new QName("http://www.epo.org/exchange", "merror");
    private final static QName _Mpadded_QNAME = new QName("http://www.epo.org/exchange", "mpadded");
    private final static QName _Mphantom_QNAME = new QName("http://www.epo.org/exchange", "mphantom");
    private final static QName _Mfenced_QNAME = new QName("http://www.epo.org/exchange", "mfenced");
    private final static QName _Msub_QNAME = new QName("http://www.epo.org/exchange", "msub");
    private final static QName _Msup_QNAME = new QName("http://www.epo.org/exchange", "msup");
    private final static QName _Msubsup_QNAME = new QName("http://www.epo.org/exchange", "msubsup");
    private final static QName _Munder_QNAME = new QName("http://www.epo.org/exchange", "munder");
    private final static QName _Mover_QNAME = new QName("http://www.epo.org/exchange", "mover");
    private final static QName _Munderover_QNAME = new QName("http://www.epo.org/exchange", "munderover");
    private final static QName _Mmultiscripts_QNAME = new QName("http://www.epo.org/exchange", "mmultiscripts");
    private final static QName _Mtable_QNAME = new QName("http://www.epo.org/exchange", "mtable");
    private final static QName _Mtr_QNAME = new QName("http://www.epo.org/exchange", "mtr");
    private final static QName _Mlabeledtr_QNAME = new QName("http://www.epo.org/exchange", "mlabeledtr");
    private final static QName _Mtd_QNAME = new QName("http://www.epo.org/exchange", "mtd");
    private final static QName _Maligngroup_QNAME = new QName("http://www.epo.org/exchange", "maligngroup");
    private final static QName _Maction_QNAME = new QName("http://www.epo.org/exchange", "maction");
    private final static QName _Ci_QNAME = new QName("http://www.epo.org/exchange", "ci");
    private final static QName _Csymbol_QNAME = new QName("http://www.epo.org/exchange", "csymbol");
    private final static QName _Cn_QNAME = new QName("http://www.epo.org/exchange", "cn");
    private final static QName _Sep_QNAME = new QName("http://www.epo.org/exchange", "sep");
    private final static QName _Integers_QNAME = new QName("http://www.epo.org/exchange", "integers");
    private final static QName _Reals_QNAME = new QName("http://www.epo.org/exchange", "reals");
    private final static QName _Rationals_QNAME = new QName("http://www.epo.org/exchange", "rationals");
    private final static QName _Naturalnumbers_QNAME = new QName("http://www.epo.org/exchange", "naturalnumbers");
    private final static QName _Complexes_QNAME = new QName("http://www.epo.org/exchange", "complexes");
    private final static QName _Primes_QNAME = new QName("http://www.epo.org/exchange", "primes");
    private final static QName _Exponentiale_QNAME = new QName("http://www.epo.org/exchange", "exponentiale");
    private final static QName _Imaginaryi_QNAME = new QName("http://www.epo.org/exchange", "imaginaryi");
    private final static QName _Notanumber_QNAME = new QName("http://www.epo.org/exchange", "notanumber");
    private final static QName _True_QNAME = new QName("http://www.epo.org/exchange", "true");
    private final static QName _False_QNAME = new QName("http://www.epo.org/exchange", "false");
    private final static QName _Emptyset_QNAME = new QName("http://www.epo.org/exchange", "emptyset");
    private final static QName _Pi_QNAME = new QName("http://www.epo.org/exchange", "pi");
    private final static QName _Eulergamma_QNAME = new QName("http://www.epo.org/exchange", "eulergamma");
    private final static QName _Infinity_QNAME = new QName("http://www.epo.org/exchange", "infinity");
    private final static QName _Apply_QNAME = new QName("http://www.epo.org/exchange", "apply");
    private final static QName _Reln_QNAME = new QName("http://www.epo.org/exchange", "reln");
    private final static QName _Lambda_QNAME = new QName("http://www.epo.org/exchange", "lambda");
    private final static QName _Condition_QNAME = new QName("http://www.epo.org/exchange", "condition");
    private final static QName _Declare_QNAME = new QName("http://www.epo.org/exchange", "declare");
    private final static QName _Semantics_QNAME = new QName("http://www.epo.org/exchange", "semantics");
    private final static QName _Annotation_QNAME = new QName("http://www.epo.org/exchange", "annotation");
    private final static QName _AnnotationXml_QNAME = new QName("http://www.epo.org/exchange", "annotation-xml");
    private final static QName _Interval_QNAME = new QName("http://www.epo.org/exchange", "interval");
    private final static QName _List_QNAME = new QName("http://www.epo.org/exchange", "list");
    private final static QName _Matrix_QNAME = new QName("http://www.epo.org/exchange", "matrix");
    private final static QName _Matrixrow_QNAME = new QName("http://www.epo.org/exchange", "matrixrow");
    private final static QName _Set_QNAME = new QName("http://www.epo.org/exchange", "set");
    private final static QName _Vector_QNAME = new QName("http://www.epo.org/exchange", "vector");
    private final static QName _Piecewise_QNAME = new QName("http://www.epo.org/exchange", "piecewise");
    private final static QName _Piece_QNAME = new QName("http://www.epo.org/exchange", "piece");
    private final static QName _Otherwise_QNAME = new QName("http://www.epo.org/exchange", "otherwise");
    private final static QName _Lowlimit_QNAME = new QName("http://www.epo.org/exchange", "lowlimit");
    private final static QName _Uplimit_QNAME = new QName("http://www.epo.org/exchange", "uplimit");
    private final static QName _Bvar_QNAME = new QName("http://www.epo.org/exchange", "bvar");
    private final static QName _Degree_QNAME = new QName("http://www.epo.org/exchange", "degree");
    private final static QName _Logbase_QNAME = new QName("http://www.epo.org/exchange", "logbase");
    private final static QName _Momentabout_QNAME = new QName("http://www.epo.org/exchange", "momentabout");
    private final static QName _Domainofapplication_QNAME = new QName("http://www.epo.org/exchange", "domainofapplication");
    private final static QName _Inverse_QNAME = new QName("http://www.epo.org/exchange", "inverse");
    private final static QName _Ident_QNAME = new QName("http://www.epo.org/exchange", "ident");
    private final static QName _Domain_QNAME = new QName("http://www.epo.org/exchange", "domain");
    private final static QName _Codomain_QNAME = new QName("http://www.epo.org/exchange", "codomain");
    private final static QName _Image_QNAME = new QName("http://www.epo.org/exchange", "image");
    private final static QName _Abs_QNAME = new QName("http://www.epo.org/exchange", "abs");
    private final static QName _Conjugate_QNAME = new QName("http://www.epo.org/exchange", "conjugate");
    private final static QName _Exp_QNAME = new QName("http://www.epo.org/exchange", "exp");
    private final static QName _Factorial_QNAME = new QName("http://www.epo.org/exchange", "factorial");
    private final static QName _Arg_QNAME = new QName("http://www.epo.org/exchange", "arg");
    private final static QName _Real_QNAME = new QName("http://www.epo.org/exchange", "real");
    private final static QName _Imaginary_QNAME = new QName("http://www.epo.org/exchange", "imaginary");
    private final static QName _Floor_QNAME = new QName("http://www.epo.org/exchange", "floor");
    private final static QName _Ceiling_QNAME = new QName("http://www.epo.org/exchange", "ceiling");
    private final static QName _Not_QNAME = new QName("http://www.epo.org/exchange", "not");
    private final static QName _Ln_QNAME = new QName("http://www.epo.org/exchange", "ln");
    private final static QName _Sin_QNAME = new QName("http://www.epo.org/exchange", "sin");
    private final static QName _Cos_QNAME = new QName("http://www.epo.org/exchange", "cos");
    private final static QName _Tan_QNAME = new QName("http://www.epo.org/exchange", "tan");
    private final static QName _Sec_QNAME = new QName("http://www.epo.org/exchange", "sec");
    private final static QName _Csc_QNAME = new QName("http://www.epo.org/exchange", "csc");
    private final static QName _Cot_QNAME = new QName("http://www.epo.org/exchange", "cot");
    private final static QName _Sinh_QNAME = new QName("http://www.epo.org/exchange", "sinh");
    private final static QName _Cosh_QNAME = new QName("http://www.epo.org/exchange", "cosh");
    private final static QName _Tanh_QNAME = new QName("http://www.epo.org/exchange", "tanh");
    private final static QName _Sech_QNAME = new QName("http://www.epo.org/exchange", "sech");
    private final static QName _Csch_QNAME = new QName("http://www.epo.org/exchange", "csch");
    private final static QName _Coth_QNAME = new QName("http://www.epo.org/exchange", "coth");
    private final static QName _Arcsin_QNAME = new QName("http://www.epo.org/exchange", "arcsin");
    private final static QName _Arccos_QNAME = new QName("http://www.epo.org/exchange", "arccos");
    private final static QName _Arctan_QNAME = new QName("http://www.epo.org/exchange", "arctan");
    private final static QName _Arccosh_QNAME = new QName("http://www.epo.org/exchange", "arccosh");
    private final static QName _Arccot_QNAME = new QName("http://www.epo.org/exchange", "arccot");
    private final static QName _Arccoth_QNAME = new QName("http://www.epo.org/exchange", "arccoth");
    private final static QName _Arccsc_QNAME = new QName("http://www.epo.org/exchange", "arccsc");
    private final static QName _Arccsch_QNAME = new QName("http://www.epo.org/exchange", "arccsch");
    private final static QName _Arcsec_QNAME = new QName("http://www.epo.org/exchange", "arcsec");
    private final static QName _Arcsech_QNAME = new QName("http://www.epo.org/exchange", "arcsech");
    private final static QName _Arcsinh_QNAME = new QName("http://www.epo.org/exchange", "arcsinh");
    private final static QName _Arctanh_QNAME = new QName("http://www.epo.org/exchange", "arctanh");
    private final static QName _Determinant_QNAME = new QName("http://www.epo.org/exchange", "determinant");
    private final static QName _Transpose_QNAME = new QName("http://www.epo.org/exchange", "transpose");
    private final static QName _Card_QNAME = new QName("http://www.epo.org/exchange", "card");
    private final static QName _Quotient_QNAME = new QName("http://www.epo.org/exchange", "quotient");
    private final static QName _Divide_QNAME = new QName("http://www.epo.org/exchange", "divide");
    private final static QName _Power_QNAME = new QName("http://www.epo.org/exchange", "power");
    private final static QName _Rem_QNAME = new QName("http://www.epo.org/exchange", "rem");
    private final static QName _Implies_QNAME = new QName("http://www.epo.org/exchange", "implies");
    private final static QName _Vectorproduct_QNAME = new QName("http://www.epo.org/exchange", "vectorproduct");
    private final static QName _Scalarproduct_QNAME = new QName("http://www.epo.org/exchange", "scalarproduct");
    private final static QName _Outerproduct_QNAME = new QName("http://www.epo.org/exchange", "outerproduct");
    private final static QName _Setdiff_QNAME = new QName("http://www.epo.org/exchange", "setdiff");
    private final static QName _Fn_QNAME = new QName("http://www.epo.org/exchange", "fn");
    private final static QName _Compose_QNAME = new QName("http://www.epo.org/exchange", "compose");
    private final static QName _Plus_QNAME = new QName("http://www.epo.org/exchange", "plus");
    private final static QName _Times_QNAME = new QName("http://www.epo.org/exchange", "times");
    private final static QName _Max_QNAME = new QName("http://www.epo.org/exchange", "max");
    private final static QName _Min_QNAME = new QName("http://www.epo.org/exchange", "min");
    private final static QName _Gcd_QNAME = new QName("http://www.epo.org/exchange", "gcd");
    private final static QName _Lcm_QNAME = new QName("http://www.epo.org/exchange", "lcm");
    private final static QName _And_QNAME = new QName("http://www.epo.org/exchange", "and");
    private final static QName _Or_QNAME = new QName("http://www.epo.org/exchange", "or");
    private final static QName _Xor_QNAME = new QName("http://www.epo.org/exchange", "xor");
    private final static QName _Union_QNAME = new QName("http://www.epo.org/exchange", "union");
    private final static QName _Intersect_QNAME = new QName("http://www.epo.org/exchange", "intersect");
    private final static QName _Cartesianproduct_QNAME = new QName("http://www.epo.org/exchange", "cartesianproduct");
    private final static QName _Mean_QNAME = new QName("http://www.epo.org/exchange", "mean");
    private final static QName _Sdev_QNAME = new QName("http://www.epo.org/exchange", "sdev");
    private final static QName _Variance_QNAME = new QName("http://www.epo.org/exchange", "variance");
    private final static QName _Median_QNAME = new QName("http://www.epo.org/exchange", "median");
    private final static QName _Mode_QNAME = new QName("http://www.epo.org/exchange", "mode");
    private final static QName _Selector_QNAME = new QName("http://www.epo.org/exchange", "selector");
    private final static QName _Root_QNAME = new QName("http://www.epo.org/exchange", "root");
    private final static QName _Minus_QNAME = new QName("http://www.epo.org/exchange", "minus");
    private final static QName _Log_QNAME = new QName("http://www.epo.org/exchange", "log");
    private final static QName _Int_QNAME = new QName("http://www.epo.org/exchange", "int");
    private final static QName _Diff_QNAME = new QName("http://www.epo.org/exchange", "diff");
    private final static QName _Partialdiff_QNAME = new QName("http://www.epo.org/exchange", "partialdiff");
    private final static QName _Divergence_QNAME = new QName("http://www.epo.org/exchange", "divergence");
    private final static QName _Grad_QNAME = new QName("http://www.epo.org/exchange", "grad");
    private final static QName _Curl_QNAME = new QName("http://www.epo.org/exchange", "curl");
    private final static QName _Laplacian_QNAME = new QName("http://www.epo.org/exchange", "laplacian");
    private final static QName _Sum_QNAME = new QName("http://www.epo.org/exchange", "sum");
    private final static QName _Product_QNAME = new QName("http://www.epo.org/exchange", "product");
    private final static QName _Limit_QNAME = new QName("http://www.epo.org/exchange", "limit");
    private final static QName _Moment_QNAME = new QName("http://www.epo.org/exchange", "moment");
    private final static QName _Exists_QNAME = new QName("http://www.epo.org/exchange", "exists");
    private final static QName _Forall_QNAME = new QName("http://www.epo.org/exchange", "forall");
    private final static QName _Neq_QNAME = new QName("http://www.epo.org/exchange", "neq");
    private final static QName _Factorof_QNAME = new QName("http://www.epo.org/exchange", "factorof");
    private final static QName _In_QNAME = new QName("http://www.epo.org/exchange", "in");
    private final static QName _Notin_QNAME = new QName("http://www.epo.org/exchange", "notin");
    private final static QName _Notsubset_QNAME = new QName("http://www.epo.org/exchange", "notsubset");
    private final static QName _Notprsubset_QNAME = new QName("http://www.epo.org/exchange", "notprsubset");
    private final static QName _Tendsto_QNAME = new QName("http://www.epo.org/exchange", "tendsto");
    private final static QName _Eq_QNAME = new QName("http://www.epo.org/exchange", "eq");
    private final static QName _Leq_QNAME = new QName("http://www.epo.org/exchange", "leq");
    private final static QName _Lt_QNAME = new QName("http://www.epo.org/exchange", "lt");
    private final static QName _Geq_QNAME = new QName("http://www.epo.org/exchange", "geq");
    private final static QName _Gt_QNAME = new QName("http://www.epo.org/exchange", "gt");
    private final static QName _Equivalent_QNAME = new QName("http://www.epo.org/exchange", "equivalent");
    private final static QName _Approx_QNAME = new QName("http://www.epo.org/exchange", "approx");
    private final static QName _Subset_QNAME = new QName("http://www.epo.org/exchange", "subset");
    private final static QName _Prsubset_QNAME = new QName("http://www.epo.org/exchange", "prsubset");
    private final static QName _Chemistry_QNAME = new QName("http://www.epo.org/exchange", "chemistry");
    private final static QName _Chem_QNAME = new QName("http://www.epo.org/exchange", "chem");
    private final static QName _Ol_QNAME = new QName("http://www.epo.org/exchange", "ol");
    private final static QName _Img_QNAME = new QName("http://www.epo.org/exchange", "img");
    private final static QName _Figref_QNAME = new QName("http://www.epo.org/exchange", "figref");
    private final static QName _Crossref_QNAME = new QName("http://www.epo.org/exchange", "crossref");
    private final static QName _BioDeposit_QNAME = new QName("http://www.epo.org/exchange", "bio-deposit");
    private final static QName _Nplcit_QNAME = new QName("http://www.epo.org/exchange", "nplcit");
    private final static QName _Refno_QNAME = new QName("http://www.epo.org/exchange", "refno");
    private final static QName _Class_QNAME = new QName("http://www.epo.org/exchange", "class");
    private final static QName _Subname_QNAME = new QName("http://www.epo.org/exchange", "subname");
    private final static QName _Author_QNAME = new QName("http://www.epo.org/exchange", "author");
    private final static QName _Addressbook_QNAME = new QName("http://www.epo.org/exchange", "addressbook");
    private final static QName _Patcit_QNAME = new QName("http://www.epo.org/exchange", "patcit");
    private final static QName _DocumentId_QNAME = new QName("http://www.epo.org/exchange", "document-id");
    private final static QName _Name_QNAME = new QName("http://www.epo.org/exchange", "name");
    private final static QName _Dt_QNAME = new QName("http://www.epo.org/exchange", "dt");
    private final static QName _O_QNAME = new QName("http://www.epo.org/exchange", "o");
    private final static QName _U_QNAME = new QName("http://www.epo.org/exchange", "u");
    private final static QName _DocPage_QNAME = new QName("http://www.epo.org/exchange", "doc-page");
    private final static QName _SrepWrittenOpinion_QNAME = new QName("http://www.epo.org/exchange", "srep-written-opinion");
    private final static QName _ObservationOnApplication_QNAME = new QName("http://www.epo.org/exchange", "observation-on-application");
    private final static QName _DefectInApplication_QNAME = new QName("http://www.epo.org/exchange", "defect-in-application");
    private final static QName _OpinionCitations_QNAME = new QName("http://www.epo.org/exchange", "opinion-citations");
    private final static QName _NonWrittenDisclosures_QNAME = new QName("http://www.epo.org/exchange", "non-written-disclosures");
    private final static QName _DateOfWrittenDisclosure_QNAME = new QName("http://www.epo.org/exchange", "date-of-written-disclosure");
    private final static QName _KindOfDisclosure_QNAME = new QName("http://www.epo.org/exchange", "kind-of-disclosure");
    private final static QName _CertainPublishedDocuments_QNAME = new QName("http://www.epo.org/exchange", "certain-published-documents");
    private final static QName _PctRule43BisStatement_QNAME = new QName("http://www.epo.org/exchange", "pct-rule43bis-statement");
    private final static QName _CitationsExplanations_QNAME = new QName("http://www.epo.org/exchange", "citations-explanations");
    private final static QName _FilingDate_QNAME = new QName("http://www.epo.org/exchange", "filing-date");
    private final static QName _ApplicabilityNotValid_QNAME = new QName("http://www.epo.org/exchange", "applicability-not-valid");
    private final static QName _ApplicabilityValid_QNAME = new QName("http://www.epo.org/exchange", "applicability-valid");
    private final static QName _InventiveStepNotValid_QNAME = new QName("http://www.epo.org/exchange", "inventive-step-not-valid");
    private final static QName _InventiveStepValid_QNAME = new QName("http://www.epo.org/exchange", "inventive-step-valid");
    private final static QName _NoveltyNotValid_QNAME = new QName("http://www.epo.org/exchange", "novelty-not-valid");
    private final static QName _NoveltyValid_QNAME = new QName("http://www.epo.org/exchange", "novelty-valid");
    private final static QName _UnityOfInvention_QNAME = new QName("http://www.epo.org/exchange", "unity-of-invention");
    private final static QName _OpinionEstablishedRegarding_QNAME = new QName("http://www.epo.org/exchange", "opinion-established-regarding");
    private final static QName _NotUnityOfInvention_QNAME = new QName("http://www.epo.org/exchange", "not-unity-of-invention");
    private final static QName _NonEstablishmentOfOpinion_QNAME = new QName("http://www.epo.org/exchange", "non-establishment-of-opinion");
    private final static QName _NotAnnexCCompliant_QNAME = new QName("http://www.epo.org/exchange", "not-annex-c-compliant");
    private final static QName _AnnexCBis_QNAME = new QName("http://www.epo.org/exchange", "annex-c-bis");
    private final static QName _AnnexC_QNAME = new QName("http://www.epo.org/exchange", "annex-c");
    private final static QName _InventionNotExamined_QNAME = new QName("http://www.epo.org/exchange", "invention-not-examined");
    private final static QName _NonEstabReason4_QNAME = new QName("http://www.epo.org/exchange", "non-estab-reason-4");
    private final static QName _NonEstabReason3_QNAME = new QName("http://www.epo.org/exchange", "non-estab-reason-3");
    private final static QName _NonEstabReason2_QNAME = new QName("http://www.epo.org/exchange", "non-estab-reason-2");
    private final static QName _NonEstabReason1_QNAME = new QName("http://www.epo.org/exchange", "non-estab-reason-1");
    private final static QName _EntireApplication_QNAME = new QName("http://www.epo.org/exchange", "entire-application");
    private final static QName _ClaimInvalid_QNAME = new QName("http://www.epo.org/exchange", "claim-invalid");
    private final static QName _BasisOfSrepOpinion_QNAME = new QName("http://www.epo.org/exchange", "basis-of-srep-opinion");
    private final static QName _SrepForPub_QNAME = new QName("http://www.epo.org/exchange", "srep-for-pub");
    private final static QName _SrepPatentFamilies_QNAME = new QName("http://www.epo.org/exchange", "srep-patent-families");
    private final static QName _SrepFamilyMember_QNAME = new QName("http://www.epo.org/exchange", "srep-family-member");
    private final static QName _PriorityApplication_QNAME = new QName("http://www.epo.org/exchange", "priority-application");
    private final static QName _SrepAdmin_QNAME = new QName("http://www.epo.org/exchange", "srep-admin");
    private final static QName _DateSearchCompleted_QNAME = new QName("http://www.epo.org/exchange", "date-search-completed");
    private final static QName _Examiners_QNAME = new QName("http://www.epo.org/exchange", "examiners");
    private final static QName _AssistantExaminer_QNAME = new QName("http://www.epo.org/exchange", "assistant-examiner");
    private final static QName _PrimaryExaminer_QNAME = new QName("http://www.epo.org/exchange", "primary-examiner");
    private final static QName _IncompleteSearch_QNAME = new QName("http://www.epo.org/exchange", "incomplete-search");
    private final static QName _ReasonLimitedSearch_QNAME = new QName("http://www.epo.org/exchange", "reason-limited-search");
    private final static QName _ClaimsNotSearched_QNAME = new QName("http://www.epo.org/exchange", "claims-not-searched");
    private final static QName _ClaimsSearchedIncompletely_QNAME = new QName("http://www.epo.org/exchange", "claims-searched-incompletely");
    private final static QName _ClaimsSearched_QNAME = new QName("http://www.epo.org/exchange", "claims-searched");
    private final static QName _SrepCitations_QNAME = new QName("http://www.epo.org/exchange", "srep-citations");
    private final static QName _SrepFieldsSearched_QNAME = new QName("http://www.epo.org/exchange", "srep-fields-searched");
    private final static QName _DatabaseSearched_QNAME = new QName("http://www.epo.org/exchange", "database-searched");
    private final static QName _OtherDocumentation_QNAME = new QName("http://www.epo.org/exchange", "other-documentation");
    private final static QName _MinimumDocumentation_QNAME = new QName("http://www.epo.org/exchange", "minimum-documentation");
    private final static QName _SrepInfo_QNAME = new QName("http://www.epo.org/exchange", "srep-info");
    private final static QName _SrepAbstract_QNAME = new QName("http://www.epo.org/exchange", "srep-abstract");
    private final static QName _SrepInventionTitle_QNAME = new QName("http://www.epo.org/exchange", "srep-invention-title");
    private final static QName _SrepOtherInfo_QNAME = new QName("http://www.epo.org/exchange", "srep-other-info");
    private final static QName _SrepInfoAdmin_QNAME = new QName("http://www.epo.org/exchange", "srep-info-admin");
    private final static QName _DateSearchReportMailed_QNAME = new QName("http://www.epo.org/exchange", "date-search-report-mailed");
    private final static QName _SrepOffice_QNAME = new QName("http://www.epo.org/exchange", "srep-office");
    private final static QName _AuthorizedOfficer_QNAME = new QName("http://www.epo.org/exchange", "authorized-officer");
    private final static QName _EnhancedSignature_QNAME = new QName("http://www.epo.org/exchange", "enhanced-signature");
    private final static QName _Pkcs7_QNAME = new QName("http://www.epo.org/exchange", "pkcs7");
    private final static QName _BasicSignature_QNAME = new QName("http://www.epo.org/exchange", "basic-signature");
    private final static QName _ClickWrap_QNAME = new QName("http://www.epo.org/exchange", "click-wrap");
    private final static QName _TextString_QNAME = new QName("http://www.epo.org/exchange", "text-string");
    private final static QName _FigureToPublish_QNAME = new QName("http://www.epo.org/exchange", "figure-to-publish");
    private final static QName _FigNumber_QNAME = new QName("http://www.epo.org/exchange", "fig-number");
    private final static QName _SrepUnityOfInvention_QNAME = new QName("http://www.epo.org/exchange", "srep-unity-of-invention");
    private final static QName _SrepSearchFees_QNAME = new QName("http://www.epo.org/exchange", "srep-search-fees");
    private final static QName _SrepFee4_QNAME = new QName("http://www.epo.org/exchange", "srep-fee-4");
    private final static QName _SrepFee3_QNAME = new QName("http://www.epo.org/exchange", "srep-fee-3");
    private final static QName _SrepFee2_QNAME = new QName("http://www.epo.org/exchange", "srep-fee-2");
    private final static QName _SrepFee1_QNAME = new QName("http://www.epo.org/exchange", "srep-fee-1");
    private final static QName _SrepClaimsInfo_QNAME = new QName("http://www.epo.org/exchange", "srep-claims-info");
    private final static QName _ClmsReason3_QNAME = new QName("http://www.epo.org/exchange", "clms-reason-3");
    private final static QName _ClmsReason2_QNAME = new QName("http://www.epo.org/exchange", "clms-reason-2");
    private final static QName _ClmsReason1_QNAME = new QName("http://www.epo.org/exchange", "clms-reason-1");
    private final static QName _ClaimRemark_QNAME = new QName("http://www.epo.org/exchange", "claim-remark");
    private final static QName _ClaimNum_QNAME = new QName("http://www.epo.org/exchange", "claim-num");
    private final static QName _SrepBasis_QNAME = new QName("http://www.epo.org/exchange", "srep-basis");
    private final static QName _SequenceListBasis_QNAME = new QName("http://www.epo.org/exchange", "sequence-list-basis");
    private final static QName _PresentationOfStatements_QNAME = new QName("http://www.epo.org/exchange", "presentation-of-statements");
    private final static QName _MaterialOfSequenceList_QNAME = new QName("http://www.epo.org/exchange", "material-of-sequence-list");
    private final static QName _SrepRequestNumber_QNAME = new QName("http://www.epo.org/exchange", "srep-request-number");
    private final static QName _SrepRequestDate_QNAME = new QName("http://www.epo.org/exchange", "srep-request-date");
    private final static QName _DateOfEarliestPriority_QNAME = new QName("http://www.epo.org/exchange", "date-of-earliest-priority");
    private final static QName _FileReferenceId_QNAME = new QName("http://www.epo.org/exchange", "file-reference-id");
    private final static QName _FamilyMember_QNAME = new QName("http://www.epo.org/exchange", "family-member");
    private final static QName _CorrectionNotice_QNAME = new QName("http://www.epo.org/exchange", "correction-notice");
    private final static QName _RepublicationNotes_QNAME = new QName("http://www.epo.org/exchange", "republication-notes");
    private final static QName _Modifications_QNAME = new QName("http://www.epo.org/exchange", "modifications");
    private final static QName _ModifiedPartName_QNAME = new QName("http://www.epo.org/exchange", "modified-part-name");
    private final static QName _ModifiedBibliography_QNAME = new QName("http://www.epo.org/exchange", "modified-bibliography");
    private final static QName _CancellationDate_QNAME = new QName("http://www.epo.org/exchange", "cancellation-date");
    private final static QName _RepublicationCode_QNAME = new QName("http://www.epo.org/exchange", "republication-code");
    private final static QName _TypeOfCorrection_QNAME = new QName("http://www.epo.org/exchange", "type-of-correction");
    private final static QName _CorrespondingDocs_QNAME = new QName("http://www.epo.org/exchange", "corresponding-docs");
    private final static QName _PriorityClaims_QNAME = new QName("http://www.epo.org/exchange", "priority-claims");
    private final static QName _PriorityActiveIndicator_QNAME = new QName("http://www.epo.org/exchange", "priority-active-indicator");
    private final static QName _PriorityLinkageType_QNAME = new QName("http://www.epo.org/exchange", "priority-linkage-type");
    private final static QName _PriorityDocAttached_QNAME = new QName("http://www.epo.org/exchange", "priority-doc-attached");
    private final static QName _PriorityDocRequested_QNAME = new QName("http://www.epo.org/exchange", "priority-doc-requested");
    private final static QName _OfficeOfFiling_QNAME = new QName("http://www.epo.org/exchange", "office-of-filing");
    private final static QName _Parties_QNAME = new QName("http://www.epo.org/exchange", "parties");
    private final static QName _Agents_QNAME = new QName("http://www.epo.org/exchange", "agents");
    private final static QName _CorrespondenceAddress_QNAME = new QName("http://www.epo.org/exchange", "correspondence-address");
    private final static QName _CustomerNumber_QNAME = new QName("http://www.epo.org/exchange", "customer-number");
    private final static QName _Inventors_QNAME = new QName("http://www.epo.org/exchange", "inventors");
    private final static QName _Inventor_QNAME = new QName("http://www.epo.org/exchange", "inventor");
    private final static QName _Applicants_QNAME = new QName("http://www.epo.org/exchange", "applicants");
    private final static QName _DesignatedStatesAsInventor_QNAME = new QName("http://www.epo.org/exchange", "designated-states-as-inventor");
    private final static QName _DesignatedStates_QNAME = new QName("http://www.epo.org/exchange", "designated-states");
    private final static QName _Residence_QNAME = new QName("http://www.epo.org/exchange", "residence");
    private final static QName _Nationality_QNAME = new QName("http://www.epo.org/exchange", "nationality");
    private final static QName _DesignationEpc_QNAME = new QName("http://www.epo.org/exchange", "designation-epc");
    private final static QName _ExtensionStates_QNAME = new QName("http://www.epo.org/exchange", "extension-states");
    private final static QName _ContractingStates_QNAME = new QName("http://www.epo.org/exchange", "contracting-states");
    private final static QName _ExclusionFromDesignation_QNAME = new QName("http://www.epo.org/exchange", "exclusion-from-designation");
    private final static QName _PrecautionaryDesignationStatement_QNAME = new QName("http://www.epo.org/exchange", "precautionary-designation-statement");
    private final static QName _DesignationPct_QNAME = new QName("http://www.epo.org/exchange", "designation-pct");
    private final static QName _NewDesignationCountry_QNAME = new QName("http://www.epo.org/exchange", "new-designation-country");
    private final static QName _National_QNAME = new QName("http://www.epo.org/exchange", "national");
    private final static QName _Regional_QNAME = new QName("http://www.epo.org/exchange", "regional");
    private final static QName _AnyOtherState_QNAME = new QName("http://www.epo.org/exchange", "any-other-state");
    private final static QName _ProtectionRequest_QNAME = new QName("http://www.epo.org/exchange", "protection-request");
    private final static QName _KindOfProtection_QNAME = new QName("http://www.epo.org/exchange", "kind-of-protection");
    private final static QName _Region_QNAME = new QName("http://www.epo.org/exchange", "region");
    private final static QName _TermOfGrant_QNAME = new QName("http://www.epo.org/exchange", "term-of-grant");
    private final static QName _LapseOfPatent_QNAME = new QName("http://www.epo.org/exchange", "lapse-of-patent");
    private final static QName _LengthOfGrant_QNAME = new QName("http://www.epo.org/exchange", "length-of-grant");
    private final static QName _Disclaimer_QNAME = new QName("http://www.epo.org/exchange", "disclaimer");
    private final static QName _CombinationRank_QNAME = new QName("http://www.epo.org/exchange", "combination-rank");
    private final static QName _UnlinkedIndexingCode_QNAME = new QName("http://www.epo.org/exchange", "unlinked-indexing-code");
    private final static QName _LinkedIndexingCodeGroup_QNAME = new QName("http://www.epo.org/exchange", "linked-indexing-code-group");
    private final static QName _SubLinkedIndexingCode_QNAME = new QName("http://www.epo.org/exchange", "sub-linked-indexing-code");
    private final static QName _MainLinkedIndexingCode_QNAME = new QName("http://www.epo.org/exchange", "main-linked-indexing-code");
    private final static QName _AdditionalInfo_QNAME = new QName("http://www.epo.org/exchange", "additional-info");
    private final static QName _MainClassification_QNAME = new QName("http://www.epo.org/exchange", "main-classification");
    private final static QName _GeneratingOffice_QNAME = new QName("http://www.epo.org/exchange", "generating-office");
    private final static QName _ClassificationDataSource_QNAME = new QName("http://www.epo.org/exchange", "classification-data-source");
    private final static QName _ClassificationStatus_QNAME = new QName("http://www.epo.org/exchange", "classification-status");
    private final static QName _ActionDate_QNAME = new QName("http://www.epo.org/exchange", "action-date");
    private final static QName _ClassificationValue_QNAME = new QName("http://www.epo.org/exchange", "classification-value");
    private final static QName _SymbolPosition_QNAME = new QName("http://www.epo.org/exchange", "symbol-position");
    private final static QName _ClassificationLevel_QNAME = new QName("http://www.epo.org/exchange", "classification-level");
    private final static QName _IpcVersionIndicator_QNAME = new QName("http://www.epo.org/exchange", "ipc-version-indicator");
    private final static QName _Subgroup_QNAME = new QName("http://www.epo.org/exchange", "subgroup");
    private final static QName _MainGroup_QNAME = new QName("http://www.epo.org/exchange", "main-group");
    private final static QName _Subclass_QNAME = new QName("http://www.epo.org/exchange", "subclass");
    private final static QName _Section_QNAME = new QName("http://www.epo.org/exchange", "section");
    private final static QName _P_QNAME = new QName("http://www.epo.org/exchange", "p");
    private final static QName _AbstSolution_QNAME = new QName("http://www.epo.org/exchange", "abst-solution");
    private final static QName _AbstProblem_QNAME = new QName("http://www.epo.org/exchange", "abst-problem");
    private final static QName _Dd_QNAME = new QName("http://www.epo.org/exchange", "dd");
    private final static QName _Math_QNAME = new QName("http://www.epo.org/exchange", "math");
    private final static QName _Term_QNAME = new QName("http://www.epo.org/exchange", "term");
    private final static QName _BioAccno_QNAME = new QName("http://www.epo.org/exchange", "bio-accno");
    private final static QName _Depositary_QNAME = new QName("http://www.epo.org/exchange", "depositary");
    private final static QName _Othercit_QNAME = new QName("http://www.epo.org/exchange", "othercit");
    private final static QName _Online_QNAME = new QName("http://www.epo.org/exchange", "online");
    private final static QName _Srchdate_QNAME = new QName("http://www.epo.org/exchange", "srchdate");
    private final static QName _Srchterm_QNAME = new QName("http://www.epo.org/exchange", "srchterm");
    private final static QName _Datecit_QNAME = new QName("http://www.epo.org/exchange", "datecit");
    private final static QName _Avail_QNAME = new QName("http://www.epo.org/exchange", "avail");
    private final static QName _Hostno_QNAME = new QName("http://www.epo.org/exchange", "hostno");
    private final static QName _History_QNAME = new QName("http://www.epo.org/exchange", "history");
    private final static QName _Misc_QNAME = new QName("http://www.epo.org/exchange", "misc");
    private final static QName _Revised_QNAME = new QName("http://www.epo.org/exchange", "revised");
    private final static QName _Accepted_QNAME = new QName("http://www.epo.org/exchange", "accepted");
    private final static QName _Received_QNAME = new QName("http://www.epo.org/exchange", "received");
    private final static QName _Hosttitle_QNAME = new QName("http://www.epo.org/exchange", "hosttitle");
    private final static QName _OnlineTitle_QNAME = new QName("http://www.epo.org/exchange", "online-title");
    private final static QName _Article_QNAME = new QName("http://www.epo.org/exchange", "article");
    private final static QName _Artid_QNAME = new QName("http://www.epo.org/exchange", "artid");
    private final static QName _Book_QNAME = new QName("http://www.epo.org/exchange", "book");
    private final static QName _Keyword_QNAME = new QName("http://www.epo.org/exchange", "keyword");
    private final static QName _Bookno_QNAME = new QName("http://www.epo.org/exchange", "bookno");
    private final static QName _Location_QNAME = new QName("http://www.epo.org/exchange", "location");
    private final static QName _Line_QNAME = new QName("http://www.epo.org/exchange", "line");
    private final static QName _Linel_QNAME = new QName("http://www.epo.org/exchange", "linel");
    private final static QName _Linef_QNAME = new QName("http://www.epo.org/exchange", "linef");
    private final static QName _Para_QNAME = new QName("http://www.epo.org/exchange", "para");
    private final static QName _Paral_QNAME = new QName("http://www.epo.org/exchange", "paral");
    private final static QName _Paraf_QNAME = new QName("http://www.epo.org/exchange", "paraf");
    private final static QName _Column_QNAME = new QName("http://www.epo.org/exchange", "column");
    private final static QName _Coll_QNAME = new QName("http://www.epo.org/exchange", "coll");
    private final static QName _Colf_QNAME = new QName("http://www.epo.org/exchange", "colf");
    private final static QName _Pp_QNAME = new QName("http://www.epo.org/exchange", "pp");
    private final static QName _Ppl_QNAME = new QName("http://www.epo.org/exchange", "ppl");
    private final static QName _Ppf_QNAME = new QName("http://www.epo.org/exchange", "ppf");
    private final static QName _Chapter_QNAME = new QName("http://www.epo.org/exchange", "chapter");
    private final static QName _Sersect_QNAME = new QName("http://www.epo.org/exchange", "sersect");
    private final static QName _Serpart_QNAME = new QName("http://www.epo.org/exchange", "serpart");
    private final static QName _Absno_QNAME = new QName("http://www.epo.org/exchange", "absno");
    private final static QName _Series_QNAME = new QName("http://www.epo.org/exchange", "series");
    private final static QName _Msn_QNAME = new QName("http://www.epo.org/exchange", "msn");
    private final static QName _Mst_QNAME = new QName("http://www.epo.org/exchange", "mst");
    private final static QName _Edition_QNAME = new QName("http://www.epo.org/exchange", "edition");
    private final static QName _Subtitle_QNAME = new QName("http://www.epo.org/exchange", "subtitle");
    private final static QName _Conference_QNAME = new QName("http://www.epo.org/exchange", "conference");
    private final static QName _Confsponsor_QNAME = new QName("http://www.epo.org/exchange", "confsponsor");
    private final static QName _Confplace_QNAME = new QName("http://www.epo.org/exchange", "confplace");
    private final static QName _Confno_QNAME = new QName("http://www.epo.org/exchange", "confno");
    private final static QName _Conftitle_QNAME = new QName("http://www.epo.org/exchange", "conftitle");
    private final static QName _BookTitle_QNAME = new QName("http://www.epo.org/exchange", "book-title");
    private final static QName _Serial_QNAME = new QName("http://www.epo.org/exchange", "serial");
    private final static QName _Cpyrt_QNAME = new QName("http://www.epo.org/exchange", "cpyrt");
    private final static QName _Isbn_QNAME = new QName("http://www.epo.org/exchange", "isbn");
    private final static QName _Issn_QNAME = new QName("http://www.epo.org/exchange", "issn");
    private final static QName _Ino_QNAME = new QName("http://www.epo.org/exchange", "ino");
    private final static QName _Doi_QNAME = new QName("http://www.epo.org/exchange", "doi");
    private final static QName _Vid_QNAME = new QName("http://www.epo.org/exchange", "vid");
    private final static QName _Pubid_QNAME = new QName("http://www.epo.org/exchange", "pubid");
    private final static QName _Notes_QNAME = new QName("http://www.epo.org/exchange", "notes");
    private final static QName _Descrip_QNAME = new QName("http://www.epo.org/exchange", "descrip");
    private final static QName _Imprint_QNAME = new QName("http://www.epo.org/exchange", "imprint");
    private final static QName _Pubdate_QNAME = new QName("http://www.epo.org/exchange", "pubdate");
    private final static QName _Time_QNAME = new QName("http://www.epo.org/exchange", "time");
    private final static QName _Edate_QNAME = new QName("http://www.epo.org/exchange", "edate");
    private final static QName _Sdate_QNAME = new QName("http://www.epo.org/exchange", "sdate");
    private final static QName _Issue_QNAME = new QName("http://www.epo.org/exchange", "issue");
    private final static QName _Alttitle_QNAME = new QName("http://www.epo.org/exchange", "alttitle");
    private final static QName _Sertitle_QNAME = new QName("http://www.epo.org/exchange", "sertitle");
    private final static QName _Atl_QNAME = new QName("http://www.epo.org/exchange", "atl");
    private final static QName _Dtext_QNAME = new QName("http://www.epo.org/exchange", "dtext");
    private final static QName _Ead_QNAME = new QName("http://www.epo.org/exchange", "ead");
    private final static QName _Url_QNAME = new QName("http://www.epo.org/exchange", "url");
    private final static QName _Email_QNAME = new QName("http://www.epo.org/exchange", "email");
    private final static QName _Fax_QNAME = new QName("http://www.epo.org/exchange", "fax");
    private final static QName _Phone_QNAME = new QName("http://www.epo.org/exchange", "phone");
    private final static QName _Address_QNAME = new QName("http://www.epo.org/exchange", "address");
    private final static QName _Postcode_QNAME = new QName("http://www.epo.org/exchange", "postcode");
    private final static QName _State_QNAME = new QName("http://www.epo.org/exchange", "state");
    private final static QName _County_QNAME = new QName("http://www.epo.org/exchange", "county");
    private final static QName _City_QNAME = new QName("http://www.epo.org/exchange", "city");
    private final static QName _Street_QNAME = new QName("http://www.epo.org/exchange", "street");
    private final static QName _Building_QNAME = new QName("http://www.epo.org/exchange", "building");
    private final static QName _AddressFloor_QNAME = new QName("http://www.epo.org/exchange", "address-floor");
    private final static QName _Room_QNAME = new QName("http://www.epo.org/exchange", "room");
    private final static QName _Pobox_QNAME = new QName("http://www.epo.org/exchange", "pobox");
    private final static QName _Mailcode_QNAME = new QName("http://www.epo.org/exchange", "mailcode");
    private final static QName _Address3_QNAME = new QName("http://www.epo.org/exchange", "address-3");
    private final static QName _Address2_QNAME = new QName("http://www.epo.org/exchange", "address-2");
    private final static QName _Address1_QNAME = new QName("http://www.epo.org/exchange", "address-1");
    private final static QName _RegisteredNumber_QNAME = new QName("http://www.epo.org/exchange", "registered-number");
    private final static QName _Synonym_QNAME = new QName("http://www.epo.org/exchange", "synonym");
    private final static QName _Department_QNAME = new QName("http://www.epo.org/exchange", "department");
    private final static QName _Suffix_QNAME = new QName("http://www.epo.org/exchange", "suffix");
    private final static QName _Prefix_QNAME = new QName("http://www.epo.org/exchange", "prefix");
    private final static QName _Role_QNAME = new QName("http://www.epo.org/exchange", "role");
    private final static QName _Iid_QNAME = new QName("http://www.epo.org/exchange", "iid");
    private final static QName _Orgname_QNAME = new QName("http://www.epo.org/exchange", "orgname");
    private final static QName _MiddleName_QNAME = new QName("http://www.epo.org/exchange", "middle-name");
    private final static QName _FirstName_QNAME = new QName("http://www.epo.org/exchange", "first-name");
    private final static QName _LastName_QNAME = new QName("http://www.epo.org/exchange", "last-name");
    private final static QName _RelPassage_QNAME = new QName("http://www.epo.org/exchange", "rel-passage");
    private final static QName _RelClaims_QNAME = new QName("http://www.epo.org/exchange", "rel-claims");
    private final static QName _Category_QNAME = new QName("http://www.epo.org/exchange", "category");
    private final static QName _Passage_QNAME = new QName("http://www.epo.org/exchange", "passage");
    private final static QName _Kind_QNAME = new QName("http://www.epo.org/exchange", "kind");
    private final static QName _DocNumber_QNAME = new QName("http://www.epo.org/exchange", "doc-number");
    private final static QName _Country_QNAME = new QName("http://www.epo.org/exchange", "country");
    private final static QName _Pre_QNAME = new QName("http://www.epo.org/exchange", "pre");
    private final static QName _Br_QNAME = new QName("http://www.epo.org/exchange", "br");
    private final static QName _B_QNAME = new QName("http://www.epo.org/exchange", "b");
    private final static QName _I_QNAME = new QName("http://www.epo.org/exchange", "i");
    private final static QName _Smallcaps_QNAME = new QName("http://www.epo.org/exchange", "smallcaps");
    private final static QName _Sup_QNAME = new QName("http://www.epo.org/exchange", "sup");
    private final static QName _Sub_QNAME = new QName("http://www.epo.org/exchange", "sub");
    private final static QName _Sub2_QNAME = new QName("http://www.epo.org/exchange", "sub2");
    private final static QName _Sup2_QNAME = new QName("http://www.epo.org/exchange", "sup2");
    private final static QName _RangedateTypeSdate_QNAME = new QName("", "sdate");
    private final static QName _RangedateTypeEdate_QNAME = new QName("", "edate");
    private final static QName _RangedateTypeTime_QNAME = new QName("", "time");
    private final static QName _PTypeB_QNAME = new QName("", "b");
    private final static QName _PTypeI_QNAME = new QName("", "i");
    private final static QName _PTypeU_QNAME = new QName("", "u");
    private final static QName _PTypeSup_QNAME = new QName("", "sup");
    private final static QName _PTypeSub_QNAME = new QName("", "sub");
    private final static QName _PTypeSmallcaps_QNAME = new QName("", "smallcaps");
    private final static QName _PTypeBr_QNAME = new QName("", "br");
    private final static QName _PTypePre_QNAME = new QName("", "pre");
    private final static QName _PTypeDl_QNAME = new QName("", "dl");
    private final static QName _PTypeUl_QNAME = new QName("", "ul");
    private final static QName _PTypeOl_QNAME = new QName("", "ol");
    private final static QName _PTypeCrossref_QNAME = new QName("", "crossref");
    private final static QName _PTypeFigref_QNAME = new QName("", "figref");
    private final static QName _PTypePatcit_QNAME = new QName("", "patcit");
    private final static QName _PTypeNplcit_QNAME = new QName("", "nplcit");
    private final static QName _PTypeBioDeposit_QNAME = new QName("", "bio-deposit");
    private final static QName _PTypeImg_QNAME = new QName("", "img");
    private final static QName _PTypeChemistry_QNAME = new QName("", "chemistry");
    private final static QName _PTypeMaths_QNAME = new QName("", "maths");
    private final static QName _PTypeTables_QNAME = new QName("", "tables");
    private final static QName _PTypeTableExternalDoc_QNAME = new QName("", "table-external-doc");
    private final static QName _Sup2TypeO_QNAME = new QName("", "o");
    private final static QName _SubTypeSup2_QNAME = new QName("", "sup2");
    private final static QName _SubTypeSub2_QNAME = new QName("", "sub2");
    private final static QName _PassageTypePp_QNAME = new QName("", "pp");
    private final static QName _PassageTypePpf_QNAME = new QName("", "ppf");
    private final static QName _PassageTypePpl_QNAME = new QName("", "ppl");
    private final static QName _PassageTypeColumn_QNAME = new QName("", "column");
    private final static QName _PassageTypeColf_QNAME = new QName("", "colf");
    private final static QName _PassageTypeColl_QNAME = new QName("", "coll");
    private final static QName _PassageTypePara_QNAME = new QName("", "para");
    private final static QName _PassageTypeParaf_QNAME = new QName("", "paraf");
    private final static QName _PassageTypeParal_QNAME = new QName("", "paral");
    private final static QName _PassageTypeLine_QNAME = new QName("", "line");
    private final static QName _PassageTypeLinef_QNAME = new QName("", "linef");
    private final static QName _PassageTypeLinel_QNAME = new QName("", "linel");
    private final static QName _PassageTypeClaim_QNAME = new QName("", "claim");
    private final static QName _PassageTypeFigure_QNAME = new QName("", "figure");
    private final static QName _PassageTypeExample_QNAME = new QName("", "example");
    private final static QName _PassageTypeTable_QNAME = new QName("", "table");
    private final static QName _PassageTypeSequence_QNAME = new QName("", "sequence");
    private final static QName _PassageTypeCompound_QNAME = new QName("", "compound");
    private final static QName _PassageTypeBookmark_QNAME = new QName("", "bookmark");
    private final static QName _ConfplaceTypeAddress_QNAME = new QName("", "address");
    private final static QName _ConfsponsorTypeAddressbook_QNAME = new QName("", "addressbook");
    private final static QName _MiscTypeDate_QNAME = new QName("", "date");
    private final static QName _OfficeOfFilingTypeRegion_QNAME = new QName("", "region");
    private final static QName _OfficeOfFilingTypeCountry_QNAME = new QName("", "country");
    private final static QName _AuthorizedOfficerTypeName_QNAME = new QName("", "name");
    private final static QName _AuthorizedOfficerTypePrefix_QNAME = new QName("", "prefix");
    private final static QName _AuthorizedOfficerTypeLastName_QNAME = new QName("", "last-name");
    private final static QName _AuthorizedOfficerTypeOrgname_QNAME = new QName("", "orgname");
    private final static QName _AuthorizedOfficerTypeFirstName_QNAME = new QName("", "first-name");
    private final static QName _AuthorizedOfficerTypeMiddleName_QNAME = new QName("", "middle-name");
    private final static QName _AuthorizedOfficerTypeSuffix_QNAME = new QName("", "suffix");
    private final static QName _AuthorizedOfficerTypeIid_QNAME = new QName("", "iid");
    private final static QName _AuthorizedOfficerTypeRole_QNAME = new QName("", "role");
    private final static QName _AuthorizedOfficerTypeDepartment_QNAME = new QName("", "department");
    private final static QName _AuthorizedOfficerTypeSynonym_QNAME = new QName("", "synonym");
    private final static QName _AuthorizedOfficerTypeRegisteredNumber_QNAME = new QName("", "registered-number");
    private final static QName _AuthorizedOfficerTypePhone_QNAME = new QName("", "phone");
    private final static QName _AuthorizedOfficerTypeFax_QNAME = new QName("", "fax");
    private final static QName _AuthorizedOfficerTypeEmail_QNAME = new QName("", "email");
    private final static QName _AuthorizedOfficerTypeElectronicSignature_QNAME = new QName("", "electronic-signature");
    private final static QName _AddressbookTypeUrl_QNAME = new QName("", "url");
    private final static QName _AddressbookTypeEad_QNAME = new QName("", "ead");
    private final static QName _AddressbookTypeDtext_QNAME = new QName("", "dtext");
    private final static QName _AddressbookTypeText_QNAME = new QName("", "text");
    private final static QName _ChemistryTypeChem_QNAME = new QName("", "chem");
    private final static QName _CnTypeMglyph_QNAME = new QName("", "mglyph");
    private final static QName _CnTypeSep_QNAME = new QName("", "sep");
    private final static QName _CnTypeMi_QNAME = new QName("", "mi");
    private final static QName _CnTypeMn_QNAME = new QName("", "mn");
    private final static QName _CnTypeMo_QNAME = new QName("", "mo");
    private final static QName _CnTypeMtext_QNAME = new QName("", "mtext");
    private final static QName _CnTypeMs_QNAME = new QName("", "ms");
    private final static QName _CnTypeMspace_QNAME = new QName("", "mspace");
    private final static QName _CnTypeMrow_QNAME = new QName("", "mrow");
    private final static QName _CnTypeMfrac_QNAME = new QName("", "mfrac");
    private final static QName _CnTypeMsqrt_QNAME = new QName("", "msqrt");
    private final static QName _CnTypeMroot_QNAME = new QName("", "mroot");
    private final static QName _CnTypeMenclose_QNAME = new QName("", "menclose");
    private final static QName _CnTypeMstyle_QNAME = new QName("", "mstyle");
    private final static QName _CnTypeMerror_QNAME = new QName("", "merror");
    private final static QName _CnTypeMpadded_QNAME = new QName("", "mpadded");
    private final static QName _CnTypeMphantom_QNAME = new QName("", "mphantom");
    private final static QName _CnTypeMfenced_QNAME = new QName("", "mfenced");
    private final static QName _CnTypeMsub_QNAME = new QName("", "msub");
    private final static QName _CnTypeMsup_QNAME = new QName("", "msup");
    private final static QName _CnTypeMsubsup_QNAME = new QName("", "msubsup");
    private final static QName _CnTypeMunder_QNAME = new QName("", "munder");
    private final static QName _CnTypeMover_QNAME = new QName("", "mover");
    private final static QName _CnTypeMunderover_QNAME = new QName("", "munderover");
    private final static QName _CnTypeMmultiscripts_QNAME = new QName("", "mmultiscripts");
    private final static QName _CnTypeMtable_QNAME = new QName("", "mtable");
    private final static QName _CnTypeMtr_QNAME = new QName("", "mtr");
    private final static QName _CnTypeMlabeledtr_QNAME = new QName("", "mlabeledtr");
    private final static QName _CnTypeMtd_QNAME = new QName("", "mtd");
    private final static QName _CnTypeMaligngroup_QNAME = new QName("", "maligngroup");
    private final static QName _CnTypeMalignmark_QNAME = new QName("", "malignmark");
    private final static QName _CnTypeMaction_QNAME = new QName("", "maction");
    private final static QName _MathsTypeMath_QNAME = new QName("", "math");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.jaxb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PatentClassificationType }
     * 
     */
    public PatentClassificationType createPatentClassificationType() {
        return new PatentClassificationType();
    }

    /**
     * Create an instance of {@link ExchangeDocument }
     * 
     */
    public ExchangeDocument createExchangeDocument() {
        return new ExchangeDocument();
    }

    /**
     * Create an instance of {@link BibliographicDataType }
     * 
     */
    public BibliographicDataType createBibliographicDataType() {
        return new BibliographicDataType();
    }

    /**
     * Create an instance of {@link AbstractType }
     * 
     */
    public AbstractType createAbstractType() {
        return new AbstractType();
    }

    /**
     * Create an instance of {@link PatentFamilyType }
     * 
     */
    public PatentFamilyType createPatentFamilyType() {
        return new PatentFamilyType();
    }

    /**
     * Create an instance of {@link SearchReportDataType }
     * 
     */
    public SearchReportDataType createSearchReportDataType() {
        return new SearchReportDataType();
    }

    /**
     * Create an instance of {@link PriorityDateType }
     * 
     */
    public PriorityDateType createPriorityDateType() {
        return new PriorityDateType();
    }

    /**
     * Create an instance of {@link ComplianceUnityInventionType }
     * 
     */
    public ComplianceUnityInventionType createComplianceUnityInventionType() {
        return new ComplianceUnityInventionType();
    }

    /**
     * Create an instance of {@link InvitationPayAdditionalFeesType }
     * 
     */
    public InvitationPayAdditionalFeesType createInvitationPayAdditionalFeesType() {
        return new InvitationPayAdditionalFeesType();
    }

    /**
     * Create an instance of {@link SequenceListingComputerReadableFormType }
     * 
     */
    public SequenceListingComputerReadableFormType createSequenceListingComputerReadableFormType() {
        return new SequenceListingComputerReadableFormType();
    }

    /**
     * Create an instance of {@link SequenceListingWrittenFormType }
     * 
     */
    public SequenceListingWrittenFormType createSequenceListingWrittenFormType() {
        return new SequenceListingWrittenFormType();
    }

    /**
     * Create an instance of {@link PriorityOpinionType }
     * 
     */
    public PriorityOpinionType createPriorityOpinionType() {
        return new PriorityOpinionType();
    }

    /**
     * Create an instance of {@link EarlierApplType }
     * 
     */
    public EarlierApplType createEarlierApplType() {
        return new EarlierApplType();
    }

    /**
     * Create an instance of {@link TranslationOfApplType }
     * 
     */
    public TranslationOfApplType createTranslationOfApplType() {
        return new TranslationOfApplType();
    }

    /**
     * Create an instance of {@link SrepPatentFamilyType }
     * 
     */
    public SrepPatentFamilyType createSrepPatentFamilyType() {
        return new SrepPatentFamilyType();
    }

    /**
     * Create an instance of {@link SrepInformationType }
     * 
     */
    public SrepInformationType createSrepInformationType() {
        return new SrepInformationType();
    }

    /**
     * Create an instance of {@link ElectronicSignatureType }
     * 
     */
    public ElectronicSignatureType createElectronicSignatureType() {
        return new ElectronicSignatureType();
    }

    /**
     * Create an instance of {@link FaxImageType }
     * 
     */
    public FaxImageType createFaxImageType() {
        return new FaxImageType();
    }

    /**
     * Create an instance of {@link SrepFigureToPublishType }
     * 
     */
    public SrepFigureToPublishType createSrepFigureToPublishType() {
        return new SrepFigureToPublishType();
    }

    /**
     * Create an instance of {@link SearchFeeProtestType }
     * 
     */
    public SearchFeeProtestType createSearchFeeProtestType() {
        return new SearchFeeProtestType();
    }

    /**
     * Create an instance of {@link SequenceListingFilingTimeType }
     * 
     */
    public SequenceListingFilingTimeType createSequenceListingFilingTimeType() {
        return new SequenceListingFilingTimeType();
    }

    /**
     * Create an instance of {@link SequenceListingMaterialFormatType }
     * 
     */
    public SequenceListingMaterialFormatType createSequenceListingMaterialFormatType() {
        return new SequenceListingMaterialFormatType();
    }

    /**
     * Create an instance of {@link SequenceListingMaterialTypeType }
     * 
     */
    public SequenceListingMaterialTypeType createSequenceListingMaterialTypeType() {
        return new SequenceListingMaterialTypeType();
    }

    /**
     * Create an instance of {@link BasisLanguageForSearchType }
     * 
     */
    public BasisLanguageForSearchType createBasisLanguageForSearchType() {
        return new BasisLanguageForSearchType();
    }

    /**
     * Create an instance of {@link SrepPriorArtDocsType }
     * 
     */
    public SrepPriorArtDocsType createSrepPriorArtDocsType() {
        return new SrepPriorArtDocsType();
    }

    /**
     * Create an instance of {@link PriorArtXmlDocType }
     * 
     */
    public PriorArtXmlDocType createPriorArtXmlDocType() {
        return new PriorArtXmlDocType();
    }

    /**
     * Create an instance of {@link SrepProtestFeesType }
     * 
     */
    public SrepProtestFeesType createSrepProtestFeesType() {
        return new SrepProtestFeesType();
    }

    /**
     * Create an instance of {@link SrepEstablishedType }
     * 
     */
    public SrepEstablishedType createSrepEstablishedType() {
        return new SrepEstablishedType();
    }

    /**
     * Create an instance of {@link St50RepublicationType }
     * 
     */
    public St50RepublicationType createSt50RepublicationType() {
        return new St50RepublicationType();
    }

    /**
     * Create an instance of {@link RepublicationNoteType }
     * 
     */
    public RepublicationNoteType createRepublicationNoteType() {
        return new RepublicationNoteType();
    }

    /**
     * Create an instance of {@link ModifiedPartType }
     * 
     */
    public ModifiedPartType createModifiedPartType() {
        return new ModifiedPartType();
    }

    /**
     * Create an instance of {@link ModifiedItemType }
     * 
     */
    public ModifiedItemType createModifiedItemType() {
        return new ModifiedItemType();
    }

    /**
     * Create an instance of {@link InidCodeType }
     * 
     */
    public InidCodeType createInidCodeType() {
        return new InidCodeType();
    }

    /**
     * Create an instance of {@link ReferencesCitedType }
     * 
     */
    public ReferencesCitedType createReferencesCitedType() {
        return new ReferencesCitedType();
    }

    /**
     * Create an instance of {@link CitationType }
     * 
     */
    public CitationType createCitationType() {
        return new CitationType();
    }

    /**
     * Create an instance of {@link PriorityClaimType }
     * 
     */
    public PriorityClaimType createPriorityClaimType() {
        return new PriorityClaimType();
    }

    /**
     * Create an instance of {@link AgentType }
     * 
     */
    public AgentType createAgentType() {
        return new AgentType();
    }

    /**
     * Create an instance of {@link DeceasedInventorType }
     * 
     */
    public DeceasedInventorType createDeceasedInventorType() {
        return new DeceasedInventorType();
    }

    /**
     * Create an instance of {@link InventorNameType }
     * 
     */
    public InventorNameType createInventorNameType() {
        return new InventorNameType();
    }

    /**
     * Create an instance of {@link ApplicantType }
     * 
     */
    public ApplicantType createApplicantType() {
        return new ApplicantType();
    }

    /**
     * Create an instance of {@link UsRightsType }
     * 
     */
    public UsRightsType createUsRightsType() {
        return new UsRightsType();
    }

    /**
     * Create an instance of {@link ApplicantNameType }
     * 
     */
    public ApplicantNameType createApplicantNameType() {
        return new ApplicantNameType();
    }

    /**
     * Create an instance of {@link InventionTitleType }
     * 
     */
    public InventionTitleType createInventionTitleType() {
        return new InventionTitleType();
    }

    /**
     * Create an instance of {@link ExtendedKindCode }
     * 
     */
    public ExtendedKindCode createExtendedKindCode() {
        return new ExtendedKindCode();
    }

    /**
     * Create an instance of {@link DesignationOfStatesType }
     * 
     */
    public DesignationOfStatesType createDesignationOfStatesType() {
        return new DesignationOfStatesType();
    }

    /**
     * Create an instance of {@link DatesOfPublicAvailability }
     * 
     */
    public DatesOfPublicAvailability createDatesOfPublicAvailability() {
        return new DatesOfPublicAvailability();
    }

    /**
     * Create an instance of {@link ExchangeGazetteReferenceType }
     * 
     */
    public ExchangeGazetteReferenceType createExchangeGazetteReferenceType() {
        return new ExchangeGazetteReferenceType();
    }

    /**
     * Create an instance of {@link AbstractReferenceType }
     * 
     */
    public AbstractReferenceType createAbstractReferenceType() {
        return new AbstractReferenceType();
    }

    /**
     * Create an instance of {@link SupplementalSrepPub }
     * 
     */
    public SupplementalSrepPub createSupplementalSrepPub() {
        return new SupplementalSrepPub();
    }

    /**
     * Create an instance of {@link GazettePubAnnouncement }
     * 
     */
    public GazettePubAnnouncement createGazettePubAnnouncement() {
        return new GazettePubAnnouncement();
    }

    /**
     * Create an instance of {@link GazetteNumType }
     * 
     */
    public GazetteNumType createGazetteNumType() {
        return new GazetteNumType();
    }

    /**
     * Create an instance of {@link TextType }
     * 
     */
    public TextType createTextType() {
        return new TextType();
    }

    /**
     * Create an instance of {@link ModifiedFirstPagePubType }
     * 
     */
    public ModifiedFirstPagePubType createModifiedFirstPagePubType() {
        return new ModifiedFirstPagePubType();
    }

    /**
     * Create an instance of {@link ModifiedCompleteSpecPubType }
     * 
     */
    public ModifiedCompleteSpecPubType createModifiedCompleteSpecPubType() {
        return new ModifiedCompleteSpecPubType();
    }

    /**
     * Create an instance of {@link UnexaminedNotPrintedWithoutGrantType }
     * 
     */
    public UnexaminedNotPrintedWithoutGrantType createUnexaminedNotPrintedWithoutGrantType() {
        return new UnexaminedNotPrintedWithoutGrantType();
    }

    /**
     * Create an instance of {@link ExaminedNotPrintedWithoutGrantType }
     * 
     */
    public ExaminedNotPrintedWithoutGrantType createExaminedNotPrintedWithoutGrantType() {
        return new ExaminedNotPrintedWithoutGrantType();
    }

    /**
     * Create an instance of {@link UnexaminedPrintedWithoutGrantType }
     * 
     */
    public UnexaminedPrintedWithoutGrantType createUnexaminedPrintedWithoutGrantType() {
        return new UnexaminedPrintedWithoutGrantType();
    }

    /**
     * Create an instance of {@link ExaminedPrintedWithoutGrantType }
     * 
     */
    public ExaminedPrintedWithoutGrantType createExaminedPrintedWithoutGrantType() {
        return new ExaminedPrintedWithoutGrantType();
    }

    /**
     * Create an instance of {@link PrintedWithGrantType }
     * 
     */
    public PrintedWithGrantType createPrintedWithGrantType() {
        return new PrintedWithGrantType();
    }

    /**
     * Create an instance of {@link ClaimsOnlyAvailableType }
     * 
     */
    public ClaimsOnlyAvailableType createClaimsOnlyAvailableType() {
        return new ClaimsOnlyAvailableType();
    }

    /**
     * Create an instance of {@link NotPrintedWithGrantType }
     * 
     */
    public NotPrintedWithGrantType createNotPrintedWithGrantType() {
        return new NotPrintedWithGrantType();
    }

    /**
     * Create an instance of {@link TermOfGrantType }
     * 
     */
    public TermOfGrantType createTermOfGrantType() {
        return new TermOfGrantType();
    }

    /**
     * Create an instance of {@link InvalidationOfPatentType }
     * 
     */
    public InvalidationOfPatentType createInvalidationOfPatentType() {
        return new InvalidationOfPatentType();
    }

    /**
     * Create an instance of {@link PrintedAsAmendedType }
     * 
     */
    public PrintedAsAmendedType createPrintedAsAmendedType() {
        return new PrintedAsAmendedType();
    }

    /**
     * Create an instance of {@link PatentClassificationsType }
     * 
     */
    public PatentClassificationsType createPatentClassificationsType() {
        return new PatentClassificationsType();
    }

    /**
     * Create an instance of {@link CombinationSetType }
     * 
     */
    public CombinationSetType createCombinationSetType() {
        return new CombinationSetType();
    }

    /**
     * Create an instance of {@link ClassificationIpcType }
     * 
     */
    public ClassificationIpcType createClassificationIpcType() {
        return new ClassificationIpcType();
    }

    /**
     * Create an instance of {@link ApplicationReferenceType }
     * 
     */
    public ApplicationReferenceType createApplicationReferenceType() {
        return new ApplicationReferenceType();
    }

    /**
     * Create an instance of {@link PreviouslyFiledAppType }
     * 
     */
    public PreviouslyFiledAppType createPreviouslyFiledAppType() {
        return new PreviouslyFiledAppType();
    }

    /**
     * Create an instance of {@link DateOfComingIntoForceType }
     * 
     */
    public DateOfComingIntoForceType createDateOfComingIntoForceType() {
        return new DateOfComingIntoForceType();
    }

    /**
     * Create an instance of {@link PrecedingPublicationDateType }
     * 
     */
    public PrecedingPublicationDateType createPrecedingPublicationDateType() {
        return new PrecedingPublicationDateType();
    }

    /**
     * Create an instance of {@link LanguageOfPublicationType }
     * 
     */
    public LanguageOfPublicationType createLanguageOfPublicationType() {
        return new LanguageOfPublicationType();
    }

    /**
     * Create an instance of {@link LanguageOfFilingType }
     * 
     */
    public LanguageOfFilingType createLanguageOfFilingType() {
        return new LanguageOfFilingType();
    }

    /**
     * Create an instance of {@link ClassificationNationalType }
     * 
     */
    public ClassificationNationalType createClassificationNationalType() {
        return new ClassificationNationalType();
    }

    /**
     * Create an instance of {@link FurtherClassificationType }
     * 
     */
    public FurtherClassificationType createFurtherClassificationType() {
        return new FurtherClassificationType();
    }

    /**
     * Create an instance of {@link ClassificationsIpcrType }
     * 
     */
    public ClassificationsIpcrType createClassificationsIpcrType() {
        return new ClassificationsIpcrType();
    }

    /**
     * Create an instance of {@link ClassificationIpcrType }
     * 
     */
    public ClassificationIpcrType createClassificationIpcrType() {
        return new ClassificationIpcrType();
    }

    /**
     * Create an instance of {@link PublicationReferenceType }
     * 
     */
    public PublicationReferenceType createPublicationReferenceType() {
        return new PublicationReferenceType();
    }

    /**
     * Create an instance of {@link TableExternalDocType }
     * 
     */
    public TableExternalDocType createTableExternalDocType() {
        return new TableExternalDocType();
    }

    /**
     * Create an instance of {@link TablesType }
     * 
     */
    public TablesType createTablesType() {
        return new TablesType();
    }

    /**
     * Create an instance of {@link TitleType }
     * 
     */
    public TitleType createTitleType() {
        return new TitleType();
    }

    /**
     * Create an instance of {@link TgroupType }
     * 
     */
    public TgroupType createTgroupType() {
        return new TgroupType();
    }

    /**
     * Create an instance of {@link ColspecType }
     * 
     */
    public ColspecType createColspecType() {
        return new ColspecType();
    }

    /**
     * Create an instance of {@link TheadType }
     * 
     */
    public TheadType createTheadType() {
        return new TheadType();
    }

    /**
     * Create an instance of {@link TbodyType }
     * 
     */
    public TbodyType createTbodyType() {
        return new TbodyType();
    }

    /**
     * Create an instance of {@link RowType }
     * 
     */
    public RowType createRowType() {
        return new RowType();
    }

    /**
     * Create an instance of {@link EntryType }
     * 
     */
    public EntryType createEntryType() {
        return new EntryType();
    }

    /**
     * Create an instance of {@link TableType }
     * 
     */
    public TableType createTableType() {
        return new TableType();
    }

    /**
     * Create an instance of {@link DlType }
     * 
     */
    public DlType createDlType() {
        return new DlType();
    }

    /**
     * Create an instance of {@link UlType }
     * 
     */
    public UlType createUlType() {
        return new UlType();
    }

    /**
     * Create an instance of {@link LiType }
     * 
     */
    public LiType createLiType() {
        return new LiType();
    }

    /**
     * Create an instance of {@link MathsType }
     * 
     */
    public MathsType createMathsType() {
        return new MathsType();
    }

    /**
     * Create an instance of {@link MiType }
     * 
     */
    public MiType createMiType() {
        return new MiType();
    }

    /**
     * Create an instance of {@link MglyphType }
     * 
     */
    public MglyphType createMglyphType() {
        return new MglyphType();
    }

    /**
     * Create an instance of {@link MalignmarkType }
     * 
     */
    public MalignmarkType createMalignmarkType() {
        return new MalignmarkType();
    }

    /**
     * Create an instance of {@link MnType }
     * 
     */
    public MnType createMnType() {
        return new MnType();
    }

    /**
     * Create an instance of {@link MoType }
     * 
     */
    public MoType createMoType() {
        return new MoType();
    }

    /**
     * Create an instance of {@link MtextType }
     * 
     */
    public MtextType createMtextType() {
        return new MtextType();
    }

    /**
     * Create an instance of {@link MsType }
     * 
     */
    public MsType createMsType() {
        return new MsType();
    }

    /**
     * Create an instance of {@link MspaceType }
     * 
     */
    public MspaceType createMspaceType() {
        return new MspaceType();
    }

    /**
     * Create an instance of {@link MrowType }
     * 
     */
    public MrowType createMrowType() {
        return new MrowType();
    }

    /**
     * Create an instance of {@link MprescriptsType }
     * 
     */
    public MprescriptsType createMprescriptsType() {
        return new MprescriptsType();
    }

    /**
     * Create an instance of {@link NoneType }
     * 
     */
    public NoneType createNoneType() {
        return new NoneType();
    }

    /**
     * Create an instance of {@link MfracType }
     * 
     */
    public MfracType createMfracType() {
        return new MfracType();
    }

    /**
     * Create an instance of {@link MsqrtType }
     * 
     */
    public MsqrtType createMsqrtType() {
        return new MsqrtType();
    }

    /**
     * Create an instance of {@link MrootType }
     * 
     */
    public MrootType createMrootType() {
        return new MrootType();
    }

    /**
     * Create an instance of {@link MencloseType }
     * 
     */
    public MencloseType createMencloseType() {
        return new MencloseType();
    }

    /**
     * Create an instance of {@link MstyleType }
     * 
     */
    public MstyleType createMstyleType() {
        return new MstyleType();
    }

    /**
     * Create an instance of {@link MerrorType }
     * 
     */
    public MerrorType createMerrorType() {
        return new MerrorType();
    }

    /**
     * Create an instance of {@link MpaddedType }
     * 
     */
    public MpaddedType createMpaddedType() {
        return new MpaddedType();
    }

    /**
     * Create an instance of {@link MphantomType }
     * 
     */
    public MphantomType createMphantomType() {
        return new MphantomType();
    }

    /**
     * Create an instance of {@link MfencedType }
     * 
     */
    public MfencedType createMfencedType() {
        return new MfencedType();
    }

    /**
     * Create an instance of {@link MsubType }
     * 
     */
    public MsubType createMsubType() {
        return new MsubType();
    }

    /**
     * Create an instance of {@link MsupType }
     * 
     */
    public MsupType createMsupType() {
        return new MsupType();
    }

    /**
     * Create an instance of {@link MsubsupType }
     * 
     */
    public MsubsupType createMsubsupType() {
        return new MsubsupType();
    }

    /**
     * Create an instance of {@link MunderType }
     * 
     */
    public MunderType createMunderType() {
        return new MunderType();
    }

    /**
     * Create an instance of {@link MoverType }
     * 
     */
    public MoverType createMoverType() {
        return new MoverType();
    }

    /**
     * Create an instance of {@link MunderoverType }
     * 
     */
    public MunderoverType createMunderoverType() {
        return new MunderoverType();
    }

    /**
     * Create an instance of {@link MmultiscriptsType }
     * 
     */
    public MmultiscriptsType createMmultiscriptsType() {
        return new MmultiscriptsType();
    }

    /**
     * Create an instance of {@link MtableType }
     * 
     */
    public MtableType createMtableType() {
        return new MtableType();
    }

    /**
     * Create an instance of {@link MtrType }
     * 
     */
    public MtrType createMtrType() {
        return new MtrType();
    }

    /**
     * Create an instance of {@link MlabeledtrType }
     * 
     */
    public MlabeledtrType createMlabeledtrType() {
        return new MlabeledtrType();
    }

    /**
     * Create an instance of {@link MtdType }
     * 
     */
    public MtdType createMtdType() {
        return new MtdType();
    }

    /**
     * Create an instance of {@link MaligngroupType }
     * 
     */
    public MaligngroupType createMaligngroupType() {
        return new MaligngroupType();
    }

    /**
     * Create an instance of {@link MactionType }
     * 
     */
    public MactionType createMactionType() {
        return new MactionType();
    }

    /**
     * Create an instance of {@link CiType }
     * 
     */
    public CiType createCiType() {
        return new CiType();
    }

    /**
     * Create an instance of {@link CsymbolType }
     * 
     */
    public CsymbolType createCsymbolType() {
        return new CsymbolType();
    }

    /**
     * Create an instance of {@link CnType }
     * 
     */
    public CnType createCnType() {
        return new CnType();
    }

    /**
     * Create an instance of {@link SepType }
     * 
     */
    public SepType createSepType() {
        return new SepType();
    }

    /**
     * Create an instance of {@link IntegersType }
     * 
     */
    public IntegersType createIntegersType() {
        return new IntegersType();
    }

    /**
     * Create an instance of {@link RealsType }
     * 
     */
    public RealsType createRealsType() {
        return new RealsType();
    }

    /**
     * Create an instance of {@link RationalsType }
     * 
     */
    public RationalsType createRationalsType() {
        return new RationalsType();
    }

    /**
     * Create an instance of {@link NaturalnumbersType }
     * 
     */
    public NaturalnumbersType createNaturalnumbersType() {
        return new NaturalnumbersType();
    }

    /**
     * Create an instance of {@link ComplexesType }
     * 
     */
    public ComplexesType createComplexesType() {
        return new ComplexesType();
    }

    /**
     * Create an instance of {@link PrimesType }
     * 
     */
    public PrimesType createPrimesType() {
        return new PrimesType();
    }

    /**
     * Create an instance of {@link ExponentialeType }
     * 
     */
    public ExponentialeType createExponentialeType() {
        return new ExponentialeType();
    }

    /**
     * Create an instance of {@link ImaginaryiType }
     * 
     */
    public ImaginaryiType createImaginaryiType() {
        return new ImaginaryiType();
    }

    /**
     * Create an instance of {@link NotanumberType }
     * 
     */
    public NotanumberType createNotanumberType() {
        return new NotanumberType();
    }

    /**
     * Create an instance of {@link TrueType }
     * 
     */
    public TrueType createTrueType() {
        return new TrueType();
    }

    /**
     * Create an instance of {@link FalseType }
     * 
     */
    public FalseType createFalseType() {
        return new FalseType();
    }

    /**
     * Create an instance of {@link EmptysetType }
     * 
     */
    public EmptysetType createEmptysetType() {
        return new EmptysetType();
    }

    /**
     * Create an instance of {@link PiType }
     * 
     */
    public PiType createPiType() {
        return new PiType();
    }

    /**
     * Create an instance of {@link EulergammaType }
     * 
     */
    public EulergammaType createEulergammaType() {
        return new EulergammaType();
    }

    /**
     * Create an instance of {@link InfinityType }
     * 
     */
    public InfinityType createInfinityType() {
        return new InfinityType();
    }

    /**
     * Create an instance of {@link ApplyType }
     * 
     */
    public ApplyType createApplyType() {
        return new ApplyType();
    }

    /**
     * Create an instance of {@link RelnType }
     * 
     */
    public RelnType createRelnType() {
        return new RelnType();
    }

    /**
     * Create an instance of {@link LambdaType }
     * 
     */
    public LambdaType createLambdaType() {
        return new LambdaType();
    }

    /**
     * Create an instance of {@link ConditionType }
     * 
     */
    public ConditionType createConditionType() {
        return new ConditionType();
    }

    /**
     * Create an instance of {@link DeclareType }
     * 
     */
    public DeclareType createDeclareType() {
        return new DeclareType();
    }

    /**
     * Create an instance of {@link SemanticsType }
     * 
     */
    public SemanticsType createSemanticsType() {
        return new SemanticsType();
    }

    /**
     * Create an instance of {@link AnnotationType }
     * 
     */
    public AnnotationType createAnnotationType() {
        return new AnnotationType();
    }

    /**
     * Create an instance of {@link AnnotationXmlType }
     * 
     */
    public AnnotationXmlType createAnnotationXmlType() {
        return new AnnotationXmlType();
    }

    /**
     * Create an instance of {@link IntervalType }
     * 
     */
    public IntervalType createIntervalType() {
        return new IntervalType();
    }

    /**
     * Create an instance of {@link ListType }
     * 
     */
    public ListType createListType() {
        return new ListType();
    }

    /**
     * Create an instance of {@link MatrixType }
     * 
     */
    public MatrixType createMatrixType() {
        return new MatrixType();
    }

    /**
     * Create an instance of {@link MatrixrowType }
     * 
     */
    public MatrixrowType createMatrixrowType() {
        return new MatrixrowType();
    }

    /**
     * Create an instance of {@link SetType }
     * 
     */
    public SetType createSetType() {
        return new SetType();
    }

    /**
     * Create an instance of {@link VectorType }
     * 
     */
    public VectorType createVectorType() {
        return new VectorType();
    }

    /**
     * Create an instance of {@link PiecewiseType }
     * 
     */
    public PiecewiseType createPiecewiseType() {
        return new PiecewiseType();
    }

    /**
     * Create an instance of {@link PieceType }
     * 
     */
    public PieceType createPieceType() {
        return new PieceType();
    }

    /**
     * Create an instance of {@link OtherwiseType }
     * 
     */
    public OtherwiseType createOtherwiseType() {
        return new OtherwiseType();
    }

    /**
     * Create an instance of {@link LowlimitType }
     * 
     */
    public LowlimitType createLowlimitType() {
        return new LowlimitType();
    }

    /**
     * Create an instance of {@link UplimitType }
     * 
     */
    public UplimitType createUplimitType() {
        return new UplimitType();
    }

    /**
     * Create an instance of {@link BvarType }
     * 
     */
    public BvarType createBvarType() {
        return new BvarType();
    }

    /**
     * Create an instance of {@link DegreeType }
     * 
     */
    public DegreeType createDegreeType() {
        return new DegreeType();
    }

    /**
     * Create an instance of {@link LogbaseType }
     * 
     */
    public LogbaseType createLogbaseType() {
        return new LogbaseType();
    }

    /**
     * Create an instance of {@link MomentaboutType }
     * 
     */
    public MomentaboutType createMomentaboutType() {
        return new MomentaboutType();
    }

    /**
     * Create an instance of {@link DomainofapplicationType }
     * 
     */
    public DomainofapplicationType createDomainofapplicationType() {
        return new DomainofapplicationType();
    }

    /**
     * Create an instance of {@link InverseType }
     * 
     */
    public InverseType createInverseType() {
        return new InverseType();
    }

    /**
     * Create an instance of {@link IdentType }
     * 
     */
    public IdentType createIdentType() {
        return new IdentType();
    }

    /**
     * Create an instance of {@link DomainType }
     * 
     */
    public DomainType createDomainType() {
        return new DomainType();
    }

    /**
     * Create an instance of {@link CodomainType }
     * 
     */
    public CodomainType createCodomainType() {
        return new CodomainType();
    }

    /**
     * Create an instance of {@link ImageType }
     * 
     */
    public ImageType createImageType() {
        return new ImageType();
    }

    /**
     * Create an instance of {@link AbsType }
     * 
     */
    public AbsType createAbsType() {
        return new AbsType();
    }

    /**
     * Create an instance of {@link ConjugateType }
     * 
     */
    public ConjugateType createConjugateType() {
        return new ConjugateType();
    }

    /**
     * Create an instance of {@link ExpType }
     * 
     */
    public ExpType createExpType() {
        return new ExpType();
    }

    /**
     * Create an instance of {@link FactorialType }
     * 
     */
    public FactorialType createFactorialType() {
        return new FactorialType();
    }

    /**
     * Create an instance of {@link ArgType }
     * 
     */
    public ArgType createArgType() {
        return new ArgType();
    }

    /**
     * Create an instance of {@link RealType }
     * 
     */
    public RealType createRealType() {
        return new RealType();
    }

    /**
     * Create an instance of {@link ImaginaryType }
     * 
     */
    public ImaginaryType createImaginaryType() {
        return new ImaginaryType();
    }

    /**
     * Create an instance of {@link FloorType }
     * 
     */
    public FloorType createFloorType() {
        return new FloorType();
    }

    /**
     * Create an instance of {@link CeilingType }
     * 
     */
    public CeilingType createCeilingType() {
        return new CeilingType();
    }

    /**
     * Create an instance of {@link NotType }
     * 
     */
    public NotType createNotType() {
        return new NotType();
    }

    /**
     * Create an instance of {@link LnType }
     * 
     */
    public LnType createLnType() {
        return new LnType();
    }

    /**
     * Create an instance of {@link SinType }
     * 
     */
    public SinType createSinType() {
        return new SinType();
    }

    /**
     * Create an instance of {@link CosType }
     * 
     */
    public CosType createCosType() {
        return new CosType();
    }

    /**
     * Create an instance of {@link TanType }
     * 
     */
    public TanType createTanType() {
        return new TanType();
    }

    /**
     * Create an instance of {@link SecType }
     * 
     */
    public SecType createSecType() {
        return new SecType();
    }

    /**
     * Create an instance of {@link CscType }
     * 
     */
    public CscType createCscType() {
        return new CscType();
    }

    /**
     * Create an instance of {@link CotType }
     * 
     */
    public CotType createCotType() {
        return new CotType();
    }

    /**
     * Create an instance of {@link SinhType }
     * 
     */
    public SinhType createSinhType() {
        return new SinhType();
    }

    /**
     * Create an instance of {@link CoshType }
     * 
     */
    public CoshType createCoshType() {
        return new CoshType();
    }

    /**
     * Create an instance of {@link TanhType }
     * 
     */
    public TanhType createTanhType() {
        return new TanhType();
    }

    /**
     * Create an instance of {@link SechType }
     * 
     */
    public SechType createSechType() {
        return new SechType();
    }

    /**
     * Create an instance of {@link CschType }
     * 
     */
    public CschType createCschType() {
        return new CschType();
    }

    /**
     * Create an instance of {@link CothType }
     * 
     */
    public CothType createCothType() {
        return new CothType();
    }

    /**
     * Create an instance of {@link ArcsinType }
     * 
     */
    public ArcsinType createArcsinType() {
        return new ArcsinType();
    }

    /**
     * Create an instance of {@link ArccosType }
     * 
     */
    public ArccosType createArccosType() {
        return new ArccosType();
    }

    /**
     * Create an instance of {@link ArctanType }
     * 
     */
    public ArctanType createArctanType() {
        return new ArctanType();
    }

    /**
     * Create an instance of {@link ArccoshType }
     * 
     */
    public ArccoshType createArccoshType() {
        return new ArccoshType();
    }

    /**
     * Create an instance of {@link ArccotType }
     * 
     */
    public ArccotType createArccotType() {
        return new ArccotType();
    }

    /**
     * Create an instance of {@link ArccothType }
     * 
     */
    public ArccothType createArccothType() {
        return new ArccothType();
    }

    /**
     * Create an instance of {@link ArccscType }
     * 
     */
    public ArccscType createArccscType() {
        return new ArccscType();
    }

    /**
     * Create an instance of {@link ArccschType }
     * 
     */
    public ArccschType createArccschType() {
        return new ArccschType();
    }

    /**
     * Create an instance of {@link ArcsecType }
     * 
     */
    public ArcsecType createArcsecType() {
        return new ArcsecType();
    }

    /**
     * Create an instance of {@link ArcsechType }
     * 
     */
    public ArcsechType createArcsechType() {
        return new ArcsechType();
    }

    /**
     * Create an instance of {@link ArcsinhType }
     * 
     */
    public ArcsinhType createArcsinhType() {
        return new ArcsinhType();
    }

    /**
     * Create an instance of {@link ArctanhType }
     * 
     */
    public ArctanhType createArctanhType() {
        return new ArctanhType();
    }

    /**
     * Create an instance of {@link DeterminantType }
     * 
     */
    public DeterminantType createDeterminantType() {
        return new DeterminantType();
    }

    /**
     * Create an instance of {@link TransposeType }
     * 
     */
    public TransposeType createTransposeType() {
        return new TransposeType();
    }

    /**
     * Create an instance of {@link CardType }
     * 
     */
    public CardType createCardType() {
        return new CardType();
    }

    /**
     * Create an instance of {@link QuotientType }
     * 
     */
    public QuotientType createQuotientType() {
        return new QuotientType();
    }

    /**
     * Create an instance of {@link DivideType }
     * 
     */
    public DivideType createDivideType() {
        return new DivideType();
    }

    /**
     * Create an instance of {@link PowerType }
     * 
     */
    public PowerType createPowerType() {
        return new PowerType();
    }

    /**
     * Create an instance of {@link RemType }
     * 
     */
    public RemType createRemType() {
        return new RemType();
    }

    /**
     * Create an instance of {@link ImpliesType }
     * 
     */
    public ImpliesType createImpliesType() {
        return new ImpliesType();
    }

    /**
     * Create an instance of {@link VectorproductType }
     * 
     */
    public VectorproductType createVectorproductType() {
        return new VectorproductType();
    }

    /**
     * Create an instance of {@link ScalarproductType }
     * 
     */
    public ScalarproductType createScalarproductType() {
        return new ScalarproductType();
    }

    /**
     * Create an instance of {@link OuterproductType }
     * 
     */
    public OuterproductType createOuterproductType() {
        return new OuterproductType();
    }

    /**
     * Create an instance of {@link SetdiffType }
     * 
     */
    public SetdiffType createSetdiffType() {
        return new SetdiffType();
    }

    /**
     * Create an instance of {@link FnType }
     * 
     */
    public FnType createFnType() {
        return new FnType();
    }

    /**
     * Create an instance of {@link ComposeType }
     * 
     */
    public ComposeType createComposeType() {
        return new ComposeType();
    }

    /**
     * Create an instance of {@link PlusType }
     * 
     */
    public PlusType createPlusType() {
        return new PlusType();
    }

    /**
     * Create an instance of {@link TimesType }
     * 
     */
    public TimesType createTimesType() {
        return new TimesType();
    }

    /**
     * Create an instance of {@link MaxType }
     * 
     */
    public MaxType createMaxType() {
        return new MaxType();
    }

    /**
     * Create an instance of {@link MinType }
     * 
     */
    public MinType createMinType() {
        return new MinType();
    }

    /**
     * Create an instance of {@link GcdType }
     * 
     */
    public GcdType createGcdType() {
        return new GcdType();
    }

    /**
     * Create an instance of {@link LcmType }
     * 
     */
    public LcmType createLcmType() {
        return new LcmType();
    }

    /**
     * Create an instance of {@link AndType }
     * 
     */
    public AndType createAndType() {
        return new AndType();
    }

    /**
     * Create an instance of {@link OrType }
     * 
     */
    public OrType createOrType() {
        return new OrType();
    }

    /**
     * Create an instance of {@link XorType }
     * 
     */
    public XorType createXorType() {
        return new XorType();
    }

    /**
     * Create an instance of {@link UnionType }
     * 
     */
    public UnionType createUnionType() {
        return new UnionType();
    }

    /**
     * Create an instance of {@link IntersectType }
     * 
     */
    public IntersectType createIntersectType() {
        return new IntersectType();
    }

    /**
     * Create an instance of {@link CartesianproductType }
     * 
     */
    public CartesianproductType createCartesianproductType() {
        return new CartesianproductType();
    }

    /**
     * Create an instance of {@link MeanType }
     * 
     */
    public MeanType createMeanType() {
        return new MeanType();
    }

    /**
     * Create an instance of {@link SdevType }
     * 
     */
    public SdevType createSdevType() {
        return new SdevType();
    }

    /**
     * Create an instance of {@link VarianceType }
     * 
     */
    public VarianceType createVarianceType() {
        return new VarianceType();
    }

    /**
     * Create an instance of {@link MedianType }
     * 
     */
    public MedianType createMedianType() {
        return new MedianType();
    }

    /**
     * Create an instance of {@link ModeType }
     * 
     */
    public ModeType createModeType() {
        return new ModeType();
    }

    /**
     * Create an instance of {@link SelectorType }
     * 
     */
    public SelectorType createSelectorType() {
        return new SelectorType();
    }

    /**
     * Create an instance of {@link RootType }
     * 
     */
    public RootType createRootType() {
        return new RootType();
    }

    /**
     * Create an instance of {@link MinusType }
     * 
     */
    public MinusType createMinusType() {
        return new MinusType();
    }

    /**
     * Create an instance of {@link LogType }
     * 
     */
    public LogType createLogType() {
        return new LogType();
    }

    /**
     * Create an instance of {@link IntType }
     * 
     */
    public IntType createIntType() {
        return new IntType();
    }

    /**
     * Create an instance of {@link DiffType }
     * 
     */
    public DiffType createDiffType() {
        return new DiffType();
    }

    /**
     * Create an instance of {@link PartialdiffType }
     * 
     */
    public PartialdiffType createPartialdiffType() {
        return new PartialdiffType();
    }

    /**
     * Create an instance of {@link DivergenceType }
     * 
     */
    public DivergenceType createDivergenceType() {
        return new DivergenceType();
    }

    /**
     * Create an instance of {@link GradType }
     * 
     */
    public GradType createGradType() {
        return new GradType();
    }

    /**
     * Create an instance of {@link CurlType }
     * 
     */
    public CurlType createCurlType() {
        return new CurlType();
    }

    /**
     * Create an instance of {@link LaplacianType }
     * 
     */
    public LaplacianType createLaplacianType() {
        return new LaplacianType();
    }

    /**
     * Create an instance of {@link SumType }
     * 
     */
    public SumType createSumType() {
        return new SumType();
    }

    /**
     * Create an instance of {@link ProductType }
     * 
     */
    public ProductType createProductType() {
        return new ProductType();
    }

    /**
     * Create an instance of {@link LimitType }
     * 
     */
    public LimitType createLimitType() {
        return new LimitType();
    }

    /**
     * Create an instance of {@link MomentType }
     * 
     */
    public MomentType createMomentType() {
        return new MomentType();
    }

    /**
     * Create an instance of {@link ExistsType }
     * 
     */
    public ExistsType createExistsType() {
        return new ExistsType();
    }

    /**
     * Create an instance of {@link ForallType }
     * 
     */
    public ForallType createForallType() {
        return new ForallType();
    }

    /**
     * Create an instance of {@link NeqType }
     * 
     */
    public NeqType createNeqType() {
        return new NeqType();
    }

    /**
     * Create an instance of {@link FactorofType }
     * 
     */
    public FactorofType createFactorofType() {
        return new FactorofType();
    }

    /**
     * Create an instance of {@link InType }
     * 
     */
    public InType createInType() {
        return new InType();
    }

    /**
     * Create an instance of {@link NotinType }
     * 
     */
    public NotinType createNotinType() {
        return new NotinType();
    }

    /**
     * Create an instance of {@link NotsubsetType }
     * 
     */
    public NotsubsetType createNotsubsetType() {
        return new NotsubsetType();
    }

    /**
     * Create an instance of {@link NotprsubsetType }
     * 
     */
    public NotprsubsetType createNotprsubsetType() {
        return new NotprsubsetType();
    }

    /**
     * Create an instance of {@link TendstoType }
     * 
     */
    public TendstoType createTendstoType() {
        return new TendstoType();
    }

    /**
     * Create an instance of {@link EqType }
     * 
     */
    public EqType createEqType() {
        return new EqType();
    }

    /**
     * Create an instance of {@link LeqType }
     * 
     */
    public LeqType createLeqType() {
        return new LeqType();
    }

    /**
     * Create an instance of {@link LtType }
     * 
     */
    public LtType createLtType() {
        return new LtType();
    }

    /**
     * Create an instance of {@link GeqType }
     * 
     */
    public GeqType createGeqType() {
        return new GeqType();
    }

    /**
     * Create an instance of {@link GtType }
     * 
     */
    public GtType createGtType() {
        return new GtType();
    }

    /**
     * Create an instance of {@link EquivalentType }
     * 
     */
    public EquivalentType createEquivalentType() {
        return new EquivalentType();
    }

    /**
     * Create an instance of {@link ApproxType }
     * 
     */
    public ApproxType createApproxType() {
        return new ApproxType();
    }

    /**
     * Create an instance of {@link SubsetType }
     * 
     */
    public SubsetType createSubsetType() {
        return new SubsetType();
    }

    /**
     * Create an instance of {@link PrsubsetType }
     * 
     */
    public PrsubsetType createPrsubsetType() {
        return new PrsubsetType();
    }

    /**
     * Create an instance of {@link ChemistryType }
     * 
     */
    public ChemistryType createChemistryType() {
        return new ChemistryType();
    }

    /**
     * Create an instance of {@link ChemType }
     * 
     */
    public ChemType createChemType() {
        return new ChemType();
    }

    /**
     * Create an instance of {@link OlType }
     * 
     */
    public OlType createOlType() {
        return new OlType();
    }

    /**
     * Create an instance of {@link ImgType }
     * 
     */
    public ImgType createImgType() {
        return new ImgType();
    }

    /**
     * Create an instance of {@link FigrefType }
     * 
     */
    public FigrefType createFigrefType() {
        return new FigrefType();
    }

    /**
     * Create an instance of {@link CrossrefType }
     * 
     */
    public CrossrefType createCrossrefType() {
        return new CrossrefType();
    }

    /**
     * Create an instance of {@link BioDepositType }
     * 
     */
    public BioDepositType createBioDepositType() {
        return new BioDepositType();
    }

    /**
     * Create an instance of {@link NplcitType }
     * 
     */
    public NplcitType createNplcitType() {
        return new NplcitType();
    }

    /**
     * Create an instance of {@link RefnoType }
     * 
     */
    public RefnoType createRefnoType() {
        return new RefnoType();
    }

    /**
     * Create an instance of {@link ClassType }
     * 
     */
    public ClassType createClassType() {
        return new ClassType();
    }

    /**
     * Create an instance of {@link SubnameType }
     * 
     */
    public SubnameType createSubnameType() {
        return new SubnameType();
    }

    /**
     * Create an instance of {@link AuthorType }
     * 
     */
    public AuthorType createAuthorType() {
        return new AuthorType();
    }

    /**
     * Create an instance of {@link AddressbookType }
     * 
     */
    public AddressbookType createAddressbookType() {
        return new AddressbookType();
    }

    /**
     * Create an instance of {@link PatcitType }
     * 
     */
    public PatcitType createPatcitType() {
        return new PatcitType();
    }

    /**
     * Create an instance of {@link DocumentIdType }
     * 
     */
    public DocumentIdType createDocumentIdType() {
        return new DocumentIdType();
    }

    /**
     * Create an instance of {@link NameType }
     * 
     */
    public NameType createNameType() {
        return new NameType();
    }

    /**
     * Create an instance of {@link DtType }
     * 
     */
    public DtType createDtType() {
        return new DtType();
    }

    /**
     * Create an instance of {@link OType }
     * 
     */
    public OType createOType() {
        return new OType();
    }

    /**
     * Create an instance of {@link UType }
     * 
     */
    public UType createUType() {
        return new UType();
    }

    /**
     * Create an instance of {@link DocPageType }
     * 
     */
    public DocPageType createDocPageType() {
        return new DocPageType();
    }

    /**
     * Create an instance of {@link SrepWrittenOpinionType }
     * 
     */
    public SrepWrittenOpinionType createSrepWrittenOpinionType() {
        return new SrepWrittenOpinionType();
    }

    /**
     * Create an instance of {@link ObservationOnApplicationType }
     * 
     */
    public ObservationOnApplicationType createObservationOnApplicationType() {
        return new ObservationOnApplicationType();
    }

    /**
     * Create an instance of {@link DefectInApplicationType }
     * 
     */
    public DefectInApplicationType createDefectInApplicationType() {
        return new DefectInApplicationType();
    }

    /**
     * Create an instance of {@link OpinionCitationsType }
     * 
     */
    public OpinionCitationsType createOpinionCitationsType() {
        return new OpinionCitationsType();
    }

    /**
     * Create an instance of {@link NonWrittenDisclosuresType }
     * 
     */
    public NonWrittenDisclosuresType createNonWrittenDisclosuresType() {
        return new NonWrittenDisclosuresType();
    }

    /**
     * Create an instance of {@link DateOfWrittenDisclosureType }
     * 
     */
    public DateOfWrittenDisclosureType createDateOfWrittenDisclosureType() {
        return new DateOfWrittenDisclosureType();
    }

    /**
     * Create an instance of {@link KindOfDisclosureType }
     * 
     */
    public KindOfDisclosureType createKindOfDisclosureType() {
        return new KindOfDisclosureType();
    }

    /**
     * Create an instance of {@link CertainPublishedDocumentsType }
     * 
     */
    public CertainPublishedDocumentsType createCertainPublishedDocumentsType() {
        return new CertainPublishedDocumentsType();
    }

    /**
     * Create an instance of {@link PctRule43BisStatementType }
     * 
     */
    public PctRule43BisStatementType createPctRule43BisStatementType() {
        return new PctRule43BisStatementType();
    }

    /**
     * Create an instance of {@link CitationsExplanationsType }
     * 
     */
    public CitationsExplanationsType createCitationsExplanationsType() {
        return new CitationsExplanationsType();
    }

    /**
     * Create an instance of {@link FilingDateType }
     * 
     */
    public FilingDateType createFilingDateType() {
        return new FilingDateType();
    }

    /**
     * Create an instance of {@link ApplicabilityNotValidType }
     * 
     */
    public ApplicabilityNotValidType createApplicabilityNotValidType() {
        return new ApplicabilityNotValidType();
    }

    /**
     * Create an instance of {@link ApplicabilityValidType }
     * 
     */
    public ApplicabilityValidType createApplicabilityValidType() {
        return new ApplicabilityValidType();
    }

    /**
     * Create an instance of {@link InventiveStepNotValidType }
     * 
     */
    public InventiveStepNotValidType createInventiveStepNotValidType() {
        return new InventiveStepNotValidType();
    }

    /**
     * Create an instance of {@link InventiveStepValidType }
     * 
     */
    public InventiveStepValidType createInventiveStepValidType() {
        return new InventiveStepValidType();
    }

    /**
     * Create an instance of {@link NoveltyNotValidType }
     * 
     */
    public NoveltyNotValidType createNoveltyNotValidType() {
        return new NoveltyNotValidType();
    }

    /**
     * Create an instance of {@link NoveltyValidType }
     * 
     */
    public NoveltyValidType createNoveltyValidType() {
        return new NoveltyValidType();
    }

    /**
     * Create an instance of {@link UnityOfInventionType }
     * 
     */
    public UnityOfInventionType createUnityOfInventionType() {
        return new UnityOfInventionType();
    }

    /**
     * Create an instance of {@link OpinionEstablishedRegardingType }
     * 
     */
    public OpinionEstablishedRegardingType createOpinionEstablishedRegardingType() {
        return new OpinionEstablishedRegardingType();
    }

    /**
     * Create an instance of {@link NotUnityOfInventionType }
     * 
     */
    public NotUnityOfInventionType createNotUnityOfInventionType() {
        return new NotUnityOfInventionType();
    }

    /**
     * Create an instance of {@link NonEstablishmentOfOpinionType }
     * 
     */
    public NonEstablishmentOfOpinionType createNonEstablishmentOfOpinionType() {
        return new NonEstablishmentOfOpinionType();
    }

    /**
     * Create an instance of {@link NotAnnexCCompliantType }
     * 
     */
    public NotAnnexCCompliantType createNotAnnexCCompliantType() {
        return new NotAnnexCCompliantType();
    }

    /**
     * Create an instance of {@link AnnexCBisType }
     * 
     */
    public AnnexCBisType createAnnexCBisType() {
        return new AnnexCBisType();
    }

    /**
     * Create an instance of {@link AnnexCType }
     * 
     */
    public AnnexCType createAnnexCType() {
        return new AnnexCType();
    }

    /**
     * Create an instance of {@link InventionNotExaminedType }
     * 
     */
    public InventionNotExaminedType createInventionNotExaminedType() {
        return new InventionNotExaminedType();
    }

    /**
     * Create an instance of {@link NonEstabReason4Type }
     * 
     */
    public NonEstabReason4Type createNonEstabReason4Type() {
        return new NonEstabReason4Type();
    }

    /**
     * Create an instance of {@link NonEstabReason3Type }
     * 
     */
    public NonEstabReason3Type createNonEstabReason3Type() {
        return new NonEstabReason3Type();
    }

    /**
     * Create an instance of {@link NonEstabReason2Type }
     * 
     */
    public NonEstabReason2Type createNonEstabReason2Type() {
        return new NonEstabReason2Type();
    }

    /**
     * Create an instance of {@link NonEstabReason1Type }
     * 
     */
    public NonEstabReason1Type createNonEstabReason1Type() {
        return new NonEstabReason1Type();
    }

    /**
     * Create an instance of {@link EntireApplicationType }
     * 
     */
    public EntireApplicationType createEntireApplicationType() {
        return new EntireApplicationType();
    }

    /**
     * Create an instance of {@link ClaimInvalidType }
     * 
     */
    public ClaimInvalidType createClaimInvalidType() {
        return new ClaimInvalidType();
    }

    /**
     * Create an instance of {@link BasisOfSrepOpinionType }
     * 
     */
    public BasisOfSrepOpinionType createBasisOfSrepOpinionType() {
        return new BasisOfSrepOpinionType();
    }

    /**
     * Create an instance of {@link SrepForPubType }
     * 
     */
    public SrepForPubType createSrepForPubType() {
        return new SrepForPubType();
    }

    /**
     * Create an instance of {@link SrepPatentFamiliesType }
     * 
     */
    public SrepPatentFamiliesType createSrepPatentFamiliesType() {
        return new SrepPatentFamiliesType();
    }

    /**
     * Create an instance of {@link SrepFamilyMemberType }
     * 
     */
    public SrepFamilyMemberType createSrepFamilyMemberType() {
        return new SrepFamilyMemberType();
    }

    /**
     * Create an instance of {@link PriorityApplicationType }
     * 
     */
    public PriorityApplicationType createPriorityApplicationType() {
        return new PriorityApplicationType();
    }

    /**
     * Create an instance of {@link SrepAdminType }
     * 
     */
    public SrepAdminType createSrepAdminType() {
        return new SrepAdminType();
    }

    /**
     * Create an instance of {@link DateSearchCompletedType }
     * 
     */
    public DateSearchCompletedType createDateSearchCompletedType() {
        return new DateSearchCompletedType();
    }

    /**
     * Create an instance of {@link ExaminersType }
     * 
     */
    public ExaminersType createExaminersType() {
        return new ExaminersType();
    }

    /**
     * Create an instance of {@link AssistantExaminerType }
     * 
     */
    public AssistantExaminerType createAssistantExaminerType() {
        return new AssistantExaminerType();
    }

    /**
     * Create an instance of {@link PrimaryExaminerType }
     * 
     */
    public PrimaryExaminerType createPrimaryExaminerType() {
        return new PrimaryExaminerType();
    }

    /**
     * Create an instance of {@link IncompleteSearchType }
     * 
     */
    public IncompleteSearchType createIncompleteSearchType() {
        return new IncompleteSearchType();
    }

    /**
     * Create an instance of {@link ReasonLimitedSearchType }
     * 
     */
    public ReasonLimitedSearchType createReasonLimitedSearchType() {
        return new ReasonLimitedSearchType();
    }

    /**
     * Create an instance of {@link ClaimsNotSearchedType }
     * 
     */
    public ClaimsNotSearchedType createClaimsNotSearchedType() {
        return new ClaimsNotSearchedType();
    }

    /**
     * Create an instance of {@link ClaimsSearchedIncompletelyType }
     * 
     */
    public ClaimsSearchedIncompletelyType createClaimsSearchedIncompletelyType() {
        return new ClaimsSearchedIncompletelyType();
    }

    /**
     * Create an instance of {@link ClaimsSearchedType }
     * 
     */
    public ClaimsSearchedType createClaimsSearchedType() {
        return new ClaimsSearchedType();
    }

    /**
     * Create an instance of {@link SrepCitationsType }
     * 
     */
    public SrepCitationsType createSrepCitationsType() {
        return new SrepCitationsType();
    }

    /**
     * Create an instance of {@link SrepFieldsSearchedType }
     * 
     */
    public SrepFieldsSearchedType createSrepFieldsSearchedType() {
        return new SrepFieldsSearchedType();
    }

    /**
     * Create an instance of {@link DatabaseSearchedType }
     * 
     */
    public DatabaseSearchedType createDatabaseSearchedType() {
        return new DatabaseSearchedType();
    }

    /**
     * Create an instance of {@link OtherDocumentationType }
     * 
     */
    public OtherDocumentationType createOtherDocumentationType() {
        return new OtherDocumentationType();
    }

    /**
     * Create an instance of {@link MinimumDocumentationType }
     * 
     */
    public MinimumDocumentationType createMinimumDocumentationType() {
        return new MinimumDocumentationType();
    }

    /**
     * Create an instance of {@link SrepInfoType }
     * 
     */
    public SrepInfoType createSrepInfoType() {
        return new SrepInfoType();
    }

    /**
     * Create an instance of {@link SrepAbstractType }
     * 
     */
    public SrepAbstractType createSrepAbstractType() {
        return new SrepAbstractType();
    }

    /**
     * Create an instance of {@link SrepInventionTitleType }
     * 
     */
    public SrepInventionTitleType createSrepInventionTitleType() {
        return new SrepInventionTitleType();
    }

    /**
     * Create an instance of {@link SrepOtherInfoType }
     * 
     */
    public SrepOtherInfoType createSrepOtherInfoType() {
        return new SrepOtherInfoType();
    }

    /**
     * Create an instance of {@link SrepInfoAdminType }
     * 
     */
    public SrepInfoAdminType createSrepInfoAdminType() {
        return new SrepInfoAdminType();
    }

    /**
     * Create an instance of {@link DateSearchReportMailedType }
     * 
     */
    public DateSearchReportMailedType createDateSearchReportMailedType() {
        return new DateSearchReportMailedType();
    }

    /**
     * Create an instance of {@link SrepOfficeType }
     * 
     */
    public SrepOfficeType createSrepOfficeType() {
        return new SrepOfficeType();
    }

    /**
     * Create an instance of {@link AuthorizedOfficerType }
     * 
     */
    public AuthorizedOfficerType createAuthorizedOfficerType() {
        return new AuthorizedOfficerType();
    }

    /**
     * Create an instance of {@link EnhancedSignatureType }
     * 
     */
    public EnhancedSignatureType createEnhancedSignatureType() {
        return new EnhancedSignatureType();
    }

    /**
     * Create an instance of {@link Pkcs7Type }
     * 
     */
    public Pkcs7Type createPkcs7Type() {
        return new Pkcs7Type();
    }

    /**
     * Create an instance of {@link BasicSignatureType }
     * 
     */
    public BasicSignatureType createBasicSignatureType() {
        return new BasicSignatureType();
    }

    /**
     * Create an instance of {@link ClickWrapType }
     * 
     */
    public ClickWrapType createClickWrapType() {
        return new ClickWrapType();
    }

    /**
     * Create an instance of {@link TextStringType }
     * 
     */
    public TextStringType createTextStringType() {
        return new TextStringType();
    }

    /**
     * Create an instance of {@link FigureToPublishType }
     * 
     */
    public FigureToPublishType createFigureToPublishType() {
        return new FigureToPublishType();
    }

    /**
     * Create an instance of {@link FigNumberType }
     * 
     */
    public FigNumberType createFigNumberType() {
        return new FigNumberType();
    }

    /**
     * Create an instance of {@link SrepUnityOfInventionType }
     * 
     */
    public SrepUnityOfInventionType createSrepUnityOfInventionType() {
        return new SrepUnityOfInventionType();
    }

    /**
     * Create an instance of {@link SrepSearchFeesType }
     * 
     */
    public SrepSearchFeesType createSrepSearchFeesType() {
        return new SrepSearchFeesType();
    }

    /**
     * Create an instance of {@link SrepFee4Type }
     * 
     */
    public SrepFee4Type createSrepFee4Type() {
        return new SrepFee4Type();
    }

    /**
     * Create an instance of {@link SrepFee3Type }
     * 
     */
    public SrepFee3Type createSrepFee3Type() {
        return new SrepFee3Type();
    }

    /**
     * Create an instance of {@link SrepFee2Type }
     * 
     */
    public SrepFee2Type createSrepFee2Type() {
        return new SrepFee2Type();
    }

    /**
     * Create an instance of {@link SrepFee1Type }
     * 
     */
    public SrepFee1Type createSrepFee1Type() {
        return new SrepFee1Type();
    }

    /**
     * Create an instance of {@link SrepClaimsInfoType }
     * 
     */
    public SrepClaimsInfoType createSrepClaimsInfoType() {
        return new SrepClaimsInfoType();
    }

    /**
     * Create an instance of {@link ClmsReason3Type }
     * 
     */
    public ClmsReason3Type createClmsReason3Type() {
        return new ClmsReason3Type();
    }

    /**
     * Create an instance of {@link ClmsReason2Type }
     * 
     */
    public ClmsReason2Type createClmsReason2Type() {
        return new ClmsReason2Type();
    }

    /**
     * Create an instance of {@link ClmsReason1Type }
     * 
     */
    public ClmsReason1Type createClmsReason1Type() {
        return new ClmsReason1Type();
    }

    /**
     * Create an instance of {@link ClaimRemarkType }
     * 
     */
    public ClaimRemarkType createClaimRemarkType() {
        return new ClaimRemarkType();
    }

    /**
     * Create an instance of {@link ClaimNumType }
     * 
     */
    public ClaimNumType createClaimNumType() {
        return new ClaimNumType();
    }

    /**
     * Create an instance of {@link SrepBasisType }
     * 
     */
    public SrepBasisType createSrepBasisType() {
        return new SrepBasisType();
    }

    /**
     * Create an instance of {@link SequenceListBasisType }
     * 
     */
    public SequenceListBasisType createSequenceListBasisType() {
        return new SequenceListBasisType();
    }

    /**
     * Create an instance of {@link PresentationOfStatementsType }
     * 
     */
    public PresentationOfStatementsType createPresentationOfStatementsType() {
        return new PresentationOfStatementsType();
    }

    /**
     * Create an instance of {@link MaterialOfSequenceListType }
     * 
     */
    public MaterialOfSequenceListType createMaterialOfSequenceListType() {
        return new MaterialOfSequenceListType();
    }

    /**
     * Create an instance of {@link SrepRequestNumberType }
     * 
     */
    public SrepRequestNumberType createSrepRequestNumberType() {
        return new SrepRequestNumberType();
    }

    /**
     * Create an instance of {@link SrepRequestDateType }
     * 
     */
    public SrepRequestDateType createSrepRequestDateType() {
        return new SrepRequestDateType();
    }

    /**
     * Create an instance of {@link DateOfEarliestPriorityType }
     * 
     */
    public DateOfEarliestPriorityType createDateOfEarliestPriorityType() {
        return new DateOfEarliestPriorityType();
    }

    /**
     * Create an instance of {@link FileReferenceIdType }
     * 
     */
    public FileReferenceIdType createFileReferenceIdType() {
        return new FileReferenceIdType();
    }

    /**
     * Create an instance of {@link FamilyMemberType }
     * 
     */
    public FamilyMemberType createFamilyMemberType() {
        return new FamilyMemberType();
    }

    /**
     * Create an instance of {@link CorrectionNoticeType }
     * 
     */
    public CorrectionNoticeType createCorrectionNoticeType() {
        return new CorrectionNoticeType();
    }

    /**
     * Create an instance of {@link RepublicationNotesType }
     * 
     */
    public RepublicationNotesType createRepublicationNotesType() {
        return new RepublicationNotesType();
    }

    /**
     * Create an instance of {@link ModificationsType }
     * 
     */
    public ModificationsType createModificationsType() {
        return new ModificationsType();
    }

    /**
     * Create an instance of {@link ModifiedPartNameType }
     * 
     */
    public ModifiedPartNameType createModifiedPartNameType() {
        return new ModifiedPartNameType();
    }

    /**
     * Create an instance of {@link ModifiedBibliographyType }
     * 
     */
    public ModifiedBibliographyType createModifiedBibliographyType() {
        return new ModifiedBibliographyType();
    }

    /**
     * Create an instance of {@link CancellationDateType }
     * 
     */
    public CancellationDateType createCancellationDateType() {
        return new CancellationDateType();
    }

    /**
     * Create an instance of {@link RepublicationCodeType }
     * 
     */
    public RepublicationCodeType createRepublicationCodeType() {
        return new RepublicationCodeType();
    }

    /**
     * Create an instance of {@link TypeOfCorrectionType }
     * 
     */
    public TypeOfCorrectionType createTypeOfCorrectionType() {
        return new TypeOfCorrectionType();
    }

    /**
     * Create an instance of {@link CorrespondingDocsType }
     * 
     */
    public CorrespondingDocsType createCorrespondingDocsType() {
        return new CorrespondingDocsType();
    }

    /**
     * Create an instance of {@link PriorityClaimsType }
     * 
     */
    public PriorityClaimsType createPriorityClaimsType() {
        return new PriorityClaimsType();
    }

    /**
     * Create an instance of {@link PriorityDocAttachedType }
     * 
     */
    public PriorityDocAttachedType createPriorityDocAttachedType() {
        return new PriorityDocAttachedType();
    }

    /**
     * Create an instance of {@link PriorityDocRequestedType }
     * 
     */
    public PriorityDocRequestedType createPriorityDocRequestedType() {
        return new PriorityDocRequestedType();
    }

    /**
     * Create an instance of {@link OfficeOfFilingType }
     * 
     */
    public OfficeOfFilingType createOfficeOfFilingType() {
        return new OfficeOfFilingType();
    }

    /**
     * Create an instance of {@link PartiesType }
     * 
     */
    public PartiesType createPartiesType() {
        return new PartiesType();
    }

    /**
     * Create an instance of {@link AgentsType }
     * 
     */
    public AgentsType createAgentsType() {
        return new AgentsType();
    }

    /**
     * Create an instance of {@link CorrespondenceAddressType }
     * 
     */
    public CorrespondenceAddressType createCorrespondenceAddressType() {
        return new CorrespondenceAddressType();
    }

    /**
     * Create an instance of {@link CustomerNumberType }
     * 
     */
    public CustomerNumberType createCustomerNumberType() {
        return new CustomerNumberType();
    }

    /**
     * Create an instance of {@link InventorsType }
     * 
     */
    public InventorsType createInventorsType() {
        return new InventorsType();
    }

    /**
     * Create an instance of {@link InventorType }
     * 
     */
    public InventorType createInventorType() {
        return new InventorType();
    }

    /**
     * Create an instance of {@link ApplicantsType }
     * 
     */
    public ApplicantsType createApplicantsType() {
        return new ApplicantsType();
    }

    /**
     * Create an instance of {@link DesignatedStatesAsInventorType }
     * 
     */
    public DesignatedStatesAsInventorType createDesignatedStatesAsInventorType() {
        return new DesignatedStatesAsInventorType();
    }

    /**
     * Create an instance of {@link DesignatedStatesType }
     * 
     */
    public DesignatedStatesType createDesignatedStatesType() {
        return new DesignatedStatesType();
    }

    /**
     * Create an instance of {@link ResidenceType }
     * 
     */
    public ResidenceType createResidenceType() {
        return new ResidenceType();
    }

    /**
     * Create an instance of {@link NationalityType }
     * 
     */
    public NationalityType createNationalityType() {
        return new NationalityType();
    }

    /**
     * Create an instance of {@link DesignationEpcType }
     * 
     */
    public DesignationEpcType createDesignationEpcType() {
        return new DesignationEpcType();
    }

    /**
     * Create an instance of {@link ExtensionStatesType }
     * 
     */
    public ExtensionStatesType createExtensionStatesType() {
        return new ExtensionStatesType();
    }

    /**
     * Create an instance of {@link ContractingStatesType }
     * 
     */
    public ContractingStatesType createContractingStatesType() {
        return new ContractingStatesType();
    }

    /**
     * Create an instance of {@link ExclusionFromDesignationType }
     * 
     */
    public ExclusionFromDesignationType createExclusionFromDesignationType() {
        return new ExclusionFromDesignationType();
    }

    /**
     * Create an instance of {@link PrecautionaryDesignationStatementType }
     * 
     */
    public PrecautionaryDesignationStatementType createPrecautionaryDesignationStatementType() {
        return new PrecautionaryDesignationStatementType();
    }

    /**
     * Create an instance of {@link DesignationPctType }
     * 
     */
    public DesignationPctType createDesignationPctType() {
        return new DesignationPctType();
    }

    /**
     * Create an instance of {@link NewDesignationCountryType }
     * 
     */
    public NewDesignationCountryType createNewDesignationCountryType() {
        return new NewDesignationCountryType();
    }

    /**
     * Create an instance of {@link NationalType }
     * 
     */
    public NationalType createNationalType() {
        return new NationalType();
    }

    /**
     * Create an instance of {@link RegionalType }
     * 
     */
    public RegionalType createRegionalType() {
        return new RegionalType();
    }

    /**
     * Create an instance of {@link AnyOtherStateType }
     * 
     */
    public AnyOtherStateType createAnyOtherStateType() {
        return new AnyOtherStateType();
    }

    /**
     * Create an instance of {@link ProtectionRequestType }
     * 
     */
    public ProtectionRequestType createProtectionRequestType() {
        return new ProtectionRequestType();
    }

    /**
     * Create an instance of {@link KindOfProtectionType }
     * 
     */
    public KindOfProtectionType createKindOfProtectionType() {
        return new KindOfProtectionType();
    }

    /**
     * Create an instance of {@link RegionType }
     * 
     */
    public RegionType createRegionType() {
        return new RegionType();
    }

    /**
     * Create an instance of {@link LapseOfPatentType }
     * 
     */
    public LapseOfPatentType createLapseOfPatentType() {
        return new LapseOfPatentType();
    }

    /**
     * Create an instance of {@link LengthOfGrantType }
     * 
     */
    public LengthOfGrantType createLengthOfGrantType() {
        return new LengthOfGrantType();
    }

    /**
     * Create an instance of {@link DisclaimerType }
     * 
     */
    public DisclaimerType createDisclaimerType() {
        return new DisclaimerType();
    }

    /**
     * Create an instance of {@link CombinationRankType }
     * 
     */
    public CombinationRankType createCombinationRankType() {
        return new CombinationRankType();
    }

    /**
     * Create an instance of {@link UnlinkedIndexingCodeType }
     * 
     */
    public UnlinkedIndexingCodeType createUnlinkedIndexingCodeType() {
        return new UnlinkedIndexingCodeType();
    }

    /**
     * Create an instance of {@link LinkedIndexingCodeGroupType }
     * 
     */
    public LinkedIndexingCodeGroupType createLinkedIndexingCodeGroupType() {
        return new LinkedIndexingCodeGroupType();
    }

    /**
     * Create an instance of {@link SubLinkedIndexingCodeType }
     * 
     */
    public SubLinkedIndexingCodeType createSubLinkedIndexingCodeType() {
        return new SubLinkedIndexingCodeType();
    }

    /**
     * Create an instance of {@link MainLinkedIndexingCodeType }
     * 
     */
    public MainLinkedIndexingCodeType createMainLinkedIndexingCodeType() {
        return new MainLinkedIndexingCodeType();
    }

    /**
     * Create an instance of {@link AdditionalInfoType }
     * 
     */
    public AdditionalInfoType createAdditionalInfoType() {
        return new AdditionalInfoType();
    }

    /**
     * Create an instance of {@link MainClassificationType }
     * 
     */
    public MainClassificationType createMainClassificationType() {
        return new MainClassificationType();
    }

    /**
     * Create an instance of {@link GeneratingOfficeType }
     * 
     */
    public GeneratingOfficeType createGeneratingOfficeType() {
        return new GeneratingOfficeType();
    }

    /**
     * Create an instance of {@link ClassificationDataSourceType }
     * 
     */
    public ClassificationDataSourceType createClassificationDataSourceType() {
        return new ClassificationDataSourceType();
    }

    /**
     * Create an instance of {@link ClassificationStatusType }
     * 
     */
    public ClassificationStatusType createClassificationStatusType() {
        return new ClassificationStatusType();
    }

    /**
     * Create an instance of {@link ActionDateType }
     * 
     */
    public ActionDateType createActionDateType() {
        return new ActionDateType();
    }

    /**
     * Create an instance of {@link ClassificationValueType }
     * 
     */
    public ClassificationValueType createClassificationValueType() {
        return new ClassificationValueType();
    }

    /**
     * Create an instance of {@link SymbolPositionType }
     * 
     */
    public SymbolPositionType createSymbolPositionType() {
        return new SymbolPositionType();
    }

    /**
     * Create an instance of {@link ClassificationLevelType }
     * 
     */
    public ClassificationLevelType createClassificationLevelType() {
        return new ClassificationLevelType();
    }

    /**
     * Create an instance of {@link IpcVersionIndicatorType }
     * 
     */
    public IpcVersionIndicatorType createIpcVersionIndicatorType() {
        return new IpcVersionIndicatorType();
    }

    /**
     * Create an instance of {@link SubgroupType }
     * 
     */
    public SubgroupType createSubgroupType() {
        return new SubgroupType();
    }

    /**
     * Create an instance of {@link MainGroupType }
     * 
     */
    public MainGroupType createMainGroupType() {
        return new MainGroupType();
    }

    /**
     * Create an instance of {@link SubclassType }
     * 
     */
    public SubclassType createSubclassType() {
        return new SubclassType();
    }

    /**
     * Create an instance of {@link SectionType }
     * 
     */
    public SectionType createSectionType() {
        return new SectionType();
    }

    /**
     * Create an instance of {@link ExchPType }
     * 
     */
    public ExchPType createExchPType() {
        return new ExchPType();
    }

    /**
     * Create an instance of {@link AbstSolutionType }
     * 
     */
    public AbstSolutionType createAbstSolutionType() {
        return new AbstSolutionType();
    }

    /**
     * Create an instance of {@link AbstProblemType }
     * 
     */
    public AbstProblemType createAbstProblemType() {
        return new AbstProblemType();
    }

    /**
     * Create an instance of {@link DdType }
     * 
     */
    public DdType createDdType() {
        return new DdType();
    }

    /**
     * Create an instance of {@link MathType }
     * 
     */
    public MathType createMathType() {
        return new MathType();
    }

    /**
     * Create an instance of {@link TermType }
     * 
     */
    public TermType createTermType() {
        return new TermType();
    }

    /**
     * Create an instance of {@link BioAccnoType }
     * 
     */
    public BioAccnoType createBioAccnoType() {
        return new BioAccnoType();
    }

    /**
     * Create an instance of {@link DepositaryType }
     * 
     */
    public DepositaryType createDepositaryType() {
        return new DepositaryType();
    }

    /**
     * Create an instance of {@link OthercitType }
     * 
     */
    public OthercitType createOthercitType() {
        return new OthercitType();
    }

    /**
     * Create an instance of {@link OnlineType }
     * 
     */
    public OnlineType createOnlineType() {
        return new OnlineType();
    }

    /**
     * Create an instance of {@link SrchdateType }
     * 
     */
    public SrchdateType createSrchdateType() {
        return new SrchdateType();
    }

    /**
     * Create an instance of {@link SrchtermType }
     * 
     */
    public SrchtermType createSrchtermType() {
        return new SrchtermType();
    }

    /**
     * Create an instance of {@link DatecitType }
     * 
     */
    public DatecitType createDatecitType() {
        return new DatecitType();
    }

    /**
     * Create an instance of {@link AvailType }
     * 
     */
    public AvailType createAvailType() {
        return new AvailType();
    }

    /**
     * Create an instance of {@link HostnoType }
     * 
     */
    public HostnoType createHostnoType() {
        return new HostnoType();
    }

    /**
     * Create an instance of {@link HistoryType }
     * 
     */
    public HistoryType createHistoryType() {
        return new HistoryType();
    }

    /**
     * Create an instance of {@link MiscType }
     * 
     */
    public MiscType createMiscType() {
        return new MiscType();
    }

    /**
     * Create an instance of {@link RevisedType }
     * 
     */
    public RevisedType createRevisedType() {
        return new RevisedType();
    }

    /**
     * Create an instance of {@link AcceptedType }
     * 
     */
    public AcceptedType createAcceptedType() {
        return new AcceptedType();
    }

    /**
     * Create an instance of {@link ReceivedType }
     * 
     */
    public ReceivedType createReceivedType() {
        return new ReceivedType();
    }

    /**
     * Create an instance of {@link HosttitleType }
     * 
     */
    public HosttitleType createHosttitleType() {
        return new HosttitleType();
    }

    /**
     * Create an instance of {@link OnlineTitleType }
     * 
     */
    public OnlineTitleType createOnlineTitleType() {
        return new OnlineTitleType();
    }

    /**
     * Create an instance of {@link ArticleType }
     * 
     */
    public ArticleType createArticleType() {
        return new ArticleType();
    }

    /**
     * Create an instance of {@link ArtidType }
     * 
     */
    public ArtidType createArtidType() {
        return new ArtidType();
    }

    /**
     * Create an instance of {@link BookType }
     * 
     */
    public BookType createBookType() {
        return new BookType();
    }

    /**
     * Create an instance of {@link KeywordType }
     * 
     */
    public KeywordType createKeywordType() {
        return new KeywordType();
    }

    /**
     * Create an instance of {@link BooknoType }
     * 
     */
    public BooknoType createBooknoType() {
        return new BooknoType();
    }

    /**
     * Create an instance of {@link LocationType }
     * 
     */
    public LocationType createLocationType() {
        return new LocationType();
    }

    /**
     * Create an instance of {@link LineType }
     * 
     */
    public LineType createLineType() {
        return new LineType();
    }

    /**
     * Create an instance of {@link LinelType }
     * 
     */
    public LinelType createLinelType() {
        return new LinelType();
    }

    /**
     * Create an instance of {@link LinefType }
     * 
     */
    public LinefType createLinefType() {
        return new LinefType();
    }

    /**
     * Create an instance of {@link ParaType }
     * 
     */
    public ParaType createParaType() {
        return new ParaType();
    }

    /**
     * Create an instance of {@link ParalType }
     * 
     */
    public ParalType createParalType() {
        return new ParalType();
    }

    /**
     * Create an instance of {@link ParafType }
     * 
     */
    public ParafType createParafType() {
        return new ParafType();
    }

    /**
     * Create an instance of {@link ColumnType }
     * 
     */
    public ColumnType createColumnType() {
        return new ColumnType();
    }

    /**
     * Create an instance of {@link CollType }
     * 
     */
    public CollType createCollType() {
        return new CollType();
    }

    /**
     * Create an instance of {@link ColfType }
     * 
     */
    public ColfType createColfType() {
        return new ColfType();
    }

    /**
     * Create an instance of {@link PpType }
     * 
     */
    public PpType createPpType() {
        return new PpType();
    }

    /**
     * Create an instance of {@link PplType }
     * 
     */
    public PplType createPplType() {
        return new PplType();
    }

    /**
     * Create an instance of {@link PpfType }
     * 
     */
    public PpfType createPpfType() {
        return new PpfType();
    }

    /**
     * Create an instance of {@link ChapterType }
     * 
     */
    public ChapterType createChapterType() {
        return new ChapterType();
    }

    /**
     * Create an instance of {@link SersectType }
     * 
     */
    public SersectType createSersectType() {
        return new SersectType();
    }

    /**
     * Create an instance of {@link SerpartType }
     * 
     */
    public SerpartType createSerpartType() {
        return new SerpartType();
    }

    /**
     * Create an instance of {@link AbsnoType }
     * 
     */
    public AbsnoType createAbsnoType() {
        return new AbsnoType();
    }

    /**
     * Create an instance of {@link SeriesType }
     * 
     */
    public SeriesType createSeriesType() {
        return new SeriesType();
    }

    /**
     * Create an instance of {@link MsnType }
     * 
     */
    public MsnType createMsnType() {
        return new MsnType();
    }

    /**
     * Create an instance of {@link MstType }
     * 
     */
    public MstType createMstType() {
        return new MstType();
    }

    /**
     * Create an instance of {@link EditionType }
     * 
     */
    public EditionType createEditionType() {
        return new EditionType();
    }

    /**
     * Create an instance of {@link SubtitleType }
     * 
     */
    public SubtitleType createSubtitleType() {
        return new SubtitleType();
    }

    /**
     * Create an instance of {@link ConferenceType }
     * 
     */
    public ConferenceType createConferenceType() {
        return new ConferenceType();
    }

    /**
     * Create an instance of {@link ConfsponsorType }
     * 
     */
    public ConfsponsorType createConfsponsorType() {
        return new ConfsponsorType();
    }

    /**
     * Create an instance of {@link ConfplaceType }
     * 
     */
    public ConfplaceType createConfplaceType() {
        return new ConfplaceType();
    }

    /**
     * Create an instance of {@link ConfnoType }
     * 
     */
    public ConfnoType createConfnoType() {
        return new ConfnoType();
    }

    /**
     * Create an instance of {@link ConftitleType }
     * 
     */
    public ConftitleType createConftitleType() {
        return new ConftitleType();
    }

    /**
     * Create an instance of {@link BookTitleType }
     * 
     */
    public BookTitleType createBookTitleType() {
        return new BookTitleType();
    }

    /**
     * Create an instance of {@link SerialType }
     * 
     */
    public SerialType createSerialType() {
        return new SerialType();
    }

    /**
     * Create an instance of {@link CpyrtType }
     * 
     */
    public CpyrtType createCpyrtType() {
        return new CpyrtType();
    }

    /**
     * Create an instance of {@link IsbnType }
     * 
     */
    public IsbnType createIsbnType() {
        return new IsbnType();
    }

    /**
     * Create an instance of {@link IssnType }
     * 
     */
    public IssnType createIssnType() {
        return new IssnType();
    }

    /**
     * Create an instance of {@link InoType }
     * 
     */
    public InoType createInoType() {
        return new InoType();
    }

    /**
     * Create an instance of {@link DoiType }
     * 
     */
    public DoiType createDoiType() {
        return new DoiType();
    }

    /**
     * Create an instance of {@link VidType }
     * 
     */
    public VidType createVidType() {
        return new VidType();
    }

    /**
     * Create an instance of {@link PubidType }
     * 
     */
    public PubidType createPubidType() {
        return new PubidType();
    }

    /**
     * Create an instance of {@link NotesType }
     * 
     */
    public NotesType createNotesType() {
        return new NotesType();
    }

    /**
     * Create an instance of {@link DescripType }
     * 
     */
    public DescripType createDescripType() {
        return new DescripType();
    }

    /**
     * Create an instance of {@link ImprintType }
     * 
     */
    public ImprintType createImprintType() {
        return new ImprintType();
    }

    /**
     * Create an instance of {@link PubdateType }
     * 
     */
    public PubdateType createPubdateType() {
        return new PubdateType();
    }

    /**
     * Create an instance of {@link TimeType }
     * 
     */
    public TimeType createTimeType() {
        return new TimeType();
    }

    /**
     * Create an instance of {@link EdateType }
     * 
     */
    public EdateType createEdateType() {
        return new EdateType();
    }

    /**
     * Create an instance of {@link SdateType }
     * 
     */
    public SdateType createSdateType() {
        return new SdateType();
    }

    /**
     * Create an instance of {@link IssueType }
     * 
     */
    public IssueType createIssueType() {
        return new IssueType();
    }

    /**
     * Create an instance of {@link AlttitleType }
     * 
     */
    public AlttitleType createAlttitleType() {
        return new AlttitleType();
    }

    /**
     * Create an instance of {@link SertitleType }
     * 
     */
    public SertitleType createSertitleType() {
        return new SertitleType();
    }

    /**
     * Create an instance of {@link AtlType }
     * 
     */
    public AtlType createAtlType() {
        return new AtlType();
    }

    /**
     * Create an instance of {@link DtextType }
     * 
     */
    public DtextType createDtextType() {
        return new DtextType();
    }

    /**
     * Create an instance of {@link EadType }
     * 
     */
    public EadType createEadType() {
        return new EadType();
    }

    /**
     * Create an instance of {@link UrlType }
     * 
     */
    public UrlType createUrlType() {
        return new UrlType();
    }

    /**
     * Create an instance of {@link EmailType }
     * 
     */
    public EmailType createEmailType() {
        return new EmailType();
    }

    /**
     * Create an instance of {@link FaxType }
     * 
     */
    public FaxType createFaxType() {
        return new FaxType();
    }

    /**
     * Create an instance of {@link PhoneType }
     * 
     */
    public PhoneType createPhoneType() {
        return new PhoneType();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link PostcodeType }
     * 
     */
    public PostcodeType createPostcodeType() {
        return new PostcodeType();
    }

    /**
     * Create an instance of {@link StateType }
     * 
     */
    public StateType createStateType() {
        return new StateType();
    }

    /**
     * Create an instance of {@link CountyType }
     * 
     */
    public CountyType createCountyType() {
        return new CountyType();
    }

    /**
     * Create an instance of {@link CityType }
     * 
     */
    public CityType createCityType() {
        return new CityType();
    }

    /**
     * Create an instance of {@link StreetType }
     * 
     */
    public StreetType createStreetType() {
        return new StreetType();
    }

    /**
     * Create an instance of {@link BuildingType }
     * 
     */
    public BuildingType createBuildingType() {
        return new BuildingType();
    }

    /**
     * Create an instance of {@link AddressFloorType }
     * 
     */
    public AddressFloorType createAddressFloorType() {
        return new AddressFloorType();
    }

    /**
     * Create an instance of {@link RoomType }
     * 
     */
    public RoomType createRoomType() {
        return new RoomType();
    }

    /**
     * Create an instance of {@link PoboxType }
     * 
     */
    public PoboxType createPoboxType() {
        return new PoboxType();
    }

    /**
     * Create an instance of {@link MailcodeType }
     * 
     */
    public MailcodeType createMailcodeType() {
        return new MailcodeType();
    }

    /**
     * Create an instance of {@link Address3Type }
     * 
     */
    public Address3Type createAddress3Type() {
        return new Address3Type();
    }

    /**
     * Create an instance of {@link Address2Type }
     * 
     */
    public Address2Type createAddress2Type() {
        return new Address2Type();
    }

    /**
     * Create an instance of {@link Address1Type }
     * 
     */
    public Address1Type createAddress1Type() {
        return new Address1Type();
    }

    /**
     * Create an instance of {@link RegisteredNumberType }
     * 
     */
    public RegisteredNumberType createRegisteredNumberType() {
        return new RegisteredNumberType();
    }

    /**
     * Create an instance of {@link SynonymType }
     * 
     */
    public SynonymType createSynonymType() {
        return new SynonymType();
    }

    /**
     * Create an instance of {@link DepartmentType }
     * 
     */
    public DepartmentType createDepartmentType() {
        return new DepartmentType();
    }

    /**
     * Create an instance of {@link SuffixType }
     * 
     */
    public SuffixType createSuffixType() {
        return new SuffixType();
    }

    /**
     * Create an instance of {@link PrefixType }
     * 
     */
    public PrefixType createPrefixType() {
        return new PrefixType();
    }

    /**
     * Create an instance of {@link RoleType }
     * 
     */
    public RoleType createRoleType() {
        return new RoleType();
    }

    /**
     * Create an instance of {@link IidType }
     * 
     */
    public IidType createIidType() {
        return new IidType();
    }

    /**
     * Create an instance of {@link OrgnameType }
     * 
     */
    public OrgnameType createOrgnameType() {
        return new OrgnameType();
    }

    /**
     * Create an instance of {@link MiddleNameType }
     * 
     */
    public MiddleNameType createMiddleNameType() {
        return new MiddleNameType();
    }

    /**
     * Create an instance of {@link FirstNameType }
     * 
     */
    public FirstNameType createFirstNameType() {
        return new FirstNameType();
    }

    /**
     * Create an instance of {@link LastNameType }
     * 
     */
    public LastNameType createLastNameType() {
        return new LastNameType();
    }

    /**
     * Create an instance of {@link RelPassageType }
     * 
     */
    public RelPassageType createRelPassageType() {
        return new RelPassageType();
    }

    /**
     * Create an instance of {@link RelClaimsType }
     * 
     */
    public RelClaimsType createRelClaimsType() {
        return new RelClaimsType();
    }

    /**
     * Create an instance of {@link CategoryType }
     * 
     */
    public CategoryType createCategoryType() {
        return new CategoryType();
    }

    /**
     * Create an instance of {@link PassageType }
     * 
     */
    public PassageType createPassageType() {
        return new PassageType();
    }

    /**
     * Create an instance of {@link KindType }
     * 
     */
    public KindType createKindType() {
        return new KindType();
    }

    /**
     * Create an instance of {@link DocNumberType }
     * 
     */
    public DocNumberType createDocNumberType() {
        return new DocNumberType();
    }

    /**
     * Create an instance of {@link PreType }
     * 
     */
    public PreType createPreType() {
        return new PreType();
    }

    /**
     * Create an instance of {@link BrType }
     * 
     */
    public BrType createBrType() {
        return new BrType();
    }

    /**
     * Create an instance of {@link BType }
     * 
     */
    public BType createBType() {
        return new BType();
    }

    /**
     * Create an instance of {@link IType }
     * 
     */
    public IType createIType() {
        return new IType();
    }

    /**
     * Create an instance of {@link SmallcapsType }
     * 
     */
    public SmallcapsType createSmallcapsType() {
        return new SmallcapsType();
    }

    /**
     * Create an instance of {@link SupType }
     * 
     */
    public SupType createSupType() {
        return new SupType();
    }

    /**
     * Create an instance of {@link SubType }
     * 
     */
    public SubType createSubType() {
        return new SubType();
    }

    /**
     * Create an instance of {@link Sub2Type }
     * 
     */
    public Sub2Type createSub2Type() {
        return new Sub2Type();
    }

    /**
     * Create an instance of {@link Sup2Type }
     * 
     */
    public Sup2Type createSup2Type() {
        return new Sup2Type();
    }

    /**
     * Create an instance of {@link ExchangeDocuments }
     * 
     */
    public ExchangeDocuments createExchangeDocuments() {
        return new ExchangeDocuments();
    }

    /**
     * Create an instance of {@link PType }
     * 
     */
    public PType createPType() {
        return new PType();
    }

    /**
     * Create an instance of {@link SourceDocType }
     * 
     */
    public SourceDocType createSourceDocType() {
        return new SourceDocType();
    }

    /**
     * Create an instance of {@link DocumentIdPrintType }
     * 
     */
    public DocumentIdPrintType createDocumentIdPrintType() {
        return new DocumentIdPrintType();
    }

    /**
     * Create an instance of {@link ConfdateType }
     * 
     */
    public ConfdateType createConfdateType() {
        return new ConfdateType();
    }

    /**
     * Create an instance of {@link RangedateType }
     * 
     */
    public RangedateType createRangedateType() {
        return new RangedateType();
    }

    /**
     * Create an instance of {@link NewsgroupType }
     * 
     */
    public NewsgroupType createNewsgroupType() {
        return new NewsgroupType();
    }

    /**
     * Create an instance of {@link PatentClassificationType.ClassificationScheme }
     * 
     */
    public PatentClassificationType.ClassificationScheme createPatentClassificationTypeClassificationScheme() {
        return new PatentClassificationType.ClassificationScheme();
    }

    /**
     * Create an instance of {@link PatentClassificationType.Class }
     * 
     */
    public PatentClassificationType.Class createPatentClassificationTypeClass() {
        return new PatentClassificationType.Class();
    }

    /**
     * Create an instance of {@link PatentClassificationType.ActionDate }
     * 
     */
    public PatentClassificationType.ActionDate createPatentClassificationTypeActionDate() {
        return new PatentClassificationType.ActionDate();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BibliographicDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "bibliographic-data")
    public JAXBElement<BibliographicDataType> createBibliographicData(BibliographicDataType value) {
        return new JAXBElement<BibliographicDataType>(_BibliographicData_QNAME, BibliographicDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstractType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "abstract")
    public JAXBElement<AbstractType> createAbstract(AbstractType value) {
        return new JAXBElement<AbstractType>(_Abstract_QNAME, AbstractType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentFamilyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "patent-family")
    public JAXBElement<PatentFamilyType> createPatentFamily(PatentFamilyType value) {
        return new JAXBElement<PatentFamilyType>(_PatentFamily_QNAME, PatentFamilyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchReportDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "search-report-data")
    public JAXBElement<SearchReportDataType> createSearchReportData(SearchReportDataType value) {
        return new JAXBElement<SearchReportDataType>(_SearchReportData_QNAME, SearchReportDataType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-date")
    public JAXBElement<PriorityDateType> createPriorityDate(PriorityDateType value) {
        return new JAXBElement<PriorityDateType>(_PriorityDate_QNAME, PriorityDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComplianceUnityInventionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "compliance-unity-invention")
    public JAXBElement<ComplianceUnityInventionType> createComplianceUnityInvention(ComplianceUnityInventionType value) {
        return new JAXBElement<ComplianceUnityInventionType>(_ComplianceUnityInvention_QNAME, ComplianceUnityInventionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InvitationPayAdditionalFeesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "invitation-pay-additional-fees")
    public JAXBElement<InvitationPayAdditionalFeesType> createInvitationPayAdditionalFees(InvitationPayAdditionalFeesType value) {
        return new JAXBElement<InvitationPayAdditionalFeesType>(_InvitationPayAdditionalFees_QNAME, InvitationPayAdditionalFeesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListingComputerReadableFormType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-listing-computer-readable-form")
    public JAXBElement<SequenceListingComputerReadableFormType> createSequenceListingComputerReadableForm(SequenceListingComputerReadableFormType value) {
        return new JAXBElement<SequenceListingComputerReadableFormType>(_SequenceListingComputerReadableForm_QNAME, SequenceListingComputerReadableFormType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListingWrittenFormType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-listing-written-form")
    public JAXBElement<SequenceListingWrittenFormType> createSequenceListingWrittenForm(SequenceListingWrittenFormType value) {
        return new JAXBElement<SequenceListingWrittenFormType>(_SequenceListingWrittenForm_QNAME, SequenceListingWrittenFormType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityOpinionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-opinion")
    public JAXBElement<PriorityOpinionType> createPriorityOpinion(PriorityOpinionType value) {
        return new JAXBElement<PriorityOpinionType>(_PriorityOpinion_QNAME, PriorityOpinionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EarlierApplType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "earlier-appl")
    public JAXBElement<EarlierApplType> createEarlierAppl(EarlierApplType value) {
        return new JAXBElement<EarlierApplType>(_EarlierAppl_QNAME, EarlierApplType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TranslationOfApplType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "translation-of-appl")
    public JAXBElement<TranslationOfApplType> createTranslationOfAppl(TranslationOfApplType value) {
        return new JAXBElement<TranslationOfApplType>(_TranslationOfAppl_QNAME, TranslationOfApplType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepPatentFamilyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-patent-family")
    public JAXBElement<SrepPatentFamilyType> createSrepPatentFamily(SrepPatentFamilyType value) {
        return new JAXBElement<SrepPatentFamilyType>(_SrepPatentFamily_QNAME, SrepPatentFamilyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepInformationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-information")
    public JAXBElement<SrepInformationType> createSrepInformation(SrepInformationType value) {
        return new JAXBElement<SrepInformationType>(_SrepInformation_QNAME, SrepInformationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "electronic-signature")
    public JAXBElement<ElectronicSignatureType> createElectronicSignature(ElectronicSignatureType value) {
        return new JAXBElement<ElectronicSignatureType>(_ElectronicSignature_QNAME, ElectronicSignatureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaxImageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "fax-image")
    public JAXBElement<FaxImageType> createFaxImage(FaxImageType value) {
        return new JAXBElement<FaxImageType>(_FaxImage_QNAME, FaxImageType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFigureToPublishType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-figure-to-publish")
    public JAXBElement<SrepFigureToPublishType> createSrepFigureToPublish(SrepFigureToPublishType value) {
        return new JAXBElement<SrepFigureToPublishType>(_SrepFigureToPublish_QNAME, SrepFigureToPublishType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchFeeProtestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "search-fee-protest")
    public JAXBElement<SearchFeeProtestType> createSearchFeeProtest(SearchFeeProtestType value) {
        return new JAXBElement<SearchFeeProtestType>(_SearchFeeProtest_QNAME, SearchFeeProtestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListingFilingTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-listing-filing-time")
    public JAXBElement<SequenceListingFilingTimeType> createSequenceListingFilingTime(SequenceListingFilingTimeType value) {
        return new JAXBElement<SequenceListingFilingTimeType>(_SequenceListingFilingTime_QNAME, SequenceListingFilingTimeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListingMaterialFormatType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-listing-material-format")
    public JAXBElement<SequenceListingMaterialFormatType> createSequenceListingMaterialFormat(SequenceListingMaterialFormatType value) {
        return new JAXBElement<SequenceListingMaterialFormatType>(_SequenceListingMaterialFormat_QNAME, SequenceListingMaterialFormatType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListingMaterialTypeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-listing-material-type")
    public JAXBElement<SequenceListingMaterialTypeType> createSequenceListingMaterialType(SequenceListingMaterialTypeType value) {
        return new JAXBElement<SequenceListingMaterialTypeType>(_SequenceListingMaterialType_QNAME, SequenceListingMaterialTypeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasisLanguageForSearchType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "basis-language-for-search")
    public JAXBElement<BasisLanguageForSearchType> createBasisLanguageForSearch(BasisLanguageForSearchType value) {
        return new JAXBElement<BasisLanguageForSearchType>(_BasisLanguageForSearch_QNAME, BasisLanguageForSearchType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepPriorArtDocsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-prior-art-docs")
    public JAXBElement<SrepPriorArtDocsType> createSrepPriorArtDocs(SrepPriorArtDocsType value) {
        return new JAXBElement<SrepPriorArtDocsType>(_SrepPriorArtDocs_QNAME, SrepPriorArtDocsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorArtXmlDocType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "prior-art-xml-doc")
    public JAXBElement<PriorArtXmlDocType> createPriorArtXmlDoc(PriorArtXmlDocType value) {
        return new JAXBElement<PriorArtXmlDocType>(_PriorArtXmlDoc_QNAME, PriorArtXmlDocType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepProtestFeesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-protest-fees")
    public JAXBElement<SrepProtestFeesType> createSrepProtestFees(SrepProtestFeesType value) {
        return new JAXBElement<SrepProtestFeesType>(_SrepProtestFees_QNAME, SrepProtestFeesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepEstablishedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-established")
    public JAXBElement<SrepEstablishedType> createSrepEstablished(SrepEstablishedType value) {
        return new JAXBElement<SrepEstablishedType>(_SrepEstablished_QNAME, SrepEstablishedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link St50RepublicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "st50-republication")
    public JAXBElement<St50RepublicationType> createSt50Republication(St50RepublicationType value) {
        return new JAXBElement<St50RepublicationType>(_St50Republication_QNAME, St50RepublicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RepublicationNoteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "republication-note")
    public JAXBElement<RepublicationNoteType> createRepublicationNote(RepublicationNoteType value) {
        return new JAXBElement<RepublicationNoteType>(_RepublicationNote_QNAME, RepublicationNoteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedPartType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-part")
    public JAXBElement<ModifiedPartType> createModifiedPart(ModifiedPartType value) {
        return new JAXBElement<ModifiedPartType>(_ModifiedPart_QNAME, ModifiedPartType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedItemType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-item")
    public JAXBElement<ModifiedItemType> createModifiedItem(ModifiedItemType value) {
        return new JAXBElement<ModifiedItemType>(_ModifiedItem_QNAME, ModifiedItemType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InidCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inid-code")
    public JAXBElement<InidCodeType> createInidCode(InidCodeType value) {
        return new JAXBElement<InidCodeType>(_InidCode_QNAME, InidCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReferencesCitedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "references-cited")
    public JAXBElement<ReferencesCitedType> createReferencesCited(ReferencesCitedType value) {
        return new JAXBElement<ReferencesCitedType>(_ReferencesCited_QNAME, ReferencesCitedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CitationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "citation")
    public JAXBElement<CitationType> createCitation(CitationType value) {
        return new JAXBElement<CitationType>(_Citation_QNAME, CitationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityClaimType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-claim")
    public JAXBElement<PriorityClaimType> createPriorityClaim(PriorityClaimType value) {
        return new JAXBElement<PriorityClaimType>(_PriorityClaim_QNAME, PriorityClaimType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "agent")
    public JAXBElement<AgentType> createAgent(AgentType value) {
        return new JAXBElement<AgentType>(_Agent_QNAME, AgentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeceasedInventorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "deceased-inventor")
    public JAXBElement<DeceasedInventorType> createDeceasedInventor(DeceasedInventorType value) {
        return new JAXBElement<DeceasedInventorType>(_DeceasedInventor_QNAME, DeceasedInventorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventorNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inventor-name")
    public JAXBElement<InventorNameType> createInventorName(InventorNameType value) {
        return new JAXBElement<InventorNameType>(_InventorName_QNAME, InventorNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "applicant")
    public JAXBElement<ApplicantType> createApplicant(ApplicantType value) {
        return new JAXBElement<ApplicantType>(_Applicant_QNAME, ApplicantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsRightsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "us-rights")
    public JAXBElement<UsRightsType> createUsRights(UsRightsType value) {
        return new JAXBElement<UsRightsType>(_UsRights_QNAME, UsRightsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicantNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "applicant-name")
    public JAXBElement<ApplicantNameType> createApplicantName(ApplicantNameType value) {
        return new JAXBElement<ApplicantNameType>(_ApplicantName_QNAME, ApplicantNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventionTitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "invention-title")
    public JAXBElement<InventionTitleType> createInventionTitle(InventionTitleType value) {
        return new JAXBElement<InventionTitleType>(_InventionTitle_QNAME, InventionTitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesignationOfStatesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "designation-of-states")
    public JAXBElement<DesignationOfStatesType> createDesignationOfStates(DesignationOfStatesType value) {
        return new JAXBElement<DesignationOfStatesType>(_DesignationOfStates_QNAME, DesignationOfStatesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExchangeGazetteReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "gazette-reference")
    public JAXBElement<ExchangeGazetteReferenceType> createGazetteReference(ExchangeGazetteReferenceType value) {
        return new JAXBElement<ExchangeGazetteReferenceType>(_GazetteReference_QNAME, ExchangeGazetteReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstractReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "abstract-reference")
    public JAXBElement<AbstractReferenceType> createAbstractReference(AbstractReferenceType value) {
        return new JAXBElement<AbstractReferenceType>(_AbstractReference_QNAME, AbstractReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-num")
    public JAXBElement<String> createSrepNum(String value) {
        return new JAXBElement<String>(_SrepNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date")
    public JAXBElement<BigInteger> createDate(BigInteger value) {
        return new JAXBElement<BigInteger>(_Date_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GazetteNumType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "gazette-num")
    public JAXBElement<GazetteNumType> createGazetteNum(GazetteNumType value) {
        return new JAXBElement<GazetteNumType>(_GazetteNum_QNAME, GazetteNumType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "text")
    public JAXBElement<TextType> createText(TextType value) {
        return new JAXBElement<TextType>(_Text_QNAME, TextType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedFirstPagePubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-first-page-pub")
    public JAXBElement<ModifiedFirstPagePubType> createModifiedFirstPagePub(ModifiedFirstPagePubType value) {
        return new JAXBElement<ModifiedFirstPagePubType>(_ModifiedFirstPagePub_QNAME, ModifiedFirstPagePubType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedCompleteSpecPubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-complete-spec-pub")
    public JAXBElement<ModifiedCompleteSpecPubType> createModifiedCompleteSpecPub(ModifiedCompleteSpecPubType value) {
        return new JAXBElement<ModifiedCompleteSpecPubType>(_ModifiedCompleteSpecPub_QNAME, ModifiedCompleteSpecPubType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnexaminedNotPrintedWithoutGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "unexamined-not-printed-without-grant")
    public JAXBElement<UnexaminedNotPrintedWithoutGrantType> createUnexaminedNotPrintedWithoutGrant(UnexaminedNotPrintedWithoutGrantType value) {
        return new JAXBElement<UnexaminedNotPrintedWithoutGrantType>(_UnexaminedNotPrintedWithoutGrant_QNAME, UnexaminedNotPrintedWithoutGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExaminedNotPrintedWithoutGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "examined-not-printed-without-grant")
    public JAXBElement<ExaminedNotPrintedWithoutGrantType> createExaminedNotPrintedWithoutGrant(ExaminedNotPrintedWithoutGrantType value) {
        return new JAXBElement<ExaminedNotPrintedWithoutGrantType>(_ExaminedNotPrintedWithoutGrant_QNAME, ExaminedNotPrintedWithoutGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnexaminedPrintedWithoutGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "unexamined-printed-without-grant")
    public JAXBElement<UnexaminedPrintedWithoutGrantType> createUnexaminedPrintedWithoutGrant(UnexaminedPrintedWithoutGrantType value) {
        return new JAXBElement<UnexaminedPrintedWithoutGrantType>(_UnexaminedPrintedWithoutGrant_QNAME, UnexaminedPrintedWithoutGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExaminedPrintedWithoutGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "examined-printed-without-grant")
    public JAXBElement<ExaminedPrintedWithoutGrantType> createExaminedPrintedWithoutGrant(ExaminedPrintedWithoutGrantType value) {
        return new JAXBElement<ExaminedPrintedWithoutGrantType>(_ExaminedPrintedWithoutGrant_QNAME, ExaminedPrintedWithoutGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrintedWithGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "printed-with-grant")
    public JAXBElement<PrintedWithGrantType> createPrintedWithGrant(PrintedWithGrantType value) {
        return new JAXBElement<PrintedWithGrantType>(_PrintedWithGrant_QNAME, PrintedWithGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimsOnlyAvailableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claims-only-available")
    public JAXBElement<ClaimsOnlyAvailableType> createClaimsOnlyAvailable(ClaimsOnlyAvailableType value) {
        return new JAXBElement<ClaimsOnlyAvailableType>(_ClaimsOnlyAvailable_QNAME, ClaimsOnlyAvailableType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotPrintedWithGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "not-printed-with-grant")
    public JAXBElement<NotPrintedWithGrantType> createNotPrintedWithGrant(NotPrintedWithGrantType value) {
        return new JAXBElement<NotPrintedWithGrantType>(_NotPrintedWithGrant_QNAME, NotPrintedWithGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InvalidationOfPatentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "invalidation-of-patent")
    public JAXBElement<InvalidationOfPatentType> createInvalidationOfPatent(InvalidationOfPatentType value) {
        return new JAXBElement<InvalidationOfPatentType>(_InvalidationOfPatent_QNAME, InvalidationOfPatentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrintedAsAmendedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "printed-as-amended")
    public JAXBElement<PrintedAsAmendedType> createPrintedAsAmended(PrintedAsAmendedType value) {
        return new JAXBElement<PrintedAsAmendedType>(_PrintedAsAmended_QNAME, PrintedAsAmendedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentClassificationsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "patent-classifications")
    public JAXBElement<PatentClassificationsType> createPatentClassifications(PatentClassificationsType value) {
        return new JAXBElement<PatentClassificationsType>(_PatentClassifications_QNAME, PatentClassificationsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CombinationSetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "combination-set")
    public JAXBElement<CombinationSetType> createCombinationSet(CombinationSetType value) {
        return new JAXBElement<CombinationSetType>(_CombinationSet_QNAME, CombinationSetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentClassificationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "patent-classification")
    public JAXBElement<PatentClassificationType> createPatentClassification(PatentClassificationType value) {
        return new JAXBElement<PatentClassificationType>(_PatentClassification_QNAME, PatentClassificationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationIpcType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-ipc")
    public JAXBElement<ClassificationIpcType> createClassificationIpc(ClassificationIpcType value) {
        return new JAXBElement<ClassificationIpcType>(_ClassificationIpc_QNAME, ClassificationIpcType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "application-reference")
    public JAXBElement<ApplicationReferenceType> createApplicationReference(ApplicationReferenceType value) {
        return new JAXBElement<ApplicationReferenceType>(_ApplicationReference_QNAME, ApplicationReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreviouslyFiledAppType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "previously-filed-app")
    public JAXBElement<PreviouslyFiledAppType> createPreviouslyFiledApp(PreviouslyFiledAppType value) {
        return new JAXBElement<PreviouslyFiledAppType>(_PreviouslyFiledApp_QNAME, PreviouslyFiledAppType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateOfComingIntoForceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date-of-coming-into-force")
    public JAXBElement<DateOfComingIntoForceType> createDateOfComingIntoForce(DateOfComingIntoForceType value) {
        return new JAXBElement<DateOfComingIntoForceType>(_DateOfComingIntoForce_QNAME, DateOfComingIntoForceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrecedingPublicationDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "preceding-publication-date")
    public JAXBElement<PrecedingPublicationDateType> createPrecedingPublicationDate(PrecedingPublicationDateType value) {
        return new JAXBElement<PrecedingPublicationDateType>(_PrecedingPublicationDate_QNAME, PrecedingPublicationDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LanguageOfPublicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "language-of-publication")
    public JAXBElement<LanguageOfPublicationType> createLanguageOfPublication(LanguageOfPublicationType value) {
        return new JAXBElement<LanguageOfPublicationType>(_LanguageOfPublication_QNAME, LanguageOfPublicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LanguageOfFilingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "language-of-filing")
    public JAXBElement<LanguageOfFilingType> createLanguageOfFiling(LanguageOfFilingType value) {
        return new JAXBElement<LanguageOfFilingType>(_LanguageOfFiling_QNAME, LanguageOfFilingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationNationalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-national")
    public JAXBElement<ClassificationNationalType> createClassificationNational(ClassificationNationalType value) {
        return new JAXBElement<ClassificationNationalType>(_ClassificationNational_QNAME, ClassificationNationalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FurtherClassificationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "further-classification")
    public JAXBElement<FurtherClassificationType> createFurtherClassification(FurtherClassificationType value) {
        return new JAXBElement<FurtherClassificationType>(_FurtherClassification_QNAME, FurtherClassificationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationsIpcrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classifications-ipcr")
    public JAXBElement<ClassificationsIpcrType> createClassificationsIpcr(ClassificationsIpcrType value) {
        return new JAXBElement<ClassificationsIpcrType>(_ClassificationsIpcr_QNAME, ClassificationsIpcrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationIpcrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-ipcr")
    public JAXBElement<ClassificationIpcrType> createClassificationIpcr(ClassificationIpcrType value) {
        return new JAXBElement<ClassificationIpcrType>(_ClassificationIpcr_QNAME, ClassificationIpcrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublicationReferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "publication-reference")
    public JAXBElement<PublicationReferenceType> createPublicationReference(PublicationReferenceType value) {
        return new JAXBElement<PublicationReferenceType>(_PublicationReference_QNAME, PublicationReferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableExternalDocType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "table-external-doc")
    public JAXBElement<TableExternalDocType> createTableExternalDoc(TableExternalDocType value) {
        return new JAXBElement<TableExternalDocType>(_TableExternalDoc_QNAME, TableExternalDocType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TablesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tables")
    public JAXBElement<TablesType> createTables(TablesType value) {
        return new JAXBElement<TablesType>(_Tables_QNAME, TablesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "title")
    public JAXBElement<TitleType> createTitle(TitleType value) {
        return new JAXBElement<TitleType>(_Title_QNAME, TitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TgroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tgroup")
    public JAXBElement<TgroupType> createTgroup(TgroupType value) {
        return new JAXBElement<TgroupType>(_Tgroup_QNAME, TgroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ColspecType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "colspec")
    public JAXBElement<ColspecType> createColspec(ColspecType value) {
        return new JAXBElement<ColspecType>(_Colspec_QNAME, ColspecType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TheadType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "thead")
    public JAXBElement<TheadType> createThead(TheadType value) {
        return new JAXBElement<TheadType>(_Thead_QNAME, TheadType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TbodyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tbody")
    public JAXBElement<TbodyType> createTbody(TbodyType value) {
        return new JAXBElement<TbodyType>(_Tbody_QNAME, TbodyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "row")
    public JAXBElement<RowType> createRow(RowType value) {
        return new JAXBElement<RowType>(_Row_QNAME, RowType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EntryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "entry")
    public JAXBElement<EntryType> createEntry(EntryType value) {
        return new JAXBElement<EntryType>(_Entry_QNAME, EntryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "table")
    public JAXBElement<TableType> createTable(TableType value) {
        return new JAXBElement<TableType>(_Table_QNAME, TableType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "dl")
    public JAXBElement<DlType> createDl(DlType value) {
        return new JAXBElement<DlType>(_Dl_QNAME, DlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ul")
    public JAXBElement<UlType> createUl(UlType value) {
        return new JAXBElement<UlType>(_Ul_QNAME, UlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "li")
    public JAXBElement<LiType> createLi(LiType value) {
        return new JAXBElement<LiType>(_Li_QNAME, LiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "maths")
    public JAXBElement<MathsType> createMaths(MathsType value) {
        return new JAXBElement<MathsType>(_Maths_QNAME, MathsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mi")
    public JAXBElement<MiType> createMi(MiType value) {
        return new JAXBElement<MiType>(_Mi_QNAME, MiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mglyph")
    public JAXBElement<MglyphType> createMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_Mglyph_QNAME, MglyphType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "malignmark")
    public JAXBElement<MalignmarkType> createMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_Malignmark_QNAME, MalignmarkType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mn")
    public JAXBElement<MnType> createMn(MnType value) {
        return new JAXBElement<MnType>(_Mn_QNAME, MnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mo")
    public JAXBElement<MoType> createMo(MoType value) {
        return new JAXBElement<MoType>(_Mo_QNAME, MoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mtext")
    public JAXBElement<MtextType> createMtext(MtextType value) {
        return new JAXBElement<MtextType>(_Mtext_QNAME, MtextType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ms")
    public JAXBElement<MsType> createMs(MsType value) {
        return new JAXBElement<MsType>(_Ms_QNAME, MsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MspaceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mspace")
    public JAXBElement<MspaceType> createMspace(MspaceType value) {
        return new JAXBElement<MspaceType>(_Mspace_QNAME, MspaceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mrow")
    public JAXBElement<MrowType> createMrow(MrowType value) {
        return new JAXBElement<MrowType>(_Mrow_QNAME, MrowType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MprescriptsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mprescripts")
    public JAXBElement<MprescriptsType> createMprescripts(MprescriptsType value) {
        return new JAXBElement<MprescriptsType>(_Mprescripts_QNAME, MprescriptsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoneType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "none")
    public JAXBElement<NoneType> createNone(NoneType value) {
        return new JAXBElement<NoneType>(_None_QNAME, NoneType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfracType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mfrac")
    public JAXBElement<MfracType> createMfrac(MfracType value) {
        return new JAXBElement<MfracType>(_Mfrac_QNAME, MfracType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsqrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "msqrt")
    public JAXBElement<MsqrtType> createMsqrt(MsqrtType value) {
        return new JAXBElement<MsqrtType>(_Msqrt_QNAME, MsqrtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mroot")
    public JAXBElement<MrootType> createMroot(MrootType value) {
        return new JAXBElement<MrootType>(_Mroot_QNAME, MrootType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MencloseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "menclose")
    public JAXBElement<MencloseType> createMenclose(MencloseType value) {
        return new JAXBElement<MencloseType>(_Menclose_QNAME, MencloseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MstyleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mstyle")
    public JAXBElement<MstyleType> createMstyle(MstyleType value) {
        return new JAXBElement<MstyleType>(_Mstyle_QNAME, MstyleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MerrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "merror")
    public JAXBElement<MerrorType> createMerror(MerrorType value) {
        return new JAXBElement<MerrorType>(_Merror_QNAME, MerrorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MpaddedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mpadded")
    public JAXBElement<MpaddedType> createMpadded(MpaddedType value) {
        return new JAXBElement<MpaddedType>(_Mpadded_QNAME, MpaddedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MphantomType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mphantom")
    public JAXBElement<MphantomType> createMphantom(MphantomType value) {
        return new JAXBElement<MphantomType>(_Mphantom_QNAME, MphantomType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfencedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mfenced")
    public JAXBElement<MfencedType> createMfenced(MfencedType value) {
        return new JAXBElement<MfencedType>(_Mfenced_QNAME, MfencedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "msub")
    public JAXBElement<MsubType> createMsub(MsubType value) {
        return new JAXBElement<MsubType>(_Msub_QNAME, MsubType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "msup")
    public JAXBElement<MsupType> createMsup(MsupType value) {
        return new JAXBElement<MsupType>(_Msup_QNAME, MsupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "msubsup")
    public JAXBElement<MsubsupType> createMsubsup(MsubsupType value) {
        return new JAXBElement<MsubsupType>(_Msubsup_QNAME, MsubsupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "munder")
    public JAXBElement<MunderType> createMunder(MunderType value) {
        return new JAXBElement<MunderType>(_Munder_QNAME, MunderType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mover")
    public JAXBElement<MoverType> createMover(MoverType value) {
        return new JAXBElement<MoverType>(_Mover_QNAME, MoverType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "munderover")
    public JAXBElement<MunderoverType> createMunderover(MunderoverType value) {
        return new JAXBElement<MunderoverType>(_Munderover_QNAME, MunderoverType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MmultiscriptsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mmultiscripts")
    public JAXBElement<MmultiscriptsType> createMmultiscripts(MmultiscriptsType value) {
        return new JAXBElement<MmultiscriptsType>(_Mmultiscripts_QNAME, MmultiscriptsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mtable")
    public JAXBElement<MtableType> createMtable(MtableType value) {
        return new JAXBElement<MtableType>(_Mtable_QNAME, MtableType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mtr")
    public JAXBElement<MtrType> createMtr(MtrType value) {
        return new JAXBElement<MtrType>(_Mtr_QNAME, MtrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MlabeledtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mlabeledtr")
    public JAXBElement<MlabeledtrType> createMlabeledtr(MlabeledtrType value) {
        return new JAXBElement<MlabeledtrType>(_Mlabeledtr_QNAME, MlabeledtrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mtd")
    public JAXBElement<MtdType> createMtd(MtdType value) {
        return new JAXBElement<MtdType>(_Mtd_QNAME, MtdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaligngroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "maligngroup")
    public JAXBElement<MaligngroupType> createMaligngroup(MaligngroupType value) {
        return new JAXBElement<MaligngroupType>(_Maligngroup_QNAME, MaligngroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MactionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "maction")
    public JAXBElement<MactionType> createMaction(MactionType value) {
        return new JAXBElement<MactionType>(_Maction_QNAME, MactionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ci")
    public JAXBElement<CiType> createCi(CiType value) {
        return new JAXBElement<CiType>(_Ci_QNAME, CiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CsymbolType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "csymbol")
    public JAXBElement<CsymbolType> createCsymbol(CsymbolType value) {
        return new JAXBElement<CsymbolType>(_Csymbol_QNAME, CsymbolType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cn")
    public JAXBElement<CnType> createCn(CnType value) {
        return new JAXBElement<CnType>(_Cn_QNAME, CnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SepType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sep")
    public JAXBElement<SepType> createSep(SepType value) {
        return new JAXBElement<SepType>(_Sep_QNAME, SepType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntegersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "integers")
    public JAXBElement<IntegersType> createIntegers(IntegersType value) {
        return new JAXBElement<IntegersType>(_Integers_QNAME, IntegersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RealsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "reals")
    public JAXBElement<RealsType> createReals(RealsType value) {
        return new JAXBElement<RealsType>(_Reals_QNAME, RealsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RationalsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "rationals")
    public JAXBElement<RationalsType> createRationals(RationalsType value) {
        return new JAXBElement<RationalsType>(_Rationals_QNAME, RationalsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NaturalnumbersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "naturalnumbers")
    public JAXBElement<NaturalnumbersType> createNaturalnumbers(NaturalnumbersType value) {
        return new JAXBElement<NaturalnumbersType>(_Naturalnumbers_QNAME, NaturalnumbersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComplexesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "complexes")
    public JAXBElement<ComplexesType> createComplexes(ComplexesType value) {
        return new JAXBElement<ComplexesType>(_Complexes_QNAME, ComplexesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrimesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "primes")
    public JAXBElement<PrimesType> createPrimes(PrimesType value) {
        return new JAXBElement<PrimesType>(_Primes_QNAME, PrimesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExponentialeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "exponentiale")
    public JAXBElement<ExponentialeType> createExponentiale(ExponentialeType value) {
        return new JAXBElement<ExponentialeType>(_Exponentiale_QNAME, ExponentialeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImaginaryiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "imaginaryi")
    public JAXBElement<ImaginaryiType> createImaginaryi(ImaginaryiType value) {
        return new JAXBElement<ImaginaryiType>(_Imaginaryi_QNAME, ImaginaryiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotanumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "notanumber")
    public JAXBElement<NotanumberType> createNotanumber(NotanumberType value) {
        return new JAXBElement<NotanumberType>(_Notanumber_QNAME, NotanumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TrueType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "true")
    public JAXBElement<TrueType> createTrue(TrueType value) {
        return new JAXBElement<TrueType>(_True_QNAME, TrueType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FalseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "false")
    public JAXBElement<FalseType> createFalse(FalseType value) {
        return new JAXBElement<FalseType>(_False_QNAME, FalseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmptysetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "emptyset")
    public JAXBElement<EmptysetType> createEmptyset(EmptysetType value) {
        return new JAXBElement<EmptysetType>(_Emptyset_QNAME, EmptysetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pi")
    public JAXBElement<PiType> createPi(PiType value) {
        return new JAXBElement<PiType>(_Pi_QNAME, PiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EulergammaType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "eulergamma")
    public JAXBElement<EulergammaType> createEulergamma(EulergammaType value) {
        return new JAXBElement<EulergammaType>(_Eulergamma_QNAME, EulergammaType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InfinityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "infinity")
    public JAXBElement<InfinityType> createInfinity(InfinityType value) {
        return new JAXBElement<InfinityType>(_Infinity_QNAME, InfinityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "apply")
    public JAXBElement<ApplyType> createApply(ApplyType value) {
        return new JAXBElement<ApplyType>(_Apply_QNAME, ApplyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "reln")
    public JAXBElement<RelnType> createReln(RelnType value) {
        return new JAXBElement<RelnType>(_Reln_QNAME, RelnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LambdaType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "lambda")
    public JAXBElement<LambdaType> createLambda(LambdaType value) {
        return new JAXBElement<LambdaType>(_Lambda_QNAME, LambdaType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConditionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "condition")
    public JAXBElement<ConditionType> createCondition(ConditionType value) {
        return new JAXBElement<ConditionType>(_Condition_QNAME, ConditionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeclareType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "declare")
    public JAXBElement<DeclareType> createDeclare(DeclareType value) {
        return new JAXBElement<DeclareType>(_Declare_QNAME, DeclareType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SemanticsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "semantics")
    public JAXBElement<SemanticsType> createSemantics(SemanticsType value) {
        return new JAXBElement<SemanticsType>(_Semantics_QNAME, SemanticsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnotationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "annotation")
    public JAXBElement<AnnotationType> createAnnotation(AnnotationType value) {
        return new JAXBElement<AnnotationType>(_Annotation_QNAME, AnnotationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnotationXmlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "annotation-xml")
    public JAXBElement<AnnotationXmlType> createAnnotationXml(AnnotationXmlType value) {
        return new JAXBElement<AnnotationXmlType>(_AnnotationXml_QNAME, AnnotationXmlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntervalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "interval")
    public JAXBElement<IntervalType> createInterval(IntervalType value) {
        return new JAXBElement<IntervalType>(_Interval_QNAME, IntervalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "list")
    public JAXBElement<ListType> createList(ListType value) {
        return new JAXBElement<ListType>(_List_QNAME, ListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MatrixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "matrix")
    public JAXBElement<MatrixType> createMatrix(MatrixType value) {
        return new JAXBElement<MatrixType>(_Matrix_QNAME, MatrixType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MatrixrowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "matrixrow")
    public JAXBElement<MatrixrowType> createMatrixrow(MatrixrowType value) {
        return new JAXBElement<MatrixrowType>(_Matrixrow_QNAME, MatrixrowType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "set")
    public JAXBElement<SetType> createSet(SetType value) {
        return new JAXBElement<SetType>(_Set_QNAME, SetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VectorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "vector")
    public JAXBElement<VectorType> createVector(VectorType value) {
        return new JAXBElement<VectorType>(_Vector_QNAME, VectorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PiecewiseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "piecewise")
    public JAXBElement<PiecewiseType> createPiecewise(PiecewiseType value) {
        return new JAXBElement<PiecewiseType>(_Piecewise_QNAME, PiecewiseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PieceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "piece")
    public JAXBElement<PieceType> createPiece(PieceType value) {
        return new JAXBElement<PieceType>(_Piece_QNAME, PieceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OtherwiseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "otherwise")
    public JAXBElement<OtherwiseType> createOtherwise(OtherwiseType value) {
        return new JAXBElement<OtherwiseType>(_Otherwise_QNAME, OtherwiseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LowlimitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "lowlimit")
    public JAXBElement<LowlimitType> createLowlimit(LowlimitType value) {
        return new JAXBElement<LowlimitType>(_Lowlimit_QNAME, LowlimitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UplimitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "uplimit")
    public JAXBElement<UplimitType> createUplimit(UplimitType value) {
        return new JAXBElement<UplimitType>(_Uplimit_QNAME, UplimitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BvarType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "bvar")
    public JAXBElement<BvarType> createBvar(BvarType value) {
        return new JAXBElement<BvarType>(_Bvar_QNAME, BvarType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DegreeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "degree")
    public JAXBElement<DegreeType> createDegree(DegreeType value) {
        return new JAXBElement<DegreeType>(_Degree_QNAME, DegreeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LogbaseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "logbase")
    public JAXBElement<LogbaseType> createLogbase(LogbaseType value) {
        return new JAXBElement<LogbaseType>(_Logbase_QNAME, LogbaseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MomentaboutType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "momentabout")
    public JAXBElement<MomentaboutType> createMomentabout(MomentaboutType value) {
        return new JAXBElement<MomentaboutType>(_Momentabout_QNAME, MomentaboutType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DomainofapplicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "domainofapplication")
    public JAXBElement<DomainofapplicationType> createDomainofapplication(DomainofapplicationType value) {
        return new JAXBElement<DomainofapplicationType>(_Domainofapplication_QNAME, DomainofapplicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InverseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inverse")
    public JAXBElement<InverseType> createInverse(InverseType value) {
        return new JAXBElement<InverseType>(_Inverse_QNAME, InverseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ident")
    public JAXBElement<IdentType> createIdent(IdentType value) {
        return new JAXBElement<IdentType>(_Ident_QNAME, IdentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DomainType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "domain")
    public JAXBElement<DomainType> createDomain(DomainType value) {
        return new JAXBElement<DomainType>(_Domain_QNAME, DomainType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CodomainType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "codomain")
    public JAXBElement<CodomainType> createCodomain(CodomainType value) {
        return new JAXBElement<CodomainType>(_Codomain_QNAME, CodomainType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "image")
    public JAXBElement<ImageType> createImage(ImageType value) {
        return new JAXBElement<ImageType>(_Image_QNAME, ImageType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "abs")
    public JAXBElement<AbsType> createAbs(AbsType value) {
        return new JAXBElement<AbsType>(_Abs_QNAME, AbsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConjugateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "conjugate")
    public JAXBElement<ConjugateType> createConjugate(ConjugateType value) {
        return new JAXBElement<ConjugateType>(_Conjugate_QNAME, ConjugateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExpType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "exp")
    public JAXBElement<ExpType> createExp(ExpType value) {
        return new JAXBElement<ExpType>(_Exp_QNAME, ExpType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FactorialType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "factorial")
    public JAXBElement<FactorialType> createFactorial(FactorialType value) {
        return new JAXBElement<FactorialType>(_Factorial_QNAME, FactorialType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arg")
    public JAXBElement<ArgType> createArg(ArgType value) {
        return new JAXBElement<ArgType>(_Arg_QNAME, ArgType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RealType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "real")
    public JAXBElement<RealType> createReal(RealType value) {
        return new JAXBElement<RealType>(_Real_QNAME, RealType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImaginaryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "imaginary")
    public JAXBElement<ImaginaryType> createImaginary(ImaginaryType value) {
        return new JAXBElement<ImaginaryType>(_Imaginary_QNAME, ImaginaryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FloorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "floor")
    public JAXBElement<FloorType> createFloor(FloorType value) {
        return new JAXBElement<FloorType>(_Floor_QNAME, FloorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CeilingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ceiling")
    public JAXBElement<CeilingType> createCeiling(CeilingType value) {
        return new JAXBElement<CeilingType>(_Ceiling_QNAME, CeilingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "not")
    public JAXBElement<NotType> createNot(NotType value) {
        return new JAXBElement<NotType>(_Not_QNAME, NotType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ln")
    public JAXBElement<LnType> createLn(LnType value) {
        return new JAXBElement<LnType>(_Ln_QNAME, LnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SinType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sin")
    public JAXBElement<SinType> createSin(SinType value) {
        return new JAXBElement<SinType>(_Sin_QNAME, SinType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CosType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cos")
    public JAXBElement<CosType> createCos(CosType value) {
        return new JAXBElement<CosType>(_Cos_QNAME, CosType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tan")
    public JAXBElement<TanType> createTan(TanType value) {
        return new JAXBElement<TanType>(_Tan_QNAME, TanType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SecType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sec")
    public JAXBElement<SecType> createSec(SecType value) {
        return new JAXBElement<SecType>(_Sec_QNAME, SecType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CscType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "csc")
    public JAXBElement<CscType> createCsc(CscType value) {
        return new JAXBElement<CscType>(_Csc_QNAME, CscType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CotType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cot")
    public JAXBElement<CotType> createCot(CotType value) {
        return new JAXBElement<CotType>(_Cot_QNAME, CotType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SinhType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sinh")
    public JAXBElement<SinhType> createSinh(SinhType value) {
        return new JAXBElement<SinhType>(_Sinh_QNAME, SinhType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CoshType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cosh")
    public JAXBElement<CoshType> createCosh(CoshType value) {
        return new JAXBElement<CoshType>(_Cosh_QNAME, CoshType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TanhType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tanh")
    public JAXBElement<TanhType> createTanh(TanhType value) {
        return new JAXBElement<TanhType>(_Tanh_QNAME, TanhType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SechType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sech")
    public JAXBElement<SechType> createSech(SechType value) {
        return new JAXBElement<SechType>(_Sech_QNAME, SechType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CschType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "csch")
    public JAXBElement<CschType> createCsch(CschType value) {
        return new JAXBElement<CschType>(_Csch_QNAME, CschType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CothType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "coth")
    public JAXBElement<CothType> createCoth(CothType value) {
        return new JAXBElement<CothType>(_Coth_QNAME, CothType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArcsinType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arcsin")
    public JAXBElement<ArcsinType> createArcsin(ArcsinType value) {
        return new JAXBElement<ArcsinType>(_Arcsin_QNAME, ArcsinType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccosType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccos")
    public JAXBElement<ArccosType> createArccos(ArccosType value) {
        return new JAXBElement<ArccosType>(_Arccos_QNAME, ArccosType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArctanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arctan")
    public JAXBElement<ArctanType> createArctan(ArctanType value) {
        return new JAXBElement<ArctanType>(_Arctan_QNAME, ArctanType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccoshType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccosh")
    public JAXBElement<ArccoshType> createArccosh(ArccoshType value) {
        return new JAXBElement<ArccoshType>(_Arccosh_QNAME, ArccoshType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccotType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccot")
    public JAXBElement<ArccotType> createArccot(ArccotType value) {
        return new JAXBElement<ArccotType>(_Arccot_QNAME, ArccotType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccothType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccoth")
    public JAXBElement<ArccothType> createArccoth(ArccothType value) {
        return new JAXBElement<ArccothType>(_Arccoth_QNAME, ArccothType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccscType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccsc")
    public JAXBElement<ArccscType> createArccsc(ArccscType value) {
        return new JAXBElement<ArccscType>(_Arccsc_QNAME, ArccscType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArccschType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arccsch")
    public JAXBElement<ArccschType> createArccsch(ArccschType value) {
        return new JAXBElement<ArccschType>(_Arccsch_QNAME, ArccschType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArcsecType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arcsec")
    public JAXBElement<ArcsecType> createArcsec(ArcsecType value) {
        return new JAXBElement<ArcsecType>(_Arcsec_QNAME, ArcsecType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArcsechType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arcsech")
    public JAXBElement<ArcsechType> createArcsech(ArcsechType value) {
        return new JAXBElement<ArcsechType>(_Arcsech_QNAME, ArcsechType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArcsinhType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arcsinh")
    public JAXBElement<ArcsinhType> createArcsinh(ArcsinhType value) {
        return new JAXBElement<ArcsinhType>(_Arcsinh_QNAME, ArcsinhType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArctanhType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "arctanh")
    public JAXBElement<ArctanhType> createArctanh(ArctanhType value) {
        return new JAXBElement<ArctanhType>(_Arctanh_QNAME, ArctanhType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeterminantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "determinant")
    public JAXBElement<DeterminantType> createDeterminant(DeterminantType value) {
        return new JAXBElement<DeterminantType>(_Determinant_QNAME, DeterminantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransposeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "transpose")
    public JAXBElement<TransposeType> createTranspose(TransposeType value) {
        return new JAXBElement<TransposeType>(_Transpose_QNAME, TransposeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "card")
    public JAXBElement<CardType> createCard(CardType value) {
        return new JAXBElement<CardType>(_Card_QNAME, CardType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QuotientType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "quotient")
    public JAXBElement<QuotientType> createQuotient(QuotientType value) {
        return new JAXBElement<QuotientType>(_Quotient_QNAME, QuotientType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DivideType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "divide")
    public JAXBElement<DivideType> createDivide(DivideType value) {
        return new JAXBElement<DivideType>(_Divide_QNAME, DivideType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PowerType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "power")
    public JAXBElement<PowerType> createPower(PowerType value) {
        return new JAXBElement<PowerType>(_Power_QNAME, PowerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "rem")
    public JAXBElement<RemType> createRem(RemType value) {
        return new JAXBElement<RemType>(_Rem_QNAME, RemType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImpliesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "implies")
    public JAXBElement<ImpliesType> createImplies(ImpliesType value) {
        return new JAXBElement<ImpliesType>(_Implies_QNAME, ImpliesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VectorproductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "vectorproduct")
    public JAXBElement<VectorproductType> createVectorproduct(VectorproductType value) {
        return new JAXBElement<VectorproductType>(_Vectorproduct_QNAME, VectorproductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ScalarproductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "scalarproduct")
    public JAXBElement<ScalarproductType> createScalarproduct(ScalarproductType value) {
        return new JAXBElement<ScalarproductType>(_Scalarproduct_QNAME, ScalarproductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OuterproductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "outerproduct")
    public JAXBElement<OuterproductType> createOuterproduct(OuterproductType value) {
        return new JAXBElement<OuterproductType>(_Outerproduct_QNAME, OuterproductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetdiffType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "setdiff")
    public JAXBElement<SetdiffType> createSetdiff(SetdiffType value) {
        return new JAXBElement<SetdiffType>(_Setdiff_QNAME, SetdiffType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "fn")
    public JAXBElement<FnType> createFn(FnType value) {
        return new JAXBElement<FnType>(_Fn_QNAME, FnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComposeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "compose")
    public JAXBElement<ComposeType> createCompose(ComposeType value) {
        return new JAXBElement<ComposeType>(_Compose_QNAME, ComposeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PlusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "plus")
    public JAXBElement<PlusType> createPlus(PlusType value) {
        return new JAXBElement<PlusType>(_Plus_QNAME, PlusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TimesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "times")
    public JAXBElement<TimesType> createTimes(TimesType value) {
        return new JAXBElement<TimesType>(_Times_QNAME, TimesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "max")
    public JAXBElement<MaxType> createMax(MaxType value) {
        return new JAXBElement<MaxType>(_Max_QNAME, MaxType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MinType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "min")
    public JAXBElement<MinType> createMin(MinType value) {
        return new JAXBElement<MinType>(_Min_QNAME, MinType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GcdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "gcd")
    public JAXBElement<GcdType> createGcd(GcdType value) {
        return new JAXBElement<GcdType>(_Gcd_QNAME, GcdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LcmType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "lcm")
    public JAXBElement<LcmType> createLcm(LcmType value) {
        return new JAXBElement<LcmType>(_Lcm_QNAME, LcmType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AndType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "and")
    public JAXBElement<AndType> createAnd(AndType value) {
        return new JAXBElement<AndType>(_And_QNAME, AndType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "or")
    public JAXBElement<OrType> createOr(OrType value) {
        return new JAXBElement<OrType>(_Or_QNAME, OrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "xor")
    public JAXBElement<XorType> createXor(XorType value) {
        return new JAXBElement<XorType>(_Xor_QNAME, XorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "union")
    public JAXBElement<UnionType> createUnion(UnionType value) {
        return new JAXBElement<UnionType>(_Union_QNAME, UnionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntersectType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "intersect")
    public JAXBElement<IntersectType> createIntersect(IntersectType value) {
        return new JAXBElement<IntersectType>(_Intersect_QNAME, IntersectType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CartesianproductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cartesianproduct")
    public JAXBElement<CartesianproductType> createCartesianproduct(CartesianproductType value) {
        return new JAXBElement<CartesianproductType>(_Cartesianproduct_QNAME, CartesianproductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mean")
    public JAXBElement<MeanType> createMean(MeanType value) {
        return new JAXBElement<MeanType>(_Mean_QNAME, MeanType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SdevType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sdev")
    public JAXBElement<SdevType> createSdev(SdevType value) {
        return new JAXBElement<SdevType>(_Sdev_QNAME, SdevType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VarianceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "variance")
    public JAXBElement<VarianceType> createVariance(VarianceType value) {
        return new JAXBElement<VarianceType>(_Variance_QNAME, VarianceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MedianType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "median")
    public JAXBElement<MedianType> createMedian(MedianType value) {
        return new JAXBElement<MedianType>(_Median_QNAME, MedianType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mode")
    public JAXBElement<ModeType> createMode(ModeType value) {
        return new JAXBElement<ModeType>(_Mode_QNAME, ModeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SelectorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "selector")
    public JAXBElement<SelectorType> createSelector(SelectorType value) {
        return new JAXBElement<SelectorType>(_Selector_QNAME, SelectorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "root")
    public JAXBElement<RootType> createRoot(RootType value) {
        return new JAXBElement<RootType>(_Root_QNAME, RootType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MinusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "minus")
    public JAXBElement<MinusType> createMinus(MinusType value) {
        return new JAXBElement<MinusType>(_Minus_QNAME, MinusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LogType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "log")
    public JAXBElement<LogType> createLog(LogType value) {
        return new JAXBElement<LogType>(_Log_QNAME, LogType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "int")
    public JAXBElement<IntType> createInt(IntType value) {
        return new JAXBElement<IntType>(_Int_QNAME, IntType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DiffType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "diff")
    public JAXBElement<DiffType> createDiff(DiffType value) {
        return new JAXBElement<DiffType>(_Diff_QNAME, DiffType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartialdiffType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "partialdiff")
    public JAXBElement<PartialdiffType> createPartialdiff(PartialdiffType value) {
        return new JAXBElement<PartialdiffType>(_Partialdiff_QNAME, PartialdiffType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DivergenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "divergence")
    public JAXBElement<DivergenceType> createDivergence(DivergenceType value) {
        return new JAXBElement<DivergenceType>(_Divergence_QNAME, DivergenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GradType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "grad")
    public JAXBElement<GradType> createGrad(GradType value) {
        return new JAXBElement<GradType>(_Grad_QNAME, GradType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CurlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "curl")
    public JAXBElement<CurlType> createCurl(CurlType value) {
        return new JAXBElement<CurlType>(_Curl_QNAME, CurlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LaplacianType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "laplacian")
    public JAXBElement<LaplacianType> createLaplacian(LaplacianType value) {
        return new JAXBElement<LaplacianType>(_Laplacian_QNAME, LaplacianType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SumType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sum")
    public JAXBElement<SumType> createSum(SumType value) {
        return new JAXBElement<SumType>(_Sum_QNAME, SumType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "product")
    public JAXBElement<ProductType> createProduct(ProductType value) {
        return new JAXBElement<ProductType>(_Product_QNAME, ProductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LimitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "limit")
    public JAXBElement<LimitType> createLimit(LimitType value) {
        return new JAXBElement<LimitType>(_Limit_QNAME, LimitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MomentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "moment")
    public JAXBElement<MomentType> createMoment(MomentType value) {
        return new JAXBElement<MomentType>(_Moment_QNAME, MomentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExistsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "exists")
    public JAXBElement<ExistsType> createExists(ExistsType value) {
        return new JAXBElement<ExistsType>(_Exists_QNAME, ExistsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ForallType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "forall")
    public JAXBElement<ForallType> createForall(ForallType value) {
        return new JAXBElement<ForallType>(_Forall_QNAME, ForallType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NeqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "neq")
    public JAXBElement<NeqType> createNeq(NeqType value) {
        return new JAXBElement<NeqType>(_Neq_QNAME, NeqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FactorofType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "factorof")
    public JAXBElement<FactorofType> createFactorof(FactorofType value) {
        return new JAXBElement<FactorofType>(_Factorof_QNAME, FactorofType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "in")
    public JAXBElement<InType> createIn(InType value) {
        return new JAXBElement<InType>(_In_QNAME, InType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotinType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "notin")
    public JAXBElement<NotinType> createNotin(NotinType value) {
        return new JAXBElement<NotinType>(_Notin_QNAME, NotinType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotsubsetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "notsubset")
    public JAXBElement<NotsubsetType> createNotsubset(NotsubsetType value) {
        return new JAXBElement<NotsubsetType>(_Notsubset_QNAME, NotsubsetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotprsubsetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "notprsubset")
    public JAXBElement<NotprsubsetType> createNotprsubset(NotprsubsetType value) {
        return new JAXBElement<NotprsubsetType>(_Notprsubset_QNAME, NotprsubsetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TendstoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "tendsto")
    public JAXBElement<TendstoType> createTendsto(TendstoType value) {
        return new JAXBElement<TendstoType>(_Tendsto_QNAME, TendstoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "eq")
    public JAXBElement<EqType> createEq(EqType value) {
        return new JAXBElement<EqType>(_Eq_QNAME, EqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LeqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "leq")
    public JAXBElement<LeqType> createLeq(LeqType value) {
        return new JAXBElement<LeqType>(_Leq_QNAME, LeqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "lt")
    public JAXBElement<LtType> createLt(LtType value) {
        return new JAXBElement<LtType>(_Lt_QNAME, LtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GeqType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "geq")
    public JAXBElement<GeqType> createGeq(GeqType value) {
        return new JAXBElement<GeqType>(_Geq_QNAME, GeqType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "gt")
    public JAXBElement<GtType> createGt(GtType value) {
        return new JAXBElement<GtType>(_Gt_QNAME, GtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EquivalentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "equivalent")
    public JAXBElement<EquivalentType> createEquivalent(EquivalentType value) {
        return new JAXBElement<EquivalentType>(_Equivalent_QNAME, EquivalentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApproxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "approx")
    public JAXBElement<ApproxType> createApprox(ApproxType value) {
        return new JAXBElement<ApproxType>(_Approx_QNAME, ApproxType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubsetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "subset")
    public JAXBElement<SubsetType> createSubset(SubsetType value) {
        return new JAXBElement<SubsetType>(_Subset_QNAME, SubsetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrsubsetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "prsubset")
    public JAXBElement<PrsubsetType> createPrsubset(PrsubsetType value) {
        return new JAXBElement<PrsubsetType>(_Prsubset_QNAME, PrsubsetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "chemistry")
    public JAXBElement<ChemistryType> createChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_Chemistry_QNAME, ChemistryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "chem")
    public JAXBElement<ChemType> createChem(ChemType value) {
        return new JAXBElement<ChemType>(_Chem_QNAME, ChemType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ol")
    public JAXBElement<OlType> createOl(OlType value) {
        return new JAXBElement<OlType>(_Ol_QNAME, OlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "img")
    public JAXBElement<ImgType> createImg(ImgType value) {
        return new JAXBElement<ImgType>(_Img_QNAME, ImgType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "figref")
    public JAXBElement<FigrefType> createFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_Figref_QNAME, FigrefType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "crossref")
    public JAXBElement<CrossrefType> createCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_Crossref_QNAME, CrossrefType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "bio-deposit")
    public JAXBElement<BioDepositType> createBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_BioDeposit_QNAME, BioDepositType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "nplcit")
    public JAXBElement<NplcitType> createNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_Nplcit_QNAME, NplcitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RefnoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "refno")
    public JAXBElement<RefnoType> createRefno(RefnoType value) {
        return new JAXBElement<RefnoType>(_Refno_QNAME, RefnoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "class")
    public JAXBElement<ClassType> createClass(ClassType value) {
        return new JAXBElement<ClassType>(_Class_QNAME, ClassType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "subname")
    public JAXBElement<SubnameType> createSubname(SubnameType value) {
        return new JAXBElement<SubnameType>(_Subname_QNAME, SubnameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "author")
    public JAXBElement<AuthorType> createAuthor(AuthorType value) {
        return new JAXBElement<AuthorType>(_Author_QNAME, AuthorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressbookType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "addressbook")
    public JAXBElement<AddressbookType> createAddressbook(AddressbookType value) {
        return new JAXBElement<AddressbookType>(_Addressbook_QNAME, AddressbookType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "patcit")
    public JAXBElement<PatcitType> createPatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_Patcit_QNAME, PatcitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentIdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "document-id")
    public JAXBElement<DocumentIdType> createDocumentId(DocumentIdType value) {
        return new JAXBElement<DocumentIdType>(_DocumentId_QNAME, DocumentIdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "name")
    public JAXBElement<NameType> createName(NameType value) {
        return new JAXBElement<NameType>(_Name_QNAME, NameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "dt")
    public JAXBElement<DtType> createDt(DtType value) {
        return new JAXBElement<DtType>(_Dt_QNAME, DtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "o")
    public JAXBElement<OType> createO(OType value) {
        return new JAXBElement<OType>(_O_QNAME, OType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "u")
    public JAXBElement<UType> createU(UType value) {
        return new JAXBElement<UType>(_U_QNAME, UType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocPageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "doc-page")
    public JAXBElement<DocPageType> createDocPage(DocPageType value) {
        return new JAXBElement<DocPageType>(_DocPage_QNAME, DocPageType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepWrittenOpinionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-written-opinion")
    public JAXBElement<SrepWrittenOpinionType> createSrepWrittenOpinion(SrepWrittenOpinionType value) {
        return new JAXBElement<SrepWrittenOpinionType>(_SrepWrittenOpinion_QNAME, SrepWrittenOpinionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObservationOnApplicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "observation-on-application")
    public JAXBElement<ObservationOnApplicationType> createObservationOnApplication(ObservationOnApplicationType value) {
        return new JAXBElement<ObservationOnApplicationType>(_ObservationOnApplication_QNAME, ObservationOnApplicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DefectInApplicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "defect-in-application")
    public JAXBElement<DefectInApplicationType> createDefectInApplication(DefectInApplicationType value) {
        return new JAXBElement<DefectInApplicationType>(_DefectInApplication_QNAME, DefectInApplicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpinionCitationsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "opinion-citations")
    public JAXBElement<OpinionCitationsType> createOpinionCitations(OpinionCitationsType value) {
        return new JAXBElement<OpinionCitationsType>(_OpinionCitations_QNAME, OpinionCitationsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonWrittenDisclosuresType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-written-disclosures")
    public JAXBElement<NonWrittenDisclosuresType> createNonWrittenDisclosures(NonWrittenDisclosuresType value) {
        return new JAXBElement<NonWrittenDisclosuresType>(_NonWrittenDisclosures_QNAME, NonWrittenDisclosuresType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateOfWrittenDisclosureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date-of-written-disclosure")
    public JAXBElement<DateOfWrittenDisclosureType> createDateOfWrittenDisclosure(DateOfWrittenDisclosureType value) {
        return new JAXBElement<DateOfWrittenDisclosureType>(_DateOfWrittenDisclosure_QNAME, DateOfWrittenDisclosureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KindOfDisclosureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "kind-of-disclosure")
    public JAXBElement<KindOfDisclosureType> createKindOfDisclosure(KindOfDisclosureType value) {
        return new JAXBElement<KindOfDisclosureType>(_KindOfDisclosure_QNAME, KindOfDisclosureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CertainPublishedDocumentsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "certain-published-documents")
    public JAXBElement<CertainPublishedDocumentsType> createCertainPublishedDocuments(CertainPublishedDocumentsType value) {
        return new JAXBElement<CertainPublishedDocumentsType>(_CertainPublishedDocuments_QNAME, CertainPublishedDocumentsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PctRule43BisStatementType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pct-rule43bis-statement")
    public JAXBElement<PctRule43BisStatementType> createPctRule43BisStatement(PctRule43BisStatementType value) {
        return new JAXBElement<PctRule43BisStatementType>(_PctRule43BisStatement_QNAME, PctRule43BisStatementType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CitationsExplanationsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "citations-explanations")
    public JAXBElement<CitationsExplanationsType> createCitationsExplanations(CitationsExplanationsType value) {
        return new JAXBElement<CitationsExplanationsType>(_CitationsExplanations_QNAME, CitationsExplanationsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FilingDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "filing-date")
    public JAXBElement<FilingDateType> createFilingDate(FilingDateType value) {
        return new JAXBElement<FilingDateType>(_FilingDate_QNAME, FilingDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicabilityNotValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "applicability-not-valid")
    public JAXBElement<ApplicabilityNotValidType> createApplicabilityNotValid(ApplicabilityNotValidType value) {
        return new JAXBElement<ApplicabilityNotValidType>(_ApplicabilityNotValid_QNAME, ApplicabilityNotValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicabilityValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "applicability-valid")
    public JAXBElement<ApplicabilityValidType> createApplicabilityValid(ApplicabilityValidType value) {
        return new JAXBElement<ApplicabilityValidType>(_ApplicabilityValid_QNAME, ApplicabilityValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventiveStepNotValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inventive-step-not-valid")
    public JAXBElement<InventiveStepNotValidType> createInventiveStepNotValid(InventiveStepNotValidType value) {
        return new JAXBElement<InventiveStepNotValidType>(_InventiveStepNotValid_QNAME, InventiveStepNotValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventiveStepValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inventive-step-valid")
    public JAXBElement<InventiveStepValidType> createInventiveStepValid(InventiveStepValidType value) {
        return new JAXBElement<InventiveStepValidType>(_InventiveStepValid_QNAME, InventiveStepValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoveltyNotValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "novelty-not-valid")
    public JAXBElement<NoveltyNotValidType> createNoveltyNotValid(NoveltyNotValidType value) {
        return new JAXBElement<NoveltyNotValidType>(_NoveltyNotValid_QNAME, NoveltyNotValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoveltyValidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "novelty-valid")
    public JAXBElement<NoveltyValidType> createNoveltyValid(NoveltyValidType value) {
        return new JAXBElement<NoveltyValidType>(_NoveltyValid_QNAME, NoveltyValidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnityOfInventionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "unity-of-invention")
    public JAXBElement<UnityOfInventionType> createUnityOfInvention(UnityOfInventionType value) {
        return new JAXBElement<UnityOfInventionType>(_UnityOfInvention_QNAME, UnityOfInventionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpinionEstablishedRegardingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "opinion-established-regarding")
    public JAXBElement<OpinionEstablishedRegardingType> createOpinionEstablishedRegarding(OpinionEstablishedRegardingType value) {
        return new JAXBElement<OpinionEstablishedRegardingType>(_OpinionEstablishedRegarding_QNAME, OpinionEstablishedRegardingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotUnityOfInventionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "not-unity-of-invention")
    public JAXBElement<NotUnityOfInventionType> createNotUnityOfInvention(NotUnityOfInventionType value) {
        return new JAXBElement<NotUnityOfInventionType>(_NotUnityOfInvention_QNAME, NotUnityOfInventionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonEstablishmentOfOpinionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-establishment-of-opinion")
    public JAXBElement<NonEstablishmentOfOpinionType> createNonEstablishmentOfOpinion(NonEstablishmentOfOpinionType value) {
        return new JAXBElement<NonEstablishmentOfOpinionType>(_NonEstablishmentOfOpinion_QNAME, NonEstablishmentOfOpinionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotAnnexCCompliantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "not-annex-c-compliant")
    public JAXBElement<NotAnnexCCompliantType> createNotAnnexCCompliant(NotAnnexCCompliantType value) {
        return new JAXBElement<NotAnnexCCompliantType>(_NotAnnexCCompliant_QNAME, NotAnnexCCompliantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnexCBisType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "annex-c-bis")
    public JAXBElement<AnnexCBisType> createAnnexCBis(AnnexCBisType value) {
        return new JAXBElement<AnnexCBisType>(_AnnexCBis_QNAME, AnnexCBisType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnexCType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "annex-c")
    public JAXBElement<AnnexCType> createAnnexC(AnnexCType value) {
        return new JAXBElement<AnnexCType>(_AnnexC_QNAME, AnnexCType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventionNotExaminedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "invention-not-examined")
    public JAXBElement<InventionNotExaminedType> createInventionNotExamined(InventionNotExaminedType value) {
        return new JAXBElement<InventionNotExaminedType>(_InventionNotExamined_QNAME, InventionNotExaminedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonEstabReason4Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-estab-reason-4")
    public JAXBElement<NonEstabReason4Type> createNonEstabReason4(NonEstabReason4Type value) {
        return new JAXBElement<NonEstabReason4Type>(_NonEstabReason4_QNAME, NonEstabReason4Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonEstabReason3Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-estab-reason-3")
    public JAXBElement<NonEstabReason3Type> createNonEstabReason3(NonEstabReason3Type value) {
        return new JAXBElement<NonEstabReason3Type>(_NonEstabReason3_QNAME, NonEstabReason3Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonEstabReason2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-estab-reason-2")
    public JAXBElement<NonEstabReason2Type> createNonEstabReason2(NonEstabReason2Type value) {
        return new JAXBElement<NonEstabReason2Type>(_NonEstabReason2_QNAME, NonEstabReason2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonEstabReason1Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "non-estab-reason-1")
    public JAXBElement<NonEstabReason1Type> createNonEstabReason1(NonEstabReason1Type value) {
        return new JAXBElement<NonEstabReason1Type>(_NonEstabReason1_QNAME, NonEstabReason1Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EntireApplicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "entire-application")
    public JAXBElement<EntireApplicationType> createEntireApplication(EntireApplicationType value) {
        return new JAXBElement<EntireApplicationType>(_EntireApplication_QNAME, EntireApplicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimInvalidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claim-invalid")
    public JAXBElement<ClaimInvalidType> createClaimInvalid(ClaimInvalidType value) {
        return new JAXBElement<ClaimInvalidType>(_ClaimInvalid_QNAME, ClaimInvalidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasisOfSrepOpinionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "basis-of-srep-opinion")
    public JAXBElement<BasisOfSrepOpinionType> createBasisOfSrepOpinion(BasisOfSrepOpinionType value) {
        return new JAXBElement<BasisOfSrepOpinionType>(_BasisOfSrepOpinion_QNAME, BasisOfSrepOpinionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepForPubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-for-pub")
    public JAXBElement<SrepForPubType> createSrepForPub(SrepForPubType value) {
        return new JAXBElement<SrepForPubType>(_SrepForPub_QNAME, SrepForPubType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepPatentFamiliesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-patent-families")
    public JAXBElement<SrepPatentFamiliesType> createSrepPatentFamilies(SrepPatentFamiliesType value) {
        return new JAXBElement<SrepPatentFamiliesType>(_SrepPatentFamilies_QNAME, SrepPatentFamiliesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFamilyMemberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-family-member")
    public JAXBElement<SrepFamilyMemberType> createSrepFamilyMember(SrepFamilyMemberType value) {
        return new JAXBElement<SrepFamilyMemberType>(_SrepFamilyMember_QNAME, SrepFamilyMemberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityApplicationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-application")
    public JAXBElement<PriorityApplicationType> createPriorityApplication(PriorityApplicationType value) {
        return new JAXBElement<PriorityApplicationType>(_PriorityApplication_QNAME, PriorityApplicationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepAdminType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-admin")
    public JAXBElement<SrepAdminType> createSrepAdmin(SrepAdminType value) {
        return new JAXBElement<SrepAdminType>(_SrepAdmin_QNAME, SrepAdminType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateSearchCompletedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date-search-completed")
    public JAXBElement<DateSearchCompletedType> createDateSearchCompleted(DateSearchCompletedType value) {
        return new JAXBElement<DateSearchCompletedType>(_DateSearchCompleted_QNAME, DateSearchCompletedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExaminersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "examiners")
    public JAXBElement<ExaminersType> createExaminers(ExaminersType value) {
        return new JAXBElement<ExaminersType>(_Examiners_QNAME, ExaminersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssistantExaminerType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "assistant-examiner")
    public JAXBElement<AssistantExaminerType> createAssistantExaminer(AssistantExaminerType value) {
        return new JAXBElement<AssistantExaminerType>(_AssistantExaminer_QNAME, AssistantExaminerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrimaryExaminerType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "primary-examiner")
    public JAXBElement<PrimaryExaminerType> createPrimaryExaminer(PrimaryExaminerType value) {
        return new JAXBElement<PrimaryExaminerType>(_PrimaryExaminer_QNAME, PrimaryExaminerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IncompleteSearchType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "incomplete-search")
    public JAXBElement<IncompleteSearchType> createIncompleteSearch(IncompleteSearchType value) {
        return new JAXBElement<IncompleteSearchType>(_IncompleteSearch_QNAME, IncompleteSearchType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReasonLimitedSearchType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "reason-limited-search")
    public JAXBElement<ReasonLimitedSearchType> createReasonLimitedSearch(ReasonLimitedSearchType value) {
        return new JAXBElement<ReasonLimitedSearchType>(_ReasonLimitedSearch_QNAME, ReasonLimitedSearchType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimsNotSearchedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claims-not-searched")
    public JAXBElement<ClaimsNotSearchedType> createClaimsNotSearched(ClaimsNotSearchedType value) {
        return new JAXBElement<ClaimsNotSearchedType>(_ClaimsNotSearched_QNAME, ClaimsNotSearchedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimsSearchedIncompletelyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claims-searched-incompletely")
    public JAXBElement<ClaimsSearchedIncompletelyType> createClaimsSearchedIncompletely(ClaimsSearchedIncompletelyType value) {
        return new JAXBElement<ClaimsSearchedIncompletelyType>(_ClaimsSearchedIncompletely_QNAME, ClaimsSearchedIncompletelyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimsSearchedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claims-searched")
    public JAXBElement<ClaimsSearchedType> createClaimsSearched(ClaimsSearchedType value) {
        return new JAXBElement<ClaimsSearchedType>(_ClaimsSearched_QNAME, ClaimsSearchedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepCitationsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-citations")
    public JAXBElement<SrepCitationsType> createSrepCitations(SrepCitationsType value) {
        return new JAXBElement<SrepCitationsType>(_SrepCitations_QNAME, SrepCitationsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFieldsSearchedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-fields-searched")
    public JAXBElement<SrepFieldsSearchedType> createSrepFieldsSearched(SrepFieldsSearchedType value) {
        return new JAXBElement<SrepFieldsSearchedType>(_SrepFieldsSearched_QNAME, SrepFieldsSearchedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DatabaseSearchedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "database-searched")
    public JAXBElement<DatabaseSearchedType> createDatabaseSearched(DatabaseSearchedType value) {
        return new JAXBElement<DatabaseSearchedType>(_DatabaseSearched_QNAME, DatabaseSearchedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OtherDocumentationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "other-documentation")
    public JAXBElement<OtherDocumentationType> createOtherDocumentation(OtherDocumentationType value) {
        return new JAXBElement<OtherDocumentationType>(_OtherDocumentation_QNAME, OtherDocumentationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MinimumDocumentationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "minimum-documentation")
    public JAXBElement<MinimumDocumentationType> createMinimumDocumentation(MinimumDocumentationType value) {
        return new JAXBElement<MinimumDocumentationType>(_MinimumDocumentation_QNAME, MinimumDocumentationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-info")
    public JAXBElement<SrepInfoType> createSrepInfo(SrepInfoType value) {
        return new JAXBElement<SrepInfoType>(_SrepInfo_QNAME, SrepInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepAbstractType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-abstract")
    public JAXBElement<SrepAbstractType> createSrepAbstract(SrepAbstractType value) {
        return new JAXBElement<SrepAbstractType>(_SrepAbstract_QNAME, SrepAbstractType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepInventionTitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-invention-title")
    public JAXBElement<SrepInventionTitleType> createSrepInventionTitle(SrepInventionTitleType value) {
        return new JAXBElement<SrepInventionTitleType>(_SrepInventionTitle_QNAME, SrepInventionTitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepOtherInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-other-info")
    public JAXBElement<SrepOtherInfoType> createSrepOtherInfo(SrepOtherInfoType value) {
        return new JAXBElement<SrepOtherInfoType>(_SrepOtherInfo_QNAME, SrepOtherInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepInfoAdminType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-info-admin")
    public JAXBElement<SrepInfoAdminType> createSrepInfoAdmin(SrepInfoAdminType value) {
        return new JAXBElement<SrepInfoAdminType>(_SrepInfoAdmin_QNAME, SrepInfoAdminType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateSearchReportMailedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date-search-report-mailed")
    public JAXBElement<DateSearchReportMailedType> createDateSearchReportMailed(DateSearchReportMailedType value) {
        return new JAXBElement<DateSearchReportMailedType>(_DateSearchReportMailed_QNAME, DateSearchReportMailedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepOfficeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-office")
    public JAXBElement<SrepOfficeType> createSrepOffice(SrepOfficeType value) {
        return new JAXBElement<SrepOfficeType>(_SrepOffice_QNAME, SrepOfficeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorizedOfficerType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "authorized-officer")
    public JAXBElement<AuthorizedOfficerType> createAuthorizedOfficer(AuthorizedOfficerType value) {
        return new JAXBElement<AuthorizedOfficerType>(_AuthorizedOfficer_QNAME, AuthorizedOfficerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnhancedSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "enhanced-signature")
    public JAXBElement<EnhancedSignatureType> createEnhancedSignature(EnhancedSignatureType value) {
        return new JAXBElement<EnhancedSignatureType>(_EnhancedSignature_QNAME, EnhancedSignatureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pkcs7Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pkcs7")
    public JAXBElement<Pkcs7Type> createPkcs7(Pkcs7Type value) {
        return new JAXBElement<Pkcs7Type>(_Pkcs7_QNAME, Pkcs7Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasicSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "basic-signature")
    public JAXBElement<BasicSignatureType> createBasicSignature(BasicSignatureType value) {
        return new JAXBElement<BasicSignatureType>(_BasicSignature_QNAME, BasicSignatureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClickWrapType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "click-wrap")
    public JAXBElement<ClickWrapType> createClickWrap(ClickWrapType value) {
        return new JAXBElement<ClickWrapType>(_ClickWrap_QNAME, ClickWrapType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TextStringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "text-string")
    public JAXBElement<TextStringType> createTextString(TextStringType value) {
        return new JAXBElement<TextStringType>(_TextString_QNAME, TextStringType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigureToPublishType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "figure-to-publish")
    public JAXBElement<FigureToPublishType> createFigureToPublish(FigureToPublishType value) {
        return new JAXBElement<FigureToPublishType>(_FigureToPublish_QNAME, FigureToPublishType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "fig-number")
    public JAXBElement<FigNumberType> createFigNumber(FigNumberType value) {
        return new JAXBElement<FigNumberType>(_FigNumber_QNAME, FigNumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepUnityOfInventionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-unity-of-invention")
    public JAXBElement<SrepUnityOfInventionType> createSrepUnityOfInvention(SrepUnityOfInventionType value) {
        return new JAXBElement<SrepUnityOfInventionType>(_SrepUnityOfInvention_QNAME, SrepUnityOfInventionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepSearchFeesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-search-fees")
    public JAXBElement<SrepSearchFeesType> createSrepSearchFees(SrepSearchFeesType value) {
        return new JAXBElement<SrepSearchFeesType>(_SrepSearchFees_QNAME, SrepSearchFeesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFee4Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-fee-4")
    public JAXBElement<SrepFee4Type> createSrepFee4(SrepFee4Type value) {
        return new JAXBElement<SrepFee4Type>(_SrepFee4_QNAME, SrepFee4Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFee3Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-fee-3")
    public JAXBElement<SrepFee3Type> createSrepFee3(SrepFee3Type value) {
        return new JAXBElement<SrepFee3Type>(_SrepFee3_QNAME, SrepFee3Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFee2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-fee-2")
    public JAXBElement<SrepFee2Type> createSrepFee2(SrepFee2Type value) {
        return new JAXBElement<SrepFee2Type>(_SrepFee2_QNAME, SrepFee2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepFee1Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-fee-1")
    public JAXBElement<SrepFee1Type> createSrepFee1(SrepFee1Type value) {
        return new JAXBElement<SrepFee1Type>(_SrepFee1_QNAME, SrepFee1Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepClaimsInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-claims-info")
    public JAXBElement<SrepClaimsInfoType> createSrepClaimsInfo(SrepClaimsInfoType value) {
        return new JAXBElement<SrepClaimsInfoType>(_SrepClaimsInfo_QNAME, SrepClaimsInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClmsReason3Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "clms-reason-3")
    public JAXBElement<ClmsReason3Type> createClmsReason3(ClmsReason3Type value) {
        return new JAXBElement<ClmsReason3Type>(_ClmsReason3_QNAME, ClmsReason3Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClmsReason2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "clms-reason-2")
    public JAXBElement<ClmsReason2Type> createClmsReason2(ClmsReason2Type value) {
        return new JAXBElement<ClmsReason2Type>(_ClmsReason2_QNAME, ClmsReason2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClmsReason1Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "clms-reason-1")
    public JAXBElement<ClmsReason1Type> createClmsReason1(ClmsReason1Type value) {
        return new JAXBElement<ClmsReason1Type>(_ClmsReason1_QNAME, ClmsReason1Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimRemarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claim-remark")
    public JAXBElement<ClaimRemarkType> createClaimRemark(ClaimRemarkType value) {
        return new JAXBElement<ClaimRemarkType>(_ClaimRemark_QNAME, ClaimRemarkType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimNumType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "claim-num")
    public JAXBElement<ClaimNumType> createClaimNum(ClaimNumType value) {
        return new JAXBElement<ClaimNumType>(_ClaimNum_QNAME, ClaimNumType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepBasisType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-basis")
    public JAXBElement<SrepBasisType> createSrepBasis(SrepBasisType value) {
        return new JAXBElement<SrepBasisType>(_SrepBasis_QNAME, SrepBasisType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListBasisType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sequence-list-basis")
    public JAXBElement<SequenceListBasisType> createSequenceListBasis(SequenceListBasisType value) {
        return new JAXBElement<SequenceListBasisType>(_SequenceListBasis_QNAME, SequenceListBasisType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PresentationOfStatementsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "presentation-of-statements")
    public JAXBElement<PresentationOfStatementsType> createPresentationOfStatements(PresentationOfStatementsType value) {
        return new JAXBElement<PresentationOfStatementsType>(_PresentationOfStatements_QNAME, PresentationOfStatementsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaterialOfSequenceListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "material-of-sequence-list")
    public JAXBElement<MaterialOfSequenceListType> createMaterialOfSequenceList(MaterialOfSequenceListType value) {
        return new JAXBElement<MaterialOfSequenceListType>(_MaterialOfSequenceList_QNAME, MaterialOfSequenceListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepRequestNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-request-number")
    public JAXBElement<SrepRequestNumberType> createSrepRequestNumber(SrepRequestNumberType value) {
        return new JAXBElement<SrepRequestNumberType>(_SrepRequestNumber_QNAME, SrepRequestNumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrepRequestDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srep-request-date")
    public JAXBElement<SrepRequestDateType> createSrepRequestDate(SrepRequestDateType value) {
        return new JAXBElement<SrepRequestDateType>(_SrepRequestDate_QNAME, SrepRequestDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateOfEarliestPriorityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "date-of-earliest-priority")
    public JAXBElement<DateOfEarliestPriorityType> createDateOfEarliestPriority(DateOfEarliestPriorityType value) {
        return new JAXBElement<DateOfEarliestPriorityType>(_DateOfEarliestPriority_QNAME, DateOfEarliestPriorityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FileReferenceIdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "file-reference-id")
    public JAXBElement<FileReferenceIdType> createFileReferenceId(FileReferenceIdType value) {
        return new JAXBElement<FileReferenceIdType>(_FileReferenceId_QNAME, FileReferenceIdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FamilyMemberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "family-member")
    public JAXBElement<FamilyMemberType> createFamilyMember(FamilyMemberType value) {
        return new JAXBElement<FamilyMemberType>(_FamilyMember_QNAME, FamilyMemberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrectionNoticeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "correction-notice")
    public JAXBElement<CorrectionNoticeType> createCorrectionNotice(CorrectionNoticeType value) {
        return new JAXBElement<CorrectionNoticeType>(_CorrectionNotice_QNAME, CorrectionNoticeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RepublicationNotesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "republication-notes")
    public JAXBElement<RepublicationNotesType> createRepublicationNotes(RepublicationNotesType value) {
        return new JAXBElement<RepublicationNotesType>(_RepublicationNotes_QNAME, RepublicationNotesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModificationsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modifications")
    public JAXBElement<ModificationsType> createModifications(ModificationsType value) {
        return new JAXBElement<ModificationsType>(_Modifications_QNAME, ModificationsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedPartNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-part-name")
    public JAXBElement<ModifiedPartNameType> createModifiedPartName(ModifiedPartNameType value) {
        return new JAXBElement<ModifiedPartNameType>(_ModifiedPartName_QNAME, ModifiedPartNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifiedBibliographyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "modified-bibliography")
    public JAXBElement<ModifiedBibliographyType> createModifiedBibliography(ModifiedBibliographyType value) {
        return new JAXBElement<ModifiedBibliographyType>(_ModifiedBibliography_QNAME, ModifiedBibliographyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancellationDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cancellation-date")
    public JAXBElement<CancellationDateType> createCancellationDate(CancellationDateType value) {
        return new JAXBElement<CancellationDateType>(_CancellationDate_QNAME, CancellationDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RepublicationCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "republication-code")
    public JAXBElement<RepublicationCodeType> createRepublicationCode(RepublicationCodeType value) {
        return new JAXBElement<RepublicationCodeType>(_RepublicationCode_QNAME, RepublicationCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TypeOfCorrectionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "type-of-correction")
    public JAXBElement<TypeOfCorrectionType> createTypeOfCorrection(TypeOfCorrectionType value) {
        return new JAXBElement<TypeOfCorrectionType>(_TypeOfCorrection_QNAME, TypeOfCorrectionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrespondingDocsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "corresponding-docs")
    public JAXBElement<CorrespondingDocsType> createCorrespondingDocs(CorrespondingDocsType value) {
        return new JAXBElement<CorrespondingDocsType>(_CorrespondingDocs_QNAME, CorrespondingDocsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityClaimsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-claims")
    public JAXBElement<PriorityClaimsType> createPriorityClaims(PriorityClaimsType value) {
        return new JAXBElement<PriorityClaimsType>(_PriorityClaims_QNAME, PriorityClaimsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-active-indicator")
    public JAXBElement<String> createPriorityActiveIndicator(String value) {
        return new JAXBElement<String>(_PriorityActiveIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-linkage-type")
    public JAXBElement<String> createPriorityLinkageType(String value) {
        return new JAXBElement<String>(_PriorityLinkageType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityDocAttachedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-doc-attached")
    public JAXBElement<PriorityDocAttachedType> createPriorityDocAttached(PriorityDocAttachedType value) {
        return new JAXBElement<PriorityDocAttachedType>(_PriorityDocAttached_QNAME, PriorityDocAttachedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PriorityDocRequestedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "priority-doc-requested")
    public JAXBElement<PriorityDocRequestedType> createPriorityDocRequested(PriorityDocRequestedType value) {
        return new JAXBElement<PriorityDocRequestedType>(_PriorityDocRequested_QNAME, PriorityDocRequestedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OfficeOfFilingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "office-of-filing")
    public JAXBElement<OfficeOfFilingType> createOfficeOfFiling(OfficeOfFilingType value) {
        return new JAXBElement<OfficeOfFilingType>(_OfficeOfFiling_QNAME, OfficeOfFilingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartiesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "parties")
    public JAXBElement<PartiesType> createParties(PartiesType value) {
        return new JAXBElement<PartiesType>(_Parties_QNAME, PartiesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgentsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "agents")
    public JAXBElement<AgentsType> createAgents(AgentsType value) {
        return new JAXBElement<AgentsType>(_Agents_QNAME, AgentsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CorrespondenceAddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "correspondence-address")
    public JAXBElement<CorrespondenceAddressType> createCorrespondenceAddress(CorrespondenceAddressType value) {
        return new JAXBElement<CorrespondenceAddressType>(_CorrespondenceAddress_QNAME, CorrespondenceAddressType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CustomerNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "customer-number")
    public JAXBElement<CustomerNumberType> createCustomerNumber(CustomerNumberType value) {
        return new JAXBElement<CustomerNumberType>(_CustomerNumber_QNAME, CustomerNumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventorsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inventors")
    public JAXBElement<InventorsType> createInventors(InventorsType value) {
        return new JAXBElement<InventorsType>(_Inventors_QNAME, InventorsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "inventor")
    public JAXBElement<InventorType> createInventor(InventorType value) {
        return new JAXBElement<InventorType>(_Inventor_QNAME, InventorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicantsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "applicants")
    public JAXBElement<ApplicantsType> createApplicants(ApplicantsType value) {
        return new JAXBElement<ApplicantsType>(_Applicants_QNAME, ApplicantsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesignatedStatesAsInventorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "designated-states-as-inventor")
    public JAXBElement<DesignatedStatesAsInventorType> createDesignatedStatesAsInventor(DesignatedStatesAsInventorType value) {
        return new JAXBElement<DesignatedStatesAsInventorType>(_DesignatedStatesAsInventor_QNAME, DesignatedStatesAsInventorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesignatedStatesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "designated-states")
    public JAXBElement<DesignatedStatesType> createDesignatedStates(DesignatedStatesType value) {
        return new JAXBElement<DesignatedStatesType>(_DesignatedStates_QNAME, DesignatedStatesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResidenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "residence")
    public JAXBElement<ResidenceType> createResidence(ResidenceType value) {
        return new JAXBElement<ResidenceType>(_Residence_QNAME, ResidenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NationalityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "nationality")
    public JAXBElement<NationalityType> createNationality(NationalityType value) {
        return new JAXBElement<NationalityType>(_Nationality_QNAME, NationalityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesignationEpcType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "designation-epc")
    public JAXBElement<DesignationEpcType> createDesignationEpc(DesignationEpcType value) {
        return new JAXBElement<DesignationEpcType>(_DesignationEpc_QNAME, DesignationEpcType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtensionStatesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "extension-states")
    public JAXBElement<ExtensionStatesType> createExtensionStates(ExtensionStatesType value) {
        return new JAXBElement<ExtensionStatesType>(_ExtensionStates_QNAME, ExtensionStatesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractingStatesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "contracting-states")
    public JAXBElement<ContractingStatesType> createContractingStates(ContractingStatesType value) {
        return new JAXBElement<ContractingStatesType>(_ContractingStates_QNAME, ContractingStatesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExclusionFromDesignationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "exclusion-from-designation")
    public JAXBElement<ExclusionFromDesignationType> createExclusionFromDesignation(ExclusionFromDesignationType value) {
        return new JAXBElement<ExclusionFromDesignationType>(_ExclusionFromDesignation_QNAME, ExclusionFromDesignationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrecautionaryDesignationStatementType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "precautionary-designation-statement")
    public JAXBElement<PrecautionaryDesignationStatementType> createPrecautionaryDesignationStatement(PrecautionaryDesignationStatementType value) {
        return new JAXBElement<PrecautionaryDesignationStatementType>(_PrecautionaryDesignationStatement_QNAME, PrecautionaryDesignationStatementType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DesignationPctType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "designation-pct")
    public JAXBElement<DesignationPctType> createDesignationPct(DesignationPctType value) {
        return new JAXBElement<DesignationPctType>(_DesignationPct_QNAME, DesignationPctType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NewDesignationCountryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "new-designation-country")
    public JAXBElement<NewDesignationCountryType> createNewDesignationCountry(NewDesignationCountryType value) {
        return new JAXBElement<NewDesignationCountryType>(_NewDesignationCountry_QNAME, NewDesignationCountryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NationalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "national")
    public JAXBElement<NationalType> createNational(NationalType value) {
        return new JAXBElement<NationalType>(_National_QNAME, NationalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegionalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "regional")
    public JAXBElement<RegionalType> createRegional(RegionalType value) {
        return new JAXBElement<RegionalType>(_Regional_QNAME, RegionalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnyOtherStateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "any-other-state")
    public JAXBElement<AnyOtherStateType> createAnyOtherState(AnyOtherStateType value) {
        return new JAXBElement<AnyOtherStateType>(_AnyOtherState_QNAME, AnyOtherStateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProtectionRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "protection-request")
    public JAXBElement<ProtectionRequestType> createProtectionRequest(ProtectionRequestType value) {
        return new JAXBElement<ProtectionRequestType>(_ProtectionRequest_QNAME, ProtectionRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KindOfProtectionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "kind-of-protection")
    public JAXBElement<KindOfProtectionType> createKindOfProtection(KindOfProtectionType value) {
        return new JAXBElement<KindOfProtectionType>(_KindOfProtection_QNAME, KindOfProtectionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "region")
    public JAXBElement<RegionType> createRegion(RegionType value) {
        return new JAXBElement<RegionType>(_Region_QNAME, RegionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TermOfGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "term-of-grant")
    public JAXBElement<TermOfGrantType> createTermOfGrant(TermOfGrantType value) {
        return new JAXBElement<TermOfGrantType>(_TermOfGrant_QNAME, TermOfGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LapseOfPatentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "lapse-of-patent")
    public JAXBElement<LapseOfPatentType> createLapseOfPatent(LapseOfPatentType value) {
        return new JAXBElement<LapseOfPatentType>(_LapseOfPatent_QNAME, LapseOfPatentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LengthOfGrantType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "length-of-grant")
    public JAXBElement<LengthOfGrantType> createLengthOfGrant(LengthOfGrantType value) {
        return new JAXBElement<LengthOfGrantType>(_LengthOfGrant_QNAME, LengthOfGrantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DisclaimerType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "disclaimer")
    public JAXBElement<DisclaimerType> createDisclaimer(DisclaimerType value) {
        return new JAXBElement<DisclaimerType>(_Disclaimer_QNAME, DisclaimerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CombinationRankType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "combination-rank")
    public JAXBElement<CombinationRankType> createCombinationRank(CombinationRankType value) {
        return new JAXBElement<CombinationRankType>(_CombinationRank_QNAME, CombinationRankType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlinkedIndexingCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "unlinked-indexing-code")
    public JAXBElement<UnlinkedIndexingCodeType> createUnlinkedIndexingCode(UnlinkedIndexingCodeType value) {
        return new JAXBElement<UnlinkedIndexingCodeType>(_UnlinkedIndexingCode_QNAME, UnlinkedIndexingCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinkedIndexingCodeGroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "linked-indexing-code-group")
    public JAXBElement<LinkedIndexingCodeGroupType> createLinkedIndexingCodeGroup(LinkedIndexingCodeGroupType value) {
        return new JAXBElement<LinkedIndexingCodeGroupType>(_LinkedIndexingCodeGroup_QNAME, LinkedIndexingCodeGroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubLinkedIndexingCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sub-linked-indexing-code")
    public JAXBElement<SubLinkedIndexingCodeType> createSubLinkedIndexingCode(SubLinkedIndexingCodeType value) {
        return new JAXBElement<SubLinkedIndexingCodeType>(_SubLinkedIndexingCode_QNAME, SubLinkedIndexingCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainLinkedIndexingCodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "main-linked-indexing-code")
    public JAXBElement<MainLinkedIndexingCodeType> createMainLinkedIndexingCode(MainLinkedIndexingCodeType value) {
        return new JAXBElement<MainLinkedIndexingCodeType>(_MainLinkedIndexingCode_QNAME, MainLinkedIndexingCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdditionalInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "additional-info")
    public JAXBElement<AdditionalInfoType> createAdditionalInfo(AdditionalInfoType value) {
        return new JAXBElement<AdditionalInfoType>(_AdditionalInfo_QNAME, AdditionalInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainClassificationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "main-classification")
    public JAXBElement<MainClassificationType> createMainClassification(MainClassificationType value) {
        return new JAXBElement<MainClassificationType>(_MainClassification_QNAME, MainClassificationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GeneratingOfficeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "generating-office")
    public JAXBElement<GeneratingOfficeType> createGeneratingOffice(GeneratingOfficeType value) {
        return new JAXBElement<GeneratingOfficeType>(_GeneratingOffice_QNAME, GeneratingOfficeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationDataSourceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-data-source")
    public JAXBElement<ClassificationDataSourceType> createClassificationDataSource(ClassificationDataSourceType value) {
        return new JAXBElement<ClassificationDataSourceType>(_ClassificationDataSource_QNAME, ClassificationDataSourceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-status")
    public JAXBElement<ClassificationStatusType> createClassificationStatus(ClassificationStatusType value) {
        return new JAXBElement<ClassificationStatusType>(_ClassificationStatus_QNAME, ClassificationStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActionDateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "action-date")
    public JAXBElement<ActionDateType> createActionDate(ActionDateType value) {
        return new JAXBElement<ActionDateType>(_ActionDate_QNAME, ActionDateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationValueType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-value")
    public JAXBElement<ClassificationValueType> createClassificationValue(ClassificationValueType value) {
        return new JAXBElement<ClassificationValueType>(_ClassificationValue_QNAME, ClassificationValueType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SymbolPositionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "symbol-position")
    public JAXBElement<SymbolPositionType> createSymbolPosition(SymbolPositionType value) {
        return new JAXBElement<SymbolPositionType>(_SymbolPosition_QNAME, SymbolPositionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClassificationLevelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "classification-level")
    public JAXBElement<ClassificationLevelType> createClassificationLevel(ClassificationLevelType value) {
        return new JAXBElement<ClassificationLevelType>(_ClassificationLevel_QNAME, ClassificationLevelType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IpcVersionIndicatorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ipc-version-indicator")
    public JAXBElement<IpcVersionIndicatorType> createIpcVersionIndicator(IpcVersionIndicatorType value) {
        return new JAXBElement<IpcVersionIndicatorType>(_IpcVersionIndicator_QNAME, IpcVersionIndicatorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubgroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "subgroup")
    public JAXBElement<SubgroupType> createSubgroup(SubgroupType value) {
        return new JAXBElement<SubgroupType>(_Subgroup_QNAME, SubgroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MainGroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "main-group")
    public JAXBElement<MainGroupType> createMainGroup(MainGroupType value) {
        return new JAXBElement<MainGroupType>(_MainGroup_QNAME, MainGroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubclassType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "subclass")
    public JAXBElement<SubclassType> createSubclass(SubclassType value) {
        return new JAXBElement<SubclassType>(_Subclass_QNAME, SubclassType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SectionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "section")
    public JAXBElement<SectionType> createSection(SectionType value) {
        return new JAXBElement<SectionType>(_Section_QNAME, SectionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExchPType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "p")
    public JAXBElement<ExchPType> createP(ExchPType value) {
        return new JAXBElement<ExchPType>(_P_QNAME, ExchPType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstSolutionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "abst-solution")
    public JAXBElement<AbstSolutionType> createAbstSolution(AbstSolutionType value) {
        return new JAXBElement<AbstSolutionType>(_AbstSolution_QNAME, AbstSolutionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstProblemType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "abst-problem")
    public JAXBElement<AbstProblemType> createAbstProblem(AbstProblemType value) {
        return new JAXBElement<AbstProblemType>(_AbstProblem_QNAME, AbstProblemType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "dd")
    public JAXBElement<DdType> createDd(DdType value) {
        return new JAXBElement<DdType>(_Dd_QNAME, DdType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "math")
    public JAXBElement<MathType> createMath(MathType value) {
        return new JAXBElement<MathType>(_Math_QNAME, MathType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TermType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "term")
    public JAXBElement<TermType> createTerm(TermType value) {
        return new JAXBElement<TermType>(_Term_QNAME, TermType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioAccnoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "bio-accno")
    public JAXBElement<BioAccnoType> createBioAccno(BioAccnoType value) {
        return new JAXBElement<BioAccnoType>(_BioAccno_QNAME, BioAccnoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepositaryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "depositary")
    public JAXBElement<DepositaryType> createDepositary(DepositaryType value) {
        return new JAXBElement<DepositaryType>(_Depositary_QNAME, DepositaryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OthercitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "othercit")
    public JAXBElement<OthercitType> createOthercit(OthercitType value) {
        return new JAXBElement<OthercitType>(_Othercit_QNAME, OthercitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnlineType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "online")
    public JAXBElement<OnlineType> createOnline(OnlineType value) {
        return new JAXBElement<OnlineType>(_Online_QNAME, OnlineType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrchdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srchdate")
    public JAXBElement<SrchdateType> createSrchdate(SrchdateType value) {
        return new JAXBElement<SrchdateType>(_Srchdate_QNAME, SrchdateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SrchtermType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "srchterm")
    public JAXBElement<SrchtermType> createSrchterm(SrchtermType value) {
        return new JAXBElement<SrchtermType>(_Srchterm_QNAME, SrchtermType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DatecitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "datecit")
    public JAXBElement<DatecitType> createDatecit(DatecitType value) {
        return new JAXBElement<DatecitType>(_Datecit_QNAME, DatecitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AvailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "avail")
    public JAXBElement<AvailType> createAvail(AvailType value) {
        return new JAXBElement<AvailType>(_Avail_QNAME, AvailType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HostnoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "hostno")
    public JAXBElement<HostnoType> createHostno(HostnoType value) {
        return new JAXBElement<HostnoType>(_Hostno_QNAME, HostnoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HistoryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "history")
    public JAXBElement<HistoryType> createHistory(HistoryType value) {
        return new JAXBElement<HistoryType>(_History_QNAME, HistoryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiscType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "misc")
    public JAXBElement<MiscType> createMisc(MiscType value) {
        return new JAXBElement<MiscType>(_Misc_QNAME, MiscType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RevisedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "revised")
    public JAXBElement<RevisedType> createRevised(RevisedType value) {
        return new JAXBElement<RevisedType>(_Revised_QNAME, RevisedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AcceptedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "accepted")
    public JAXBElement<AcceptedType> createAccepted(AcceptedType value) {
        return new JAXBElement<AcceptedType>(_Accepted_QNAME, AcceptedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceivedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "received")
    public JAXBElement<ReceivedType> createReceived(ReceivedType value) {
        return new JAXBElement<ReceivedType>(_Received_QNAME, ReceivedType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HosttitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "hosttitle")
    public JAXBElement<HosttitleType> createHosttitle(HosttitleType value) {
        return new JAXBElement<HosttitleType>(_Hosttitle_QNAME, HosttitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnlineTitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "online-title")
    public JAXBElement<OnlineTitleType> createOnlineTitle(OnlineTitleType value) {
        return new JAXBElement<OnlineTitleType>(_OnlineTitle_QNAME, OnlineTitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArticleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "article")
    public JAXBElement<ArticleType> createArticle(ArticleType value) {
        return new JAXBElement<ArticleType>(_Article_QNAME, ArticleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArtidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "artid")
    public JAXBElement<ArtidType> createArtid(ArtidType value) {
        return new JAXBElement<ArtidType>(_Artid_QNAME, ArtidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BookType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "book")
    public JAXBElement<BookType> createBook(BookType value) {
        return new JAXBElement<BookType>(_Book_QNAME, BookType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KeywordType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "keyword")
    public JAXBElement<KeywordType> createKeyword(KeywordType value) {
        return new JAXBElement<KeywordType>(_Keyword_QNAME, KeywordType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooknoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "bookno")
    public JAXBElement<BooknoType> createBookno(BooknoType value) {
        return new JAXBElement<BooknoType>(_Bookno_QNAME, BooknoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "location")
    public JAXBElement<LocationType> createLocation(LocationType value) {
        return new JAXBElement<LocationType>(_Location_QNAME, LocationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LineType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "line")
    public JAXBElement<LineType> createLine(LineType value) {
        return new JAXBElement<LineType>(_Line_QNAME, LineType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "linel")
    public JAXBElement<LinelType> createLinel(LinelType value) {
        return new JAXBElement<LinelType>(_Linel_QNAME, LinelType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "linef")
    public JAXBElement<LinefType> createLinef(LinefType value) {
        return new JAXBElement<LinefType>(_Linef_QNAME, LinefType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParaType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "para")
    public JAXBElement<ParaType> createPara(ParaType value) {
        return new JAXBElement<ParaType>(_Para_QNAME, ParaType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "paral")
    public JAXBElement<ParalType> createParal(ParalType value) {
        return new JAXBElement<ParalType>(_Paral_QNAME, ParalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParafType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "paraf")
    public JAXBElement<ParafType> createParaf(ParafType value) {
        return new JAXBElement<ParafType>(_Paraf_QNAME, ParafType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ColumnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "column")
    public JAXBElement<ColumnType> createColumn(ColumnType value) {
        return new JAXBElement<ColumnType>(_Column_QNAME, ColumnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CollType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "coll")
    public JAXBElement<CollType> createColl(CollType value) {
        return new JAXBElement<CollType>(_Coll_QNAME, CollType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ColfType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "colf")
    public JAXBElement<ColfType> createColf(ColfType value) {
        return new JAXBElement<ColfType>(_Colf_QNAME, ColfType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PpType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pp")
    public JAXBElement<PpType> createPp(PpType value) {
        return new JAXBElement<PpType>(_Pp_QNAME, PpType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PplType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ppl")
    public JAXBElement<PplType> createPpl(PplType value) {
        return new JAXBElement<PplType>(_Ppl_QNAME, PplType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PpfType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ppf")
    public JAXBElement<PpfType> createPpf(PpfType value) {
        return new JAXBElement<PpfType>(_Ppf_QNAME, PpfType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChapterType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "chapter")
    public JAXBElement<ChapterType> createChapter(ChapterType value) {
        return new JAXBElement<ChapterType>(_Chapter_QNAME, ChapterType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SersectType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sersect")
    public JAXBElement<SersectType> createSersect(SersectType value) {
        return new JAXBElement<SersectType>(_Sersect_QNAME, SersectType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SerpartType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "serpart")
    public JAXBElement<SerpartType> createSerpart(SerpartType value) {
        return new JAXBElement<SerpartType>(_Serpart_QNAME, SerpartType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbsnoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "absno")
    public JAXBElement<AbsnoType> createAbsno(AbsnoType value) {
        return new JAXBElement<AbsnoType>(_Absno_QNAME, AbsnoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SeriesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "series")
    public JAXBElement<SeriesType> createSeries(SeriesType value) {
        return new JAXBElement<SeriesType>(_Series_QNAME, SeriesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "msn")
    public JAXBElement<MsnType> createMsn(MsnType value) {
        return new JAXBElement<MsnType>(_Msn_QNAME, MsnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MstType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mst")
    public JAXBElement<MstType> createMst(MstType value) {
        return new JAXBElement<MstType>(_Mst_QNAME, MstType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EditionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "edition")
    public JAXBElement<EditionType> createEdition(EditionType value) {
        return new JAXBElement<EditionType>(_Edition_QNAME, EditionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubtitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "subtitle")
    public JAXBElement<SubtitleType> createSubtitle(SubtitleType value) {
        return new JAXBElement<SubtitleType>(_Subtitle_QNAME, SubtitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConferenceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "conference")
    public JAXBElement<ConferenceType> createConference(ConferenceType value) {
        return new JAXBElement<ConferenceType>(_Conference_QNAME, ConferenceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConfsponsorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "confsponsor")
    public JAXBElement<ConfsponsorType> createConfsponsor(ConfsponsorType value) {
        return new JAXBElement<ConfsponsorType>(_Confsponsor_QNAME, ConfsponsorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConfplaceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "confplace")
    public JAXBElement<ConfplaceType> createConfplace(ConfplaceType value) {
        return new JAXBElement<ConfplaceType>(_Confplace_QNAME, ConfplaceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConfnoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "confno")
    public JAXBElement<ConfnoType> createConfno(ConfnoType value) {
        return new JAXBElement<ConfnoType>(_Confno_QNAME, ConfnoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConftitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "conftitle")
    public JAXBElement<ConftitleType> createConftitle(ConftitleType value) {
        return new JAXBElement<ConftitleType>(_Conftitle_QNAME, ConftitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BookTitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "book-title")
    public JAXBElement<BookTitleType> createBookTitle(BookTitleType value) {
        return new JAXBElement<BookTitleType>(_BookTitle_QNAME, BookTitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SerialType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "serial")
    public JAXBElement<SerialType> createSerial(SerialType value) {
        return new JAXBElement<SerialType>(_Serial_QNAME, SerialType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpyrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "cpyrt")
    public JAXBElement<CpyrtType> createCpyrt(CpyrtType value) {
        return new JAXBElement<CpyrtType>(_Cpyrt_QNAME, CpyrtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsbnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "isbn")
    public JAXBElement<IsbnType> createIsbn(IsbnType value) {
        return new JAXBElement<IsbnType>(_Isbn_QNAME, IsbnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IssnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "issn")
    public JAXBElement<IssnType> createIssn(IssnType value) {
        return new JAXBElement<IssnType>(_Issn_QNAME, IssnType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ino")
    public JAXBElement<InoType> createIno(InoType value) {
        return new JAXBElement<InoType>(_Ino_QNAME, InoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "doi")
    public JAXBElement<DoiType> createDoi(DoiType value) {
        return new JAXBElement<DoiType>(_Doi_QNAME, DoiType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "vid")
    public JAXBElement<VidType> createVid(VidType value) {
        return new JAXBElement<VidType>(_Vid_QNAME, VidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PubidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pubid")
    public JAXBElement<PubidType> createPubid(PubidType value) {
        return new JAXBElement<PubidType>(_Pubid_QNAME, PubidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NotesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "notes")
    public JAXBElement<NotesType> createNotes(NotesType value) {
        return new JAXBElement<NotesType>(_Notes_QNAME, NotesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DescripType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "descrip")
    public JAXBElement<DescripType> createDescrip(DescripType value) {
        return new JAXBElement<DescripType>(_Descrip_QNAME, DescripType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImprintType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "imprint")
    public JAXBElement<ImprintType> createImprint(ImprintType value) {
        return new JAXBElement<ImprintType>(_Imprint_QNAME, ImprintType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PubdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pubdate")
    public JAXBElement<PubdateType> createPubdate(PubdateType value) {
        return new JAXBElement<PubdateType>(_Pubdate_QNAME, PubdateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "time")
    public JAXBElement<TimeType> createTime(TimeType value) {
        return new JAXBElement<TimeType>(_Time_QNAME, TimeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "edate")
    public JAXBElement<EdateType> createEdate(EdateType value) {
        return new JAXBElement<EdateType>(_Edate_QNAME, EdateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sdate")
    public JAXBElement<SdateType> createSdate(SdateType value) {
        return new JAXBElement<SdateType>(_Sdate_QNAME, SdateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IssueType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "issue")
    public JAXBElement<IssueType> createIssue(IssueType value) {
        return new JAXBElement<IssueType>(_Issue_QNAME, IssueType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AlttitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "alttitle")
    public JAXBElement<AlttitleType> createAlttitle(AlttitleType value) {
        return new JAXBElement<AlttitleType>(_Alttitle_QNAME, AlttitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SertitleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sertitle")
    public JAXBElement<SertitleType> createSertitle(SertitleType value) {
        return new JAXBElement<SertitleType>(_Sertitle_QNAME, SertitleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AtlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "atl")
    public JAXBElement<AtlType> createAtl(AtlType value) {
        return new JAXBElement<AtlType>(_Atl_QNAME, AtlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "dtext")
    public JAXBElement<DtextType> createDtext(DtextType value) {
        return new JAXBElement<DtextType>(_Dtext_QNAME, DtextType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EadType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "ead")
    public JAXBElement<EadType> createEad(EadType value) {
        return new JAXBElement<EadType>(_Ead_QNAME, EadType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UrlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "url")
    public JAXBElement<UrlType> createUrl(UrlType value) {
        return new JAXBElement<UrlType>(_Url_QNAME, UrlType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "email")
    public JAXBElement<EmailType> createEmail(EmailType value) {
        return new JAXBElement<EmailType>(_Email_QNAME, EmailType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "fax")
    public JAXBElement<FaxType> createFax(FaxType value) {
        return new JAXBElement<FaxType>(_Fax_QNAME, FaxType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PhoneType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "phone")
    public JAXBElement<PhoneType> createPhone(PhoneType value) {
        return new JAXBElement<PhoneType>(_Phone_QNAME, PhoneType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "address")
    public JAXBElement<AddressType> createAddress(AddressType value) {
        return new JAXBElement<AddressType>(_Address_QNAME, AddressType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PostcodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "postcode")
    public JAXBElement<PostcodeType> createPostcode(PostcodeType value) {
        return new JAXBElement<PostcodeType>(_Postcode_QNAME, PostcodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "state")
    public JAXBElement<StateType> createState(StateType value) {
        return new JAXBElement<StateType>(_State_QNAME, StateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CountyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "county")
    public JAXBElement<CountyType> createCounty(CountyType value) {
        return new JAXBElement<CountyType>(_County_QNAME, CountyType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "city")
    public JAXBElement<CityType> createCity(CityType value) {
        return new JAXBElement<CityType>(_City_QNAME, CityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StreetType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "street")
    public JAXBElement<StreetType> createStreet(StreetType value) {
        return new JAXBElement<StreetType>(_Street_QNAME, StreetType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BuildingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "building")
    public JAXBElement<BuildingType> createBuilding(BuildingType value) {
        return new JAXBElement<BuildingType>(_Building_QNAME, BuildingType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFloorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "address-floor")
    public JAXBElement<AddressFloorType> createAddressFloor(AddressFloorType value) {
        return new JAXBElement<AddressFloorType>(_AddressFloor_QNAME, AddressFloorType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoomType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "room")
    public JAXBElement<RoomType> createRoom(RoomType value) {
        return new JAXBElement<RoomType>(_Room_QNAME, RoomType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PoboxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pobox")
    public JAXBElement<PoboxType> createPobox(PoboxType value) {
        return new JAXBElement<PoboxType>(_Pobox_QNAME, PoboxType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MailcodeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "mailcode")
    public JAXBElement<MailcodeType> createMailcode(MailcodeType value) {
        return new JAXBElement<MailcodeType>(_Mailcode_QNAME, MailcodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address3Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "address-3")
    public JAXBElement<Address3Type> createAddress3(Address3Type value) {
        return new JAXBElement<Address3Type>(_Address3_QNAME, Address3Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "address-2")
    public JAXBElement<Address2Type> createAddress2(Address2Type value) {
        return new JAXBElement<Address2Type>(_Address2_QNAME, Address2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address1Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "address-1")
    public JAXBElement<Address1Type> createAddress1(Address1Type value) {
        return new JAXBElement<Address1Type>(_Address1_QNAME, Address1Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "registered-number")
    public JAXBElement<RegisteredNumberType> createRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_RegisteredNumber_QNAME, RegisteredNumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "synonym")
    public JAXBElement<SynonymType> createSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_Synonym_QNAME, SynonymType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "department")
    public JAXBElement<DepartmentType> createDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_Department_QNAME, DepartmentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "suffix")
    public JAXBElement<SuffixType> createSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_Suffix_QNAME, SuffixType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "prefix")
    public JAXBElement<PrefixType> createPrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_Prefix_QNAME, PrefixType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "role")
    public JAXBElement<RoleType> createRole(RoleType value) {
        return new JAXBElement<RoleType>(_Role_QNAME, RoleType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "iid")
    public JAXBElement<IidType> createIid(IidType value) {
        return new JAXBElement<IidType>(_Iid_QNAME, IidType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "orgname")
    public JAXBElement<OrgnameType> createOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_Orgname_QNAME, OrgnameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "middle-name")
    public JAXBElement<MiddleNameType> createMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_MiddleName_QNAME, MiddleNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "first-name")
    public JAXBElement<FirstNameType> createFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_FirstName_QNAME, FirstNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "last-name")
    public JAXBElement<LastNameType> createLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_LastName_QNAME, LastNameType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelPassageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "rel-passage")
    public JAXBElement<RelPassageType> createRelPassage(RelPassageType value) {
        return new JAXBElement<RelPassageType>(_RelPassage_QNAME, RelPassageType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelClaimsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "rel-claims")
    public JAXBElement<RelClaimsType> createRelClaims(RelClaimsType value) {
        return new JAXBElement<RelClaimsType>(_RelClaims_QNAME, RelClaimsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CategoryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "category")
    public JAXBElement<CategoryType> createCategory(CategoryType value) {
        return new JAXBElement<CategoryType>(_Category_QNAME, CategoryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PassageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "passage")
    public JAXBElement<PassageType> createPassage(PassageType value) {
        return new JAXBElement<PassageType>(_Passage_QNAME, PassageType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KindType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "kind")
    public JAXBElement<KindType> createKind(KindType value) {
        return new JAXBElement<KindType>(_Kind_QNAME, KindType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "doc-number")
    public JAXBElement<DocNumberType> createDocNumber(DocNumberType value) {
        return new JAXBElement<DocNumberType>(_DocNumber_QNAME, DocNumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CountryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "country")
    public JAXBElement<CountryType> createCountry(CountryType value) {
        return new JAXBElement<CountryType>(_Country_QNAME, CountryType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "pre")
    public JAXBElement<PreType> createPre(PreType value) {
        return new JAXBElement<PreType>(_Pre_QNAME, PreType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "br")
    public JAXBElement<BrType> createBr(BrType value) {
        return new JAXBElement<BrType>(_Br_QNAME, BrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "b")
    public JAXBElement<BType> createB(BType value) {
        return new JAXBElement<BType>(_B_QNAME, BType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "i")
    public JAXBElement<IType> createI(IType value) {
        return new JAXBElement<IType>(_I_QNAME, IType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "smallcaps")
    public JAXBElement<SmallcapsType> createSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_Smallcaps_QNAME, SmallcapsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sup")
    public JAXBElement<SupType> createSup(SupType value) {
        return new JAXBElement<SupType>(_Sup_QNAME, SupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sub")
    public JAXBElement<SubType> createSub(SubType value) {
        return new JAXBElement<SubType>(_Sub_QNAME, SubType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sub2")
    public JAXBElement<Sub2Type> createSub2(Sub2Type value) {
        return new JAXBElement<Sub2Type>(_Sub2_QNAME, Sub2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.epo.org/exchange", name = "sup2")
    public JAXBElement<Sup2Type> createSup2(Sup2Type value) {
        return new JAXBElement<Sup2Type>(_Sup2_QNAME, Sup2Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sdate", scope = RangedateType.class)
    public JAXBElement<SdateType> createRangedateTypeSdate(SdateType value) {
        return new JAXBElement<SdateType>(_RangedateTypeSdate_QNAME, SdateType.class, RangedateType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EdateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edate", scope = RangedateType.class)
    public JAXBElement<EdateType> createRangedateTypeEdate(EdateType value) {
        return new JAXBElement<EdateType>(_RangedateTypeEdate_QNAME, EdateType.class, RangedateType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "time", scope = RangedateType.class)
    public JAXBElement<TimeType> createRangedateTypeTime(TimeType value) {
        return new JAXBElement<TimeType>(_RangedateTypeTime_QNAME, TimeType.class, RangedateType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = PType.class)
    public JAXBElement<BType> createPTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = PType.class)
    public JAXBElement<IType> createPTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = PType.class)
    public JAXBElement<UType> createPTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = PType.class)
    public JAXBElement<SupType> createPTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = PType.class)
    public JAXBElement<SubType> createPTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = PType.class)
    public JAXBElement<SmallcapsType> createPTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br", scope = PType.class)
    public JAXBElement<BrType> createPTypeBr(BrType value) {
        return new JAXBElement<BrType>(_PTypeBr_QNAME, BrType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre", scope = PType.class)
    public JAXBElement<PreType> createPTypePre(PreType value) {
        return new JAXBElement<PreType>(_PTypePre_QNAME, PreType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl", scope = PType.class)
    public JAXBElement<DlType> createPTypeDl(DlType value) {
        return new JAXBElement<DlType>(_PTypeDl_QNAME, DlType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul", scope = PType.class)
    public JAXBElement<UlType> createPTypeUl(UlType value) {
        return new JAXBElement<UlType>(_PTypeUl_QNAME, UlType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol", scope = PType.class)
    public JAXBElement<OlType> createPTypeOl(OlType value) {
        return new JAXBElement<OlType>(_PTypeOl_QNAME, OlType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref", scope = PType.class)
    public JAXBElement<CrossrefType> createPTypeCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_PTypeCrossref_QNAME, CrossrefType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref", scope = PType.class)
    public JAXBElement<FigrefType> createPTypeFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_PTypeFigref_QNAME, FigrefType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit", scope = PType.class)
    public JAXBElement<PatcitType> createPTypePatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_PTypePatcit_QNAME, PatcitType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit", scope = PType.class)
    public JAXBElement<NplcitType> createPTypeNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_PTypeNplcit_QNAME, NplcitType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit", scope = PType.class)
    public JAXBElement<BioDepositType> createPTypeBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_PTypeBioDeposit_QNAME, BioDepositType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = PType.class)
    public JAXBElement<ImgType> createPTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry", scope = PType.class)
    public JAXBElement<ChemistryType> createPTypeChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_PTypeChemistry_QNAME, ChemistryType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths", scope = PType.class)
    public JAXBElement<MathsType> createPTypeMaths(MathsType value) {
        return new JAXBElement<MathsType>(_PTypeMaths_QNAME, MathsType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TablesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tables", scope = PType.class)
    public JAXBElement<TablesType> createPTypeTables(TablesType value) {
        return new JAXBElement<TablesType>(_PTypeTables_QNAME, TablesType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableExternalDocType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table-external-doc", scope = PType.class)
    public JAXBElement<TableExternalDocType> createPTypeTableExternalDoc(TableExternalDocType value) {
        return new JAXBElement<TableExternalDocType>(_PTypeTableExternalDoc_QNAME, TableExternalDocType.class, PType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = Sup2Type.class)
    public JAXBElement<BType> createSup2TypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, Sup2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = Sup2Type.class)
    public JAXBElement<UType> createSup2TypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, Sup2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = Sup2Type.class)
    public JAXBElement<IType> createSup2TypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, Sup2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = Sup2Type.class)
    public JAXBElement<OType> createSup2TypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, Sup2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = Sub2Type.class)
    public JAXBElement<BType> createSub2TypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, Sub2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = Sub2Type.class)
    public JAXBElement<UType> createSub2TypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, Sub2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = Sub2Type.class)
    public JAXBElement<IType> createSub2TypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, Sub2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = Sub2Type.class)
    public JAXBElement<OType> createSub2TypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, Sub2Type.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = SubType.class)
    public JAXBElement<BType> createSubTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = SubType.class)
    public JAXBElement<UType> createSubTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = SubType.class)
    public JAXBElement<IType> createSubTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = SubType.class)
    public JAXBElement<OType> createSubTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup2", scope = SubType.class)
    public JAXBElement<Sup2Type> createSubTypeSup2(Sup2Type value) {
        return new JAXBElement<Sup2Type>(_SubTypeSup2_QNAME, Sup2Type.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub2", scope = SubType.class)
    public JAXBElement<Sub2Type> createSubTypeSub2(Sub2Type value) {
        return new JAXBElement<Sub2Type>(_SubTypeSub2_QNAME, Sub2Type.class, SubType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = SupType.class)
    public JAXBElement<BType> createSupTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = SupType.class)
    public JAXBElement<UType> createSupTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = SupType.class)
    public JAXBElement<IType> createSupTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = SupType.class)
    public JAXBElement<OType> createSupTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup2", scope = SupType.class)
    public JAXBElement<Sup2Type> createSupTypeSup2(Sup2Type value) {
        return new JAXBElement<Sup2Type>(_SubTypeSup2_QNAME, Sup2Type.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub2Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub2", scope = SupType.class)
    public JAXBElement<Sub2Type> createSupTypeSub2(Sub2Type value) {
        return new JAXBElement<Sub2Type>(_SubTypeSub2_QNAME, Sub2Type.class, SupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = SmallcapsType.class)
    public JAXBElement<BType> createSmallcapsTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, SmallcapsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = SmallcapsType.class)
    public JAXBElement<UType> createSmallcapsTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, SmallcapsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = SmallcapsType.class)
    public JAXBElement<IType> createSmallcapsTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, SmallcapsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = SmallcapsType.class)
    public JAXBElement<OType> createSmallcapsTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, SmallcapsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = IType.class)
    public JAXBElement<BType> createITypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = IType.class)
    public JAXBElement<UType> createITypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = IType.class)
    public JAXBElement<OType> createITypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = IType.class)
    public JAXBElement<SupType> createITypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = IType.class)
    public JAXBElement<SubType> createITypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = IType.class)
    public JAXBElement<SmallcapsType> createITypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, IType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = BType.class)
    public JAXBElement<IType> createBTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = BType.class)
    public JAXBElement<UType> createBTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = BType.class)
    public JAXBElement<OType> createBTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = BType.class)
    public JAXBElement<SupType> createBTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = BType.class)
    public JAXBElement<SubType> createBTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = BType.class)
    public JAXBElement<SmallcapsType> createBTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, BType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pp", scope = PassageType.class)
    public JAXBElement<String> createPassageTypePp(String value) {
        return new JAXBElement<String>(_PassageTypePp_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppf", scope = PassageType.class)
    public JAXBElement<String> createPassageTypePpf(String value) {
        return new JAXBElement<String>(_PassageTypePpf_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppl", scope = PassageType.class)
    public JAXBElement<String> createPassageTypePpl(String value) {
        return new JAXBElement<String>(_PassageTypePpl_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "column", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeColumn(String value) {
        return new JAXBElement<String>(_PassageTypeColumn_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colf", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeColf(String value) {
        return new JAXBElement<String>(_PassageTypeColf_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coll", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeColl(String value) {
        return new JAXBElement<String>(_PassageTypeColl_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "para", scope = PassageType.class)
    public JAXBElement<String> createPassageTypePara(String value) {
        return new JAXBElement<String>(_PassageTypePara_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paraf", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeParaf(String value) {
        return new JAXBElement<String>(_PassageTypeParaf_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paral", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeParal(String value) {
        return new JAXBElement<String>(_PassageTypeParal_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "line", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeLine(String value) {
        return new JAXBElement<String>(_PassageTypeLine_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linef", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeLinef(String value) {
        return new JAXBElement<String>(_PassageTypeLinef_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linel", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeLinel(String value) {
        return new JAXBElement<String>(_PassageTypeLinel_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeClaim(String value) {
        return new JAXBElement<String>(_PassageTypeClaim_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figure", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeFigure(String value) {
        return new JAXBElement<String>(_PassageTypeFigure_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "example", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeExample(String value) {
        return new JAXBElement<String>(_PassageTypeExample_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeTable(String value) {
        return new JAXBElement<String>(_PassageTypeTable_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sequence", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeSequence(String value) {
        return new JAXBElement<String>(_PassageTypeSequence_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "compound", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeCompound(String value) {
        return new JAXBElement<String>(_PassageTypeCompound_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bookmark", scope = PassageType.class)
    public JAXBElement<String> createPassageTypeBookmark(String value) {
        return new JAXBElement<String>(_PassageTypeBookmark_QNAME, String.class, PassageType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address", scope = ConfplaceType.class)
    public JAXBElement<AddressType> createConfplaceTypeAddress(AddressType value) {
        return new JAXBElement<AddressType>(_ConfplaceTypeAddress_QNAME, AddressType.class, ConfplaceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressbookType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressbook", scope = ConfsponsorType.class)
    public JAXBElement<AddressbookType> createConfsponsorTypeAddressbook(AddressbookType value) {
        return new JAXBElement<AddressbookType>(_ConfsponsorTypeAddressbook_QNAME, AddressbookType.class, ConfsponsorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PpfType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppf", scope = PpType.class)
    public JAXBElement<PpfType> createPpTypePpf(PpfType value) {
        return new JAXBElement<PpfType>(_PassageTypePpf_QNAME, PpfType.class, PpType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PplType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppl", scope = PpType.class)
    public JAXBElement<PplType> createPpTypePpl(PplType value) {
        return new JAXBElement<PplType>(_PassageTypePpl_QNAME, PplType.class, PpType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ColfType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colf", scope = ColumnType.class)
    public JAXBElement<ColfType> createColumnTypeColf(ColfType value) {
        return new JAXBElement<ColfType>(_PassageTypeColf_QNAME, ColfType.class, ColumnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CollType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coll", scope = ColumnType.class)
    public JAXBElement<CollType> createColumnTypeColl(CollType value) {
        return new JAXBElement<CollType>(_PassageTypeColl_QNAME, CollType.class, ColumnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParafType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paraf", scope = ParaType.class)
    public JAXBElement<ParafType> createParaTypeParaf(ParafType value) {
        return new JAXBElement<ParafType>(_PassageTypeParaf_QNAME, ParafType.class, ParaType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ParalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paral", scope = ParaType.class)
    public JAXBElement<ParalType> createParaTypeParal(ParalType value) {
        return new JAXBElement<ParalType>(_PassageTypeParal_QNAME, ParalType.class, ParaType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linef", scope = LineType.class)
    public JAXBElement<LinefType> createLineTypeLinef(LinefType value) {
        return new JAXBElement<LinefType>(_PassageTypeLinef_QNAME, LinefType.class, LineType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LinelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linel", scope = LineType.class)
    public JAXBElement<LinelType> createLineTypeLinel(LinelType value) {
        return new JAXBElement<LinelType>(_PassageTypeLinel_QNAME, LinelType.class, LineType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date", scope = MiscType.class)
    public JAXBElement<BigInteger> createMiscTypeDate(BigInteger value) {
        return new JAXBElement<BigInteger>(_MiscTypeDate_QNAME, BigInteger.class, MiscType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = OthercitType.class)
    public JAXBElement<BType> createOthercitTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, OthercitType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = OthercitType.class)
    public JAXBElement<IType> createOthercitTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, OthercitType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = OthercitType.class)
    public JAXBElement<UType> createOthercitTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, OthercitType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = OthercitType.class)
    public JAXBElement<SupType> createOthercitTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, OthercitType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = OthercitType.class)
    public JAXBElement<SubType> createOthercitTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, OthercitType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address", scope = DepositaryType.class)
    public JAXBElement<AddressType> createDepositaryTypeAddress(AddressType value) {
        return new JAXBElement<AddressType>(_ConfplaceTypeAddress_QNAME, AddressType.class, DepositaryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = DdType.class)
    public JAXBElement<BType> createDdTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = DdType.class)
    public JAXBElement<IType> createDdTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = DdType.class)
    public JAXBElement<UType> createDdTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = DdType.class)
    public JAXBElement<OType> createDdTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = DdType.class)
    public JAXBElement<SupType> createDdTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = DdType.class)
    public JAXBElement<SubType> createDdTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = DdType.class)
    public JAXBElement<SmallcapsType> createDdTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br", scope = DdType.class)
    public JAXBElement<BrType> createDdTypeBr(BrType value) {
        return new JAXBElement<BrType>(_PTypeBr_QNAME, BrType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre", scope = DdType.class)
    public JAXBElement<PreType> createDdTypePre(PreType value) {
        return new JAXBElement<PreType>(_PTypePre_QNAME, PreType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit", scope = DdType.class)
    public JAXBElement<PatcitType> createDdTypePatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_PTypePatcit_QNAME, PatcitType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit", scope = DdType.class)
    public JAXBElement<NplcitType> createDdTypeNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_PTypeNplcit_QNAME, NplcitType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit", scope = DdType.class)
    public JAXBElement<BioDepositType> createDdTypeBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_PTypeBioDeposit_QNAME, BioDepositType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref", scope = DdType.class)
    public JAXBElement<CrossrefType> createDdTypeCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_PTypeCrossref_QNAME, CrossrefType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref", scope = DdType.class)
    public JAXBElement<FigrefType> createDdTypeFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_PTypeFigref_QNAME, FigrefType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = DdType.class)
    public JAXBElement<ImgType> createDdTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul", scope = DdType.class)
    public JAXBElement<UlType> createDdTypeUl(UlType value) {
        return new JAXBElement<UlType>(_PTypeUl_QNAME, UlType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol", scope = DdType.class)
    public JAXBElement<OlType> createDdTypeOl(OlType value) {
        return new JAXBElement<OlType>(_PTypeOl_QNAME, OlType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry", scope = DdType.class)
    public JAXBElement<ChemistryType> createDdTypeChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_PTypeChemistry_QNAME, ChemistryType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths", scope = DdType.class)
    public JAXBElement<MathsType> createDdTypeMaths(MathsType value) {
        return new JAXBElement<MathsType>(_PTypeMaths_QNAME, MathsType.class, DdType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = ExchPType.class)
    public JAXBElement<OType> createExchPTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = ExchPType.class)
    public JAXBElement<BType> createExchPTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = ExchPType.class)
    public JAXBElement<IType> createExchPTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = ExchPType.class)
    public JAXBElement<UType> createExchPTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = ExchPType.class)
    public JAXBElement<SupType> createExchPTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = ExchPType.class)
    public JAXBElement<SubType> createExchPTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = ExchPType.class)
    public JAXBElement<SmallcapsType> createExchPTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br", scope = ExchPType.class)
    public JAXBElement<BrType> createExchPTypeBr(BrType value) {
        return new JAXBElement<BrType>(_PTypeBr_QNAME, BrType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre", scope = ExchPType.class)
    public JAXBElement<PreType> createExchPTypePre(PreType value) {
        return new JAXBElement<PreType>(_PTypePre_QNAME, PreType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl", scope = ExchPType.class)
    public JAXBElement<DlType> createExchPTypeDl(DlType value) {
        return new JAXBElement<DlType>(_PTypeDl_QNAME, DlType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul", scope = ExchPType.class)
    public JAXBElement<UlType> createExchPTypeUl(UlType value) {
        return new JAXBElement<UlType>(_PTypeUl_QNAME, UlType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol", scope = ExchPType.class)
    public JAXBElement<OlType> createExchPTypeOl(OlType value) {
        return new JAXBElement<OlType>(_PTypeOl_QNAME, OlType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref", scope = ExchPType.class)
    public JAXBElement<CrossrefType> createExchPTypeCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_PTypeCrossref_QNAME, CrossrefType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref", scope = ExchPType.class)
    public JAXBElement<FigrefType> createExchPTypeFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_PTypeFigref_QNAME, FigrefType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit", scope = ExchPType.class)
    public JAXBElement<PatcitType> createExchPTypePatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_PTypePatcit_QNAME, PatcitType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit", scope = ExchPType.class)
    public JAXBElement<NplcitType> createExchPTypeNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_PTypeNplcit_QNAME, NplcitType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit", scope = ExchPType.class)
    public JAXBElement<BioDepositType> createExchPTypeBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_PTypeBioDeposit_QNAME, BioDepositType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = ExchPType.class)
    public JAXBElement<ImgType> createExchPTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry", scope = ExchPType.class)
    public JAXBElement<ChemistryType> createExchPTypeChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_PTypeChemistry_QNAME, ChemistryType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths", scope = ExchPType.class)
    public JAXBElement<MathsType> createExchPTypeMaths(MathsType value) {
        return new JAXBElement<MathsType>(_PTypeMaths_QNAME, MathsType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TablesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tables", scope = ExchPType.class)
    public JAXBElement<TablesType> createExchPTypeTables(TablesType value) {
        return new JAXBElement<TablesType>(_PTypeTables_QNAME, TablesType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableExternalDocType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table-external-doc", scope = ExchPType.class)
    public JAXBElement<TableExternalDocType> createExchPTypeTableExternalDoc(TableExternalDocType value) {
        return new JAXBElement<TableExternalDocType>(_PTypeTableExternalDoc_QNAME, TableExternalDocType.class, ExchPType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "region", scope = OfficeOfFilingType.class)
    public JAXBElement<RegionType> createOfficeOfFilingTypeRegion(RegionType value) {
        return new JAXBElement<RegionType>(_OfficeOfFilingTypeRegion_QNAME, RegionType.class, OfficeOfFilingType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CountryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country", scope = OfficeOfFilingType.class)
    public JAXBElement<CountryType> createOfficeOfFilingTypeCountry(CountryType value) {
        return new JAXBElement<CountryType>(_OfficeOfFilingTypeCountry_QNAME, CountryType.class, OfficeOfFilingType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = AuthorizedOfficerType.class)
    public JAXBElement<NameType> createAuthorizedOfficerTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = AuthorizedOfficerType.class)
    public JAXBElement<PrefixType> createAuthorizedOfficerTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = AuthorizedOfficerType.class)
    public JAXBElement<LastNameType> createAuthorizedOfficerTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = AuthorizedOfficerType.class)
    public JAXBElement<OrgnameType> createAuthorizedOfficerTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = AuthorizedOfficerType.class)
    public JAXBElement<FirstNameType> createAuthorizedOfficerTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = AuthorizedOfficerType.class)
    public JAXBElement<MiddleNameType> createAuthorizedOfficerTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = AuthorizedOfficerType.class)
    public JAXBElement<SuffixType> createAuthorizedOfficerTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = AuthorizedOfficerType.class)
    public JAXBElement<IidType> createAuthorizedOfficerTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = AuthorizedOfficerType.class)
    public JAXBElement<RoleType> createAuthorizedOfficerTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = AuthorizedOfficerType.class)
    public JAXBElement<DepartmentType> createAuthorizedOfficerTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = AuthorizedOfficerType.class)
    public JAXBElement<SynonymType> createAuthorizedOfficerTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = AuthorizedOfficerType.class)
    public JAXBElement<RegisteredNumberType> createAuthorizedOfficerTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PhoneType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "phone", scope = AuthorizedOfficerType.class)
    public JAXBElement<PhoneType> createAuthorizedOfficerTypePhone(PhoneType value) {
        return new JAXBElement<PhoneType>(_AuthorizedOfficerTypePhone_QNAME, PhoneType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fax", scope = AuthorizedOfficerType.class)
    public JAXBElement<FaxType> createAuthorizedOfficerTypeFax(FaxType value) {
        return new JAXBElement<FaxType>(_AuthorizedOfficerTypeFax_QNAME, FaxType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "email", scope = AuthorizedOfficerType.class)
    public JAXBElement<EmailType> createAuthorizedOfficerTypeEmail(EmailType value) {
        return new JAXBElement<EmailType>(_AuthorizedOfficerTypeEmail_QNAME, EmailType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "electronic-signature", scope = AuthorizedOfficerType.class)
    public JAXBElement<ElectronicSignatureType> createAuthorizedOfficerTypeElectronicSignature(ElectronicSignatureType value) {
        return new JAXBElement<ElectronicSignatureType>(_AuthorizedOfficerTypeElectronicSignature_QNAME, ElectronicSignatureType.class, AuthorizedOfficerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = PrimaryExaminerType.class)
    public JAXBElement<NameType> createPrimaryExaminerTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = PrimaryExaminerType.class)
    public JAXBElement<PrefixType> createPrimaryExaminerTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = PrimaryExaminerType.class)
    public JAXBElement<LastNameType> createPrimaryExaminerTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = PrimaryExaminerType.class)
    public JAXBElement<OrgnameType> createPrimaryExaminerTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = PrimaryExaminerType.class)
    public JAXBElement<FirstNameType> createPrimaryExaminerTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = PrimaryExaminerType.class)
    public JAXBElement<MiddleNameType> createPrimaryExaminerTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = PrimaryExaminerType.class)
    public JAXBElement<SuffixType> createPrimaryExaminerTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = PrimaryExaminerType.class)
    public JAXBElement<IidType> createPrimaryExaminerTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = PrimaryExaminerType.class)
    public JAXBElement<RoleType> createPrimaryExaminerTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = PrimaryExaminerType.class)
    public JAXBElement<DepartmentType> createPrimaryExaminerTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = PrimaryExaminerType.class)
    public JAXBElement<SynonymType> createPrimaryExaminerTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = PrimaryExaminerType.class)
    public JAXBElement<RegisteredNumberType> createPrimaryExaminerTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "electronic-signature", scope = PrimaryExaminerType.class)
    public JAXBElement<ElectronicSignatureType> createPrimaryExaminerTypeElectronicSignature(ElectronicSignatureType value) {
        return new JAXBElement<ElectronicSignatureType>(_AuthorizedOfficerTypeElectronicSignature_QNAME, ElectronicSignatureType.class, PrimaryExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = AssistantExaminerType.class)
    public JAXBElement<NameType> createAssistantExaminerTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = AssistantExaminerType.class)
    public JAXBElement<PrefixType> createAssistantExaminerTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = AssistantExaminerType.class)
    public JAXBElement<LastNameType> createAssistantExaminerTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = AssistantExaminerType.class)
    public JAXBElement<OrgnameType> createAssistantExaminerTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = AssistantExaminerType.class)
    public JAXBElement<FirstNameType> createAssistantExaminerTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = AssistantExaminerType.class)
    public JAXBElement<MiddleNameType> createAssistantExaminerTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = AssistantExaminerType.class)
    public JAXBElement<SuffixType> createAssistantExaminerTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = AssistantExaminerType.class)
    public JAXBElement<IidType> createAssistantExaminerTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = AssistantExaminerType.class)
    public JAXBElement<RoleType> createAssistantExaminerTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = AssistantExaminerType.class)
    public JAXBElement<DepartmentType> createAssistantExaminerTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = AssistantExaminerType.class)
    public JAXBElement<SynonymType> createAssistantExaminerTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = AssistantExaminerType.class)
    public JAXBElement<RegisteredNumberType> createAssistantExaminerTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ElectronicSignatureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "electronic-signature", scope = AssistantExaminerType.class)
    public JAXBElement<ElectronicSignatureType> createAssistantExaminerTypeElectronicSignature(ElectronicSignatureType value) {
        return new JAXBElement<ElectronicSignatureType>(_AuthorizedOfficerTypeElectronicSignature_QNAME, ElectronicSignatureType.class, AssistantExaminerType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = UType.class)
    public JAXBElement<BType> createUTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = UType.class)
    public JAXBElement<IType> createUTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = UType.class)
    public JAXBElement<OType> createUTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = UType.class)
    public JAXBElement<SupType> createUTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = UType.class)
    public JAXBElement<SubType> createUTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = UType.class)
    public JAXBElement<SmallcapsType> createUTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, UType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = OType.class)
    public JAXBElement<BType> createOTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, OType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = OType.class)
    public JAXBElement<IType> createOTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, OType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = OType.class)
    public JAXBElement<SubType> createOTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, OType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = OType.class)
    public JAXBElement<SupType> createOTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, OType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = OType.class)
    public JAXBElement<SmallcapsType> createOTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, OType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = DtType.class)
    public JAXBElement<BType> createDtTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = DtType.class)
    public JAXBElement<IType> createDtTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = DtType.class)
    public JAXBElement<UType> createDtTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = DtType.class)
    public JAXBElement<OType> createDtTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = DtType.class)
    public JAXBElement<SupType> createDtTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = DtType.class)
    public JAXBElement<SubType> createDtTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = DtType.class)
    public JAXBElement<SmallcapsType> createDtTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, DtType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = AddressbookType.class)
    public JAXBElement<NameType> createAddressbookTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = AddressbookType.class)
    public JAXBElement<PrefixType> createAddressbookTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = AddressbookType.class)
    public JAXBElement<LastNameType> createAddressbookTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = AddressbookType.class)
    public JAXBElement<OrgnameType> createAddressbookTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = AddressbookType.class)
    public JAXBElement<FirstNameType> createAddressbookTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = AddressbookType.class)
    public JAXBElement<MiddleNameType> createAddressbookTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = AddressbookType.class)
    public JAXBElement<SuffixType> createAddressbookTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = AddressbookType.class)
    public JAXBElement<IidType> createAddressbookTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = AddressbookType.class)
    public JAXBElement<RoleType> createAddressbookTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = AddressbookType.class)
    public JAXBElement<DepartmentType> createAddressbookTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = AddressbookType.class)
    public JAXBElement<SynonymType> createAddressbookTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = AddressbookType.class)
    public JAXBElement<RegisteredNumberType> createAddressbookTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address", scope = AddressbookType.class)
    public JAXBElement<AddressType> createAddressbookTypeAddress(AddressType value) {
        return new JAXBElement<AddressType>(_ConfplaceTypeAddress_QNAME, AddressType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PhoneType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "phone", scope = AddressbookType.class)
    public JAXBElement<PhoneType> createAddressbookTypePhone(PhoneType value) {
        return new JAXBElement<PhoneType>(_AuthorizedOfficerTypePhone_QNAME, PhoneType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaxType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fax", scope = AddressbookType.class)
    public JAXBElement<FaxType> createAddressbookTypeFax(FaxType value) {
        return new JAXBElement<FaxType>(_AuthorizedOfficerTypeFax_QNAME, FaxType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmailType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "email", scope = AddressbookType.class)
    public JAXBElement<EmailType> createAddressbookTypeEmail(EmailType value) {
        return new JAXBElement<EmailType>(_AuthorizedOfficerTypeEmail_QNAME, EmailType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UrlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "url", scope = AddressbookType.class)
    public JAXBElement<UrlType> createAddressbookTypeUrl(UrlType value) {
        return new JAXBElement<UrlType>(_AddressbookTypeUrl_QNAME, UrlType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EadType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ead", scope = AddressbookType.class)
    public JAXBElement<EadType> createAddressbookTypeEad(EadType value) {
        return new JAXBElement<EadType>(_AddressbookTypeEad_QNAME, EadType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dtext", scope = AddressbookType.class)
    public JAXBElement<DtextType> createAddressbookTypeDtext(DtextType value) {
        return new JAXBElement<DtextType>(_AddressbookTypeDtext_QNAME, DtextType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "text", scope = AddressbookType.class)
    public JAXBElement<TextType> createAddressbookTypeText(TextType value) {
        return new JAXBElement<TextType>(_AddressbookTypeText_QNAME, TextType.class, AddressbookType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = AuthorType.class)
    public JAXBElement<NameType> createAuthorTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = AuthorType.class)
    public JAXBElement<PrefixType> createAuthorTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = AuthorType.class)
    public JAXBElement<LastNameType> createAuthorTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = AuthorType.class)
    public JAXBElement<OrgnameType> createAuthorTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = AuthorType.class)
    public JAXBElement<FirstNameType> createAuthorTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = AuthorType.class)
    public JAXBElement<MiddleNameType> createAuthorTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = AuthorType.class)
    public JAXBElement<SuffixType> createAuthorTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = AuthorType.class)
    public JAXBElement<IidType> createAuthorTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = AuthorType.class)
    public JAXBElement<RoleType> createAuthorTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = AuthorType.class)
    public JAXBElement<DepartmentType> createAuthorTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = AuthorType.class)
    public JAXBElement<SynonymType> createAuthorTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = AuthorType.class)
    public JAXBElement<RegisteredNumberType> createAuthorTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressbookType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressbook", scope = AuthorType.class)
    public JAXBElement<AddressbookType> createAuthorTypeAddressbook(AddressbookType value) {
        return new JAXBElement<AddressbookType>(_ConfsponsorTypeAddressbook_QNAME, AddressbookType.class, AuthorType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = SubnameType.class)
    public JAXBElement<NameType> createSubnameTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = SubnameType.class)
    public JAXBElement<PrefixType> createSubnameTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = SubnameType.class)
    public JAXBElement<LastNameType> createSubnameTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = SubnameType.class)
    public JAXBElement<OrgnameType> createSubnameTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = SubnameType.class)
    public JAXBElement<FirstNameType> createSubnameTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = SubnameType.class)
    public JAXBElement<MiddleNameType> createSubnameTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = SubnameType.class)
    public JAXBElement<SuffixType> createSubnameTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = SubnameType.class)
    public JAXBElement<IidType> createSubnameTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = SubnameType.class)
    public JAXBElement<RoleType> createSubnameTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = SubnameType.class)
    public JAXBElement<DepartmentType> createSubnameTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = SubnameType.class)
    public JAXBElement<SynonymType> createSubnameTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = SubnameType.class)
    public JAXBElement<RegisteredNumberType> createSubnameTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressbookType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressbook", scope = SubnameType.class)
    public JAXBElement<AddressbookType> createSubnameTypeAddressbook(AddressbookType value) {
        return new JAXBElement<AddressbookType>(_ConfsponsorTypeAddressbook_QNAME, AddressbookType.class, SubnameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = CrossrefType.class)
    public JAXBElement<BType> createCrossrefTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = CrossrefType.class)
    public JAXBElement<IType> createCrossrefTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = CrossrefType.class)
    public JAXBElement<UType> createCrossrefTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = CrossrefType.class)
    public JAXBElement<OType> createCrossrefTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = CrossrefType.class)
    public JAXBElement<SupType> createCrossrefTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = CrossrefType.class)
    public JAXBElement<SubType> createCrossrefTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = CrossrefType.class)
    public JAXBElement<SmallcapsType> createCrossrefTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, CrossrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = FigrefType.class)
    public JAXBElement<BType> createFigrefTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = FigrefType.class)
    public JAXBElement<IType> createFigrefTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = FigrefType.class)
    public JAXBElement<UType> createFigrefTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = FigrefType.class)
    public JAXBElement<OType> createFigrefTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = FigrefType.class)
    public JAXBElement<SupType> createFigrefTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = FigrefType.class)
    public JAXBElement<SubType> createFigrefTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = FigrefType.class)
    public JAXBElement<SmallcapsType> createFigrefTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, FigrefType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = ChemistryType.class)
    public JAXBElement<ImgType> createChemistryTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, ChemistryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chem", scope = ChemistryType.class)
    public JAXBElement<ChemType> createChemistryTypeChem(ChemType value) {
        return new JAXBElement<ChemType>(_ChemistryTypeChem_QNAME, ChemType.class, ChemistryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = CnType.class)
    public JAXBElement<MglyphType> createCnTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SepType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sep", scope = CnType.class)
    public JAXBElement<SepType> createCnTypeSep(SepType value) {
        return new JAXBElement<SepType>(_CnTypeSep_QNAME, SepType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mi", scope = CnType.class)
    public JAXBElement<MiType> createCnTypeMi(MiType value) {
        return new JAXBElement<MiType>(_CnTypeMi_QNAME, MiType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mn", scope = CnType.class)
    public JAXBElement<MnType> createCnTypeMn(MnType value) {
        return new JAXBElement<MnType>(_CnTypeMn_QNAME, MnType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mo", scope = CnType.class)
    public JAXBElement<MoType> createCnTypeMo(MoType value) {
        return new JAXBElement<MoType>(_CnTypeMo_QNAME, MoType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtext", scope = CnType.class)
    public JAXBElement<MtextType> createCnTypeMtext(MtextType value) {
        return new JAXBElement<MtextType>(_CnTypeMtext_QNAME, MtextType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ms", scope = CnType.class)
    public JAXBElement<MsType> createCnTypeMs(MsType value) {
        return new JAXBElement<MsType>(_CnTypeMs_QNAME, MsType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MspaceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mspace", scope = CnType.class)
    public JAXBElement<MspaceType> createCnTypeMspace(MspaceType value) {
        return new JAXBElement<MspaceType>(_CnTypeMspace_QNAME, MspaceType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mrow", scope = CnType.class)
    public JAXBElement<MrowType> createCnTypeMrow(MrowType value) {
        return new JAXBElement<MrowType>(_CnTypeMrow_QNAME, MrowType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfracType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfrac", scope = CnType.class)
    public JAXBElement<MfracType> createCnTypeMfrac(MfracType value) {
        return new JAXBElement<MfracType>(_CnTypeMfrac_QNAME, MfracType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsqrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msqrt", scope = CnType.class)
    public JAXBElement<MsqrtType> createCnTypeMsqrt(MsqrtType value) {
        return new JAXBElement<MsqrtType>(_CnTypeMsqrt_QNAME, MsqrtType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mroot", scope = CnType.class)
    public JAXBElement<MrootType> createCnTypeMroot(MrootType value) {
        return new JAXBElement<MrootType>(_CnTypeMroot_QNAME, MrootType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MencloseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "menclose", scope = CnType.class)
    public JAXBElement<MencloseType> createCnTypeMenclose(MencloseType value) {
        return new JAXBElement<MencloseType>(_CnTypeMenclose_QNAME, MencloseType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MstyleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mstyle", scope = CnType.class)
    public JAXBElement<MstyleType> createCnTypeMstyle(MstyleType value) {
        return new JAXBElement<MstyleType>(_CnTypeMstyle_QNAME, MstyleType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MerrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "merror", scope = CnType.class)
    public JAXBElement<MerrorType> createCnTypeMerror(MerrorType value) {
        return new JAXBElement<MerrorType>(_CnTypeMerror_QNAME, MerrorType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MpaddedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mpadded", scope = CnType.class)
    public JAXBElement<MpaddedType> createCnTypeMpadded(MpaddedType value) {
        return new JAXBElement<MpaddedType>(_CnTypeMpadded_QNAME, MpaddedType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MphantomType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mphantom", scope = CnType.class)
    public JAXBElement<MphantomType> createCnTypeMphantom(MphantomType value) {
        return new JAXBElement<MphantomType>(_CnTypeMphantom_QNAME, MphantomType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfencedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfenced", scope = CnType.class)
    public JAXBElement<MfencedType> createCnTypeMfenced(MfencedType value) {
        return new JAXBElement<MfencedType>(_CnTypeMfenced_QNAME, MfencedType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msub", scope = CnType.class)
    public JAXBElement<MsubType> createCnTypeMsub(MsubType value) {
        return new JAXBElement<MsubType>(_CnTypeMsub_QNAME, MsubType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msup", scope = CnType.class)
    public JAXBElement<MsupType> createCnTypeMsup(MsupType value) {
        return new JAXBElement<MsupType>(_CnTypeMsup_QNAME, MsupType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msubsup", scope = CnType.class)
    public JAXBElement<MsubsupType> createCnTypeMsubsup(MsubsupType value) {
        return new JAXBElement<MsubsupType>(_CnTypeMsubsup_QNAME, MsubsupType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munder", scope = CnType.class)
    public JAXBElement<MunderType> createCnTypeMunder(MunderType value) {
        return new JAXBElement<MunderType>(_CnTypeMunder_QNAME, MunderType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mover", scope = CnType.class)
    public JAXBElement<MoverType> createCnTypeMover(MoverType value) {
        return new JAXBElement<MoverType>(_CnTypeMover_QNAME, MoverType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munderover", scope = CnType.class)
    public JAXBElement<MunderoverType> createCnTypeMunderover(MunderoverType value) {
        return new JAXBElement<MunderoverType>(_CnTypeMunderover_QNAME, MunderoverType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MmultiscriptsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mmultiscripts", scope = CnType.class)
    public JAXBElement<MmultiscriptsType> createCnTypeMmultiscripts(MmultiscriptsType value) {
        return new JAXBElement<MmultiscriptsType>(_CnTypeMmultiscripts_QNAME, MmultiscriptsType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtable", scope = CnType.class)
    public JAXBElement<MtableType> createCnTypeMtable(MtableType value) {
        return new JAXBElement<MtableType>(_CnTypeMtable_QNAME, MtableType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtr", scope = CnType.class)
    public JAXBElement<MtrType> createCnTypeMtr(MtrType value) {
        return new JAXBElement<MtrType>(_CnTypeMtr_QNAME, MtrType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MlabeledtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mlabeledtr", scope = CnType.class)
    public JAXBElement<MlabeledtrType> createCnTypeMlabeledtr(MlabeledtrType value) {
        return new JAXBElement<MlabeledtrType>(_CnTypeMlabeledtr_QNAME, MlabeledtrType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtd", scope = CnType.class)
    public JAXBElement<MtdType> createCnTypeMtd(MtdType value) {
        return new JAXBElement<MtdType>(_CnTypeMtd_QNAME, MtdType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaligngroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maligngroup", scope = CnType.class)
    public JAXBElement<MaligngroupType> createCnTypeMaligngroup(MaligngroupType value) {
        return new JAXBElement<MaligngroupType>(_CnTypeMaligngroup_QNAME, MaligngroupType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = CnType.class)
    public JAXBElement<MalignmarkType> createCnTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MactionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maction", scope = CnType.class)
    public JAXBElement<MactionType> createCnTypeMaction(MactionType value) {
        return new JAXBElement<MactionType>(_CnTypeMaction_QNAME, MactionType.class, CnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = CsymbolType.class)
    public JAXBElement<MglyphType> createCsymbolTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mi", scope = CsymbolType.class)
    public JAXBElement<MiType> createCsymbolTypeMi(MiType value) {
        return new JAXBElement<MiType>(_CnTypeMi_QNAME, MiType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mn", scope = CsymbolType.class)
    public JAXBElement<MnType> createCsymbolTypeMn(MnType value) {
        return new JAXBElement<MnType>(_CnTypeMn_QNAME, MnType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mo", scope = CsymbolType.class)
    public JAXBElement<MoType> createCsymbolTypeMo(MoType value) {
        return new JAXBElement<MoType>(_CnTypeMo_QNAME, MoType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtext", scope = CsymbolType.class)
    public JAXBElement<MtextType> createCsymbolTypeMtext(MtextType value) {
        return new JAXBElement<MtextType>(_CnTypeMtext_QNAME, MtextType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ms", scope = CsymbolType.class)
    public JAXBElement<MsType> createCsymbolTypeMs(MsType value) {
        return new JAXBElement<MsType>(_CnTypeMs_QNAME, MsType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MspaceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mspace", scope = CsymbolType.class)
    public JAXBElement<MspaceType> createCsymbolTypeMspace(MspaceType value) {
        return new JAXBElement<MspaceType>(_CnTypeMspace_QNAME, MspaceType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mrow", scope = CsymbolType.class)
    public JAXBElement<MrowType> createCsymbolTypeMrow(MrowType value) {
        return new JAXBElement<MrowType>(_CnTypeMrow_QNAME, MrowType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfracType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfrac", scope = CsymbolType.class)
    public JAXBElement<MfracType> createCsymbolTypeMfrac(MfracType value) {
        return new JAXBElement<MfracType>(_CnTypeMfrac_QNAME, MfracType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsqrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msqrt", scope = CsymbolType.class)
    public JAXBElement<MsqrtType> createCsymbolTypeMsqrt(MsqrtType value) {
        return new JAXBElement<MsqrtType>(_CnTypeMsqrt_QNAME, MsqrtType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mroot", scope = CsymbolType.class)
    public JAXBElement<MrootType> createCsymbolTypeMroot(MrootType value) {
        return new JAXBElement<MrootType>(_CnTypeMroot_QNAME, MrootType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MencloseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "menclose", scope = CsymbolType.class)
    public JAXBElement<MencloseType> createCsymbolTypeMenclose(MencloseType value) {
        return new JAXBElement<MencloseType>(_CnTypeMenclose_QNAME, MencloseType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MstyleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mstyle", scope = CsymbolType.class)
    public JAXBElement<MstyleType> createCsymbolTypeMstyle(MstyleType value) {
        return new JAXBElement<MstyleType>(_CnTypeMstyle_QNAME, MstyleType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MerrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "merror", scope = CsymbolType.class)
    public JAXBElement<MerrorType> createCsymbolTypeMerror(MerrorType value) {
        return new JAXBElement<MerrorType>(_CnTypeMerror_QNAME, MerrorType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MpaddedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mpadded", scope = CsymbolType.class)
    public JAXBElement<MpaddedType> createCsymbolTypeMpadded(MpaddedType value) {
        return new JAXBElement<MpaddedType>(_CnTypeMpadded_QNAME, MpaddedType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MphantomType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mphantom", scope = CsymbolType.class)
    public JAXBElement<MphantomType> createCsymbolTypeMphantom(MphantomType value) {
        return new JAXBElement<MphantomType>(_CnTypeMphantom_QNAME, MphantomType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfencedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfenced", scope = CsymbolType.class)
    public JAXBElement<MfencedType> createCsymbolTypeMfenced(MfencedType value) {
        return new JAXBElement<MfencedType>(_CnTypeMfenced_QNAME, MfencedType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msub", scope = CsymbolType.class)
    public JAXBElement<MsubType> createCsymbolTypeMsub(MsubType value) {
        return new JAXBElement<MsubType>(_CnTypeMsub_QNAME, MsubType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msup", scope = CsymbolType.class)
    public JAXBElement<MsupType> createCsymbolTypeMsup(MsupType value) {
        return new JAXBElement<MsupType>(_CnTypeMsup_QNAME, MsupType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msubsup", scope = CsymbolType.class)
    public JAXBElement<MsubsupType> createCsymbolTypeMsubsup(MsubsupType value) {
        return new JAXBElement<MsubsupType>(_CnTypeMsubsup_QNAME, MsubsupType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munder", scope = CsymbolType.class)
    public JAXBElement<MunderType> createCsymbolTypeMunder(MunderType value) {
        return new JAXBElement<MunderType>(_CnTypeMunder_QNAME, MunderType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mover", scope = CsymbolType.class)
    public JAXBElement<MoverType> createCsymbolTypeMover(MoverType value) {
        return new JAXBElement<MoverType>(_CnTypeMover_QNAME, MoverType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munderover", scope = CsymbolType.class)
    public JAXBElement<MunderoverType> createCsymbolTypeMunderover(MunderoverType value) {
        return new JAXBElement<MunderoverType>(_CnTypeMunderover_QNAME, MunderoverType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MmultiscriptsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mmultiscripts", scope = CsymbolType.class)
    public JAXBElement<MmultiscriptsType> createCsymbolTypeMmultiscripts(MmultiscriptsType value) {
        return new JAXBElement<MmultiscriptsType>(_CnTypeMmultiscripts_QNAME, MmultiscriptsType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtable", scope = CsymbolType.class)
    public JAXBElement<MtableType> createCsymbolTypeMtable(MtableType value) {
        return new JAXBElement<MtableType>(_CnTypeMtable_QNAME, MtableType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtr", scope = CsymbolType.class)
    public JAXBElement<MtrType> createCsymbolTypeMtr(MtrType value) {
        return new JAXBElement<MtrType>(_CnTypeMtr_QNAME, MtrType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MlabeledtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mlabeledtr", scope = CsymbolType.class)
    public JAXBElement<MlabeledtrType> createCsymbolTypeMlabeledtr(MlabeledtrType value) {
        return new JAXBElement<MlabeledtrType>(_CnTypeMlabeledtr_QNAME, MlabeledtrType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtd", scope = CsymbolType.class)
    public JAXBElement<MtdType> createCsymbolTypeMtd(MtdType value) {
        return new JAXBElement<MtdType>(_CnTypeMtd_QNAME, MtdType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaligngroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maligngroup", scope = CsymbolType.class)
    public JAXBElement<MaligngroupType> createCsymbolTypeMaligngroup(MaligngroupType value) {
        return new JAXBElement<MaligngroupType>(_CnTypeMaligngroup_QNAME, MaligngroupType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = CsymbolType.class)
    public JAXBElement<MalignmarkType> createCsymbolTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MactionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maction", scope = CsymbolType.class)
    public JAXBElement<MactionType> createCsymbolTypeMaction(MactionType value) {
        return new JAXBElement<MactionType>(_CnTypeMaction_QNAME, MactionType.class, CsymbolType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = CiType.class)
    public JAXBElement<MglyphType> createCiTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mi", scope = CiType.class)
    public JAXBElement<MiType> createCiTypeMi(MiType value) {
        return new JAXBElement<MiType>(_CnTypeMi_QNAME, MiType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MnType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mn", scope = CiType.class)
    public JAXBElement<MnType> createCiTypeMn(MnType value) {
        return new JAXBElement<MnType>(_CnTypeMn_QNAME, MnType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mo", scope = CiType.class)
    public JAXBElement<MoType> createCiTypeMo(MoType value) {
        return new JAXBElement<MoType>(_CnTypeMo_QNAME, MoType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtextType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtext", scope = CiType.class)
    public JAXBElement<MtextType> createCiTypeMtext(MtextType value) {
        return new JAXBElement<MtextType>(_CnTypeMtext_QNAME, MtextType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ms", scope = CiType.class)
    public JAXBElement<MsType> createCiTypeMs(MsType value) {
        return new JAXBElement<MsType>(_CnTypeMs_QNAME, MsType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MspaceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mspace", scope = CiType.class)
    public JAXBElement<MspaceType> createCiTypeMspace(MspaceType value) {
        return new JAXBElement<MspaceType>(_CnTypeMspace_QNAME, MspaceType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrowType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mrow", scope = CiType.class)
    public JAXBElement<MrowType> createCiTypeMrow(MrowType value) {
        return new JAXBElement<MrowType>(_CnTypeMrow_QNAME, MrowType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfracType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfrac", scope = CiType.class)
    public JAXBElement<MfracType> createCiTypeMfrac(MfracType value) {
        return new JAXBElement<MfracType>(_CnTypeMfrac_QNAME, MfracType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsqrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msqrt", scope = CiType.class)
    public JAXBElement<MsqrtType> createCiTypeMsqrt(MsqrtType value) {
        return new JAXBElement<MsqrtType>(_CnTypeMsqrt_QNAME, MsqrtType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MrootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mroot", scope = CiType.class)
    public JAXBElement<MrootType> createCiTypeMroot(MrootType value) {
        return new JAXBElement<MrootType>(_CnTypeMroot_QNAME, MrootType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MencloseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "menclose", scope = CiType.class)
    public JAXBElement<MencloseType> createCiTypeMenclose(MencloseType value) {
        return new JAXBElement<MencloseType>(_CnTypeMenclose_QNAME, MencloseType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MstyleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mstyle", scope = CiType.class)
    public JAXBElement<MstyleType> createCiTypeMstyle(MstyleType value) {
        return new JAXBElement<MstyleType>(_CnTypeMstyle_QNAME, MstyleType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MerrorType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "merror", scope = CiType.class)
    public JAXBElement<MerrorType> createCiTypeMerror(MerrorType value) {
        return new JAXBElement<MerrorType>(_CnTypeMerror_QNAME, MerrorType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MpaddedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mpadded", scope = CiType.class)
    public JAXBElement<MpaddedType> createCiTypeMpadded(MpaddedType value) {
        return new JAXBElement<MpaddedType>(_CnTypeMpadded_QNAME, MpaddedType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MphantomType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mphantom", scope = CiType.class)
    public JAXBElement<MphantomType> createCiTypeMphantom(MphantomType value) {
        return new JAXBElement<MphantomType>(_CnTypeMphantom_QNAME, MphantomType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MfencedType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfenced", scope = CiType.class)
    public JAXBElement<MfencedType> createCiTypeMfenced(MfencedType value) {
        return new JAXBElement<MfencedType>(_CnTypeMfenced_QNAME, MfencedType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msub", scope = CiType.class)
    public JAXBElement<MsubType> createCiTypeMsub(MsubType value) {
        return new JAXBElement<MsubType>(_CnTypeMsub_QNAME, MsubType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msup", scope = CiType.class)
    public JAXBElement<MsupType> createCiTypeMsup(MsupType value) {
        return new JAXBElement<MsupType>(_CnTypeMsup_QNAME, MsupType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MsubsupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msubsup", scope = CiType.class)
    public JAXBElement<MsubsupType> createCiTypeMsubsup(MsubsupType value) {
        return new JAXBElement<MsubsupType>(_CnTypeMsubsup_QNAME, MsubsupType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munder", scope = CiType.class)
    public JAXBElement<MunderType> createCiTypeMunder(MunderType value) {
        return new JAXBElement<MunderType>(_CnTypeMunder_QNAME, MunderType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mover", scope = CiType.class)
    public JAXBElement<MoverType> createCiTypeMover(MoverType value) {
        return new JAXBElement<MoverType>(_CnTypeMover_QNAME, MoverType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MunderoverType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munderover", scope = CiType.class)
    public JAXBElement<MunderoverType> createCiTypeMunderover(MunderoverType value) {
        return new JAXBElement<MunderoverType>(_CnTypeMunderover_QNAME, MunderoverType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MmultiscriptsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mmultiscripts", scope = CiType.class)
    public JAXBElement<MmultiscriptsType> createCiTypeMmultiscripts(MmultiscriptsType value) {
        return new JAXBElement<MmultiscriptsType>(_CnTypeMmultiscripts_QNAME, MmultiscriptsType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtableType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtable", scope = CiType.class)
    public JAXBElement<MtableType> createCiTypeMtable(MtableType value) {
        return new JAXBElement<MtableType>(_CnTypeMtable_QNAME, MtableType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtr", scope = CiType.class)
    public JAXBElement<MtrType> createCiTypeMtr(MtrType value) {
        return new JAXBElement<MtrType>(_CnTypeMtr_QNAME, MtrType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MlabeledtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mlabeledtr", scope = CiType.class)
    public JAXBElement<MlabeledtrType> createCiTypeMlabeledtr(MlabeledtrType value) {
        return new JAXBElement<MlabeledtrType>(_CnTypeMlabeledtr_QNAME, MlabeledtrType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MtdType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtd", scope = CiType.class)
    public JAXBElement<MtdType> createCiTypeMtd(MtdType value) {
        return new JAXBElement<MtdType>(_CnTypeMtd_QNAME, MtdType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MaligngroupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maligngroup", scope = CiType.class)
    public JAXBElement<MaligngroupType> createCiTypeMaligngroup(MaligngroupType value) {
        return new JAXBElement<MaligngroupType>(_CnTypeMaligngroup_QNAME, MaligngroupType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = CiType.class)
    public JAXBElement<MalignmarkType> createCiTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MactionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maction", scope = CiType.class)
    public JAXBElement<MactionType> createCiTypeMaction(MactionType value) {
        return new JAXBElement<MactionType>(_CnTypeMaction_QNAME, MactionType.class, CiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = MsType.class)
    public JAXBElement<MglyphType> createMsTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, MsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = MsType.class)
    public JAXBElement<MalignmarkType> createMsTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, MsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = MtextType.class)
    public JAXBElement<MglyphType> createMtextTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, MtextType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = MtextType.class)
    public JAXBElement<MalignmarkType> createMtextTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, MtextType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = MoType.class)
    public JAXBElement<MglyphType> createMoTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, MoType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = MoType.class)
    public JAXBElement<MalignmarkType> createMoTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, MoType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = MnType.class)
    public JAXBElement<MglyphType> createMnTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, MnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = MnType.class)
    public JAXBElement<MalignmarkType> createMnTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, MnType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MglyphType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph", scope = MiType.class)
    public JAXBElement<MglyphType> createMiTypeMglyph(MglyphType value) {
        return new JAXBElement<MglyphType>(_CnTypeMglyph_QNAME, MglyphType.class, MiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MalignmarkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark", scope = MiType.class)
    public JAXBElement<MalignmarkType> createMiTypeMalignmark(MalignmarkType value) {
        return new JAXBElement<MalignmarkType>(_CnTypeMalignmark_QNAME, MalignmarkType.class, MiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = MathsType.class)
    public JAXBElement<ImgType> createMathsTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, MathsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "math", scope = MathsType.class)
    public JAXBElement<MathType> createMathsTypeMath(MathType value) {
        return new JAXBElement<MathType>(_MathsTypeMath_QNAME, MathType.class, MathsType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = LiType.class)
    public JAXBElement<BType> createLiTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = LiType.class)
    public JAXBElement<IType> createLiTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = LiType.class)
    public JAXBElement<UType> createLiTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = LiType.class)
    public JAXBElement<OType> createLiTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = LiType.class)
    public JAXBElement<SupType> createLiTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = LiType.class)
    public JAXBElement<SubType> createLiTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = LiType.class)
    public JAXBElement<SmallcapsType> createLiTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br", scope = LiType.class)
    public JAXBElement<BrType> createLiTypeBr(BrType value) {
        return new JAXBElement<BrType>(_PTypeBr_QNAME, BrType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre", scope = LiType.class)
    public JAXBElement<PreType> createLiTypePre(PreType value) {
        return new JAXBElement<PreType>(_PTypePre_QNAME, PreType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit", scope = LiType.class)
    public JAXBElement<PatcitType> createLiTypePatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_PTypePatcit_QNAME, PatcitType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit", scope = LiType.class)
    public JAXBElement<NplcitType> createLiTypeNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_PTypeNplcit_QNAME, NplcitType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit", scope = LiType.class)
    public JAXBElement<BioDepositType> createLiTypeBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_PTypeBioDeposit_QNAME, BioDepositType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref", scope = LiType.class)
    public JAXBElement<CrossrefType> createLiTypeCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_PTypeCrossref_QNAME, CrossrefType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref", scope = LiType.class)
    public JAXBElement<FigrefType> createLiTypeFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_PTypeFigref_QNAME, FigrefType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = LiType.class)
    public JAXBElement<ImgType> createLiTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl", scope = LiType.class)
    public JAXBElement<DlType> createLiTypeDl(DlType value) {
        return new JAXBElement<DlType>(_PTypeDl_QNAME, DlType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul", scope = LiType.class)
    public JAXBElement<UlType> createLiTypeUl(UlType value) {
        return new JAXBElement<UlType>(_PTypeUl_QNAME, UlType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol", scope = LiType.class)
    public JAXBElement<OlType> createLiTypeOl(OlType value) {
        return new JAXBElement<OlType>(_PTypeOl_QNAME, OlType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry", scope = LiType.class)
    public JAXBElement<ChemistryType> createLiTypeChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_PTypeChemistry_QNAME, ChemistryType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths", scope = LiType.class)
    public JAXBElement<MathsType> createLiTypeMaths(MathsType value) {
        return new JAXBElement<MathsType>(_PTypeMaths_QNAME, MathsType.class, LiType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = EntryType.class)
    public JAXBElement<BType> createEntryTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = EntryType.class)
    public JAXBElement<IType> createEntryTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = EntryType.class)
    public JAXBElement<UType> createEntryTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o", scope = EntryType.class)
    public JAXBElement<OType> createEntryTypeO(OType value) {
        return new JAXBElement<OType>(_Sup2TypeO_QNAME, OType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = EntryType.class)
    public JAXBElement<SupType> createEntryTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = EntryType.class)
    public JAXBElement<SubType> createEntryTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = EntryType.class)
    public JAXBElement<SmallcapsType> createEntryTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br", scope = EntryType.class)
    public JAXBElement<BrType> createEntryTypeBr(BrType value) {
        return new JAXBElement<BrType>(_PTypeBr_QNAME, BrType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit", scope = EntryType.class)
    public JAXBElement<PatcitType> createEntryTypePatcit(PatcitType value) {
        return new JAXBElement<PatcitType>(_PTypePatcit_QNAME, PatcitType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NplcitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit", scope = EntryType.class)
    public JAXBElement<NplcitType> createEntryTypeNplcit(NplcitType value) {
        return new JAXBElement<NplcitType>(_PTypeNplcit_QNAME, NplcitType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDepositType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit", scope = EntryType.class)
    public JAXBElement<BioDepositType> createEntryTypeBioDeposit(BioDepositType value) {
        return new JAXBElement<BioDepositType>(_PTypeBioDeposit_QNAME, BioDepositType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CrossrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref", scope = EntryType.class)
    public JAXBElement<CrossrefType> createEntryTypeCrossref(CrossrefType value) {
        return new JAXBElement<CrossrefType>(_PTypeCrossref_QNAME, CrossrefType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FigrefType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref", scope = EntryType.class)
    public JAXBElement<FigrefType> createEntryTypeFigref(FigrefType value) {
        return new JAXBElement<FigrefType>(_PTypeFigref_QNAME, FigrefType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ImgType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img", scope = EntryType.class)
    public JAXBElement<ImgType> createEntryTypeImg(ImgType value) {
        return new JAXBElement<ImgType>(_PTypeImg_QNAME, ImgType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl", scope = EntryType.class)
    public JAXBElement<DlType> createEntryTypeDl(DlType value) {
        return new JAXBElement<DlType>(_PTypeDl_QNAME, DlType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul", scope = EntryType.class)
    public JAXBElement<UlType> createEntryTypeUl(UlType value) {
        return new JAXBElement<UlType>(_PTypeUl_QNAME, UlType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OlType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol", scope = EntryType.class)
    public JAXBElement<OlType> createEntryTypeOl(OlType value) {
        return new JAXBElement<OlType>(_PTypeOl_QNAME, OlType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ChemistryType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry", scope = EntryType.class)
    public JAXBElement<ChemistryType> createEntryTypeChemistry(ChemistryType value) {
        return new JAXBElement<ChemistryType>(_PTypeChemistry_QNAME, ChemistryType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MathsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths", scope = EntryType.class)
    public JAXBElement<MathsType> createEntryTypeMaths(MathsType value) {
        return new JAXBElement<MathsType>(_PTypeMaths_QNAME, MathsType.class, EntryType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = TitleType.class)
    public JAXBElement<BType> createTitleTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = TitleType.class)
    public JAXBElement<IType> createTitleTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = TitleType.class)
    public JAXBElement<UType> createTitleTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = TitleType.class)
    public JAXBElement<SupType> createTitleTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = TitleType.class)
    public JAXBElement<SubType> createTitleTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SmallcapsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps", scope = TitleType.class)
    public JAXBElement<SmallcapsType> createTitleTypeSmallcaps(SmallcapsType value) {
        return new JAXBElement<SmallcapsType>(_PTypeSmallcaps_QNAME, SmallcapsType.class, TitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b", scope = InventionTitleType.class)
    public JAXBElement<BType> createInventionTitleTypeB(BType value) {
        return new JAXBElement<BType>(_PTypeB_QNAME, BType.class, InventionTitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i", scope = InventionTitleType.class)
    public JAXBElement<IType> createInventionTitleTypeI(IType value) {
        return new JAXBElement<IType>(_PTypeI_QNAME, IType.class, InventionTitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u", scope = InventionTitleType.class)
    public JAXBElement<UType> createInventionTitleTypeU(UType value) {
        return new JAXBElement<UType>(_PTypeU_QNAME, UType.class, InventionTitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup", scope = InventionTitleType.class)
    public JAXBElement<SupType> createInventionTitleTypeSup(SupType value) {
        return new JAXBElement<SupType>(_PTypeSup_QNAME, SupType.class, InventionTitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub", scope = InventionTitleType.class)
    public JAXBElement<SubType> createInventionTitleTypeSub(SubType value) {
        return new JAXBElement<SubType>(_PTypeSub_QNAME, SubType.class, InventionTitleType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = ApplicantNameType.class)
    public JAXBElement<NameType> createApplicantNameTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = ApplicantNameType.class)
    public JAXBElement<PrefixType> createApplicantNameTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = ApplicantNameType.class)
    public JAXBElement<LastNameType> createApplicantNameTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = ApplicantNameType.class)
    public JAXBElement<OrgnameType> createApplicantNameTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = ApplicantNameType.class)
    public JAXBElement<FirstNameType> createApplicantNameTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = ApplicantNameType.class)
    public JAXBElement<MiddleNameType> createApplicantNameTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = ApplicantNameType.class)
    public JAXBElement<SuffixType> createApplicantNameTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = ApplicantNameType.class)
    public JAXBElement<IidType> createApplicantNameTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = ApplicantNameType.class)
    public JAXBElement<RoleType> createApplicantNameTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = ApplicantNameType.class)
    public JAXBElement<DepartmentType> createApplicantNameTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = ApplicantNameType.class)
    public JAXBElement<SynonymType> createApplicantNameTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = ApplicantNameType.class)
    public JAXBElement<RegisteredNumberType> createApplicantNameTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, ApplicantNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = InventorNameType.class)
    public JAXBElement<NameType> createInventorNameTypeName(NameType value) {
        return new JAXBElement<NameType>(_AuthorizedOfficerTypeName_QNAME, NameType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PrefixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix", scope = InventorNameType.class)
    public JAXBElement<PrefixType> createInventorNameTypePrefix(PrefixType value) {
        return new JAXBElement<PrefixType>(_AuthorizedOfficerTypePrefix_QNAME, PrefixType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name", scope = InventorNameType.class)
    public JAXBElement<LastNameType> createInventorNameTypeLastName(LastNameType value) {
        return new JAXBElement<LastNameType>(_AuthorizedOfficerTypeLastName_QNAME, LastNameType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrgnameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname", scope = InventorNameType.class)
    public JAXBElement<OrgnameType> createInventorNameTypeOrgname(OrgnameType value) {
        return new JAXBElement<OrgnameType>(_AuthorizedOfficerTypeOrgname_QNAME, OrgnameType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name", scope = InventorNameType.class)
    public JAXBElement<FirstNameType> createInventorNameTypeFirstName(FirstNameType value) {
        return new JAXBElement<FirstNameType>(_AuthorizedOfficerTypeFirstName_QNAME, FirstNameType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleNameType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name", scope = InventorNameType.class)
    public JAXBElement<MiddleNameType> createInventorNameTypeMiddleName(MiddleNameType value) {
        return new JAXBElement<MiddleNameType>(_AuthorizedOfficerTypeMiddleName_QNAME, MiddleNameType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuffixType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = InventorNameType.class)
    public JAXBElement<SuffixType> createInventorNameTypeSuffix(SuffixType value) {
        return new JAXBElement<SuffixType>(_AuthorizedOfficerTypeSuffix_QNAME, SuffixType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IidType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid", scope = InventorNameType.class)
    public JAXBElement<IidType> createInventorNameTypeIid(IidType value) {
        return new JAXBElement<IidType>(_AuthorizedOfficerTypeIid_QNAME, IidType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoleType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role", scope = InventorNameType.class)
    public JAXBElement<RoleType> createInventorNameTypeRole(RoleType value) {
        return new JAXBElement<RoleType>(_AuthorizedOfficerTypeRole_QNAME, RoleType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DepartmentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department", scope = InventorNameType.class)
    public JAXBElement<DepartmentType> createInventorNameTypeDepartment(DepartmentType value) {
        return new JAXBElement<DepartmentType>(_AuthorizedOfficerTypeDepartment_QNAME, DepartmentType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynonymType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym", scope = InventorNameType.class)
    public JAXBElement<SynonymType> createInventorNameTypeSynonym(SynonymType value) {
        return new JAXBElement<SynonymType>(_AuthorizedOfficerTypeSynonym_QNAME, SynonymType.class, InventorNameType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number", scope = InventorNameType.class)
    public JAXBElement<RegisteredNumberType> createInventorNameTypeRegisteredNumber(RegisteredNumberType value) {
        return new JAXBElement<RegisteredNumberType>(_AuthorizedOfficerTypeRegisteredNumber_QNAME, RegisteredNumberType.class, InventorNameType.class, value);
    }

}
