//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * IFD tag = 132; ST.30 tag = 151
 * 
 * <p>bibliographic-dataType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="bibliographic-dataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}publication-reference" maxOccurs="unbounded"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}previously-filed-app" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}preceding-publication-date" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}date-of-coming-into-force" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}extended-kind-code" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}classification-ipc" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}classifications-ipcr" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}classification-national" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}patent-classifications" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}application-reference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}language-of-filing" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}language-of-publication" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}priority-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}parties" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}designation-of-states" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}invention-title" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}dates-of-public-availability" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}st50-republication" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}references-cited" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}language" /&gt;
 *       &lt;attribute name="country" type="{http://www.epo.org/exchange}countryType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bibliographic-dataType", propOrder = {
    "publicationReference",
    "previouslyFiledApp",
    "precedingPublicationDate",
    "dateOfComingIntoForce",
    "extendedKindCode",
    "classificationIpc",
    "classificationsIpcr",
    "classificationNational",
    "patentClassifications",
    "applicationReference",
    "languageOfFiling",
    "languageOfPublication",
    "priorityClaims",
    "parties",
    "designationOfStates",
    "inventionTitle",
    "datesOfPublicAvailability",
    "st50Republication",
    "referencesCited"
})
public class BibliographicDataType {

    @XmlElement(name = "publication-reference", namespace = "http://www.epo.org/exchange", required = true)
    protected List<PublicationReferenceType> publicationReference;
    @XmlElement(name = "previously-filed-app", namespace = "http://www.epo.org/exchange")
    protected PreviouslyFiledAppType previouslyFiledApp;
    @XmlElement(name = "preceding-publication-date", namespace = "http://www.epo.org/exchange")
    protected PrecedingPublicationDateType precedingPublicationDate;
    @XmlElement(name = "date-of-coming-into-force", namespace = "http://www.epo.org/exchange")
    protected DateOfComingIntoForceType dateOfComingIntoForce;
    @XmlElement(name = "extended-kind-code", namespace = "http://www.epo.org/exchange")
    protected ExtendedKindCode extendedKindCode;
    @XmlElement(name = "classification-ipc", namespace = "http://www.epo.org/exchange")
    protected ClassificationIpcType classificationIpc;
    @XmlElement(name = "classifications-ipcr", namespace = "http://www.epo.org/exchange")
    protected ClassificationsIpcrType classificationsIpcr;
    @XmlElement(name = "classification-national", namespace = "http://www.epo.org/exchange")
    protected ClassificationNationalType classificationNational;
    @XmlElement(name = "patent-classifications", namespace = "http://www.epo.org/exchange")
    protected PatentClassificationsType patentClassifications;
    @XmlElement(name = "application-reference", namespace = "http://www.epo.org/exchange")
    protected List<ApplicationReferenceType> applicationReference;
    @XmlElement(name = "language-of-filing", namespace = "http://www.epo.org/exchange")
    protected LanguageOfFilingType languageOfFiling;
    @XmlElement(name = "language-of-publication", namespace = "http://www.epo.org/exchange")
    protected LanguageOfPublicationType languageOfPublication;
    @XmlElement(name = "priority-claims", namespace = "http://www.epo.org/exchange")
    protected PriorityClaimsType priorityClaims;
    @XmlElement(namespace = "http://www.epo.org/exchange")
    protected PartiesType parties;
    @XmlElement(name = "designation-of-states", namespace = "http://www.epo.org/exchange")
    protected DesignationOfStatesType designationOfStates;
    @XmlElement(name = "invention-title", namespace = "http://www.epo.org/exchange")
    protected List<InventionTitleType> inventionTitle;
    @XmlElement(name = "dates-of-public-availability", namespace = "http://www.epo.org/exchange")
    protected DatesOfPublicAvailability datesOfPublicAvailability;
    @XmlElement(name = "st50-republication", namespace = "http://www.epo.org/exchange")
    protected St50RepublicationType st50Republication;
    @XmlElement(name = "references-cited", namespace = "http://www.epo.org/exchange")
    protected List<ReferencesCitedType> referencesCited;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String lang;
    @XmlAttribute(name = "country")
    protected CountryType country;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * Gets the value of the publicationReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the publicationReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPublicationReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PublicationReferenceType }
     * 
     * 
     */
    public List<PublicationReferenceType> getPublicationReference() {
        if (publicationReference == null) {
            publicationReference = new ArrayList<PublicationReferenceType>();
        }
        return this.publicationReference;
    }

    /**
     * 取得 previouslyFiledApp 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PreviouslyFiledAppType }
     *     
     */
    public PreviouslyFiledAppType getPreviouslyFiledApp() {
        return previouslyFiledApp;
    }

    /**
     * 設定 previouslyFiledApp 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PreviouslyFiledAppType }
     *     
     */
    public void setPreviouslyFiledApp(PreviouslyFiledAppType value) {
        this.previouslyFiledApp = value;
    }

    /**
     * 取得 precedingPublicationDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PrecedingPublicationDateType }
     *     
     */
    public PrecedingPublicationDateType getPrecedingPublicationDate() {
        return precedingPublicationDate;
    }

    /**
     * 設定 precedingPublicationDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PrecedingPublicationDateType }
     *     
     */
    public void setPrecedingPublicationDate(PrecedingPublicationDateType value) {
        this.precedingPublicationDate = value;
    }

    /**
     * 取得 dateOfComingIntoForce 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DateOfComingIntoForceType }
     *     
     */
    public DateOfComingIntoForceType getDateOfComingIntoForce() {
        return dateOfComingIntoForce;
    }

    /**
     * 設定 dateOfComingIntoForce 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DateOfComingIntoForceType }
     *     
     */
    public void setDateOfComingIntoForce(DateOfComingIntoForceType value) {
        this.dateOfComingIntoForce = value;
    }

    /**
     * 取得 extendedKindCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExtendedKindCode }
     *     
     */
    public ExtendedKindCode getExtendedKindCode() {
        return extendedKindCode;
    }

    /**
     * 設定 extendedKindCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtendedKindCode }
     *     
     */
    public void setExtendedKindCode(ExtendedKindCode value) {
        this.extendedKindCode = value;
    }

    /**
     * 取得 classificationIpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpcType }
     *     
     */
    public ClassificationIpcType getClassificationIpc() {
        return classificationIpc;
    }

    /**
     * 設定 classificationIpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpcType }
     *     
     */
    public void setClassificationIpc(ClassificationIpcType value) {
        this.classificationIpc = value;
    }

    /**
     * 取得 classificationsIpcr 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsIpcrType }
     *     
     */
    public ClassificationsIpcrType getClassificationsIpcr() {
        return classificationsIpcr;
    }

    /**
     * 設定 classificationsIpcr 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsIpcrType }
     *     
     */
    public void setClassificationsIpcr(ClassificationsIpcrType value) {
        this.classificationsIpcr = value;
    }

    /**
     * 取得 classificationNational 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationNationalType }
     *     
     */
    public ClassificationNationalType getClassificationNational() {
        return classificationNational;
    }

    /**
     * 設定 classificationNational 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationNationalType }
     *     
     */
    public void setClassificationNational(ClassificationNationalType value) {
        this.classificationNational = value;
    }

    /**
     * 取得 patentClassifications 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentClassificationsType }
     *     
     */
    public PatentClassificationsType getPatentClassifications() {
        return patentClassifications;
    }

    /**
     * 設定 patentClassifications 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentClassificationsType }
     *     
     */
    public void setPatentClassifications(PatentClassificationsType value) {
        this.patentClassifications = value;
    }

    /**
     * Gets the value of the applicationReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the applicationReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplicationReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ApplicationReferenceType }
     * 
     * 
     */
    public List<ApplicationReferenceType> getApplicationReference() {
        if (applicationReference == null) {
            applicationReference = new ArrayList<ApplicationReferenceType>();
        }
        return this.applicationReference;
    }

    /**
     * 取得 languageOfFiling 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link LanguageOfFilingType }
     *     
     */
    public LanguageOfFilingType getLanguageOfFiling() {
        return languageOfFiling;
    }

    /**
     * 設定 languageOfFiling 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link LanguageOfFilingType }
     *     
     */
    public void setLanguageOfFiling(LanguageOfFilingType value) {
        this.languageOfFiling = value;
    }

    /**
     * 取得 languageOfPublication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link LanguageOfPublicationType }
     *     
     */
    public LanguageOfPublicationType getLanguageOfPublication() {
        return languageOfPublication;
    }

    /**
     * 設定 languageOfPublication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link LanguageOfPublicationType }
     *     
     */
    public void setLanguageOfPublication(LanguageOfPublicationType value) {
        this.languageOfPublication = value;
    }

    /**
     * 取得 priorityClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PriorityClaimsType }
     *     
     */
    public PriorityClaimsType getPriorityClaims() {
        return priorityClaims;
    }

    /**
     * 設定 priorityClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityClaimsType }
     *     
     */
    public void setPriorityClaims(PriorityClaimsType value) {
        this.priorityClaims = value;
    }

    /**
     * 取得 parties 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PartiesType }
     *     
     */
    public PartiesType getParties() {
        return parties;
    }

    /**
     * 設定 parties 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PartiesType }
     *     
     */
    public void setParties(PartiesType value) {
        this.parties = value;
    }

    /**
     * 取得 designationOfStates 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignationOfStatesType }
     *     
     */
    public DesignationOfStatesType getDesignationOfStates() {
        return designationOfStates;
    }

    /**
     * 設定 designationOfStates 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignationOfStatesType }
     *     
     */
    public void setDesignationOfStates(DesignationOfStatesType value) {
        this.designationOfStates = value;
    }

    /**
     * Gets the value of the inventionTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inventionTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInventionTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InventionTitleType }
     * 
     * 
     */
    public List<InventionTitleType> getInventionTitle() {
        if (inventionTitle == null) {
            inventionTitle = new ArrayList<InventionTitleType>();
        }
        return this.inventionTitle;
    }

    /**
     * 取得 datesOfPublicAvailability 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public DatesOfPublicAvailability getDatesOfPublicAvailability() {
        return datesOfPublicAvailability;
    }

    /**
     * 設定 datesOfPublicAvailability 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public void setDatesOfPublicAvailability(DatesOfPublicAvailability value) {
        this.datesOfPublicAvailability = value;
    }

    /**
     * 取得 st50Republication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link St50RepublicationType }
     *     
     */
    public St50RepublicationType getSt50Republication() {
        return st50Republication;
    }

    /**
     * 設定 st50Republication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link St50RepublicationType }
     *     
     */
    public void setSt50Republication(St50RepublicationType value) {
        this.st50Republication = value;
    }

    /**
     * Gets the value of the referencesCited property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the referencesCited property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReferencesCited().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferencesCitedType }
     * 
     * 
     */
    public List<ReferencesCitedType> getReferencesCited() {
        if (referencesCited == null) {
            referencesCited = new ArrayList<ReferencesCitedType>();
        }
        return this.referencesCited;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setCountry(CountryType value) {
        this.country = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
