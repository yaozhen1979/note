//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>addressType complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="addressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;element name="address-1" type="{http://www.epo.org/exchange}address-1Type" minOccurs="0"/&gt;
 *           &lt;element name="address-2" type="{http://www.epo.org/exchange}address-2Type" minOccurs="0"/&gt;
 *           &lt;element name="address-3" type="{http://www.epo.org/exchange}address-3Type" minOccurs="0"/&gt;
 *           &lt;element name="mailcode" type="{http://www.epo.org/exchange}mailcodeType" minOccurs="0"/&gt;
 *           &lt;element name="pobox" type="{http://www.epo.org/exchange}poboxType" minOccurs="0"/&gt;
 *           &lt;element name="room" type="{http://www.epo.org/exchange}roomType" minOccurs="0"/&gt;
 *           &lt;element name="address-floor" type="{http://www.epo.org/exchange}address-floorType" minOccurs="0"/&gt;
 *           &lt;element name="building" type="{http://www.epo.org/exchange}buildingType" minOccurs="0"/&gt;
 *           &lt;element name="street" type="{http://www.epo.org/exchange}streetType" minOccurs="0"/&gt;
 *           &lt;element name="city" type="{http://www.epo.org/exchange}cityType" minOccurs="0"/&gt;
 *           &lt;element name="county" type="{http://www.epo.org/exchange}countyType" minOccurs="0"/&gt;
 *           &lt;element name="state" type="{http://www.epo.org/exchange}stateType" minOccurs="0"/&gt;
 *           &lt;element name="postcode" type="{http://www.epo.org/exchange}postcodeType" minOccurs="0"/&gt;
 *           &lt;element name="country" type="{http://www.epo.org/exchange}countryType"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element name="text" type="{http://www.epo.org/exchange}textType"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addressType", propOrder = {
    "address1",
    "address2",
    "address3",
    "mailcode",
    "pobox",
    "room",
    "addressFloor",
    "building",
    "street",
    "city",
    "county",
    "state",
    "postcode",
    "country",
    "text"
})
public class AddressType {

    @XmlElement(name = "address-1")
    protected Address1Type address1;
    @XmlElement(name = "address-2")
    protected Address2Type address2;
    @XmlElement(name = "address-3")
    protected Address3Type address3;
    protected MailcodeType mailcode;
    protected PoboxType pobox;
    protected RoomType room;
    @XmlElement(name = "address-floor")
    protected AddressFloorType addressFloor;
    protected BuildingType building;
    protected StreetType street;
    protected CityType city;
    protected CountyType county;
    protected StateType state;
    protected PostcodeType postcode;
    @XmlSchemaType(name = "string")
    protected CountryType country;
    protected TextType text;

    /**
     * 取得 address1 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address1Type }
     *     
     */
    public Address1Type getAddress1() {
        return address1;
    }

    /**
     * 設定 address1 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address1Type }
     *     
     */
    public void setAddress1(Address1Type value) {
        this.address1 = value;
    }

    /**
     * 取得 address2 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address2Type }
     *     
     */
    public Address2Type getAddress2() {
        return address2;
    }

    /**
     * 設定 address2 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address2Type }
     *     
     */
    public void setAddress2(Address2Type value) {
        this.address2 = value;
    }

    /**
     * 取得 address3 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address3Type }
     *     
     */
    public Address3Type getAddress3() {
        return address3;
    }

    /**
     * 設定 address3 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address3Type }
     *     
     */
    public void setAddress3(Address3Type value) {
        this.address3 = value;
    }

    /**
     * 取得 mailcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MailcodeType }
     *     
     */
    public MailcodeType getMailcode() {
        return mailcode;
    }

    /**
     * 設定 mailcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MailcodeType }
     *     
     */
    public void setMailcode(MailcodeType value) {
        this.mailcode = value;
    }

    /**
     * 取得 pobox 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PoboxType }
     *     
     */
    public PoboxType getPobox() {
        return pobox;
    }

    /**
     * 設定 pobox 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PoboxType }
     *     
     */
    public void setPobox(PoboxType value) {
        this.pobox = value;
    }

    /**
     * 取得 room 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link RoomType }
     *     
     */
    public RoomType getRoom() {
        return room;
    }

    /**
     * 設定 room 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link RoomType }
     *     
     */
    public void setRoom(RoomType value) {
        this.room = value;
    }

    /**
     * 取得 addressFloor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AddressFloorType }
     *     
     */
    public AddressFloorType getAddressFloor() {
        return addressFloor;
    }

    /**
     * 設定 addressFloor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFloorType }
     *     
     */
    public void setAddressFloor(AddressFloorType value) {
        this.addressFloor = value;
    }

    /**
     * 取得 building 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BuildingType }
     *     
     */
    public BuildingType getBuilding() {
        return building;
    }

    /**
     * 設定 building 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BuildingType }
     *     
     */
    public void setBuilding(BuildingType value) {
        this.building = value;
    }

    /**
     * 取得 street 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link StreetType }
     *     
     */
    public StreetType getStreet() {
        return street;
    }

    /**
     * 設定 street 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link StreetType }
     *     
     */
    public void setStreet(StreetType value) {
        this.street = value;
    }

    /**
     * 取得 city 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CityType }
     *     
     */
    public CityType getCity() {
        return city;
    }

    /**
     * 設定 city 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CityType }
     *     
     */
    public void setCity(CityType value) {
        this.city = value;
    }

    /**
     * 取得 county 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountyType }
     *     
     */
    public CountyType getCounty() {
        return county;
    }

    /**
     * 設定 county 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountyType }
     *     
     */
    public void setCounty(CountyType value) {
        this.county = value;
    }

    /**
     * 取得 state 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link StateType }
     *     
     */
    public StateType getState() {
        return state;
    }

    /**
     * 設定 state 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link StateType }
     *     
     */
    public void setState(StateType value) {
        this.state = value;
    }

    /**
     * 取得 postcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PostcodeType }
     *     
     */
    public PostcodeType getPostcode() {
        return postcode;
    }

    /**
     * 設定 postcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PostcodeType }
     *     
     */
    public void setPostcode(PostcodeType value) {
        this.postcode = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryType }
     *     
     */
    public CountryType getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryType }
     *     
     */
    public void setCountry(CountryType value) {
        this.country = value;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setText(TextType value) {
        this.text = value;
    }

}
