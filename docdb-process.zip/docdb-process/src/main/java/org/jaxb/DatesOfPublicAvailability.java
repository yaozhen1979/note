//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.23 於 10:06:51 AM CST 
//


package org.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}gazette-reference" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}abstract-reference" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}supplemental-srep-pub" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}gazette-pub-announcement" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}modified-first-page-pub" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}modified-complete-spec-pub" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}unexamined-not-printed-without-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}examined-not-printed-without-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}unexamined-printed-without-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}examined-printed-without-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}printed-with-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}claims-only-available" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}not-printed-with-grant" minOccurs="0"/&gt;
 *         &lt;element name="term-of-grant" type="{http://www.epo.org/exchange}term-of-grantType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}invalidation-of-patent" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.epo.org/exchange}printed-as-amended" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "gazetteReference",
    "abstractReference",
    "supplementalSrepPub",
    "gazettePubAnnouncement",
    "modifiedFirstPagePub",
    "modifiedCompleteSpecPub",
    "unexaminedNotPrintedWithoutGrant",
    "examinedNotPrintedWithoutGrant",
    "unexaminedPrintedWithoutGrant",
    "examinedPrintedWithoutGrant",
    "printedWithGrant",
    "claimsOnlyAvailable",
    "notPrintedWithGrant",
    "termOfGrant",
    "invalidationOfPatent",
    "printedAsAmended"
})
@XmlRootElement(name = "dates-of-public-availability")
public class DatesOfPublicAvailability {

    @XmlElement(name = "gazette-reference", namespace = "http://www.epo.org/exchange")
    protected ExchangeGazetteReferenceType gazetteReference;
    @XmlElement(name = "abstract-reference", namespace = "http://www.epo.org/exchange")
    protected AbstractReferenceType abstractReference;
    @XmlElement(name = "supplemental-srep-pub", namespace = "http://www.epo.org/exchange")
    protected SupplementalSrepPub supplementalSrepPub;
    @XmlElement(name = "gazette-pub-announcement", namespace = "http://www.epo.org/exchange")
    protected GazettePubAnnouncement gazettePubAnnouncement;
    @XmlElement(name = "modified-first-page-pub", namespace = "http://www.epo.org/exchange")
    protected ModifiedFirstPagePubType modifiedFirstPagePub;
    @XmlElement(name = "modified-complete-spec-pub", namespace = "http://www.epo.org/exchange")
    protected ModifiedCompleteSpecPubType modifiedCompleteSpecPub;
    @XmlElement(name = "unexamined-not-printed-without-grant", namespace = "http://www.epo.org/exchange")
    protected UnexaminedNotPrintedWithoutGrantType unexaminedNotPrintedWithoutGrant;
    @XmlElement(name = "examined-not-printed-without-grant", namespace = "http://www.epo.org/exchange")
    protected ExaminedNotPrintedWithoutGrantType examinedNotPrintedWithoutGrant;
    @XmlElement(name = "unexamined-printed-without-grant", namespace = "http://www.epo.org/exchange")
    protected UnexaminedPrintedWithoutGrantType unexaminedPrintedWithoutGrant;
    @XmlElement(name = "examined-printed-without-grant", namespace = "http://www.epo.org/exchange")
    protected ExaminedPrintedWithoutGrantType examinedPrintedWithoutGrant;
    @XmlElement(name = "printed-with-grant", namespace = "http://www.epo.org/exchange")
    protected PrintedWithGrantType printedWithGrant;
    @XmlElement(name = "claims-only-available", namespace = "http://www.epo.org/exchange")
    protected ClaimsOnlyAvailableType claimsOnlyAvailable;
    @XmlElement(name = "not-printed-with-grant", namespace = "http://www.epo.org/exchange")
    protected NotPrintedWithGrantType notPrintedWithGrant;
    @XmlElement(name = "term-of-grant")
    protected TermOfGrantType termOfGrant;
    @XmlElement(name = "invalidation-of-patent", namespace = "http://www.epo.org/exchange")
    protected InvalidationOfPatentType invalidationOfPatent;
    @XmlElement(name = "printed-as-amended", namespace = "http://www.epo.org/exchange")
    protected PrintedAsAmendedType printedAsAmended;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * 取得 gazetteReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExchangeGazetteReferenceType }
     *     
     */
    public ExchangeGazetteReferenceType getGazetteReference() {
        return gazetteReference;
    }

    /**
     * 設定 gazetteReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExchangeGazetteReferenceType }
     *     
     */
    public void setGazetteReference(ExchangeGazetteReferenceType value) {
        this.gazetteReference = value;
    }

    /**
     * 取得 abstractReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbstractReferenceType }
     *     
     */
    public AbstractReferenceType getAbstractReference() {
        return abstractReference;
    }

    /**
     * 設定 abstractReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbstractReferenceType }
     *     
     */
    public void setAbstractReference(AbstractReferenceType value) {
        this.abstractReference = value;
    }

    /**
     * 取得 supplementalSrepPub 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SupplementalSrepPub }
     *     
     */
    public SupplementalSrepPub getSupplementalSrepPub() {
        return supplementalSrepPub;
    }

    /**
     * 設定 supplementalSrepPub 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SupplementalSrepPub }
     *     
     */
    public void setSupplementalSrepPub(SupplementalSrepPub value) {
        this.supplementalSrepPub = value;
    }

    /**
     * 取得 gazettePubAnnouncement 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link GazettePubAnnouncement }
     *     
     */
    public GazettePubAnnouncement getGazettePubAnnouncement() {
        return gazettePubAnnouncement;
    }

    /**
     * 設定 gazettePubAnnouncement 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link GazettePubAnnouncement }
     *     
     */
    public void setGazettePubAnnouncement(GazettePubAnnouncement value) {
        this.gazettePubAnnouncement = value;
    }

    /**
     * 取得 modifiedFirstPagePub 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ModifiedFirstPagePubType }
     *     
     */
    public ModifiedFirstPagePubType getModifiedFirstPagePub() {
        return modifiedFirstPagePub;
    }

    /**
     * 設定 modifiedFirstPagePub 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ModifiedFirstPagePubType }
     *     
     */
    public void setModifiedFirstPagePub(ModifiedFirstPagePubType value) {
        this.modifiedFirstPagePub = value;
    }

    /**
     * 取得 modifiedCompleteSpecPub 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ModifiedCompleteSpecPubType }
     *     
     */
    public ModifiedCompleteSpecPubType getModifiedCompleteSpecPub() {
        return modifiedCompleteSpecPub;
    }

    /**
     * 設定 modifiedCompleteSpecPub 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ModifiedCompleteSpecPubType }
     *     
     */
    public void setModifiedCompleteSpecPub(ModifiedCompleteSpecPubType value) {
        this.modifiedCompleteSpecPub = value;
    }

    /**
     * 取得 unexaminedNotPrintedWithoutGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link UnexaminedNotPrintedWithoutGrantType }
     *     
     */
    public UnexaminedNotPrintedWithoutGrantType getUnexaminedNotPrintedWithoutGrant() {
        return unexaminedNotPrintedWithoutGrant;
    }

    /**
     * 設定 unexaminedNotPrintedWithoutGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link UnexaminedNotPrintedWithoutGrantType }
     *     
     */
    public void setUnexaminedNotPrintedWithoutGrant(UnexaminedNotPrintedWithoutGrantType value) {
        this.unexaminedNotPrintedWithoutGrant = value;
    }

    /**
     * 取得 examinedNotPrintedWithoutGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExaminedNotPrintedWithoutGrantType }
     *     
     */
    public ExaminedNotPrintedWithoutGrantType getExaminedNotPrintedWithoutGrant() {
        return examinedNotPrintedWithoutGrant;
    }

    /**
     * 設定 examinedNotPrintedWithoutGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExaminedNotPrintedWithoutGrantType }
     *     
     */
    public void setExaminedNotPrintedWithoutGrant(ExaminedNotPrintedWithoutGrantType value) {
        this.examinedNotPrintedWithoutGrant = value;
    }

    /**
     * 取得 unexaminedPrintedWithoutGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link UnexaminedPrintedWithoutGrantType }
     *     
     */
    public UnexaminedPrintedWithoutGrantType getUnexaminedPrintedWithoutGrant() {
        return unexaminedPrintedWithoutGrant;
    }

    /**
     * 設定 unexaminedPrintedWithoutGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link UnexaminedPrintedWithoutGrantType }
     *     
     */
    public void setUnexaminedPrintedWithoutGrant(UnexaminedPrintedWithoutGrantType value) {
        this.unexaminedPrintedWithoutGrant = value;
    }

    /**
     * 取得 examinedPrintedWithoutGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExaminedPrintedWithoutGrantType }
     *     
     */
    public ExaminedPrintedWithoutGrantType getExaminedPrintedWithoutGrant() {
        return examinedPrintedWithoutGrant;
    }

    /**
     * 設定 examinedPrintedWithoutGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExaminedPrintedWithoutGrantType }
     *     
     */
    public void setExaminedPrintedWithoutGrant(ExaminedPrintedWithoutGrantType value) {
        this.examinedPrintedWithoutGrant = value;
    }

    /**
     * 取得 printedWithGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PrintedWithGrantType }
     *     
     */
    public PrintedWithGrantType getPrintedWithGrant() {
        return printedWithGrant;
    }

    /**
     * 設定 printedWithGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PrintedWithGrantType }
     *     
     */
    public void setPrintedWithGrant(PrintedWithGrantType value) {
        this.printedWithGrant = value;
    }

    /**
     * 取得 claimsOnlyAvailable 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClaimsOnlyAvailableType }
     *     
     */
    public ClaimsOnlyAvailableType getClaimsOnlyAvailable() {
        return claimsOnlyAvailable;
    }

    /**
     * 設定 claimsOnlyAvailable 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimsOnlyAvailableType }
     *     
     */
    public void setClaimsOnlyAvailable(ClaimsOnlyAvailableType value) {
        this.claimsOnlyAvailable = value;
    }

    /**
     * 取得 notPrintedWithGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NotPrintedWithGrantType }
     *     
     */
    public NotPrintedWithGrantType getNotPrintedWithGrant() {
        return notPrintedWithGrant;
    }

    /**
     * 設定 notPrintedWithGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NotPrintedWithGrantType }
     *     
     */
    public void setNotPrintedWithGrant(NotPrintedWithGrantType value) {
        this.notPrintedWithGrant = value;
    }

    /**
     * 取得 termOfGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TermOfGrantType }
     *     
     */
    public TermOfGrantType getTermOfGrant() {
        return termOfGrant;
    }

    /**
     * 設定 termOfGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TermOfGrantType }
     *     
     */
    public void setTermOfGrant(TermOfGrantType value) {
        this.termOfGrant = value;
    }

    /**
     * 取得 invalidationOfPatent 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InvalidationOfPatentType }
     *     
     */
    public InvalidationOfPatentType getInvalidationOfPatent() {
        return invalidationOfPatent;
    }

    /**
     * 設定 invalidationOfPatent 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InvalidationOfPatentType }
     *     
     */
    public void setInvalidationOfPatent(InvalidationOfPatentType value) {
        this.invalidationOfPatent = value;
    }

    /**
     * 取得 printedAsAmended 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PrintedAsAmendedType }
     *     
     */
    public PrintedAsAmendedType getPrintedAsAmended() {
        return printedAsAmended;
    }

    /**
     * 設定 printedAsAmended 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PrintedAsAmendedType }
     *     
     */
    public void setPrintedAsAmended(PrintedAsAmendedType value) {
        this.printedAsAmended = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
