1. 在DOCDB country = CZ的資料中, 有三筆資料. 其國家應為CS.
   marshall_id分別為
   * DOCDB-201511-003-CZ-0003.xml/303251503
   * DOCDB-201538-Amend-PubDate20150911AndBefore-CZ-0004.xml/303251503
   * DOCDB-201539-Amend-PubDate20150918AndBefore-CZ-0003.xml/303251503
   
   + 再加三筆
   * DOCDB-201511-003-CZ-0003.xml/303504657
   * DOCDB-201538-Amend-PubDate20150911AndBefore-CZ-0004.xml/303504657
   * DOCDB-201539-Amend-PubDate20150918AndBefore-CZ-0003.xml/303504657
   
   
   => 為確保資料處理正確, 先在country=CZ處理時, 先刪除這三筆資料, 待之後在驗證筆數再行加回其數量.
   2016-04-05 特此記錄. 
   
2. CS, CZ, SU 分不清 ???

CS12345

CS12345

CZ12345
   