1. 2015 back file => file total count = 718954
   DocdbRawDataCH => count = 717927
   ErrorDocdbRawData => country = 1027
   
   2015 Cr-Del file => 
   
   2015 Amend file =>