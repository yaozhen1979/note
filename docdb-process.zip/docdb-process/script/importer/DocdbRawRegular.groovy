import groovy.time.TimeCategory
import groovy.time.TimeDuration

import org.json.XML

// import utils.MongoUtil

import com.mongodb.BasicDBObject
import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.mongodb.util.JSON

def ln = System.getProperty('line.separator')

// def ccList = ["NI"]
// 
def ccList = [
    // "KR", "KZ", "LT", "LU", "LV", "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY" 
    // "NL", "NO", "NZ", "OA", "PA", "PE", "PH", "PL", "PT" , 
    // "RO", "RS", "RU", "SE", "SG", "SI", "SK", "SM", "SU", "SV" 
    "TH", "TJ", "TN", "TR", "TT", "TW", "UA", "US", "UY", "UZ", "VN", "WO", "YU",
    "ZA", "ZM", "ZW"
]

File file = new File('tmp/docdb_regular.txt')

// docdb lv1
def srcCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, "PatentRawDOCDB").getDb().getCollection("PatentRawDOCDB")
//
def tarDb = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, "PatentRegularDOCDB").getDb()

def timeCalculateClosure = { closure ->

    def timeStart = new Date()

    def msg = closure()

    def timeStop = new Date()

    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    def msg1 = msg + " spend time: " +  duration

    file << msg1 << ln

    println msg1
}

for (def cc : ccList) {
    
    timeCalculateClosure {
        //docdb raw regular by country
        def tarCol = tarDb.getCollection("PatentRegularDOCDB$cc")

        def queryMap = [:]
        queryMap << ['country' : cc]

        def total = srcCol.count(new BasicDBObject(queryMap))

        println "country $cc parsing...total source document counts: $total"
        file << "country $cc parsing...total source document counts: $total" << ln

        DBCursor srcCur = srcCol.find(new BasicDBObject(queryMap)).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        def cnt = 0

        while (srcCur.hasNext()) {

            println "country ${cc} process ${++cnt}/${total}"

            DBObject srcDoc = srcCur.next()

            def tarDoc = [:]

            tarDoc['data'] = (DBObject) JSON.parse(XML.toJSONObject(srcDoc.data.xml).toString(4));

            def srcId = ['_id':srcDoc._id]

            tarDoc['relRawdatas'] = [srcId]

            //		tarDoc['mongoSyncFlag'] = [['init' : Date.parse("yyyy/MM/dd", new Date().getDateString())]]
            tarDoc['mongoSyncFlag'] = [['init' : new Date()]]

            tarDoc['tagAndFile'] = [['file': 'DocdbRawRegular.groovy', 'tag' : 'v1.0.0']]

            //		println tarDoc

            def updateMap = ['$set' : ['regularFlag' : true]]

            tarCol.save(new BasicDBObject(tarDoc))

            srcCol.update(srcId, updateMap)

            //		println JsonOutput.prettyPrint(XML.toJSONObject(xml).toString(4))
        }

        def tarCnt = tarCol.count()
        println "country $cc parsing...total target document counts: $tarCnt"
        file << "country $cc parsing...total target document counts: $tarCnt" << ln

        def isMatch = tarCnt - total == 0 ? "finish!" : "- NOT Match!"

        return "country $cc parsing...$isMatch"

    }

    //if (cc == 'AM') break;
}

