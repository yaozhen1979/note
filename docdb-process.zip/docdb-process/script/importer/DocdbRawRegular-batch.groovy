import groovy.time.TimeCategory
import groovy.time.TimeDuration

import org.json.XML

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;
import com.mongodb.Bytes
import com.mongodb.DBCursor
import com.mongodb.DBObject
import com.mongodb.util.JSON

File file = new File('tmp/docdb_regular.txt')

def batchNumber = 1000

def ln = System.getProperty('line.separator')

def ccList = ["DK", "DO", "NI"]


// docdb lv1
def srcCol = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, "PatentRawDOCDB").getDb().getCollection("PatentRawDOCDB")
//
def tarDb = new MongoUtil("patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, "PatentRegularDOCDB").getDb()

def timeCalculateClosure = { closure ->

    def timeStart = new Date()

    def msg = closure()

    def timeStop = new Date()

    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    def msg1 = msg + " spend time: " +  duration

    println msg1

    file << msg1 << ln

}

for (def cc : ccList) {

    timeCalculateClosure {
        //docdb raw regular by country
        def tarCol = tarDb.getCollection("PatentRegularDOCDB$cc")

        BulkWriteOperation tarBulk = tarCol.initializeOrderedBulkOperation()
        BulkWriteOperation srcBulk = srcCol.initializeOrderedBulkOperation()

        def queryMap = [:]
        queryMap << ['country' : cc]

        def total = srcCol.count(new BasicDBObject(queryMap))

        println "country $cc parsing...total source document counts: $total"
        file << "country $cc parsing...total source document counts: $total" << ln

        DBCursor srcCur = srcCol.find(new BasicDBObject(queryMap)).addOption(Bytes.QUERYOPTION_NOTIMEOUT)

        def cnt = 0

        while (srcCur.hasNext()) {

            println "country ${cc} process ${++cnt}/${total}"

            DBObject srcDoc = srcCur.next()

            def tarDoc = [:]

            tarDoc['data'] = (DBObject) JSON.parse(XML.toJSONObject(srcDoc.data.xml).toString(4));

            def srcId = ['_id':srcDoc._id]

            tarDoc['relRawdatas'] = [srcId]

            //		tarDoc['mongoSyncFlag'] = [['init' : Date.parse("yyyy/MM/dd", new Date().getDateString())]]
            tarDoc['mongoSyncFlag'] = [['init' : new Date()]]

            tarDoc['tagAndFile'] = [['file': 'DocdbRawRegular.groovy', 'tag' : 'v1.0.0']]

            def updateMap = ['$set' : ['regularFlag' : true]]

            //batch operation
            srcBulk.find(new BasicDBObject(srcId)).update(new BasicDBObject(updateMap))

            tarBulk.insert(new BasicDBObject(tarDoc))

            if (cnt.mod(batchNumber) == 0) {

                println "batch insert ...."

                def srcResult = srcBulk.execute()

                def tarResult = tarBulk.execute()

                tarBulk = tarCol.initializeOrderedBulkOperation()
                srcBulk = srcCol.initializeOrderedBulkOperation()
            }

        }

        println "batch insert ...."
        tarBulk.execute()
        srcBulk.execute()

        def tarCnt = tarCol.count()
        println "country $cc parsing...total target document counts: $tarCnt"
        file << "country $cc parsing...total target document counts: $tarCnt" << ln

        def isMatch = tarCnt - total == 0 ? "finish!" : "- NOT Match!"

        return "country $cc parsing...$isMatch"

    }

}

