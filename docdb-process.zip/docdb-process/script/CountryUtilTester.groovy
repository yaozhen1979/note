import org.utils.CountryUtil

// println CountryUtil.getOtherCountryList().size()

assert CountryUtil.getOtherCountryList().size() == 95

println "test finished..."