import org.apache.commons.lang3.StringUtils

def test1 = "＂test test ＂xxx＂ test test＂"

def test2 = "“SYSTEM AND METHOD OF MANAGING THE EXECUTION OF APPLICATIONS AT A PORTABLE COMPUTING DEVICE AND A PORTABLE COMPUTING DEVICE DOCKING STATION ”"

println test2

test2 = StringUtils.removeStart(test2, "“")
test2 = StringUtils.removeEnd(test2, "”")

println test2

def unwrap(String str, String remove) {
    
    def removeStartStr = StringUtils.removeStart(str, remove)
    def removeEndStr = StringUtils.removeEnd(removeStartStr, remove)
    
    return removeEndStr
}

// println "finished..."