/** 
 *
 *@api{get}/oauth/token token
 *@apiVersion 0.1.1
 *@apiName Oauth
 *@apiGroup Oauth
 *
 *@apiParam {String} grant_type
 *@apiParam {String} username
 *@apiParam {String} password
 *@apiParam {String} client_id
 *@apiParam {String} client_secret
 *@apiParam {String} scope
 *
 *@apiSampleRequest /oauth/token
 *@apiSuccess{String}access_token 
 *@apiSuccess{String}token_type
 *@apiSuccess{String}refresh_token
 *@apiSuccess{String}expires_in
 *@apiSuccess{String}scope
 * 
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"grant_type":"password",
 *		"client_id":"restapp",
 *		"client_secret":"restapp",
 *		"username":"xxxxxxxx",
 *		"password":"yyyyyy",
 *		"scope":"client",
 *  }
 *  
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{
 *		"access_token":"df7a04d7-a115-4101-89b1-c8253eee4358",
 *		"token_type":"bearer",
 *		"refresh_token":"0c24b520-acef-47e6-8439-cf096db13e80",
 *		"expires_in":1289804,
 *		"scope":"client"
 *	} 
 */

/** 
 *
 *@api{get}/queryPatentList queryPatentList
 *@apiVersion 0.1.1
 *@apiName queryPatentList
 *@apiGroup Query
 *
 *@apiParam {String} access_token
 *@apiParam {String} query
 *@apiParam {Int} rows=20 It specify the maximum number of documents from the complete result set to return to the client for every request.
 *@apiParam {Int} start=0 It indicates the offset in the complete result set for the queries where the set of returned documents should begin.
 *@apiParam {String} sort="score.desc" score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc
 *@apiParam {String} country us,cn,ep,wo,jp,kr,tw.
 *@apiParam {String} type="1,2,3,4,5,6,9" 1:"發明"、Type 2:"新型"、Type 3:"設計"、Type 4:"Plant"(US)、Type 5:"Reissue"(US)、Type 6:"SIR"(US)、Type 9:"Others"
 *@apiParam {Boolean} docdb=False
 *@apiParam {String} state="1,2" 1:"公開"、2:"公告"
 *@apiParam {Boolean} stem=True
 *@apiParam {String} mode  BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2
 *@apiParam {String} fl="all" Any field, function, or transformer can be displayed with a different name in the output document
 *@apiParam {Boolean} litigation=True
 *@apiParam {Boolean} solrsyntax=True
 *
 *@apiSampleRequest /restful/query/1.1/queryPatentList
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{ 
 *		response: {
 *   		numFound: 254719, 
 *   		start: 0, 
 *   		maxScore: 1.3225307, 
 *			docs: [patentListInfo]
 *	},
 *	{
 *		responseHeader: responseHeader
 *	} 
 */

/** 
 *
 *@api{get}/findPatentInfo findPatentInfo
 *@apiVersion 0.1.1
 *@apiName findPatentInfo
 *@apiGroup Query
 *
 *@apiParam {String} access_token 
 *@apiParam {String} ptopid
 *@apiParam {String} sort="score.desc" score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc
 *@apiParam {String} mode  BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2
 *@apiParam {String} fl="all" Any field, function, or transformer can be displayed with a different name in the output document.
 *@apiParam {Boolean} litigation=True
 *
 *@apiSampleRequest /restful/query/1.1/findPatentInfo
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{ 
 *		response: {
 *   		numFound: 1, 
 *   		start: 0, 
 *   		maxScore: 16.984732, 
 *			docs: [patentListInfo]
 *	},
 *	{
 *		responseHeader: responseHeader
 *	} 
 */

/** 
 *
 *@api{get}/findPatentGroup findPatentGroup
 *@apiVersion 0.1.1
 *@apiName findPatentGroup
 *@apiGroup Query
 *
 *@apiParam {String} access_token
 *@apiParam {String} query
 *@apiParam {Int} rows=20 It specify the maximum number of documents from the complete result set to return to the client for every request.
 *@apiParam {Int} start=0 It indicates the offset in the complete result set for the queries where the set of returned documents should begin.
 *@apiParam {String} sort="score.desc" score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc
 *@apiParam {String} country us,cn,ep,wo,jp,kr,tw.
 *@apiParam {String} type="1,2,3,4,5,6,9" 1:"發明"、Type 2:"新型"、Type 3:"設計"、Type 4:"Plant"(US)、Type 5:"Reissue"(US)、Type 6:"SIR"(US)、Type 9:"Others"
 *@apiParam {Boolean} docdb=False
 *@apiParam {String} state="1,2" 1:"公開"、2:"公告"
 *@apiParam {Boolean} stem=True
 *@apiParam {String} group.field familyIdGroup、appNumberGroup
 *@apiParam {Int} group.limit=20
 *@apiParam {String} mode  BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2
 *@apiParam {String} fl="all" Any field, function, or transformer can be displayed with a different name in the output document.
 *@apiParam {Boolean} litigation=True
 *@apiParam {Boolean} solrsyntax=True
 *
 *@apiSampleRequest /restful/query/1.1/findPatentGroup
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{ 
 *		grouped: {
 *			familyIdGroup: [GroupInfo]
 *	},
 *	{
 *		responseHeader: responseHeader
 *	} 
 */

/** 
 *
 *@api{get}/findPatentFacet findPatentFacet
 *@apiVersion 0.1.1
 *@apiName findPatentFacet
 *@apiGroup Query
 *
 *@apiParam {String} access_token
 *@apiParam {String} query
 *@apiParam {Int} rows=20 It specify the maximum number of documents from the complete result set to return to the client for every request.
 *@apiParam {String} sort="score.desc" score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc
 *@apiParam {String} country us,cn,ep,wo,jp,kr,tw.
 *@apiParam {String} type="1,2,3,4,5,6,9" 1:"發明"、Type 2:"新型"、Type 3:"設計"、Type 4:"Plant"(US)、Type 5:"Reissue"(US)、Type 6:"SIR"(US)、Type 9:"Others"
 *@apiParam {Boolean} docdb=False
 *@apiParam {String} state="1,2" 1:"公開"、2:"公告"
 *@apiParam {Boolean} stem=True
 *@apiParam {Int} facet.offset=0
 *@apiParam {String} facet.field country,typeCode,kindcode,assigneesFacetname,inventorsFacetname,agentsFacetname,examinerMastersFacetname,uspcs,ipcsNormal,locs,cpcsNormal,fis,appYear,openYear,decisionYear,currentAssigneesFacetname,ipcsClass,ipcsSubClass,ipcsGroup,ipcsSubGroup,cpcsClass,cpcsSubClass,cpcsGroup,cpcsSubGroup,fis,fisClass,fisSubClass,fisGroup,fisSubGroup,docdbAssigneesFacetname
 *@apiParam {Int} facet.limit=20
 *@apiParam {String} mode  BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2
 *@apiParam {String} fl="all" Any field, function, or transformer can be displayed with a different name in the output document.
 *@apiParam {Boolean} litigation=True
 *@apiParam {Boolean} solrsyntax=True
 *
 *@apiSampleRequest /restful/query/1.1/findPatentFacet
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *  { 
 *		facet_counts: {
 *   		facet_dates: {}, 
 *   		facet_fields: {facetInfo}, 
 *   		facet_heatmaps: {}, 
 *			facet_intervals: {},
 *			facet_queries: {}, 
 *			facet_ranges: {}
 *	},
 *	{ 
 *		response: {
 *   		numFound: 1, 
 *   		start: 0, 
 *   		maxScore: 16.984732, 
 *			docs: [...]
 *	},
 *	{
 *		responseHeader: responseHeader
 *	} 
 */

/** 
 *
 *@api{get}/findSimpleQuery findSimpleQuery
 *@apiVersion 0.1.1
 *@apiName findSimpleQuery
 *@apiGroup NLP
 *
 *@apiParam {String} access_token
 *@apiParam {String} text
 *@apiParam {String} id
 *@apiParam {String} id_type
 *@apiParam {String} time yyy-mm-ddThh:mm:ssZ
 * 
 *@apiSampleRequest /restful/nlp/1.1/findSimpleQuery
  */

/** 
 *
 *@api{get}/findSimpleQuery_brief findSimpleQuery_brief
 *@apiVersion 0.1.1
 *@apiName findSimpleQuery_brief
 *@apiGroup NLP
 *
 *@apiParam {String} access_token
 *@apiParam {String} text
 *@apiParam {String} id
 *@apiParam {String} id_type
 *@apiParam {String} time yyy-mm-ddThh:mm:ssZ
 * 
 *@apiSampleRequest /restful/nlp/1.1/findSimpleQuery/brief
  */

/** 
 *
 *@api{get}/findSimpleQuery_claim findSimpleQuery_claim
 *@apiVersion 0.1.1
 *@apiName findSimpleQuery_claim
 *@apiGroup NLP
 *
 *@apiParam {String} access_token
 *@apiParam {String} text
 *@apiParam {String} id
 *@apiParam {String} id_type
 *@apiParam {String} time yyy-mm-ddThh:mm:ssZ
 * 
 *@apiSampleRequest /restful/nlp/1.1/findSimpleQuery/claim
  */

/** 
 *
 *@api{get}/findQueryExpansion findQueryExpansion
 *@apiVersion 0.1.1
 *@apiName findQueryExpansion
 *@apiGroup NLP
 *
 *@apiParam {String} access_token
 *@apiParam {String} text
 *@apiParam {String} id
 *@apiParam {String} id_type
 *@apiParam {String} time yyy-mm-ddThh:mm:ssZ
 * 
 *@apiSampleRequest /restful/nlp/1.1/findQueryExpansion
  */

/** 
 *
 *@api{get}/findKeywordExtraction findKeywordExtraction
 *@apiVersion 0.1.1
 *@apiName findKeywordExtraction
 *@apiGroup NLP
 *
 *@apiParam {String} access_token
 *@apiParam {String} text
 *@apiParam {String} id
 *@apiParam {String} id_type
 *@apiParam {String} time yyy-mm-ddThh:mm:ssZ
 * 
 *@apiSampleRequest /restful/nlp/1.1/findKeywordExtraction
  */

/** 
 *
 *@api{get}/countClipImage countClipImage
 *@apiVersion 0.1.1
 *@apiName countClipImage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *
 *@apiSampleRequest /restful/data/1.1/countClipImage
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{ 
 *		response: {
 *   		"patentNumber":"20100230186",
 *   		"clipImageCount":12,
 *   		"path":"us1a1/2010/09/16/20100230186"
 *	}
 */

/** 
 *
 *@api{get}/countFullPage countFullPage
 *@apiVersion 0.1.1
 *@apiName countFullPage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path
 *
 *@apiSampleRequest /restful/data/1.1/countFullPage
 *@apiSuccess{Object[]}response 
 *@apiSuccess{Object[]}responseHeader
 
 *@apiSuccessExample {json} Success-Response:
 *  HTTP/1.1 200 OK
 *	{ 
 *		response: {
 *   		[{
 *   			result: true, 
 *   			path: "us2s1/2015/08/18/us00d736967"
 *   		}]
 *	}
 */

/** 
 *
 *@api{get}/findInsetImage findInsetImage
 *@apiVersion 0.1.1
 *@apiName findInsetImage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us2b2/2014/01/07/us008623912"
 *  }
 *  
 *@apiSampleRequest /restful/data/1.1/findInsetImage
  */

/** 
 *
 *@api{get}/findFullImage findFullImage
 *@apiVersion 0.1.1
 *@apiName findFullImage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *@apiParam {String} num
 *
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us2b2/2014/01/07/us008623912",
 *    	"num":"2"
 *  }
 *  
 *@apiSampleRequest /restful/data/1.1/findFullImage
  */

/** 
 *
 *@api{get}/findFirstImage findFirstImage
 *@apiVersion 0.1.1
 *@apiName firstImage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us2b2/2014/01/07/us008623912"
 *  }
 *  
 *@apiSampleRequest /restful/data/1.1/findFirstImage
  */

/** 
 *
 *@api{get}/findClipImage findClipImage
 *@apiVersion 0.1.1
 *@apiName findClipImage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *@apiParam {String} num
 * 
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us2b2/2014/01/07/us008623912",
 *    	"num":"2"
 *  }
 *@apiSampleRequest /restful/data/1.1/findClipImage
  */

/** 
 *
 *@api{get}/findFirstPage findFirstPage
 *@apiVersion 0.1.1
 *@apiName findFirstPage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *@apiParam {String} filename
 *@apiParam {String} downloadType
 * 
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us2b2/2014/01/07/us008623912",
 *    	"filename":"us008623912_firstPage",
 *    	"downloadType":"pdf"
 *  }
 *  
 *@apiSampleRequest /restful/data/1.1/findFirstPage
  */

/** 
 *
 *@api{get}/findFullPage findFullPage
 *@apiVersion 0.1.1
 *@apiName findFullPage
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} path [country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]
 *@apiParam {String} filename
 * 
 *@apiParamExample {json} Request-Example:
 *  {
 *    	"access_token":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
 *    	"path":"us1a1/2010/09/16/20100230186",
 *    	"filename":"20100230186_fullPage",
 *    	"downloadType":"pdf"
 *  }
 *  
 *@apiSampleRequest /restful/data/1.1/findFullPage
  */

/** 
 *
 *@api{get}/findPatentExcel findPatentExcel
 *@apiVersion 0.1.1
 *@apiName findPatentExcel
 *@apiGroup Data
 *
 *@apiParam {String} access_token
 *@apiParam {String} ptopid
 *@apiParam {String} field country,appNumber,appDate,title,titleEn,openDecisionNumber,doDate,openNumber,openDate,decisionNumber,decisionDate,certificateNumber, certificateDate,type,assignees,docdbAssignees,currentAssigneesName,inventors,docdbInventors,agents,uspcs,ipcs,locs,cpcs,fis,brief,briefEn,firstImage,fullTextUrl
 *@apiParam {String} locale=en_US zh_TW, zh_CN, en_US, ja_JP 
 *@apiParam {String} filename=Patentlist-Patentcloud.xls
 * 
 *@apiSampleRequest /restful/data/1.1/findPatentExcel
  */