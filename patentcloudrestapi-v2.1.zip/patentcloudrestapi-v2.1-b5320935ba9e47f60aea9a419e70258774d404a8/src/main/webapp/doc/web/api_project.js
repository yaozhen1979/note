define({
  "name": "PatentCloud RestAPI document",
  "version": "0.1.1",
  "description": "apiDoc basic example",
  "title": "PatentCloud RestAPI",
  "header": {
    "title": "Get start",
    "content": "<div style=\"padding-bottom:30px\">\n\t<section style=\"padding-bottom:0px\">\n\t\t<h1>基本概述</h1>\n\t</section>\n\t<ul style=\"color: #c60;font-size: 20px;\"><li>Oauth</li></ul>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\t\t\n\t\tPatentCloud RestfulAPI 通過使用 Oauth2 的方法來驗證某個請求的發送者身份。\n\t</span><p/>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\n\t\t用戶在使用 API 前，需先透過帳號和密碼呼叫 Oauth token API 取得 access token，\n\t</span><p/>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\n\t\t每次使用 API Request 時增加 access_token 參數帶入所取得的 access token。\n\t</span><p/>\n\t<ul style=\"color: #c60;font-size: 20px;\"><li>Query</li></ul>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\n\t\t透過 Solr 搜尋專利相關資訊、統計、分組等相關 API。\n\t</span><p/>\n\t<ul style=\"color: #c60;font-size: 20px;\"><li>Data</li></ul>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\n\t\t搜尋專利文檔、圖片和專利資訊 Excel 匯出。\n\t</span><p/>\n\t<ul style=\"color: #c60;font-size: 20px;\"><li>NLP</li></ul>\n\t<span style=\"color:black;font-size: 16px;margin-left: 40px;\">\n\t\t專利自然語言搜尋。\n\t</span>\n</div>\n<div> \n\t<section style=\"padding-bottom:0px\">\n\t\t<h1>方法用途</h1>\n\t</section>\n</div>\n<table>\n\t<tr>\n\t\t<td style=\"background:#A8D7E0\">\n\t\t\t<span>用途</span>\n  \t\t</td>\n  \t\t<td style=\"background:#A8D7E0\">\n\t\t\t<span>Rest API 架構</span>\n  \t\t</td>\n \t</tr>\n \t<tr>\n  \t\t<td>\n\t\t\t<span>取得access token</span>\n  \t\t</td>\n  \t\t<td>\n  \t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n\t\t\t<span>/PatentCloudAPI/oauth/token</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得搜尋專利列表</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/query/1.1/queryPatentList</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得搜尋專利單篇資訊</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/query/1.1/findPatentInfo</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得搜尋專利統計資料</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/query/1.1/findPatentFacet</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得搜尋專利分組資料</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/query/1.1/findPatentGroup</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利第一張圖片</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findFirstImage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利圖片</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findClipImage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利圖片總數量</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/countClipImage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET、POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利全文圖片</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findFullImage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET、POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利全文圖片總數量</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/countFullPage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: GET、POST</span>\n  \t\t</td> \n \t</tr>\t\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利第一頁全文</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findFirstPage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利全文</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findFullPage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>取得單篇專利化學式圖片</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findInsetImage</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n\t<tr>\n  \t\t<td>\n\t\t\t<span>匯出專利資訊 Excel</span>\n  \t\t</td>\n  \t\t<td>\n\t\t\t<span>URI : </span>\n\t\t\t<i style=\"font-family:sans-serif;color:firebrick;\">\n\t\t\t\t(HostIP)\n\t\t\t</i>\n  \t\t\t<span>/PatentCloudAPI/restful/data/1.1/findPatentExcel</span><p>\n  \t\t\t<span style=\"color:black\">Verb: POST</span>\n  \t\t</td> \n \t</tr>\n</table>"
  },
  "order": [
    "Oauth",
    "Query",
    "QueryPatentList",
    "FindPatentInfo",
    "FindPatentGroup",
    "FindPatentFacet",
    "Data",
    "CountClipImage",
    "CountFullPage",
    "FindInsetImage",
    "FindFullImage",
    "findClipImage",
    "FindFirstImage",
    "FindFirstPage",
    "FindFullPage",
    "FindPatentExcel",
    "NLP",
    "FindSimpleQuery",
    "FindSimpleQueryByBrief",
    "FindSimpleQueryByClaim",
    "FindQueryExpansion",
    "FindKeywordExtraction"
  ],
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-04-10T07:30:54.362Z",
    "url": "http://apidocjs.com",
    "version": "0.15.1"
  }
});
