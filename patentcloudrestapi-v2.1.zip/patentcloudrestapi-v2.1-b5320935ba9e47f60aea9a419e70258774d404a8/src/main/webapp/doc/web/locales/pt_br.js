define({
    'pt_br': {
        'Allowed values:'             : 'Valores permitidos:',
        'Compare all with predecessor': 'Compare todos com antecessores',
        'compare changes to:'         : 'comparar alterações com:',
        'compared to'                 : 'comparado com',
        'Default value:'              : 'Valor padrão:',
        'Description'                 : 'Descrição',
        'Field'                       : 'Campo',
        'General'                     : 'Geral',
        'Generated with'              : 'Gerado com',
        'Name'                        : 'Nome',
        'No response values.'         : 'Sem valores de resposta.',
        'optional'                    : 'opcional',
        'Parameter'                   : 'Parâmetro',
        'Permission:'                 : 'Permissão:',
        'Response'                    : 'Resposta',
        'Send'                        : 'Enviar',
        'Send a Sample Request'       : 'Enviar um Exemplo de Pedido',
        'show up to version:'         : 'aparecer para a versão:',
        'Size range:'                 : 'Faixa de tamanho:',
        'Type'                        : 'Tipo',
        'url'                         : 'url'
    }
});
