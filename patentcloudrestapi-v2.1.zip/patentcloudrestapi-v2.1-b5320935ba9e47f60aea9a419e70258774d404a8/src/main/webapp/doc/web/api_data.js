define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./web/main.js",
    "group": "C__Dev_Java_PatentCloudRestfulAPI_src_main_webapp_doc_web_main_js",
    "groupTitle": "C__Dev_Java_PatentCloudRestfulAPI_src_main_webapp_doc_web_main_js",
    "name": ""
  },
  {
    "type": "get",
    "url": "/countClipImage",
    "title": "countClipImage",
    "version": "0.1.1",
    "name": "countClipImage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/countClipImage"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{ \n\t\tresponse: {\n  \t\t\"patentNumber\":\"20100230186\",\n  \t\t\"clipImageCount\":12,\n  \t\t\"path\":\"us1a1/2010/09/16/20100230186\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/countFullPage",
    "title": "countFullPage",
    "version": "0.1.1",
    "name": "countFullPage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/countFullPage"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{ \n\t\tresponse: {\n  \t\t[{\n  \t\t\tresult: true, \n  \t\t\tpath: \"us2s1/2015/08/18/us00d736967\"\n  \t\t}]\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findClipImage",
    "title": "findClipImage",
    "version": "0.1.1",
    "name": "findClipImage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "num",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us2b2/2014/01/07/us008623912\",\n  \t\"num\":\"2\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findClipImage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findFirstPage",
    "title": "findFirstPage",
    "version": "0.1.1",
    "name": "findFirstPage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filename",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "downloadType",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us2b2/2014/01/07/us008623912\",\n  \t\"filename\":\"us008623912_firstPage\",\n  \t\"downloadType\":\"pdf\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findFirstPage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findFullImage",
    "title": "findFullImage",
    "version": "0.1.1",
    "name": "findFullImage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "num",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us2b2/2014/01/07/us008623912\",\n  \t\"num\":\"2\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findFullImage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findFullPage",
    "title": "findFullPage",
    "version": "0.1.1",
    "name": "findFullPage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filename",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us1a1/2010/09/16/20100230186\",\n  \t\"filename\":\"20100230186_fullPage\",\n  \t\"downloadType\":\"pdf\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findFullPage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findInsetImage",
    "title": "findInsetImage",
    "version": "0.1.1",
    "name": "findInsetImage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us2b2/2014/01/07/us008623912\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findInsetImage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findPatentExcel",
    "title": "findPatentExcel",
    "version": "0.1.1",
    "name": "findPatentExcel",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "ptopid",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "field",
            "description": "<p>country,appNumber,appDate,title,titleEn,openDecisionNumber,doDate,openNumber,openDate,decisionNumber,decisionDate,certificateNumber, certificateDate,type,assignees,docdbAssignees,currentAssigneesName,inventors,docdbInventors,agents,uspcs,ipcs,locs,cpcs,fis,brief,briefEn,firstImage,fullTextUrl</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "locale",
            "defaultValue": "en_US",
            "description": "<p>zh_TW, zh_CN, en_US, ja_JP</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filename",
            "defaultValue": "Patentlist-Patentcloud.xls",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findPatentExcel"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findFirstImage",
    "title": "findFirstImage",
    "version": "0.1.1",
    "name": "firstImage",
    "group": "Data",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "path",
            "description": "<p>[country][state][kindCode]/[doDate-year]/[doDate-month]/[doDate-day]/[patentNumber]</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \t\"access_token\":\"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\",\n  \t\"path\":\"us2b2/2014/01/07/us008623912\"\n}",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/restful/data/1.1/findFirstImage"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "Data"
  },
  {
    "type": "get",
    "url": "/findKeywordExtraction",
    "title": "findKeywordExtraction",
    "version": "0.1.1",
    "name": "findKeywordExtraction",
    "group": "NLP",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "text",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>yyy-mm-ddThh:mm:ssZ</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/nlp/1.1/findKeywordExtraction"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "NLP"
  },
  {
    "type": "get",
    "url": "/findQueryExpansion",
    "title": "findQueryExpansion",
    "version": "0.1.1",
    "name": "findQueryExpansion",
    "group": "NLP",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "text",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>yyy-mm-ddThh:mm:ssZ</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/nlp/1.1/findQueryExpansion"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "NLP"
  },
  {
    "type": "get",
    "url": "/findSimpleQuery",
    "title": "findSimpleQuery",
    "version": "0.1.1",
    "name": "findSimpleQuery",
    "group": "NLP",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "text",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>yyy-mm-ddThh:mm:ssZ</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/nlp/1.1/findSimpleQuery"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "NLP"
  },
  {
    "type": "get",
    "url": "/findSimpleQuery_brief",
    "title": "findSimpleQuery_brief",
    "version": "0.1.1",
    "name": "findSimpleQuery_brief",
    "group": "NLP",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "text",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>yyy-mm-ddThh:mm:ssZ</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/nlp/1.1/findSimpleQuery/brief"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "NLP"
  },
  {
    "type": "get",
    "url": "/findSimpleQuery_claim",
    "title": "findSimpleQuery_claim",
    "version": "0.1.1",
    "name": "findSimpleQuery_claim",
    "group": "NLP",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "text",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>yyy-mm-ddThh:mm:ssZ</p>"
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/nlp/1.1/findSimpleQuery/claim"
      }
    ],
    "filename": "./example.js",
    "groupTitle": "NLP"
  },
  {
    "type": "get",
    "url": "/oauth/token",
    "title": "token",
    "version": "0.1.1",
    "name": "Oauth",
    "group": "Oauth",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "grant_type",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "client_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "client_secret",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "scope",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": " {\n   \t\"grant_type\":\"password\",\n\t\t\"client_id\":\"restapp\",\n\t\t\"client_secret\":\"restapp\",\n\t\t\"username\":\"xxxxxxxx\",\n\t\t\"password\":\"yyyyyy\",\n\t\t\"scope\":\"client\",\n }",
          "type": "json"
        }
      ]
    },
    "sampleRequest": [
      {
        "url": "/oauth/token"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "token_type",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "refresh_token",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "expires_in",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "scope",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{\n\t\t\"access_token\":\"df7a04d7-a115-4101-89b1-c8253eee4358\",\n\t\t\"token_type\":\"bearer\",\n\t\t\"refresh_token\":\"0c24b520-acef-47e6-8439-cf096db13e80\",\n\t\t\"expires_in\":1289804,\n\t\t\"scope\":\"client\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Oauth"
  },
  {
    "type": "get",
    "url": "/findPatentFacet",
    "title": "findPatentFacet",
    "version": "0.1.1",
    "name": "findPatentFacet",
    "group": "Query",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "query",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "rows",
            "defaultValue": "20",
            "description": "<p>It specify the maximum number of documents from the complete result set to return to the client for every request.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "sort",
            "defaultValue": "score.desc",
            "description": "<p>score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "country",
            "description": "<p>us,cn,ep,wo,jp,kr,tw.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "type",
            "defaultValue": "1,2,3,4,5,6,9",
            "description": "<p>1:&quot;發明&quot;、Type 2:&quot;新型&quot;、Type 3:&quot;設計&quot;、Type 4:&quot;Plant&quot;(US)、Type 5:&quot;Reissue&quot;(US)、Type 6:&quot;SIR&quot;(US)、Type 9:&quot;Others&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "docdb",
            "defaultValue": "False",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "state",
            "defaultValue": "1,2",
            "description": "<p>1:&quot;公開&quot;、2:&quot;公告&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "stem",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "facet.offset",
            "defaultValue": "0",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "facet.field",
            "description": "<p>country,typeCode,kindcode,assigneesFacetname,inventorsFacetname,agentsFacetname,examinerMastersFacetname,uspcs,ipcsNormal,locs,cpcsNormal,fis,appYear,openYear,decisionYear,currentAssigneesFacetname,ipcsClass,ipcsSubClass,ipcsGroup,ipcsSubGroup,cpcsClass,cpcsSubClass,cpcsGroup,cpcsSubGroup,fis,fisClass,fisSubClass,fisGroup,fisSubGroup,docdbAssigneesFacetname</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "facet.limit",
            "defaultValue": "20",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "mode",
            "description": "<p>BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "fl",
            "defaultValue": "all",
            "description": "<p>Any field, function, or transformer can be displayed with a different name in the output document.</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "litigation",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "solrsyntax",
            "defaultValue": "True",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/query/1.1/findPatentFacet"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n { \n\t\tfacet_counts: {\n  \t\tfacet_dates: {}, \n  \t\tfacet_fields: {facetInfo}, \n  \t\tfacet_heatmaps: {}, \n\t\t\tfacet_intervals: {},\n\t\t\tfacet_queries: {}, \n\t\t\tfacet_ranges: {}\n\t},\n\t{ \n\t\tresponse: {\n  \t\tnumFound: 1, \n  \t\tstart: 0, \n  \t\tmaxScore: 16.984732, \n\t\t\tdocs: [...]\n\t},\n\t{\n\t\tresponseHeader: responseHeader\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Query"
  },
  {
    "type": "get",
    "url": "/findPatentGroup",
    "title": "findPatentGroup",
    "version": "0.1.1",
    "name": "findPatentGroup",
    "group": "Query",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "query",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "rows",
            "defaultValue": "20",
            "description": "<p>It specify the maximum number of documents from the complete result set to return to the client for every request.</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "start",
            "defaultValue": "0",
            "description": "<p>It indicates the offset in the complete result set for the queries where the set of returned documents should begin.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "sort",
            "defaultValue": "score.desc",
            "description": "<p>score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "country",
            "description": "<p>us,cn,ep,wo,jp,kr,tw.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "type",
            "defaultValue": "1,2,3,4,5,6,9",
            "description": "<p>1:&quot;發明&quot;、Type 2:&quot;新型&quot;、Type 3:&quot;設計&quot;、Type 4:&quot;Plant&quot;(US)、Type 5:&quot;Reissue&quot;(US)、Type 6:&quot;SIR&quot;(US)、Type 9:&quot;Others&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "docdb",
            "defaultValue": "False",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "state",
            "defaultValue": "1,2",
            "description": "<p>1:&quot;公開&quot;、2:&quot;公告&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "stem",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "group.field",
            "description": "<p>familyIdGroup、appNumberGroup</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "group.limit",
            "defaultValue": "20",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "mode",
            "description": "<p>BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "fl",
            "defaultValue": "all",
            "description": "<p>Any field, function, or transformer can be displayed with a different name in the output document.</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "litigation",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "solrsyntax",
            "defaultValue": "True",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/query/1.1/findPatentGroup"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{ \n\t\tgrouped: {\n\t\t\tfamilyIdGroup: [GroupInfo]\n\t},\n\t{\n\t\tresponseHeader: responseHeader\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Query"
  },
  {
    "type": "get",
    "url": "/findPatentInfo",
    "title": "findPatentInfo",
    "version": "0.1.1",
    "name": "findPatentInfo",
    "group": "Query",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "ptopid",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "sort",
            "defaultValue": "score.desc",
            "description": "<p>score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "mode",
            "description": "<p>BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "fl",
            "defaultValue": "all",
            "description": "<p>Any field, function, or transformer can be displayed with a different name in the output document.</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "litigation",
            "defaultValue": "True",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/query/1.1/findPatentInfo"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{ \n\t\tresponse: {\n  \t\tnumFound: 1, \n  \t\tstart: 0, \n  \t\tmaxScore: 16.984732, \n\t\t\tdocs: [patentListInfo]\n\t},\n\t{\n\t\tresponseHeader: responseHeader\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Query"
  },
  {
    "type": "get",
    "url": "/queryPatentList",
    "title": "queryPatentList",
    "version": "0.1.1",
    "name": "queryPatentList",
    "group": "Query",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "access_token",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "query",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "rows",
            "defaultValue": "20",
            "description": "<p>It specify the maximum number of documents from the complete result set to return to the client for every request.</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "start",
            "defaultValue": "0",
            "description": "<p>It indicates the offset in the complete result set for the queries where the set of returned documents should begin.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "sort",
            "defaultValue": "score.desc",
            "description": "<p>score.asc、appDate.asc、doDate.asc、score.desc、appDate.desc、doDate.desc</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "country",
            "description": "<p>us,cn,ep,wo,jp,kr,tw.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "type",
            "defaultValue": "1,2,3,4,5,6,9",
            "description": "<p>1:&quot;發明&quot;、Type 2:&quot;新型&quot;、Type 3:&quot;設計&quot;、Type 4:&quot;Plant&quot;(US)、Type 5:&quot;Reissue&quot;(US)、Type 6:&quot;SIR&quot;(US)、Type 9:&quot;Others&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "docdb",
            "defaultValue": "False",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "state",
            "defaultValue": "1,2",
            "description": "<p>1:&quot;公開&quot;、2:&quot;公告&quot;</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "stem",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "mode",
            "description": "<p>BRIEF_1、BRIEF_2、PATENT_LIST、PATENT_INFO、PATENT_FACET、PATENT_GROUPING、DEFINITION_1、DEFINITION_2</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "fl",
            "defaultValue": "all",
            "description": "<p>Any field, function, or transformer can be displayed with a different name in the output document</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "litigation",
            "defaultValue": "True",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "optional": false,
            "field": "solrsyntax",
            "defaultValue": "True",
            "description": ""
          }
        ]
      }
    },
    "sampleRequest": [
      {
        "url": "/restful/query/1.1/queryPatentList"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "response",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "responseHeader",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n\t{ \n\t\tresponse: {\n  \t\tnumFound: 254719, \n  \t\tstart: 0, \n  \t\tmaxScore: 1.3225307, \n\t\t\tdocs: [patentListInfo]\n\t},\n\t{\n\t\tresponseHeader: responseHeader\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "./example.js",
    "groupTitle": "Query"
  }
] });
