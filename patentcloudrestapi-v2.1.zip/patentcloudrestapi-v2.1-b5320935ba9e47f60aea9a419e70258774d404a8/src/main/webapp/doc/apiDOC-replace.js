send_sample_request.js


// grab user-inputted URL				
var pathnameArray = window.location.pathname.split("/");				
var url = "/" + pathnameArray[1] + $root.find(".sample-request-url").val();
--------------------------------------------------------------------------------------------------------------------------------


send_sample_request.js

var paramURL = ""; //增加此行
$root.find(".sample-request-param:checked")
		.each(function(i, element) {
			var group = $(element).data(
				"sample-request-param-group-id");
				$root.find("[data-sample-request-param-group=\"" + group + "\"]")
					.each(function(i, element) {
						var key = $(element).data(
								"sample-request-param-name");
						var value = element.value;
						paramURL += key + "=" + value + "&"; //增加此行
						if (!element.optional && element.defaultValue !== '') {
							value = element.defaultValue;
						}
						param[key] = value;
						paramType[key] = $(
							element).next().text();
					});
		);

---------------------------------------------------------------------------------------------------------------------------------

send_sample_request.js

$.ajax(ajaxRequest); //此行用下面程式碼取代

var blobUrl = [ "findInsetImage", "findFullImage",
				"findFirstImage", "findClipImage", "findFirstPage",
				"findFullPage", "findPatentExcel" ];
var saveUrl = [ "findFirstPage", "findFullPage",
				"findPatentExcel" ];
var lastPartofURL = url.substring(url.lastIndexOf('/') + 1);
console.log($.inArray(lastPartofURL, blobUrl));
if ($.inArray(lastPartofURL, blobUrl) != -1) {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.open("Post", encodeURI(url + "?" + paramURL), true);
	xmlhttp.setRequestHeader("content-Type",
		"application/x-www-form-urlencoded; charset=ISO-8859-1");
	xmlhttp.responseType = 'blob'; // 定義回傳型態為Blob
	xmlhttp.onload = function(e) {
		if (this.status == 200) {
			var blob = this.response;
			if ($.inArray(lastPartofURL, saveUrl) != -1) {
				var contentDisposition = xmlhttp.getResponseHeader("Content-Disposition");
				var filename = contentDisposition.substring(
					contentDisposition.lastIndexOf('=') + 1).replace(/\"/g, "");
				saveAs(blob, filename);
			} else {
				window.open(window.URL.createObjectURL(blob), 'image', config='height=400,width=300');
			}							
			$root.find(".sample-request-response").hide();
			refreshScrollSpy();
		}
	};
	xmlhttp.send();
} else {
	$.ajax(ajaxRequest);
}

function saveAs(blob, filename) {
	window.URL = window.URL || window.webkitURL;
	var url = window.URL.createObjectURL(blob);
	var save_link = document.createElement('a');
	save_link.href = url;
	save_link.download = filename;
	save_link.click();
}