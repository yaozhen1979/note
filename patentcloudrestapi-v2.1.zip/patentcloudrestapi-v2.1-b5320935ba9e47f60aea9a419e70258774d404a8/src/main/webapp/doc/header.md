<div style="padding-bottom:30px">
	<section style="padding-bottom:0px">
		<h1>基本概述</h1>
	</section>
	<ul style="color: #c60;font-size: 20px;"><li>Oauth</li></ul>
	<span style="color:black;font-size: 16px;margin-left: 40px;">		
		PatentCloud RestfulAPI 通過使用 Oauth2 的方法來驗證某個請求的發送者身份。
	</span><p/>
	<span style="color:black;font-size: 16px;margin-left: 40px;">
		用戶在使用 API 前，需先透過帳號和密碼呼叫 Oauth token API 取得 access token，
	</span><p/>
	<span style="color:black;font-size: 16px;margin-left: 40px;">
		每次使用 API Request 時增加 access_token 參數帶入所取得的 access token。
	</span><p/>
	<ul style="color: #c60;font-size: 20px;"><li>Query</li></ul>
	<span style="color:black;font-size: 16px;margin-left: 40px;">
		透過 Solr 搜尋專利相關資訊、統計、分組等相關 API。
	</span><p/>
	<ul style="color: #c60;font-size: 20px;"><li>Data</li></ul>
	<span style="color:black;font-size: 16px;margin-left: 40px;">
		搜尋專利文檔、圖片和專利資訊 Excel 匯出。
	</span><p/>
	<ul style="color: #c60;font-size: 20px;"><li>NLP</li></ul>
	<span style="color:black;font-size: 16px;margin-left: 40px;">
		專利自然語言搜尋。
	</span>
</div>
<div> 
	<section style="padding-bottom:0px">
		<h1>方法用途</h1>
	</section>
</div>
<table>
	<tr>
		<td style="background:#A8D7E0">
			<span>用途</span>
  		</td>
  		<td style="background:#A8D7E0">
			<span>Rest API 架構</span>
  		</td>
 	</tr>
 	<tr>
  		<td>
			<span>取得access token</span>
  		</td>
  		<td>
  			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
			<span>/PatentCloudAPI/oauth/token</span><p>
  			<span style="color:black">Verb: GET</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得搜尋專利列表</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/query/1.1/queryPatentList</span><p>
  			<span style="color:black">Verb: GET</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得搜尋專利單篇資訊</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/query/1.1/findPatentInfo</span><p>
  			<span style="color:black">Verb: GET</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得搜尋專利統計資料</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/query/1.1/findPatentFacet</span><p>
  			<span style="color:black">Verb: GET</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得搜尋專利分組資料</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/query/1.1/findPatentGroup</span><p>
  			<span style="color:black">Verb: GET</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利第一張圖片</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findFirstImage</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利圖片</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findClipImage</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利圖片總數量</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/countClipImage</span><p>
  			<span style="color:black">Verb: GET、POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利全文圖片</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findFullImage</span><p>
  			<span style="color:black">Verb: GET、POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利全文圖片總數量</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/countFullPage</span><p>
  			<span style="color:black">Verb: GET、POST</span>
  		</td> 
 	</tr>	
	<tr>
  		<td>
			<span>取得單篇專利第一頁全文</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findFirstPage</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利全文</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findFullPage</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>取得單篇專利化學式圖片</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findInsetImage</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
	<tr>
  		<td>
			<span>匯出專利資訊 Excel</span>
  		</td>
  		<td>
			<span>URI : </span>
			<i style="font-family:sans-serif;color:firebrick;">
				(HostIP)
			</i>
  			<span>/PatentCloudAPI/restful/data/1.1/findPatentExcel</span><p>
  			<span style="color:black">Verb: POST</span>
  		</td> 
 	</tr>
</table>