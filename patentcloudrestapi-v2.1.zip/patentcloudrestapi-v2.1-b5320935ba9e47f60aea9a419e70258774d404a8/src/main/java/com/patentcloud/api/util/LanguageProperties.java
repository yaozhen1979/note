package com.patentcloud.api.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LanguageProperties {

    private static final Logger log = LoggerFactory.getLogger(LanguageProperties.class);

    private static final Properties defLang = new Properties();

    static {
        try {
            defLang.load(LanguageProperties.class.getResourceAsStream("/ExcelLang.properties"));

        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    private static final Map<Locale, Properties> langMap = new HashMap<>();

    static {
        try {
            Properties prop = new Properties();
            prop.load(LanguageProperties.class.getResourceAsStream("/ExcelLang_zh_TW.properties"));
            langMap.put(Locale.TRADITIONAL_CHINESE, prop);
            prop = new Properties();
            prop.load(LanguageProperties.class.getResourceAsStream("/ExcelLang_zh_CN.properties"));
            langMap.put(Locale.CHINA, prop);
            prop = new Properties();
            prop.load(LanguageProperties.class.getResourceAsStream("/ExcelLang_ja_JP.properties"));
            langMap.put(Locale.JAPAN, prop);

        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    public static String get(Locale locale, String lid) {
        String defStr = "??? " + lid + " ???";
        if (langMap.containsKey(locale)) {
            return langMap.get(locale).getProperty(lid, defStr);
        }

        return defLang.getProperty(lid, defStr);
    }
}
