package com.patentcloud.api.common;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.patentcloud.api.constant.Pto;

public class Mapping {

    public static final Map<String, String> PTO2CORE = new LinkedHashMap<>();

    static {
        PTO2CORE.put(Pto.USPTO.name(), "US");
        PTO2CORE.put(Pto.CNIPR.name(), "CN");
        PTO2CORE.put(Pto.TIPO.name(), "TW");
        PTO2CORE.put(Pto.JPO.name(), "JP");
        PTO2CORE.put(Pto.KIPO.name(), "KR");
        PTO2CORE.put(Pto.EPO.name(), "EP");
        PTO2CORE.put(Pto.WIPO.name(), "WO");
        PTO2CORE.put(Pto.DOCDB.name(), "DOCDB");
        PTO2CORE.put(Pto.IN.name(), "IN");
    }

    public static final HashMap<String, Pto> ptoCountryMap = new HashMap<>();

    static {
        ptoCountryMap.put("us", Pto.USPTO);
        ptoCountryMap.put("tw", Pto.TIPO);
        ptoCountryMap.put("cn", Pto.CNIPR);
        ptoCountryMap.put("jp", Pto.JPO);
        ptoCountryMap.put("kr", Pto.KIPO);
        ptoCountryMap.put("ep", Pto.EPO);
        ptoCountryMap.put("wo", Pto.WIPO);
    }

    public static final HashMap<Pto, String> ptoPathMap = new HashMap<>();

    static {
        ptoPathMap.put(Pto.USPTO, "us");
        ptoPathMap.put(Pto.US, "us");
        ptoPathMap.put(Pto.TIPO, "tw");
        ptoPathMap.put(Pto.TW, "tw");
        ptoPathMap.put(Pto.CNIPR, "cn");
        ptoPathMap.put(Pto.CN, "cn");
        ptoPathMap.put(Pto.JPO, "jp");
        ptoPathMap.put(Pto.JP, "jp");
        ptoPathMap.put(Pto.KIPO, "kr");
        ptoPathMap.put(Pto.KR, "kr");
        ptoPathMap.put(Pto.EPO, "ep");
        ptoPathMap.put(Pto.EP, "ep");
        ptoPathMap.put(Pto.WIPO, "wo");
        ptoPathMap.put(Pto.WO, "wo");
        ptoPathMap.put(Pto.DPMA, "de");
        ptoPathMap.put(Pto.DE, "de");
        ptoPathMap.put(Pto.INPI, "fr");
        ptoPathMap.put(Pto.FR, "fr");
        ptoPathMap.put(Pto.UKIPO, "gb");
        ptoPathMap.put(Pto.GB, "gb");
        ptoPathMap.put(Pto.IGE, "ch");
        ptoPathMap.put(Pto.CH, "ch");
        ptoPathMap.put(Pto.IN, "in");
    }
}
