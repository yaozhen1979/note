package com.patentcloud.api.server.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.patentcloud.api.model.PatentDataStatus;
import com.patentcloud.api.server.dao.common.AbstractDaoSupport;
import com.patentcloud.api.server.dao.mapper.PatentDataStatusRowMapper;

public class PatentDataStatusDaoImpl extends AbstractDaoSupport implements PatentDataStatusDao {

    @Override
    public void savePatentDataStatus(PatentDataStatus patentDataStatus) {
        if (patentDataStatus == null) {
            return;
        }

        Date now = new Date();
        patentDataStatus.setCreatedDateTime(now);
        patentDataStatus.setModifiedDateTime(now);
        if (patentDataStatus.getId() == null) {
            patentDataStatus.setId(patentDataStatus.generateId());
        }

        StringBuffer sql = new StringBuffer();
        sql.append("insert into PatentDataStatus");
        sql.append(" (ID, Pto, Target, PatentType, PatentStatus, PatentCount, EarliestUpdateDateTime, LatestUpdateDateTime, CheckDateTime, CreatedDateTime, ModifiedDateTime)");
        sql.append(" values");
        sql.append(" (:id, :pto, :target, :patentType, :patentStatus, :patentCount, :earliestUpdateDateTime, :latestUpdateDateTime, :checkDateTime, :createdDateTime, :modifiedDateTime)");

        super.getNamedParameterJdbcTemplate().update(sql.toString(), super.getParamMap(patentDataStatus));
    }

    @Override
    public void updatePatentDataStatus(PatentDataStatus patentDataStatus) {
        if (patentDataStatus == null) {
            return;
        }

        patentDataStatus.setModifiedDateTime(new Date());
        if (patentDataStatus.getId() == null) {
            patentDataStatus.setId(patentDataStatus.generateId());
        }

        StringBuffer sql = new StringBuffer();
        sql.append("update PatentDataStatus");
        sql.append(" set PatentCount = :patentCount");
        sql.append(", EarliestUpdateDateTime = :earliestUpdateDateTime");
        sql.append(", LatestUpdateDateTime = :latestUpdateDateTime");
        sql.append(", CheckDateTime = :checkDateTime");
        sql.append(", ModifiedDateTime = :modifiedDateTime");
        sql.append(" where ID = :id");

        super.getNamedParameterJdbcTemplate().update(sql.toString(), super.getParamMap(patentDataStatus));
    }

    @Override
    public void deleteInvalidPatentDataStatus(Date checkDateTime) {
        String sql = "delete PatentDataStatus where checkDateTime is null or checkDateTime < ?";
        super.getJdbcTemplate().update(sql, checkDateTime);
    }

    @Override
    public PatentDataStatus findPatentDataStatusById(String id) {
        String sql = "select * from PatentDataStatus where ID = ?";
        List<PatentDataStatus> list = super.getJdbcTemplate().query(sql, new Object[] { id },
                new PatentDataStatusRowMapper());
        if (list != null && list.size() == 1) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public PatentDataStatus findPatentDataStatus(String target, Integer stat, Integer type) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<String, Object>();

        sql.append("select * from PatentDataStatus");

        sql.append(" where Target ");
        if (target == null) {
            sql.append("is null");
        } else {
            sql.append("= :target");
            paramMap.put("target", target);
        }

        sql.append(" and PatentStatus ");
        if (stat == null) {
            sql.append("is null");
        } else {
            sql.append("= :stat");
            paramMap.put("stat", stat);
        }

        sql.append(" and PatentType ");
        if (type == null) {
            sql.append("is null");
        } else {
            sql.append("= :type");
            paramMap.put("type", type);
        }

        List<PatentDataStatus> list = super.getNamedParameterJdbcTemplate().query(sql.toString(), paramMap,
                new PatentDataStatusRowMapper());
        if (list != null && list.size() == 1) {
            return list.get(0);
        } else {
            return null;
        }
    }

    @Override
    public List<PatentDataStatus> findAllPatentDataStatus() {
        String sql = "select * from PatentDataStatus order by target, patentType, patentStatus";
        return super.getJdbcTemplate().query(sql, new PatentDataStatusRowMapper());
    }
}
