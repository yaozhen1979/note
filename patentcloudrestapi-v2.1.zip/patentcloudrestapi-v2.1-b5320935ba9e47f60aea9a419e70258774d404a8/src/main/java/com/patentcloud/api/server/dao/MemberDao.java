package com.patentcloud.api.server.dao;

import com.patentcloud.api.model.Member;

public interface MemberDao {

    Member getMemberInfo(String account);
}
