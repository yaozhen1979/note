package com.patentcloud.api.server.dao.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.logicalcobwebs.proxool.ProxoolException;
import org.logicalcobwebs.proxool.configuration.JAXPConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;

import com.patentcloud.api.util.config.ConfigProperties;

public class JdbcUtils {

    private static final Logger log = LoggerFactory.getLogger(JdbcUtils.class);

    public static void loadProxoolConnectionPool() throws IOException, ProxoolException {
        InputStream input = JdbcUtils.class.getResourceAsStream("/proxool.xml");
        String proxoolConfigTemplate = IOUtils.toString(input);

        Map<String, String> valuesMap = new HashMap<>();
        valuesMap.put("jdbc.driver", ConfigProperties.getInstance().getString("jdbc.driver"));
        valuesMap.put("jdbc.url", ConfigProperties.getInstance().getString("jdbc.url"));
        valuesMap.put("jdbc.user", ConfigProperties.getInstance().getString("jdbc.user"));
        valuesMap.put("jdbc.password", ConfigProperties.getInstance().getString("jdbc.password"));

        StrSubstitutor substitutor = new StrSubstitutor(valuesMap);
        String proxoolXml = substitutor.replace(proxoolConfigTemplate);

        JAXPConfigurator.configure(new InputSource(new StringReader(proxoolXml)), false);
    }

    public static void deregisterJdbcDrivers() {
        // deregister JDBC drivers
        // Important! See details below:
        // http://wiki.apache.org/tomcat/OutOfMemory
        Enumeration<Driver> drivers = DriverManager.getDrivers();
        List<Driver> unloadedDrivers = new ArrayList<>();

        while (drivers.hasMoreElements()) {
            Driver driver = drivers.nextElement();
            ClassLoader loader = driver.getClass().getClassLoader();

            if (loader != null && loader.equals(JdbcUtils.class.getClassLoader())) {
                unloadedDrivers.add(driver);
            }
        }

        for (Driver unloadedDriver : unloadedDrivers) {
            try {
                DriverManager.deregisterDriver(unloadedDriver);
                log.info("Deregister JDBC drivers. info: {}", unloadedDriver);

            } catch (SQLException e) {
                log.warn("Failed to deregister JDBC drivers.", e);
            }
        }
    }

    /**
     * The caller should be prevented from constructing objects of this class,
     * by declaring this private constructor.
     */
    private JdbcUtils() {
        // this prevents even the native class from
        // calling this ctor as well :
        throw new AssertionError();
    }
}
