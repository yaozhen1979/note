package com.patentcloud.api.web.common;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

public class ServletUtils {

    public static String showParameter(Map<String, String[]> parameterMap, Set<String> parameterNameFilter) {
        Set<Entry<String, String[]>> parameterSet = parameterMap.entrySet();

        StringBuilder parametersSb = new StringBuilder();

        for (Entry<String, String[]> parameterPair : parameterSet) {
            String key = parameterPair.getKey();

            if (parameterNameFilter != null && !parameterNameFilter.isEmpty()) {
                if (!parameterNameFilter.contains(key)) {
                    continue;
                }
            }

            if (parametersSb.length() > 0) {
                parametersSb.append(',');
            }

            String[] values = parameterPair.getValue();

            StringBuilder valueSb = new StringBuilder();
            for (int i = 0; i < values.length; i++) {
                valueSb.append(values[i]);

                if (i < values.length - 1) {
                    valueSb.append(',');
                }
            }
            valueSb.insert(0, '{').append('}');

            parametersSb.append(key).append('=').append(valueSb);
        }

        return parametersSb.toString();
    }

    public static void outputJsonResult(String jsonString, HttpServletResponse response) throws IOException {
        byte[] data = jsonString.getBytes("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        response.setContentLength(data.length);

        OutputStream output = response.getOutputStream();
        output.write(data);
        output.flush();
        IOUtils.closeQuietly(output);
    }

    public static boolean checkEtagIsCached(HttpServletRequest req, HttpServletResponse res, String etag) {
        res.setHeader("ETag", etag);

        String previousToken = req.getHeader("If-None-Match");
        if ((res.getStatus() < 400) && previousToken != null && previousToken.equals(etag)) {
            res.setStatus(HttpServletResponse.SC_NOT_MODIFIED);

            String modelLastModified = req.getHeader("If-Modified-Since");
            if (modelLastModified != null) {
                res.setHeader("Last-Modified", modelLastModified);
            }

            return true;
        }

        res.setDateHeader("Last-Modified", System.currentTimeMillis());
        res.setStatus(HttpServletResponse.SC_OK);

        return false;
    }

    public static boolean checkEtagIsCached(HttpServletRequest req, HttpServletResponse res,
            long modelLastModifiedDateMs) {
        res.setHeader("ETag", Long.toString(modelLastModifiedDateMs));
        res.setDateHeader("Last-Modified", modelLastModifiedDateMs);

        // need to check header date
        long headerDateMs = req.getDateHeader("If-Modified-Since");
        if (headerDateMs > 0) {
            // browser date accuracy only to second
            if ((modelLastModifiedDateMs / 1000) > (headerDateMs / 1000)) {
                res.setStatus(HttpServletResponse.SC_OK);
                return false;
            }
        }

        // if over expire data, see the Etag
        String previousToken = req.getHeader("If-None-Match");
        if ((res.getStatus() < 400) && previousToken != null
                && previousToken.equals(String.valueOf(modelLastModifiedDateMs))) {
            res.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
            return true;
        }

        // if the model has modified, setup the new modified date
        res.setStatus(HttpServletResponse.SC_OK);

        return false;
    }
}
