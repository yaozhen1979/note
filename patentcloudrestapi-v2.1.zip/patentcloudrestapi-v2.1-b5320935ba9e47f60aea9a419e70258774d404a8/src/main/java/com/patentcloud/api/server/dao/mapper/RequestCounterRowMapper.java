package com.patentcloud.api.server.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.patentcloud.api.model.RequestCounter;

public class RequestCounterRowMapper implements RowMapper<RequestCounter> {

    public RequestCounter mapRow(ResultSet rs, int index) throws SQLException {
        RequestCounter reqCounter = new RequestCounter();

        reqCounter.setId(rs.getString("ID"));
        reqCounter.setUserId(rs.getString("UserID"));
        reqCounter.setRequestCount(rs.getInt("RequestCount"));
        reqCounter.setCreatedDateTime(rs.getDate("CreatedDateTime"));

        return reqCounter;
    }

}
