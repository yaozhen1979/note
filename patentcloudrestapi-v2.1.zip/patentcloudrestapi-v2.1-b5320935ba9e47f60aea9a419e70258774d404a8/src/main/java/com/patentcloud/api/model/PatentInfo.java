package com.patentcloud.api.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.solr.client.solrj.SolrQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.patentcloud.api.constant.Pto;
import com.patentcloud.api.model.solr.SolrPatentInfo;
import com.patentcloud.api.model.solr.SolrQueryResult;
import com.patentcloud.api.util.solr.SolrUtils;

public class PatentInfo extends SolrPatentInfo {

    private static final Logger log = LoggerFactory.getLogger(PatentInfo.class);

    public String path;

    public Pto ptoVO;

    // MultiLangString
    public MultiLangString titleVO;

    public MultiLangString descriptionVO;

    public MultiLangString briefVO;

    public MultiLangString claimVO;

    // person info
    public ArrayList<Person> applicantVOs = new ArrayList<>();

    public ArrayList<Person> agentVOs = new ArrayList<>();

    public ArrayList<Person> agentOperatorVOs = new ArrayList<>();

    public ArrayList<Person> assigneeVOs = new ArrayList<>();

    public ArrayList<Person> inventorVOs = new ArrayList<>();

    public ArrayList<Person> examinerMasterVOs = new ArrayList<>();

    public ArrayList<Person> examinerSlaveVOs = new ArrayList<>();

    public ArrayList<Person> docdbAssigneeVOs = new ArrayList<>();

    public ArrayList<Person> docdbInventorVOs = new ArrayList<>();

    public ArrayList<Person> docdbaAssigneeVOs = new ArrayList<>();

    public ArrayList<Person> docdbaInventorVOs = new ArrayList<>();

    public ArrayList<MultiLangString> currentAssigneesNameVOs = new ArrayList<>();

    // citation
    public ArrayList<RelatedPatent> citedPatentVOs = new ArrayList<>();

    // priority
    public ArrayList<RelatedPatent> priorityPatentVOs = new ArrayList<>();

    // related
    public ArrayList<RelatedPatent> relatedPatentVOs = new ArrayList<>();

    // division
    public RelatedPatent dividedPatentVO;

    public String openDecisionNumber;

    public static PatentInfo findOne(String ptopid, String... fields) {
        // SolrSession session = SolrSession.newInstance();
        SolrQueryVO queryVO = new SolrQueryVO();
        queryVO.setQ("ptopid:\"" + ptopid + "\"");
        try {
            // session.processQuery(queryVO);
            // SolrQuery query = session.getQuery();

            SolrQuery query = SolrUtils.genQuery(queryVO);
            if (fields.length > 0) {
                // pto, country, stats, kindcode, doDate are necessary for
                // PatentDataPath
                // moreover, type is necessary for CN to download firstImage
                // from CNIPR
                query.addField("pto");
                query.addField("country");
                query.addField("stats");
                query.addField("kindcode");
                query.addField("doDate");
                query.addField("type");
                query.addField("patentNumber"); // for PatentDataPath
                query.addField("openNumberAll"); // for PatentDataPath
                query.addField("decisionNumberAll"); // for PatentDataPath
                query.addField("certificateNumberAll"); // for PatentDataPath
                query.addField("id");
            }

            for (String field : fields) {
                if ("cpcs".equals(field)) {
                    query.addField("cpcsNormal");
                } else if ("docdbAssignees".equals(field)) {
                    query.addField("docdbaAssignees");
                } else if ("docdbInventors".equals(field)) {
                    query.addField("docdbaInventors");
                } else if ("openDecisionNumber".equals(field)) {// 公開/公告 號
                    query.addField("openNumber");
                    query.addField("decisionNumber");
                    // query.addField("kindcode");
                }
                query.addField(field);
            }

            SolrQueryResult list = SolrUtils.queryInfos(query);
            if (list.getPatentInfoList().size() > 0) {
                SolrPatentInfo info2 = list.getPatentInfoList().get(0);
                PatentInfo patentInfo = fromSolrPatentInfo(info2);
                patentInfo.ptopid = ptopid;
                return patentInfo;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return null;
    }

    public static PatentInfo fromSolrPatentInfo(SolrPatentInfo solrPatentInfo) {
        PatentInfo p = new PatentInfo();
        BeanUtils.copyProperties(solrPatentInfo, p, SolrPatentInfo.class);
        p.id = solrPatentInfo.id;
        p.ptoVO = Pto.valueOf(solrPatentInfo.pto);
        p.country = solrPatentInfo.country;
        p.kindcode = solrPatentInfo.kindcode;
        p.doDate = solrPatentInfo.doDate;
        // MultiLangString
        p.titleVO = buildMultiLangString(solrPatentInfo.title);
        p.descriptionVO = buildMultiLangString(solrPatentInfo.description);
        p.briefVO = buildMultiLangString(solrPatentInfo.brief);
        p.claimVO = buildMultiLangString(solrPatentInfo.claim);
        // person info
        p.applicantVOs = buildPerson(solrPatentInfo.applicants);
        p.agentVOs = buildPerson(solrPatentInfo.agents);
        p.agentOperatorVOs = buildPerson(solrPatentInfo.agentOperators);
        p.assigneeVOs = buildPerson(solrPatentInfo.assignees);
        p.inventorVOs = buildPerson(solrPatentInfo.inventors);
        p.examinerMasterVOs = buildPerson(solrPatentInfo.examinerMasters);
        p.examinerSlaveVOs = buildPerson(solrPatentInfo.examinerSlaves);
        p.docdbAssigneeVOs = buildPerson(solrPatentInfo.docdbAssignees);
        p.docdbaAssigneeVOs = buildPerson(solrPatentInfo.docdbaAssignees);
        p.docdbInventorVOs = buildPerson(solrPatentInfo.docdbInventors);
        p.docdbaInventorVOs = buildPerson(solrPatentInfo.docdbaInventors);
        p.currentAssigneesNameVOs = buildMultiLangStringList(solrPatentInfo.currentAssigneesName);
        // citation openDecisionNumber
        p.citedPatentVOs = buildRelatedPatent(solrPatentInfo.citedPatents);
        p.priorityPatentVOs = buildRelatedPatent(solrPatentInfo.priorityPatents);
        p.relatedPatentVOs = buildRelatedPatent(solrPatentInfo.relatedPatents);

        if (solrPatentInfo.cpcsNormal != null && solrPatentInfo.cpcsNormal.size() == 0) {
            p.cpcs = solrPatentInfo.cpcs;
        } else {
            p.cpcs = solrPatentInfo.cpcsNormal;
        }

        p.openDecisionNumber = solrPatentInfo.decisionNumber;
        if (p.openDecisionNumber == null || p.openDecisionNumber.isEmpty()) {
            p.openDecisionNumber = solrPatentInfo.openNumber;
        }
        if (p.openDecisionNumber == null || p.openDecisionNumber.isEmpty()) {
            p.openDecisionNumber = "";
        } else {
            if (!p.openDecisionNumber.matches("^[A-Za-z]{2}.*") && p.country != null && !p.country.isEmpty()
                    || "US".equalsIgnoreCase(p.country) && p.openDecisionNumber.matches("^(RE|PP).*")) {
                // 如果號碼沒有以國家代碼（兩位字母）開頭（US的RE和PP除外）
                p.openDecisionNumber = p.country + p.openDecisionNumber;
            }
            if (!p.openDecisionNumber.matches(".*[A-Za-z]\\d{0,1}$") && p.kindcode != null && !p.kindcode.isEmpty()) {
                // 如果號碼沒有以kindcode（一位字母，或者一位字母加一位數字）結尾
                p.openDecisionNumber += p.kindcode;
            }
        }
        return p;
    }

    public static ArrayList<MultiLangString> buildMultiLangStringList(ArrayList<String> jsonStringList) {
        ArrayList<MultiLangString> objectList = new ArrayList<MultiLangString>();
        if (jsonStringList != null && jsonStringList.size() > 0) {
            for (String jsonString : jsonStringList) {
                try {
                    MultiLangString objectvo = new MultiLangString();
                    objectvo = new Gson().fromJson(jsonString, MultiLangString.class);
                    objectList.add(objectvo);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return objectList;
    }

    public static MultiLangString buildMultiLangString(String jsonString) {
        MultiLangString objectvo = new MultiLangString();
        try {
            objectvo = new Gson().fromJson(jsonString, MultiLangString.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return objectvo;
    }

    public static ArrayList<Person> buildPerson(ArrayList<String> jsonStringList) {
        ArrayList<Person> objectPersonvo = new ArrayList<Person>();
        if (jsonStringList != null && jsonStringList.size() > 0) {
            JsonParser jsonParser = new JsonParser();
            for (String jsonString : jsonStringList) {
                try {
                    Person objectvo = new Person();
                    JsonObject jo = (JsonObject) jsonParser.parse(jsonString);
                    if (jo.has("name")) {
                        objectvo.name = jo.getAsJsonObject("name").get("origin").toString().replace("\"", "");
                    }
                    if (jo.has("country")) {
                        objectvo.country = jo.getAsJsonObject("country").get("origin").toString().replace("\"", "");
                    }
                    if (jo.has("address")) {
                        objectvo.address = jo.getAsJsonObject("address").get("origin").toString().replace("\"", "");
                    }
                    objectPersonvo.add(objectvo);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return objectPersonvo;
    }

    public static ArrayList<RelatedPatent> buildRelatedPatent(ArrayList<String> jsonStringList) {
        ArrayList<RelatedPatent> objectRelatedPatentvo = new ArrayList<RelatedPatent>();
        if (jsonStringList != null && jsonStringList.size() > 0) {
            for (String jsonString : jsonStringList) {
                try {
                    jsonString = replaceDate(jsonString);
                    RelatedPatent objectvo = new RelatedPatent();
                    Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").create();

                    objectvo = gson.fromJson(jsonString, RelatedPatent.class);
                    objectRelatedPatentvo.add(objectvo);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return objectRelatedPatentvo;
    }

    private static String replaceDate(String jsonString) {

        boolean matcher = jsonString.contains("$date");
        if (!matcher) {
            return jsonString;
        }
        JsonObject jsonObject = new JsonParser().parse(jsonString).getAsJsonObject();

        List<String> keys = new ArrayList<String>();
        for (Entry<String, JsonElement> e : jsonObject.entrySet()) {
            keys.add(e.getKey());
        }

        for (String currentDynamicKey : keys) {
            JsonElement currentDynamicJsonElement = jsonObject.get(currentDynamicKey);
            JsonObject currentDynamicJsonObject = currentDynamicJsonElement.getAsJsonObject();
            if (currentDynamicJsonObject.has("$date")) {
                try {
                    JsonElement realdate = currentDynamicJsonObject.get("$date");
                    jsonObject.remove(currentDynamicJsonElement.getAsString());
                    jsonObject.add(currentDynamicKey, realdate);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return jsonObject.toString();

    }

}
