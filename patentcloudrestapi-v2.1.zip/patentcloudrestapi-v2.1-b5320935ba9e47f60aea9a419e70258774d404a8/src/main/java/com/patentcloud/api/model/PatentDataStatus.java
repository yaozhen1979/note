package com.patentcloud.api.model;

import java.util.Date;

public class PatentDataStatus {

    private String id;

    private String pto;

    private String target;

    private Integer patentType;

    private Integer patentStatus;

    private Long patentCount;

    private Date earliestUpdateDateTime;

    private Date latestUpdateDateTime;

    private Date checkDateTime;

    private Date createdDateTime;

    private Date modifiedDateTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPto() {
        return pto;
    }

    public void setPto(String pto) {
        this.pto = pto;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public Integer getPatentType() {
        return patentType;
    }

    public void setPatentType(Integer patentType) {
        this.patentType = patentType;
    }

    public Integer getPatentStatus() {
        return patentStatus;
    }

    public void setPatentStatus(Integer patentStatus) {
        this.patentStatus = patentStatus;
    }

    public Long getPatentCount() {
        return patentCount;
    }

    public void setPatentCount(Long patentCount) {
        this.patentCount = patentCount;
    }

    public Date getEarliestUpdateDateTime() {
        return earliestUpdateDateTime;
    }

    public void setEarliestUpdateDateTime(Date earliestUpdateDateTime) {
        this.earliestUpdateDateTime = earliestUpdateDateTime;
    }

    public Date getLatestUpdateDateTime() {
        return latestUpdateDateTime;
    }

    public void setLatestUpdateDateTime(Date latestUpdateDateTime) {
        this.latestUpdateDateTime = latestUpdateDateTime;
    }

    public Date getCheckDateTime() {
        return checkDateTime;
    }

    public void setCheckDateTime(Date checkDateTime) {
        this.checkDateTime = checkDateTime;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public Date getModifiedDateTime() {
        return modifiedDateTime;
    }

    public void setModifiedDateTime(Date modifiedDateTime) {
        this.modifiedDateTime = modifiedDateTime;
    }

    public String generateId() {
        StringBuffer sb = new StringBuffer();
        if (pto != null) {
            sb.append(pto);
        }
        sb.append("|");
        if (target != null) {
            sb.append(target);
        }
        sb.append("|");
        if (patentType != null) {
            sb.append(patentType);
        }
        sb.append("|");
        if (patentStatus != null) {
            sb.append(patentStatus);
        }
        return sb.toString();
    }
}
