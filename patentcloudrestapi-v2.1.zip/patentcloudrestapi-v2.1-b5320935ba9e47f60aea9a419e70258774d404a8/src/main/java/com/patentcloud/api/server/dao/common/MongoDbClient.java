package com.patentcloud.api.server.dao.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.patentcloud.api.model.RequestLog;
import com.patentcloud.api.util.EncrypUtil;
import com.patentcloud.api.util.config.ConfigProperties;

/**
 * A Mongo DB client
 * 
 * @author Allan Huang
 */
public class MongoDbClient {

    private static final Logger log = LoggerFactory.getLogger(MongoDbClient.class);

    private static final int MAX_LOGGER_THREAD_SIZE = Runtime.getRuntime().availableProcessors() * 2;

    private static final int MAX_LOG_QUEUE_SIZE = 500;

    private static final MongoDbClient INSTANCE = new MongoDbClient();

    public static MongoDbClient getInstance() {
        return INSTANCE;
    }

    private MongoDbClient() {
        super();
    }

    private ExecutorService logger;

    private BlockingQueue<RequestLog> logQueue;

    private boolean shutdown = false;

    /**
     * A configuration of MongoDB client
     */
    private MongoDbClientConfig clientConfig;

    /**
     * A MongoDB client is responsible for accessing remote MongoDB server.
     */
    private MongoClient mongoClient;

    /**
     * Start up a MongoDB client
     */
    public final void startUp() {
        synchronized (this) {
            if (this.mongoClient != null) {
                return;
            }
        }

        log.info("Start to start up a MongoDB client...");

        this.clientConfig = ConfigProperties.getInstance().getMongoDbClientConfig();
        log.info("MongoDB client config: {}", clientConfig);

        boolean authorized = false;

        try {
            ServerAddress serverAddress = new ServerAddress(this.clientConfig.getMongoDbHost(),
                    this.clientConfig.getMongoDbPort());
            List<MongoCredential> credentialsList = Collections.singletonList(MongoCredential.createCredential(
                    this.clientConfig.getUserName(), "admin", this.clientConfig.getPassword().toCharArray()));

            this.mongoClient = new MongoClient(serverAddress, credentialsList);
            authorized = true;

        } catch (MongoException e) {
            MongoDbClientException exception = new MongoDbClientException("Failed to connect a MongoDB server.", e);
            exception.addContextValue("MongoDbHost", this.clientConfig.getMongoDbHost());
            exception.addContextValue("MongoDbPort", this.clientConfig.getMongoDbPort());
            exception.addContextValue("UserName", this.clientConfig.getUserName());
            exception.addContextValue("Password", EncrypUtil.maskPassword(this.clientConfig.getPassword()));

            throw exception;

        } finally {
            if (this.mongoClient != null && !authorized) {
                this.shutdown();
            }
        }

        this.logQueue = new ArrayBlockingQueue<>(MAX_LOG_QUEUE_SIZE);
        this.logger = Executors.newFixedThreadPool(MAX_LOGGER_THREAD_SIZE);

        for (int i = 0; i < MAX_LOGGER_THREAD_SIZE; i++) {
            this.logger.submit(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        try {
                            RequestLog requestLog = logQueue.poll(100, TimeUnit.MILLISECONDS);

                            if (requestLog != null) {
                                insertToMongoDb(requestLog);
                            }
                            TimeUnit.MILLISECONDS.sleep(100);

                        } catch (InterruptedException e) {
                            // nothing to do
                        }

                        if (shutdown) {
                            break;
                        }
                    }
                }
            });
        }

        log.info("Finish to start up a MongoDB client, connection: {},\nmongo client options: {}", this,
                this.mongoClient.getMongoClientOptions());
    }

    /**
     * Shutdown a MongoDB client
     */
    public final void shutdown() {
        synchronized (this) {
            if (this.mongoClient == null) {
                return;
            }
        }

        log.info("Start to shutdown a MongoDB client...");

        this.shutdown = true;
        this.logger.shutdown();
        try {
            // Important! Wait until all tasks have completed execution after a
            // shutdown request
            this.logger.awaitTermination(Integer.MAX_VALUE, TimeUnit.NANOSECONDS);

        } catch (InterruptedException e) {
            // nothing to do
        }
        this.logger = null;

        this.mongoClient.close();
        this.mongoClient = null;

        log.info("Finish to shutdown a MongoDB client.");
    }

    public final JsonElement getClientConfig() {
        if (this.mongoClient == null) {
            return new JsonPrimitive("MonogDB client is not started up.");
        }

        return this.clientConfig.toJsonObject();
    }

    /**
     * Insert the log of a user's request to MongoDB in background thread pool
     * 
     * @param requestLog
     *            a log retains the information of a user's request
     */
    public void insertLog(final RequestLog requestLog) {
        if (requestLog == null) {
            return;
        }

        if (this.mongoClient == null) {
            throw new MongoDbClientException("MongoDB client is not started yet.");
        }

        try {
            boolean successful = this.logQueue.offer(requestLog, 300, TimeUnit.MILLISECONDS);

            if (!successful) {
                log.warn("Failed to insert one log to log db because logQueue is full");
            }
        } catch (InterruptedException e) {
            // nothing to do
        }
    }

    private ObjectId insertToMongoDb(RequestLog requestLog) {
        MongoDatabase logDatabase = this.mongoClient.getDatabase(this.clientConfig.getMongoDbName());

        Document paramDocument = new Document();
        Set<Entry<String, String[]>> parameterSet = requestLog.getParameter().entrySet();

        for (Entry<String, String[]> paramEntry : parameterSet) {
            String[] valueArray = paramEntry.getValue();
            List<String> valueList = Arrays.asList(valueArray);
            paramDocument.append(paramEntry.getKey(), valueList);
        }

        Document logDocument = new Document("clientId", requestLog.getClientId())
                .append("clientHost", requestLog.getClientHost()).append("servicePath", requestLog.getServicePath())
                .append("parameter", paramDocument).append("httpStatus", requestLog.getHttpStatus())
                .append("createdDateTime", requestLog.getCreatedDateTime())
                .append("executionTime", requestLog.getExecutionTime());

        if (requestLog.getErrorMessage() != null) {
            logDocument.append("errorMessage", requestLog.getErrorMessage());
        }

        MongoCollection<Document> logCollection = logDatabase.getCollection("Log");
        logCollection.insertOne(logDocument);

        ObjectId objectId = logDocument.getObjectId("_id");
        log.info("Finish to insert one log to log db. mongo objectId: {}", objectId);

        return objectId;
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("config", this.clientConfig).build();
    }
}
