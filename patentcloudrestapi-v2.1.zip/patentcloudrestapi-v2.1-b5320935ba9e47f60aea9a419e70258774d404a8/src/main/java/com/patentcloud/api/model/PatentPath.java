package com.patentcloud.api.model;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class PatentPath {
    
    public PatentInfo info = new PatentInfo();

    public List<Path> paths = new ArrayList<>();

    public PatentPath(PatentInfo info, Path... paths) {
        this.info = info;
        for (Path path : paths) {
            this.paths.add(path);
        }
    }

    public PatentPath(PatentInfo info, Path paths) {
        this.info = info;
        this.paths.add(paths);
    }
}
