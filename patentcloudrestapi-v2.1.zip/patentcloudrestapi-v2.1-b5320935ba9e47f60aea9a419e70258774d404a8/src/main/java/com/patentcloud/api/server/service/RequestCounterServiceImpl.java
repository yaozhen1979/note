package com.patentcloud.api.server.service;

import java.util.Date;

import com.patentcloud.api.model.Member;
import com.patentcloud.api.model.RequestCounter;
import com.patentcloud.api.server.dao.RequestCounterDao;

public class RequestCounterServiceImpl implements RequestCounterService {

    private RequestCounterDao requestCounterDao;

    private MemberService memberService;

    public void setRequestCounterDao(RequestCounterDao requestCounterDao) {
        this.requestCounterDao = requestCounterDao;
    }

    public void setMemberService(MemberService memberService) {
        this.memberService = memberService;
    }

    public void updateRequestCounter(String username) {
        Member memberInfo = this.memberService.getMemberInfo(username);

        Date now = new Date();
        RequestCounter requestCounterInfo = requestCounterDao.getRequestCounterByDate(memberInfo.getId(), now);

        int count = 1;
        if (requestCounterInfo != null) {
            requestCounterInfo.setRequestCount(requestCounterInfo.getRequestCount() + 1);
            requestCounterDao.updateRequestCounter(requestCounterInfo);

        } else {
            requestCounterInfo = new RequestCounter();
            requestCounterInfo.setCreatedDateTime(new Date());

            requestCounterInfo.setUserId(memberInfo.getId());
            requestCounterInfo.setRequestCount(count);
            requestCounterInfo.setCreatedDateTime(new Date());
            requestCounterDao.addRequestCounter(requestCounterInfo);
        }
    }
}
