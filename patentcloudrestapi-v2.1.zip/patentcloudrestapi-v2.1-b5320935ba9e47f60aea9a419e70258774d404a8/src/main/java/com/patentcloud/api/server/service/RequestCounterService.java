package com.patentcloud.api.server.service;

public interface RequestCounterService {

    void updateRequestCounter(String username);
}
