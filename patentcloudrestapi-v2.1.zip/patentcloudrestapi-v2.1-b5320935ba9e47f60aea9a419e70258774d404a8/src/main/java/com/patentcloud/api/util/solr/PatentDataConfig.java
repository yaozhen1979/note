package com.patentcloud.api.util.solr;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.patentcloud.api.common.Mapping;
import com.patentcloud.api.constant.Pto;
import com.patentcloud.api.util.config.ConfigProperties;
public class PatentDataConfig {

    public static final Map<Pto, List<File>> DATA_PATH_PTO = new HashMap<>();

    public static final Map<Pto, List<File>> CACHE_PATH_PTO = new HashMap<>();

    private static final Map<Pto, List<File>> EPOOPS_PATH_PTO = new HashMap<>();

    public static final Map<Pto, List<File>> GOOGLE_PATENT_PATH_PTO = new HashMap<>();

    public static final Map<Pto, List<File>> CNIPR_PATH_PTO = new HashMap<>();

    static {
        reload();
    }

    private static void reload() {
        for (Pto pto : Pto.values()) {
            List<File> list = new ArrayList<>();

            String confkey = String.format("data.path.%s", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("data.path.%s2", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("data.path.%s3", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("data.path", list);
            addConfigList("data.path2", list);
            addConfigList("data.path3", list);
            DATA_PATH_PTO.put(pto, list);

            list = new ArrayList<>();
            confkey = String.format("cache.path.%s", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cache.path.%s2", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cache.path.%s3", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("cache.path", list);
            addConfigList("cache.path2", list);
            addConfigList("cache.path3", list);
            CACHE_PATH_PTO.put(pto, list);

            list = new ArrayList<>();
            confkey = String.format("epoops.path.%s", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("epoops.path.%s2", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("epoops.path.%s3", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("epoops.path", list);
            addConfigList("epoops.path2", list);
            addConfigList("epoops.path3", list);
            EPOOPS_PATH_PTO.put(pto, list);

            list = new ArrayList<>();
            confkey = String.format("googlepatent.path.%s", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("googlepatent.path.%s2", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("googlepatent.path.%s3", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);

            addConfigList("googlepatent.path", list);
            addConfigList("googlepatent.path2", list);
            addConfigList("googlepatent.path3", list);
            GOOGLE_PATENT_PATH_PTO.put(pto, list);

            list = new ArrayList<>();
            confkey = String.format("cnipr.path.%s", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cnipr.path.%s2", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            confkey = String.format("cnipr.path.%s3", Mapping.ptoPathMap.get(pto));
            addConfigList(confkey, list);
            addConfigList("cnipr.path", list);
            addConfigList("cnipr.path2", list);
            addConfigList("cnipr.path3", list);
            CNIPR_PATH_PTO.put(pto, list);
        }
    }

    private static void addConfigList(String configKey, List<File> list) {
        String configValue = ConfigProperties.getInstance().getString(configKey, "");

        File file = new File(configValue);

        if (file.isDirectory()) {
            list.add(file);
        }
    }

    public static boolean isPtopidEnabled() {
        boolean ptopidEnabled = ConfigProperties.getInstance().getBoolean("ptopidEnabled", false);

        return ptopidEnabled;
    }
}