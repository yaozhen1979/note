package com.patentcloud.api.server.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.patentcloud.api.model.PatentDataStatus;

public class PatentDataStatusRowMapper implements RowMapper<PatentDataStatus> {

    public PatentDataStatus mapRow(ResultSet rs, int index) throws SQLException {
        PatentDataStatus patentDataStatus = new PatentDataStatus();

        patentDataStatus.setId(rs.getString("ID"));
        patentDataStatus.setPto(rs.getString("Pto"));
        patentDataStatus.setTarget(rs.getString("Target"));
        patentDataStatus.setPatentType(rs.getInt("PatentType"));
        patentDataStatus.setPatentStatus(rs.getInt("PatentStatus"));
        patentDataStatus.setPatentCount(rs.getLong("PatentCount"));
        patentDataStatus.setEarliestUpdateDateTime(rs.getTimestamp("EarliestUpdateDateTime"));
        patentDataStatus.setLatestUpdateDateTime(rs.getTimestamp("LatestUpdateDateTime"));
        patentDataStatus.setCheckDateTime(rs.getTimestamp("CheckDateTime"));
        patentDataStatus.setCreatedDateTime(rs.getTimestamp("CreatedDateTime"));
        patentDataStatus.setModifiedDateTime(rs.getTimestamp("ModifiedDateTime"));

        return patentDataStatus;
    }
}
