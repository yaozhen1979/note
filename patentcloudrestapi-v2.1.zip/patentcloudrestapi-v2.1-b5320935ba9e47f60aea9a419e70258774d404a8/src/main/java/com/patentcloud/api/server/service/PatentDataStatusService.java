package com.patentcloud.api.server.service;

import java.util.List;

import com.patentcloud.api.model.PatentDataStatus;

public interface PatentDataStatusService {

    void updatePatentDataStatus();

    PatentDataStatus findPatentDataStatus(String target, Integer stat, Integer type);

    List<PatentDataStatus> findAllPatentDataStatus();
}
