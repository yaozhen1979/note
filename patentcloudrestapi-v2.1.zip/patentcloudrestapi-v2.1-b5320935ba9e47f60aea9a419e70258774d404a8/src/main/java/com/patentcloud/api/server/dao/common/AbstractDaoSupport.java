package com.patentcloud.api.server.dao.common;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

public abstract class AbstractDaoSupport extends NamedParameterJdbcDaoSupport {

    private static DataSource dataSource;

    public AbstractDaoSupport() {
        if (dataSource != null) {
            super.setDataSource(dataSource);
        }
    }

    @Override
    protected void initTemplateConfig() {
        super.initTemplateConfig();
        if (dataSource == null) {
            dataSource = super.getDataSource();
        }
    }

    protected Map<String, Object> getParamMap(Object object) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        if (object != null) {
            Method[] methods = object.getClass().getMethods();
            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.indexOf("get") == 0 && methodName.length() > 3) {
                    String filedName = methodName.substring(3, 4).toLowerCase() + methodName.substring(4);
                    try {
                        paramMap.put(filedName, method.invoke(object));
                    } catch (Exception e) {
                    }
                }
            }
        }
        return paramMap;
    }
}
