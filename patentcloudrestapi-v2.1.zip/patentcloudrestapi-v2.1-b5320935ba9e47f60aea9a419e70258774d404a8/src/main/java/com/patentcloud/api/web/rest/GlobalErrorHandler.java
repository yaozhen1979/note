package com.patentcloud.api.web.rest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.google.gson.JsonObject;

@ControllerAdvice
public class GlobalErrorHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalErrorHandler.class);

    @ExceptionHandler(value = { IllegalArgumentException.class, IllegalStateException.class })
    public ResponseEntity<String> handleIllegalRequest(RuntimeException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "system.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.BAD_REQUEST);

        return responseEntity;
    }

    @ExceptionHandler(value = { Exception.class })
    public ResponseEntity<String> handleGeneralException(Exception exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "system.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }
}
