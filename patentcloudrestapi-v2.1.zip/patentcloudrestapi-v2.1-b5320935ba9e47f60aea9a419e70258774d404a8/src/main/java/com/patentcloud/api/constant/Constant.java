package com.patentcloud.api.constant;

import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.lang3.time.FastDateFormat;

public class Constant {

    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    public static final String APPLICATION_XML_VALUE = "application/xml;charset=UTF-8";

    public static final String APPLICATION_PDF_VALUE = "application/pdf";

    public static final String APPLICATION_ZIP_VALUE = "application/zip";
    
    public static final String APPLICATION_EXCEL_VALUE = "application/vnd.ms-excel";

    public static final String ISO_8601_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String ISO_8601_MILLISEC_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public static final FastDateFormat ISO_8601_FORMAT = FastDateFormat.getInstance(Constant.ISO_8601_PATTERN,
            TimeZone.getTimeZone("UTC"), Locale.US);
}
