package com.patentcloud.api.util.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Tries to look up the file name in the classpath and loads the specified
 * properties file.
 *
 * @author Allan Huang
 */
public class SystemProperties extends Properties {

    private static final long serialVersionUID = -5740758569343633436L;

    private static final String BASE_PATH_KEY = "com.patentcloud.api.resources";

    private static final String HOME_DIR_NAME = ".patentcloud_api";

    private static final Logger log = LoggerFactory.getLogger(SystemProperties.class);

    /**
     * A kind of the constructor.
     *
     * @param filePath
     *            the URL of the specified properties file in the classpath, the
     *            name of the specified file in a CONFIG_DIR_PATH_KEY directory,
     *            or the name of the specified file in a CONFIG_HOME_DIR_NANE
     *            directory of the "use.home".
     */
    public SystemProperties(String filePath) {
        this(filePath, false);
    }

    /**
     * A kind of the constructor.
     *
     * @param filePath
     *            the URL of the specified properties file in the classpath, the
     *            name of the specified file in a CONFIG_DIR_PATH_KEY directory,
     *            or the name of the specified file in a CONFIG_HOME_DIR_NANE
     *            directory of the "use.home".
     * @param throwOnMissing
     *            a flag whether an exception should be thrown for a missing
     *            value
     */
    public SystemProperties(String filePath, boolean throwOnMissing) {
        this.filePath = filePath;
        this.throwOnMissing = throwOnMissing;

        // load a specified properties file from the classpath
        boolean successful = this.loadFromClasspath();

        if (!successful) {
            URL configUrl = SystemProperties.class.getResource(this.filePath);

            throw new SystemPropertiesException("Fail to load a properties file from classpath.")
                    .addContextValue("Classpath", configUrl);
        }
    }

    /**
     * The URL of the specified properties file in the classpath, the name of
     * the specified file in a BASE_PATH_KEY directory, or the name of the
     * specified file in a HOME_DIR_NAME directory of the "use.home".
     */
    private String filePath;

    /**
     * Getter method for filePath
     *
     * @return the name or classpath of a properties file
     */
    public String getFilePath() {
        return this.filePath;
    }

    /**
     * A flag whether an exception should be thrown for a missing value.
     */
    private boolean throwOnMissing;

    /**
     * Getter method for field 'throwOnMissing'
     *
     * @return Returns true if an exception should be thrown for a missing
     *         value.
     */
    public boolean isThrowOnMissing() {
        return this.throwOnMissing;
    }

    private boolean loadFromBasePath() {
        String basePath = System.getProperty(BASE_PATH_KEY);

        if (StringUtils.isBlank(basePath)) {
            log.warn(
                    "Failed to read a system property: {}. Add a '-D{}=folderpath' argument into java command line if necessary.",
                    BASE_PATH_KEY);
            return false;
        }

        StringBuilder filePath = new StringBuilder(basePath);
        filePath.append(File.separatorChar);

        StringBuilder fileNameSb = new StringBuilder(this.filePath);
        if (fileNameSb.charAt(0) == '/') {
            fileNameSb.deleteCharAt(0);
        }
        filePath.append(fileNameSb);

        File file = new File(filePath.toString());

        if (!file.exists()) {
            log.warn("Failed to load a properties file. filePath: {}", filePath);
            return false;
        }

        InputStream input = null;

        try {
            input = new FileInputStream(file);
            this.load(input);
            log.info("Finish to load a properties file. filePath: {}", filePath);

            return true;

        } catch (IOException e) {
            log.warn("Fail to load a properties file. filePath: {}", filePath, e);

        } finally {
            IOUtils.closeQuietly(input);
        }

        return false;
    }

    private boolean loadFromHomeDir() {
        String userHomeDir = System.getProperty("user.home");
        StringBuilder filePath = new StringBuilder(userHomeDir);
        filePath.append(File.separatorChar);
        filePath.append(HOME_DIR_NAME);
        filePath.append(File.separatorChar);

        StringBuilder fileNameSb = new StringBuilder(this.filePath);
        if (fileNameSb.charAt(0) == '/') {
            fileNameSb.deleteCharAt(0);
        }
        filePath.append(fileNameSb);

        File file = new File(filePath.toString());

        if (!file.exists()) {
            log.warn("Failed to load a properties file. filePath: {}", filePath);
            return false;
        }

        InputStream input = null;

        try {
            input = new FileInputStream(file);
            this.load(input);
            log.info("Finish to load a properties file. filePath: {}", filePath);

            return true;

        } catch (IOException e) {
            log.warn("Fail to load a properties file. filePath: {}", filePath, e);

        } finally {
            IOUtils.closeQuietly(input);
        }

        return false;
    }

    private boolean loadFromClasspath() {
        URL classpath = SystemProperties.class.getResource(this.filePath);
        InputStream input = SystemProperties.class.getResourceAsStream(this.filePath);

        if (input == null) {
            log.warn("Failed to load a properties file. classpath: {}", classpath);
            return false;
        }

        try {
            this.load(input);
            log.info("Finish to load a properties file. classpath: {}", classpath);

            return true;

        } catch (IOException e) {
            log.warn("Fail to load a properties file. classpath: {}", classpath, e);

        } finally {
            IOUtils.closeQuietly(input);

        }

        return false;
    }

    /**
     * Throws an exception for a missing value.
     *
     * @param key
     *            the key of a missing value.
     */
    private void throwMissingPropertyException(String key) {
        throw new NoSuchElementException(String.format("Key '%s' does not map to an existing object!", key));
    }

    /**
     * Gets the list of the keys contained in the properties.
     *
     * @return an iterator of keys.
     */
    public Iterator<String> getKeys() {
        Set<String> keys = new HashSet<String>();

        for (Object key : this.keySet()) {
            String stringKey = (String) key;
            keys.add(stringKey);
        }

        return keys.iterator();
    }

    /**
     * Gets the list of the keys contained in the properties.
     *
     * @param prefix
     *            the prefix to test against.
     * @return an iterator of keys that match the prefix.
     */
    public Iterator<String> getKeys(String prefix) {
        Set<String> keys = new HashSet<>();

        for (Object key : this.keySet()) {
            String stringKey = (String) key;
            boolean matching = StringUtils.startsWith(stringKey, prefix);

            if (matching) {
                keys.add(stringKey);
            }
        }

        return keys.iterator();
    }

    /**
     * Gets a boolean associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the boolean value of this key.
     */
    public boolean getBoolean(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return false;
            }
        }

        String value = super.getProperty(key);
        boolean booleanValue = BooleanUtils.toBoolean(value);

        return booleanValue;
    }

    /**
     * Gets a boolean associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the boolean value of this key.
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        boolean booleanValue = BooleanUtils.toBoolean(value);

        return booleanValue;
    }

    /**
     * Gets a boolean associated with the given properties key and tries to
     * convert it into a Boolean object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the boolean value of this key converted to a Boolean object.
     */
    public Boolean getBoolean(String key, Boolean defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        boolean booleanValue = BooleanUtils.toBoolean(value);

        return booleanValue;
    }

    /**
     * Gets a byte associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the byte value of this key.
     */
    public byte getByte(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0;
            }
        }

        String value = super.getProperty(key);
        byte byteValue = NumberUtils.toByte(value);

        return byteValue;
    }

    /**
     * Gets a byte associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the byte value of this key.
     */
    public byte getByte(String key, byte defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        byte byteValue = NumberUtils.toByte(value);

        return byteValue;
    }

    /**
     * Gets a byte associated with the given properties key and tries to convert
     * it into a Byte object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the byte value of this key converted to a Byte object.
     */
    public Byte getByte(String key, Byte defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        byte byteValue = NumberUtils.toByte(value);

        return byteValue;
    }

    /**
     * Gets a double associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the double value of this key.
     */
    public double getDouble(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0d;
            }
        }

        String value = super.getProperty(key);
        double doubleValue = NumberUtils.toDouble(value);

        return doubleValue;
    }

    /**
     * Gets a double associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the double value of this key.
     */
    public double getDouble(String key, double defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        double doubleValue = NumberUtils.toDouble(value);

        return doubleValue;
    }

    /**
     * Gets a double associated with the given properties key and tries to
     * convert it into a Double object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the double value of this key converted to a Double object.
     */
    public Double getDouble(String key, Double defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        Double doubleValue = NumberUtils.createDouble(value);

        return doubleValue;
    }

    /**
     * Gets a float associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the float value of this key.
     */
    public float getFloat(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0f;
            }
        }

        String value = super.getProperty(key);
        float floatValue = NumberUtils.toFloat(value);

        return floatValue;
    }

    /**
     * Gets a float associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the float value of this key.
     */
    public float getFloat(String key, float defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        float floatValue = NumberUtils.toFloat(value);

        return floatValue;
    }

    /**
     * Gets a float associated with the given properties key and tries to
     * convert it into a Float object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the float value of this key converted to a Float object.
     */
    public Float getFloat(String key, Float defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        Float floatValue = NumberUtils.createFloat(value);

        return floatValue;
    }

    /**
     * Gets a int associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the int value of this key.
     */
    public int getInt(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0;
            }
        }

        String value = super.getProperty(key);
        int intValue = NumberUtils.toInt(value);

        return intValue;
    }

    /**
     * Gets a int associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the int value of this key.
     */
    public int getInt(String key, int defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        int intValue = NumberUtils.toInt(value);

        return intValue;
    }

    /**
     * Gets a int associated with the given properties key and tries to convert
     * it into a Integer object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the int value of this key converted to a Integer object.
     */
    public Integer getInteger(String key, Integer defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        Integer intValue = NumberUtils.createInteger(value);

        return intValue;
    }

    /**
     * Gets a long associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the long value of this key.
     */
    public long getLong(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0l;
            }
        }

        String value = super.getProperty(key);
        long longValue = NumberUtils.toLong(value);

        return longValue;
    }

    /**
     * Gets a long associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the long value of this key.
     */
    public long getLong(String key, long defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        long longValue = NumberUtils.toLong(value);

        return longValue;
    }

    /**
     * Gets a long associated with the given properties key and tries to convert
     * it into a Long object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the long value of this key converted to a Long object.
     */
    public Long getLong(String key, Long defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        Long longValue = NumberUtils.createLong(value);

        return longValue;
    }

    /**
     * Gets a short associated with the given properties key.
     *
     * @param key
     *            the properties key.
     * @return the short value of this key.
     */
    public short getShort(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return 0;
            }
        }

        String value = super.getProperty(key);
        short shortValue = NumberUtils.toShort(value);

        return shortValue;
    }

    /**
     * Gets a short associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the short value of this key.
     */
    public short getShort(String key, short defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        short shortValue = NumberUtils.toShort(value);

        return shortValue;
    }

    /**
     * Gets a short associated with the given properties key and tries to
     * convert it into a Short object.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the short value of this key converted to a Short object.
     */
    public Short getShort(String key, Short defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        short shortValue = NumberUtils.toShort(value);

        return shortValue;
    }

    /**
     * Gets a BigDecimal associated with the given properties key.<br>
     *
     * @param key
     *            the properties key.
     * @return the BigDecimal value of this key.
     */
    public BigDecimal getBigDecimal(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return BigDecimal.ZERO;
            }
        }

        String value = super.getProperty(key);
        BigDecimal bigDecimalValue = NumberUtils.createBigDecimal(value);

        return bigDecimalValue;
    }

    /**
     * Gets a BigDecimal associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the BigDecimal value of this key.
     */
    public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        BigDecimal bigDecimalValue = NumberUtils.createBigDecimal(value);

        return bigDecimalValue;
    }

    /**
     * Gets a BigInteger associated with the given properties key.<br>
     *
     * @param key
     *            the properties key.
     * @return the BigInteger value of this key.
     */
    public BigInteger getBigInteger(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return BigInteger.ZERO;
            }
        }

        String value = super.getProperty(key);
        BigInteger bigIntegerValue = NumberUtils.createBigInteger(value);

        return bigIntegerValue;
    }

    /**
     * Gets a BigInteger associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the BigInteger value of this key.
     */
    public BigInteger getBigInteger(String key, BigInteger defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        BigInteger bigIntegerValue = NumberUtils.createBigInteger(value);

        return bigIntegerValue;
    }

    /**
     * Gets a String associated with the given properties key.<br>
     *
     * @param key
     *            the properties key.
     * @return the String value of this key.
     */
    public String getString(String key) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            if (this.throwOnMissing) {
                this.throwMissingPropertyException(key);
            } else {
                return null;
            }
        }

        String value = super.getProperty(key);

        return value;
    }

    /**
     * Gets a String associated with the given properties key.<br>
     * If the property has no value or the key is non-existent, the passed in
     * default value will be returned.
     *
     * @param key
     *            the properties key.
     * @param defaultValue
     *            the default value.
     * @return the String value of this key.
     */
    public String getString(String key, String defaultValue) {
        boolean hasKey = this.containsKey(key);

        if (false == hasKey) {
            return defaultValue;
        }

        String value = super.getProperty(key);

        if (value == null) {
            return defaultValue;
        }

        return value;
    }

    /**
     * Overrides the {@link java.util.Properties#getProperty(String)} method and
     * replace its function with
     * {@link com.patentcloud.api.util.config.SystemProperties#getString(String)}
     * method.
     */
    public String getProperty(String key) {
        return this.getString(key);
    }

    /**
     * Overrides the {@link java.util.Properties#getProperty(String, String)}
     * method and replace its function with
     * {@link com.patentcloud.api.util.config.SystemProperties#getString(String, String)}
     * method.
     */
    public String getProperty(String key, String defaultValue) {
        return this.getString(key, defaultValue);
    }
}
