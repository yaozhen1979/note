package com.patentcloud.api.util.nlp;

import java.io.StringReader;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

/**
 * A container that wraps a result returned by NLP service server
 * 
 * @author Allan Huang
 */
public class NlpResult {

    private int httpStatus;

    private String entity;

    private JsonElement entityJson;

    public NlpResult(int httpStatus, String entity) {
        this.httpStatus = httpStatus;
        this.entity = entity;
    }

    public int getHttpStatus() {
        return this.httpStatus;
    }

    public String getEntity() {
        return entity;
    }

    public JsonObject getEntityAsJsonObject() {
        if (StringUtils.isBlank(this.entity)) {
            return null;
        }

        if (this.entityJson == null) {
            // configure this parser to be be liberal in what it accepts.
            StringReader stringReader = new StringReader(this.entity);
            JsonReader jsonReader = new JsonReader(stringReader);
            jsonReader.setLenient(true);

            JsonParser parser = new JsonParser();
            this.entityJson = parser.parse(jsonReader);
            boolean objectType = this.entityJson.isJsonObject();

            if (!objectType) {
                throw new IllegalStateException("entity is not a json object");
            }
        }

        return this.entityJson.getAsJsonObject();
    }

    public JsonArray getEntityAsJsonArray() {
        if (StringUtils.isBlank(this.entity)) {
            return null;
        }

        if (this.entityJson == null) {
            // configure this parser to be be liberal in what it accepts.
            StringReader stringReader = new StringReader(this.entity);
            JsonReader jsonReader = new JsonReader(stringReader);
            jsonReader.setLenient(true);

            JsonParser parser = new JsonParser();
            this.entityJson = parser.parse(jsonReader);
            boolean arrayType = this.entityJson.isJsonArray();

            if (!arrayType) {
                throw new IllegalStateException("entity is not a json array");
            }
        }

        return this.entityJson.getAsJsonArray();
    }
}
