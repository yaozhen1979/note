package com.patentcloud.api.util.nlp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.pool.PoolStats;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.patentcloud.api.util.config.ConfigProperties;
import com.patentcloud.api.util.nlp.parameter.KeywordExtractorParameter;
import com.patentcloud.api.util.nlp.parameter.ParameterMap;
import com.patentcloud.api.util.nlp.parameter.QueryExpansionParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByBriefParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByClaimParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryParameter;

/**
 * A HTTP-based NLP (Natural language processing) service client
 * 
 * @author Allan Huang
 */
public class NlpServiceClient {

    private static final Logger log = LoggerFactory.getLogger(NlpServiceClient.class);

    private static int MAX_RETRY_COUNT = 3;

    private static final String USER_AGENT = "PatentcloudNlpServiceClient/1.0";

    private static final NlpServiceClient INSTANCE = new NlpServiceClient();

    public static NlpServiceClient getInstance() {
        return INSTANCE;
    }

    private NlpServiceClient() {
        super();
    }

    /**
     * A HTTP-based client is responsible for accessing remote NLP server.
     */
    private CloseableHttpClient httpClient;

    /**
     * A connection manager is responsible for provioding the pooled HTTP
     * connections.
     */
    private PoolingHttpClientConnectionManager connectionManager;

    /**
     * A single scheduled thread is responsible for monitoring the status of the
     * connection pool in the connection manager.
     */
    private ScheduledExecutorService connectionMonitor;

    /**
     * A configuration of NLP service client
     */
    private NlpServiceClientConfig clientConfig;

    /**
     * The host of NLP service client
     */
    private String host;

    /**
     * Start up a NLP service client
     */
    public final void startUp() {
        synchronized (this) {
            if (this.httpClient != null) {
                return;
            }
        }

        log.info("Start to start up a NLP service client...");

        try {
            InetAddress hostIp = InetAddress.getLocalHost();
            this.host = hostIp.toString();

        } catch (UnknownHostException e) {
            NlpServiceException exception = new NlpServiceException("Failed to get this client's Hostname/IP.", e);

            throw exception;
        }

        this.clientConfig = ConfigProperties.getInstance().getNlpServiceClientConfig();
        log.info("NLP service client config: {}", clientConfig);

        // configure a custom http client builder
        HttpClientBuilder clientBuilder = HttpClients.custom();

        // add a set of default http header
        clientBuilder.setUserAgent(USER_AGENT);

        Header acceptCharsetHeader = new BasicHeader(HttpHeaders.ACCEPT_CHARSET, Consts.UTF_8.name());

        List<Header> headerList = new ArrayList<>();
        headerList.add(acceptCharsetHeader);
        // don't add Accept-Encoding header because content decompression is
        // enabled automatically.
        clientBuilder.setDefaultHeaders(headerList);

        // Refer to http://www.baeldung.com/httpclient-connection-management
        this.connectionManager = new PoolingHttpClientConnectionManager();
        this.connectionManager.setMaxTotal(this.clientConfig.getMaxTotalConnection());
        this.connectionManager.setDefaultMaxPerRoute(this.clientConfig.getMaxTotalConnection());

        clientBuilder.setConnectionManager(this.connectionManager);

        // Refer to http://www.baeldung.com/httpclient-timeout
        // create a custom request configuration, e.g. configure timeout
        // parameters, ignore all cookies, etc.
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(this.clientConfig.getMaxConnectionTimout())
                .setSocketTimeout(this.clientConfig.getMaxSocketTimeout())
                .setConnectionRequestTimeout(this.clientConfig.getMaxConnectionRequestTimeout())
                .setCookieSpec(CookieSpecs.IGNORE_COOKIES).setExpectContinueEnabled(false).build();

        clientBuilder.setDefaultRequestConfig(requestConfig).disableCookieManagement();

        // use default retry handler
        clientBuilder.setRetryHandler(new DefaultHttpRequestRetryHandler(MAX_RETRY_COUNT, false));

        // create an HttpClient with the given custom dependencies and
        // configuration.
        this.httpClient = clientBuilder.build();

        this.connectionMonitor = Executors.newSingleThreadScheduledExecutor();
        this.connectionMonitor.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                PoolStats poolStats = connectionManager.getTotalStats();
                if (poolStats.getLeased() + poolStats.getPending() > poolStats.getMax()) {
                    log.warn("It's not enough HTTP connection in NLP service client: {}", poolStats);
                } else {
                    log.info("The stats of HTTP connection pool in NLP service client: {}", poolStats);
                }

                // close expired connections
                connectionManager.closeExpiredConnections();
                // close connections that have been idle longer than 30 seconds
                connectionManager.closeIdleConnections(30, TimeUnit.SECONDS);
            }
        }, 3, 3, TimeUnit.MINUTES);

        log.info("Finish to start up a NLP service client,\nclient: {}", this);
    }

    public String toString() {
        return new ToStringBuilder(this).append("host", this.host).append("config", this.clientConfig).build();
    }

    /**
     * Shutdown a NLP service client
     */
    public final void shutdown() {
        synchronized (this) {
            if (this.httpClient == null) {
                return;
            }
        }

        log.info("Start to shutdown a NLP service client...");

        this.connectionManager.shutdown();
        this.connectionMonitor.shutdownNow();

        IOUtils.closeQuietly(this.httpClient);
        IOUtils.closeQuietly(this.connectionManager);

        this.connectionManager = null;
        this.httpClient = null;

        log.info("Finish to shutdown a NLP service client.");
    }

    public final JsonElement getClientConfig() {
        if (this.httpClient == null) {
            return new JsonPrimitive("NLP service client is not started up.");
        }

        JsonObject clientConfigJson = this.clientConfig.toJsonObject();
        clientConfigJson.addProperty("host", this.host);

        return clientConfigJson;
    }

    public final JsonElement getPoolStats() {
        if (this.httpClient == null) {
            return new JsonPrimitive("NLP service client is not started up.");
        }

        PoolStats poolStats = this.connectionManager.getTotalStats();

        float demand = (poolStats.getLeased() + poolStats.getPending() / (float) poolStats.getMax());
        String utilization = String.format("%.2f%%", demand);

        JsonObject poolStatsJson = new JsonObject();
        poolStatsJson.addProperty("max", poolStats.getMax());
        poolStatsJson.addProperty("utilization", utilization);
        poolStatsJson.addProperty("leased", poolStats.getLeased());
        poolStatsJson.addProperty("pending", poolStats.getPending());
        poolStatsJson.addProperty("available", poolStats.getAvailable());

        return poolStatsJson;
    }

    private NlpResult getEntityAsString(URIBuilder uriBuilder, List<NameValuePair> parameterList) {
        URI uri;
        try {
            uri = uriBuilder.build();

        } catch (URISyntaxException e) {
            NlpServiceException exception = new NlpServiceException("Failed to build a URI", e);

            throw exception;
        }

        if (log.isInfoEnabled()) {
            StringBuilder debuggingUrl = new StringBuilder(uri.toString());

            if (!parameterList.isEmpty()) {
                String queryString = URLEncodedUtils.format(parameterList, Consts.UTF_8);
                debuggingUrl.append('?').append(queryString);
            }

            log.info("Send a POST reuqest to NLP server. debugging url: {}, parameter: {}", debuggingUrl,
                    parameterList);
        }

        HttpPost httpPost = new HttpPost(uri);

        CloseableHttpResponse response = null;
        int httpStatus = 0;
        String stringEntity = "";

        try {
            httpPost.setEntity(new UrlEncodedFormEntity(parameterList, Consts.UTF_8));
            response = this.httpClient.execute(httpPost);

            httpStatus = response.getStatusLine().getStatusCode();
            HttpEntity httpEntity = response.getEntity();
            stringEntity = EntityUtils.toString(httpEntity, Consts.UTF_8);

        } catch (IOException e) {
            NlpServiceException exception = new NlpServiceException("Failed to read data from NLP server", e);
            exception.addContextValue("Url", uri);

            throw exception;

        } finally {
            IOUtils.closeQuietly(response);
        }

        if (HttpStatus.SC_OK != httpStatus) {
            NlpServiceException exception = new NlpServiceException("Failed to read data from NLP server");
            exception.addContextValue("Url", uri);
            exception.addContextValue("HttpStatus", httpStatus);

            // just retain the most 2000 characters for debugging
            String errorDetail = stringEntity;
            int start = StringUtils.indexOf(errorDetail, "root cause");
            if (start > 0) {
                errorDetail = errorDetail.substring(start);
            }
            exception.addContextValue("Detail", StringUtils.left(errorDetail, 2000));

            throw exception;
        }

        NlpResult nlpResult = new NlpResult(httpStatus, stringEntity);

        return nlpResult;
    }

    private List<NameValuePair> buildHttpPostParameterList(ParameterMap<String, Object> parameterMap) {
        if (parameterMap == null) {
            return Collections.emptyList();
        }

        Map<String, Object> unmodifiableParamMap = parameterMap.unmodifiableParamMap();
        if (unmodifiableParamMap.isEmpty()) {
            return Collections.emptyList();
        }

        Set<Entry<String, Object>> paramEntrySet = unmodifiableParamMap.entrySet();
        List<NameValuePair> parameterList = new ArrayList<NameValuePair>();

        for (Entry<String, Object> paramEntry : paramEntrySet) {
            Object value = paramEntry.getValue();
            String key = paramEntry.getKey();

            if (value != null) {
                Class<? extends Object> valueClass = value.getClass();

                if (valueClass.isArray()) {
                    Object[] valueArray = (Object[]) value;

                    for (Object valueObj : valueArray) {
                        if (valueObj != null) {
                            parameterList.add(new BasicNameValuePair(key, valueObj.toString()));
                        }
                    }
                } else if (Collection.class.isAssignableFrom(valueClass)) {
                    Collection<?> valueCollection = (Collection<?>) value;

                    for (Object valueObj : valueCollection) {
                        if (valueObj != null) {
                            parameterList.add(new BasicNameValuePair(key, valueObj.toString()));
                        }
                    }
                } else {
                    if (value != null) {
                        parameterList.add(new BasicNameValuePair(key, value.toString()));
                    }
                }
            }
        }

        return parameterList;
    }

    private NlpResult getNlpJsonResult(ParameterMap<String, Object> parameterMap, String servicePath) {
        log.trace("NLP service parameter map: {}", parameterMap);

        StringBuilder serviceUrl = new StringBuilder(this.clientConfig.getNlpServiceUrl());
        serviceUrl.append(servicePath);

        URIBuilder uriBuilder;
        try {
            uriBuilder = new URIBuilder(serviceUrl.toString());

        } catch (URISyntaxException e) {
            NlpServiceException exception = new NlpServiceException("Failed to build a URI", e);
            exception.addContextValue("Url", serviceUrl);

            throw exception;
        }

        List<NameValuePair> parameterList = this.buildHttpPostParameterList(parameterMap);
        NlpResult nlpResult = this.getEntityAsString(uriBuilder, parameterList);

        return nlpResult;
    }

    /**
     * A HTTP URL is provided by NLP server for the findSimpleQuery function.
     * <br>
     * 
     * The format of the URL is as follow:<br>
     * http://{host}:{port}/SimpleQuery/
     * 
     * @param parameter
     *            a parameter container holds the required and optional query
     *            parameters
     * @return a NLP result
     */
    public NlpResult findSimpleQuery(SimpleQueryParameter parameter) {
        if (this.httpClient == null) {
            throw new NlpServiceException("NLP service client is not started yet.");
        }

        NlpResult nlpResult = this.getNlpJsonResult(parameter, "/SimpleQuery/");

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Do findSimpleQuery action. solrQueryStr: {}", solrQueryStr);
        }

        return nlpResult;
    }

    /**
     * A HTTP URL is provided by NLP server for the findSimpleQueryByBrief
     * function.<br>
     * 
     * The format of the URL is as follow:<br>
     * http://{host}:{port}/SimpleQuery/brief/
     * 
     * @param parameter
     *            a parameter container holds the required and optional query
     *            parameters
     * @return a NLP result
     */
    public NlpResult findSimpleQueryByBrief(SimpleQueryByBriefParameter parameter) {
        if (this.httpClient == null) {
            throw new NlpServiceException("NLP service client is not started yet.");
        }

        NlpResult nlpResult = this.getNlpJsonResult(parameter, "/SimpleQuery/brief/");

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Do findSimpleQueryByBrief action. solrQueryStr: {}", solrQueryStr);
        }

        return nlpResult;
    }

    /**
     * A HTTP URL is provided by NLP server for the findSimpleQueryByClaim
     * function.<br>
     * 
     * The format of the URL is as follow:<br>
     * http://{host}:{port}/SimpleQuery/claim/
     * 
     * @param parameter
     *            a parameter container holds the required and optional query
     *            parameters
     * @return a NLP result
     */
    public NlpResult findSimpleQueryByClaim(SimpleQueryByClaimParameter parameter) {
        if (this.httpClient == null) {
            throw new NlpServiceException("NLP service client is not started yet.");
        }

        NlpResult nlpResult = this.getNlpJsonResult(parameter, "/SimpleQuery/claim/");

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Do findSimpleQueryByClaim action. solrQueryStr: {}", solrQueryStr);
        }

        return nlpResult;
    }

    /**
     * A HTTP URL is provided by NLP server for the findKeywordExtraction
     * function.<br>
     * 
     * The format of the URL is as follow:<br>
     * http://{host}:{port}/KeywordExtractor/
     * 
     * @param parameter
     *            a parameter container holds the required and optional query
     *            parameters
     * @return a NLP result
     */
    public NlpResult findKeywordExtraction(KeywordExtractorParameter parameter) {
        if (this.httpClient == null) {
            throw new NlpServiceException("NLP service client is not started yet.");
        }

        NlpResult nlpResult = this.getNlpJsonResult(parameter, "/KeywordExtractor/");

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            JsonArray keywordsJson = nlpResultJson.getAsJsonArray("keywords");

            log.info("Do findKeywordExtraction action. keywords: {}", keywordsJson);
        }

        return nlpResult;
    }

    /**
     * A HTTP URL is provided by NLP server for the findQueryExpansion function.
     * <br>
     * 
     * The format of the URL is as follow:<br>
     * http://{host}:{port}/QueryExpansion/
     * 
     * @param parameter
     *            a parameter container holds the required and optional query
     *            parameters
     * @return a NLP result
     */
    public NlpResult findQueryExpansion(QueryExpansionParameter parameter) {
        if (this.httpClient == null) {
            throw new NlpServiceException("NLP service client is not started yet.");
        }

        NlpResult nlpResult = this.getNlpJsonResult(parameter, "/QueryExpansion/");

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            JsonArray identicalWordsJson = nlpResultJson.getAsJsonArray("identical words");

            log.info("Do findQueryExpansion action.. identicalWords: {}", identicalWordsJson);
        }

        return nlpResult;
    }
}