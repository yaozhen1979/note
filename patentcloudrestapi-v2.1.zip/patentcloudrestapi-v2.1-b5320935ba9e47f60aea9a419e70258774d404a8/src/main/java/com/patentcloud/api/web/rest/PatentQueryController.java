package com.patentcloud.api.web.rest;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.solr.client.solrj.SolrQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.patentcloud.api.constant.Constant;
import com.patentcloud.api.exception.PatentQueryException;
import com.patentcloud.api.model.PatentDataStatus;
import com.patentcloud.api.model.SolrQueryVO;
import com.patentcloud.api.server.service.PatentDataStatusService;
import com.patentcloud.api.util.SpringContextUtil;
import com.patentcloud.api.util.http.SolrResult;
import com.patentcloud.api.util.solr.SolrUtils;

@RestController
@RequestMapping("/restful/query/{version}")
public class PatentQueryController {

    private static final Logger log = LoggerFactory.getLogger(PatentQueryController.class);

    @Autowired
    private PatentDataStatusService patentDataStatusService;

    private static final String ISO_8601_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    // create one Gson Builder and reuse it.
    private static final Gson GSON = new GsonBuilder().setDateFormat(ISO_8601_PATTERN).serializeNulls().create();

    @RequestMapping(value = "/queryPatentList")
    public ResponseEntity<String> queryPatentList(@PathVariable String version,
            @RequestParam(value = "query", required = true) String query,
            @RequestParam(value = "fq", required = false) String fq,
            @RequestParam(value = "rows", required = false) Integer rows,
            @RequestParam(value = "start", required = false) Integer start,
            @RequestParam(value = "sort", required = false) List<String> sort,
            @RequestParam(value = "country", required = false) List<String> country,
            @RequestParam(value = "type", required = false) Integer[] type,
            @RequestParam(value = "docdb", required = false) boolean docdb,
            @RequestParam(value = "state", required = false) Integer[] state,
            @RequestParam(value = "stem", required = false) boolean stem,
            @RequestParam(value = "mode", required = false) String mode,
            @RequestParam(value = "fl", required = false) List<String> fl,
            @RequestParam(value = "cursormark", required = false) String cursormark,
            @RequestParam(value = "solrsyntax", required = false) boolean solrsyntax) {
        log.info(
                "Start to do queryPatentList action. version: {}, query: {},\n"
                        + "fq: {}, rows: {}, start: {}, sort: {}, country: {}, type: {}, docdb: {}, state: {}, "
                        + "stem: {}, mode: {}, fl: {}, solrsyntax: {}",
                version, query, fq, rows, start, sort, country, type, docdb, state, stem, mode, fl, solrsyntax);

        SolrQueryVO solrQueryVo = new SolrQueryVO();

        solrQueryVo.Builder(rows, start, sort, query, fq, null, country, state, type, fl, mode, true, stem, docdb,
                cursormark, false, 0, 0, null, null, null, false, null, 0, false);
        SolrQuery solrQuery = SolrUtils.genQuery(solrQueryVo);

        SolrResult solrResult = SolrUtils.queryJSonServlet(solrQuery);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        HttpStatus solrHttpStatus = HttpStatus.valueOf(solrResult.getHttpStatus());
        ResponseEntity<String> responseEntity = new ResponseEntity<>(solrResult.getEntity(), httpHeaders,
                solrHttpStatus);

        log.info("Finish to do queryPatentList action. Solr HttpStatus: {}", solrResult.getHttpStatus());

        return responseEntity;
    }

    @RequestMapping(value = "/findPatentInfo")
    public ResponseEntity<String> findPatentInfo(@PathVariable String version,
            @RequestParam(value = "ptopid", required = true) List<String> ptopid,
            @RequestParam(value = "sort", required = false) List<String> sort,
            @RequestParam(value = "mode", required = false) String mode,
            @RequestParam(value = "fl", required = false) List<String> fl) {
        log.info("Start to do findPatentInfo action. version: {}, ptopid: {},"
                + "sort: {}, mode: {}, fl: {}", version, ptopid, sort, mode, fl);

        SolrQueryVO solrQueryVo = new SolrQueryVO();

        solrQueryVo.Builder(20, 0, sort, null, null, ptopid, null, null, null, fl, mode, false, false, false, null,
                false, 0, 0, null, null, null, false, null, 0, false);
        SolrQuery solrQuery = SolrUtils.genQuery(solrQueryVo);

        SolrResult solrResult = SolrUtils.queryJSonServlet(solrQuery);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        HttpStatus solrHttpStatus = HttpStatus.valueOf(solrResult.getHttpStatus());
        ResponseEntity<String> responseEntity = new ResponseEntity<>(solrResult.getEntity(), httpHeaders,
                solrHttpStatus);

        log.info("Finish to do findPatentInfo action. Solr HttpStatus: {}", solrResult.getHttpStatus());

        return responseEntity;
    }

    @RequestMapping(value = "/findPatentGroup")
    public ResponseEntity<String> findPatentGroup(@PathVariable String version,
            @RequestParam(value = "query", required = true) String query,
            @RequestParam(value = "fq", required = false) String fq,
            @RequestParam(value = "rows", required = false) Integer rows,
            @RequestParam(value = "start", required = false) Integer start,
            @RequestParam(value = "sort", required = false) List<String> sort,
            @RequestParam(value = "country", required = false) List<String> country,
            @RequestParam(value = "type", required = false) Integer[] type,
            @RequestParam(value = "docdb", required = false) boolean docdb,
            @RequestParam(value = "state", required = false) Integer[] state,
            @RequestParam(value = "stem", required = false) boolean stem,
            @RequestParam(value = "mode", required = false) String mode,
            @RequestParam(value = "fl", required = false) List<String> fl,
            @RequestParam(value = "group.limit", required = false) Integer groupLimit,
            @RequestParam(value = "group.field", required = false) String groupField,
            @RequestParam(value = "solrsyntax", required = false) boolean solrsyntax) {
        log.info(
                "Start to do findPatentGroup action. version: {}, query: {},\n"
                        + "fq: {}, rows: {}, start: {}, sort: {}, country: {}, type: {}, docdb: {}, state: {}, "
                        + "stem: {}, mode: {}, fl: {}, group.limit: {}, group.field: {}, solrsyntax: {}",
                version, query, fq, rows, start, sort, country, type, docdb, state, stem, mode, fl, groupLimit,
                groupField, solrsyntax);

        SolrQueryVO solrQueryVo = new SolrQueryVO();

        solrQueryVo.Builder(rows, start, sort, query, fq, null, country, state, type, fl, mode, true, stem, docdb, null,
                false, 0, 0, null, null, null, true, groupField, groupLimit, true);

        SolrQuery solrQuery = SolrUtils.genQuery(solrQueryVo);

        SolrResult solrResult = SolrUtils.queryJSonServlet(solrQuery);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        HttpStatus solrHttpStatus = HttpStatus.valueOf(solrResult.getHttpStatus());
        ResponseEntity<String> responseEntity = new ResponseEntity<>(solrResult.getEntity(), httpHeaders,
                solrHttpStatus);

        log.info("Finish to do findPatentInfo action. Solr HttpStatus: {}", solrResult.getHttpStatus());

        return responseEntity;
    }

    @RequestMapping(value = "/findPatentFacet")
    public ResponseEntity<String> findPatentFacet(@PathVariable String version,
            @RequestParam(value = "query", required = true) String query,
            @RequestParam(value = "fq", required = false) String fq,
            @RequestParam(value = "rows", required = false) Integer rows,
            @RequestParam(value = "sort", required = false) List<String> sort,
            @RequestParam(value = "country", required = false) List<String> country,
            @RequestParam(value = "type", required = false) Integer[] type,
            @RequestParam(value = "docdb", required = false) boolean docdb,
            @RequestParam(value = "state", required = false) Integer[] state,
            @RequestParam(value = "stem", required = false) boolean stem,
            @RequestParam(value = "mode", required = false) String mode,
            @RequestParam(value = "fl", required = false) List<String> fl,
            @RequestParam(value = "facet.offset", required = false) Integer facetOffset,
            @RequestParam(value = "facet.field", required = false) List<String> facetField,
            @RequestParam(value = "facet.sort", required = false) String facetSort,
            @RequestParam(value = "facet.field.mode", required = false) String facetFieldMode,
            @RequestParam(value = "facet.limit", required = false) Integer facetLimit,
            @RequestParam(value = "solrsyntax", required = false) boolean solrsyntax) {
        log.info(
                "Start to do findPatentFacet action. version: {}, query: {},\n"
                        + "fq: {}, rows: {}, sort: {}, country: {}, type: {}, docdb: {}, state: {}, "
                        + "stem: {}, mode: {}, fl: {}, facet.offset: {}, facet.field: {}, facet.field.mode: {}, facet.limit: {}, "
                        + "solrsyntax: {}",
                version, query, fq, rows, sort, country, type, docdb, state, stem, mode, fl, facetOffset, facetField,
                facetField, facetLimit, solrsyntax);

        SolrQueryVO solrQueryVo = new SolrQueryVO();

        solrQueryVo.Builder(rows, 0, sort, query, fq, null, country, state, type, fl, mode, true, stem, docdb, null,
                true, facetLimit, facetOffset, facetSort, facetFieldMode, facetField, false, null, 0, false);

        SolrQuery solrQuery = SolrUtils.genQuery(solrQueryVo);

        SolrResult solrResult = SolrUtils.queryJSonServlet(solrQuery);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        HttpStatus solrHttpStatus = HttpStatus.valueOf(solrResult.getHttpStatus());
        ResponseEntity<String> responseEntity = new ResponseEntity<>(solrResult.getEntity(), httpHeaders,
                solrHttpStatus);

        log.info("Finish to do findPatentFacet action. Solr HttpStatus: {}", solrResult.getHttpStatus());

        return responseEntity;
    }

    @RequestMapping(value = "/queryPatentDataStatus")
    public ResponseEntity<String> queryPatentDataStatus(@PathVariable String version) {
        log.info("Start to do queryPatentDataStatus action. version: {}", version);

        List<PatentDataStatus> dataStatusList = this.patentDataStatusService.findAllPatentDataStatus();
        String dataStatusListJson = GSON.toJson(dataStatusList);
        ResponseEntity<String> responseEntity = new ResponseEntity<>(dataStatusListJson, HttpStatus.OK);

        log.info("Finish to do queryPatentDataStatus action. HttpStatus: {}", HttpStatus.OK);

        return responseEntity;
    }

    @RequestMapping(value = "/updatePatentDataStatus")
    public ResponseEntity<String> updatePatentDataStatus(@PathVariable String version) {
        log.info("Start to do updatePatentDataStatus action. version: {}", version);

        PatentDataStatusService patentDataStatusService = (PatentDataStatusService) SpringContextUtil
                .getBean("patentDataStatusService");

        patentDataStatusService.updatePatentDataStatus();

        JsonObject responseJson = new JsonObject();
        responseJson.addProperty("result", true);
        ResponseEntity<String> responseEntity = new ResponseEntity<>(responseJson.toString(), HttpStatus.OK);

        log.info("Finish to do updatePatentDataStatus action. HttpStatus: {}", HttpStatus.OK);

        return responseEntity;
    }

    @ExceptionHandler(value = { PatentQueryException.class })
    public ResponseEntity<String> handlePatentQueryException(PatentQueryException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "patent.query.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }

    /**
     * A workaround handles the low level IOException
     */
    @ExceptionHandler(value = { IOException.class })
    public ResponseEntity<String> handleIOException(IOException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "patent.query.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }
}
