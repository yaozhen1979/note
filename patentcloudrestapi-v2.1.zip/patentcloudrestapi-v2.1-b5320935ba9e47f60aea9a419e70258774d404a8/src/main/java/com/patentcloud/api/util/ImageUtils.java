package com.patentcloud.api.util;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfWriter;
import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.model.solr.SolrPatentInfo;
import com.patentcloud.api.util.solr.PatentDataConfig;

public class ImageUtils {

    private static final Logger log = LoggerFactory.getLogger(ImageUtils.class);

    private static final Map<String, String> EXT_MIME_TYPE = new HashMap<>();

    static {
        EXT_MIME_TYPE.put("gif", "gif");
        EXT_MIME_TYPE.put("jpg", "jpeg");
        EXT_MIME_TYPE.put("png", "png");
        EXT_MIME_TYPE.put("tif", "tiff");
    }

    private static void saveImage(BufferedImage image, File file) throws IOException {
        FileUtils.sureFileExists(file, true);
        if (!ImageIO.write(image, "PNG", file)) {
            throw new IOException("create cache image failed: " + file);
        }
    }

    private static void checkImageMimeType(PatentFile patentFile) {
        // auto detect type failed
        if ((patentFile.mimeType == null || patentFile.mimeType.equalsIgnoreCase("text/plain"))
                && patentFile.file.exists()) {
            // fix mimetype by file name extension
            String ext = FilenameUtils.getExtension(patentFile.getFile().getName()).toLowerCase();
            if (EXT_MIME_TYPE.containsKey(ext)) {
                patentFile.setMimeType("image/" + EXT_MIME_TYPE.get(ext));
            }
        }
    }

    public static PatentFile getFirstPagePdf(PatentPath patentPath) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);

        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get(""), "firstPage.pdf");
        if (pathList.isEmpty()) {
            List<Path> pdfPathlist = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get(""), "fullPage.pdf");
            if (!pdfPathlist.isEmpty()) {
                for (Path path : pdfPathlist) {
                    patentFile.setFile(path.toFile());
                    patentFile.setMimeType("application/pdf");
                    break;
                }
                // US,USPTO 使用PDFBox處理 modify by mike
                switch (patentFile.getInfo().ptoVO) {
                case US:
                case USPTO:
                case TW:
                case TIPO:
                case JP:
                case JPO:
                case KR:
                case KIPO:
                case EP:
                case EPO:
                case WO:
                case WIPO:
                    PdfUtils.splitFirstPagePdf(patentFile);
                    break;
                default:
                }

                pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get(""), "firstPage.pdf");
                if (!pathList.isEmpty()) {
                    Path path = pathList.get(0);
                    patentFile.setFile(path.toFile());
                    patentFile.setMimeType("application/pdf");
                }
            } else {
                patentFile = getFullImage(patentPath, 1);

                File cacheFile = FileUtils.getCacheFile(patentFile, Paths.get("firstPage.pdf"));
                if (!cacheFile.exists()) {
                    Document doc = null;
                    PdfWriter pdfWriter = null;
                    try {
                        doc = new Document();
                        pdfWriter = PdfWriter.getInstance(doc, new FileOutputStream(cacheFile));
                        doc.open();

                        Rectangle rect = doc.getPageSize();
                        PdfUtils.addImageToPdfbyIText(doc, patentFile.getFile().toPath(), rect);
                        patentFile.setFile(cacheFile);
                        patentFile.setMimeType("application/pdf");

                    } catch (DocumentException e) {
                        cacheFile.delete();
                        throw new IOException(e);

                    } finally {
                        if (doc != null) {
                            doc.close();
                        }
                        if (pdfWriter != null) {
                            pdfWriter.close();
                        }
                    }
                }
            }
        } else {
            if (!pathList.isEmpty()) {
                Path path = pathList.get(0);
                patentFile.setFile(path.toFile());
                patentFile.setMimeType("application/pdf");
            }
        }

        return patentFile;
    }

    public static PatentFile getFullImage(PatentPath patentPath, int num) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);
        String filenameStart = String.format("%1$d.", num);

        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get("fullimage"), filenameStart);
        if (pathList.isEmpty()) {
            switch (patentFile.getInfo().ptoVO) {
            case US:
            case USPTO:
            case TW:
            case TIPO:
            case JP:
            case JPO:
            case KR:
            case KIPO:
            case EP:
            case EPO:
            case WO:
            case WIPO:
                patentFile = getFullPdf(patentPath);
                ImageMagickUtils.splitPdfToImage(patentFile, num);
                patentFile.setFile(new File(""));
                patentFile.setMimeType("");
                pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get("fullimage"), filenameStart);

                if (!pathList.isEmpty()) {
                    Path path = pathList.get(0);
                    patentFile.setFile(path.toFile());
                    patentFile.setMimeType(Files.probeContentType(path));
                }
                break;

            default:
            }
        } else {
            if (!pathList.isEmpty()) {
                Path path = pathList.get(0);
                patentFile.setFile(path.toFile());
                patentFile.setMimeType(Files.probeContentType(path));
            }
        }
        if (!patentFile.file.getPath().isEmpty()) {
            checkImageMimeType(patentFile);
            ImageMagickUtils.cachePatentImage2Png(patentFile, Paths.get("fullimage", filenameStart + "png"));
        }
        return patentFile;
    }

    private static class FirstImageUtils {

        private static int[] computeXAxisBlackDotNumber(BufferedImage image, int countThreshold)
                throws UnsupportedEncodingException {
            WritableRaster raster = image.getRaster();
            int width = image.getWidth();
            int height = image.getHeight();
            int[] pixel = { 0, 0, 0, 0 };
            int pixelThreshold = 1;

            int[] axisBlockDotNumber = new int[height];
            for (int y = 0; y < height; y++) {
                int sum = 0;
                for (int x = 0; x < width; x++) {
                    raster.getPixel(x, y, pixel);
                    if (pixel[0] >= pixelThreshold) {
                        sum++;
                        if (sum >= countThreshold) {
                            axisBlockDotNumber[y] = 1;
                            break;
                        }
                    }
                }
            }

            return axisBlockDotNumber;
        }

        private static int[] computeYAxisBlackDotNumber(BufferedImage image, int countThreshold)
                throws UnsupportedEncodingException {
            WritableRaster raster = image.getRaster();
            int width = image.getWidth();
            int height = image.getHeight();
            int[] pixel = { 0, 0, 0, 0 };
            int pixelThreshold = 1;

            int[] axisBlockDotNumber = new int[width];
            for (int x = 0; x < width; x++) {
                int sum = 0;
                for (int y = 0; y < height; y++) {
                    raster.getPixel(x, y, pixel);
                    if (pixel[0] >= pixelThreshold) {
                        sum++;
                        if (sum >= countThreshold) {
                            axisBlockDotNumber[x] = 1;
                            break;
                        }
                    }
                }
            }

            return axisBlockDotNumber;
        }

        private static BufferedImage autoCropWhiteImage(BufferedImage image, int countThreshold)
                throws UnsupportedEncodingException {
            int[] axisBlockDotNumber = computeXAxisBlackDotNumber(image, countThreshold);
            Point ycenter = extractNonEmptyCenterRange(axisBlockDotNumber);

            int[] yaxisBlockDotNumber = computeYAxisBlackDotNumber(image, countThreshold);
            Point xcenter = extractNonEmptyCenterRange(yaxisBlockDotNumber);

            if (xcenter.x < xcenter.y) {
                if (ycenter.x < ycenter.y) {
                    return image.getSubimage(xcenter.x, ycenter.x, xcenter.y - xcenter.x, ycenter.y - ycenter.x);
                }
            }
            return image;
        }

        /**
         * Point.x: y start Point.y: y end
         */
        private static List<Point> extractEmptyRanges(int[] input, int start, int end) {
            List<Point> ranges = new ArrayList<>();
            int len = 0;
            for (int i = start; i < end; i++) {
                if (input[i] > 0) {
                    ranges.add(new Point(i - len, i));
                    len = 0;
                } else {
                    len++;
                }
            }
            if (len > 1) {
                ranges.add(new Point(end - len, end - 1));
            }
            return ranges;
        }

        /**
         * Point.x: y start Point.y: y end
         */
        private static Point extractNonEmptyCenterRange(int[] input) {
            int total = input.length;
            int start = 0;
            int end = total;
            for (int i = 0; i < total; i++) {
                if (input[i] > 0) {
                    start = i;
                    break;
                }
            }
            for (int i = total - 1; i >= 0; i--) {
                if (input[i] > 0) {
                    end = i;
                    break;
                }
            }
            if (start < end) {
                return new Point(start, end);
            } else {
                return new Point(0, 0);
            }
        }

        /**
         * @return true if generate firstImage.png
         */
        private static void genFirstImage(PatentFile patentFile) throws IOException {
            if (!patentFile.file.exists()) {
                return;
            }

            BufferedImage image = ImageIO.read(patentFile.getFile());
            ColorModel colorModel = image.getColorModel();
            int width = image.getWidth();
            int height = image.getHeight();
            int countThreshold = 1;
            int minEmptyHeight = 50;
            int maxEmptyHeight = Math.round(height * 0.15f);
            BufferedImage outimage = null;

            if (colorModel.getPixelSize() != 1) {
                throw new UnsupportedEncodingException("only support 1 bit image");
            }

            // calculate x-axis black dot numbers
            int[] xaxisBlockDotNumber = computeXAxisBlackDotNumber(image, countThreshold);

            if (outimage == null) {
                List<Point> listEmptyBlock = extractEmptyRanges(xaxisBlockDotNumber, Math.round(height * 0.33f),
                        Math.round(height * 0.95f));
                if (!listEmptyBlock.isEmpty()) {
                    for (Point range : listEmptyBlock) {
                        int rangesize = range.y - range.x;
                        if (rangesize >= minEmptyHeight && rangesize <= maxEmptyHeight) {
                            outimage = image.getSubimage(0, range.x, width, height - range.x - 1);
                            break;
                        }
                    }
                }
            }

            if (outimage == null) {
                outimage = image;
            } else {
                outimage = autoCropWhiteImage(outimage, countThreshold);
            }

            File file = FileUtils.getCacheFile(patentFile, Paths.get("firstImage.png"));
            saveImage(outimage, file);
            patentFile.setFile(file);
            patentFile.setMimeType("image/png");
        }

    }

    public static PatentFile getFirstImage(PatentPath patentPath) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);
        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get(""), "firstImage.");

        log.info("Patent path: {}, matching path list: {}", patentPath.paths, pathList);

        if (pathList.isEmpty()) {
            switch (patentFile.getInfo().ptoVO) {
            case US:
            case USPTO:
                patentFile = GooglePatentUtils.downloadFirstImageFromGooglePatent(patentPath);
                if (!patentFile.file.exists()) {
                    patentFile = getFullImage(patentPath, 1);
                    FirstImageUtils.genFirstImage(patentFile);
                }
                break;
            case CN:
            case CNIPR:
                if (patentPath.info.typeCode == 3) {
                    patentFile = ImageUtils.getFullImage(patentPath, 1);
                } else {
                    patentFile = CniprPatentUtils.downloadFirstImageFromCnipr(patentPath);
                }
                break;
            case TW:
            case TIPO:
            case WO:
            case WIPO:
            case JP:
            case JPO:
                patentFile = getFullImage(patentPath, 1);
                break;
            default:
            }
        }

        if (pathList.size() > 0) {
            Path path = pathList.get(0);
            patentFile.setFile(path.toFile());
            patentFile.setMimeType(Files.probeContentType(path));
        }

        if (!patentFile.file.getPath().isEmpty()) {
            checkImageMimeType(patentFile);
            ImageMagickUtils.cacheAndResizePatentImage2Png(patentFile, Paths.get("firstImage.png"), 250, 250);
        }
        return patentFile;
    }

    public static PatentFile getClipImage(PatentPath patentPath, int num) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);

        String filenameStart = String.format("%1$d.", num);
        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get("clip"), filenameStart);

        if (pathList.size() > 0) {
            Path path = pathList.get(0);
            patentFile.setFile(path.toFile());
            patentFile.setMimeType(Files.probeContentType(path));
        }
        if (!patentFile.file.getPath().isEmpty()) {
            checkImageMimeType(patentFile);
            ImageMagickUtils.cachePatentImage2Png(patentFile, Paths.get("clip", filenameStart + "png"));
        }
        return patentFile;
    }

    public static PatentFile getInsetImage(PatentPath patentPath, String filename) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);
        String prefix = filename.substring(0, filename.lastIndexOf(".") + 1);
        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get("figure"), prefix);
        if (pathList.size() > 0) {
            patentFile.setFile(pathList.get(0).toFile());
            patentFile.setMimeType(Files.probeContentType(pathList.get(0)));
        }

        if (!patentFile.file.getPath().isEmpty()) {
            checkImageMimeType(patentFile);
            ImageMagickUtils.cachePatentImage2Png(patentFile, Paths.get("figure", prefix + "png"));
        }
        return patentFile;
    }

    private static PatentFile genFullPdfbyIText(PatentPath patentPath) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);

        switch (patentPath.info.ptoVO) {
        case CNIPR:
        case CN:
        case TIPO:
        case TW:
            break;
        default:
            throw new UnsupportedEncodingException("only support TW/CN image to PDF by itext");
        }
        File file = FileUtils.getCacheFile(patentFile, Paths.get("fullPage.pdf"));
        FileUtils.sureFileExists(file, true);

        List<Path> pathList = FileUtils.listPatentFilesBySuffix(patentPath, Paths.get("fullimage"), ".tif", ".jpg");
        if (pathList.isEmpty()) {
            return patentFile;
        }
        Document doc = null;
        PdfWriter pdfWriter = null;
        try {
            doc = new Document();
            pdfWriter = PdfWriter.getInstance(doc, new FileOutputStream(file));
            doc.open();
            Rectangle rect = doc.getPageSize();
            for (Path path : pathList) {
                PdfUtils.addImageToPdfbyIText(doc, path, rect);
            }
            patentFile.setFile(file);
            patentFile.setMimeType("application/pdf");
        } catch (DocumentException e) {
            file.delete();
            throw new IOException(e);
        } finally {
            if (doc != null) {
                doc.close();
                pdfWriter.close();
            }
        }
        return patentFile;
    }

    public static PatentFile getFullPdf(PatentPath patentPath) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);
        List<Path> pathList = FileUtils.listPatentFilesByPrefix(patentPath, Paths.get(""), "fullPage.pdf");

        log.info("Patent path: {}, matching path list: {}", patentPath.paths, pathList);

        if (pathList.isEmpty()) {
            switch (patentFile.getInfo().ptoVO) {
            case US:
            case USPTO:
                patentFile = GooglePatentUtils.downloadPdfFromGooglePatent(patentPath);
                break;
            case CN:
            case CNIPR:
                if (!patentFile.file.exists()) {
                    patentFile = genFullPdfbyIText(patentPath);
                }
                break;
            case TW:
            case TIPO:
                if (!patentFile.file.exists()) {
                    patentFile = genFullPdfbyIText(patentPath);
                }
                break;
            default:
            }
        } else {
            if (!pathList.isEmpty()) {
                Path path = pathList.get(0);
                patentFile.setFile(path.toFile());
                patentFile.setMimeType("application/pdf");
            }
        }

        return patentFile;
    }

    private static File getGooglePatentFile(PatentFile patentFile, Path filePath) {
        String relpath = PatentDataUtils.getRelPatentPath(patentFile.getInfo());
        for (File file : PatentDataConfig.GOOGLE_PATENT_PATH_PTO.get(patentFile.getInfo().ptoVO)) {
            return file.toPath().resolve(relpath).resolve(filePath).toFile();
        }

        return new File("");
    }

    private static class GooglePatentUtils {
        private static String getGooglePatentNumber(PatentInfo info) throws UnsupportedEncodingException {
            String pn;
            switch (info.ptoVO) {
            case US:
            case USPTO:
                pn = info.patentNumber.replaceAll("(?i)^(US)?0*", "US");
                break;
            case CN:
            case CNIPR:
                if (info.stats.get(info.stats.size() - 1) == 1) {
                    pn = info.openNumber.replaceAll("(?i)^(CN)?0*", "CN");
                } else {
                    pn = info.decisionNumber.replaceAll("(?i)^(CN)?0*", "CN");
                }
                pn = pn.replaceAll("\\D$", "");
                if (info.kindcode != null) {
                    pn += info.kindcode.toUpperCase();
                }
                break;
            case EP:
            case EPO:
                pn = info.patentNumber.replaceAll("(?i)^(EP)?0*", "EP");
                pn = pn.replaceAll("\\D\\d$", "");
                if (info.kindcode != null) {
                    pn += info.kindcode.toUpperCase();
                }
                break;
            default:
                throw new UnsupportedEncodingException("unsupported pto for google patent: " + info.ptoVO);
            }
            return pn;
        }

        private static PatentFile downloadPdfFromGooglePatent(PatentPath patentPath) throws IOException {
            PatentFile patentFile = new PatentFile();
            patentFile.setInfo(patentPath.info);

            String srcUrl = "";
            String patentNumber = getGooglePatentNumber(patentPath.info);

            switch (patentFile.getInfo().ptoVO) {
            case US:
            case USPTO:
                srcUrl = String.format("http://patentimages.storage.googleapis.com/pdfs/%1$s.pdf", patentNumber);
                break;
            default:
            }

            File destFile = getGooglePatentFile(patentFile, Paths.get("fullPage.pdf"));

            boolean successful = DownloadUtils.downloadAndWriteFile(srcUrl, destFile);
            if (successful) {
                patentFile.setFile(destFile);
                patentFile.setMimeType("application/pdf");
            }

            return patentFile;
        }

        private static PatentFile downloadFirstImageFromGooglePatent(PatentPath patentPath) throws IOException {
            PatentFile patentFile = new PatentFile();
            patentFile.setInfo(patentPath.info);

            String srcUrl;
            String patentNumber = getGooglePatentNumber(patentPath.info);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + "MM" + "dd");

            switch (patentFile.getInfo().ptoVO) {
            case US:
            case USPTO:
                srcUrl = String.format("http://patentimages.storage.googleapis.com/%1$s%2$s/%1$s%2$s-%3$s-D00000.png",
                        patentNumber, patentFile.getInfo().kindcode, dateFormat.format(patentFile.getInfo().doDate));
                break;
            default:
                throw new UnsupportedEncodingException("unsupported pto for download PDF from google patent");
            }

            File destFile = getGooglePatentFile(patentFile, Paths.get("firstImage.png"));

            boolean successful = DownloadUtils.downloadAndWriteFile(srcUrl, destFile);
            if (successful) {
                patentFile.setFile(destFile);
                patentFile.setMimeType("image/gif");
            }
            return patentFile;
        }
    }

    public static int getClipCounts(PatentPath patpath) {
        PatentFile pfile = new PatentFile();
        pfile.info = patpath.info;
        List<Path> pathlist = FileUtils.listPatentFilesBySuffix(patpath, Paths.get("clip"), ".tif", ".jpg", "png");
        if (pathlist.isEmpty()) {
            return 0;
        } else {
            return pathlist.size();
        }
    }

    public static String getImagePath(SolrPatentInfo solrPatentInfo) {
        ArrayList<Integer> statsList = solrPatentInfo.getStats();
        String patentNumber = solrPatentInfo.getPatentNumber();
        DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String doDateStr = sdf.format(solrPatentInfo.getDoDate());
        doDateStr = doDateStr.substring(0, 10).replace("-", "/");
        String kindCode = solrPatentInfo.getKindcode().toString();
        String path = solrPatentInfo.getCountry().toLowerCase() + statsList.get(statsList.size() - 1)
                + kindCode.toLowerCase() + "/" + doDateStr + "/" + patentNumber;
        return path;
    }

}
