package com.patentcloud.api.server.dao;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.RequestCounter;
import com.patentcloud.api.server.dao.common.AbstractDaoSupport;
import com.patentcloud.api.server.dao.mapper.RequestCounterRowMapper;

public class RequestCounterDaoImpl extends AbstractDaoSupport implements RequestCounterDao {

    private static final Logger log = LoggerFactory.getLogger(RequestCounterDaoImpl.class);

    public RequestCounter getRequestCounterByDate(String userId, Date now) {
        Date tmorrow = DateUtils.addDays(now, 1);

        String sql = "SELECT * FROM RequestCounter WHERE UserID = ? AND CreatedDateTime >= ? AND CreatedDateTime <= ? order by CreatedDateTime desc";

        Object[] parameterArray = new Object[] { userId, now, tmorrow };

        List<RequestCounter> reqCounterList = this.getJdbcTemplate().query(sql, parameterArray,
                new RequestCounterRowMapper());

        RequestCounter requestCounter = null;
        if (reqCounterList != null && !reqCounterList.isEmpty()) {
            requestCounter = reqCounterList.get(0);
        }

        return requestCounter;
    }

    public void addRequestCounter(RequestCounter requestCounterInfo) {
        final String sql = "INSERT INTO RequestCounter (userID, requestCount, createdDateTime) VALUES (?, ?, ?)";

        Object[] parameterArray = new Object[] { requestCounterInfo.getUserId(), requestCounterInfo.getRequestCount(),
                requestCounterInfo.getCreatedDateTime() };

        this.getJdbcTemplate().update(sql, parameterArray);
    }

    public void updateRequestCounter(RequestCounter requestCounterInfo) {
        final String sql = "UPDATE RequestCounter SET requestCount = ? WHERE id = ?";

        Object[] parameterArray = new Object[] { requestCounterInfo.getRequestCount(), requestCounterInfo.getId() };

        this.getJdbcTemplate().update(sql, parameterArray);
    }
}
