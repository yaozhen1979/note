package com.patentcloud.api.model.solr;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.solr.client.solrj.beans.Field;

public class SolrPatentInfo {
    @Field
    public String ptopid;

    @Field
    public String id;

    @Field
    public String pto;

    @Field
    public String country;

    @Field
    public Date appDate;

    @Field
    public Integer appYear;

    @Field
    public Integer appYearmon;

    @Field
    public Date certificateDate;

    @Field
    public Integer certificateYear;

    @Field
    public Integer certificateYearmon;

    @Field
    public Date decisionDate;

    @Field
    public Integer decisionYear;

    @Field
    public Integer decisionYearmon;

    @Field
    public Date examDate;

    @Field
    public Integer examYear;

    @Field
    public Integer examYearmon;

    @Field
    public Date openDate;

    @Field
    public Integer openYear;

    @Field
    public Integer openYearmon;

    @Field
    public Date pctAppDate;

    @Field
    public Integer pctAppYear;

    @Field
    public Integer pctAppYearmon;

    @Field
    public Date pctOpenDate;

    @Field
    public Integer pctOpenYear;

    @Field
    public Integer pctOpenYearmon;

    @Field
    public String appNumber;

    @Field
    public ArrayList<String> appNumberAll;

    @Field
    public String certificateNumber;

    @Field
    public ArrayList<String> certificateNumberAll;

    @Field
    public String decisionNumber;

    @Field
    public ArrayList<String> decisionNumberAll;

    @Field
    public String openNumber;

    @Field
    public ArrayList<String> openNumberAll;

    @Field
    public String patentNumber;

    @Field
    public ArrayList<String> patentNumberAll;

    @Field
    public String pctAppNumber;

    @Field
    public ArrayList<String> pctAppNumberAll;

    @Field
    public String pctOpenNumber;

    @Field
    public ArrayList<String> pctOpenNumberAll;

    @Field
    public String mainCPC;

    @Field
    public String mainCPCNormal;

    @Field
    public String mainIPC;

    @Field
    public String mainIPCNormal;

    @Field
    public String mainIPCR;

    @Field
    public String mainLOC;

    @Field
    public String mainUSPC;

    @Field
    public String mainFI;

    @Field
    public String mainFterm;

    @Field
    public String mainDI;

    @Field
    public String mainDTerm;

    @Field
    public ArrayList<String> cpcs;

    @Field
    public ArrayList<String> cpcsNormal;

    @Field
    public ArrayList<String> ipcs;

    @Field
    public ArrayList<String> ipcsNormal;

    @Field
    public ArrayList<String> ipcrs;

    @Field
    public ArrayList<String> locs;

    @Field
    public ArrayList<String> uspcs;

    @Field
    public ArrayList<String> fis;

    @Field
    public ArrayList<String> fterms;

    @Field
    public ArrayList<String> dis;

    @Field
    public ArrayList<String> dterms;

    @Field
    public ArrayList<String> eclas;

    @Field
    public ArrayList<String> agents;

    @Field
    public ArrayList<String> agentsName;

    @Field
    public ArrayList<String> agentsAddress;

    @Field
    public ArrayList<String> agentsCountry;

    @Field
    public ArrayList<String> agentsFacetname;

    @Field
    public ArrayList<String> agentOperators;

    @Field
    public ArrayList<String> agentOperatorsName;

    @Field
    public ArrayList<String> agentOperatorsAddress;

    @Field
    public ArrayList<String> agentOperatorsCountry;

    @Field
    public ArrayList<String> agentOperatorsFacetname;

    @Field
    public ArrayList<String> applicants;

    @Field
    public ArrayList<String> applicantsName;

    @Field
    public ArrayList<String> applicantsAddress;

    @Field
    public ArrayList<String> applicantsCountry;

    @Field
    public ArrayList<String> applicantsFacetname;

    @Field
    public ArrayList<String> assignees;

    @Field
    public ArrayList<String> assigneesName;

    @Field
    public ArrayList<String> assigneesAddress;

    @Field
    public ArrayList<String> assigneesCountry;

    @Field
    public ArrayList<String> assigneesFacetname;

    @Field
    public ArrayList<String> currentAssigneesName;

    @Field
    public ArrayList<String> currentAssigneesFacetname;

    @Field
    public ArrayList<String> inventors;

    @Field
    public ArrayList<String> inventorsName;

    @Field
    public ArrayList<String> inventorsAddress;

    @Field
    public ArrayList<String> inventorsCountry;

    @Field
    public ArrayList<String> inventorsFacetname;

    @Field
    public ArrayList<String> examinerMasters;

    @Field
    public ArrayList<String> examinerMastersName;

    @Field
    public ArrayList<String> examinerMastersAddress;

    @Field
    public ArrayList<String> examinerMastersCountry;

    @Field
    public ArrayList<String> examinerMastersFacetname;

    @Field
    public ArrayList<String> examinerSlaves;

    @Field
    public ArrayList<String> examinerSlavesName;

    @Field
    public ArrayList<String> examinerSlavesAddress;

    @Field
    public ArrayList<String> examinerSlavesCountry;

    @Field
    public ArrayList<String> examinerSlavesFacetname;

    @Field
    public ArrayList<String> docdbAssignees;

    @Field
    public ArrayList<String> docdbAssigneesName;

    @Field
    public ArrayList<String> docdbAssigneesFacetname;

    @Field
    public ArrayList<String> docdbAssigneesAddress;

    @Field
    public ArrayList<String> docdbAssigneesCountry;

    @Field
    public ArrayList<String> docdbaAssignees;

    @Field
    public ArrayList<String> docdbaAssigneesName;

    @Field
    public ArrayList<String> docdbaAssigneesFacetname;

    @Field
    public ArrayList<String> docdbaAssigneesAddress;

    @Field
    public ArrayList<String> docdbaAssigneesCountry;

    @Field
    public ArrayList<String> docdbInventors;

    @Field
    public ArrayList<String> docdbInventorsName;

    @Field
    public ArrayList<String> docdbInventorsFacetname;

    @Field
    public ArrayList<String> docdbInventorsAddress;

    @Field
    public ArrayList<String> docdbInventorsCountry;

    @Field
    public ArrayList<String> docdbaInventors;

    @Field
    public ArrayList<String> docdbaInventorsName;

    @Field
    public ArrayList<String> docdbaInventorsFacetname;

    @Field
    public ArrayList<String> docdbaInventorsAddress;

    @Field
    public ArrayList<String> docdbaInventorsCountry;

    // image info
    @Field
    public Integer filePageClaim;

    @Field
    public Integer filePageDesc;

    @Field
    public Integer filePageFig;

    @Field
    public Integer filePageFirst;

    @Field
    public Integer filePageNumber;

    @Field
    public Integer gazettePageNumber;

    @Field
    public Integer clipPageNumber;

    @Field
    public Integer figurePageNumber;

    @Field
    public boolean firstImagePageFlag;

    @Field
    public ArrayList<String> otherReferences;

    @Field
    public ArrayList<String> priorityPatents;

    @Field
    public ArrayList<String> priorityPatentsNumberAll;

    @Field
    public ArrayList<String> citedPatents;

    @Field
    public ArrayList<String> citedPatentsNumberAll;

    @Field
    public ArrayList<String> relatedPatents;

    @Field
    public String dividedPatent;

    @Field
    public String kindcode;

    @Field
    public String type;

    @Field
    public int typeCode;

    @Field
    public ArrayList<Integer> stats;

    @Field
    public Integer familyId;

    @Field
    public String brief;

    @Field
    public String claim;

    @Field
    public String description;

    @Field
    public String title;

    @Field
    public Date doDate;

    @Field
    public Integer doYear;

    @Field
    public Integer doYearmon;

    @Field
    public Date docdbDoDate;

    @Field
    public Integer docdbDoYear;

    @Field
    public Integer docdbDoYearmon;

    @Field
    public boolean truncate;

    @Field
    public Date solrIndexTime;

    // project usage
    @Field
    public List<String> projectId;

    @Field
    public List<String> treeId;

    @Field
    public List<String> nodeId;

    @Field
    public String patentId;

    @Field
    public List<String> tag;

    // record source from pto or patentcloud
    @Field
    public int source;

    @Field
    public List<String> tagValue;

    @Field
    public String familyIdGroup;

    @Field
    public String appNumberGroup;

    // law suit info
    @Field
    public List<String> lawsuitIds;

    @Field
    public List<String> lawsuitTitles;

    @Field
    public List<String> lawsuitDocketNumbers;

    @Field
    public List<String> lawsuitCounts;

    @Field
    public List<Date> lawsuitDatesField;

    @Field
    public List<String> lawsuitCauses;

    @Field
    public List<String> lawsuitPlaintiffs;

    @Field
    public List<String> lawsuitDefendants;

    @Field
    public List<String> lawsuitCases;

    @Field
    public List<Date> lawsuitDocketInfoDates;

    @Field
    public List<String> lawsuitTypes;

    @Field
    public List<String> lawsuitDescs;

    @Field
    public List<String> lawsuitRelatedCases;

    @Field
    public List<String> lawsuitCounterDefendants;

    @Field
    public List<String> lawsuitCounterClaimants;

    @Field
    public List<String> lawsuitAdditionalDefendants;

    @Field
    public List<String> lawsuitThrees;

    @Field
    public List<String> lawsuitConsolCounterClaimants;

    @Field
    public List<String> lawsuitMediators;

    @Field
    public List<String> lawsuitThirdPartyPlaintiffs;

    @Field
    public List<String> lawsuitThirdPartyDefendants;

    @Field
    public List<String> lawsuitRegistrationNos;

    @Field
    public List<String> lawsuitContents;

    @Field
    public Integer lawsuitTotalCount;

    // 1.9 new field
    @Field
    public Date currentAssigneesUpdateDate;

    @Field
    public String mainIPCClass;

    @Field
    public String mainIPCSubClass;

    @Field
    public String mainIPCGroup;

    @Field
    public String mainIPCSubGroup;

    @Field
    public String mainCPCClass;

    @Field
    public String mainCPCSubClass;

    @Field
    public String mainCPCGroup;

    @Field
    public String mainCPCSubGroup;

    @Field
    public String mainLOCClass;

    @Field
    public List<String> ipcsClass;

    @Field
    public List<String> ipcsSubClass;

    @Field
    public List<String> ipcsGroup;

    @Field
    public List<String> ipcsSubGroup;

    @Field
    public List<String> cpcsClass;

    @Field
    public List<String> cpcsSubClass;

    @Field
    public List<String> cpcsGroup;

    @Field
    public List<String> cpcsSubGroup;

    @Field
    public List<String> locsClass;

    public String getPtopid() {
        return ptopid;
    }

    public void setPtopid(String ptopid) {
        this.ptopid = ptopid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPto() {
        return pto;
    }

    public void setPto(String pto) {
        this.pto = pto;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Date getAppDate() {
        return appDate;
    }

    public void setAppDate(Date appDate) {
        this.appDate = appDate;
    }

    public Integer getAppYear() {
        return appYear;
    }

    public void setAppYear(Integer appYear) {
        this.appYear = appYear;
    }

    public Integer getAppYearmon() {
        return appYearmon;
    }

    public void setAppYearmon(Integer appYearmon) {
        this.appYearmon = appYearmon;
    }

    public Date getCertificateDate() {
        return certificateDate;
    }

    public void setCertificateDate(Date certificateDate) {
        this.certificateDate = certificateDate;
    }

    public Integer getCertificateYear() {
        return certificateYear;
    }

    public void setCertificateYear(Integer certificateYear) {
        this.certificateYear = certificateYear;
    }

    public Integer getCertificateYearmon() {
        return certificateYearmon;
    }

    public void setCertificateYearmon(Integer certificateYearmon) {
        this.certificateYearmon = certificateYearmon;
    }

    public Date getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(Date decisionDate) {
        this.decisionDate = decisionDate;
    }

    public Integer getDecisionYear() {
        return decisionYear;
    }

    public void setDecisionYear(Integer decisionYear) {
        this.decisionYear = decisionYear;
    }

    public Integer getDecisionYearmon() {
        return decisionYearmon;
    }

    public void setDecisionYearmon(Integer decisionYearmon) {
        this.decisionYearmon = decisionYearmon;
    }

    public Date getExamDate() {
        return examDate;
    }

    public void setExamDate(Date examDate) {
        this.examDate = examDate;
    }

    public Integer getExamYear() {
        return examYear;
    }

    public void setExamYear(Integer examYear) {
        this.examYear = examYear;
    }

    public Integer getExamYearmon() {
        return examYearmon;
    }

    public void setExamYearmon(Integer examYearmon) {
        this.examYearmon = examYearmon;
    }

    public Date getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    public Integer getOpenYear() {
        return openYear;
    }

    public void setOpenYear(Integer openYear) {
        this.openYear = openYear;
    }

    public Integer getOpenYearmon() {
        return openYearmon;
    }

    public void setOpenYearmon(Integer openYearmon) {
        this.openYearmon = openYearmon;
    }

    public Date getPctAppDate() {
        return pctAppDate;
    }

    public void setPctAppDate(Date pctAppDate) {
        this.pctAppDate = pctAppDate;
    }

    public Integer getPctAppYear() {
        return pctAppYear;
    }

    public void setPctAppYear(Integer pctAppYear) {
        this.pctAppYear = pctAppYear;
    }

    public Integer getPctAppYearmon() {
        return pctAppYearmon;
    }

    public void setPctAppYearmon(Integer pctAppYearmon) {
        this.pctAppYearmon = pctAppYearmon;
    }

    public Date getPctOpenDate() {
        return pctOpenDate;
    }

    public void setPctOpenDate(Date pctOpenDate) {
        this.pctOpenDate = pctOpenDate;
    }

    public Integer getPctOpenYear() {
        return pctOpenYear;
    }

    public void setPctOpenYear(Integer pctOpenYear) {
        this.pctOpenYear = pctOpenYear;
    }

    public Integer getPctOpenYearmon() {
        return pctOpenYearmon;
    }

    public void setPctOpenYearmon(Integer pctOpenYearmon) {
        this.pctOpenYearmon = pctOpenYearmon;
    }

    public String getAppNumber() {
        return appNumber;
    }

    public void setAppNumber(String appNumber) {
        this.appNumber = appNumber;
    }

    public ArrayList<String> getAppNumberAll() {
        return appNumberAll;
    }

    public void setAppNumberAll(ArrayList<String> appNumberAll) {
        this.appNumberAll = appNumberAll;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public ArrayList<String> getCertificateNumberAll() {
        return certificateNumberAll;
    }

    public void setCertificateNumberAll(ArrayList<String> certificateNumberAll) {
        this.certificateNumberAll = certificateNumberAll;
    }

    public String getDecisionNumber() {
        return decisionNumber;
    }

    public void setDecisionNumber(String decisionNumber) {
        this.decisionNumber = decisionNumber;
    }

    public ArrayList<String> getDecisionNumberAll() {
        return decisionNumberAll;
    }

    public void setDecisionNumberAll(ArrayList<String> decisionNumberAll) {
        this.decisionNumberAll = decisionNumberAll;
    }

    public String getOpenNumber() {
        return openNumber;
    }

    public void setOpenNumber(String openNumber) {
        this.openNumber = openNumber;
    }

    public ArrayList<String> getOpenNumberAll() {
        return openNumberAll;
    }

    public void setOpenNumberAll(ArrayList<String> openNumberAll) {
        this.openNumberAll = openNumberAll;
    }

    public String getPatentNumber() {
        return patentNumber;
    }

    public void setPatentNumber(String patentNumber) {
        this.patentNumber = patentNumber;
    }

    public ArrayList<String> getPatentNumberAll() {
        return patentNumberAll;
    }

    public void setPatentNumberAll(ArrayList<String> patentNumberAll) {
        this.patentNumberAll = patentNumberAll;
    }

    public String getPctAppNumber() {
        return pctAppNumber;
    }

    public void setPctAppNumber(String pctAppNumber) {
        this.pctAppNumber = pctAppNumber;
    }

    public ArrayList<String> getPctAppNumberAll() {
        return pctAppNumberAll;
    }

    public void setPctAppNumberAll(ArrayList<String> pctAppNumberAll) {
        this.pctAppNumberAll = pctAppNumberAll;
    }

    public String getPctOpenNumber() {
        return pctOpenNumber;
    }

    public void setPctOpenNumber(String pctOpenNumber) {
        this.pctOpenNumber = pctOpenNumber;
    }

    public ArrayList<String> getPctOpenNumberAll() {
        return pctOpenNumberAll;
    }

    public void setPctOpenNumberAll(ArrayList<String> pctOpenNumberAll) {
        this.pctOpenNumberAll = pctOpenNumberAll;
    }

    public String getMainCPC() {
        return mainCPC;
    }

    public void setMainCPC(String mainCPC) {
        this.mainCPC = mainCPC;
    }

    public String getMainIPC() {
        return mainIPC;
    }

    public void setMainIPC(String mainIPC) {
        this.mainIPC = mainIPC;
    }

    public String getMainIPCR() {
        return mainIPCR;
    }

    public void setMainIPCR(String mainIPCR) {
        this.mainIPCR = mainIPCR;
    }

    public String getMainLOC() {
        return mainLOC;
    }

    public void setMainLOC(String mainLOC) {
        this.mainLOC = mainLOC;
    }

    public String getMainUSPC() {
        return mainUSPC;
    }

    public void setMainUSPC(String mainUSPC) {
        this.mainUSPC = mainUSPC;
    }

    public String getMainFI() {
        return mainFI;
    }

    public void setMainFI(String mainFI) {
        this.mainFI = mainFI;
    }

    public String getMainFterm() {
        return mainFterm;
    }

    public void setMainFterm(String mainFterm) {
        this.mainFterm = mainFterm;
    }

    public String getMainDI() {
        return mainDI;
    }

    public void setMainDI(String mainDI) {
        this.mainDI = mainDI;
    }

    public String getMainDTerm() {
        return mainDTerm;
    }

    public void setMainDTerm(String mainDTerm) {
        this.mainDTerm = mainDTerm;
    }

    public ArrayList<String> getCpcs() {
        return cpcs;
    }

    public void setCpcs(ArrayList<String> cpcs) {
        this.cpcs = cpcs;
    }

    public ArrayList<String> getCpcsNormal() {
        return cpcsNormal;
    }

    public void setCpcsNormal(ArrayList<String> cpcsNormal) {
        this.cpcsNormal = cpcsNormal;
    }

    public ArrayList<String> getIpcs() {
        return ipcs;
    }

    public void setIpcs(ArrayList<String> ipcs) {
        this.ipcs = ipcs;
    }

    public ArrayList<String> getIpcrs() {
        return ipcrs;
    }

    public void setIpcrs(ArrayList<String> ipcrs) {
        this.ipcrs = ipcrs;
    }

    public ArrayList<String> getLocs() {
        return locs;
    }

    public void setLocs(ArrayList<String> locs) {
        this.locs = locs;
    }

    public ArrayList<String> getUspcs() {
        return uspcs;
    }

    public void setUspcs(ArrayList<String> uspcs) {
        this.uspcs = uspcs;
    }

    public ArrayList<String> getFis() {
        return fis;
    }

    public void setFis(ArrayList<String> fis) {
        this.fis = fis;
    }

    public ArrayList<String> getFterms() {
        return fterms;
    }

    public void setFterms(ArrayList<String> fterms) {
        this.fterms = fterms;
    }

    public ArrayList<String> getDis() {
        return dis;
    }

    public void setDis(ArrayList<String> dis) {
        this.dis = dis;
    }

    public ArrayList<String> getDterms() {
        return dterms;
    }

    public void setDterms(ArrayList<String> dterms) {
        this.dterms = dterms;
    }

    public ArrayList<String> getEclas() {
        return eclas;
    }

    public void setEclas(ArrayList<String> eclas) {
        this.eclas = eclas;
    }

    public ArrayList<String> getAgents() {
        return agents;
    }

    public void setAgents(ArrayList<String> agents) {
        this.agents = agents;
    }

    public ArrayList<String> getAgentsName() {
        return agentsName;
    }

    public void setAgentsName(ArrayList<String> agentsName) {
        this.agentsName = agentsName;
    }

    public ArrayList<String> getAgentsAddress() {
        return agentsAddress;
    }

    public void setAgentsAddress(ArrayList<String> agentsAddress) {
        this.agentsAddress = agentsAddress;
    }

    public ArrayList<String> getAgentsCountry() {
        return agentsCountry;
    }

    public void setAgentsCountry(ArrayList<String> agentsCountry) {
        this.agentsCountry = agentsCountry;
    }

    public ArrayList<String> getAgentsFacetname() {
        return agentsFacetname;
    }

    public void setAgentsFacetname(ArrayList<String> agentsFacetname) {
        this.agentsFacetname = agentsFacetname;
    }

    public ArrayList<String> getAgentOperators() {
        return agentOperators;
    }

    public void setAgentOperators(ArrayList<String> agentOperators) {
        this.agentOperators = agentOperators;
    }

    public ArrayList<String> getAgentOperatorsName() {
        return agentOperatorsName;
    }

    public void setAgentOperatorsName(ArrayList<String> agentOperatorsName) {
        this.agentOperatorsName = agentOperatorsName;
    }

    public ArrayList<String> getAgentOperatorsAddress() {
        return agentOperatorsAddress;
    }

    public void setAgentOperatorsAddress(ArrayList<String> agentOperatorsAddress) {
        this.agentOperatorsAddress = agentOperatorsAddress;
    }

    public ArrayList<String> getAgentOperatorsCountry() {
        return agentOperatorsCountry;
    }

    public void setAgentOperatorsCountry(ArrayList<String> agentOperatorsCountry) {
        this.agentOperatorsCountry = agentOperatorsCountry;
    }

    public ArrayList<String> getAgentOperatorsFacetname() {
        return agentOperatorsFacetname;
    }

    public void setAgentOperatorsFacetname(ArrayList<String> agentOperatorsFacetname) {
        this.agentOperatorsFacetname = agentOperatorsFacetname;
    }

    public ArrayList<String> getApplicants() {
        return applicants;
    }

    public void setApplicants(ArrayList<String> applicants) {
        this.applicants = applicants;
    }

    public ArrayList<String> getApplicantsName() {
        return applicantsName;
    }

    public void setApplicantsName(ArrayList<String> applicantsName) {
        this.applicantsName = applicantsName;
    }

    public ArrayList<String> getApplicantsAddress() {
        return applicantsAddress;
    }

    public void setApplicantsAddress(ArrayList<String> applicantsAddress) {
        this.applicantsAddress = applicantsAddress;
    }

    public ArrayList<String> getApplicantsCountry() {
        return applicantsCountry;
    }

    public void setApplicantsCountry(ArrayList<String> applicantsCountry) {
        this.applicantsCountry = applicantsCountry;
    }

    public ArrayList<String> getApplicantsFacetname() {
        return applicantsFacetname;
    }

    public void setApplicantsFacetname(ArrayList<String> applicantsFacetname) {
        this.applicantsFacetname = applicantsFacetname;
    }

    public ArrayList<String> getAssignees() {
        return assignees;
    }

    public void setAssignees(ArrayList<String> assignees) {
        this.assignees = assignees;
    }

    public ArrayList<String> getAssigneesName() {
        return assigneesName;
    }

    public void setAssigneesName(ArrayList<String> assigneesName) {
        this.assigneesName = assigneesName;
    }

    public ArrayList<String> getAssigneesAddress() {
        return assigneesAddress;
    }

    public void setAssigneesAddress(ArrayList<String> assigneesAddress) {
        this.assigneesAddress = assigneesAddress;
    }

    public ArrayList<String> getAssigneesCountry() {
        return assigneesCountry;
    }

    public void setAssigneesCountry(ArrayList<String> assigneesCountry) {
        this.assigneesCountry = assigneesCountry;
    }

    public ArrayList<String> getAssigneesFacetname() {
        return assigneesFacetname;
    }

    public void setAssigneesFacetname(ArrayList<String> assigneesFacetname) {
        this.assigneesFacetname = assigneesFacetname;
    }

    public ArrayList<String> getCurrentAssigneesName() {
        return currentAssigneesName;
    }

    public void setCurrentAssigneesName(ArrayList<String> currentAssigneesName) {
        this.currentAssigneesName = currentAssigneesName;
    }

    public ArrayList<String> getCurrentAssigneesFacetname() {
        return currentAssigneesFacetname;
    }

    public void setCurrentAssigneesFacetname(ArrayList<String> currentAssigneesFacetname) {
        this.currentAssigneesFacetname = currentAssigneesFacetname;
    }

    public ArrayList<String> getInventors() {
        return inventors;
    }

    public void setInventors(ArrayList<String> inventors) {
        this.inventors = inventors;
    }

    public ArrayList<String> getInventorsName() {
        return inventorsName;
    }

    public void setInventorsName(ArrayList<String> inventorsName) {
        this.inventorsName = inventorsName;
    }

    public ArrayList<String> getInventorsAddress() {
        return inventorsAddress;
    }

    public void setInventorsAddress(ArrayList<String> inventorsAddress) {
        this.inventorsAddress = inventorsAddress;
    }

    public ArrayList<String> getInventorsCountry() {
        return inventorsCountry;
    }

    public void setInventorsCountry(ArrayList<String> inventorsCountry) {
        this.inventorsCountry = inventorsCountry;
    }

    public ArrayList<String> getInventorsFacetname() {
        return inventorsFacetname;
    }

    public void setInventorsFacetname(ArrayList<String> inventorsFacetname) {
        this.inventorsFacetname = inventorsFacetname;
    }

    public ArrayList<String> getExaminerMasters() {
        return examinerMasters;
    }

    public void setExaminerMasters(ArrayList<String> examinerMasters) {
        this.examinerMasters = examinerMasters;
    }

    public ArrayList<String> getExaminerMastersName() {
        return examinerMastersName;
    }

    public void setExaminerMastersName(ArrayList<String> examinerMastersName) {
        this.examinerMastersName = examinerMastersName;
    }

    public ArrayList<String> getExaminerMastersAddress() {
        return examinerMastersAddress;
    }

    public void setExaminerMastersAddress(ArrayList<String> examinerMastersAddress) {
        this.examinerMastersAddress = examinerMastersAddress;
    }

    public ArrayList<String> getExaminerMastersCountry() {
        return examinerMastersCountry;
    }

    public void setExaminerMastersCountry(ArrayList<String> examinerMastersCountry) {
        this.examinerMastersCountry = examinerMastersCountry;
    }

    public ArrayList<String> getExaminerMastersFacetname() {
        return examinerMastersFacetname;
    }

    public void setExaminerMastersFacetname(ArrayList<String> examinerMastersFacetname) {
        this.examinerMastersFacetname = examinerMastersFacetname;
    }

    public ArrayList<String> getExaminerSlaves() {
        return examinerSlaves;
    }

    public void setExaminerSlaves(ArrayList<String> examinerSlaves) {
        this.examinerSlaves = examinerSlaves;
    }

    public ArrayList<String> getExaminerSlavesName() {
        return examinerSlavesName;
    }

    public void setExaminerSlavesName(ArrayList<String> examinerSlavesName) {
        this.examinerSlavesName = examinerSlavesName;
    }

    public ArrayList<String> getExaminerSlavesAddress() {
        return examinerSlavesAddress;
    }

    public void setExaminerSlavesAddress(ArrayList<String> examinerSlavesAddress) {
        this.examinerSlavesAddress = examinerSlavesAddress;
    }

    public ArrayList<String> getExaminerSlavesCountry() {
        return examinerSlavesCountry;
    }

    public void setExaminerSlavesCountry(ArrayList<String> examinerSlavesCountry) {
        this.examinerSlavesCountry = examinerSlavesCountry;
    }

    public ArrayList<String> getExaminerSlavesFacetname() {
        return examinerSlavesFacetname;
    }

    public void setExaminerSlavesFacetname(ArrayList<String> examinerSlavesFacetname) {
        this.examinerSlavesFacetname = examinerSlavesFacetname;
    }

    public Integer getFilePageClaim() {
        return filePageClaim;
    }

    public void setFilePageClaim(Integer filePageClaim) {
        this.filePageClaim = filePageClaim;
    }

    public Integer getFilePageDesc() {
        return filePageDesc;
    }

    public void setFilePageDesc(Integer filePageDesc) {
        this.filePageDesc = filePageDesc;
    }

    public Integer getFilePageFig() {
        return filePageFig;
    }

    public void setFilePageFig(Integer filePageFig) {
        this.filePageFig = filePageFig;
    }

    public Integer getFilePageFirst() {
        return filePageFirst;
    }

    public void setFilePageFirst(Integer filePageFirst) {
        this.filePageFirst = filePageFirst;
    }

    public Integer getFilePageNumber() {
        return filePageNumber;
    }

    public void setFilePageNumber(Integer filePageNumber) {
        this.filePageNumber = filePageNumber;
    }

    public Integer getGazettePageNumber() {
        return gazettePageNumber;
    }

    public void setGazettePageNumber(Integer gazettePageNumber) {
        this.gazettePageNumber = gazettePageNumber;
    }

    public Integer getClipPageNumber() {
        return clipPageNumber;
    }

    public void setClipPageNumber(Integer clipPageNumber) {
        this.clipPageNumber = clipPageNumber;
    }

    public Integer getFigurePageNumber() {
        return figurePageNumber;
    }

    public void setFigurePageNumber(Integer figurePageNumber) {
        this.figurePageNumber = figurePageNumber;
    }

    public boolean isFirstImagePageFlag() {
        return firstImagePageFlag;
    }

    public void setFirstImagePageFlag(boolean firstImagePageFlag) {
        this.firstImagePageFlag = firstImagePageFlag;
    }

    public ArrayList<String> getOtherReferences() {
        return otherReferences;
    }

    public void setOtherReferences(ArrayList<String> otherReferences) {
        this.otherReferences = otherReferences;
    }

    public List<String> getLawsuitContents() {
        return lawsuitContents;
    }

    public void setLawsuitContents(ArrayList<String> lawsuitContents) {
        this.lawsuitContents = lawsuitContents;
    }

    public ArrayList<String> getPriorityPatents() {
        return priorityPatents;
    }

    public void setPriorityPatents(ArrayList<String> priorityPatents) {
        this.priorityPatents = priorityPatents;
    }

    public ArrayList<String> getPriorityPatentsNumberAll() {
        return priorityPatentsNumberAll;
    }

    public void setPriorityPatentsNumberAll(ArrayList<String> priorityPatentsNumberAll) {
        this.priorityPatentsNumberAll = priorityPatentsNumberAll;
    }

    public ArrayList<String> getCitedPatents() {
        return citedPatents;
    }

    public void setCitedPatents(ArrayList<String> citedPatents) {
        this.citedPatents = citedPatents;
    }

    public ArrayList<String> getCitedPatentsNumberAll() {
        return citedPatentsNumberAll;
    }

    public void setCitedPatentsNumberAll(ArrayList<String> citedPatentsNumberAll) {
        this.citedPatentsNumberAll = citedPatentsNumberAll;
    }

    public ArrayList<String> getRelatedPatents() {
        return relatedPatents;
    }

    public void setRelatedPatents(ArrayList<String> relatedPatents) {
        this.relatedPatents = relatedPatents;
    }

    public String getDividedPatent() {
        return dividedPatent;
    }

    public void setDividedPatent(String dividedPatent) {
        this.dividedPatent = dividedPatent;
    }

    public String getKindcode() {
        return kindcode;
    }

    public void setKindcode(String kindcode) {
        this.kindcode = kindcode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(int typeCode) {
        this.typeCode = typeCode;
    }

    public ArrayList<Integer> getStats() {
        return stats;
    }

    public void setStats(ArrayList<Integer> stats) {
        this.stats = stats;
    }

    public Integer getFamilyId() {
        return familyId;
    }

    public void setFamilyId(Integer familyId) {
        this.familyId = familyId;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getClaim() {
        return claim;
    }

    public void setClaim(String claim) {
        this.claim = claim;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDoDate() {
        return doDate;
    }

    public void setDoDate(Date doDate) {
        this.doDate = doDate;
    }

    public Integer getDoYear() {
        return doYear;
    }

    public void setDoYear(Integer doYear) {
        this.doYear = doYear;
    }

    public Integer getDoYearmon() {
        return doYearmon;
    }

    public void setDoYearmon(Integer doYearmon) {
        this.doYearmon = doYearmon;
    }

    public Date getDocdbDoDate() {
        return docdbDoDate;
    }

    public void setDocdbDoDate(Date docdbDoDate) {
        this.docdbDoDate = docdbDoDate;
    }

    public Integer getDocdbDoYear() {
        return docdbDoYear;
    }

    public void setDocdbDoYear(Integer docdbDoYear) {
        this.docdbDoYear = docdbDoYear;
    }

    public Integer getDocdbDoYearmon() {
        return docdbDoYearmon;
    }

    public void setDocdbDoYearmon(Integer docdbDoYearmon) {
        this.docdbDoYearmon = docdbDoYearmon;
    }

    public boolean isTruncate() {
        return truncate;
    }

    public void setTruncate(boolean truncate) {
        this.truncate = truncate;
    }

    public Date getSolrIndexTime() {
        return solrIndexTime;
    }

    public void setSolrIndexTime(Date solrIndexTime) {
        this.solrIndexTime = solrIndexTime;
    }

    public List<String> getProjectId() {
        return projectId;
    }

    public void setProjectId(List<String> projectId) {
        this.projectId = projectId;
    }

    public List<String> getTreeId() {
        return treeId;
    }

    public void setTreeId(List<String> treeId) {
        this.treeId = treeId;
    }

    public List<String> getNodeId() {
        return nodeId;
    }

    public void setNodeId(List<String> nodeId) {
        this.nodeId = nodeId;
    }

    public String getPatentId() {
        return patentId;
    }

    public void setPatentId(String patentId) {
        this.patentId = patentId;
    }

    public List<String> getTag() {
        return tag;
    }

    public void setTag(List<String> tag) {
        this.tag = tag;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public List<String> getTagValue() {
        return tagValue;
    }

    public void setTagValue(List<String> tagValue) {
        this.tagValue = tagValue;
    }

    public String getFamilyIdGroup() {
        return familyIdGroup;
    }

    public String getAppNumberGroup() {
        return appNumberGroup;
    }

    public void setFamilyIdGroup(String familyIdGroup) {
        this.familyIdGroup = familyIdGroup;
    }

    public void setAppNumberGroup(String appNumberGroup) {
        this.appNumberGroup = appNumberGroup;
    }

    public ArrayList<String> getDocdbAssignees() {
        return docdbAssignees;
    }

    public void setDocdbAssignees(ArrayList<String> docdbAssignees) {
        this.docdbAssignees = docdbAssignees;
    }

    public ArrayList<String> getDocdbAssigneesFacetname() {
        return docdbAssigneesFacetname;
    }

    public void setDocdbAssigneesFacetname(ArrayList<String> docdbAssigneesFacetname) {
        this.docdbAssigneesFacetname = docdbAssigneesFacetname;
    }

    public ArrayList<String> getDocdbaAssignees() {
        return docdbaAssignees;
    }

    public void setDocdbaAssignees(ArrayList<String> docdbaAssignees) {
        this.docdbaAssignees = docdbaAssignees;
    }

    public ArrayList<String> getDocdbInventors() {
        return docdbInventors;
    }

    public void setDocdbInventors(ArrayList<String> docdbInventors) {
        this.docdbInventors = docdbInventors;
    }

    public ArrayList<String> getDocdbaInventors() {
        return docdbaInventors;
    }

    public void setDocdbaInventors(ArrayList<String> docdbaInventors) {
        this.docdbaInventors = docdbaInventors;
    }

    public ArrayList<String> getIpcsNormal() {
        return ipcsNormal;
    }

    public void setIpcsNormal(ArrayList<String> ipcsNormal) {
        this.ipcsNormal = ipcsNormal;
    }

    public String getMainCPCNormal() {
        return mainCPCNormal;
    }

    public String getMainIPCNormal() {
        return mainIPCNormal;
    }

    public void setMainCPCNormal(String mainCPCNormal) {
        this.mainCPCNormal = mainCPCNormal;
    }

    public void setMainIPCNormal(String mainIPCNormal) {
        this.mainIPCNormal = mainIPCNormal;
    }

    public ArrayList<String> getDocdbAssigneesName() {
        return docdbAssigneesName;
    }

    public void setDocdbAssigneesName(ArrayList<String> docdbAssigneesName) {
        this.docdbAssigneesName = docdbAssigneesName;
    }

    public ArrayList<String> getDocdbAssigneesAddress() {
        return docdbAssigneesAddress;
    }

    public void setDocdbAssigneesAddress(ArrayList<String> docdbAssigneesAddress) {
        this.docdbAssigneesAddress = docdbAssigneesAddress;
    }

    public ArrayList<String> getDocdbAssigneesCountry() {
        return docdbAssigneesCountry;
    }

    public void setDocdbAssigneesCountry(ArrayList<String> docdbAssigneesCountry) {
        this.docdbAssigneesCountry = docdbAssigneesCountry;
    }

    public ArrayList<String> getDocdbaAssigneesName() {
        return docdbaAssigneesName;
    }

    public void setDocdbaAssigneesName(ArrayList<String> docdbaAssigneesName) {
        this.docdbaAssigneesName = docdbaAssigneesName;
    }

    public ArrayList<String> getDocdbaAssigneesFacetname() {
        return docdbaAssigneesFacetname;
    }

    public void setDocdbaAssigneesFacetname(ArrayList<String> docdbaAssigneesFacetname) {
        this.docdbaAssigneesFacetname = docdbaAssigneesFacetname;
    }

    public ArrayList<String> getDocdbaAssigneesAddress() {
        return docdbaAssigneesAddress;
    }

    public void setDocdbaAssigneesAddress(ArrayList<String> docdbaAssigneesAddress) {
        this.docdbaAssigneesAddress = docdbaAssigneesAddress;
    }

    public ArrayList<String> getDocdbaAssigneesCountry() {
        return docdbaAssigneesCountry;
    }

    public void setDocdbaAssigneesCountry(ArrayList<String> docdbaAssigneesCountry) {
        this.docdbaAssigneesCountry = docdbaAssigneesCountry;
    }

    public ArrayList<String> getDocdbInventorsName() {
        return docdbInventorsName;
    }

    public void setDocdbInventorsName(ArrayList<String> docdbInventorsName) {
        this.docdbInventorsName = docdbInventorsName;
    }

    public ArrayList<String> getDocdbInventorsFacetname() {
        return docdbInventorsFacetname;
    }

    public void setDocdbInventorsFacetname(ArrayList<String> docdbInventorsFacetname) {
        this.docdbInventorsFacetname = docdbInventorsFacetname;
    }

    public ArrayList<String> getDocdbInventorsAddress() {
        return docdbInventorsAddress;
    }

    public void setDocdbInventorsAddress(ArrayList<String> docdbInventorsAddress) {
        this.docdbInventorsAddress = docdbInventorsAddress;
    }

    public ArrayList<String> getDocdbInventorsCountry() {
        return docdbInventorsCountry;
    }

    public void setDocdbInventorsCountry(ArrayList<String> docdbInventorsCountry) {
        this.docdbInventorsCountry = docdbInventorsCountry;
    }

    public ArrayList<String> getDocdbaInventorsName() {
        return docdbaInventorsName;
    }

    public void setDocdbaInventorsName(ArrayList<String> docdbaInventorsName) {
        this.docdbaInventorsName = docdbaInventorsName;
    }

    public ArrayList<String> getDocdbaInventorsFacetname() {
        return docdbaInventorsFacetname;
    }

    public void setDocdbaInventorsFacetname(ArrayList<String> docdbaInventorsFacetname) {
        this.docdbaInventorsFacetname = docdbaInventorsFacetname;
    }

    public ArrayList<String> getDocdbaInventorsAddress() {
        return docdbaInventorsAddress;
    }

    public void setDocdbaInventorsAddress(ArrayList<String> docdbaInventorsAddress) {
        this.docdbaInventorsAddress = docdbaInventorsAddress;
    }

    public ArrayList<String> getDocdbaInventorsCountry() {
        return docdbaInventorsCountry;
    }

    public void setDocdbaInventorsCountry(ArrayList<String> docdbaInventorsCountry) {
        this.docdbaInventorsCountry = docdbaInventorsCountry;
    }

    public List<String> getLawsuitIds() {
        return lawsuitIds;
    }

    public void setLawsuitIds(List<String> lawsuitIds) {
        this.lawsuitIds = lawsuitIds;
    }

    public List<String> getLawsuitTitles() {
        return lawsuitTitles;
    }

    public void setLawsuitTitles(List<String> lawsuitTitles) {
        this.lawsuitTitles = lawsuitTitles;
    }

    public List<String> getLawsuitDocketNumbers() {
        return lawsuitDocketNumbers;
    }

    public void setLawsuitDocketNumbers(List<String> lawsuitDocketNumbers) {
        this.lawsuitDocketNumbers = lawsuitDocketNumbers;
    }

    public List<String> getLawsuitCounts() {
        return lawsuitCounts;
    }

    public void setLawsuitCounts(List<String> lawsuitCounts) {
        this.lawsuitCounts = lawsuitCounts;
    }

    public List<Date> getLawsuitDatesField() {
        return lawsuitDatesField;
    }

    public void setLawsuitDatesField(List<Date> lawsuitDatesField) {
        this.lawsuitDatesField = lawsuitDatesField;
    }

    public List<String> getLawsuitCauses() {
        return lawsuitCauses;
    }

    public void setLawsuitCauses(List<String> lawsuitCauses) {
        this.lawsuitCauses = lawsuitCauses;
    }

    public List<String> getLawsuitPlaintiffs() {
        return lawsuitPlaintiffs;
    }

    public void setLawsuitPlaintiffs(List<String> lawsuitPlaintiffs) {
        this.lawsuitPlaintiffs = lawsuitPlaintiffs;
    }

    public List<String> getLawsuitDefendants() {
        return lawsuitDefendants;
    }

    public void setLawsuitDefendants(List<String> lawsuitDefendants) {
        this.lawsuitDefendants = lawsuitDefendants;
    }

    public List<String> getLawsuitCases() {
        return lawsuitCases;
    }

    public void setLawsuitCases(List<String> lawsuitCases) {
        this.lawsuitCases = lawsuitCases;
    }

    public List<Date> getLawsuitDocketInfoDates() {
        return lawsuitDocketInfoDates;
    }

    public void setLawsuitDocketInfoDates(List<Date> lawsuitDocketInfoDates) {
        this.lawsuitDocketInfoDates = lawsuitDocketInfoDates;
    }

    public List<String> getLawsuitTypes() {
        return lawsuitTypes;
    }

    public void setLawsuitTypes(List<String> lawsuitTypes) {
        this.lawsuitTypes = lawsuitTypes;
    }

    public List<String> getLawsuitDescs() {
        return lawsuitDescs;
    }

    public void setLawsuitDescs(List<String> lawsuitDescs) {
        this.lawsuitDescs = lawsuitDescs;
    }

    public List<String> getLawsuitRelatedCases() {
        return lawsuitRelatedCases;
    }

    public void setLawsuitRelatedCases(List<String> lawsuitRelatedCases) {
        this.lawsuitRelatedCases = lawsuitRelatedCases;
    }

    public List<String> getLawsuitCounterDefendants() {
        return lawsuitCounterDefendants;
    }

    public void setLawsuitCounterDefendants(List<String> lawsuitCounterDefendants) {
        this.lawsuitCounterDefendants = lawsuitCounterDefendants;
    }

    public List<String> getLawsuitCounterClaimants() {
        return lawsuitCounterClaimants;
    }

    public void setLawsuitCounterClaimants(List<String> lawsuitCounterClaimants) {
        this.lawsuitCounterClaimants = lawsuitCounterClaimants;
    }

    public List<String> getLawsuitAdditionalDefendants() {
        return lawsuitAdditionalDefendants;
    }

    public void setLawsuitAdditionalDefendants(List<String> lawsuitAdditionalDefendants) {
        this.lawsuitAdditionalDefendants = lawsuitAdditionalDefendants;
    }

    public List<String> getLawsuitThrees() {
        return lawsuitThrees;
    }

    public void setLawsuitThrees(List<String> lawsuitThrees) {
        this.lawsuitThrees = lawsuitThrees;
    }

    public List<String> getLawsuitConsolCounterClaimants() {
        return lawsuitConsolCounterClaimants;
    }

    public void setLawsuitConsolCounterClaimants(List<String> lawsuitConsolCounterClaimants) {
        this.lawsuitConsolCounterClaimants = lawsuitConsolCounterClaimants;
    }

    public List<String> getLawsuitMediators() {
        return lawsuitMediators;
    }

    public void setLawsuitMediators(List<String> lawsuitMediators) {
        this.lawsuitMediators = lawsuitMediators;
    }

    public List<String> getLawsuitThirdPartyPlaintiffs() {
        return lawsuitThirdPartyPlaintiffs;
    }

    public void setLawsuitThirdPartyPlaintiffs(List<String> lawsuitThirdPartyPlaintiffs) {
        this.lawsuitThirdPartyPlaintiffs = lawsuitThirdPartyPlaintiffs;
    }

    public List<String> getLawsuitThirdPartyDefendants() {
        return lawsuitThirdPartyDefendants;
    }

    public void setLawsuitThirdPartyDefendants(List<String> lawsuitThirdPartyDefendants) {
        this.lawsuitThirdPartyDefendants = lawsuitThirdPartyDefendants;
    }

    public List<String> getLawsuitRegistrationNos() {
        return lawsuitRegistrationNos;
    }

    public void setLawsuitRegistrationNos(List<String> lawsuitRegistrationNos) {
        this.lawsuitRegistrationNos = lawsuitRegistrationNos;
    }

    public Integer getLawsuitTotalCount() {
        return lawsuitTotalCount;
    }

    public void setLawsuitTotalCount(Integer lawsuitTotalCount) {
        this.lawsuitTotalCount = lawsuitTotalCount;
    }

    public Date getCurrentAssigneesUpdateDate() {
        return currentAssigneesUpdateDate;
    }

    public void setCurrentAssigneesUpdateDate(Date currentAssigneesUpdateDate) {
        this.currentAssigneesUpdateDate = currentAssigneesUpdateDate;
    }

    public String getMainIPCClass() {
        return mainIPCClass;
    }

    public void setMainIPCClass(String mainIPCClass) {
        this.mainIPCClass = mainIPCClass;
    }

    public String getMainIPCSubClass() {
        return mainIPCSubClass;
    }

    public void setMainIPCSubClass(String mainIPCSubClass) {
        this.mainIPCSubClass = mainIPCSubClass;
    }

    public String getMainIPCGroup() {
        return mainIPCGroup;
    }

    public void setMainIPCGroup(String mainIPCGroup) {
        this.mainIPCGroup = mainIPCGroup;
    }

    public String getMainIPCSubGroup() {
        return mainIPCSubGroup;
    }

    public void setMainIPCSubGroup(String mainIPCSubGroup) {
        this.mainIPCSubGroup = mainIPCSubGroup;
    }

    public String getMainCPCClass() {
        return mainCPCClass;
    }

    public void setMainCPCClass(String mainCPCClass) {
        this.mainCPCClass = mainCPCClass;
    }

    public String getMainCPCSubClass() {
        return mainCPCSubClass;
    }

    public void setMainCPCSubClass(String mainCPCSubClass) {
        this.mainCPCSubClass = mainCPCSubClass;
    }

    public String getMainCPCGroup() {
        return mainCPCGroup;
    }

    public void setMainCPCGroup(String mainCPCGroup) {
        this.mainCPCGroup = mainCPCGroup;
    }

    public String getMainCPCSubGroup() {
        return mainCPCSubGroup;
    }

    public void setMainCPCSubGroup(String mainCPCSubGroup) {
        this.mainCPCSubGroup = mainCPCSubGroup;
    }

    public String getMainLOCClass() {
        return mainLOCClass;
    }

    public void setMainLOCClass(String mainLOCClass) {
        this.mainLOCClass = mainLOCClass;
    }

    public List<String> getIpcsClass() {
        return ipcsClass;
    }

    public void setIpcsClass(List<String> ipcsClass) {
        this.ipcsClass = ipcsClass;
    }

    public List<String> getIpcsSubClass() {
        return ipcsSubClass;
    }

    public void setIpcsSubClass(List<String> ipcsSubClass) {
        this.ipcsSubClass = ipcsSubClass;
    }

    public List<String> getIpcsGroup() {
        return ipcsGroup;
    }

    public void setIpcsGroup(List<String> ipcsGroup) {
        this.ipcsGroup = ipcsGroup;
    }

    public List<String> getIpcsSubGroup() {
        return ipcsSubGroup;
    }

    public void setIpcsSubGroup(List<String> ipcsSubGroup) {
        this.ipcsSubGroup = ipcsSubGroup;
    }

    public List<String> getCpcsClass() {
        return cpcsClass;
    }

    public void setCpcsClass(List<String> cpcsClass) {
        this.cpcsClass = cpcsClass;
    }

    public List<String> getCpcsSubClass() {
        return cpcsSubClass;
    }

    public void setCpcsSubClass(List<String> cpcsSubClass) {
        this.cpcsSubClass = cpcsSubClass;
    }

    public List<String> getCpcsGroup() {
        return cpcsGroup;
    }

    public void setCpcsGroup(List<String> cpcsGroup) {
        this.cpcsGroup = cpcsGroup;
    }

    public List<String> getCpcsSubGroup() {
        return cpcsSubGroup;
    }

    public void setCpcsSubGroup(List<String> cpcsSubGroup) {
        this.cpcsSubGroup = cpcsSubGroup;
    }

    public List<String> getLocsClass() {
        return locsClass;
    }

    public void setLocsClass(List<String> locsClass) {
        this.locsClass = locsClass;
    }
}
