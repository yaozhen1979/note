package com.patentcloud.api.util;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.util.solr.PatentDataConfig;

public class CniprPatentUtils {

    private static final Logger log = LoggerFactory.getLogger(CniprPatentUtils.class);

    private static final Map<String, String> CNIPR_TYPE = new HashMap<>();

    static {
        CNIPR_TYPE.put("发明专利1", "FM");
        CNIPR_TYPE.put("发明专利2", "SQ");
        CNIPR_TYPE.put("实用新型1", "xx");
        CNIPR_TYPE.put("实用新型2", "xx");
        CNIPR_TYPE.put("外观专利1", "WG");
        CNIPR_TYPE.put("外观专利2", "WG");
    }

    private static File getCniprFile(PatentFile pfile, Path filepath) {
        String relpath = PatentDataUtils.getRelPatentPath(pfile.getInfo());
        for (File file : PatentDataConfig.CNIPR_PATH_PTO.get(pfile.getInfo().ptoVO)) {
            return file.toPath().resolve(relpath).resolve(filepath).toFile();
        }
        return new File("");
    }

    public static PatentFile downloadFirstImageFromCnipr(PatentPath patentPath) throws IOException {
        PatentFile patentFile = new PatentFile();
        patentFile.setInfo(patentPath.info);

        PatentInfo info = patentPath.info;

        switch (info.ptoVO) {
        case CN:
        case CNIPR:
            break;
        default:
            throw new UnsupportedEncodingException("unsupported pto for download first image from CNIPR");
        }

        String cniprType = info.type + info.stats.get(info.stats.size() - 1);

        if (!CNIPR_TYPE.containsKey(cniprType)) {
            throw new UnsupportedEncodingException("unsupported type for download first image from CNIPR");
        }

        File destFile = getCniprFile(patentFile, Paths.get("firstImage.gif"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        String srcUrl = "http://pic.cnipr.com/XmlData" + "/" + CNIPR_TYPE.get(cniprType) + "/"
                + sdf.format(info.doDate) + "/" + info.patentNumber + "/" + info.patentNumber.replaceAll("\\.\\S$", "")
                + ".gif";

        boolean successful = DownloadUtils.downloadAndWriteFile(srcUrl, destFile);
        if (successful) {
            patentFile.setFile(destFile);
            patentFile.setMimeType("image/gif");

        } else if (info.stats.get(info.stats.size() - 1) == 2 && info.openDate != null) {
            cniprType = info.type + "1";
            srcUrl = "http://pic.cnipr.com/XmlData" + "/" + CNIPR_TYPE.get(cniprType) + "/"
                    + sdf.format(info.openDate) + "/" + info.patentNumber + "/"
                    + info.patentNumber.replaceAll("\\.\\S$", "") + ".gif";

            successful = DownloadUtils.downloadAndWriteFile(srcUrl, destFile);
            if (successful) {
                patentFile.setFile(destFile);
                patentFile.setMimeType("image/gif");
            }
        }

        return patentFile;
    }
}
