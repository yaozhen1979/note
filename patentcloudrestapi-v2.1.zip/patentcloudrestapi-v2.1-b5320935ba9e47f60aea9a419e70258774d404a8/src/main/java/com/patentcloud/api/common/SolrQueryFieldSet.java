package com.patentcloud.api.common;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;

public class SolrQueryFieldSet {

    public static final Set<String> BRIEF_1 = new HashSet<>();
    
    static {
        BRIEF_1.add("ptopid");
        BRIEF_1.add("pto");
        BRIEF_1.add("id");
        BRIEF_1.add("appNumberGroup");
        BRIEF_1.add("familyIdGroup");

        BRIEF_1.add("country");
        BRIEF_1.add("kindcode");
        BRIEF_1.add("stats");
        BRIEF_1.add("type");
        BRIEF_1.add("typeCode");

        BRIEF_1.add("appNumber");
        BRIEF_1.add("openNumber");
        BRIEF_1.add("decisionNumber");
        BRIEF_1.add("certificateNumber");
        BRIEF_1.add("patentNumber");

        BRIEF_1.add("appDate");
        BRIEF_1.add("openDate");
        BRIEF_1.add("decisionDate");
        BRIEF_1.add("doDate");
        BRIEF_1.add("docdbDoDate");

        BRIEF_1.add("title");
    }

    public static final Set<String> BRIEF_2 = new HashSet<>();

    static {
        BRIEF_2.addAll(BRIEF_1);

        BRIEF_2.add("appNumberAll");
        BRIEF_2.add("openNumberAll");
        BRIEF_2.add("decisionNumberAll");
        BRIEF_2.add("certificateNumberAll");
        BRIEF_2.add("patentNumberAll");

        BRIEF_2.add("assignees");
        BRIEF_2.add("inventors");
        BRIEF_2.add("currentAssigneesName");
        BRIEF_2.add("source");
    }

    public static final Set<String> FL_SearchCommand = new HashSet<>();

    static {
        FL_SearchCommand.add("pto");
        FL_SearchCommand.add("id");
        FL_SearchCommand.add("appNumberGroup");
        FL_SearchCommand.add("familyIdGroup");

        FL_SearchCommand.add("country");
        FL_SearchCommand.add("kindcode");
        FL_SearchCommand.add("stats");

        FL_SearchCommand.add("appNumber");
        FL_SearchCommand.add("openNumber");
        FL_SearchCommand.add("decisionNumber");

        FL_SearchCommand.add("appDate");
        FL_SearchCommand.add("openDate");
        FL_SearchCommand.add("decisionDate");
        FL_SearchCommand.add("doDate");

        FL_SearchCommand.add("title");
    }

    public static final Set<String> FL_PatentInfo2 = new HashSet<>();

    static {
        // FL_PatentInfo2.add("pto");
        // FL_PatentInfo2.add("id");
        //
        // FL_PatentInfo2.add("country");
        // FL_PatentInfo2.add("kindcode");
        // FL_PatentInfo2.add("stats");
        // FL_PatentInfo2.add("type");
        //
        // FL_PatentInfo2.add("patentNumber"); // for PatentDataPath
        // FL_PatentInfo2.add("openNumberAll"); // for PatentDataPath
        // FL_PatentInfo2.add("decisionNumberAll"); // for PatentDataPath
        // FL_PatentInfo2.add("certificateNumberAll"); // for PatentDataPath
        //
        // FL_PatentInfo2.add("doDate");
    }

    public static final Set<String> FL_PatentsUpdater = new HashSet<>();

    static {
        FL_PatentsUpdater.add("pto");
        FL_PatentsUpdater.add("id");
        FL_PatentsUpdater.add("appNumberGroup");
        FL_PatentsUpdater.add("familyId");
        FL_PatentsUpdater.add("familyIdGroup");

        FL_PatentsUpdater.add("country");
        FL_PatentsUpdater.add("kindcode");
        FL_PatentsUpdater.add("stats");

        FL_PatentsUpdater.add("appNumber");
        FL_PatentsUpdater.add("openNumber");
        FL_PatentsUpdater.add("decisionNumber");
        FL_PatentsUpdater.add("patentNumber");

        FL_PatentsUpdater.add("appDate");
        FL_PatentsUpdater.add("openDate");
        FL_PatentsUpdater.add("decisionDate");

        FL_PatentsUpdater.add("title");
        FL_PatentsUpdater.add("brief");
        FL_PatentsUpdater.add("inventors");
        FL_PatentsUpdater.add("assignees");
        FL_PatentsUpdater.add("currentAssigneesName");
        FL_PatentsUpdater.add("relPatents");
    }

    public static final Set<String> FL_addPatentsToTreeNode = new HashSet<>();

    static {
        FL_addPatentsToTreeNode.add("pto");
        FL_addPatentsToTreeNode.add("appNumberGroup");
        FL_addPatentsToTreeNode.add("familyIdGroup");
        FL_addPatentsToTreeNode.add("country");
        FL_addPatentsToTreeNode.add("patentNumber");
    }

    public static final Set<String> FL_PatentInfoGet = new HashSet<>();

    static {
        FL_PatentInfoGet.add("pto");
        FL_PatentInfoGet.add("id");

        FL_PatentInfoGet.add("kindcode");
        FL_PatentInfoGet.add("type");
        FL_PatentInfoGet.add("stats");

        FL_PatentInfoGet.add("appNumber");
        FL_PatentInfoGet.add("openNumber");
        FL_PatentInfoGet.add("decisionNumber");
        FL_PatentInfoGet.add("patentNumber");

        FL_PatentInfoGet.add("appDate");
        FL_PatentInfoGet.add("openDate");
        FL_PatentInfoGet.add("decisionDate");
        FL_PatentInfoGet.add("doDate");

        FL_PatentInfoGet.add("title");

        FL_PatentInfoGet.add("relPatents");
        FL_PatentInfoGet.add("filePageClaim");
        FL_PatentInfoGet.add("filePageDesc");
        FL_PatentInfoGet.add("filePageFig");
        FL_PatentInfoGet.add("filePageNumber");
    }

    public static final Set<String> FL_ExportProcessor_processPDFExport4Pid = new HashSet<>();

    static {
        FL_ExportProcessor_processPDFExport4Pid.add("pto");

        FL_ExportProcessor_processPDFExport4Pid.add("country");
        FL_ExportProcessor_processPDFExport4Pid.add("kindcode");
        FL_ExportProcessor_processPDFExport4Pid.add("stats");

        FL_ExportProcessor_processPDFExport4Pid.add("appNumber");
        FL_ExportProcessor_processPDFExport4Pid.add("openNumber");
        FL_ExportProcessor_processPDFExport4Pid.add("decisionNumber");

        FL_ExportProcessor_processPDFExport4Pid.add("openNumberAll");
        FL_ExportProcessor_processPDFExport4Pid.add("decisionNumberAll");
        FL_ExportProcessor_processPDFExport4Pid.add("certificateNumberAll");

        FL_ExportProcessor_processPDFExport4Pid.add("doDate");

        FL_ExportProcessor_processPDFExport4Pid.add("source");
    }

    public static final Set<String> FL_PoPatentChecker = new HashSet<>();

    static {
        FL_PoPatentChecker.add("ptopid");
        FL_PoPatentChecker.add("pto");
        FL_PoPatentChecker.add("id");
    }
    
    public static final Set<String> IMAGE_SEARCH = new HashSet<>();

    static {
        IMAGE_SEARCH.add("country");
        IMAGE_SEARCH.add("doDate");
        IMAGE_SEARCH.add("kindcode");
        IMAGE_SEARCH.add("ptopid");
        IMAGE_SEARCH.add("patentNumber");
        IMAGE_SEARCH.add("stats");
        IMAGE_SEARCH.add("title");
    }

    public static final Set<String> PATENT_LIST = new TreeSet<>();

    static {
        PATENT_LIST.add("agents");
        PATENT_LIST.add("appDate");
        PATENT_LIST.add("appNumber");
        PATENT_LIST.add("appYear");
        PATENT_LIST.add("appYearmon");
        PATENT_LIST.add("assignees");
        PATENT_LIST.add("brief");
        PATENT_LIST.add("certificateNumber");
        PATENT_LIST.add("certificateNumberAll");
        PATENT_LIST.add("country");
        PATENT_LIST.add("cpcs");
        PATENT_LIST.add("currentAssigneesName");
        PATENT_LIST.add("currentAssigneesUpdateDate");
        PATENT_LIST.add("decisionDate");
        PATENT_LIST.add("decisionNumber");
        PATENT_LIST.add("decisionNumberAll");
        PATENT_LIST.add("doDate");
        PATENT_LIST.add("doYear");
        PATENT_LIST.add("doYearmon");
        PATENT_LIST.add("docdbAssignees");
        PATENT_LIST.add("docdbDoDate");
        PATENT_LIST.add("docdbDoYear");
        PATENT_LIST.add("docdbDoYearmon");
        PATENT_LIST.add("docdbInventors");
        PATENT_LIST.add("docdbaAssignees");
        PATENT_LIST.add("docdbaInventors");
        PATENT_LIST.add("familyId");
        PATENT_LIST.add("familyIdGroup");
        PATENT_LIST.add("filePageNumber");
        PATENT_LIST.add("firstImagePageFlag");
        PATENT_LIST.add("fis");
        PATENT_LIST.add("id");
        PATENT_LIST.add("inventors");
        PATENT_LIST.add("ipcs");
        PATENT_LIST.add("kindcode");
        PATENT_LIST.add("locs");
        PATENT_LIST.add("mainCPC");
        PATENT_LIST.add("mainIPC");
        PATENT_LIST.add("mainUSPC");
        PATENT_LIST.add("openDate");
        PATENT_LIST.add("openNumber");
        PATENT_LIST.add("openNumberAll");
        PATENT_LIST.add("openYear");
        PATENT_LIST.add("openYearmon");
        PATENT_LIST.add("patentId");
        PATENT_LIST.add("patentNumber");
        PATENT_LIST.add("patentNumberAll");
        PATENT_LIST.add("pto");
        PATENT_LIST.add("ptopid");
        PATENT_LIST.add("source");
        PATENT_LIST.add("stats");
        PATENT_LIST.add("title");
        PATENT_LIST.add("type");
        PATENT_LIST.add("typeCode");
        PATENT_LIST.add("uspcs");

        PATENT_LIST.add("litigationTotalCount");
    }

    public static final Set<String> PATENT_INFO = new TreeSet<>();

    static {
        PATENT_INFO.add("_version_");
        PATENT_INFO.add("agents");
        PATENT_INFO.add("agentsFacetname");
        PATENT_INFO.add("appDate");
        PATENT_INFO.add("appNumber");
        PATENT_INFO.add("appNumberAll");
        PATENT_INFO.add("appNumberGroup");
        PATENT_INFO.add("appYear");
        PATENT_INFO.add("appYearmon");
        PATENT_INFO.add("assignees");
        PATENT_INFO.add("assigneesFacetname");
        PATENT_INFO.add("brief");
        PATENT_INFO.add("certificateDate");
        PATENT_INFO.add("certificateNumber");
        PATENT_INFO.add("certificateNumberAll");
        PATENT_INFO.add("citedPatents");
        PATENT_INFO.add("citedPatentsNumberAll");
        // Refer to http://redmine.scienbizip.com/redmine/issues/15850
        // PATENT_INFO.add("claim");
        PATENT_INFO.add("country");
        PATENT_INFO.add("cpcs");
        PATENT_INFO.add("cpcsNormal");
        PATENT_INFO.add("currentAssigneesFacetname");
        PATENT_INFO.add("currentAssigneesName");
        PATENT_INFO.add("currentAssigneesUpdateDate");
        PATENT_INFO.add("decisionDate");
        PATENT_INFO.add("decisionNumber");
        PATENT_INFO.add("decisionNumberAll");
        // Refer to http://redmine.scienbizip.com/redmine/issues/15850
        // PATENT_INFO.add("description");
        PATENT_INFO.add("doDate");
        PATENT_INFO.add("doYear");
        PATENT_INFO.add("doYearmon");
        PATENT_INFO.add("docdbAssignees");
        PATENT_INFO.add("docdbAssigneesFacetname");
        PATENT_INFO.add("docdbDoDate");
        PATENT_INFO.add("docdbDoYear");
        PATENT_INFO.add("docdbDoYearmon");
        PATENT_INFO.add("docdbInventors");
        PATENT_INFO.add("docdbInventorsFacetname");
        PATENT_INFO.add("docdbaAssignees");
        PATENT_INFO.add("docdbaAssigneesFacetname");
        PATENT_INFO.add("docdbaInventors");
        PATENT_INFO.add("docdbaInventorsFacetname");
        PATENT_INFO.add("examinerMasters");
        PATENT_INFO.add("examinerMastersFacetname");
        PATENT_INFO.add("familyId");
        PATENT_INFO.add("familyIdGroup");
        PATENT_INFO.add("filePageClaim");
        PATENT_INFO.add("filePageDesc");
        PATENT_INFO.add("filePageFig");
        PATENT_INFO.add("filePageNumber");
        PATENT_INFO.add("firstImagePageFlag");
        PATENT_INFO.add("fis");
        PATENT_INFO.add("id");
        PATENT_INFO.add("inventors");
        PATENT_INFO.add("inventorsFacetname");
        PATENT_INFO.add("ipcs");
        PATENT_INFO.add("ipcsNormal");
        PATENT_INFO.add("kindcode");
        PATENT_INFO.add("locs");
        PATENT_INFO.add("mainCPC");
        PATENT_INFO.add("mainIPC");
        PATENT_INFO.add("mainUSPC");
        PATENT_INFO.add("openDate");
        PATENT_INFO.add("openNumber");
        PATENT_INFO.add("openNumberAll");
        PATENT_INFO.add("openYear");
        PATENT_INFO.add("openYearmon");
        PATENT_INFO.add("otherReferences");
        PATENT_INFO.add("patentId");
        PATENT_INFO.add("patentNumber");
        PATENT_INFO.add("patentNumberAll");
        PATENT_INFO.add("priorityPatents");
        PATENT_INFO.add("priorityPatentsNumberAll");
        PATENT_INFO.add("pto");
        PATENT_INFO.add("ptopid");
        PATENT_INFO.add("solrIndexTime");
        PATENT_INFO.add("source");
        PATENT_INFO.add("stats");
        PATENT_INFO.add("title");
        PATENT_INFO.add("truncate");
        PATENT_INFO.add("type");
        PATENT_INFO.add("typeCode");
        PATENT_INFO.add("uspcs");

        PATENT_INFO.add("litigationContents");
    }

    /**
     * @see <a http://redmine.scienbizip.com/redmine/issues/15850">Redmine
     *      Feature #15850</a>
     */
    public static final Set<String> PATENT_INFO_MORE = new TreeSet<>();

    static {
        PATENT_INFO_MORE.add("claim");
        PATENT_INFO_MORE.add("description");
    }

    public static final Set<String> PATENT_FACET = new TreeSet<>();

    static {
        PATENT_FACET.add("agentsFacetname");
        PATENT_FACET.add("appYear");
        PATENT_FACET.add("assigneesFacetname");
        PATENT_FACET.add("country");
        PATENT_FACET.add("cpcsClass");
        PATENT_FACET.add("cpcsGroup");
        PATENT_FACET.add("cpcsNormal");
        PATENT_FACET.add("cpcsSubClass");
        PATENT_FACET.add("cpcsSubGroup");
        PATENT_FACET.add("currentAssigneesFacetname");
        PATENT_FACET.add("decisionYear");
        PATENT_FACET.add("docdbAssigneesFacetname");
        PATENT_FACET.add("examinerMastersFacetname");
        PATENT_FACET.add("fis");
        PATENT_FACET.add("fisClass");
        PATENT_FACET.add("fisGroup");
        PATENT_FACET.add("fisSubClass");
        PATENT_FACET.add("fisSubGroup");
        PATENT_FACET.add("inventorsFacetname");
        PATENT_FACET.add("ipcsClass");
        PATENT_FACET.add("ipcsGroup");
        PATENT_FACET.add("ipcsNormal");
        PATENT_FACET.add("ipcsSubClass");
        PATENT_FACET.add("ipcsSubGroup");
        PATENT_FACET.add("kindcode");
        PATENT_FACET.add("locs");
        PATENT_FACET.add("openYear");
        PATENT_FACET.add("typeCode");
        PATENT_FACET.add("uspcs");
    }

    public static final Set<String> PATENT_GROUPING = new TreeSet<>();

    static {
        PATENT_GROUPING.add("agents");
        PATENT_GROUPING.add("appDate");
        PATENT_GROUPING.add("appNumber");
        PATENT_GROUPING.add("appYear");
        PATENT_GROUPING.add("appYearmon");
        PATENT_GROUPING.add("assignees");
        PATENT_GROUPING.add("brief");
        PATENT_GROUPING.add("certificateNumber");
        PATENT_GROUPING.add("certificateNumberAll");
        PATENT_GROUPING.add("country");
        PATENT_GROUPING.add("cpcs");
        PATENT_GROUPING.add("currentAssigneesName");
        PATENT_GROUPING.add("currentAssigneesUpdateDate");
        PATENT_GROUPING.add("decisionDate");
        PATENT_GROUPING.add("decisionNumber");
        PATENT_GROUPING.add("decisionNumberAll");
        PATENT_GROUPING.add("doDate");
        PATENT_GROUPING.add("doYear");
        PATENT_GROUPING.add("doYearmon");
        PATENT_GROUPING.add("docdbAssignees");
        PATENT_GROUPING.add("docdbDoDate");
        PATENT_GROUPING.add("docdbDoYear");
        PATENT_GROUPING.add("docdbDoYearmon");
        PATENT_GROUPING.add("docdbInventors");
        PATENT_GROUPING.add("docdbaAssignees");
        PATENT_GROUPING.add("docdbaInventors");
        PATENT_GROUPING.add("familyId");
        PATENT_GROUPING.add("familyIdGroup");
        PATENT_GROUPING.add("filePageNumber");
        PATENT_GROUPING.add("firstImagePageFlag");
        PATENT_GROUPING.add("fis");
        PATENT_GROUPING.add("id");
        PATENT_GROUPING.add("inventors");
        PATENT_GROUPING.add("ipcs");
        PATENT_GROUPING.add("kindcode");
        PATENT_GROUPING.add("locs");
        PATENT_GROUPING.add("mainCPC");
        PATENT_GROUPING.add("mainIPC");
        PATENT_GROUPING.add("mainUSPC");
        PATENT_GROUPING.add("openDate");
        PATENT_GROUPING.add("openNumber");
        PATENT_GROUPING.add("openNumberAll");
        PATENT_GROUPING.add("openYear");
        PATENT_GROUPING.add("openYearmon");
        PATENT_GROUPING.add("patentId");
        PATENT_GROUPING.add("patentNumber");
        PATENT_GROUPING.add("patentNumberAll");
        PATENT_GROUPING.add("pto");
        PATENT_GROUPING.add("ptopid");
        PATENT_GROUPING.add("source");
        PATENT_GROUPING.add("stats");
        PATENT_GROUPING.add("title");
        PATENT_GROUPING.add("type");
        PATENT_GROUPING.add("typeCode");
        PATENT_GROUPING.add("uspcs");

        PATENT_GROUPING.add("litigationTotalCount");
    }

    public static final Set<String> DEFINITION_1 = new TreeSet<>();

    /**
     * @see itec.kangaroo.utils.SolrUtils
     */
    static {
        DEFINITION_1.add("ptopid");
        DEFINITION_1.add("id");
        DEFINITION_1.add("pto");
        DEFINITION_1.add("country");
        DEFINITION_1.add("appDate");
        DEFINITION_1.add("appYear");
        DEFINITION_1.add("appYearmon");
        DEFINITION_1.add("openDate");
        DEFINITION_1.add("openYear");
        DEFINITION_1.add("openYearmon");
        DEFINITION_1.add("appNumber");
        DEFINITION_1.add("openNumber");
        DEFINITION_1.add("openNumberAll");
        DEFINITION_1.add("patentNumber");
        DEFINITION_1.add("patentNumberAll");
        DEFINITION_1.add("mainIPC");
        DEFINITION_1.add("mainCPC");
        DEFINITION_1.add("mainUSPC");
        DEFINITION_1.add("ipcs");
        DEFINITION_1.add("locs");
        DEFINITION_1.add("cpcs");
        DEFINITION_1.add("uspcs");
        DEFINITION_1.add("assignees");
        DEFINITION_1.add("docdbAssignees");
        DEFINITION_1.add("docdbaAssignees");
        DEFINITION_1.add("currentAssigneesName");
        DEFINITION_1.add("currentAssigneesUpdateDate");
        DEFINITION_1.add("inventors");
        DEFINITION_1.add("docdbInventors");
        DEFINITION_1.add("docdbaInventors");
        DEFINITION_1.add("filePageNumber");
        DEFINITION_1.add("firstImagePageFlag");
        DEFINITION_1.add("kindcode");
        DEFINITION_1.add("type");
        DEFINITION_1.add("familyId");
        DEFINITION_1.add("familyIdGroup");
        DEFINITION_1.add("title");
        DEFINITION_1.add("doDate");
        DEFINITION_1.add("doYear");
        DEFINITION_1.add("doYearmon");
        DEFINITION_1.add("docdbDoDate");
        DEFINITION_1.add("docdbDoYear");
        DEFINITION_1.add("docdbDoYearmon");
        DEFINITION_1.add("decisionDate");
        DEFINITION_1.add("decisionNumber");
        DEFINITION_1.add("decisionNumberAll");
        DEFINITION_1.add("certificateNumber");
        DEFINITION_1.add("certificateNumberAll");
        DEFINITION_1.add("typeCode");
        DEFINITION_1.add("agents");
        DEFINITION_1.add("brief");
        DEFINITION_1.add("stats");
        DEFINITION_1.add("patentId");
        DEFINITION_1.add("source");
    }

    public static final Set<String> DEFINITION_2 = new TreeSet<>();

    /**
     * @see itec.kangaroo.utils.SolrUtils
     */
    static {
        DEFINITION_2.addAll(DEFINITION_1);

        DEFINITION_2.add("ipcsNormal");
        DEFINITION_2.add("cpcsNormal");
        DEFINITION_2.add("certificateDate");
        DEFINITION_2.add("appNumberGroup");
        DEFINITION_2.add("appNumberAll");
        DEFINITION_2.add("assigneesFacetname");
        DEFINITION_2.add("docdbAssigneesFacetname");
        DEFINITION_2.add("docdbaAssigneesFacetname");
        DEFINITION_2.add("inventorsFacetname");
        DEFINITION_2.add("docdbInventorsFacetname");
        DEFINITION_2.add("docdbaInventorsFacetname");
        DEFINITION_2.add("agentsFacetname");
        DEFINITION_2.add("priorityPatents");
        DEFINITION_2.add("priorityPatentsNumberAll");
        DEFINITION_2.add("examinerMasters");
        DEFINITION_2.add("examinerMastersFacetname");
        DEFINITION_2.add("claim");
        DEFINITION_2.add("description");
        DEFINITION_2.add("truncate");
        DEFINITION_2.add("citedPatents");
        DEFINITION_2.add("citedPatentsNumberAll");
        DEFINITION_2.add("otherReferences");
        DEFINITION_2.add("solrIndexTime");
        DEFINITION_2.add("_version_");
        DEFINITION_2.add("filePageFig");
        DEFINITION_2.add("filePageDesc");
        DEFINITION_2.add("filePageClaim");
        DEFINITION_2.add("currentAssigneesFacetname");
    }

    /**
     * A mapping table of the parameters in the frontend Facet UI and Solr
     * fields
     * 
     * @see <a http://redmine.scienbizip.com/redmine/issues/12935">Redmine
     *      Feature #12935</a>
     */
    public static final Map<String, String> FACET_FIELD_PARAM_MAPPING = new HashMap<>();

    static {
        FACET_FIELD_PARAM_MAPPING.put("assignees", "assigneesFacetname");
        FACET_FIELD_PARAM_MAPPING.put("docdbAssignees", "docdbAssigneesFacetname");
        FACET_FIELD_PARAM_MAPPING.put("currentAssignees", "currentAssigneesFacetname");
        FACET_FIELD_PARAM_MAPPING.put("inventors", "inventorsFacetname");
        FACET_FIELD_PARAM_MAPPING.put("agents", "agentsFacetname");
        FACET_FIELD_PARAM_MAPPING.put("examinerMasters", "examinerMastersFacetname");
        FACET_FIELD_PARAM_MAPPING.put("ipcs", "ipcsNormal");
        FACET_FIELD_PARAM_MAPPING.put("cpcs", "cpcsNormal");
        FACET_FIELD_PARAM_MAPPING.put("appDate", "appYear");
        FACET_FIELD_PARAM_MAPPING.put("openDate", "openYear");
        FACET_FIELD_PARAM_MAPPING.put("decisionDate", "decisionYear");
    }

    /**
     * Convert a UI-customized facet field to a solr-defined facet field
     * 
     * 
     * @param facetField
     *            UI-customized facet field
     * @return a solr-defined facet field
     * 
     * @see <a http://redmine.scienbizip.com/redmine/issues/12935">Redmine
     *      Feature #12935</a>
     */
    public static String getSolrFacetField(String facetField) {
        if (facetField == null || facetField.isEmpty()) {
            return "";
        }

        if (SolrQueryFieldSet.PATENT_FACET.contains(facetField)) {
            return facetField;
        }

        String solrFacetField = FACET_FIELD_PARAM_MAPPING.get(facetField);
        if (solrFacetField != null) {
            return solrFacetField;

        } else {
            return "";
        }
    }

    private static final Map<String, Set<String>> FIELD_SET_MAPPING = new HashMap<>();

    static {
        FIELD_SET_MAPPING.put("BRIEF_1", BRIEF_1);
        FIELD_SET_MAPPING.put("BRIEF_2", BRIEF_2);
        FIELD_SET_MAPPING.put("FL_SearchCommand", FL_SearchCommand);
        FIELD_SET_MAPPING.put("FL_PatentInfo2", FL_PatentInfo2);
        FIELD_SET_MAPPING.put("FL_PatentsUpdater", FL_PatentsUpdater);
        FIELD_SET_MAPPING.put("FL_addPatentsToTreeNode", FL_addPatentsToTreeNode);
        FIELD_SET_MAPPING.put("FL_PatentInfoGet", FL_PatentInfoGet);
        FIELD_SET_MAPPING.put("IMAGE_SEARCH", IMAGE_SEARCH);
        FIELD_SET_MAPPING.put("PATENT_LIST", PATENT_LIST);
        FIELD_SET_MAPPING.put("PATENT_INFO", PATENT_INFO);
        FIELD_SET_MAPPING.put("PATENT_INFO_MORE", PATENT_INFO_MORE);
        FIELD_SET_MAPPING.put("PATENT_FACET", PATENT_FACET);
        FIELD_SET_MAPPING.put("PATENT_GROUPING", PATENT_GROUPING);
        FIELD_SET_MAPPING.put("DEFINITION_1", DEFINITION_1);
        FIELD_SET_MAPPING.put("DEFINITION_2", DEFINITION_2);
    }

    public static Set<String> getFieldSet(String solrFieldSetName) {
        if (StringUtils.isBlank(solrFieldSetName)) {
            throw new IllegalArgumentException("solrFieldSetName is blank");
        }

        Set<String> fieldSet = FIELD_SET_MAPPING.get(solrFieldSetName);

        if (fieldSet == null) {
            throw new IllegalArgumentException(String.format("Unsupported solrFieldSetName: %s", solrFieldSetName));
        }

        return fieldSet;
    }

    public static String getFieldSetName(Set<String> solrFieldSet) {
        if (solrFieldSet == null) {
            throw new IllegalArgumentException("solrFieldSet is null");
        }

        String fieldSetName = null;
        Set<Entry<String, Set<String>>> entrySet = FIELD_SET_MAPPING.entrySet();

        for (Entry<String, Set<String>> entry : entrySet) {
            if (entry.getValue() == solrFieldSet) {
                fieldSetName = entry.getKey();
                break;
            }
        }

        if (fieldSetName == null) {
            throw new IllegalArgumentException(String.format("Unsupported solrFieldSet: %s", solrFieldSet));
        }

        return fieldSetName;
    }

    public static String[] toStringArray(Set<String> solrFieldSet) {
        String[] solrFieldArray = solrFieldSet.toArray(new String[solrFieldSet.size()]);

        return solrFieldArray;
    }

    public static String toStringBetween(Set<String> solrFieldSet, char separator) {
        String solrFields = StringUtils.join(solrFieldSet, separator);

        return solrFields;
    }
}
