package com.patentcloud.api.util.nlp.parameter;

import java.util.Map;

public interface ParameterMap<K, V> {

    Map<K, V> unmodifiableParamMap();

}
