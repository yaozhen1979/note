package com.patentcloud.api.util.http;

import java.io.IOException;
import java.io.StringReader;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.patentcloud.api.util.JsonUtils;

/**
 * A container that wraps a result returned by Solr service server
 * 
 * @author Allan Huang
 */
public class SolrResult {

    private static final Logger log = LoggerFactory.getLogger(SolrResult.class);

    private int httpStatus;

    private String entity;

    private JsonElement entityJson;

    public SolrResult(int httpStatus, String entity) {
        this.httpStatus = httpStatus;
        this.entity = entity;
    }

    public int getHttpStatus() {
        return this.httpStatus;
    }

    public String getEntity() {
        return entity;
    }

    /**
     * A convenient method that delegates to the
     * {@link JsonUtil#findElementByPath(String, String)} method.
     * 
     * @param jsonPath
     *            a JSONPath for query
     * @return a matching JsonElement or returns null if not found
     */
    public JsonElement findElementByPath(String jsonPath) {
        JsonElement element = null;

        try {
            element = JsonUtils.findElementByPath(this.entity, jsonPath);

        } catch (IOException e) {
            log.error("Occur an IO exception while finding an element. jsonPath: {}", jsonPath, e);
        }

        return element;
    }

    /**
     * A convenient method that delegates to the
     * {@link JsonUtil#findElementsByPath(String, String)} method.
     * 
     * @param jsonPath
     *            a JSONPath for query
     * @return a map contains path and matching element pairs
     */
    public Map<String, JsonElement> findElementsByPath(String... jsonPaths) {
        Map<String, JsonElement> elementMap = null;

        try {
            elementMap = JsonUtils.findElementsByPath(this.entity, jsonPaths);

        } catch (IOException e) {
            log.error("Occur an IO exception while finding the elements. jsonPaths: {}", jsonPaths, e);
        }

        return elementMap;
    }

    public JsonObject getEntityAsJsonObject() {
        if (StringUtils.isBlank(this.entity)) {
            return null;
        }

        if (this.entityJson == null) {
            // configure this parser to be be liberal in what it accepts.
            StringReader stringReader = new StringReader(this.entity);
            JsonReader jsonReader = new JsonReader(stringReader);
            jsonReader.setLenient(true);

            JsonParser parser = new JsonParser();
            this.entityJson = parser.parse(jsonReader);
            boolean objectType = this.entityJson.isJsonObject();

            if (!objectType) {
                throw new IllegalStateException("entity is not a json object");
            }
        }

        return this.entityJson.getAsJsonObject();
    }

    public JsonArray getEntityAsJsonArray() {
        if (StringUtils.isBlank(this.entity)) {
            return null;
        }

        if (this.entityJson == null) {
            // configure this parser to be be liberal in what it accepts.
            StringReader stringReader = new StringReader(this.entity);
            JsonReader jsonReader = new JsonReader(stringReader);
            jsonReader.setLenient(true);

            JsonParser parser = new JsonParser();
            this.entityJson = parser.parse(jsonReader);
            boolean arrayType = this.entityJson.isJsonArray();

            if (!arrayType) {
                throw new IllegalStateException("entity is not a json array");
            }
        }

        return this.entityJson.getAsJsonArray();
    }
}
