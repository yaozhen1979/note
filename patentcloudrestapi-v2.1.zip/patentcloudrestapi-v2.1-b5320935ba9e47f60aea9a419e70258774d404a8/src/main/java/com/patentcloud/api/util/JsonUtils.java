package com.patentcloud.api.util;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.internal.bind.TypeAdapters;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;

public class JsonUtils {

    private static final Logger log = LoggerFactory.getLogger(JsonUtils.class);

    /**
     * The caller should be prevented from constructing objects of this class,
     * by declaring this private constructor.
     */
    private JsonUtils() {
        // this prevents even the native class from
        // calling this ctor as well :
        throw new AssertionError();
    }

    /**
     * Outputs a json element that fits in a page for pretty printing.
     * 
     * @param jsonElement
     *            a specified json element
     * @return a pretty printing string
     */
    public static final String prettyPrint(JsonElement jsonElement) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String prettyJson = gson.toJson(jsonElement);

        return prettyJson;
    }

    /**
     * Removes a specific property of all the elements in a json array.
     * 
     * @param jsonArray
     *            a json array
     * @param propertyName
     *            a removed property name be specified
     */
    public static final void removeProperty(JsonArray jsonArray, String propertyName) {
        if (jsonArray == null || jsonArray.size() == 0) {
            return;
        }

        for (JsonElement element : jsonArray) {
            if (element.isJsonObject()) {
                JsonObject jsonObject = element.getAsJsonObject();

                if (jsonObject.has(propertyName)) {
                    jsonObject.remove(propertyName);
                }
            }
        }
    }

    /**
     * Gets a list of a name of all properties belong to a specified json object
     * 
     * @param jsonObject
     *            a specified json object
     * @return a list of a name of all properties
     */
    public static final List<String> getPropertyNames(JsonObject jsonObject) {
        if (jsonObject == null || jsonObject.isJsonNull()) {
            return new ArrayList<>();
        }

        List<String> propretyNames = new ArrayList<>();

        Set<Entry<String, JsonElement>> propertyEntries = jsonObject.entrySet();
        for (Entry<String, JsonElement> propertyEntry : propertyEntries) {
            String propertyName = propertyEntry.getKey();
            propretyNames.add(propertyName);
        }

        return propretyNames;
    }

    /**
     * Converts a collection to a json array by according to the specified class
     * of a primitive type
     * 
     * @param collection
     *            a specified collection
     * @param clazz
     *            the specified class of a primitive type
     * @return a new json array with the primitive data
     */
    public static final <T> JsonArray toJsonPrimitiveArray(Collection<T> collection, Class<T> clazz) {
        if (collection == null) {
            return null;
        }

        JsonArray results = new JsonArray();

        if (collection.size() == 0) {
            return results;
        }

        for (Object object : collection) {
            JsonPrimitive jsonPrimitive = toJsonPrimitive(object, clazz);

            results.add(jsonPrimitive);
        }

        return results;
    }

    /**
     * Converts a json array to a list by according to the specified class of a
     * primitive type
     * 
     * @param jsonArray
     *            a specified json array
     * @param clazz
     *            the specified class of a primitive type
     * @return a new list with the primitive data
     */
    public static final <T> List<T> toPrimitiveList(JsonArray jsonArray, Class<T> clazz) {
        if (jsonArray == null) {
            return null;
        }

        List<T> results = new ArrayList<>();

        if (jsonArray.size() == 0) {
            return results;
        }

        for (JsonElement element : jsonArray) {
            String primitiveJson = element.getAsString();
            T primitiveObject = toPrimitiveObject(primitiveJson, clazz);

            results.add(primitiveObject);
        }

        return results;
    }

    /**
     * Converts a json array to a set by according to the specified class of a
     * primitive type
     * 
     * @param jsonArray
     *            a specified json array
     * @param clazz
     *            the specified class of a primitive type
     * @return a new set with the primitive data
     */
    public static final <T> Set<T> toPrimitiveSet(JsonArray jsonArray, Class<T> clazz) {
        if (jsonArray == null) {
            return null;
        }

        Set<T> results = new HashSet<>();

        if (jsonArray.size() == 0) {
            return results;
        }

        for (JsonElement element : jsonArray) {
            String primitiveJson = element.getAsString();
            T primitiveObject = toPrimitiveObject(primitiveJson, clazz);

            results.add(primitiveObject);
        }

        return results;
    }

    /**
     * Converts a json array to a sorted set by according to the specified class
     * of a primitive type
     * 
     * @param jsonArray
     *            a specified json array
     * @param clazz
     *            the specified class of a primitive type
     * @return a new sorted set with the primitive data
     */
    public static final <T> SortedSet<T> toPrimitiveSortedSet(JsonArray jsonArray, Class<T> clazz) {
        if (jsonArray == null) {
            return null;
        }

        SortedSet<T> results = new TreeSet<>();

        if (jsonArray.size() == 0) {
            return results;
        }

        for (JsonElement element : jsonArray) {
            String primitiveJson = element.getAsString();
            T primitiveObject = toPrimitiveObject(primitiveJson, clazz);

            results.add(primitiveObject);
        }

        return results;
    }

    /**
     * Converts a json array to a map by according to the specified class of a
     * primitive type
     * 
     * @param jsonArray
     *            a specified json array
     * @param mapKey
     *            a key name in a map, e.g. Id
     * @param clazz
     *            the specified class of a primitive type
     * @return a new map with the primitive data
     */
    public static final <T> Map<T, JsonObject> toPrimitiveMap(JsonArray jsonArray, String mapKey, Class<T> clazz) {
        if (jsonArray == null) {
            return null;
        }

        Map<T, JsonObject> results = new HashMap<>();

        if (jsonArray.size() == 0) {
            return results;
        }

        for (JsonElement element : jsonArray) {
            JsonObject jsonObject = element.getAsJsonObject();
            JsonElement jsonKey = jsonObject.get(mapKey);

            String primitiveJson = jsonKey.getAsString();
            T primitiveObject = toPrimitiveObject(primitiveJson, clazz);

            results.put(primitiveObject, jsonObject);
        }

        return results;
    }

    private static final <T> JsonPrimitive toJsonPrimitive(Object primitiveObject, Class<T> clazz) {
        JsonPrimitive result = null;

        if (clazz.isAssignableFrom(Integer.class)) {
            result = new JsonPrimitive((Integer) primitiveObject);

        } else if (clazz.isAssignableFrom(Long.class)) {
            result = new JsonPrimitive((Long) primitiveObject);

        } else if (clazz.isAssignableFrom(Short.class)) {
            result = new JsonPrimitive((Short) primitiveObject);

        } else if (clazz.isAssignableFrom(Float.class)) {
            result = new JsonPrimitive((Float) primitiveObject);

        } else if (clazz.isAssignableFrom(Double.class)) {
            result = new JsonPrimitive((Double) primitiveObject);

        } else if (clazz.isAssignableFrom(Byte.class)) {
            result = new JsonPrimitive((Byte) primitiveObject);

        } else if (clazz.isAssignableFrom(Boolean.class)) {
            result = new JsonPrimitive((Boolean) primitiveObject);

        } else if (clazz.isAssignableFrom(Character.class)) {
            result = new JsonPrimitive((Character) primitiveObject);

        } else {
            result = new JsonPrimitive((String) primitiveObject);
        }

        return result;
    }

    private static final <T> T toPrimitiveObject(String primitiveJson, Class<T> clazz) {
        Object result = null;

        if (clazz.isAssignableFrom(Integer.class)) {
            result = Integer.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Long.class)) {
            result = Long.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Short.class)) {
            result = Short.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Float.class)) {
            result = Float.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Double.class)) {
            result = Double.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Byte.class)) {
            result = Byte.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Boolean.class)) {
            result = Boolean.valueOf(primitiveJson);

        } else if (clazz.isAssignableFrom(Character.class)) {
            result = Character.valueOf(primitiveJson.charAt(0));

        } else {
            result = primitiveJson;
        }

        return clazz.cast(result);
    }

    /**
     * A container holds the node status of a json tree for keeping track of
     * depth-first traversal.
     */
    private static class JsonNode {

        private static JsonNode createRootNode() {
            return new JsonNode("$", JsonToken.BEGIN_OBJECT, -1);
        }

        private static JsonNode createArrayElementNode() {
            return new JsonNode("[]", null, -1);
        }

        private JsonNode(String name) {
            super();
            this.name = name;
        }

        private JsonNode(String name, JsonToken valueToken, int arrayIndex) {
            super();
            this.name = name;
            this.valueToken = valueToken;
            this.arrayIndex = arrayIndex;
        }

        private String name;

        private JsonToken valueToken;

        private int arrayIndex = -1;

        private JsonNode previous;

        private boolean isArrayElementNode() {
            return ("[]".equals(this.name));
        }

        private String toJsonPath() {
            String jsonPath = null;

            if (this.isArrayElementNode()) {
                jsonPath = String.format("[%d]", this.previous.arrayIndex);

            } else {
                jsonPath = this.name;
            }

            return jsonPath;
        }

        public String toString() {
            return String.format("{%s,%s,%d}", this.name, this.valueToken, this.arrayIndex);
        }

        private static String insertDotInArray(String jsonPath) {
            // insert a dot in the front of an array notation
            int i = -1;
            do {
                i = jsonPath.indexOf('[', i);
                if (i >= 0) {
                    StringBuilder jsonPathSb = new StringBuilder(jsonPath);
                    jsonPath = jsonPathSb.insert(i, '.').toString();
                    i = i + 2;
                }
            } while (i >= 0);

            return jsonPath;
        }

        private static String deleteDotOfArray(String jsonPath) {
            // delete a dot in the front of an array notation
            int i = -1;
            do {
                i = jsonPath.indexOf('[', i);
                if (i >= 0) {
                    StringBuilder jsonPathSb = new StringBuilder(jsonPath);
                    jsonPath = jsonPathSb.deleteCharAt(i - 1).toString();
                }
            } while (i >= 0);

            return jsonPath;
        }
    }

    /**
     * Uses GSON streaming parser to find the first matching element by
     * JSONPath-like query syntax for greatly improving parsing performance
     * about 9 times.<br>
     * 
     * <ul>
     * <li>$: returns the root node. The root node must be a json object.</li>
     * <li>$[0]: returns the root node. The root node must be a json array.</li>
     * <li>$.responseHeader: returns a "responseHeader" object of the root node.
     * </li>
     * <li>$.response.numFound: returns a "numFound" field of the "response"
     * object.</li>
     * <li>$.response.docs[0].agents: returns a "agents" array of the first
     * element of "docs" array.</li>
     * <li>$.response.docs[0].firstImagePageFlag: returns a "firstImagePageFlag"
     * of the first element of "docs" array.</li>
     * <li>$.response.docs[*].ptopid: returns a json array that keeps all of the
     * json primitive value of the matched ptopid.</li>
     * </ul>
     * 
     * 
     * @param json
     *            a JSON string
     * @param jsonPath
     *            a JSONPath for query
     * @return a matching element or returns null if not found
     * @throws IOException
     *             throws a IOException when failed to parsing a JSON string.
     * 
     * @see <a href="http://goessner.net/articles/JsonPath/">JSONPath - XPath
     *      for JSON</a>
     * @see <a href="https://sites.google.com/site/gson/streaming">GSON
     *      Streaming</a>
     */
    public static JsonElement findElementByPath(String json, String jsonPath) throws IOException {
        Map<String, JsonElement> matchingMap = findElementsByPath(json, jsonPath);

        JsonElement matching = matchingMap.get(jsonPath);

        return matching;
    }

    /**
     * Uses GSON streaming parser to find the first matching element by
     * JSONPath-like query syntax for greatly improving parsing performance
     * about 9 times.<br>
     * 
     * <ul>
     * <li>$: returns the root node. The root node must be a json object.</li>
     * <li>$[0]: returns the root node. The root node must be a json array.</li>
     * <li>$.responseHeader: returns a "responseHeader" object of the root node.
     * </li>
     * <li>$.response.numFound: returns a "numFound" field of the "response"
     * object.</li>
     * <li>$.response.docs[0].agents: returns a "agents" array of the first
     * element of "docs" array.</li>
     * <li>$.response.docs[0].firstImagePageFlag: returns a "firstImagePageFlag"
     * of the first element of "docs" array.</li>
     * <li>$.response.docs[*].ptopid: returns a json array that keeps all of the
     * json primitive value of the matched ptopid.</li>
     * </ul>
     * 
     * @param json
     *            a JSON string
     * @param jsonPaths
     *            a JSONPath array for query
     * @return a map contains path and matching element pairs
     * @throws IOException
     *             throws a IOException when failed to parsing a JSON string.
     * 
     * @see <a href="http://goessner.net/articles/JsonPath/">JSONPath - XPath
     *      for JSON</a>
     * @see <a href="https://sites.google.com/site/gson/streaming">GSON
     *      Streaming</a>
     */
    public static Map<String, JsonElement> findElementsByPath(String json, String... jsonPaths) throws IOException {
        if (jsonPaths == null || jsonPaths.length == 0) {
            return Collections.emptyMap();
        }

        // convert array notation from a1[n] to a1.[n] for path comparison, e.g.
        // $.response.docs[0].ptopid to $.response.docs.[0].ptopid or $[1][2] to
        // $.[1].[2]
        Set<String> jsonPathSet = new HashSet<>();
        for (String jsonPath : jsonPaths) {
            jsonPath = jsonPath.trim();
            // insert a dot in the front of an array notation
            jsonPath = JsonNode.insertDotInArray(jsonPath);
            jsonPathSet.add(jsonPath);
        }

        // collect json path with "[*]" wildcard and save them as a set
        Set<String> jsonWildcardPathSet = new HashSet<>();
        for (String jsonPath : jsonPathSet) {
            if (jsonPath.indexOf("[*]") >= 0) {
                jsonWildcardPathSet.add(jsonPath);
            }
        }

        JsonReader reader = new JsonReader(new StringReader(json));
        reader.setLenient(true);

        LinkedList<JsonNode> nodeStack = new LinkedList<>();
        Map<String, JsonElement> matchingMap = new HashMap<>();

        try {
            while (true) {
                if (jsonPathSet.isEmpty()) {
                    // all json paths have been found
                    break;
                }

                JsonToken currentToken = reader.peek();

                if (currentToken == JsonToken.END_DOCUMENT) {
                    // finish parsing and jump out while-loop
                    break;
                }

                if (nodeStack.isEmpty()) {
                    // add a root node
                    nodeStack.addLast(JsonNode.createRootNode());
                }

                // obtain the current path because the getPath method of GSON
                // reader always returns a unexpected path, e.g. $.response.null
                StringBuilder currentPathSb = new StringBuilder();
                for (int i = 0; i < nodeStack.size(); i++) {
                    if (i >= 1) {
                        currentPathSb.append('.');
                    }
                    JsonNode node = nodeStack.get(i);
                    currentPathSb.append(node.toJsonPath());
                }

                log.trace("{}, path: {}, token: {}", reader, currentPathSb, currentToken);

                String matchedJsonWildcardPath = null;
                // first, try to find any totally matched path
                boolean matched = jsonPathSet.contains(currentPathSb.toString());

                // if can't find any matched path, then try to compare path
                // by according to path with "[*]" wildcard if existed
                if (!matched && !jsonWildcardPathSet.isEmpty()) {
                    for (String jsonPathWithAnywildcard : jsonWildcardPathSet) {
                        String[] jsonPathArray = StringUtils.split(jsonPathWithAnywildcard, ".");

                        if (jsonPathArray.length != nodeStack.size()) {
                            // continue to compare since it's mismatched
                            continue;
                        }

                        for (int i = 0; i < nodeStack.size(); i++) {
                            JsonNode node = nodeStack.get(i);
                            String nodeJsonPath = node.toJsonPath();

                            if ("[*]".equals(jsonPathArray[i]) && node.isArrayElementNode()) {
                                // [*] represents any position of an array
                                matched = true;
                                continue;
                            }

                            if (!nodeJsonPath.equals(jsonPathArray[i])) {
                                matched = false;
                                break;
                            }
                        }

                        if (matched) {
                            matchedJsonWildcardPath = jsonPathWithAnywildcard;
                            break;
                        }
                    }
                }

                if (matched) {
                    // visit the whole nested element and convert it to a
                    // returnable json element
                    JsonElement matchingJson = TypeAdapters.JSON_ELEMENT.read(reader);

                    if (matchedJsonWildcardPath == null) {
                        String jsonPath = currentPathSb.toString();
                        // delete a dot in the front of an array notation to
                        // restore the original json path
                        jsonPath = JsonNode.deleteDotOfArray(jsonPath);
                        matchingMap.put(jsonPath, matchingJson);

                    } else {
                        // a json array saves the many of matched json element
                        String jsonPath = matchedJsonWildcardPath;
                        // delete a dot in the front of an array notation to
                        // restore the original json path
                        jsonPath = JsonNode.deleteDotOfArray(jsonPath);
                        JsonArray matchingArray = (JsonArray) matchingMap.get(jsonPath);

                        if (matchingArray == null) {
                            matchingArray = new JsonArray();
                            matchingMap.put(jsonPath, matchingArray);
                        }
                        matchingArray.add(matchingJson);
                    }

                    if (log.isDebugEnabled()) {
                        String value = matchingJson.toString();
                        if (value.length() > 50) {
                            value = StringUtils.left(value, 50) + "...(omitted)";
                        }
                        log.debug("Find a matching node. path: {}, value: {}", currentPathSb, value);
                    }

                    JsonNode currentNode = nodeStack.getLast();
                    if (!currentNode.isArrayElementNode()) {
                        nodeStack.removeLast();
                    } else {
                        ++currentNode.previous.arrayIndex;
                    }

                    if (matchedJsonWildcardPath == null) {
                        // remove the matching json path, avoid that it are
                        // searched again
                        jsonPathSet.remove(currentPathSb.toString());
                    }

                } else if (JsonToken.NAME == currentToken) {
                    // add the current node and link it to the previous
                    // node
                    JsonNode currentNode = new JsonNode(reader.nextName());
                    currentNode.previous = nodeStack.getLast();
                    nodeStack.addLast(currentNode);

                } else {
                    // for example, $.response and $.response.numFound are both
                    // on the same path
                    // otherwise, $.responseHeader and $.response.numFound are
                    // not on the same path
                    boolean samePath = false;
                    for (String jsonPath : jsonPathSet) {
                        String[] jsonPathArray = StringUtils.split(jsonPath, ".");

                        samePath = true;
                        for (int i = 0; i < nodeStack.size(); i++) {
                            JsonNode node = nodeStack.get(i);
                            String nodeJsonPath = node.toJsonPath();

                            if ("[*]".equals(jsonPathArray[i]) && node.isArrayElementNode()) {
                                // [*] represents any position of an array
                                samePath = true;
                                continue;
                            }

                            if (!nodeJsonPath.equals(jsonPathArray[i])) {
                                samePath = false;
                                break;
                            }
                        }

                        if (samePath) {
                            break;
                        }
                    }

                    log.trace("Current path: {}, same path? {}", currentPathSb, samePath);

                    if (!samePath) {
                        switch (currentToken) {
                        case BEGIN_ARRAY:
                        case BEGIN_OBJECT:
                        case STRING:
                        case NUMBER:
                        case BOOLEAN:
                        case NULL: {
                            // skip all nested elements
                            reader.skipValue();

                            // don't visit all nested elements because it's a
                            // different path
                            JsonNode currentNode = nodeStack.getLast();
                            if (!currentNode.isArrayElementNode()) {
                                // remove the current node because don't trace
                                // it again
                                nodeStack.removeLast();
                            } else {
                                // the previous node of the current node is
                                // responsible for keeping track of the last
                                // index of an array, e.g.
                                // [{$,BEGIN_ARRAY,1},{[],BEGIN_ARRAY,2},
                                // {[],null,-1}]
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        case END_ARRAY: {
                            // end a visit of an array and avoid that enters a
                            // endless loop
                            reader.endArray();

                            JsonNode currentNode = nodeStack.getLast();
                            if (!currentNode.isArrayElementNode()) {
                                // remove the current node because don't trace
                                // it again
                                nodeStack.removeLast();
                            } else {
                                // the previous node of the current node is
                                // responsible for keeping track of the last
                                // index of an array, e.g.
                                // [{$,BEGIN_ARRAY,1},{[],BEGIN_ARRAY,2},
                                // {[],null,-1}]
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        case END_OBJECT: {
                            // end a visit of an array and avoid that enters a
                            // endless loop
                            reader.endObject();

                            JsonNode currentNode = nodeStack.getLast();
                            if (!currentNode.isArrayElementNode()) {
                                // remove the current node because don't trace
                                // it again
                                nodeStack.removeLast();
                            } else {
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        default:
                        }

                    } else {
                        // on the same path
                        switch (currentToken) {
                        case BEGIN_ARRAY: {
                            // visit a nested array
                            reader.beginArray();

                            JsonNode currentNode = nodeStack.getLast();
                            currentNode.valueToken = JsonToken.BEGIN_ARRAY;
                            currentNode.arrayIndex = 0;

                            // add a virtual node that points the first element
                            // of the array
                            JsonNode arrayElementNode = JsonNode.createArrayElementNode();
                            arrayElementNode.previous = currentNode;
                            nodeStack.addLast(arrayElementNode);
                        }
                            break;

                        case BEGIN_OBJECT: {
                            // visit a nested object
                            reader.beginObject();

                            JsonNode currentNode = nodeStack.getLast();
                            currentNode.valueToken = JsonToken.BEGIN_OBJECT;
                        }
                            break;

                        case END_ARRAY: {
                            // end a visit of an array and avoid that enters a
                            // endless loop
                            reader.endArray();

                            JsonNode currentNode = nodeStack.getLast();
                            if (currentNode.isArrayElementNode()) {
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        case END_OBJECT: {
                            // end a visit of an array and avoid that enters a
                            // endless loop
                            reader.endObject();

                            JsonNode currentNode = nodeStack.getLast();
                            if (currentNode.isArrayElementNode()) {
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        case STRING:
                        case NUMBER:
                        case BOOLEAN:
                        case NULL: {
                            // it's unreasonable that both path are on the same
                            // path but mismatched
                            reader.skipValue();

                            JsonNode currentNode = nodeStack.getLast();
                            if (currentNode.isArrayElementNode()) {
                                ++currentNode.previous.arrayIndex;
                            }
                        }
                            break;

                        default:
                        }
                    }
                }

                log.trace("Node stack: {}", nodeStack);
            }

            // exclude candidate from "[*]" wildcard set
            jsonPathSet.removeAll(jsonWildcardPathSet);

            if (!jsonPathSet.isEmpty()) {
                for (String mismatchingJsonPath : jsonPathSet) {
                    matchingMap.put(mismatchingJsonPath, null);
                }
                log.trace("Mismatching jsonPaths: {}", jsonPathSet);
            }
        } finally {
            IOUtils.closeQuietly(reader);
        }

        return matchingMap;
    }
}
