package com.patentcloud.api.web.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.patentcloud.api.model.RequestLog;
import com.patentcloud.api.server.dao.common.MongoDbClient;
import com.patentcloud.api.server.service.RequestCounterService;

@Component
public class RequestInterceptor extends HandlerInterceptorAdapter {

    private static final Logger log = LoggerFactory.getLogger(RequestInterceptor.class);

    @Autowired
    private RequestCounterService requestCounterService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        long startTime = System.currentTimeMillis();
        request.setAttribute("start", startTime);

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception exception) throws Exception {
        long startTime = (Long) request.getAttribute("start");
        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        // log it
        log.debug("{} takes {} ms", request.getRequestURI(), executionTime);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        this.requestCounterService.updateRequestCounter(user.getUsername());

        String clientId = user.getUsername();
        String clientHost = request.getParameter("client_host");

        if (StringUtils.isBlank(clientHost)) {
            // host format is "host name/ip address", e.g.
            // patentcloud-webtest2/10.60.90.178
            clientHost = String.format("%s/%s", request.getRemoteAddr(), request.getRemoteHost());
        }

        String errorMessage = null;
        if (exception != null) {
            errorMessage = exception.getMessage();
        }
        RequestLog requestLog = new RequestLog(clientId, clientHost, request.getPathInfo(), request.getParameterMap(),
                response.getStatus(), errorMessage, executionTime);

        log.debug("Prepare to insert one log to log db. request log: {}", requestLog);

        MongoDbClient.getInstance().insertLog(requestLog);
    }
}