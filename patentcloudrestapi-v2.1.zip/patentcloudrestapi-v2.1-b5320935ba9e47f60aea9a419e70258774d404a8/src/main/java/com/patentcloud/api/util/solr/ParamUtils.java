package com.patentcloud.api.util.solr;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.MemberPrivilege;
import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.util.FieldTermParseException;

public class ParamUtils {

    private static final Logger log = LoggerFactory.getLogger(ParamUtils.class);

    private static final CharsetEncoder iso8859_1Encoder = Charset.forName("ISO-8859-1").newEncoder();

    private static Pattern weight = Pattern.compile("^(\\^[0-9]+.?[0-9]*)");

    private static Pattern adj = Pattern.compile("^(~[0-9]+)");

    private static String processWeightOrAdj(String query) {
        if (query.trim().length() == 0) {
            return null;
        }
        if (query.charAt(0) != '^' && query.charAt(0) != '~') {
            return null;
        }
        String result = null;
        Matcher matcher = weight.matcher(query);
        if (matcher.find()) {
            result = matcher.group(1);
        } else {
            matcher = adj.matcher(query);
            if (matcher.find()) {
                result = matcher.group(1);
            }
        }
        return result;
    }

    public static List<String> splitQueryTerms(String query) {
        List<String> terms = new ArrayList<>();
        StringBuilder term = new StringBuilder();
        boolean inQuot = false;
        query = query.trim() + " ";
        for (int i = 0; i < query.length(); i++) {
            char ch = query.charAt(i);
            if (ch == '"') {
                inQuot = !inQuot;
                if (term.length() > 0) {
                    if (inQuot) {
                        terms.add(term.toString());
                    } else {
                        String theTerm = "\"" + term + "\"";
                        String extra = processWeightOrAdj(StringUtils.substring(query, i + 1));
                        if (extra != null) {
                            theTerm += extra;
                            i += extra.length();
                        }
                        terms.add(theTerm);
                    }
                }
                term = new StringBuilder();
                continue;
            }

            if (inQuot) {
                term.append(ch);
                continue;
            }

            if (ch == ' ') {
                if (term.length() > 0) {
                    terms.add(term.toString());
                    term = new StringBuilder();
                }
                continue;
            }

            if (ch == '(') {
                if (term.length() > 0) {
                    terms.add(term.toString());
                    term = new StringBuilder();
                }
                terms.add("(");
                continue;
            }

            if (ch == ')') {
                if (term.length() > 0) {
                    terms.add(term.toString());
                    term = new StringBuilder();
                }
                terms.add(")");
                continue;
            }

            if (ch == ':') {
                if (term.length() > 0) {
                    String termStr = processFieldTerms(query.substring(i + 1));
                    i += termStr.length();
                    terms.add(term + ":" + termStr);
                    term = new StringBuilder();
                    continue;
                } else {
                    throw new FieldTermParseException("Failed to parse field term");
                }
            }

            term.append(ch);
        }

        if (term.length() > 0) {
            terms.add(term.toString());
        }
        return terms;
    }

    private static String processFieldTerms(String query) {
        StringBuffer term = new StringBuffer();
        if (query.length() == 0) {
            throw new FieldTermParseException("Miss term!");
        }
        char first = query.charAt(0);
        int idx = 1;
        if (first == ' ') {
            throw new FieldTermParseException("Miss term!");
        } else if (first == '\"') {
            term.append(first);
            for (idx = 1; idx < query.length(); idx++) {
                char ch = query.charAt(idx);
                term.append(ch);
                if (ch == '\"') {
                    break;
                }
            }
            String extra = processWeightOrAdj(StringUtils.substring(query, idx + 1));
            if (extra != null) {
                term.append(extra);
                idx += extra.length();
            }
        } else if (first == '(') {
            term.append(first);
            int level = 1;
            for (idx = 1; idx < query.length(); idx++) {
                char ch = query.charAt(idx);
                term.append(ch);
                if (ch == '(') {
                    level++;
                }
                if (ch == ')') {
                    level--;
                }
                if (level == 0) {
                    break;
                }
            }
            if (level != 0) {
                throw new FieldTermParseException("Miss close )!");
            }
        } else if (first == '[') {
            term.append(first);
            boolean close = false;
            for (idx = 1; idx < query.length(); idx++) {
                char ch = query.charAt(idx);
                term.append(ch);
                if (ch == ']') {
                    close = true;
                    break;
                }
            }
            if (!close) {
                throw new FieldTermParseException("Miss close ]!");
            }
        } else {
            term.append(first);
            for (idx = 1; idx < query.length(); idx++) {
                char ch = query.charAt(idx);
                if (ch == ' ' || ch == ')') {
                    idx--;
                    break;
                }
                term.append(ch);
            }
        }
        return term.toString();
    }

    /* sync with base.js */
    private static final HashMap<String, String> baseFieldNameMap = new HashMap<>();

    static {
        baseFieldNameMap.put("agentsname", "agentsName");
        // added by yh for Censor
        baseFieldNameMap.put("examinermastersname", "examinerMastersName");
        baseFieldNameMap.put("appdate", "appDate");
        baseFieldNameMap.put("appnumberall", "appNumberAll");
        baseFieldNameMap.put("assigneesname", "assigneesName");
        baseFieldNameMap.put("assigneesaddress", "assigneesAddress");
        baseFieldNameMap.put("uspcs", "uspcs");
        baseFieldNameMap.put("decisiondate", "decisionDate");
        baseFieldNameMap.put("dodate", "doDate");
        baseFieldNameMap.put("inventorsname", "inventorsName");
        baseFieldNameMap.put("inventorsaddress", "inventorsAddress");
        baseFieldNameMap.put("inventorscountry", "inventorsCountry");
        baseFieldNameMap.put("ipcsnormal", "ipcsNormal");
        baseFieldNameMap.put("locs", "locs");
        baseFieldNameMap.put("mainuspc", "mainUSPC");
        baseFieldNameMap.put("mainipcnormal", "mainIPCNormal");
        baseFieldNameMap.put("mainloc", "mainLOC");
        baseFieldNameMap.put("cpcsnormal", "cpcsNormal");
        baseFieldNameMap.put("maincpcnormal", "mainCPCNormal");
        baseFieldNameMap.put("opendate", "openDate");
        baseFieldNameMap.put("brief", "brief");
        baseFieldNameMap.put("claim", "claim");
        baseFieldNameMap.put("description", "description");
        baseFieldNameMap.put("title", "title");
        baseFieldNameMap.put("patentnumberall", "patentNumberAll");
        baseFieldNameMap.put("typecode", "typeCode");
        baseFieldNameMap.put("typecode", "typeCode");
        baseFieldNameMap.put("party", "party");
        baseFieldNameMap.put("all", "all");
        baseFieldNameMap.put("kindcode", "kindcode");
        baseFieldNameMap.put("country", "country");
        baseFieldNameMap.put("familyidgroup", "familyIdGroup");
    }

    private static final HashMap<String, String> assignmentFieldNameMap = new HashMap<>();

    static {
        assignmentFieldNameMap.put("assignmentassignors", "assignmentAssignors");
        assignmentFieldNameMap.put("assignmentassignees", "assignmentAssignees");
        assignmentFieldNameMap.put("assignmentassigneedates", "assignmentAssigneeDates");
        assignmentFieldNameMap.put("assignmentassigneecount", "assignmentAssigneeCount");
        assignmentFieldNameMap.put("assignmentlicensors", "assignmentLicensors");
        assignmentFieldNameMap.put("assignmentlicensees", "assignmentLicensees");
        assignmentFieldNameMap.put("assignmentlicenseedates", "assignmentLicenseeDates");
        assignmentFieldNameMap.put("assignmentlicenseecount", "assignmentLicenseeCount");
        assignmentFieldNameMap.put("assignmentmortgagecreditors", "assignmentMortgageCreditors");
        assignmentFieldNameMap.put("assignmentmortgageapplicants", "assignmentMortgageApplicants");
        assignmentFieldNameMap.put("assignmentmortgageapplicantdates", "assignmentMortgageApplicantDates");
        assignmentFieldNameMap.put("assignmentmortgageapplicantcount", "assignmentMortgageApplicantCount");
    }

    private static final HashMap<String, String> litigationFieldNameMap = new HashMap<>();

    static {
        litigationFieldNameMap.put("litigationcasetypes", "litigationCaseTypes");
        litigationFieldNameMap.put("litigationcasenumbers", "litigationCaseNumbers");
        litigationFieldNameMap.put("litigationcasenames", "litigationCaseNames");
        litigationFieldNameMap.put("litigationcasestatus", "litigationCaseStatus");
        litigationFieldNameMap.put("litigationcounts", "litigationCounts");
        litigationFieldNameMap.put("litigationpleading", "litigationPleading");
        litigationFieldNameMap.put("litigationpleadingtype", "litigationPleadingType");
        litigationFieldNameMap.put("litigationfilingdates", "litigationFilingDates");
        litigationFieldNameMap.put("litigationplaintiffs", "litigationPlaintiffs");
        litigationFieldNameMap.put("litigationdefendants", "litigationDefendants");
        litigationFieldNameMap.put("litigationplaintifffirms", "litigationPlaintiffFirms");
        litigationFieldNameMap.put("litigationdefendantfirms", "litigationDefendantFirms");
        litigationFieldNameMap.put("litigationpatentvalidity", "litigationPatentValidity");
        litigationFieldNameMap.put("litigationpatentinfringement", "litigationPatentInfringement");
        litigationFieldNameMap.put("litigationcontents", "litigationContents");
        litigationFieldNameMap.put("litigationtotalcount", "litigationTotalCount");
    }

    // docValue 欄位檢索大小寫有別，資料與檢索統一為大寫
    private static final Set<String> docValuesFieldSet = new HashSet<>();

    static {
        docValuesFieldSet.add("country");
        docValuesFieldSet.add("kindcode");
        docValuesFieldSet.add("uspcs");
        docValuesFieldSet.add("ipcsnormal");
        docValuesFieldSet.add("locs");
        docValuesFieldSet.add("mainuspc");
        docValuesFieldSet.add("mainipcnormal");
        docValuesFieldSet.add("mainloc");
        docValuesFieldSet.add("cpcsnormal");
        docValuesFieldSet.add("maincpcnormal");
        docValuesFieldSet.add("typecode");
    }

    private static final Set<String> stemFieldSet = new HashSet<>();

    static {
        stemFieldSet.add("title");
        stemFieldSet.add("brief");
        stemFieldSet.add("claim");
        stemFieldSet.add("description");
        stemFieldSet.add("all");
    }

    private static Pattern reK2Date = Pattern.compile("^(\\d{4})(\\d{1,2})?(\\d{1,2})?\\*?$");

    private static Date parseK2Date(String input, boolean end) {
        Date date = null;
        SimpleDateFormat sdf;
        input = input.trim();
        Matcher matcher = reK2Date.matcher(input);
        try {
            if (matcher.find()) {
                Calendar cal = Calendar.getInstance();
                String year = matcher.group(1);
                String mon = matcher.group(2);
                String day = matcher.group(3);
                if (year != null && year.length() == 4) {
                    if (mon != null && !mon.isEmpty()) {
                        if (day != null && !day.isEmpty()) {
                            sdf = new SimpleDateFormat("yyyyMMdd");
                            date = sdf.parse(year + mon + day);
                            if (end) {
                                cal.setTime(date);
                                cal.add(Calendar.DAY_OF_YEAR, 1);
                            }
                        } else {
                            sdf = new SimpleDateFormat("yyyyMM");
                            date = sdf.parse(year + mon);
                            if (end) {
                                cal.setTime(date);
                                cal.add(Calendar.MONTH, 1);
                            }
                        }
                    } else {
                        sdf = new SimpleDateFormat("yyyy");
                        date = sdf.parse(year);
                        if (end) {
                            cal.setTime(date);
                            cal.add(Calendar.YEAR, 1);
                        }
                    }

                    if (end) {
                        date = new Date(cal.getTimeInMillis() - 1);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }

    private static String transQueryK2SdateFrom(String dateFrom) {
        SimpleDateFormat solrDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        Date date = parseK2Date(dateFrom, false);
        if (date == null) {
            return "1900-01-01T00:00:00Z";
        }
        return solrDateFormat.format(date);
    }

    private static String transQueryK2SdateTo(String dateTo) {
        SimpleDateFormat solrDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        Date date = parseK2Date(dateTo, true);
        if (date == null) {
            return "*";
        }
        return solrDateFormat.format(date);
    }

    private static Pattern reK2Sdate = Pattern.compile(
            "(?i)^(appdate|decisiondate|opendate|dodate|FD):\\[?\\s*?(\\d*)(\\*?)\\s*?(->)?\\s*?(\\d*)\\*?\\s*?\\]?$");

    private static String transQueryK2Sdate(String term) {
        if (term == null) {
            return null;
        }
        Matcher matcher = reK2Sdate.matcher(term.toLowerCase());
        if (matcher.find()) {
            String mtype = matcher.group(1);
            String mfrom = matcher.group(2);
            String mfromStar = matcher.group(3);
            String mop = matcher.group(4);
            String mto = matcher.group(5);

            String dateFrom = null;
            String dateTo = null;

            dateFrom = transQueryK2SdateFrom(mfrom);

            if (mop == null || mop.isEmpty()) {
                if (mfromStar == null || mfromStar.isEmpty()) {
                    dateTo = null;
                } else {
                    dateTo = transQueryK2SdateTo(mfrom);
                }
            } else {
                dateTo = transQueryK2SdateTo(mto);
            }

            if (dateTo == null) {
                term = mtype + ":\"" + dateFrom + "\"";
            } else {
                term = mtype + ":[" + dateFrom + " TO " + dateTo + "]";
            }
        }
        return term;
    }

    private static Pattern weightTerm = Pattern.compile("^(.+)(\\^[0-9]+.?[0-9]*)$");

    public static String transQueryK2S(String query, boolean stem, MemberPrivilege privilege) {
        if (privilege == null) {
            privilege = new MemberPrivilege();
        }
        StringBuilder sb = new StringBuilder();

        HashMap<String, String> fieldNameMap = new HashMap<String, String>();
        fieldNameMap.putAll(baseFieldNameMap);
        if (privilege.permit(privilege.ASSIGNMENT)) {
            fieldNameMap.putAll(assignmentFieldNameMap);
        }
        if (privilege.permit(privilege.LITIGATION)) {
            fieldNameMap.putAll(litigationFieldNameMap);
        }

        List<String> terms = ParamUtils.splitQueryTerms(query);

        for (String term : terms) {
            if (term.matches("(?i)^AND$")) {
                term = "AND";
                sb.append(term);
            } else if (term.matches("(?i)^OR$")) {
                term = "OR";
                sb.append(term);
            } else if (term.matches("(?i)^NOT$")) {
                term = "NOT";
                sb.append(term);
            } else if (isFieldTerm(term, fieldNameMap)) {
                term = transQueryK2Sdate(term);
                int idx = term.indexOf(":");
                String fieldName = term.substring(0, idx).toLowerCase();
                String fieldValue = term.substring(idx + 1);
                String solrField = fieldNameMap.get(fieldName.toLowerCase());
                String solrq = solrField + ":" + fieldValue;

                if (!(fieldValue.startsWith(":") && fieldValue.endsWith(":"))) {
                    List<String> subTerms = splitQueryTerms(fieldValue);
                    StringBuilder subsb = new StringBuilder();
                    for (String subTerm : subTerms) {
                        if (subTerm.matches("(?i)^AND$")) {
                            subTerm = "AND";
                            subsb.append(subTerm);
                        } else if (subTerm.matches("(?i)^OR$")) {
                            subTerm = "OR";
                            subsb.append(subTerm);
                        } else if (subTerm.matches("(?i)^NOT$")) {
                            subTerm = "NOT";
                            subsb.append(subTerm);
                        } else {
                            Pattern pattern4 = Pattern.compile("\\p{Punct}+");
                            Matcher matcher4 = pattern4.matcher(subTerm);
                            if (matcher4.matches()) {
                                // TODO 理應只有 ( ) ，看是不是檔掉其他所有情況?
                                subsb.append(subTerm);
                            } else if (subTerm.startsWith("\"")) {
                                subsb.append(subTerm);
                            } else {
                                if (!subTerm.contains("*") && !iso8859_1Encoder.canEncode(subTerm)) {
                                    Matcher mat = weightTerm.matcher(subTerm);
                                    if (mat.find()) {
                                        subsb.append("\"" + mat.group(1) + "\"" + mat.group(2));
                                    } else {
                                        subsb.append("\"" + subTerm + "\"");
                                    }
                                } else {
                                    subsb.append(subTerm);
                                }
                            }
                        }
                        subsb.append(" ");
                    }
                    if (subsb.length() > 0) {
                        subsb.deleteCharAt(subsb.length() - 1);
                    }
                    if (docValuesFieldSet.contains(fieldName)) {
                        solrq = solrField + ":" + subsb.toString().toUpperCase();
                    } else {
                        solrq = solrField + ":" + subsb;
                    }
                }
                if (stem && stemFieldSet.contains(fieldName)) {
                    String solrqStem = solrq.replace(solrField, solrField + "Stem");
                    if (fieldValue.contains("*")) {
                        sb.append("(" + solrq + " OR " + solrqStem + ")");
                    } else {
                        sb.append(solrqStem);
                    }
                } else {
                    sb.append(solrq);
                }
            } else {
                // full, (, ), doDate:[] and so on...
                Pattern pattern4 = Pattern.compile("\\p{Punct}+");
                Matcher matcher4 = pattern4.matcher(term);
                if (matcher4.matches()) {
                    // TODO 理應只有 ( ) ，看是不是檔掉其他所有情況?
                    sb.append(term);
                } else if (term.startsWith("\"")) {
                    // full
                    if (stem) {
                        if (term.contains("*")) {
                            sb.append("(allStem:" + term + " OR all:" + term + ")");
                        } else {
                            sb.append("allStem:" + term);
                        }
                    } else {
                        sb.append("all:" + term);
                    }
                } else if (term.contains(":")) {
                    // solr
                    sb.append(term);
                } else {
                    // full
                    if (stem) {
                        if (term.contains("*")) {
                            sb.append("(allStem:" + term + " OR all:" + term + ")");
                        } else {
                            if (!iso8859_1Encoder.canEncode(term)) {
                                Matcher mat = weightTerm.matcher(term);
                                if (mat.find()) {
                                    sb.append("allStem:\"" + mat.group(1) + "\"" + mat.group(2));
                                } else {
                                    sb.append("allStem:\"" + term + "\"");
                                }
                            } else {
                                sb.append("allStem:" + term);
                            }
                        }
                    } else {
                        if (!iso8859_1Encoder.canEncode(term)) {
                            Matcher mat = weightTerm.matcher(term);
                            if (mat.find()) {
                                sb.append("all:\"" + mat.group(1) + "\"" + mat.group(2));
                            } else {
                                sb.append("all:\"" + term + "\"");
                            }
                        } else {
                            sb.append("all:" + term);
                        }
                    }
                }
            }
            sb.append(" ");
        }

        log.debug("transfer stem({}):{}==>{}", stem, query, sb);

        return sb.toString().trim();
    }

    private static boolean isFieldTerm(String term, HashMap<String, String> fieldNameMap) {
        if (!term.contains(":")) {
            return false;
        }
        int idx = term.indexOf(":");
        String field = term.substring(0, idx);
        return fieldNameMap.keySet().contains(field.toLowerCase());
    }

    public static String genPdfName(PatentFile pdffile) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String dateStr = sdf.format(pdffile.info.doDate);
        String name = "";
        String patentNumber = pdffile.getInfo().patentNumber;
        if (pdffile.getInfo().patentNumber.substring(0, 4).toLowerCase().equals("us00")) {
            patentNumber = patentNumber.substring(4, patentNumber.length());
        }
        if (pdffile.info.kindcode == null) {
            name = pdffile.info.country.toUpperCase() + patentNumber + "-" + dateStr + ".pdf";
        } else {
            name = pdffile.info.country.toUpperCase() + patentNumber + pdffile.info.kindcode + "-" + dateStr + ".pdf";
        }
        return name;
    }

    public static Set<String> permitFields(Set<String> requestFields, MemberPrivilege privilege) {
        Set<String> permitFields = new HashSet<String>();
        if (requestFields != null) {
            permitFields.addAll(requestFields);
            if (privilege == null) {
                privilege = new MemberPrivilege();
            }

            if (!privilege.permit(privilege.ASSIGNMENT)) {
                for (String field : assignmentFieldNameMap.values()) {
                    permitFields.remove(field);
                }
            }
            if (!privilege.permit(privilege.LITIGATION)) {
                for (String field : litigationFieldNameMap.values()) {
                    permitFields.remove(field);
                }
            }
        }
        return permitFields;
    }
}