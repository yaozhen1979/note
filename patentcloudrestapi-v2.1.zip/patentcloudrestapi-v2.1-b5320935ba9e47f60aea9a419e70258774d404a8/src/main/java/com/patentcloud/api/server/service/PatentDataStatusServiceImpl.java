package com.patentcloud.api.server.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.FacetField.Count;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.PatentDataStatus;
import com.patentcloud.api.model.SolrQueryVO;
import com.patentcloud.api.model.solr.SolrPatentInfo;
import com.patentcloud.api.model.solr.SolrQueryResult;
import com.patentcloud.api.server.dao.PatentDataStatusDao;
import com.patentcloud.api.util.solr.SolrUtils;

public class PatentDataStatusServiceImpl implements PatentDataStatusService {

    private static final Logger log = LoggerFactory.getLogger(PatentDataStatusServiceImpl.class);

    private static final String ASSIGNMENT = "ASSIGNMENT";

    private static final Map<String, Integer[]> COUNTRY_TYPE = new HashMap<>();

    static {
        COUNTRY_TYPE.put("JP", new Integer[] { 1, 2, 3 });
    }

    private Date minDate;

    private Date maxDate;

    private PatentDataStatusDao patentDataStatusDao;

    public void setPatentDataStatusDao(PatentDataStatusDao patentDataStatusDao) {
        this.patentDataStatusDao = patentDataStatusDao;
    }

    @Override
    public void updatePatentDataStatus() {
        Date startCheckTime = new Date();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startCheckTime);

        calendar.set(Calendar.MILLISECOND, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        maxDate = calendar.getTime();

        calendar.set(1700, 0, 0);
        minDate = calendar.getTime();

        List<PatentDataStatus> dataStatusList = new ArrayList<PatentDataStatus>();

        try {
            List<String> countryList = queryCountryList();
            Integer[] statArray = new Integer[] { 1, 2 };

            // update per country patent status
            for (String country : countryList) {
                Integer[] typeArray = COUNTRY_TYPE.get(country);
                for (Integer stat : statArray) {
                    if (typeArray != null && typeArray.length > 0) {
                        for (Integer type : typeArray) {
                            PatentDataStatus patentDataStatus = queryPatentDataStatus(country, stat, type);
                            if (patentDataStatus != null) {
                                dataStatusList.add(patentDataStatus);
                            }
                        }
                    } else {
                        PatentDataStatus patentDataStatus = queryPatentDataStatus(country, stat, null);
                        if (patentDataStatus != null) {
                            dataStatusList.add(patentDataStatus);
                        }
                    }
                }
            }

            // update currentAssignee Status
            SolrQueryVO queryVO = new SolrQueryVO();
            queryVO.setQ("(currentAssigneesUpdateDate:*)");
            SolrQuery query = SolrUtils.genQuery(queryVO);

            query.setRows(1);
            query.addSort("currentAssigneesUpdateDate", ORDER.desc);
            query.addField("currentAssigneesUpdateDate");

            Date checkTime = new Date();
            SolrQueryResult solrQueryResult = SolrUtils.queryInfos(query);

            if (solrQueryResult.getPatentInfoList() != null && solrQueryResult.getPatentInfoList().size() > 0) {
                SolrPatentInfo info = solrQueryResult.getPatentInfoList().get(0);
                PatentDataStatus dataStatus = new PatentDataStatus();
                dataStatus.setCheckDateTime(checkTime);
                dataStatus.setLatestUpdateDateTime(info.getCurrentAssigneesUpdateDate());
                dataStatus.setPto("USPTO");
                dataStatus.setTarget(ASSIGNMENT);
                dataStatusList.add(dataStatus);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        for (PatentDataStatus dataStatus : dataStatusList) {
            PatentDataStatus existDataStatus = patentDataStatusDao.findPatentDataStatusById(dataStatus.generateId());
            if (existDataStatus == null) {
                patentDataStatusDao.savePatentDataStatus(dataStatus);
            } else {
                existDataStatus.setEarliestUpdateDateTime(dataStatus.getEarliestUpdateDateTime());
                existDataStatus.setLatestUpdateDateTime(dataStatus.getLatestUpdateDateTime());
                existDataStatus.setPatentCount(dataStatus.getPatentCount());
                existDataStatus.setCheckDateTime(dataStatus.getCheckDateTime());
                patentDataStatusDao.updatePatentDataStatus(existDataStatus);
            }
        }

        patentDataStatusDao.deleteInvalidPatentDataStatus(startCheckTime);
    }

    private List<String> queryCountryList() throws Exception {
        SolrQueryVO queryVO = new SolrQueryVO();
        queryVO.setQ("(*:*)");
        SolrQuery query = SolrUtils.genQuery(queryVO);
        query.setFacet(true);
        query.addFacetField("country");
        query.setFacetLimit(150);
        query.set("facet.offset", 0);
        query.setRows(0);

        List<String> countryList = new ArrayList<String>();

        QueryResponse response = SolrUtils.query(query);

        List<FacetField> facetFieldList = response.getFacetFields();
        if (facetFieldList != null && facetFieldList.size() > 0) {
            List<Count> countList = facetFieldList.get(0).getValues();
            for (Count count : countList) {
                countryList.add(count.getName());
            }
        }

        return countryList;
    }

    private PatentDataStatus queryPatentDataStatus(String country, Integer stat, Integer type) throws Exception {
        PatentDataStatus dataStatus = queryPatentDataStatusFromSolr(country, stat, type, false);
        if (dataStatus != null) {
            PatentDataStatus earliestDataStatus = queryPatentDataStatusFromSolr(country, stat, type, true);
            if (earliestDataStatus != null) {
                dataStatus.setEarliestUpdateDateTime(earliestDataStatus.getEarliestUpdateDateTime());
            }
        }
        return dataStatus;
    }

    private PatentDataStatus queryPatentDataStatusFromSolr(String country, Integer stat, Integer type, boolean ascSort)
            throws Exception {
        PatentDataStatus dataStatus = null;

        SolrQueryVO queryVO = new SolrQueryVO();
        queryVO.setQ("(*:*)");
        queryVO.setStart(0);
        queryVO.setRows(1);

        if (country != null && country.length() > 0) {
            queryVO.setCc(Arrays.asList(new String[] { country }));
        }
        if (stat != null) {
            queryVO.setStat(new Integer[] { stat });
        }
        if (type != null) {
            queryVO.setTc(new Integer[] { type });
        }

        SolrQuery query = SolrUtils.genQuery(queryVO);
        setSolrQuery(query, ascSort);

        Date checkTime = new Date();
        SolrQueryResult infoList = SolrUtils.queryInfos(query);

        if (infoList.getPatentInfoList() != null && infoList.getPatentInfoList().size() > 0) {
            dataStatus = createPatentDataStatus(infoList.getPatentInfoList().get(0), type);
            dataStatus.setPatentCount(infoList.getNumFound());
            dataStatus.setCheckDateTime(checkTime);
        }
        return dataStatus;
    }

    private void setSolrQuery(SolrQuery query, boolean ascSort) {
        query.addField("pto");
        query.addField("country");
        query.addField("type");
        query.addField("typeCode");
        query.addField("stats");
        query.addField("doDate");
        query.addField("openDate");
        query.addField("decisionDate");

        if (ascSort) {
            query.addSort("score", ORDER.asc);
            query.addSort("doDate", ORDER.asc);
            query.addSort("openDate", ORDER.asc);
            query.addSort("decisionDate", ORDER.asc);
        } else {
            query.addSort("score", ORDER.desc);
            query.addSort("doDate", ORDER.desc);
            query.addSort("openDate", ORDER.desc);
            query.addSort("decisionDate", ORDER.desc);
        }
    }

    private PatentDataStatus createPatentDataStatus(SolrPatentInfo solrPatentInfo, Integer type) {
        PatentDataStatus dataStatus = new PatentDataStatus();
        dataStatus.setPto(solrPatentInfo.getPto());
        dataStatus.setTarget(solrPatentInfo.getCountry());
        if (type != null) {
            dataStatus.setPatentType(solrPatentInfo.getTypeCode());
        }
        dataStatus.setPatentStatus(solrPatentInfo.getStats().get(0));
        Date doDate = solrPatentInfo.getDoDate();
        if (doDate != null && doDate.compareTo(minDate) > 0 && doDate.compareTo(maxDate) < 0) {
            dataStatus.setEarliestUpdateDateTime(doDate);
            dataStatus.setLatestUpdateDateTime(doDate);
        } else if (doDate == null && "KR".equalsIgnoreCase(solrPatentInfo.getCountry())) {
            Calendar c = Calendar.getInstance();
            if (solrPatentInfo.getStats().get(0).intValue() == 1) {
                c.set(1980, 9, 24, 0, 0, 0);
            } else {
                c.set(1979, 6, 11, 0, 0, 0);
            }
            dataStatus.setEarliestUpdateDateTime(c.getTime());
        }
        return dataStatus;
    }

    @Override
    public PatentDataStatus findPatentDataStatus(String target, Integer stat, Integer type) {
        return patentDataStatusDao.findPatentDataStatus(target, stat, type);
    }

    @Override
    public List<PatentDataStatus> findAllPatentDataStatus() {
        return patentDataStatusDao.findAllPatentDataStatus();
    }
}
