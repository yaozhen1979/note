package com.patentcloud.api.model;

import java.io.File;

public class PatentFile {

    public PatentInfo info;

    public File file = new File("");

    public String mimeType = "";

    public PatentInfo getInfo() {
        return info;
    }

    public void setInfo(PatentInfo info) {
        this.info = info;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
}
