package com.patentcloud.api.server.dao;

import java.util.Date;
import java.util.List;

import com.patentcloud.api.model.PatentDataStatus;

public interface PatentDataStatusDao {

    void savePatentDataStatus(PatentDataStatus patentDataStatus);
    void updatePatentDataStatus(PatentDataStatus patentDataStatus);
    void deleteInvalidPatentDataStatus(Date checkDateTime);

    PatentDataStatus findPatentDataStatusById(String id);
    PatentDataStatus findPatentDataStatus(String target, Integer stat, Integer type);
    List<PatentDataStatus> findAllPatentDataStatus();
}
