package com.patentcloud.api.util;

import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

public class EncrypUtil {

    private static final String IV = "AAAAAAAAAAAAAAAA";

    private static String defaultKey = "0123456789abcdef";

    public static String encryptAES(byte[] key, String data) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(IV.getBytes()));
        byte[] encrypted = cipher.doFinal(data.getBytes("UTF-8"));
        return Base64.encodeBase64URLSafeString(encrypted);
    }

    public static String decryptAES(byte[] key, String data) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(IV.getBytes()));

        byte[] rawData = Base64.decodeBase64(data.getBytes());
        return new String(cipher.doFinal(rawData), "UTF-8");
    }

    public static String encryptAES(String plainText) throws Exception {
        return encryptAES(defaultKey.getBytes("UTF-8"), plainText);
    }

    public static String decryptAES(String cipherText) throws Exception {
        return decryptAES(defaultKey.getBytes("UTF-8"), cipherText);
    }

    /**
     * Mask a raw password with asterisk (*) symbols, e.g. 123456 to 1****6
     * 
     * @param password
     *            a raw password
     * @return a masked password
     */
    public static String maskPassword(String password) {
        if (StringUtils.isBlank(password)) {
            return password;
        }

        if (password.length() < 2) {
            char[] maskedCharArray = new char[password.length()];
            Arrays.fill(maskedCharArray, '*');
            
            return new String(maskedCharArray);
        }

        StringBuilder maskedPasswordSb = new StringBuilder(password);

        for (int i = 0; i < maskedPasswordSb.length(); i++) {
            if (i != 0 && i != maskedPasswordSb.length() - 1) {
                maskedPasswordSb.setCharAt(i, '*');
            }
        }

        return maskedPasswordSb.toString();
    }
}
