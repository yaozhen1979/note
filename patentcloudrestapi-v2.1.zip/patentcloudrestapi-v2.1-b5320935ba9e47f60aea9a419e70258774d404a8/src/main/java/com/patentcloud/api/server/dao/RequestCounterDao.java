package com.patentcloud.api.server.dao;

import java.util.Date;

import com.patentcloud.api.model.RequestCounter;

public interface RequestCounterDao {

    RequestCounter getRequestCounterByDate(String userId, Date date);

    void addRequestCounter(RequestCounter requestCounterInfo);

    void updateRequestCounter(RequestCounter requestCounterInfo);
}
