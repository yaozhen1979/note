package com.patentcloud.api.model;

import java.util.ArrayList;
import java.util.List;

public class MemberPrivilege {

    public final static String ASSIGNMENT = "assignment";
    public final static String LITIGATION = "litigation";

    public final static String[] allPermits = { ASSIGNMENT, LITIGATION };

    private List<String> permitList = new ArrayList<String>();

    public MemberPrivilege(String... permits) {
        if (permits != null) {
            for (String permit : permits) {
                if (permit != null && !permitList.contains(permit)) {
                    permitList.add(permit);
                }
            }
        }
    }

    public boolean permit(String permit) {
        return permitList.contains(permit);
    }

    public String[] getPermits() {
        return permitList.toArray(new String[0]);
    }
}
