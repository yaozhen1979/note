package com.patentcloud.api.util.config;

import com.patentcloud.api.server.dao.common.MongoDbClientConfig;
import com.patentcloud.api.util.http.SolrServiceClientConfig;
import com.patentcloud.api.util.http.external.DownloadServiceClientConfig;
import com.patentcloud.api.util.nlp.NlpServiceClientConfig;

/**
 * A container that wraps a associated configuration.
 *
 * @author Allan Huang
 */
public class ConfigProperties extends SystemProperties {

    private static final long serialVersionUID = 1702262533878238466L;

    private static final String FILE_PATH = "/api/config.properties";

    private static final ConfigProperties INSTANCE = new ConfigProperties();

    public static ConfigProperties getInstance() {
        return INSTANCE;
    }

    private ConfigProperties() {
        super(FILE_PATH);
    }

    /**
     * Get the immutable configuration of a MongoDB client from
     * config.properties
     * 
     * @return an immutable configuration object
     */
    public MongoDbClientConfig getMongoDbClientConfig() {
        String mongoDbHost = this.getProperty("mongodb.server.host");
        int mongoDbPort = this.getInt("mongodb.server.port", 27017);
        String mongoDbName = this.getProperty("mongodb.db.name");
        String userName = this.getProperty("mongodb.user.name");
        String password = this.getProperty("mongodb.user.password");

        MongoDbClientConfig config = new MongoDbClientConfig.Builder(mongoDbHost, mongoDbPort, mongoDbName, userName,
                password).build();

        return config;
    }

    /**
     * Get the immutable configuration of a Solr service client from
     * config.properties
     * 
     * @return an immutable configuration object
     */
    public SolrServiceClientConfig getSolrServiceClientConfig() {
        int maxTotalConnection = this.getInt("solr.service.connection.max.total", 100);
        int maxConnectionTimout = this.getInt("solr.service.connection.timeout.max.millsecond", 7 * 1000);
        int maxSocketTimeout = this.getInt("solr.service.socket.timeout.max.millsecond", 30 * 1000);
        int maxConnectionRequestTimeout = this.getInt("solr.service.connection.request.timeout.max.millsecond",
                3 * 1000);

        SolrServiceClientConfig config = new SolrServiceClientConfig.Builder().setMaxTotalConnection(maxTotalConnection)
                .setMaxConnectionTimout(maxConnectionTimout).setMaxSocketTimeout(maxSocketTimeout)
                .setMaxConnectionRequestTimeout(maxConnectionRequestTimeout).build();

        return config;
    }

    /**
     * Get the immutable configuration of a Download service client from
     * config.properties
     * 
     * @return an immutable configuration object
     */
    public DownloadServiceClientConfig getDownloadServiceClientConfig() {
        int maxTotalConnection = this.getInt("download.service.connection.max.total", 100);
        int maxConnectionTimout = this.getInt("download.service.connection.timeout.max.millsecond", 7 * 1000);
        int maxSocketTimeout = this.getInt("download.service.socket.timeout.max.millsecond", 30 * 1000);
        int maxConnectionRequestTimeout = this.getInt("download.service.connection.request.timeout.max.millsecond",
                3 * 1000);

        DownloadServiceClientConfig.ProxyConfig proxy = null;
        String proxyHost = this.getString("download.service.proxy.host");
        int proxyPort = this.getInt("download.service.proxy.port");

        if (proxyHost != null && proxyPort != 0) {
            proxy = new DownloadServiceClientConfig.ProxyConfig(proxyHost, proxyPort);

            String userName = this.getString("download.service.proxy.user.name");
            String password = this.getString("download.service.proxy.user.password");
            proxy.setUser(userName);
            proxy.setPassword(password);
        }

        DownloadServiceClientConfig config = new DownloadServiceClientConfig.Builder()
                .setMaxTotalConnection(maxTotalConnection).setMaxConnectionTimout(maxConnectionTimout)
                .setMaxSocketTimeout(maxSocketTimeout).setMaxConnectionRequestTimeout(maxConnectionRequestTimeout)
                .setProxyConfig(proxy).build();

        return config;
    }

    /**
     * Get the immutable configuration of a NLP service client from
     * config.properties
     * 
     * @return an immutable configuration object
     */
    public NlpServiceClientConfig getNlpServiceClientConfig() {
        String nlpServiceUrl = this.getString("nlp.service.url");

        int maxTotalConnection = this.getInt("nlp.service.connection.max.total", 100);
        int maxConnectionTimout = this.getInt("nlp.service.connection.timeout.max.millsecond", 7 * 1000);
        int maxSocketTimeout = this.getInt("nlp.service.socket.timeout.max.millsecond", 30 * 1000);
        int maxConnectionRequestTimeout = this.getInt("nlp.service.connection.request.timeout.max.millsecond",
                3 * 1000);

        NlpServiceClientConfig config = new NlpServiceClientConfig.Builder(nlpServiceUrl)
                .setMaxTotalConnection(maxTotalConnection).setMaxConnectionTimout(maxConnectionTimout)
                .setMaxSocketTimeout(maxSocketTimeout).setMaxConnectionRequestTimeout(maxConnectionRequestTimeout)
                .build();

        return config;
    }
}
