package com.patentcloud.api.model;

import java.util.ArrayList;
import java.util.List;

public class SolrQueryVO {

    private static final int DEFAULT_ROWS = 20;

    private static final int DEFAULT_GROUPLIMIT = 20;

    private static final int DEFAULT_FACETLIMIT = 20;

    private static final int DEFAULT_FACETOFFECT = 0;
    
    private static final String DEFAULT_FACETSORT = "index";

    public static final String DEFAULT_FIELD = "defaultField";

    public static final String PATDB_OVERVIEW = "patdbOverview";

    public static final String BG_EXPORT_FIELD = "bgExportField";

    private List<String> cc; // country code

    private int rows = DEFAULT_ROWS;

    private String sort;

    private int start = 0;

    private String q;

    private String fq;

    private boolean defOpAnd = true;

    private Integer[] stat;

    private Integer[] tc; // patent type code

    private boolean highlight;

    private String[] highlightField;

    private String nodeId;

    private String treeId;

    private String field;

    private String[] fieldvalue;

    private String addquery;

    private String mode;

    private List<String> ptopId;

    private boolean projectIndex;

    private boolean facet;

    private int facetLimit;

    private int facetOffset;
    
    private String facetSort;

    private String facetFieldMode;

    private List<String> facetField;

    private boolean stem = true;

    private boolean docdb = false;

    private boolean group = false;

    private String groupField;

    private int groupLimit;

    private boolean groupNgroups = false;

    private Integer rangeStart;

    private Integer rangeEnd;

    private String cursorMark;

    public List<String> getCc() {
        return cc;
    }

    public void setCc(List<String> cc) {
        this.cc = cc;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getFq() {
        return fq;
    }

    public void setFq(String fq) {
        this.fq = fq;
    }

    public boolean isDefOpAnd() {
        return defOpAnd;
    }

    public void setDefOpAnd(boolean defOpAnd) {
        this.defOpAnd = defOpAnd;
    }

    public Integer[] getStat() {
        return stat;
    }

    public void setStat(Integer[] stat) {
        this.stat = stat;
    }

    public boolean isHighlight() {
        return highlight;
    }

    public void setHighlight(boolean highlight) {
        this.highlight = highlight;
    }

    public String[] getHighlightField() {
        return highlightField;
    }

    public void setHighlightField(String[] highlightField) {
        this.highlightField = highlightField;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getTreeId() {
        return treeId;
    }

    public void setTreeId(String treeId) {
        this.treeId = treeId;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String[] getFieldvalue() {
        return fieldvalue;
    }

    public void setFieldvalue(String[] fieldvalue) {
        this.fieldvalue = fieldvalue;
    }

    public String getAddquery() {
        return addquery;
    }

    public void setAddquery(String addquery) {
        this.addquery = addquery;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public List<String> getPtopId() {
        return ptopId;
    }

    public void setPtopId(List<String> ptopId) {
        this.ptopId = ptopId;
    }

    public boolean isProjectIndex() {
        return projectIndex;
    }

    public void setProjectIndex(boolean projectIndex) {
        this.projectIndex = projectIndex;
    }

    public boolean isFacet() {
        return facet;
    }

    public void setFacet(boolean facet) {
        this.facet = facet;
    }

    public Integer getRangeStart() {
        return rangeStart;
    }

    public void setRangeStart(Integer rangeStart) {
        this.rangeStart = rangeStart;
    }

    public Integer getRangeEnd() {
        return rangeEnd;
    }

    public void setRangeEnd(Integer rangeEnd) {
        this.rangeEnd = rangeEnd;
    }

    public Integer[] getTc() {
        return tc;
    }

    public void setTc(Integer[] tc) {
        this.tc = tc;
    }

    public boolean isStem() {
        return stem;
    }

    public void setStem(boolean stem) {
        this.stem = stem;
    }

    public boolean isDocdb() {
        return docdb;
    }

    public void setDocdb(boolean docdb) {
        this.docdb = docdb;
    }

    public void addCc(String country) {
        if (cc == null) {
            cc = new ArrayList<String>();
        }
        cc.add(country);
    }

    public int getFacetLimit() {
        return facetLimit;
    }

    public void setFacetLimit(int facetLimit) {
        this.facetLimit = facetLimit;
    }

    public int getFacetOffset() {
        return facetOffset;
    }

    public void setFacetOffset(int facetOffset) {
        this.facetOffset = facetOffset;
    }    
    
    public String getFacetSort() {
        return facetSort;
    }

    public void setFacetSort(String facetSort) {
        this.facetSort = facetSort;
    }

    public String getFacetFieldMode() {
        return facetFieldMode;
    }

    public void setFacetFieldMode(String facetFieldMode) {
        this.facetFieldMode = facetFieldMode;
    }

    public List<String> getFacetField() {
        return facetField;
    }

    public void setFacetField(List<String> facetField) {
        this.facetField = facetField;
    }

    public boolean isGroup() {
        return group;
    }

    public void setGroup(boolean group) {
        this.group = group;
    }

    public String getGroupField() {
        return groupField;
    }

    public void setGroupField(String groupField) {
        this.groupField = groupField;
    }

    public int getGroupLimit() {
        return groupLimit;
    }

    public void setGroupLimit(int groupLimit) {
        this.groupLimit = groupLimit;
    }

    public boolean isGroupNgroups() {
        return groupNgroups;
    }

    public void setGroupNgroups(boolean groupNgroups) {
        this.groupNgroups = groupNgroups;
    }

    public String getCursorMark() {
        return cursorMark;
    }

    public void setCursorMark(String cursorMark) {
        this.cursorMark = cursorMark;
    }

    public void Builder(Integer rows, Integer start, List<String> sort, String q, String fq, List<String> ptopidList,
            List<String> cc, Integer[] stat, Integer[] tc, List<String> fields, String mode, boolean defOpAnd,
            boolean stem, boolean docdb, String cursormark, boolean facet, Integer facetLimit, Integer facetOffset,
            String facetSort, String facetFieldMode, List<String> facetField, boolean group, String groupField, Integer groupLimit,
            boolean groupNgroups) {
        if (rows != null) {
            this.rows = rows;
        }

        this.cursorMark = cursormark;
        if (cursormark != null && !cursormark.isEmpty()) {
            sort.add("ptopid desc");
        }

        if (sort != null && !sort.isEmpty() && !sort.get(0).equals("")) {
            String sortStr = sort.toString().replace(".", " ");
            sortStr = sortStr.replace("[", "");
            sortStr = sortStr.replace("]", "");
            this.sort = sortStr;
        } else {
            this.sort = "";
        }

        this.cc = cc;
        if (start != null) {
            this.start = start;
        }
        if (q != null) {
            this.q = q;
        }
        if (fq != null) {
            this.fq = fq;
        }
        if (ptopidList != null) {
            this.ptopId = ptopidList;
        }
        this.defOpAnd = defOpAnd;
        this.stat = stat;
        this.tc = tc;
        if (fields != null) {
            this.field = fields.toString();
        }
        this.mode = mode;
        this.facet = facet;
        this.stem = stem;
        this.docdb = docdb;

        this.facet = facet;
        if (facet) {
            if (facetLimit != null) {
                this.facetLimit = facetLimit;
            } else {
                this.facetLimit = DEFAULT_FACETLIMIT;
            }
            if (facetOffset != null) {
                this.facetOffset = facetOffset;
            } else {
                this.facetOffset = DEFAULT_FACETOFFECT;
            }
            
            if (facetSort != null) {
                this.facetSort = facetSort;
            } else {
                this.facetSort = DEFAULT_FACETSORT;
            }
            this.facetFieldMode = facetFieldMode;
            this.facetField = facetField;
        }

        this.group = group;
        if (group) {
            this.groupField = groupField;
            if (groupLimit != null) {
                this.groupLimit = groupLimit;
            } else {
                this.groupLimit = DEFAULT_GROUPLIMIT;
            }
            this.groupNgroups = groupNgroups;
        }

    }
}
