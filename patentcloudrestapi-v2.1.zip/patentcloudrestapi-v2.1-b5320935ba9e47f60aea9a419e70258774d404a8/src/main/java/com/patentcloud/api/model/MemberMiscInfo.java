package com.patentcloud.api.model;

public class MemberMiscInfo {

    private String viewIn;
    private String fulltextUrl;

    public String getViewIn() {
        return viewIn;
    }
    public void setViewIn(String viewIn) {
        this.viewIn = viewIn;
    }

    public String getFulltextUrl() {
        return fulltextUrl;
    }
    public void setFulltextUrl(String fulltextUrl) {
        this.fulltextUrl = fulltextUrl;
    }
}
