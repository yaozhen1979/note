package com.patentcloud.api.util.http.external;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.google.gson.JsonObject;

/**
 * A immutable configuration container holds the required and optional
 * properties for Download service client. It is created by according to Builder
 * pattern.
 * 
 * @author Allan Huang
 */
public class DownloadServiceClientConfig {
    // optional parameters
    /**
     * The maximum number of total open connections.
     */
    private final int maxTotalConnection;

    /**
     * The time to establish the connection with the remote host
     */
    private final int maxConnectionTimout;

    /**
     * The time waiting for data – after the connection was established; maximum
     * time of inactivity between two data packets
     */
    private final int maxSocketTimeout;

    /**
     * The time to wait for a connection from the connection manager/pool
     */
    private final int maxConnectionRequestTimeout;

    /**
     * The proxy setting for localhost development environment
     */
    private ProxyConfig proxyConfig;

    private DownloadServiceClientConfig(Builder builder) {
        this.maxTotalConnection = builder.maxTotalConnection;
        this.maxConnectionTimout = builder.maxConnectionTimout;
        this.maxSocketTimeout = builder.maxSocketTimeout;
        this.maxConnectionRequestTimeout = builder.maxConnectionRequestTimeout;
        this.proxyConfig = builder.proxyConfig;
    }

    public int getMaxTotalConnection() {
        return maxTotalConnection;
    }

    public int getMaxConnectionTimout() {
        return maxConnectionTimout;
    }

    public int getMaxSocketTimeout() {
        return maxSocketTimeout;
    }

    public int getMaxConnectionRequestTimeout() {
        return maxConnectionRequestTimeout;
    }

    public ProxyConfig getProxyConfig() {
        return this.proxyConfig;
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("maxTotalConnection", this.maxTotalConnection)
                .append("maxConnectionTimout", this.maxConnectionTimout)
                .append("maxSocketTimeout", this.maxSocketTimeout)
                .append("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout)
                .append("proxyConfig", this.proxyConfig).build();
    }

    public static class ProxyConfig {

        private String host;

        private int port;

        private String user;

        private String password;

        public ProxyConfig(String host, int port) {
            super();
            this.host = host;
            this.port = port;
        }

        public String getHost() {
            return this.host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public int getPort() {
            return this.port;
        }

        public void setPort(int port) {
            this.port = port;
        }

        public String getUser() {
            return this.user;
        }

        public void setUser(String user) {
            this.user = user;
        }

        public String getPassword() {
            return this.password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("host", this.getHost())
                    .append("port", this.getPort()).append("user", this.user).build();
        }
    }

    public JsonObject toJsonObject() {
        JsonObject infoJson = new JsonObject();

        infoJson.addProperty("maxTotalConnection", this.maxTotalConnection);
        infoJson.addProperty("maxConnectionTimout", this.maxConnectionTimout);
        infoJson.addProperty("maxSocketTimeout", this.maxSocketTimeout);
        infoJson.addProperty("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout);

        return infoJson;
    }

    // Builder Class
    public static class Builder {

        private int maxTotalConnection;

        private int maxConnectionTimout;

        private int maxSocketTimeout;

        private int maxConnectionRequestTimeout;

        private ProxyConfig proxyConfig;

        public Builder() {
        }

        public Builder setMaxTotalConnection(int maxTotalConnection) {
            this.maxTotalConnection = maxTotalConnection;

            return this;
        }

        public Builder setMaxConnectionTimout(int maxConnectionTimout) {
            this.maxConnectionTimout = maxConnectionTimout;

            return this;
        }

        public Builder setMaxSocketTimeout(int maxSocketTimeout) {
            this.maxSocketTimeout = maxSocketTimeout;

            return this;
        }

        public Builder setMaxConnectionRequestTimeout(int maxConnectionRequestTimeout) {
            this.maxConnectionRequestTimeout = maxConnectionRequestTimeout;

            return this;
        }

        public Builder setProxyConfig(ProxyConfig proxyConfig) {
            this.proxyConfig = proxyConfig;

            return this;
        }

        public DownloadServiceClientConfig build() {
            return new DownloadServiceClientConfig(this);
        }

        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                    .append("maxTotalConnection", this.maxTotalConnection)
                    .append("maxConnectionTimout", this.maxConnectionTimout)
                    .append("maxSocketTimeout", this.maxSocketTimeout)
                    .append("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout)
                    .append("proxyConfig", this.proxyConfig).build();
        }
    }
}