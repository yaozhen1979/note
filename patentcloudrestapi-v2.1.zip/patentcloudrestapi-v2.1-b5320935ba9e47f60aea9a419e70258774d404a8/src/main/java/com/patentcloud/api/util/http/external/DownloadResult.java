package com.patentcloud.api.util.http.external;

/**
 * A container that wraps a result returned by Download service server
 * 
 * @author Allan Huang
 */
public class DownloadResult {

    private int httpStatus;

    private byte[] entityByteArray;

    private String entityContentType;

    public DownloadResult(int httpStatusCode, byte[] entityByteArray, String entityContentType) {
        this.httpStatus = httpStatusCode;
        this.entityByteArray = entityByteArray;
        this.entityContentType = entityContentType;
    }

    public int getHttpStatus() {
        return this.httpStatus;
    }

    public byte[] getEntityByteArray() {
        return entityByteArray;
    }

    public String getEntityContentType() {
        return entityContentType;
    }
}
