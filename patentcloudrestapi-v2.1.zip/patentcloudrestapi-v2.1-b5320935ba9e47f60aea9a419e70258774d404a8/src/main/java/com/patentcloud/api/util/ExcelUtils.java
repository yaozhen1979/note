package com.patentcloud.api.util;

import java.awt.Dimension;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFPicture;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.MultiLangString;
import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.model.Person;
import com.patentcloud.api.model.RelatedPatent;
import com.patentcloud.api.util.solr.PatentDataConfig;
import com.patentcloud.api.util.solr.SolrUtils;

public class ExcelUtils {

    private static final Logger log = LoggerFactory.getLogger(ExcelUtils.class);

    private static final int DEFAULT_EXCEL_FIELD_WIDTH = 4000;

    private static final HashMap<String, Integer> EXCEL_FIELD_WIDTH = new HashMap<>();

    static {
        EXCEL_FIELD_WIDTH.put("pto", 3000);
        EXCEL_FIELD_WIDTH.put("country", 3000);
        EXCEL_FIELD_WIDTH.put("agents", 9000);
        EXCEL_FIELD_WIDTH.put("appDate", 4000);
        EXCEL_FIELD_WIDTH.put("appNumber", 5000);
        EXCEL_FIELD_WIDTH.put("assignees", 9000);
        EXCEL_FIELD_WIDTH.put("decisionDate", 4000);
        EXCEL_FIELD_WIDTH.put("decisionNumber", 4000);
        EXCEL_FIELD_WIDTH.put("firstImage", 8000);
        EXCEL_FIELD_WIDTH.put("inventors", 9000);
        EXCEL_FIELD_WIDTH.put("ipcs", 4000);
        EXCEL_FIELD_WIDTH.put("locs", 4000);
        EXCEL_FIELD_WIDTH.put("openDate", 4000);
        EXCEL_FIELD_WIDTH.put("openNumber", 4000);
        EXCEL_FIELD_WIDTH.put("brief", 14000);
        EXCEL_FIELD_WIDTH.put("briefEn", 14000);
        EXCEL_FIELD_WIDTH.put("claim", 14000);
        EXCEL_FIELD_WIDTH.put("title", 8000);
        EXCEL_FIELD_WIDTH.put("titleEn", 8000);
        EXCEL_FIELD_WIDTH.put("patentNumber", 4000);
        EXCEL_FIELD_WIDTH.put("type", 4000);
        EXCEL_FIELD_WIDTH.put("uspcs", 4000);
        EXCEL_FIELD_WIDTH.put("cpcs", 4000);
        EXCEL_FIELD_WIDTH.put("fis", 6000);
        EXCEL_FIELD_WIDTH.put("relPatents", 4000);
        EXCEL_FIELD_WIDTH.put("nodePath", 8000);
        EXCEL_FIELD_WIDTH.put("docdbAssignees", 9000);
        EXCEL_FIELD_WIDTH.put("currentAssigneesName", 9000);
        EXCEL_FIELD_WIDTH.put("docdbInventors", 9000);
        EXCEL_FIELD_WIDTH.put("openDecisionNumber", 5000);
        EXCEL_FIELD_WIDTH.put("doDate", 4000);
        EXCEL_FIELD_WIDTH.put("certificateNumber", 5000);
        EXCEL_FIELD_WIDTH.put("certificateDate", 4000);
        EXCEL_FIELD_WIDTH.put("cpcs", 4000);
        EXCEL_FIELD_WIDTH.put("fullTextUrl", 5000);
        EXCEL_FIELD_WIDTH.put("priorityNumber", 4000);
        EXCEL_FIELD_WIDTH.put("priorityDate", 4000);
        EXCEL_FIELD_WIDTH.put("earliestPriorityDate", 5000);
    }

    public static HSSFWorkbook toExcelWorkbook(List<PatentInfo> patentInfoList, List<String> fieldList, Locale locale,
            String viewIn, String fulltextUrl) {
        if (patentInfoList.isEmpty() || fieldList.isEmpty()) {
            throw new IllegalArgumentException("patentInfoList or fieldList is a empty list");
        }

        log.info("Start to add a list of patentInfo into an excel workbook.");

        if (log.isInfoEnabled()) {
            StringBuilder ptopidListSb = new StringBuilder();

            for (int i = 0; i < patentInfoList.size(); i++) {
                if (i >= 1) {
                    ptopidListSb.append(',');
                }

                PatentInfo patentInfo = patentInfoList.get(i);
                ptopidListSb.append(patentInfo.getPtopid());
            }

            StringBuilder fieldListSb = new StringBuilder();

            for (int i = 0; i < fieldList.size(); i++) {
                if (i >= 1) {
                    fieldListSb.append(',');
                }

                String field = fieldList.get(i);
                fieldListSb.append(field);
            }

            log.info("Ptopid list: {},\nfield list: {}", ptopidListSb, fieldListSb);
        }

        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("Patents");
        HSSFPatriarch patriarch = sheet.createDrawingPatriarch();

        HSSFFont fontBlack10 = workbook.createFont();
        fontBlack10.setFontHeightInPoints((short) 10);
        fontBlack10.setColor(HSSFColor.BLACK.index);

        HSSFFont fontWhiteBold14 = workbook.createFont();
        fontWhiteBold14.setFontHeightInPoints((short) 14);
        fontWhiteBold14.setColor(HSSFColor.WHITE.index);
        fontWhiteBold14.setBoldweight((short) 2);

        HSSFPalette palette = workbook.getCustomPalette();
        palette.setColorAtIndex(HSSFColor.VIOLET.index, (byte) 0x62, (byte) 0xc3, (byte) 0xd0);

        HSSFCellStyle styleTitle = workbook.createCellStyle();
        styleTitle.setFillForegroundColor(HSSFColor.VIOLET.index);
        styleTitle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        styleTitle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
        styleTitle.setFont(fontWhiteBold14);
        styleTitle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        HSSFCellStyle styleRowBase = workbook.createCellStyle();
        styleRowBase.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
        styleRowBase.setFont(fontBlack10);
        styleRowBase.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        styleRowBase.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        styleRowBase.setWrapText(true);
        styleRowBase.setTopBorderColor(HSSFColor.GREY_40_PERCENT.index);
        styleRowBase.setBottomBorderColor(HSSFColor.GREY_40_PERCENT.index);
        styleRowBase.setLeftBorderColor(HSSFColor.GREY_40_PERCENT.index);
        styleRowBase.setRightBorderColor(HSSFColor.GREY_40_PERCENT.index);
        styleRowBase.setBorderTop(HSSFCellStyle.BORDER_THIN);
        styleRowBase.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        styleRowBase.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        styleRowBase.setBorderRight(HSSFCellStyle.BORDER_THIN);

        HSSFCellStyle styleRowOdd = workbook.createCellStyle();
        styleRowOdd.cloneStyleFrom(styleRowBase);
        styleRowOdd.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);

        HSSFCellStyle styleRowEven = workbook.createCellStyle();
        styleRowEven.cloneStyleFrom(styleRowBase);
        styleRowEven.setFillForegroundColor(HSSFColor.WHITE.index);

        HSSFCellStyle styleRowOddAlignLeft = workbook.createCellStyle();
        styleRowOddAlignLeft.cloneStyleFrom(styleRowOdd);
        styleRowOddAlignLeft.setAlignment(HSSFCellStyle.ALIGN_LEFT);

        HSSFCellStyle styleRowEvenAlignLeft = workbook.createCellStyle();
        styleRowEvenAlignLeft.cloneStyleFrom(styleRowEven);
        styleRowEvenAlignLeft.setAlignment(HSSFCellStyle.ALIGN_LEFT);

        int rowCount = 0;
        HSSFRow row = sheet.createRow(rowCount);
        row.setHeight((short) 500);

        int colnum = 0;
        for (String field : fieldList) {
            Integer excelFieldWidthInt = EXCEL_FIELD_WIDTH.get(field);
            if (excelFieldWidthInt == null) {
                excelFieldWidthInt = DEFAULT_EXCEL_FIELD_WIDTH;
                log.warn("Cannot find the width of the field. field: {}", field);
            }
            sheet.setColumnWidth(colnum, excelFieldWidthInt);

            HSSFCell cell = row.createCell(colnum);
            cell.setCellStyle(styleTitle);
            cell.setCellValue(LanguageProperties.get(locale, field));

            colnum++;
        }

        // find all of fields of PatentInfo class and avoid that visit
        // PatentInfo class repeatly by reflection API.
        Map<String, Field> patentInfoClassFieldMap = new HashMap<>();
        List<Field> classFieldList = FieldUtils.getAllFieldsList(PatentInfo.class);
        for (Field classField : classFieldList) {
            String classFieldName = classField.getName();
            patentInfoClassFieldMap.put(classFieldName, classField);
        }

        for (PatentInfo patentInfo : patentInfoList) {
            rowCount++;
            addPatentInfo(workbook, sheet, patriarch, styleRowOdd, styleRowEven, styleRowOddAlignLeft,
                    styleRowEvenAlignLeft, rowCount, fieldList, patentInfo, patentInfoClassFieldMap, viewIn,
                    fulltextUrl);

            log.debug("Add a patentInfo into an excel. ptopid: {}", patentInfo.getPtopid());
        }

        log.info("Finish to add a list of patentInfo into an excel. workbook length: {}", workbook.getBytes().length);

        return workbook;
    }

    private static void addPatentInfo(HSSFWorkbook workbook, HSSFSheet sheet, HSSFPatriarch patriarch,
            HSSFCellStyle styleRowOdd, HSSFCellStyle styleRowEven, HSSFCellStyle styleRowOddAlignLeft,
            HSSFCellStyle styleRowEvenAlignLeft, int rowCount, List<String> fieldList, PatentInfo patentInfo,
            Map<String, Field> patentInfoClassFieldMap, String viewIn, String fulltextUrl) {
        HSSFRow row = sheet.createRow(rowCount);
        rowCount++;

        short rowHeight = (short) (fieldList.contains("") ? 3200 : 1200);
        row.setHeight(rowHeight);

        int rowNumber = rowCount - 1;
        int colnum = 0;

        String pto = toCellValueString(patentInfo.pto);
        Set<String> excelFieldAlignLeft = new HashSet<>();

        for (String field : fieldList) {
            // set the cell style of a field
            HSSFCell cell = row.createCell(colnum);
            if (excelFieldAlignLeft.contains(field)) {
                if (rowCount % 2 == 0) {
                    cell.setCellStyle(styleRowEvenAlignLeft);
                } else {
                    cell.setCellStyle(styleRowOddAlignLeft);
                }
            } else {
                if (rowCount % 2 == 0) {
                    cell.setCellStyle(styleRowEven);
                } else {
                    cell.setCellStyle(styleRowOdd);
                }
            }

            // process firstImage field
            if (field.equalsIgnoreCase("firstImage")) {
                if ("DOCDB".equalsIgnoreCase(pto)) {
                    cell.setCellValue("");
                    colnum++;
                    continue;
                }
                Object objValue = getFirstImageData(patentInfo);

                if (objValue != null) {
                    int cellw = 1023;
                    int cellh = 255;
                    int padleft = 10;
                    int padtop = 3;
                    int picw = cellw - (padleft * 2);
                    int pich = cellh - (padtop * 2);

                    HSSFClientAnchor anchor = new HSSFClientAnchor(0, 0, cellw, cellh, (short) colnum, rowNumber,
                            (short) colnum, rowNumber);
                    HSSFPicture pic = patriarch.createPicture(anchor,
                            workbook.addPicture((byte[]) objValue, HSSFWorkbook.PICTURE_TYPE_PNG));

                    Dimension picdim = pic.getImageDimension();
                    double picexw = picdim.width;
                    double picexh = (double) picdim.height / cellw * cellh;
                    double adjw = (double) picw / picexw;
                    double adjh = (double) pich / picexh;
                    double adj = (adjw < adjh) ? adjw : adjh;
                    double picadjw = picexw * adj;
                    double picadjh = picexh * adj;
                    padleft = (int) ((cellw - picadjw) / 2);
                    padtop = (int) ((cellh - picadjh) / 2);
                    anchor.setAnchor((short) colnum, rowNumber, padleft, padtop, (short) colnum, rowNumber,
                            (int) (padleft + picadjw), (int) (padtop + picadjh));
                }

                colnum++;
                continue;
            }

            // process fullTextUrl field
            if (field.equalsIgnoreCase("fullTextUrl")) {
                if (StringUtils.isNotBlank(patentInfo.ptopid)) {
                    fulltextUrl = String.format(fulltextUrl, patentInfo.ptopid);
                } else {
                    fulltextUrl = String.format(fulltextUrl,
                            patentInfo.pto.toString() + "." + patentInfo.id.toString());
                }

                HSSFHyperlink link = new HSSFHyperlink(HSSFHyperlink.LINK_URL);
                link.setAddress(fulltextUrl);
                cell.setCellValue("view in " + viewIn);
                cell.setHyperlink(link);

                colnum++;
                continue;
            }

            // process other fields
            Object objValue = null;

            if ("pto".equalsIgnoreCase(field)) {
                objValue = patentInfo.country;

            } else if ("title".equalsIgnoreCase(field) || "titleEn".equalsIgnoreCase(field)) {
                objValue = patentInfo.titleVO;

            } else if ("brief".equalsIgnoreCase(field) || "briefEn".equalsIgnoreCase(field)) {
                objValue = patentInfo.briefVO;

            } else if ("assignees".equalsIgnoreCase(field)) {
                if (patentInfo.assigneeVOs != null && patentInfo.assigneeVOs.size() > 0) {
                    objValue = patentInfo.assigneeVOs;
                } else {
                    objValue = patentInfo.docdbAssigneeVOs;
                }
            } else if ("inventors".equalsIgnoreCase(field)) {
                if (patentInfo.inventorVOs != null && patentInfo.inventorVOs.size() > 0) {
                    objValue = patentInfo.inventorVOs;
                } else {
                    objValue = patentInfo.docdbInventorVOs;
                }
            } else if ("agents".equalsIgnoreCase(field)) {
                objValue = patentInfo.agentVOs;

            } else if ("docdbAssignees".equalsIgnoreCase(field)) {
                objValue = patentInfo.docdbAssigneeVOs;

            } else if ("docdbInventors".equalsIgnoreCase(field)) {
                objValue = patentInfo.docdbInventorVOs;

            } else if ("priorityNumber".equalsIgnoreCase(field) || "priorityDate".equalsIgnoreCase(field)
                    || "earliestPriorityDate".equalsIgnoreCase(field)) {
                objValue = toPriorityCell(patentInfo.priorityPatentVOs, field);

            } else if ("currentAssigneesName".equalsIgnoreCase(field)) {
                objValue = patentInfo.currentAssigneesNameVOs;

            } else {
                Field classField = patentInfoClassFieldMap.get(field);
                if (classField != null) {
                    try {
                        objValue = classField.get(patentInfo);

                    } catch (IllegalArgumentException | IllegalAccessException e) {
                        log.warn("Failed to export an excel. ptopid: {}, field: {}", patentInfo.getPtopid(), field);

                        colnum++;
                        continue;
                    }
                } else {
                    log.warn("Cannot find the specified field. ptopid: {}, field: {}", patentInfo.getPtopid(), field);

                    colnum++;
                    continue;
                }
            }

            // successfully find the specified field and get its value
            String cellValue = "";

            if (("titleEn".equalsIgnoreCase(field) && !(patentInfo.pto.equals("USPTO") || patentInfo.pto.equals("WIPO")
                    || patentInfo.pto.equals("EPO")))
                    || ("briefEn".equalsIgnoreCase(field) && !(patentInfo.pto.equals("USPTO")
                            || patentInfo.pto.equals("WIPO") || patentInfo.pto.equals("EPO")))) {
                cellValue = toEnCellValueString(objValue);
            } else {
                cellValue = toCellValueString(objValue);
            }

            if (field.contains("nventor") || "agents".equalsIgnoreCase(field) || field.contains("brief")
                    || "claim".equalsIgnoreCase(field) || field.contains("title") 
                    || field.contains("assignees")) {
                cellValue = exportExcelStringFilter(cellValue);
            }
            cell.setCellValue(cellValue);

            colnum++;
        }
    }

    /**
     * <ul>
     * <li>1. filter HTML tags, ex. "<p ...>...</p>" in abstract.
     * <li>2. tranform the HTML character entities into normal character, ex.
     * "&#x26;" -> "&", "&lt;" -> "<".
     * </ul>
     * 
     * @param cellValue
     * 
     * @return
     */
    private static String exportExcelStringFilter(String cellValue) {
        if (cellValue == null) {
            return "";
        }
        String cellValueFiltered = StringEscapeUtils.unescapeHtml4(cellValue.replaceAll("<[^>]*>", ""))
                .replace("&angst;", "A");
        return cellValueFiltered;
    }

    private static String toEnCellValueString(Object objValue) {
        if (objValue == null) {
            return "";
        }
        if (objValue instanceof MultiLangString) {// titleVO en, briefVO en
            MultiLangString multiLang = (MultiLangString) objValue;
            return toEnCellValueString(multiLang.en);
        }
        return objValue.toString();
    }

    private static Object toPriorityCell(Object objValue, String priorityType) {
        @SuppressWarnings("unchecked")
        List<RelatedPatent> prioritys = (List<RelatedPatent>) objValue;

        if ("priorityNumber".equalsIgnoreCase(priorityType)) {
            List<String> priorityNumbers = new ArrayList<>();
            for (RelatedPatent priority : prioritys) {
                String fullPriorityNumber = String.format("%s%s%s", priority.pto != null ? priority.pto : "",
                        priority.patentNumber != null ? priority.patentNumber : "",
                        priority.kindcode != null ? priority.kindcode : "");
                priorityNumbers.add(fullPriorityNumber);
            }

            return (Object) priorityNumbers;

        } else if ("priorityDate".equalsIgnoreCase(priorityType)) {
            List<Date> priorityDates = new ArrayList<>();
            for (RelatedPatent priority : prioritys) {
                priorityDates.add(priority.doDate);
            }

            return (Object) priorityDates;

        } else if ("earliestPriorityDate".equalsIgnoreCase(priorityType)) {
            List<Date> priorityDates = new ArrayList<>();
            for (RelatedPatent priority : prioritys) {
                priorityDates.add(priority.doDate);
            }
            Collections.sort(priorityDates);

            return priorityDates.get(0);
        }
        return null;
    }

    private static String toCellValueString(Object objValue) {
        if (objValue == null) {
            return "";
        }
        if (objValue instanceof Date) {
            DateFormat fmtDate = new SimpleDateFormat("yyyy-MM-dd");
            Date date = (Date) objValue;
            return fmtDate.format(date);
        }
        if (objValue instanceof Person) {
            Person person = (Person) objValue;
            return toCellValueString(person.name);
        }

        if (objValue instanceof MultiLangString) { // titleVO
            MultiLangString multiLang = (MultiLangString) objValue;
            // return toCellValueString(multiLang.origin);
            return toCellValueString(multiLang.toString()); // origin -> en ->
            // ...
        }

        if (objValue instanceof List) {
            StringBuilder sb = new StringBuilder();
            @SuppressWarnings("unchecked")
            List<Object> list = (List<Object>) objValue;
            for (Object obj : list) {
                if (sb.length() > 0) {
                    sb.append(";\r\n");
                }
                sb.append(toCellValueString(obj));
            }
            return sb.toString();
        }
        return objValue.toString();
    }

    private static byte[] getFirstImageData(PatentInfo patentInfo) {
        String patentDataPath = SolrUtils.getPatentDataPath(patentInfo);

        PatentPath patentPath = new PatentPath(patentInfo);
        List<File> cachePathList = PatentDataConfig.CACHE_PATH_PTO.get(patentInfo.ptoVO);
        List<File> dataPathList = PatentDataConfig.DATA_PATH_PTO.get(patentInfo.ptoVO);

        for (File file : cachePathList) {
            patentPath.paths.add(file.toPath().resolve(patentDataPath));
        }
        for (File file : dataPathList) {
            patentPath.paths.add(file.toPath().resolve(patentDataPath));
        }

        PatentFile patentFile = null;
        try {
            patentFile = ImageUtils.getFirstImage(patentPath);

            if (!patentFile.file.exists()) {
                log.warn("Failed to find the first image of a patent. patentDataPath: {}", patentDataPath);
            }
        } catch (IOException e) {
            log.warn("Failed to find the first image of a patent. patentDataPath: {}", patentDataPath);
        }

        FileInputStream input = null;
        byte[] byteArray = null;

        try {
            input = new FileInputStream(patentFile.getFile());
            byteArray = IOUtils.toByteArray(input);

        } catch (IOException e) {
            log.warn("Failed to find the first image of a patent. patentDataPath: {}", patentDataPath);

        } finally {
            IOUtils.closeQuietly(input);
        }

        return byteArray;
    }
}
