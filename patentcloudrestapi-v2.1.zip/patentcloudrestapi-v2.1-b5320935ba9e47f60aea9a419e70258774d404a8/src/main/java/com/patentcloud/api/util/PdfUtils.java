package com.patentcloud.api.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Image;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.patentcloud.api.exception.PatentDataException;
import com.patentcloud.api.exception.PatentFileNotFoundException;
import com.patentcloud.api.model.PatentFile;

public class PdfUtils {

    private static final Logger log = LoggerFactory.getLogger(PdfUtils.class);

    public static void addImageToPdfbyIText(Document pdfdoc, Path imagepath, Rectangle rect)
            throws DocumentException, MalformedURLException, IOException {
        String lowname = imagepath.toString().toLowerCase();
        Image img = Image.getInstance(lowname);
        img.scaleToFit(rect.getWidth() - 10, rect.getHeight() - 10);
        pdfdoc.newPage();
        pdfdoc.add(img);
    }

    public static void mergeFirstPagesAsPdf(List<File> pdfFileList, OutputStream output)
            throws PatentFileNotFoundException {
        List<String> damagedPathList = new ArrayList<>();
        PdfWriter pdfWriter = null;
        Document pdfDoc = new Document();
        int totalPage = 0;

        try {
            pdfWriter = PdfWriter.getInstance(pdfDoc, output);
            pdfDoc.open();

            for (File pdfFile : pdfFileList) {
                if (!pdfFile.exists()) {
                    String filePath = pdfFile.getAbsolutePath();
                    damagedPathList.add(filePath);

                    log.warn("The specified image/PDF file is not existed. file path: {}", filePath);
                    continue;
                }

                FileInputStream pdfInput = null;
                PdfReader pdfReader = null;

                try {
                    pdfInput = new FileInputStream(pdfFile);
                    pdfReader = new PdfReader(pdfInput);

                    boolean added = pdfDoc.newPage();
                    if (added) {
                        PdfImportedPage firstpage = pdfWriter.getImportedPage(pdfReader, 1);
                        PdfContentByte directContent = pdfWriter.getDirectContent();
                        directContent.addTemplate(firstpage, 0, 0);
                        pdfWriter.flush();
                    }
                } catch (IOException e) {
                    log.error("Failed to add the first page of a PDF file to another PDF document.", e);

                } finally {
                    IOUtils.closeQuietly(pdfInput);

                    if (pdfReader != null) {
                        try {
                            pdfReader.close();

                        } catch (ExceptionConverter e) {
                            // just log an error message and avoid that throw a
                            // runtime exception from iText.
                            log.warn("Failed to close a PDF reader.", e);
                        }
                    }
                }
            }

            totalPage = pdfDoc.getPageNumber();

        } catch (DocumentException e) {
            throw new PatentDataException("Failed to get an instance of the PdfWriter.", e);

        } finally {
            pdfDoc.close();

            if (pdfWriter != null) {
                try {
                    pdfWriter.close();

                } catch (ExceptionConverter e) {
                    // just log an error message and avoid that throw a runtime
                    // exception from iText.
                    log.warn("Failed to close a PDF writer.", e);
                }
            }
        }

        if (totalPage == 0) {
            throw new PatentFileNotFoundException("The specified image/PDF file is not existed.")
                    .addContextValue("DamagedPathList", damagedPathList);
        }
    }

    /**
     * split first page of fullpdf
     * 
     * @param patentFile
     * 
     * @throws IOException
     */
    public static void splitFirstPagePdf(PatentFile patentFile) throws IOException {
        if (!patentFile.file.exists()) {
            return;
        }
        // get cache file
        File cacheFile = FileUtils.getCacheFile(patentFile, Paths.get("firstPage.pdf"));

        FileUtils.sureFileExists(cacheFile.getParentFile(), false);

        PDDocument fullPagePdfDoc = null;
        PDDocument firstPagePdfDoc = null;

        try {
            fullPagePdfDoc = PDDocument.load(patentFile.getFile().getAbsolutePath());
            List<PDDocument> pdfDocList = new Splitter().split(fullPagePdfDoc);
            firstPagePdfDoc = pdfDocList.listIterator().next();
            firstPagePdfDoc.save(cacheFile);

        } catch (COSVisitorException e) {
            String patentFilePath = patentFile.getFile().getAbsolutePath();
            log.warn("Failed to save the new first page to a cached file. file path: {}", patentFilePath, e);

        } finally {
            IOUtils.closeQuietly(fullPagePdfDoc);
            IOUtils.closeQuietly(firstPagePdfDoc);
        }
    }

    public static int countPdfPage(String pdfFilePath) {
        int count = 0;

        PDDocument pdfDoc = null;
        try {
            pdfDoc = PDDocument.load(new File(pdfFilePath));
            count = pdfDoc.getNumberOfPages();

        } catch (IOException e) {
            log.error("Failed to count the number of a PDF page. pdfFilePath: {}", pdfFilePath, e);

        } finally {
            IOUtils.closeQuietly(pdfDoc);
        }

        return count;
    }
}
