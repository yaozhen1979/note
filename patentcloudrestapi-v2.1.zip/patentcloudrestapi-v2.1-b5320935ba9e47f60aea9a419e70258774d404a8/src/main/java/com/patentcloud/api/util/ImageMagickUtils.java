package com.patentcloud.api.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.poi.util.IOUtils;
import org.apache.sanselan.ImageInfo;
import org.apache.sanselan.ImageReadException;
import org.apache.sanselan.Sanselan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.model.PatentFile;

public class ImageMagickUtils {

    private static final Logger log = LoggerFactory.getLogger(ImageMagickUtils.class);

    private static boolean executeCommand(List<String> command) {
        log.info("Prepare to execute a ImageMagick command. command: {}", command);

        boolean successful = false;

        BufferedReader messageReader = null;
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(command);
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            messageReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String message = messageReader.readLine();

            if (StringUtils.isBlank(message)) {
                successful = true;
            } else {
                successful = false;
                do {
                    log.warn("ImageMagick leave a message: {}", message);
                    message = messageReader.readLine();

                } while (StringUtils.isNotBlank(message));
            }
        } catch (IOException e) {
            log.error("Failed to execute a ImageMagick command. command: {}", command, e);

        } finally {
            IOUtils.closeQuietly(messageReader);
        }

        return successful;
    }

    /**
     * Convert a PDF/TIF file to a PNG image by a specified number of a page.
     * 
     * @param patentFile
     * @param filePath
     *            relative to patent directory, like: "fullImage/1.png"
     * @throws IOException
     */
    public static void cachePatentImage2Png(PatentFile patentFile, Path filePath) throws IOException {
        File physicalFile = patentFile.getFile();
        if (!physicalFile.exists()) {
            return;
        }

        if (patentFile.getMimeType().equalsIgnoreCase("image/png")) {
            return;
        }

        File cacheFile = FileUtils.getCacheFile(patentFile, filePath);
        FileUtils.sureFileExists(cacheFile, true);

        if (cacheFile.exists()) {
            patentFile.setFile(cacheFile);
            patentFile.setMimeType("image/png");
            return;
        }

        // build a ImageMagick command line and execute it
        List<String> command = new ArrayList<>();

        if (SystemUtils.IS_OS_WINDOWS) {
            command.add("cmd.exe");
            command.add("/C");
        } else {
            command.add("sudo");
        }

        command.add("convert");
        // Refer to
        // http://www.imagemagick.org/script/command-line-options.php#limit
        command.add("-limit");
        command.add("memory");
        command.add("256MiB");
        command.add("-limit");
        command.add("map");
        command.add("512MiB");

        command.add(physicalFile.getAbsolutePath());
        command.add(cacheFile.getAbsolutePath());

        boolean successful = executeCommand(command);

        if (successful) {
            patentFile.setFile(cacheFile);
            patentFile.setMimeType("image/png");
        }
    }

    /**
     * Convert a PDF file to a PNG file as thumbnail.
     * 
     * @param patentFile
     * @param filePath
     *            relative to patent directory, like: "fullImage/1.png"
     * @param maxWidth
     *            the max width of an outputted thumbnail
     * @param maxHeight
     *            the max height of an outputted thumbnail
     * @throws IOException
     */
    public static void cacheAndResizePatentImage2Png(PatentFile patentFile, Path filePath, int maxWidth, int maxHeight)
            throws IOException {
        File physicalFile = patentFile.getFile();
        if (!physicalFile.exists()) {
            return;
        }

        try {
            ImageInfo imageInfo = Sanselan.getImageInfo(physicalFile);
            int width = imageInfo.getWidth();
            int height = imageInfo.getHeight();
            log.debug("Get an ImageInfo. image width: {}, height: {}, mimeType: {}", imageInfo.getWidth(),
                    imageInfo.getHeight(), imageInfo.getMimeType());

            if (patentFile.getMimeType().equalsIgnoreCase("image/png") && width <= maxWidth && height <= maxHeight) {
                return;
            }
        } catch (ImageReadException e) {
            log.warn("Failed to get an ImageInfo. file path: {}", physicalFile.getAbsolutePath(), e);
        }

        File cacheFile = FileUtils.getCacheFile(patentFile, filePath);
        FileUtils.sureFileExists(cacheFile, true);

        if (cacheFile.exists()) {
            patentFile.setFile(cacheFile);
            patentFile.setMimeType("image/png");
            return;
        }

        List<String> command = new ArrayList<>();
        if (SystemUtils.IS_OS_WINDOWS) {
            command.add("cmd.exe");
            command.add("/C");
        } else {
            command.add("sudo");
        }

        // the command example as follows: convert -thumbnail 250X250 -limit
        // memory 256MiB -limit map 512MiB
        command.add("convert");
        command.add("-thumbnail");
        command.add(maxWidth + "X" + maxHeight);
        // Refer to
        // http://www.imagemagick.org/script/command-line-options.php#limit
        command.add("-limit");
        command.add("memory");
        command.add("256MiB");
        command.add("-limit");
        command.add("map");
        command.add("512MiB");

        command.add(physicalFile.getAbsolutePath());
        command.add(cacheFile.getAbsolutePath());

        boolean successful = executeCommand(command);

        if (successful) {
            patentFile.setFile(cacheFile);
            patentFile.setMimeType("image/png");
        }
    }

    /**
     * @deprecated use {@link org.apache.sanselan.Sanselan#getImageInfo(File)}
     *             instead.
     */
    @Deprecated
    private static int[] getImageSize(String imagePath) {
        // read the size of an image via ImageMagick
        List<String> command = new ArrayList<>();
        if (SystemUtils.IS_OS_WINDOWS) {
            command.add("cmd.exe");
            command.add("/C");
        } else {
            command.add("sudo");
        }
        command.add("identify");
        command.add(imagePath);

        log.info("Prepare to execute a ImageMagick command. command: {}", command);

        int[] imageSize = new int[2];

        BufferedReader messageReader = null;
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(command);
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            messageReader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line = messageReader.readLine();
            if (line != null) {
                String[] sizestr = line.split(" ")[2].split("x");
                imageSize[0] = Integer.parseInt(sizestr[0]);
                imageSize[1] = Integer.parseInt(sizestr[1]);
            }
        } catch (IOException e) {
            log.error("Failed to execute a ImageMagick command. command: {}", command, e);

        } finally {
            IOUtils.closeQuietly(messageReader);
        }

        return imageSize;
    }

    /**
     * Split a PDF file and convert it to a PNG file by assigning a number of a
     * page.
     * 
     * @param patentFile
     * @param pageNumber
     * @throws IOException
     */
    public static void splitPdfToImage(PatentFile patentFile, int pageNumber) throws IOException {
        File physicalFile = patentFile.getFile();
        if (!physicalFile.exists()) {
            return;
        }

        File outputDir = FileUtils.getCacheFile(patentFile, Paths.get("fullimage"));
        FileUtils.sureFileExists(outputDir, false);

        List<String> command = new ArrayList<>();
        if (SystemUtils.IS_OS_WINDOWS) {
            command.add("cmd.exe");
            command.add("/C");
        } else {
            command.add("sudo");
        }

        // the command example as follows: convert -density 400 -resize 25%
        // -limit
        // memory 256MiB -limit map 512MiB
        command.add("convert");
        command.add("-density");
        command.add("400");
        command.add("-resize");
        command.add("25%");
        // Refer to
        // http://www.imagemagick.org/script/command-line-options.php#limit
        command.add("-limit");
        command.add("memory");
        command.add("256MiB");
        command.add("-limit");
        command.add("map");
        command.add("512MiB");

        command.add(physicalFile.getAbsolutePath() + "[" + (pageNumber - 1) + "]");
        command.add(outputDir.getAbsolutePath() + File.separator + pageNumber + ".png");

        executeCommand(command);
    }
}
