package com.patentcloud.api.server.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.patentcloud.api.model.Member;
import com.patentcloud.api.server.dao.common.AbstractDaoSupport;
import com.patentcloud.api.server.dao.mapper.MemberRowMapper;

public class MemberDaoImpl extends AbstractDaoSupport implements MemberDao {

    @Override
    public Member getMemberInfo(String account) {
        JdbcTemplate jdbcTemplate = super.getJdbcTemplate();
        String sql = "SELECT * FROM Member WHERE Account = ?";
        Member memberInfo = (Member) jdbcTemplate.queryForObject(sql, new Object[] { account }, new MemberRowMapper());
        return memberInfo;
    }
}
