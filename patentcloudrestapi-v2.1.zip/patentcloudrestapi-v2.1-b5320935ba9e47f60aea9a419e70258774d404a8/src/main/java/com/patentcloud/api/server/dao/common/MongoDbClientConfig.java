package com.patentcloud.api.server.dao.common;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.patentcloud.api.util.EncrypUtil;

/**
 * A immutable configuration container holds the required and optional
 * properties for API service client. It is created by according to Builder
 * pattern.
 * 
 * @author Allan Huang
 */
public class MongoDbClientConfig {
    // required parameters
    /**
     * The host / IP of MongoDB server
     */
    private final String mongoDbHost;

    /**
     * The port number that MongoDB server listens on
     */
    private final int mongoDbPort;

    /**
     * The name of thespecified MongoDB database
     */
    private final String mongoDbName;

    /**
     * The user's name for the specified MongoDB server usage
     */
    private final String userName;

    /**
     * The password for the specified MongoDB server usage
     */
    private final String password;

    private MongoDbClientConfig(Builder builder) {
        this.mongoDbHost = builder.mongoDbHost;
        this.mongoDbPort = builder.mongoDbPort;
        this.mongoDbName = builder.mongoDbName;
        this.userName = builder.userName;
        this.password = builder.password;
    }

    public String getMongoDbHost() {
        return mongoDbHost;
    }

    public int getMongoDbPort() {
        return mongoDbPort;
    }

    public String getMongoDbName() {
        return mongoDbName;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("mongoDbHost", this.mongoDbHost)
                .append("mongoDbPort", this.mongoDbPort).append("mongoDbName", this.mongoDbName)
                .append("userName", this.userName).append("password", EncrypUtil.maskPassword(this.password)).build();
    }

    public final JsonElement toJsonObject() {
        JsonObject clientConfigJson = new JsonObject();
        clientConfigJson.addProperty("mongoDbHost", this.mongoDbHost);
        clientConfigJson.addProperty("mongoDbPort", this.mongoDbPort);
        clientConfigJson.addProperty("mongoDbNamed", this.mongoDbName);
        clientConfigJson.addProperty("userName", this.userName);

        return clientConfigJson;
    }

    // Builder Class
    public static class Builder {

        private String mongoDbHost;

        private int mongoDbPort;

        private String mongoDbName;

        private String userName;

        private String password;

        public Builder(String mongoDbHost, int mongoDbPort, String mongoDbName, String userName, String password) {
            this.mongoDbHost = mongoDbHost;
            this.mongoDbPort = mongoDbPort;
            this.mongoDbName = mongoDbName;
            this.userName = userName;
            this.password = password;
        }

        public Builder setMongoDbHost(String mongoDbHost) {
            this.mongoDbHost = mongoDbHost;

            return this;
        }

        public Builder setMongoDbPort(int mongoDbPort) {
            this.mongoDbPort = mongoDbPort;

            return this;
        }

        public Builder setMongoDbName(String mongoDbName) {
            this.mongoDbName = mongoDbName;

            return this;
        }

        public Builder setUserName(String userName) {
            this.userName = userName;

            return this;
        }

        public MongoDbClientConfig build() {
            if (StringUtils.isBlank(this.mongoDbHost)) {
                throw new IllegalStateException("apiServiceUrl is blank.");
            }

            if (this.mongoDbPort <= 0) {
                throw new IllegalStateException("mongoDbPort is negative");
            }

            if (StringUtils.isBlank(this.mongoDbName)) {
                throw new IllegalStateException("mongoDbName is blank");
            }

            if (StringUtils.isBlank(this.userName)) {
                throw new IllegalStateException("userName is blank");
            }

            if (StringUtils.isBlank(this.password)) {
                throw new IllegalStateException("password is blank");
            }

            return new MongoDbClientConfig(this);
        }

        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("mongoDbHost", this.mongoDbHost)
                    .append("mongoDbPort", this.mongoDbPort).append("mongoDbName", this.mongoDbName)
                    .append("userName", this.userName).append("password", EncrypUtil.maskPassword(this.password))
                    .build();
        }
    }
}