package com.patentcloud.api.server.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.google.gson.Gson;
import com.patentcloud.api.model.Member;
import com.patentcloud.api.model.MemberMiscInfo;
import com.patentcloud.api.model.MemberPrivilege;

public class MemberRowMapper implements RowMapper<Member> {

    public Member mapRow(ResultSet rs, int index) throws SQLException {
        Member mem = new Member();

        mem.setId(rs.getString("ID"));
        mem.setAccount(rs.getString("Account"));
        mem.setCompany(rs.getString("Company"));
        mem.setEmail(rs.getString("Email"));
        mem.setFirstName(rs.getString("FirstName"));
        mem.setLastName(rs.getString("LastName"));
        mem.setPassword(rs.getString("Password"));
        mem.setTelephone(rs.getString("Telephone"));
        mem.setTelephoneCountryCode(rs.getString("TelephoneCountryCode"));
        mem.setTelephoneExt(rs.getString("TelephoneExt"));

        String privilege = rs.getString("Privilege");
        mem.setPrivilege(privilege != null ? new MemberPrivilege(privilege.split(",")) : new MemberPrivilege());

        String miscInfo = rs.getString("MiscInfo");
        mem.setMiscInfo(miscInfo != null ? new Gson().fromJson(miscInfo, MemberMiscInfo.class) : new MemberMiscInfo());

        return mem;
    }
}
