package com.patentcloud.api.util.http;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.pool.PoolStats;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.patentcloud.api.util.config.ConfigProperties;

/**
 * A HTTP-based Solr service client
 * 
 * @author Allan Huang
 */
public class SolrServiceClient {

    private static final Logger log = LoggerFactory.getLogger(SolrServiceClient.class);

    private static int MAX_RETRY_COUNT = 3;

    private static final String USER_AGENT = "PatentcloudSolrServiceClient/1.0";

    private static final SolrServiceClient INSTANCE = new SolrServiceClient();

    public static SolrServiceClient getInstance() {
        return INSTANCE;
    }

    private SolrServiceClient() {
        super();
    }

    /**
     * A HTTP-based client is responsible for accessing remote Solr server.
     */
    private CloseableHttpClient httpClient;

    /**
     * Getter method for field 'httpClient'
     * 
     * @return httpClient
     */
    public HttpClient getHttpClient() {
        return this.httpClient;
    }

    /**
     * A connection manager is responsible for provioding the pooled HTTP
     * connections.
     */
    private PoolingHttpClientConnectionManager connectionManager;

    /**
     * A single scheduled thread is responsible for monitoring the status of the
     * connection pool in the connection manager.
     */
    private ScheduledExecutorService connectionMonitor;

    /**
     * A configuration of Solr service client
     */
    private SolrServiceClientConfig clientConfig;

    /**
     * The host of Solr service client
     */
    private String host;

    /**
     * Start up a Solr service client
     */
    public final void startUp() {
        synchronized (this) {
            if (this.httpClient != null) {
                return;
            }
        }

        log.info("Start to start up a Solr service client...");

        try {
            InetAddress hostIp = InetAddress.getLocalHost();
            this.host = hostIp.toString();

        } catch (UnknownHostException e) {
            SolrServiceException exception = new SolrServiceException("Failed to get this client's Hostname/IP.", e);

            throw exception;
        }

        this.clientConfig = ConfigProperties.getInstance().getSolrServiceClientConfig();
        log.info("Solr service client config: {}", this.clientConfig);

        // configure a custom http client builder
        HttpClientBuilder clientBuilder = HttpClients.custom();

        // add a set of default http header
        clientBuilder.setUserAgent(USER_AGENT);

        Header acceptCharsetHeader = new BasicHeader(HttpHeaders.ACCEPT_CHARSET, Consts.UTF_8.name());

        List<Header> headerList = new ArrayList<>();
        headerList.add(acceptCharsetHeader);
        // don't add Accept-Encoding header because content decompression is
        // enabled automatically.
        clientBuilder.setDefaultHeaders(headerList);

        // Refer to http://www.baeldung.com/httpclient-connection-management
        this.connectionManager = new PoolingHttpClientConnectionManager();
        this.connectionManager.setMaxTotal(this.clientConfig.getMaxTotalConnection());
        this.connectionManager.setDefaultMaxPerRoute(this.clientConfig.getMaxTotalConnection());

        clientBuilder.setConnectionManager(this.connectionManager);

        // Refer to http://www.baeldung.com/httpclient-timeout
        // create a custom request configuration, e.g. configure timeout
        // parameters, ignore all cookies, etc.
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(this.clientConfig.getMaxConnectionTimout())
                .setSocketTimeout(this.clientConfig.getMaxSocketTimeout())
                .setConnectionRequestTimeout(this.clientConfig.getMaxConnectionRequestTimeout())
                .setCookieSpec(CookieSpecs.IGNORE_COOKIES).setExpectContinueEnabled(false).build();

        clientBuilder.setDefaultRequestConfig(requestConfig).disableCookieManagement();

        // use default retry handler
        clientBuilder.setRetryHandler(new DefaultHttpRequestRetryHandler(MAX_RETRY_COUNT, false));

        // create an HttpClient with the given custom dependencies and
        // configuration.
        this.httpClient = clientBuilder.build();

        this.connectionMonitor = Executors.newSingleThreadScheduledExecutor();
        this.connectionMonitor.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                PoolStats poolStats = connectionManager.getTotalStats();
                if (poolStats.getLeased() + poolStats.getPending() > poolStats.getMax()) {
                    log.warn("It's not enough HTTP connection in Solr service client: {}", poolStats);
                } else {
                    log.info("The stats of HTTP connection pool in Solr service client: {}", poolStats);
                }

                // close expired connections
                connectionManager.closeExpiredConnections();
                // close connections that have been idle longer than 30 seconds
                connectionManager.closeIdleConnections(30, TimeUnit.SECONDS);
            }
        }, 3, 3, TimeUnit.MINUTES);

        log.info("Finish to start up a Solr service client,\nclient: {}", this);
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("host", this.host)
                .append("config", this.clientConfig).build();
    }

    /**
     * Shutdown a Solr service client
     */
    public final void shutdown() {
        synchronized (this) {
            if (this.httpClient == null) {
                return;
            }
        }

        log.info("Start to shutdown a Solr service client...");

        this.connectionManager.shutdown();
        this.connectionMonitor.shutdownNow();

        IOUtils.closeQuietly(this.httpClient);
        IOUtils.closeQuietly(this.connectionManager);

        this.connectionManager = null;
        this.httpClient = null;

        log.info("Finish to shutdown a Solr service client.");
    }

    public final JsonElement getClientConfig() {
        if (this.httpClient == null) {
            return new JsonPrimitive("Solr service client is not started up.");
        }

        JsonObject clientConfigJson = this.clientConfig.toJsonObject();
        clientConfigJson.addProperty("host", this.host);

        return clientConfigJson;
    }

    public final JsonElement getPoolStats() {
        if (this.httpClient == null) {
            return new JsonPrimitive("Solr service client is not started up.");
        }

        PoolStats poolStats = this.connectionManager.getTotalStats();

        float demand = (poolStats.getLeased() + poolStats.getPending() / (float) poolStats.getMax());
        String utilization = String.format("%.2f%%", demand);

        JsonObject poolStatsJson = new JsonObject();
        poolStatsJson.addProperty("max", poolStats.getMax());
        poolStatsJson.addProperty("utilization", utilization);
        poolStatsJson.addProperty("leased", poolStats.getLeased());
        poolStatsJson.addProperty("pending", poolStats.getPending());
        poolStatsJson.addProperty("available", poolStats.getAvailable());

        return poolStatsJson;
    }

    public SolrResult getQueryResultByPost(String url, String parameter) {
        if (this.httpClient == null) {
            throw new SolrServiceException("Solr service client is not started yet.");
        }

        log.info("Send a POST reuqest to Solr server. url: {}, parameter: {}", url, parameter);

        URI uri;
        try {
            URIBuilder uriBuilder = new URIBuilder(url.toString());
            uri = uriBuilder.build();

        } catch (URISyntaxException e) {
            SolrServiceException exception = new SolrServiceException("Failed to build a URI", e);
            exception.addContextValue("Url", url);

            throw exception;
        }

        List<NameValuePair> parameterList = URLEncodedUtils.parse(parameter, Consts.UTF_8);

        if (log.isInfoEnabled()) {
            StringBuilder debuggingUrl = new StringBuilder(uri.toString());

            if (!parameterList.isEmpty()) {
                String queryString = URLEncodedUtils.format(parameterList, Consts.UTF_8);
                debuggingUrl.append('?').append(queryString);
            }

            log.info("Send a POST reuqest to Solr server. debugging url: {}, parameter: {}", debuggingUrl,
                    parameterList);
        }

        HttpPost httpPost = new HttpPost(uri);

        CloseableHttpResponse response = null;
        int httpStatus = 0;
        String stringEntity = "";

        try {
            httpPost.setEntity(new UrlEncodedFormEntity(parameterList, Consts.UTF_8));

            HttpClientContext context = HttpClientContext.create();
            response = this.httpClient.execute(httpPost, context);

            httpStatus = response.getStatusLine().getStatusCode();
            HttpEntity httpEntity = response.getEntity();
            stringEntity = EntityUtils.toString(httpEntity, Consts.UTF_8);

        } catch (IOException e) {
            SolrServiceException exception = new SolrServiceException("Failed to read data from Solr server", e);
            exception.addContextValue("Url", uri);

            throw exception;

        } finally {
            IOUtils.closeQuietly(response);
        }

        if (HttpStatus.SC_OK != httpStatus) {
            SolrServiceException exception = new SolrServiceException("Failed to read data from Solr server");
            exception.addContextValue("Url", uri);
            exception.addContextValue("HttpStatus", httpStatus);

            // just retain the most 2000 characters for debugging
            String errorDetail = stringEntity;
            int start = StringUtils.indexOf(errorDetail, "root cause");
            if (start > 0) {
                errorDetail = errorDetail.substring(start);
            }
            exception.addContextValue("Detail", StringUtils.left(errorDetail, 2000));

            throw exception;
        }

        SolrResult solrResult = new SolrResult(httpStatus, stringEntity);

        return solrResult;
    }
}