package com.patentcloud.api.web.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.patentcloud.api.constant.Constant;
import com.patentcloud.api.exception.PatentDataException;
import com.patentcloud.api.exception.PatentFileNotFoundException;
import com.patentcloud.api.model.Member;
import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.server.service.MemberService;
import com.patentcloud.api.util.ExcelUtils;
import com.patentcloud.api.util.ImageUtils;
import com.patentcloud.api.util.JsonUtils;
import com.patentcloud.api.util.PatentDataUtils;
import com.patentcloud.api.util.PdfUtils;
import com.patentcloud.api.util.config.ConfigProperties;
import com.patentcloud.api.util.solr.ParamUtils;

@RestController
@RequestMapping("/restful/data/{version}")
public class PatentDataController {

    private static final Logger log = LoggerFactory.getLogger(PatentDataController.class);

    @Autowired
    private MemberService memberService;

    @RequestMapping(value = "/countClipImage")
    public ResponseEntity<String> countClipImage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList) {
        log.info("Start to do countClipImage action. version: {}, path: {}, patentnum: {}, country: {}", version, path,
                patentNumber, countryList);

        List<PatentPath> patentPathList;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);

        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        JsonObject clipCountInfo = new JsonObject();
        PatentPath patentPath = patentPathList.get(0);

        String cachePath = ConfigProperties.getInstance().getString("cache.path", "");
        for (Path pathInfo : patentPath.paths) {
            if (pathInfo.toString().contains(cachePath)) {
                patentPath.paths.remove(pathInfo);
                break;
            }
        }

        String dataPath = ConfigProperties.getInstance().getString("data.path", "");
        for (Path pathInfo : patentPath.paths) {
            if (pathInfo.toString().contains(dataPath)) {
                patentPath.paths.remove(pathInfo);
                break;
            }
        }

        int clipCounts = ImageUtils.getClipCounts(patentPath);
        clipCountInfo.addProperty("clipImageCount", clipCounts);
        clipCountInfo.addProperty("patentNumber", patentPath.info.patentNumber);
        clipCountInfo.addProperty("path", patentPath.info.path);

        JsonObject result = new JsonObject();
        result.add("response", clipCountInfo);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(result.toString(), httpHeaders, HttpStatus.OK);
        log.info("Finish to do countClipImage action. result: {}", result);

        return responseEntity;
    }

    @RequestMapping(value = "/countFullPage")
    public ResponseEntity<String> countFullPage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList) throws IOException {
        log.info("Start to do countFullPage action. version: {}, path: {}, patentnum: {}, country: {}", version, path,
                patentNumber, countryList);

        List<PatentPath> patentPathList;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        JsonObject checkFullPagePdfInfo = new JsonObject();
        JsonArray jsonArray = new JsonArray();

        for (PatentPath patentPath : patentPathList) {
            PatentFile pdfFile = ImageUtils.getFullPdf(patentPath);

            if (pdfFile.file.exists()) {
                int countPdfPage = PdfUtils.countPdfPage(pdfFile.file.getAbsolutePath());
                checkFullPagePdfInfo.addProperty("result", true);
                checkFullPagePdfInfo.addProperty("pages", countPdfPage);

            } else {
                checkFullPagePdfInfo.addProperty("result", false);
            }

            checkFullPagePdfInfo.addProperty("path", patentPath.info.path);
            jsonArray.add(checkFullPagePdfInfo);
        }

        JsonObject jsonObject = new JsonObject();
        jsonObject.add("response", jsonArray);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, Constant.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(jsonObject.toString(), httpHeaders, HttpStatus.OK);
        log.info("Finish to do countFullPage action. result: {}", jsonObject);

        return responseEntity;
    }

    @RequestMapping(value = "/findInsetImage")
    public ResponseEntity<Resource> findInsetImage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList,
            @RequestParam(value = "filename", required = false) String fileName)
                    throws PatentFileNotFoundException, IOException {
        log.info("Start to do findInsetImage action. version: {}, path: {}, patentnum: {}, country: {}, filename: {}",
                version, path, patentNumber, countryList, fileName);

        List<PatentPath> patentPathList = null;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        PatentFile patentFile = ImageUtils.getInsetImage(patentPathList.get(0), fileName);

        if (patentFile.file.getPath().isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent inset image is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("patentNumber", patentNumber);
            exception.addContextValue("countryList", countryList);
            exception.addContextValue("fileName", fileName);

            throw exception;
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.IMAGE_PNG);

        // handle a small image file by FileSystemResource directly
        Resource fileResource = new FileSystemResource(patentFile.getFile());
        ResponseEntity<Resource> responseEntity = new ResponseEntity<>(fileResource, httpHeaders, HttpStatus.OK);

        log.info("Finish to do findInsetImage action. image file path: {}", fileResource.getFile().getAbsolutePath());

        return responseEntity;
    }

    @RequestMapping(value = "/findFullImage")
    public ResponseEntity<Resource> findFullImage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList,
            @RequestParam(value = "num", required = true) int number) throws PatentFileNotFoundException, IOException {
        log.info("Start to do findFullImage action. version: {}, path: {}, patentnum: {}, country: {}, num: {}",
                version, path, patentNumber, countryList, number);

        List<PatentPath> patentPathList = null;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        PatentFile patentFile = ImageUtils.getFullImage(patentPathList.get(0), number);

        if (patentFile.file.getPath().isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent full image is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("patentnum", patentNumber);
            exception.addContextValue("countryList", countryList);
            exception.addContextValue("number", number);

            throw exception;
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.IMAGE_PNG);

        // handle a small image file by FileSystemResource directly
        Resource fileResource = new FileSystemResource(patentFile.getFile());
        ResponseEntity<Resource> responseEntity = new ResponseEntity<>(fileResource, httpHeaders, HttpStatus.OK);

        log.info("Finish to do findFullImage action. image file path: {}", fileResource.getFile().getAbsolutePath());

        return responseEntity;
    }

    @RequestMapping(value = "/findFirstImage")
    public ResponseEntity<Resource> findFirstImage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList)
                    throws PatentFileNotFoundException, IOException {
        log.info("Start to do findFirstImage action. version: {}, path: {}, patentnum: {}, country: {}", version, path,
                patentNumber, countryList);

        List<PatentPath> patentPathList = null;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        PatentFile patentFile = ImageUtils.getFirstImage(patentPathList.get(0));

        if (patentFile.file.getPath().isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent first image is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("patentNumber", patentNumber);
            exception.addContextValue("countryList", countryList);
            throw exception;
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.IMAGE_PNG);

        // handle a small image file by FileSystemResource directly
        Resource fileResource = new FileSystemResource(patentFile.getFile());
        ResponseEntity<Resource> responseEntity = new ResponseEntity<>(fileResource, httpHeaders, HttpStatus.OK);

        log.info("Finish to do findFirstImage action. image file path: {}", fileResource.getFile().getAbsolutePath());

        return responseEntity;
    }

    @RequestMapping(value = "/findClipImage")
    public ResponseEntity<Resource> findClipImage(@PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNumber,
            @RequestParam(value = "country", required = false) List<String> countryList,
            @RequestParam(value = "num", required = true) int number) throws PatentFileNotFoundException, IOException {
        log.info("Start to do findClipImage action. version: {}, path: {}, patentnum: {}, country: {}, num: {}",
                version, path, patentNumber, countryList, number);

        List<PatentPath> patentPathList = null;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNumber, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        PatentFile patentFile = ImageUtils.getClipImage(patentPathList.get(0), number);

        if (patentFile.file.getPath().isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent clip image is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("patentNumber", patentNumber);
            exception.addContextValue("countryList", countryList);
            exception.addContextValue("num", number);
            throw exception;
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.IMAGE_PNG);

        // handle a small image file by FileSystemResource directly
        Resource fileResource = new FileSystemResource(patentFile.getFile());
        ResponseEntity<Resource> responseEntity = new ResponseEntity<>(fileResource, httpHeaders, HttpStatus.OK);

        log.info("Finish to do findClipImage action. image file path: {}", fileResource.getFile().getAbsolutePath());

        return responseEntity;
    }

    @RequestMapping(value = "/findFullPage")
    public void findFullPage(HttpServletResponse response, @PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNum,
            @RequestParam(value = "country", required = false) List<String> countryList,
            @RequestParam(value = "filename", required = true) String fileName)
                    throws PatentFileNotFoundException, IOException {
        log.info("Start to do findFullPage action. version: {}, path: {}, patentnum: {}, country: {}, filename: {}",
                version, path, patentNum, countryList, fileName);

        List<PatentPath> patentPathList = null;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNum, countryList);
        } catch (Exception e) {
            throw new PatentDataException(e);
        }

        List<PatentFile> patentFileList = new ArrayList<>();

        for (PatentPath patentPath : patentPathList) {
            PatentFile patentFile = ImageUtils.getFullPdf(patentPath);
            if (patentFile.file.exists()) {
                patentFileList.add(patentFile);
            }
        }

        if (patentFileList.isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent PNG/PDF file is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("filename", fileName);

            throw exception;
        }

        if (patentFileList.size() == 1) {
            PatentFile patentFile = patentFileList.get(0);
            File pdfFile = patentFile.getFile();

            if (StringUtils.isNotBlank(fileName)) {
                fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "");
            } else {
                fileName = patentFile.info.patentNumber;
            }

            response.setContentType(Constant.APPLICATION_PDF_VALUE);

            String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
            String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "pdf");
            response.setHeader("Content-Disposition", disposition);

            // use try-with-resources statement to auto-close underlying io
            // stream
            try (FileInputStream pdfFileInput = new FileInputStream(pdfFile)) {
                OutputStream output = response.getOutputStream();
                int contentLength = (int) IOUtils.copyLarge(pdfFileInput, output);
                response.setContentLength(contentLength);

                log.info("Finish to do findFullPage action. PDF file path: {}", pdfFile.getAbsolutePath());
            }
        } else {
            if (StringUtils.isNotBlank(fileName)) {
                fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "");
            } else {
                fileName = "FullPDF-Patentcloud";
            }

            response.setContentType(Constant.APPLICATION_ZIP_VALUE);

            String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
            String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "zip");
            response.setHeader("Content-Disposition", disposition);

            // use try-with-resources statement to auto-close underlying io
            // stream
            OutputStream output = response.getOutputStream();
            try (ZipArchiveOutputStream zipOutput = new ZipArchiveOutputStream(output)) {
                List<String> pdfFileNameList = new ArrayList<>();

                for (PatentFile patentFile : patentFileList) {
                    String pdfFileName = ParamUtils.genPdfName(patentFile);
                    pdfFileNameList.add(pdfFileName);

                    ZipArchiveEntry zipEntry = new ZipArchiveEntry(pdfFileName);
                    zipOutput.putArchiveEntry(zipEntry);

                    File pdfFile = patentFile.getFile();
                    try (FileInputStream pdfFileInput = new FileInputStream(pdfFile)) {
                        IOUtils.copyLarge(pdfFileInput, zipOutput);
                    }
                    zipOutput.closeArchiveEntry();

                }
                zipOutput.flush();

                log.info("Finish to do findFullPage action. archived PDF file name list: {}", pdfFileNameList);
            }
        }
    }

    @RequestMapping(value = "/findFirstPage")
    public void findFirstPage(HttpServletResponse response, @PathVariable String version,
            @RequestParam(value = "path", required = true) String path,
            @RequestParam(value = "patentnum", required = false) String patentNum,
            @RequestParam(value = "country", required = false) List<String> countryList,
            @RequestParam(value = "filename", required = true) String fileName,
            @RequestParam(value = "downloadType", required = true) String downloadType)
                    throws PatentFileNotFoundException, IOException {
        log.info(
                "Start to do findFirstPage action. version: {}, path: {}, patentnum: {}, country: {}, filename: {}, downloadType: {}",
                version, path, patentNum, countryList, fileName, downloadType);

        List<PatentPath> patentPathList;
        try {
            patentPathList = PatentDataUtils.getPatentPaths(path, patentNum, countryList);
        } catch (ParseException e) {
            throw new PatentDataException(e);
        }

        List<PatentFile> patentFileList = new ArrayList<>();
        for (PatentPath patpath : patentPathList) {
            PatentFile pdffile = ImageUtils.getFirstPagePdf(patpath);
            if (pdffile.file.exists()) {
                patentFileList.add(pdffile);
            }
        }

        if (patentFileList.isEmpty()) {
            PatentFileNotFoundException exception = new PatentFileNotFoundException(
                    "The patent PNG/PDF file is not found");
            exception.addContextValue("path", path);
            exception.addContextValue("filename", fileName);

            throw exception;
        }

        if (patentFileList.size() == 1) {
            PatentFile patentFile = patentFileList.get(0);
            File pdfFile = patentFile.getFile();

            if (StringUtils.isNotBlank(fileName)) {
                fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "");
            } else {
                fileName = patentFile.info.patentNumber;
            }

            response.setContentType(Constant.APPLICATION_PDF_VALUE);

            String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
            String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "pdf");
            response.setHeader("Content-Disposition", disposition);

            try (FileInputStream pdfFileInput = new FileInputStream(pdfFile)) {
                OutputStream output = response.getOutputStream();
                int contentLength = (int) IOUtils.copyLarge(pdfFileInput, output);
                response.setContentLength(contentLength);

                log.info("Finish to do findFirstPage action. PDF file path: {}", pdfFile.getAbsolutePath());
            }
        } else {
            if ("zip".equals(downloadType)) {
                response.setContentType(Constant.APPLICATION_ZIP_VALUE);

                if (StringUtils.isNotBlank(fileName)) {
                    fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "");
                } else {
                    fileName = "FirstPDF-Patentcloud";
                }

                String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
                String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "zip");
                response.setHeader("Content-Disposition", disposition);

                // use try-with-resources statement to auto-close underlying io
                // stream
                OutputStream output = response.getOutputStream();
                try (ZipArchiveOutputStream zipOutput = new ZipArchiveOutputStream(output)) {
                    List<String> pdfFileNameList = new ArrayList<>();

                    for (PatentFile patentFile : patentFileList) {
                        String pdfFileName = ParamUtils.genPdfName(patentFile);
                        pdfFileNameList.add(pdfFileName);

                        ZipArchiveEntry zipEntry = new ZipArchiveEntry(pdfFileName);
                        zipOutput.putArchiveEntry(zipEntry);

                        File pdfFile = patentFile.getFile();
                        try (FileInputStream pdfFileInput = new FileInputStream(pdfFile)) {
                            IOUtils.copyLarge(pdfFileInput, zipOutput);
                        }
                        zipOutput.closeArchiveEntry();
                    }
                    zipOutput.flush();

                    log.info("Finish to do findFirstPage action. archived PDF file name list: {}", pdfFileNameList);
                }
            } else if ("pdf".equals(downloadType)) {
                response.setContentType(Constant.APPLICATION_PDF_VALUE);

                if (StringUtils.isNotBlank(fileName)) {
                    fileName = fileName.replaceAll("\\.zip$|\\.pdf$", "");
                } else {
                    fileName = "FirstPage-Patentcloud";
                }

                String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
                String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "pdf");
                response.setHeader("Content-Disposition", disposition);

                List<File> pdfFileList = new ArrayList<>();
                for (PatentFile patentFile : patentFileList) {
                    pdfFileList.add(patentFile.getFile());
                }

                OutputStream output = response.getOutputStream();
                PdfUtils.mergeFirstPagesAsPdf(pdfFileList, output);

                log.info("Finish to do findFirstPage action. PDF filename: {}", fileName);

            } else {
                throw new IllegalArgumentException(String.format("An invalid downloadType: %s", downloadType));
            }
        }
    }

    @RequestMapping(value = "/findPatentExcel")
    public void findPatentExcel(HttpServletResponse response, @PathVariable String version,
            @RequestParam(value = "ptopid", required = true) String ptopid,
            @RequestParam(value = "field", required = false) List<String> fieldList,
            @RequestParam(value = "locale", required = false) String locale,
            @RequestParam(value = "filename", required = false) String fileName) throws IOException {
        log.info("Start to do findPatentExcel action. version: {}, ptopid: {}, field: {}, locale: {}, filename: {}",
                version, ptopid, fieldList, locale, fileName);

        List<String> ptopidList = Arrays.asList(ptopid.split(","));
        List<PatentInfo> patentInfoList = PatentDataUtils.getPatentInfos(ptopidList, fieldList.toArray(new String[0]));

        String viewIn = null;
        String fulltextUrl = null;
        try {
            User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

            Member member = memberService.getMemberInfo(user.getUsername());
            if (member != null && member.getMiscInfo() != null) {
                viewIn = member.getMiscInfo().getViewIn();
                fulltextUrl = member.getMiscInfo().getFulltextUrl();
            }
        } catch(Exception e) {
            log.error(e.getMessage());
        }

        HSSFWorkbook excel = ExcelUtils.toExcelWorkbook(patentInfoList, fieldList, PatentDataUtils.getLocale(locale),
                viewIn, fulltextUrl);

        response.setContentType(Constant.APPLICATION_EXCEL_VALUE);

        if (StringUtils.isNotBlank(fileName)) {
            fileName = StringUtils.removeEnd(fileName, ".xls");
        } else {
            fileName = "PatentExcel-Patentcloud";
        }

        String encodedFileName = new String(fileName.getBytes(), "ISO8859-1");
        String disposition = String.format("attachment; filename=\"%s.%s\"", encodedFileName, "xls");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, disposition);

        OutputStream output = response.getOutputStream();
        excel.write(output);
        output.flush();
        IOUtils.closeQuietly(output);

        log.info("Finish to do findPatentExcel action. Excel file name: {}", fileName);
    }

    @ExceptionHandler(value = { PatentDataException.class })
    public ResponseEntity<String> handlePatentDataException(PatentDataException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "patent.data.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }

    @ExceptionHandler(value = { PatentFileNotFoundException.class })
    public ResponseEntity<String> handlePatentFileNotFoundException(PatentFileNotFoundException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "patent.file.notFound");
        errorJson.addProperty("errorMessage", exception.getMessage());

        @SuppressWarnings("unchecked")
        List<String> damagedPathList = (List<String>) exception.getFirstContextValue("DamagedPathList");
        if (damagedPathList != null) {
            JsonArray damagedPathJson = JsonUtils.toJsonPrimitiveArray(damagedPathList, String.class);
            errorJson.add("damagedPath", damagedPathJson);
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.NOT_FOUND);

        return responseEntity;
    }

    /**
     * A workaround handles the low level IOException
     */
    @ExceptionHandler(value = { IOException.class })
    public ResponseEntity<String> handleIOException(IOException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "patent.data.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }
}
