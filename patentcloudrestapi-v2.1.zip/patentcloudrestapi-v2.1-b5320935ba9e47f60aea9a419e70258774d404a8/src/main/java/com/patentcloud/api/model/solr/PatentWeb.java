package com.patentcloud.api.model.solr;

import java.util.Date;

import org.apache.solr.client.solrj.beans.Field;

public class PatentWeb {
    @Field
    public String url;

    @Field
    public String ptosl;

    @Field
    public String pages;

    @Field
    public String providersl;

    @Field
    public Date dodate;
}
