package com.patentcloud.api.server.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import com.patentcloud.api.model.Member;
import com.patentcloud.api.server.dao.MemberDao;

@Repository
public class MemberServiceImpl implements MemberService, UserDetailsService {

    private MemberDao memberDao;

    private static long expriedTime;
    private static Map<String, Member> memberMap = new ConcurrentHashMap<String, Member>();

    static {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.HOUR_OF_DAY, 1);
        expriedTime = c.getTimeInMillis();
    }

    public void setMemberDao(MemberDao memberDao) {
        this.memberDao = memberDao;
    }

    @Override
    public Member getMemberInfo(String account) {
        long now = System.currentTimeMillis();
        if (now >= expriedTime) {
            synchronized (memberMap) {
                if (now >= expriedTime) {
                    memberMap.clear();
                    expriedTime += 3600000;
                }
            }
        }

        Member member = memberMap.get(account);
        if (member == null) {
            member = memberDao.getMemberInfo(account);
            memberMap.put(account, member);
        }

        return member;
    }

    @Override
    public Member getCurrentMemberInfo() {
        Member memberInfo = null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            User authUser = (User) authentication.getPrincipal();

            if (authUser != null) {
                memberInfo = getMemberInfo(authUser.getUsername());
            }
        }

        return memberInfo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
        Member memberInfo = memberDao.getMemberInfo(username);

        UserDetails user = null;

        if (memberInfo != null) {
            Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
            authorities.add(new SimpleGrantedAuthority("ROLE_APP"));

            user = new User(username, memberInfo.getPassword(), true, true, true, true, authorities);
        }

        return user;
    }
}
