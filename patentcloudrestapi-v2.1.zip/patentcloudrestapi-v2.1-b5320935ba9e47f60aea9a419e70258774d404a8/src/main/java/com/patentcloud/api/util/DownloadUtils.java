package com.patentcloud.api.util;

import java.io.ByteArrayInputStream;
import java.io.File;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.util.http.external.DownloadResult;
import com.patentcloud.api.util.http.external.DownloadServiceClient;

public class DownloadUtils {

    private static final Logger log = LoggerFactory.getLogger(DownloadUtils.class);

    public static boolean downloadAndWriteFile(String srcUrl, File destFile) {
        boolean successful = false;

        DownloadResult downloadResult = null;

        try {
            downloadResult = DownloadServiceClient.getInstance().getQueryResultByGet(srcUrl);
            byte[] byteArrayEntity = downloadResult.getEntityByteArray();

            ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(byteArrayEntity);
            FileUtils.copyInputStreamToFile(byteArrayInput, destFile);

            successful = true;

        } catch (Exception e) {
            log.warn("Failed to download a file and write it to a file, srcUrl: {}, destFile: {}", srcUrl,
                    destFile.getAbsolutePath(), e);
        }

        return successful;
    }
}
