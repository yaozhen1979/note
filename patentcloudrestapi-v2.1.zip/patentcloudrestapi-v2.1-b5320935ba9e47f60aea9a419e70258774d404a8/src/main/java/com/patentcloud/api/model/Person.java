package com.patentcloud.api.model;

public class Person {
    public String name;

    public String country;

    public String address;
}
