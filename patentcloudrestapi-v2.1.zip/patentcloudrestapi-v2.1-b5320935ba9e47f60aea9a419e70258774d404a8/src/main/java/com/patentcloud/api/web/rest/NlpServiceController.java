package com.patentcloud.api.web.rest;

import java.util.Date;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.patentcloud.api.constant.Constant;
import com.patentcloud.api.util.nlp.NlpResult;
import com.patentcloud.api.util.nlp.NlpServiceClient;
import com.patentcloud.api.util.nlp.NlpServiceException;
import com.patentcloud.api.util.nlp.parameter.KeywordExtractorParameter;
import com.patentcloud.api.util.nlp.parameter.QueryExpansionParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByBriefParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByClaimParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryParameter;

@RestController
@RequestMapping("/restful/nlp/{version}")
public class NlpServiceController {

    private static final Logger log = LoggerFactory.getLogger(NlpServiceController.class);

    private static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    @RequestMapping(value = "/findSimpleQuery")
    public ResponseEntity<String> findSimpleQuery(@PathVariable String version,
            @RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "id", required = true) String id,
            @RequestParam(value = "id_type", required = true) String idType,
            @RequestParam(value = "time", required = true) @DateTimeFormat(pattern = Constant.ISO_8601_PATTERN) Date time) {

        SimpleQueryParameter parameter = new SimpleQueryParameter.Builder(text, id, idType, time).build();
        log.info("Start to do findSimpleQuery action. version: {}, parameter: {}", version, parameter);

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQuery(parameter);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(nlpResult.getEntity(), httpHeaders,
                HttpStatus.valueOf(nlpResult.getHttpStatus()));

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Finish to do findSimpleQuery action. solrQueryStr: {}", solrQueryStr);
        }

        return responseEntity;
    }

    @RequestMapping(value = "/findSimpleQuery/brief")
    public ResponseEntity<String> findSimpleQueryByBrief(@PathVariable String version,
            @RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "id", required = true) String id,
            @RequestParam(value = "id_type", required = true) String idType,
            @RequestParam(value = "time", required = true) @DateTimeFormat(pattern = Constant.ISO_8601_PATTERN) Date time) {

        SimpleQueryByBriefParameter parameter = new SimpleQueryByBriefParameter.Builder(text, id, idType, time).build();
        log.info("Start to do findSimpleQueryByBrief action. version: {}, parameter: {}", version, parameter);

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQueryByBrief(parameter);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(nlpResult.getEntity(), httpHeaders,
                HttpStatus.valueOf(nlpResult.getHttpStatus()));

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Finish to do findSimpleQueryByBrief action. solrQueryStr: {}", solrQueryStr);
        }

        return responseEntity;
    }

    @RequestMapping(value = "/findSimpleQuery/claim")
    public ResponseEntity<String> findSimpleQueryByClaim(@PathVariable String version,
            @RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "id", required = true) String id,
            @RequestParam(value = "id_type", required = true) String idType,
            @RequestParam(value = "time", required = true) @DateTimeFormat(pattern = Constant.ISO_8601_PATTERN) Date time) {

        SimpleQueryByClaimParameter parameter = new SimpleQueryByClaimParameter.Builder(text, id, idType, time).build();
        log.info("Start to do findSimpleQueryByClaim action. version: {}, parameter: {}", version, parameter);

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQueryByClaim(parameter);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(nlpResult.getEntity(), httpHeaders,
                HttpStatus.valueOf(nlpResult.getHttpStatus()));

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            String solrQueryStr = nlpResultJson.get("solrQueryStr").getAsString();

            log.info("Finish to do findSimpleQueryByClaim action. solrQueryStr: {}", solrQueryStr);
        }

        return responseEntity;
    }

    @RequestMapping(value = "/findKeywordExtraction")
    public ResponseEntity<String> findKeywordExtraction(@PathVariable String version,
            @RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "id", required = true) String id,
            @RequestParam(value = "id_type", required = true) String idType,
            @RequestParam(value = "time", required = true) @DateTimeFormat(pattern = Constant.ISO_8601_PATTERN) Date time) {

        KeywordExtractorParameter parameter = new KeywordExtractorParameter.Builder(text, id, idType, time).build();
        log.info("Start to do findKeywordExtraction action. version: {}, arameter: {}", version, parameter);

        NlpResult nlpResult = NlpServiceClient.getInstance().findKeywordExtraction(parameter);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(nlpResult.getEntity(), httpHeaders,
                HttpStatus.valueOf(nlpResult.getHttpStatus()));

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            JsonArray keywordsJson = nlpResultJson.getAsJsonArray("keywords");

            log.info("Finish to do findKeywordExtraction action. keywords: {}", keywordsJson);
        }

        return responseEntity;
    }

    @RequestMapping(value = "/findQueryExpansion")
    public ResponseEntity<String> findQueryExpansion(@PathVariable String version,
            @RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "id", required = true) String id,
            @RequestParam(value = "id_type", required = true) String idType,
            @RequestParam(value = "time", required = true) @DateTimeFormat(pattern = Constant.ISO_8601_PATTERN) Date time) {

        QueryExpansionParameter parameter = new QueryExpansionParameter.Builder(text, id, idType, time).build();
        log.info("Start to do findQueryExpansion action. version: {}, parameter: {}", version, parameter);

        NlpResult nlpResult = NlpServiceClient.getInstance().findQueryExpansion(parameter);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(nlpResult.getEntity(), httpHeaders,
                HttpStatus.valueOf(nlpResult.getHttpStatus()));

        if (log.isInfoEnabled()) {
            JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
            JsonArray identicalWordsJson = nlpResultJson.getAsJsonArray("identical words");

            log.info("Finish to do findQueryExpansion action. identicalWords: {}", identicalWordsJson);
        }

        return responseEntity;
    }

    @ExceptionHandler(value = { NlpServiceException.class })
    public ResponseEntity<String> handleNlpException(NlpServiceException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "nlp.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }
}
