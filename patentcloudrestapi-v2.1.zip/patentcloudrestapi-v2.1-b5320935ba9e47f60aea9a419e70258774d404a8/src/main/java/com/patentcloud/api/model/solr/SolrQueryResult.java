package com.patentcloud.api.model.solr;

import java.util.List;

import com.patentcloud.api.model.PatentInfo;

public class SolrQueryResult {
    
    public List<PatentInfo> patentInfoList;
    
    public Long numFound;

    public List<PatentInfo> getPatentInfoList() {
        return patentInfoList;
    }

    public void setPatentInfoList(List<PatentInfo> patentInfoList) {
        this.patentInfoList = patentInfoList;
    }

    public Long getNumFound() {
        return numFound;
    }

    public void setNumFound(Long numFound) {
        this.numFound = numFound;
    }   
}
