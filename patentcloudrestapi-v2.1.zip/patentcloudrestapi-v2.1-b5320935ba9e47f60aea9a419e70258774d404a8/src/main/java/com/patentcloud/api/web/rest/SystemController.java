package com.patentcloud.api.web.rest;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.patentcloud.api.server.dao.common.MongoDbClient;
import com.patentcloud.api.util.http.SolrServiceClient;
import com.patentcloud.api.util.http.external.DownloadServiceClient;
import com.patentcloud.api.util.nlp.NlpServiceClient;

@RestController
@RequestMapping("/restful/system/{version}")
public class SystemController {

    private static final Logger log = LoggerFactory.getLogger(SystemController.class);

    @RequestMapping(value = "/findSystemInfo")
    public ResponseEntity<String> findSystemInfo(HttpServletRequest request) throws IOException {
        ServletContext servletContext = request.getServletContext();
        InputStream manifestInput = servletContext.getResourceAsStream("/META-INF/MANIFEST.MF");

        if (manifestInput == null) {
            throw new IllegalStateException(
                    "Cannot load /META-INF/MANIFEST.MF file. This function only supports in test/production server environment.");
        }

        Manifest manifest = new Manifest(manifestInput);
        JsonObject manifestJson = new JsonObject();

        Attributes attributes = manifest.getMainAttributes();
        Set<Entry<Object, Object>> entrySet = attributes.entrySet();
        for (Entry<Object, Object> entry : entrySet) {
            String key = entry.getKey().toString();
            String value = entry.getValue().toString();
            manifestJson.addProperty(key, value);
        }

        JsonElement solrClientConfig = SolrServiceClient.getInstance().getClientConfig();
        JsonElement solrPoolStats = SolrServiceClient.getInstance().getPoolStats();
        JsonObject solrClientInfoJson = new JsonObject();
        solrClientInfoJson.add("config", solrClientConfig);
        solrClientInfoJson.add("poolStats", solrPoolStats);

        JsonElement downloadClientConfig = DownloadServiceClient.getInstance().getClientConfig();
        JsonElement downloadPoolStats = DownloadServiceClient.getInstance().getPoolStats();
        JsonObject downloadClientInfoJson = new JsonObject();
        downloadClientInfoJson.add("config", downloadClientConfig);
        downloadClientInfoJson.add("poolStats", downloadPoolStats);

        JsonElement nlpClientConfig = NlpServiceClient.getInstance().getClientConfig();
        JsonElement nlpPoolStats = NlpServiceClient.getInstance().getPoolStats();
        JsonObject nlpClientInfoJson = new JsonObject();
        nlpClientInfoJson.add("config", nlpClientConfig);
        nlpClientInfoJson.add("poolStats", nlpPoolStats);

        JsonElement mongoDbClientConfig = MongoDbClient.getInstance().getClientConfig();

        JsonObject systemInfoJson = new JsonObject();
        systemInfoJson.add("manifest", manifestJson);
        systemInfoJson.add("solrClient", solrClientInfoJson);
        systemInfoJson.add("downloadClient", downloadClientInfoJson);
        systemInfoJson.add("nlpClient", nlpClientInfoJson);
        systemInfoJson.add("mongoDbClient", mongoDbClientConfig);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(systemInfoJson.toString(), HttpStatus.OK);

        return responseEntity;
    }

    @ExceptionHandler(value = { IOException.class })
    public ResponseEntity<String> handleIOException(IOException exception) {
        log.error(exception.getMessage(), exception);

        JsonObject errorJson = new JsonObject();
        errorJson.addProperty("errorCode", "system.error");
        errorJson.addProperty("errorMessage", exception.getMessage());
        String errorDetail = ExceptionUtils.getStackTrace(exception);
        errorJson.addProperty("exception", errorDetail);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(errorJson.toString(), httpHeaders,
                HttpStatus.INTERNAL_SERVER_ERROR);

        return responseEntity;
    }
}
