package com.patentcloud.api.scheduling;

import com.patentcloud.api.server.service.PatentDataStatusService;

public class DailyJob {

    private PatentDataStatusService patentDataStatusService;

    public void executeJob() {       
        patentDataStatusService.updatePatentDataStatus();
    }

    public void setPatentDataStatusService(PatentDataStatusService patentDataStatusService) {
        this.patentDataStatusService = patentDataStatusService;
    }
}
