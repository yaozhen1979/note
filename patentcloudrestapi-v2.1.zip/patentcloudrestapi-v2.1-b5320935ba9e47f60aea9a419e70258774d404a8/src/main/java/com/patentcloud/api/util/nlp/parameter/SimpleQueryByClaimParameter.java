package com.patentcloud.api.util.nlp.parameter;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.patentcloud.api.constant.Constant;

/**
 * A immutable parameter container holds the required and optional query
 * parameters. It is created by according to Builder pattern.
 * 
 * @author Allan Huang
 */
public class SimpleQueryByClaimParameter implements ParameterMap<String, Object> {
    // required parameters
    private final String text;

    private final String id;

    private final String idType;

    private final Date time;

    private SimpleQueryByClaimParameter(Builder builder) {
        this.text = builder.text;
        this.id = builder.id;
        this.idType = builder.idType;
        this.time = builder.time;
    }

    public String getText() {
        return this.text;
    }

    public String getId() {
        return this.id;
    }

    public String getIdType() {
        return this.idType;
    }

    public Date getTime() {
        return this.time;
    }

    public String toString() {
        String timeValue = Constant.ISO_8601_FORMAT.format(this.time);

        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("text", this.text)
                .append("id", this.id).append("idType", this.idType).append("time", timeValue).build();
    }

    @Override
    public Map<String, Object> unmodifiableParamMap() {
        Map<String, Object> parameterMap = new HashMap<>();

        parameterMap.put("text", this.text);
        parameterMap.put("id", this.id);
        parameterMap.put("id_type", this.idType);

        String timeValue = Constant.ISO_8601_FORMAT.format(this.time);
        parameterMap.put("time", timeValue);

        Map<String, Object> unmodifiableMap = Collections.unmodifiableMap(parameterMap);

        return unmodifiableMap;
    }

    // Builder Class
    public static class Builder {

        private String text;

        private String id;

        private String idType;

        private Date time;

        public Builder(String text, String id, String idType, Date time) {
            this.text = text;
            this.id = id;
            this.idType = idType;
            this.time = time;
        }

        public SimpleQueryByClaimParameter build() {
            if (StringUtils.isBlank(this.text)) {
                throw new IllegalStateException("text is blank");
            }

            if (StringUtils.isBlank(this.id)) {
                throw new IllegalStateException("id is blank");
            }

            if (StringUtils.isBlank(this.idType)) {
                throw new IllegalStateException("idType is blank");
            }

            if (this.time == null) {
                throw new IllegalStateException("time is blank");
            }

            return new SimpleQueryByClaimParameter(this);
        }
    }
}