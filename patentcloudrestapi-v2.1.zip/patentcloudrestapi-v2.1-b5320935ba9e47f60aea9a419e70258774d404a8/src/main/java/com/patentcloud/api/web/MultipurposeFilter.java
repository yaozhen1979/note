package com.patentcloud.api.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

@WebFilter(urlPatterns = { "/*" })
public class MultipurposeFilter implements Filter {

    @SuppressWarnings("unused")
    private static final Logger log = LoggerFactory.getLogger(MultipurposeFilter.class);

    public static final String MDC_KEY_CLIENT_HOST = "clientHost";

    /**
     * Default constructor.
     */
    public MultipurposeFilter() {
    }

    private FilterConfig config;

    protected FilterConfig getConfig() {
        return this.config;
    }

    /**
     * @see Filter#init(FilterConfig)
     */
    public void init(FilterConfig config) throws ServletException {
        this.config = config;
    }

    /**
     * @see Filter#destroy()
     */
    public void destroy() {
    }

    /**
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;

        String clientHost = httpRequest.getParameter("client_host");
        if (StringUtils.isBlank(clientHost)) {
            // the format of client host is "host name/ip address", e.g.
            // patentcloud-webtest2/10.60.90.178
            clientHost = String.format("%s/%s", httpRequest.getRemoteAddr(), httpRequest.getRemoteHost());
        }

        // Refer to
        // http://logging.apache.org/log4j/2.x/manual/thread-context.html
        MDC.put(MDC_KEY_CLIENT_HOST, clientHost);

        // pass the request along the filter chain
        chain.doFilter(request, response);

        MDC.clear();
    }
}
