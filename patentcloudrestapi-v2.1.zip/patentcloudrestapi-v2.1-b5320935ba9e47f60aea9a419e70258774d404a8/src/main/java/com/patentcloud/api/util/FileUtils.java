package com.patentcloud.api.util;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.patentcloud.api.model.PatentFile;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.util.solr.PatentDataConfig;

public class FileUtils {

    public static File getCacheFile(PatentFile patentFile, Path filePath) {
        String relPatentPath = PatentDataUtils.getRelPatentPath(patentFile.getInfo());

        for (File file : PatentDataConfig.CACHE_PATH_PTO.get(patentFile.getInfo().ptoVO)) {
            return file.toPath().resolve(relPatentPath).resolve(filePath).toFile();
        }

        return new File("");
    }

    public static void sureFileExists(File file, boolean parent) throws IOException {
        File dir = parent ? file.getParentFile() : file;

        if (dir == null) {
            throw new IOException(
                    String.format("Cannot find the specified directory. directory: %s", file.getAbsolutePath()));
        }

        boolean existed = dir.exists();

        if (!existed) {
            existed = dir.mkdirs();
        }
        
        if (!existed) {
            throw new IOException(String.format("Failed to create a directory. directory: %s", dir.getAbsolutePath()));
        }
    }

    public static List<Path> listPatentFilesByPrefix(PatentPath patentPath, Path subdir, final String... prefixes) {
        List<Path> list = new ArrayList<>();

        for (Path path : patentPath.paths) {
            Path dirPath = path.resolve(subdir);
            String[] filenames = dirPath.toFile().list(new FilenameFilter() {
                @Override
                public boolean accept(File dir, String name) {
                    String lowname = name.toLowerCase();
                    for (String prefix : prefixes) {
                        if (lowname.startsWith(prefix.toLowerCase())) {
                            return true;
                        }
                    }
                    return false;
                }
            });

            if (filenames != null && filenames.length > 0) {
                for (String filename : filenames) {
                    list.add(dirPath.resolve(filename));
                }
                break;
            }
        }
        return list;
    }

    public static List<Path> listPatentFilesBySuffix(PatentPath patentPath, Path subdir, final String... suffixes) {
        List<Path> list = new ArrayList<>();

        for (Path path : patentPath.paths) {
            Path dirPath = path.resolve(subdir);

            String[] filenames = dirPath.toFile().list(new FilenameFilter() {
                @Override
                public boolean accept(File dir, String name) {
                    String lowname = name.toLowerCase();
                    for (String suffix : suffixes) {
                        if (lowname.endsWith(suffix.toLowerCase())) {
                            return true;
                        }
                    }
                    return false;
                }
            });

            if (filenames != null && filenames.length > 0) {
                Arrays.sort(filenames, new Comparator<String>() {
                    public int compare(String filename1, String filename2) {
                        int filepage1 = Integer.parseInt(filename1.substring(0, filename1.indexOf(".")));
                        int filepage2 = Integer.parseInt(filename2.substring(0, filename2.indexOf(".")));
                        if (filepage1 > filepage2) {
                            return 1;
                        } else {
                            return -1;
                        }
                    }
                });

                for (String filename : filenames) {
                    list.add(dirPath.resolve(filename));
                }

                break;
            }
        }
        return list;
    }
}
