package com.patentcloud.api.util;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.common.Mapping;
import com.patentcloud.api.constant.Pto;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.PatentPath;
import com.patentcloud.api.model.SolrQueryVO;
import com.patentcloud.api.model.solr.SolrQueryResult;
import com.patentcloud.api.util.solr.PatentDataConfig;
import com.patentcloud.api.util.solr.SolrUtils;

public class PatentDataUtils {

    private static final Logger log = LoggerFactory.getLogger(PatentDataUtils.class);

    public static List<PatentPath> getPatentPaths(String path, String patentnum, List<String> countryList)
            throws UnsupportedEncodingException, ParseException {
        List<PatentPath> patentPaths = new ArrayList<>();
        if (path != null && !path.isEmpty() && !path.equals("")) {            
            List<PatentInfo> patentInfos = getPatentInfosByPaths(path);
            for (PatentInfo info : patentInfos) {
                List<String> pathCountryList = Arrays.asList(info.getCountry());
                String ptoStr = info.ptoVO.toString().toLowerCase();
                if (ptoStr.equals("cnipr")) {
                    SolrQueryVO solrQueryVO = new SolrQueryVO();
                    solrQueryVO.setCc(pathCountryList);

                    // info.statInt
                    Integer[] statArray = { info.stats.get(info.stats.size() - 1) };
                    solrQueryVO.setStat(statArray);
                    solrQueryVO.setMode("BRIEF_1");
                    solrQueryVO.setQ("patentNumber:" + URLEncoder.encode(info.patentNumber, "UTF-8"));

                    SolrQuery query = SolrUtils.genQuery(solrQueryVO);
                    SolrQueryResult solrResult;
                    try {
                        solrResult = SolrUtils.queryInfos(query);
                        List<PatentInfo> patentInfoList = solrResult.getPatentInfoList();
                        for (PatentInfo cniprInfo : patentInfoList) {
                            cniprInfo.ptoVO = info.ptoVO;
                            cniprInfo.path = ImageUtils.getImagePath(info);
                            patentPaths.add(preparePatentPath(cniprInfo));
                        }
                    } catch (SolrServerException e) {
                        log.error(e.getMessage(), e);
                    } catch (IOException e) {
                        log.error(e.getMessage(), e);
                    }
                } else {
                    PatentPath patentPath = preparePatentPath(info);
                    patentPaths.add(patentPath);
                }
            }
        } else {
            String reqPatentNumber = new String(patentnum.getBytes("iso-8859-1"), "UTF-8");
            String[] reqPatentNumberArray = reqPatentNumber.split(",");
            for (int i = 0; i < reqPatentNumberArray.length; i++) {
                SolrQueryVO solrQueryVO = new SolrQueryVO();
                solrQueryVO.setCc(countryList);
                solrQueryVO.setMode("BRIEF_1");
                Pto pto = Mapping.ptoCountryMap.get(countryList.get(0).toLowerCase());
                solrQueryVO.setQ(
                        "patentNumber:" + URLEncoder.encode(reqPatentNumberArray[i].replaceAll("\t", ""), "UTF-8"));

                SolrQuery query = SolrUtils.genQuery(solrQueryVO);
                SolrQueryResult solrResult;
                try {
                    solrResult = SolrUtils.queryInfos(query);
                    List<PatentInfo> patentInfoList = solrResult.getPatentInfoList();
                    for (PatentInfo info : patentInfoList) {
                        info.path = ImageUtils.getImagePath(info);
                        info.ptoVO = Mapping.ptoCountryMap.get(info.getCountry().toLowerCase());
                        patentPaths.add(preparePatentPath(info));
                    }
                } catch (SolrServerException e) {
                    log.error(e.getMessage(), e);
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return patentPaths;
    }

    /**
     * path search order: cache -> google patent -> data
     */
    protected static PatentPath preparePatentPath(PatentInfo info) {
        PatentPath patentPath = new PatentPath(info);
        String relpath = info.path.toLowerCase();

        // cache path
        for (File file : PatentDataConfig.CACHE_PATH_PTO.get(info.ptoVO)) {
            patentPath.paths.add(file.toPath().resolve(relpath));
        }

        // pto data path
        for (File file : PatentDataConfig.DATA_PATH_PTO.get(info.ptoVO)) {
            patentPath.paths.add(file.toPath().resolve(relpath));
        }
        
        // google patent path
        for (File file : PatentDataConfig.GOOGLE_PATENT_PATH_PTO.get(info.ptoVO)) {
            patentPath.paths.add(file.toPath().resolve(relpath));
        }
        return patentPath;
    }

    public static List<PatentInfo> getPatentInfosByPaths(String path) throws ParseException {
        List<PatentInfo> patentInfos = new ArrayList<>();
        List<String> pathList = Arrays.asList(path.split(","));
        if (pathList == null || pathList.size() <= 0) {
            return patentInfos;
        }
        PatentInfo patentInfo = null;
        for (String pathInfo : pathList) {
            patentInfo = new PatentInfo();
            String[] info = pathInfo.split("/|\\\\"); // path can be separated
                                                      // by // "/" or "\"
            patentInfo.country = info[0].replaceAll("^(\\w{2}).*", "$1").toLowerCase();
            patentInfo.ptoVO = Mapping.ptoCountryMap.get(patentInfo.country);
            patentInfo.pto = patentInfo.ptoVO.toString();
            patentInfo.kindcode = info[0].replaceAll("\\w{3}(.*)", "$1").toUpperCase();
            patentInfo.doDate = new SimpleDateFormat("yyyy/MM/dd").parse(info[1] + "/" + info[2] + "/" + info[3]);
            patentInfo.patentNumber = info[4];
            patentInfo.path = pathInfo.toLowerCase();
            ArrayList<Integer> statsList = new ArrayList<Integer>();
            statsList.add(Integer.valueOf(info[0].replaceAll("^\\w{2}(\\d).*", "$1")));
            patentInfo.stats = statsList;
            patentInfos.add(patentInfo);
        }
        return patentInfos;
    }

    public static List<PatentInfo> getPatentInfos(List<String> ptopidList, String... fields) {
        List<PatentInfo> patentInfos = new ArrayList<>();
        for (String ptopid : ptopidList) {
            PatentInfo info = PatentInfo.findOne(ptopid.toString(), fields);
            if (info != null) {
                patentInfos.add(info);
            }
        }
        return patentInfos;
    }

    public static Locale getLocale(String strLocale) {
        String[] reqLocales = strLocale.split("_");
        if (reqLocales.length == 2) {
            Locale locale = new Locale(reqLocales[0], reqLocales[1]);
            return locale;
        } else {
            Locale locale = new Locale("en", "US");
            return locale;
        }
    }

    public static String getRelPatentPath(PatentInfo info) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String country = info.getCountry();
        if (country != null && info.ptoVO != null) {
            country = Mapping.ptoPathMap.get(info.ptoVO);
        }
        return String.format("%1$s%2$d%3$s/%4$s/%5$s", country, info.stats.get(info.stats.size() - 1),
                info.kindcode == null ? "" : info.kindcode.toLowerCase(), sdf.format(info.doDate),
                info.patentNumber.replaceAll("[\\/\\s]", "").toLowerCase());
    }
}
