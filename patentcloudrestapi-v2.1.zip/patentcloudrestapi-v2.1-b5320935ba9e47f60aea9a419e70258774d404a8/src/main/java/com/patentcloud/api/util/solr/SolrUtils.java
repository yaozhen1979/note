package com.patentcloud.api.util.solr;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrRequest.METHOD;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.common.Mapping;
import com.patentcloud.api.common.SolrQueryFieldSet;
import com.patentcloud.api.constant.Pto;
import com.patentcloud.api.model.Member;
import com.patentcloud.api.model.PatentInfo;
import com.patentcloud.api.model.SolrQueryVO;
import com.patentcloud.api.model.solr.SolrPatentInfo;
import com.patentcloud.api.model.solr.SolrQueryResult;
import com.patentcloud.api.server.service.MemberService;
import com.patentcloud.api.util.SpringContextUtil;
import com.patentcloud.api.util.config.ConfigProperties;
import com.patentcloud.api.util.http.SolrResult;
import com.patentcloud.api.util.http.SolrServiceClient;

public class SolrUtils {
    private static final Logger log = LoggerFactory.getLogger(SolrUtils.class);

    private static String shardKeyPrefix = "solr.shard.";
    private static Map<String, String> solrShardMap = new LinkedHashMap<String, String>();

    static {
        int[] statArray = new int[] { 1, 2 };
        for (String core : Mapping.PTO2CORE.values()) {
            String coreKey = shardKeyPrefix + core.toLowerCase();
            for (int stat : statArray) {
                String statKey = coreKey + "." + stat;
                String shard = ConfigProperties.getInstance().getString(statKey);
                if (shard == null) {
                    shard = ConfigProperties.getInstance().getString(coreKey);
                }
                if (shard != null) {
                    solrShardMap.put(statKey, shard);
                }
            }
        }
    }

    public static String queryJSon(String url, String query) {
        SolrResult solrResult = SolrServiceClient.getInstance().getQueryResultByPost(url, query);
        return solrResult.getEntity();
    }

    public static SolrResult queryJSonServlet(SolrQuery solrQuery) {
        solrQuery.set("wt", "json");
        String solrUrl = getUrlSelect(solrQuery);
        SolrResult solrResult = SolrServiceClient.getInstance().getQueryResultByPost(solrUrl, solrQuery.toString());
        return solrResult;
    }

    public static String addShards(SolrQuery solrQuery, List<String> countries, boolean docdb, Integer stat) {
        Set<String> cores = addShardCore(solrQuery, countries, docdb);
        return getSolrShardByCore(cores, stat);
    }

    public static void addShardsInQuery(SolrQuery solrQuery, List<String> countries, boolean docdb, Integer stat) {
        Set<String> cores = addShardCore(solrQuery, countries, docdb);
        String shardStr = getSolrShardByCore(cores, stat);
        if (StringUtils.isNotBlank(shardStr)) {
            solrQuery.set("shards", shardStr);
        }
    }

    private static Set<String> addShardCore(SolrQuery solrQuery, List<String> countries, boolean docdb) {
        Set<String> cores = new LinkedHashSet<String>();
        if (solrQuery != null) {
            String q = solrQuery.getQuery();
            if (StringUtils.isNotBlank(q)) {
                // 萃取 ptopid 參數, 加以判斷 (由於 ptopid 是程式放的，理論上以 ptopid 的 shards
                // 為主即可)
                if (q.toLowerCase().contains("ptopid:")) {
                    countries = null;
                    for (String pto : Mapping.PTO2CORE.keySet()) {
                        if (q.contains(pto + ".")) {
                            cores.add(Mapping.PTO2CORE.get(pto));
                        }
                    }
                }
            }
        }

        if (countries != null) {
            for (String c : countries) {
                if (!cores.contains(c)) {
                    cores.add(c);
                }
            }
        }
        if (docdb) {
            cores.add(Mapping.PTO2CORE.get(Pto.DOCDB.name()));
        }
        return cores;
    }

    public static String getSolrShardByCore(Set<String> cores, Integer stat) {
        if (cores.isEmpty()) {
            cores.addAll(Mapping.PTO2CORE.values());
        }

        int[] sArray = null;
        if (stat != null && (stat == 1 || stat == 2)) {
            sArray = new int[] { stat };
        } else {
            sArray = new int[] { 1, 2 };
        }

        Set<String> shards = new LinkedHashSet<String>();

        for (String core : cores) {
            for (int s : sArray) {
                String key = shardKeyPrefix + core.toLowerCase() + "." + s;
                String shard = solrShardMap.get(key);
                if (shard == null) {
                    key = shardKeyPrefix + Mapping.PTO2CORE.get(Pto.DOCDB.name()).toLowerCase() + "." + s;
                    shard = solrShardMap.get(key);
                }
                if (shard != null) {
                    shards.add(shard);
                }
            }
        }

        String solrShardString = StringUtils.join(shards, ",");
        log.debug("Convert cores: [] to solrShardString: {}", cores, solrShardString);

        return solrShardString;
    }

    public static SolrQuery genQuery(SolrQueryVO queryvo) {
        SolrQuery query = new SolrQuery();
        // rows
        int rows = queryvo.getRows();
        query.setRows(rows);

        // sort, sortType
        if (queryvo.getSort() == null || queryvo.getSort().length() == 0) {
            query.set(null);
        } else {
            query.set("sort", queryvo.getSort());
        }

        if (queryvo.isHighlight()) {
            query.setHighlight(true);
            if (queryvo.getHighlightField() != null) {
                for (String field : queryvo.getHighlightField()) {
                    query.addHighlightField(field);
                }
            }
        }

        // start
        int start = queryvo.getStart();
        query.setStart(start);

        // q
        String q = queryvo.getQ();
        List<String> ptopid = queryvo.getPtopId();
        if (ptopid != null && !ptopid.isEmpty()) {
            String ptopidStr = "";
            for (int i = 0; i < ptopid.size(); i++) {
                ptopidStr += "ptopid:" + ptopid.get(i) + " OR ";
            }
            ptopidStr = ptopidStr.substring(0, ptopidStr.length() - 4);
            q = ptopidStr;
            queryvo.setStem(false);
        }

        /*
         * if (q == null) { throw new IllegalArgumentException(
         * "invalid query string"); }
         */
        if (q != null) {
            if (queryvo.getAddquery() != null && queryvo.getAddquery().trim().length() > 0) {
                q = q + " AND (" + queryvo.getAddquery() + ") ";
            }

            MemberService memberService = (MemberService) SpringContextUtil.getBean("memberService");
            Member memberInfo = memberService.getCurrentMemberInfo();

            q = ParamUtils.transQueryK2S(q, queryvo.isStem(), memberInfo.getPrivilege());

            // generate solr query by defOpAnd
            String solrQ = "";
            if (queryvo.isDefOpAnd()) {
                solrQ = "{!lucene q.op=AND} (" + q + ")";
            } else {
                solrQ = "(" + q + ")";
            }

            // stat
            int stat = 0;
            if (queryvo.getStat() != null) {
                for (Integer value : queryvo.getStat()) {
                    stat |= value;
                }
            }
            if (stat == 1 || stat == 2) {
                solrQ += " AND (stats:" + stat + ")";
            }

            // countries
            List<String> countries = queryvo.getCc();
            if (countries != null && countries.size() > 0) {
                solrQ += " AND (";
                for (int i = 0; i < countries.size(); i++) {
                    if (i > 0) {
                        solrQ += " OR ";
                    }
                    solrQ += "country:\"" + countries.get(i).toUpperCase() + "\"";
                }
                if (queryvo.isDocdb()) {
                    solrQ += " OR (pto:\"DOCDB\")";
                }
                solrQ += ")";
            } else {
                if (queryvo.isDocdb()) {
                    solrQ += " AND (pto:\"DOCDB\")";
                }
            }

            // fq
            String fqueryStr = queryvo.getFq();
            if (!StringUtils.isBlank(fqueryStr)) {
                fqueryStr = ParamUtils.transQueryK2S(fqueryStr, false, memberInfo.getPrivilege());
                query.set("fq", fqueryStr);
            }

            // type code
            Integer[] types = queryvo.getTc();
            if (types != null && types.length > 0) {
                solrQ += " AND (";
                for (int i = 0; i < types.length; i++) {
                    if (i > 0) {
                        solrQ += " OR ";
                    }
                    if (types[i] == 9) {
                        solrQ += "typeCode:[5 TO 7]";
                    } else {
                        solrQ += "typeCode:" + types[i];
                    }
                }
                solrQ += ")";
            }

            // tree
            if (StringUtils.isNotBlank(queryvo.getTreeId())) {
                solrQ += " AND (treeId:\"" + queryvo.getTreeId() + "\")";
            } else if (StringUtils.isNotBlank(queryvo.getNodeId())) {
                solrQ += " AND (nodeId:\"" + queryvo.getNodeId() + "\")";
            }

            // field
            Set<String> fieldSet = new HashSet<>();
            Set<String> modeFieldSet = new HashSet<>();

            if (queryvo.getMode() != null && StringUtils.isNotBlank(queryvo.getMode())) {
                modeFieldSet = SolrQueryFieldSet.getFieldSet(queryvo.getMode());
                for (String fieldStr : modeFieldSet) {
                    fieldSet.add(fieldStr);
                }
            }
            if (queryvo.getField() != null) {
                for (String fieldStr : queryvo.getField().replace("[", "").replace("]", "").split(",")) {
                    fieldSet.add(fieldStr);
                }
            }

            fieldSet = ParamUtils.permitFields(fieldSet, memberInfo.getPrivilege());

            if (fieldSet.size() > 0) {
                query.set("fl", fieldSet.toString().replace("[", "").replace("]", "").replace(" ", ""));
            }
            query.setQuery(solrQ);
            addShardsInQuery(query, countries, queryvo.isDocdb(), stat);
        }
        String cursorMark = queryvo.getCursorMark();
        
        if (cursorMark != null && !cursorMark.isEmpty()) {
            query.set("cursorMark", cursorMark);
        }
        
        if (queryvo.isFacet()) {
            query.set("facet", queryvo.isFacet());
            query.set("facet.limit", queryvo.getFacetLimit());
            query.set("facet.offset", queryvo.getFacetOffset());
            query.set("facet.mincount", 1);
            query.set("f.appYear.facet.sort", queryvo.getFacetSort());
            query.set("f.openYear.facet.sort", queryvo.getFacetSort());
            query.set("f.decisionYear.facet.sort", queryvo.getFacetSort());
            Set<String> facetFields = SolrUtils.getFacetFields(queryvo);
            for (String facetField : facetFields) {
                query.addFacetField(facetField);
            }
        }
        if (queryvo.isGroup()) {
            query.set("group", queryvo.isGroup());
            query.set("group.field", queryvo.getGroupField().toString());
            query.set("group.limit", queryvo.getGroupLimit());
        }        
        query.set("wt", "json");
        return query;
    }

    public static SolrQueryResult queryInfos(SolrQuery solrQuery) throws SolrServerException, IOException {
        QueryResponse response = query(solrQuery);
        log.info("QueryResponse: {}", response);
        SolrQueryResult solrQueryResult = new SolrQueryResult();
        solrQueryResult.setPatentInfoList(response.getBeans(PatentInfo.class));
        solrQueryResult.setNumFound(response.getResults().getNumFound());
        return solrQueryResult;
    }

    public static QueryResponse query(SolrQuery query) throws SolrServerException, IOException {
        // just reuse the unique HttpClient instance of the SolrServiceClient
        HttpClient httpClient = SolrServiceClient.getInstance().getHttpClient();

        String solrUrl = getSolrUrl("wo");
        HttpSolrClient client = new HttpSolrClient(solrUrl, httpClient);

        if (log.isInfoEnabled()) {
            String queryString = query.toString();
            StringBuilder debuggingUrl = new StringBuilder(solrUrl);
            debuggingUrl.append("/select/?").append("wt=json&").append(queryString);

            log.info("Send a POST reuqest to Solr server. debugging url: {}", debuggingUrl);
        }

        QueryResponse response = null;
        try {
            response = client.query(query, METHOD.POST);

        } catch (SolrServerException | IOException e) {
            throw e;

        } finally {
            IOUtils.closeQuietly(client);
        }

        return response;
    }

//    public static String getUrlSelect(String country) {
//        StringBuilder solrUrlSb = new StringBuilder();
//
//        if (country.equals("wo")) {
//            String solrShard = ConfigProperties.getInstance().getString("solr.shard." + country.toLowerCase());
//            solrUrlSb.append("http://");
//            solrUrlSb.append(solrShard);
//            solrUrlSb.append("/select/");
//
//        } else {
//            String solrUrl = ConfigProperties.getInstance().getString("solr.url");
//            solrUrlSb.append(solrUrl);
//            solrUrlSb.append(country);
//            solrUrlSb.append("/select/");
//        }
//
//        return solrUrlSb.toString();
//    }
    public static String getUrlSelect(SolrQuery solrQuery) {
        String solrShard = null;

        String shards = solrQuery.get("shards");
        if (shards != null) {
            solrShard = shards.split(",")[0];
        }
        if (StringUtils.isBlank(solrShard)) {
            solrShard = solrShardMap.values().iterator().next();
        }

        StringBuilder solrUrlSb = new StringBuilder();
        solrUrlSb.append("http://");
        solrUrlSb.append(solrShard);
        solrUrlSb.append("/select/");
        return solrUrlSb.toString();
    }

    /**
     * 要取得某 core 的 solrUrl，會先查 solr.url.core的設定，若沒有，則轉換 shard ip 為 solr url
     */
    public static String getSolrUrl(String core) {
        String shardCore = "solr.shard." + core.toLowerCase();
        String solrUrl = ConfigProperties.getInstance().getString(shardCore);

        if (StringUtils.isBlank(solrUrl)) {
            solrUrl = ConfigProperties.getInstance().getString("solr.url");
        } else {
            solrUrl = "http://" + solrUrl;
        }

        return solrUrl;
    }

    public static Set<String> getFacetFields(SolrQueryVO solrQueryVO) {
        Set<String> fieldsModeList = new HashSet<>();
        String facetFieldMode = "";
        if (solrQueryVO.getFacetFieldMode() != null) {
            facetFieldMode = solrQueryVO.getFacetFieldMode().toLowerCase();
        }
        switch (facetFieldMode.toLowerCase()) {
        case "all":
        case "patent_facet":
            fieldsModeList = SolrQueryFieldSet.PATENT_FACET;
            break;
        default:
            break;
        }
        List<String> facetFields = solrQueryVO.getFacetField();
        
        if (facetFields != null && !facetFields.get(0).equals("") && !facetFieldMode.equals("all")) {
            int length = facetFields.size();
            for (int i = 0; i < length; i++) {
                boolean add = false;
                for (String field : fieldsModeList) {
                    if (field.toLowerCase().equals(facetFields.get(i).toLowerCase())) {
                        add = true;
                        break;
                    }
                }
                if (!add) {
                    fieldsModeList.add(facetFields.get(i));
                }
            }
        }
        return fieldsModeList;
    }

    public static String getPatentDataPath(SolrPatentInfo info) {
        if (info == null || info.pto == null || info.pto.length() < 1 || info.country == null
                || info.country.length() < 1 || info.stats == null || info.stats.size() < 1 || info.doDate == null) {
            return "";
        }
        String country = info.country.toLowerCase();
        String patentNumber = "";
        if (country.equals("jp") && info.patentNumber != null && info.patentNumber.length() > 0) {
            patentNumber = info.patentNumber;
        } else if (country.equals("cn") || country.equals("kr")) {
            patentNumber = info.appNumber;
        } else {
            if (info.decisionNumberAll != null && info.decisionNumberAll.size() > 0) {
                patentNumber = info.decisionNumberAll.get(0);
            } else if (info.certificateNumberAll != null && info.certificateNumberAll.size() > 0) {
                patentNumber = info.certificateNumberAll.get(0);
            } else if (info.openNumberAll != null && info.openNumberAll.size() > 0) {
                patentNumber = info.openNumberAll.get(0);
            }
        }
        if (patentNumber == null || patentNumber.length() < 1) {
            return "";
        }
        patentNumber = patentNumber.replaceAll("[\\/\\s]", "").toLowerCase();
        String stat = info.stats.get(0).toString();
        String kindcode = info.kindcode != null && info.kindcode.length() > 0 ? info.kindcode.toLowerCase() : "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String doDate = sdf.format(info.doDate);
        if (country.equals("us") && patentNumber.length() <= 9 && !patentNumber.startsWith("us")) {
            patentNumber = "us" + "000000000".substring(0, 9 - patentNumber.length()) + patentNumber;
        }
        if (country.matches("wo|ep") && kindcode.length() > 0 && !patentNumber.endsWith(kindcode)) {
            patentNumber += kindcode;
        }
        String path = country + stat + kindcode + "/" + doDate + "/" + patentNumber;
        if (country.equals("cn") && info.type != null && info.type.length() > 0) {
            path = path + "/" + info.type;
        }
        return path;
    }
}
