package com.patentcloud.api.model;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class RequestLog {

    private final String clientId;

    private final String clientHost;

    private final String servicePath;

    private final Map<String, String[]> parameter;

    private final int httpStatus;

    private final String errorMessage;

    private final Date createdDateTime;

    private final long executionTime;

    public RequestLog(String clientId, String clientHost, String servicePath, Map<String, String[]> parameter,
            int httpStatus, String errorMessage, long executionTime) {
        this.clientId = clientId;
        this.clientHost = clientHost;
        this.servicePath = servicePath;
        this.parameter = parameter;
        this.httpStatus = httpStatus;
        this.errorMessage = errorMessage;
        this.createdDateTime = new Date();
        this.executionTime = executionTime;
    }

    public String getClientId() {
        return clientId;
    }

    public String getClientHost() {
        return clientHost;
    }

    public String getServicePath() {
        return servicePath;
    }

    public Map<String, String[]> getParameter() {
        return parameter;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public long getExecutionTime() {
        return executionTime;
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE).append("clientId", this.clientId)
                .append("clientHost", this.clientHost).append("servicePath", this.servicePath)
                .append("httpStatus", this.httpStatus).append("errorMessage", this.errorMessage)
                .append("createdDateTime", this.createdDateTime).append("executionTime", this.executionTime).build();
    }
}
