package com.patentcloud.api.constant;

public enum Pto {
    USPTO, US, TIPO, TW, CNIPR, CN, JPO, JP, KIPO, KR, EPO, EP, WIPO, WO, DPMA, DE, INPI, FR, UKIPO, DOCDB, GB, IGE, CH, ES, EM, AU, CA, AT, NL, MX, RU, BE, BG, SE, UA, HK, ZA, SA, SG, UM, IE, NO, NZ, TM, IS, TV, DK, FI, SU, PL, WF, SV, JO, HU, LU, IT, PT, BR, GR, IL, MC, YU, RO, PH, CS, AR, DD, LK, IN, OA, TN, KP, EG, HT, IR, ZM, ZW, SI, HR, ID, CZ, AP, LV, BY, SY, CU, AM, CL, GE, MY, KZ, CM, MD, SK, MK, MA, UY,
    // added by yiyun
    TR, LT, EA, UZ, AL, KE, VN, EE, BA, PA, LS, RS, GH, CR, SD, PE, CO, BH, DZ, AE, BI, TH, BW, AZ, IB, GT, EC, TT, VE, CY, MG, BD, SM, GC, MT, PK, KG, NG, SB, MO, DO, MN, NP, AW, LY, SL, TZ, GF, PY, ME, NA, AO, BS, RH, IQ, LA, LB, HN, MU, ML, QA, CI, GA, CG, PC, JM, KW, UG, MZ, BO,
    // added by luken
    SP, EU, PZ, FL, NC, WI, NR, ED, PP, CD, HG, GM, SW, SH, UK, NE, AK, IK, LI, NT, GY, GS, FU, DC, RV, NI, JR, ET, OH,
    // add by genchi
    OHIM, PCT, EPC, KH,
    // USPTO
    SN, QZ, YE, AI, BX, XX, DJ, BB, CV, WP, ER, DM, RE, FX, AD, TC, JE, SR, of, BZ, GN, jp, IO, KN, wo, VA, ep, BN, PG, TL, TD, Wo, GP, JA, XH, AG, SZ, GD, SC, FO, FK, TJ, USA, GG, LVA, FJ, np, DT, OM, DL, UGIPO, Th, NN,
}