package com.patentcloud.api.util.http;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.google.gson.JsonObject;

/**
 * A immutable configuration container holds the required and optional
 * properties for Solr service client. It is created by according to Builder
 * pattern.
 * 
 * @author Allan Huang
 */
public class SolrServiceClientConfig {
    // optional parameters
    /**
     * The maximum number of total open connections.
     */
    private final int maxTotalConnection;

    /**
     * The time to establish the connection with the remote host
     */
    private final int maxConnectionTimout;

    /**
     * The time waiting for data – after the connection was established; maximum
     * time of inactivity between two data packets
     */
    private final int maxSocketTimeout;

    /**
     * The time to wait for a connection from the connection manager/pool
     */
    private final int maxConnectionRequestTimeout;

    private SolrServiceClientConfig(Builder builder) {
        this.maxTotalConnection = builder.maxTotalConnection;
        this.maxConnectionTimout = builder.maxConnectionTimout;
        this.maxSocketTimeout = builder.maxSocketTimeout;
        this.maxConnectionRequestTimeout = builder.maxConnectionRequestTimeout;
    }

    public int getMaxTotalConnection() {
        return maxTotalConnection;
    }

    public int getMaxConnectionTimout() {
        return maxConnectionTimout;
    }

    public int getMaxSocketTimeout() {
        return maxSocketTimeout;
    }

    public int getMaxConnectionRequestTimeout() {
        return maxConnectionRequestTimeout;
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("maxTotalConnection", this.maxTotalConnection)
                .append("maxConnectionTimout", this.maxConnectionTimout)
                .append("maxSocketTimeout", this.maxSocketTimeout)
                .append("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout).build();
    }

    public JsonObject toJsonObject() {
        JsonObject infoJson = new JsonObject();

        infoJson.addProperty("maxTotalConnection", this.maxTotalConnection);
        infoJson.addProperty("maxConnectionTimout", this.maxConnectionTimout);
        infoJson.addProperty("maxSocketTimeout", this.maxSocketTimeout);
        infoJson.addProperty("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout);

        return infoJson;
    }

    // Builder Class
    public static class Builder {

        private int maxTotalConnection;

        private int maxConnectionTimout;

        private int maxSocketTimeout;

        private int maxConnectionRequestTimeout;

        public Builder() {
        }

        public Builder setMaxTotalConnection(int maxTotalConnection) {
            this.maxTotalConnection = maxTotalConnection;

            return this;
        }

        public Builder setMaxConnectionTimout(int maxConnectionTimout) {
            this.maxConnectionTimout = maxConnectionTimout;

            return this;
        }

        public Builder setMaxSocketTimeout(int maxSocketTimeout) {
            this.maxSocketTimeout = maxSocketTimeout;

            return this;
        }

        public Builder setMaxConnectionRequestTimeout(int maxConnectionRequestTimeout) {
            this.maxConnectionRequestTimeout = maxConnectionRequestTimeout;

            return this;
        }

        public SolrServiceClientConfig build() {
            return new SolrServiceClientConfig(this);
        }

        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.NO_CLASS_NAME_STYLE)
                    .append("maxTotalConnection", this.maxTotalConnection)
                    .append("maxConnectionTimout", this.maxConnectionTimout)
                    .append("maxSocketTimeout", this.maxSocketTimeout)
                    .append("maxConnectionRequestTimeout", this.maxConnectionRequestTimeout).build();
        }
    }
}