package com.patentcloud.api.util;

import java.util.Arrays;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringContextUtil implements ApplicationContextAware {

    private static final Logger log = LoggerFactory.getLogger(SpringContextUtil.class);

    private static ApplicationContext appContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        setContext(applicationContext);
    }

    public static synchronized ApplicationContext loadContext() {
        if (appContext == null) {
            log.info("load application context from conf/spring.properties");

            ResourceBundle rsb = null;

            try {
                rsb = ResourceBundle.getBundle("conf.spring");
            } catch (MissingResourceException e) {
                log.error("miss spring.properties", e);
                throw new IllegalArgumentException("miss spring.properties");
            }

            if (rsb != null) {
                String files = rsb.getString("files");
                if (files != null) {
                    loadContext(files.split(","));
                }
            }
        }

        return appContext;
    }

    public static synchronized ApplicationContext loadContext(String[] xmlFiles) {
        if (appContext == null) {
            log.info("Loading context for locations: {}", Arrays.toString(xmlFiles));

            appContext = new ClassPathXmlApplicationContext(xmlFiles);

            if (appContext instanceof AbstractApplicationContext) {
                ((AbstractApplicationContext) appContext).registerShutdownHook();
            }
        }

        return appContext;
    }

    public static void closeContext() {
        if (appContext != null && appContext instanceof AbstractApplicationContext) {
            ((AbstractApplicationContext) appContext).close();
        }
    }

    public static synchronized void setContext(ApplicationContext context) {
        SpringContextUtil.appContext = context;
    }

    private static ApplicationContext getContext() {
        if (appContext == null) {
            loadContext();
        }
        return appContext;
    }

    // BeanFactory

    public static Object getBean(String name) throws BeansException {
        return getContext().getBean(name);
    }

    public static Object getBean(String name, Class<?> requiredType) throws BeansException {
        return getContext().getBean(name, requiredType);
    }

    public static boolean containsBean(String name) {
        return getContext().containsBean(name);
    }

    public static boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
        return getContext().isSingleton(name);
    }

    public static Class<?> getType(String name) throws NoSuchBeanDefinitionException {
        return getContext().getType(name);
    }

    public static String[] getAliases(String name) throws NoSuchBeanDefinitionException {
        return getContext().getAliases(name);
    }
}
