package com.patentcloud.api.server.service;

import com.patentcloud.api.model.Member;

public interface MemberService {

    Member getCurrentMemberInfo();

    Member getMemberInfo(String account);
}
