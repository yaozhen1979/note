package com.patentcloud.api.server.dao.common;

import org.apache.commons.lang3.exception.ContextedRuntimeException;
import org.apache.commons.lang3.exception.ExceptionContext;

/**
 * Exception thrown when failed to perform an operation to the MongoDB server.
 * 
 * @author Allan Huang
 */
public class MongoDbClientException extends ContextedRuntimeException {

    private static final long serialVersionUID = 8557037031207967781L;

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     */
    public MongoDbClientException(String message) {
        super(message);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * 
     */
    public MongoDbClientException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * @param cause
     *            the cause of this exception
     */
    public MongoDbClientException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * @param cause
     *            the cause of this exception
     * @param context
     *            a context stores the contextual information
     */
    public MongoDbClientException(String message, Throwable cause, ExceptionContext context) {
        super(message, cause, context);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.commons.lang3.exception.ContextedRuntimeException#
     * addContextValue(java.lang.String, java.lang.Object)
     */
    public MongoDbClientException addContextValue(String label, Object value) {
        super.addContextValue(label, value);

        return this;
    }
}
