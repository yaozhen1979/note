package com.patentcloud.api.exception;

import org.apache.commons.lang3.exception.ContextedException;
import org.apache.commons.lang3.exception.ExceptionContext;

/**
 * Exception thrown when failed to find the specified PNG image/PDF page of a
 * patent
 * 
 * @author Allan Huang
 */
public class PatentFileNotFoundException extends ContextedException {

    private static final long serialVersionUID = 3018416831711776525L;

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     */
    public PatentFileNotFoundException(String message) {
        super(message);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * 
     */
    public PatentFileNotFoundException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * @param cause
     *            the cause of this exception
     */
    public PatentFileNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the description of this exception
     * @param cause
     *            the cause of this exception
     * @param context
     *            a context stores the contextual information
     */
    public PatentFileNotFoundException(String message, Throwable cause, ExceptionContext context) {
        super(message, cause, context);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.apache.commons.lang3.exception.ContextedRuntimeException#
     * addContextValue(java.lang.String, java.lang.Object)
     */
    public PatentFileNotFoundException addContextValue(String label, Object value) {
        super.addContextValue(label, value);

        return this;
    }
}
