package com.patentcloud.api.web;

import java.io.IOException;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.lang3.exception.ContextedRuntimeException;
import org.logicalcobwebs.proxool.ProxoolException;
import org.logicalcobwebs.proxool.ProxoolFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.patentcloud.api.server.dao.common.MongoDbClient;
import com.patentcloud.api.server.dao.util.JdbcUtils;
import com.patentcloud.api.util.http.SolrServiceClient;
import com.patentcloud.api.util.http.external.DownloadServiceClient;
import com.patentcloud.api.util.nlp.NlpServiceClient;

@WebListener
public class MultipurposeListener implements ServletContextListener {

    private static final Logger log = LoggerFactory.getLogger(MultipurposeListener.class);

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }

    @Override
    public void contextInitialized(ServletContextEvent event) {
        ServletContext context = event.getServletContext();
        log.info("Start to initialize web context. context path: {}", context.getContextPath());

        log.info("Start to start up SolrServiceClient...");
        SolrServiceClient.getInstance().startUp();

        log.info("Start to start up NlpServiceClient...");
        NlpServiceClient.getInstance().startUp();

        log.info("Start to start up DownloadServiceClient...");
        DownloadServiceClient.getInstance().startUp();

        log.info("Start to start up MongoDbClient...");
        MongoDbClient.getInstance().startUp();

        log.info("Start to load Proxool connection pool...");

        try {
            JdbcUtils.loadProxoolConnectionPool();

        } catch (ProxoolException | IOException e) {
            log.error("Failed to load Proxool connection pool.", e);

            throw new ContextedRuntimeException("Failed to load Proxool connection pool.", e);
        }

        log.info("Finish to initialize web context.");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        log.info("Start to destroy web context...");

        // shutdown SolrServiceClient and close all associated resources
        SolrServiceClient.getInstance().shutdown();

        // shutdown NlpServiceClient and close all associated resources
        NlpServiceClient.getInstance().shutdown();

        // shutdown DownloadServiceClient and close all associated resources
        DownloadServiceClient.getInstance().shutdown();

        // shutdown MongoDbClient and close all associated resources
        MongoDbClient.getInstance().shutdown();

        // shutdown proxool that will remove all connection pools.
        log.info("Start to shutdown proxool.");
        ProxoolFacade.shutdown(3);

        // deregister JDBC drivers
        log.info("Start to deregister JDBC drivers.");
        JdbcUtils.deregisterJdbcDrivers();

        log.info("Finish to destroy web context.");
    }
}
