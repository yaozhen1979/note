package test.com.patentcloud.api;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import com.patentcloud.api.server.dao.util.JdbcUtils;

@TestExecutionListeners({ TestExecutionListener.class })
@ContextConfiguration(locations = { "classpath:conf/spring/appContext_test.xml",
        "classpath:conf/spring/appContext_service.xml" })
public abstract class AbstractJUnit4TestCase extends AbstractTransactionalJUnit4SpringContextTests {
}

class TestExecutionListener implements org.springframework.test.context.TestExecutionListener {

    private static void loadProxool() throws Exception {
        JdbcUtils.loadProxoolConnectionPool();
    }

    @Override
    public void beforeTestClass(TestContext testContext) throws Exception {
        loadProxool();
    }

    @Override
    public void prepareTestInstance(TestContext testContext) throws Exception {
    }

    @Override
    public void beforeTestMethod(TestContext testContext) throws Exception {
    }

    @Override
    public void afterTestMethod(TestContext testContext) throws Exception {
    }

    @Override
    public void afterTestClass(TestContext testContext) throws Exception {
    }
}
