package test.com.patentcloud.api;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.patentcloud.api.model.RequestLog;
import com.patentcloud.api.server.dao.common.MongoDbClient;
import com.patentcloud.api.server.dao.common.MongoDbClientConfig;
import com.patentcloud.api.util.config.ConfigProperties;

@Ignore
public class MongoDbClientTest {

    private static final Logger log = LoggerFactory.getLogger(MongoDbClientTest.class);

    @Rule
    public Timeout globalTimeout = Timeout.seconds(15);

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        MongoDbClient.getInstance().startUp();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        MongoDbClient.getInstance().shutdown();
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void insertLog_1() throws Exception {
        Map<String, String[]> parameter1 = new HashMap<>();
        parameter1.put("sort", new String[] { "appDate.desc" });
        parameter1.put("docdb", new String[] { "true" });
        parameter1.put("start", new String[] { "0" });
        parameter1.put("query", new String[] { "allStem:led" });
        parameter1.put("state", new String[] { "1" });
        parameter1.put("solrsyntax", new String[] { "true" });
        parameter1.put("litigation", new String[] { "true" });
        parameter1.put("stem", new String[] { "true" });
        parameter1.put("type", new String[] { "1", "2" });
        parameter1.put("mode", new String[] { "PATENT_LIST" });
        parameter1.put("country", new String[] { "tw", "us" });
        parameter1.put("rows", new String[] { "30" });
        parameter1.put("client_host", new String[] { "ALLANHUANG/10.60.91.66" });
        parameter1.put("access_token", new String[] { "50505b7d-1dab-424a-b50f-236712cade40" });

        Map<String, String[]> parameter2 = new HashMap<>();
        parameter2.put("sort", new String[] { "score.desc", "appDate.desc" });
        parameter2.put("ptopid", new String[] { "DOCDB.55a95160b4411f24f11bd8d5" });
        parameter2.put("litigation", new String[] { "false" });
        parameter2.put("mode", new String[] { "PATENT_INFO" });
        parameter2.put("client_host", new String[] { "ALLANHUANG/10.60.91.66" });
        parameter2.put("access_token", new String[] { "50505b7d-1dab-424a-b50f-236712cade40" });

        for (int i = 0; i < 10; i++) {
            RequestLog log1 = new RequestLog("patentcloud", "ALLANHUANG/10.60.91.66", "/1/PatentList", parameter1, 200,
                    null, 100);
            MongoDbClient.getInstance().insertLog(log1);

            RequestLog log2 = new RequestLog("patentcloud", "ALLANHUANG/10.60.91.66", "/1/PatentInfo", parameter2, 200,
                    null, 200);
            MongoDbClient.getInstance().insertLog(log2);
        }
    }

    @Test
    public void testMongoDbInsertion() throws Exception {
        MongoDbClientConfig config = ConfigProperties.getInstance().getMongoDbClientConfig();

        ServerAddress serverAddress = new ServerAddress(config.getMongoDbHost(), config.getMongoDbPort());
        List<MongoCredential> credentialsList = Collections.singletonList(
                MongoCredential.createCredential(config.getUserName(), "admin", config.getPassword().toCharArray()));

        MongoClient mongoClient = new MongoClient(serverAddress, credentialsList);
        MongoDatabase logDatabase = mongoClient.getDatabase(config.getMongoDbName());

        Map<String, String[]> parameter = new HashMap<>();
        parameter.put("sort", new String[] { "score.desc", "appDate.desc" });
        parameter.put("ptopid", new String[] { "DOCDB.55a95160b4411f24f11bd8d5" });
        parameter.put("litigation", new String[] { "false" });
        parameter.put("mode", new String[] { "PATENT_INFO" });
        parameter.put("client_host", new String[] { "ALLANHUANG-X2/10.60.91.66" });
        parameter.put("access_token", new String[] { "50505b7d-1dab-424a-b50f-236712cade40" });

        RequestLog requestLog = new RequestLog("patentcloud", "ALLANHUANG-X2/10.60.91.66", "/1/PatentInfo", parameter,
                200, null, 300);

        Document paramDocument = new Document();
        Set<Entry<String, String[]>> parameterSet = parameter.entrySet();

        for (Entry<String, String[]> paramEntry : parameterSet) {
            String[] valueArray = paramEntry.getValue();
            List<String> valueList = Arrays.asList(valueArray);
            paramDocument.append(paramEntry.getKey(), valueList);
        }

        Document logDocument = new Document("clientId", requestLog.getClientId())
                .append("clientHost", requestLog.getClientHost()).append("servicePath", requestLog.getServicePath())
                .append("parameter", paramDocument).append("httpStatus", requestLog.getHttpStatus())
                .append("createdDateTime", requestLog.getCreatedDateTime())
                .append("executionTime", requestLog.getExecutionTime());

        MongoCollection<Document> logCollection = logDatabase.getCollection("Log");
        logCollection.insertOne(logDocument);
        ObjectId oid = logDocument.getObjectId("_id");

        log.info("A log's mongo oid: {}", oid);

        mongoClient.close();
    }
}
