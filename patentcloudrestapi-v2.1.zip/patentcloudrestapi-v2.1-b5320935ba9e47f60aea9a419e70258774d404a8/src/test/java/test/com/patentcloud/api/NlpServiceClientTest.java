package test.com.patentcloud.api;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.patentcloud.api.util.nlp.NlpResult;
import com.patentcloud.api.util.nlp.NlpServiceClient;
import com.patentcloud.api.util.nlp.parameter.KeywordExtractorParameter;
import com.patentcloud.api.util.nlp.parameter.QueryExpansionParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByBriefParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryByClaimParameter;
import com.patentcloud.api.util.nlp.parameter.SimpleQueryParameter;

public class NlpServiceClientTest {

    private static final Logger log = LoggerFactory.getLogger(NlpServiceClientTest.class);

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        NlpServiceClient.getInstance().startUp();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        NlpServiceClient.getInstance().shutdown();
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getSimpleQuery_1() throws Exception {
        SimpleQueryParameter parameter = new SimpleQueryParameter.Builder(
                "A mobility scooter is a mobility aid equivalent to a wheelchair but configured like a motorscooter.",
                "patentcloud", "memberId", new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQuery(parameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonElement solrQueryStrJson = nlpResultJson.get("solrQueryStr");
        Assert.assertNotNull(solrQueryStrJson.getAsString());
    }

    @Test
    public void getSimpleQuery_2() throws Exception {
        SimpleQueryParameter parameter = new SimpleQueryParameter.Builder("AN/Oracle", "patentcloud", "memberId",
                new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQuery(parameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonElement solrQueryStrJson = nlpResultJson.get("solrQueryStr");
        Assert.assertNotNull(solrQueryStrJson.getAsString());

        String nlSolrQuery = solrQueryStrJson.getAsString();
        log.debug("Get nlSolrQuery: {}", nlSolrQuery);
    }

    @Test
    public void getSimpleQuery_3() throws Exception {
        SimpleQueryParameter nlpParameter = new SimpleQueryParameter.Builder("物聯網 感測器", "patentcloud", "memberId",
                new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQuery(nlpParameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonElement solrQueryStrJson = nlpResultJson.get("solrQueryStr");
        Assert.assertEquals("all:((物聯網 AND 感測器))", solrQueryStrJson.getAsString());
    }

    @Test
    public void getSimpleQueryByBrief_1() throws Exception {
        SimpleQueryByBriefParameter parameter = new SimpleQueryByBriefParameter.Builder(
                "An embedded system is a computer system with a dedicated function within a larger mechanical or electrical system, often with real-time computing constraints",
                "patentcloud", "memberId", new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQueryByBrief(parameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonElement solrQueryStrJson = nlpResultJson.get("solrQueryStr");
        Assert.assertNotNull(solrQueryStrJson.getAsString());

        String nlSolrQuery = solrQueryStrJson.getAsString();
        log.debug("Get nlSolrQuery: {}", nlSolrQuery);
    }

    @Test
    public void getSimpleQueryByClaim_1() throws Exception {
        SimpleQueryByClaimParameter nlpParameter = new SimpleQueryByClaimParameter.Builder(
                "1. An inhibitory nucleic acid that specifically binds, or is complementary to, an RNA that is known to bind to Polycomb repressive complex 2 (PRC2), selected from the group consisting of SEQ ID NOS: 632,564, 1 to 916,209, or 916,626 to 934,931, for use in the treatment of disease, wherein the treatment involves modulating expression of a gene targeted by the RNA, wherein the inhibitory nucleic acid is between 5 and 40 bases in length, and wherein the inhibitory nucleic acid is formulated as a sterile composition.",
                "patentcloud", "memberId", new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findSimpleQueryByClaim(nlpParameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonElement solrQueryStrJson = nlpResultJson.get("solrQueryStr");
        Assert.assertNotNull(solrQueryStrJson.getAsString());

        String nlSolrQuery = solrQueryStrJson.getAsString();
        log.debug("Get nlSolrQuery: {}", nlSolrQuery);
    }

    @Test
    public void getKeywordExtractor_1() throws Exception {
        KeywordExtractorParameter parameter = new KeywordExtractorParameter.Builder(
                "A mobility scooter is a mobility aid equivalent to a wheelchair but configured like a motorscooter.",
                "patentcloud", "memberId", new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findKeywordExtraction(parameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonArray keywordsJson = nlpResultJson.getAsJsonArray("keywords");
        Assert.assertNotNull(keywordsJson);
        Assert.assertTrue(keywordsJson.size() > 0);
    }

    @Test
    public void getQueryExpansion_1() throws Exception {
        QueryExpansionParameter parameter = new QueryExpansionParameter.Builder("mobility scooter", "patentcloud",
                "memberId", new Date()).build();

        NlpResult nlpResult = NlpServiceClient.getInstance().findQueryExpansion(parameter);
        Assert.assertNotNull(nlpResult);

        JsonObject nlpResultJson = nlpResult.getEntityAsJsonObject();
        Assert.assertNotNull(nlpResultJson);

        JsonArray identicalWordsJson = nlpResultJson.getAsJsonArray("identical words");
        Assert.assertNotNull(identicalWordsJson);
        Assert.assertTrue(identicalWordsJson.size() > 0);
    }
}
