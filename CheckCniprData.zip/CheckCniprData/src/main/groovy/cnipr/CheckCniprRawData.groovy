/**
 * 檢查由CNIPR下戴回的資料中的_data.txt, 其appNumber和folder name的appNumber是否一樣
 *
 * _data.txt
 * bibliography.html
 * claim.xml
 * description.xml
 *
 */

// T:\cnlist\rawdata\FM\20150624\201110266030.3

// 20150729: FM, SD, WG 已驗證OK
def type = "SD"
def findDate = "20140122"
def year = "2014"
def wg = ""
// def findDate = "20150000"
// def appNumber = "201110266030.3"

def emptyFileList = [];

def count = 0

def ln = System.getProperty('line.separator')

File log = new File("log/checkCniprRawData-${type}-${findDate}.txt")

// File rawFolder = new File("T:/cnlist/rawdata/${type}/${year}/${findDate}/")
File rawFolder = new File("D:/share/cnipr/${type}/${year}/${findDate}/")

/*
if (type == 'WG') {
    rawFolder = new File("T:/cnlist/rawdata/${type}/2015/${wg}/")
} else {
    rawFolder = new File("T:/cnlist/rawdata/${type}/2015/${findDate}/")
}
*/

println "checking...${type}-${findDate}"

rawFolder.eachFile() { outerFile ->
        
    def folderName = outerFile.name
    // println "origin folderName = ${folderName}"
    /*
     * 申請號有二種格式如 201320032255.7 or 2013200322557,
     * 目前決定以[201320032255.7]有dot有判斷依據.
     */
    if (!folderName.contains(".")) {
        def appNumber = folderName.substring(0, folderName.length() - 1)
        def checkNumber = folderName.substring(folderName.length() - 1, folderName.length())
        folderName = appNumber + "." + checkNumber
        // println "folderName = ${folderName}"
    }
    
    if (outerFile.isDirectory()) {
        
        def checkFile = ["_data.txt", "bibliography.html", "claim.xml", "description.xml"]
        
        outerFile.eachFile() { innerFile ->
            
            // println innerFile.name
            
            if (type != 'WG' && innerFile.name == '_data.txt') {
                
                checkFile.remove(innerFile.name)
                def dataMap = [:]
                innerFile.eachLine { line ->
                    def data = line.split("[\\s|\\t]")
                    if (data.size() > 1) {
                        dataMap.put(data[0], data[1])
                    }
                }
                // println dataMap
                if (!dataMap.get("anum").contains(folderName)) {
                    println "appNumber [${folderName}] check no good..."
                    log << "appNumber [${folderName}] check no good..." << ln
                } else {
                    // println "appNumber [${folderName}] check good..."
                }
            }
            
            if (type != 'WG' && (innerFile.name == 'bibliography.html' || innerFile.name == 'claim.xml' || innerFile.name == 'description.xml')) {
                //
                checkFile.remove(innerFile.name)
                //
                def fileContent = "";
                                
                innerFile.eachLine { line ->
                    fileContent = fileContent << line
                }
                                                
                if (fileContent.toString().trim().length() == 0) {
                    // emptyFileList << "${folderName}/${innerFile.getName()}"
                    println  "empty file = ${folderName}/${innerFile.getName()}"
                    log << "empty file = ${folderName}/${innerFile.getName()}" << ln
                }
                
            } else if (type == 'WG' && innerFile.name == 'bibliography.html') {
                //
                checkFile.remove(innerFile.name)
                //
                checkFile.remove("_data.txt")
                checkFile.remove("claim.xml")
                checkFile.remove("description.xml")
                //
                def fileContent = "";
                
                innerFile.eachLine { line ->
                    fileContent = fileContent << line
                }
                                                
                if (fileContent.toString().trim().length() == 0) {
                    // emptyFileList << "${folderName}/${innerFile.getName()}"
                    println  "empty file = ${folderName}/${innerFile.getName()}"
                    log << "empty file = ${folderName}/${innerFile.getName()}" << ln
                }
                
                // check bibliography.html 中的申請號是否會和folder中的申請號一樣
                // <span id="appNo">CN201430096086.3</span>
                // check folder name 是否等於 bibliography.html 中的 appNumber
                if (!fileContent.toString().contains("<span id=\"appNo\">CN${folderName}</span>")) {
                    println "${folderName}, folder name != appNumber in the bibliography"
                    log << "appNumber [${folderName}] check no good..." << ln
                }
                
            }
            
        }
        
        // println "checkFile = ${checkFile}"
        
        if (checkFile.size() == 0) {
            // println "all file exist..."
        } else {
            println "${folderName}-${checkFile} dont exist"
            log << "${folderName}-${checkFile} dont exist" << ln
        }
        
        // println "===============================================${++count}"
        // log << "===============================================${count}" << ln
        
    }
    
}
 
println "finished..."
