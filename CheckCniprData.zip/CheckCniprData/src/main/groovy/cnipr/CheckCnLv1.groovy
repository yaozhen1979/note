/**
 * 檢查CN LV1和CN appNumber的差異
 */

import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.util.DateUtils

// lv1 setting 10.60.90.127 27017 yyj yyj
// lv2 setting 10.60.90.121 27017 patentdata data.cloud.Abc12345

// Mongodb 2.X use createMongoCRCredential
// def lv1Auth = MongoCredential.createMongoCRCredential('yyj', 'admin', 'yyj' as char[])

// If you are using Mongodb 3.x you need to use MongoCredential#createCredential instead
def lv1Auth = MongoCredential.createMongoCRCredential('yyj', 'admin', 'yyj' as char[])

// "10.60.90.101", 27017
def lv1Client = new GMongoClient(new ServerAddress("10.60.90.127", 27017), [lv1Auth])

def patentRawCNIPR = lv1Client.getDB("PatentRawCNIPR");

/*
 * db.getCollection('PatentRawCNIPR').find({path: {$regex: /XX\/2015\/20150527/ }}).count()
 * db.getCollection('PatentRawCNIPR').find({doDate: {'$gt' : ISODate("2015-05-26T00:00:00Z")}}).count()
 */
// def lv1DataSize = patentRawCNIPR.PatentRawCNIPR.find(path: [$regex: /XX\/2015\/20150527/ ]).size()
// def lv1DataSize = patentRawCNIPR.PatentRawCNIPR.find(doDate: ['$gt' : DateUtils.parseDate("2015-05-26")]).size()
// println "lv1DataSize = ${lv1DataSize}"

def type= "XX"
def findDate = "20150624"

// T:\cnlist\appNumber\20150527
def srcFilePath = "T:\\cnlist\\appNumber\\${findDate}\\sipo-${type}-2015.06.24.txt"

def diffList = [];
def difflog = "log/find-LV1-${type}-diff-${findDate}-log.txt"

def ln = System.getProperty('line.separator')

File diffFile = new File(difflog)

println "start parsing..."

new File(srcFilePath).eachLine { line ->
    
    def appNo = line.substring(12)
    // XX/2015/20150624/201120358254.2
    def path = "XX/2015/20150624/${appNo}"
    // println "appNo = " + line.substring(12);
    
    def data = patentRawCNIPR.PatentRawCNIPR.find(path: path)
    
    if (data.size() == 0) {
        println "${line} data no exists"
        diffList << appNo
    }
    
    // wins: ${tarFilePath}\\${appNo}
    // unix: ${tarFilePath}/${appNo}
    // if (!new File("${tarFilePath}/${appNo}").exists()) {
    //     diffList << line
    // }
    
}

println diffList.size()

if (diffList.size() > 0) {
    //
    diffList.each{ it ->
        // println it
        diffFile << it << ln
    }
}

println "finished"