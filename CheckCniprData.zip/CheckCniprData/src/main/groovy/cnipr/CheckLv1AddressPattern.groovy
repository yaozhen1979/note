/**
 * 
 */

import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.util.DateUtils

def lv1Auth = MongoCredential.createMongoCRCredential('yyj', 'admin', 'yyj' as char[])
def lv1Client = new GMongoClient(new ServerAddress("10.60.90.127", 27017), [lv1Auth])
def patentRawCNIPR = lv1Client.getDB("PatentRawCNIPR");

def ln = System.getProperty('line.separator')

println "starting..."

//def count1 = patentRawCNIPR.PatentRawCNIPR.find([
//    doDate: DateUtils.parseDate("2015-07-08")
//]).count()
//
//// 54667
//println "count1 = ${count1}"
//
//// doDate: ISODate("2015-07-08 00:00:00.000Z"), 'data.bibliography':{$regex: /<td width="27%" align="right" bgcolor="#F4F4FF">\s*地址(:)?/g}
//def count2 = patentRawCNIPR.PatentRawCNIPR.find([
//    doDate: DateUtils.parseDate("2015-07-08"), 
//    'data.bibliography':[$regex: /<td width="27%" align="right" bgcolor="#F4F4FF">\s*地址(:)?/ ] 
//]).count()
//
//// 44366
//println "count2 = ${count2}"
//
//// doDate: ISODate("2015-07-08 00:00:00.000Z"), 'data.bibliography':{$regex: /<td width="27%" align="right" bgcolor="#F4F4FF">\s*地址(:)?/g}
//def count3 = patentRawCNIPR.PatentRawCNIPR.find([
//    doDate: DateUtils.parseDate("2015-07-08"),
//    'data.bibliography': ~/(?ms)地址:/
//]).count()
//
//// 44366
//println "count3 = ${count3}"

File temp1 = new File("log/temp/full_id.log")
patentRawCNIPR.PatentRawCNIPR.find([
    doDate: DateUtils.parseDate("2015-07-08")
]).each { it ->
    temp1 << it._id << ln
}

File temp2 = new File("log/temp/find_address_id.log")
patentRawCNIPR.PatentRawCNIPR.find([
    doDate: DateUtils.parseDate("2015-07-08"),
    'data.bibliography': ~/(?ms)地址:/
]).each { it ->
    temp2 << it._id << ln
}

println "finished"
