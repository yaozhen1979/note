/**
 * 檢查CN LV2和CN appNumber的差異 => find Lv2 Gap app number
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.util.DateUtils

// lv1 setting 10.60.90.127 27017 yyj yyj 
// lv2 setting 10.60.90.121 27017 patentdata data.cloud.Abc12345

// Mongodb 2.X use createMongoCRCredential
// def lv1Auth = MongoCredential.createMongoCRCredential('yyj', 'admin', 'yyj' as char[])

// If you are using Mongodb 3.x you need to use MongoCredential#createCredential instead
def lv2Auth = MongoCredential.createMongoCRCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])

def lv2Client = new GMongoClient(new ServerAddress("10.60.90.121", 27017), [lv2Auth])
def patentInfoCNIPR = lv2Client.getDB("PatentInfoCNIPR")

def type= "FM"
def findDate = "20150708"

// T:\cnlist\appNumber\20150527
def srcFilePath = "T:\\cnlist\\appNumber\\${findDate}\\sipo-${type}-${findDate.substring(0,4)}.${findDate.substring(4,6)}.${findDate.substring(6,8)}.txt"

def diffList = [];
def difflog = "log_lv2_gap/find-LV2-gap-${type}-${findDate}-log.txt"

def ln = System.getProperty('line.separator')

File diffFile = new File(difflog)

println "start ${type}-${findDate} parsing..."

new File(srcFilePath).eachLine { line ->
    
    def appNo = line.substring(12)
    
    // println "appNo = " + line.substring(12);
    
    def data = patentInfoCNIPR.PatentInfoCNIPR.find([appNumber: line.substring(12), doDate: DateUtils.parseDate("2015-07-08")])
    
    if (data.size() == 0) {
        println "${appNo} data no exists"
        diffList << appNo
    }
    
    // wins: ${tarFilePath}\\${appNo}
    // unix: ${tarFilePath}/${appNo}
    // if (!new File("${tarFilePath}/${appNo}").exists()) {
    //     diffList << line
    // }
    
}

println diffList.size()

if (diffList.size() > 0) {
    //
    diffList.each{ it ->
        // println it
        // format = XX\20150701\201520085573.9
        diffFile << "${type}\\${findDate}\\${it}" << ln
    }
}

println "finished"
