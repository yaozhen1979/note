/**
 *  由appNumber, 找出LV2 GAP的objectId.
 * 
 *  ref: http://stackoverflow.com/questions/1016278/is-this-the-best-way-to-rewrite-the-content-of-a-file-in-java
 */
import utils.MongoUtil

import org.bson.types.ObjectId
import org.common.util.DateUtils

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def db = client.getDB("PatentInfoCNIPR")

def count = 0;

def type = "SD"
def findDate = "20150527"
def doDate = DateUtils.parseDate(findDate)

def file = new File("log_lv2_gap/objectId/${type}-objectId-${findDate}.log")
// true to append
// false to overwrite.
FileWriter fileWriter = new FileWriter(file, false);
// fileWriter.write("New Contents\n");

new File("log_lv2_gap/bak/find-LV2-gap-${type}-${findDate}-log.txt").eachLine { line ->
    //
    def appNumber = line.split('\\\\')[2].trim()
    println "app number = ${appNumber}"
    
    db.PatentInfoCNIPR.find([appNumber: appNumber, doDate:doDate]).each { it ->
        //
        fileWriter << it._id << ln
        println it._id
        count++;
    }
    
}

fileWriter.close()

println "objectId count = ${count}"

println "finished..."
