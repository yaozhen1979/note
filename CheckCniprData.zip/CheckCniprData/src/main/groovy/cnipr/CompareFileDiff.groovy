/**
 * 
 * @author tonykuo
 * 
 * check CN 申請號和CNIPR rawdata中的申請號folder name是否有少
 *
 */

// T:\cnlist\20150520\\

// compare soure (file)
// T:\cnlist\20150520\sipo-WG-2015.05.20.txt
// T:\cnlist\20150520\sipo-XX-2015.05.20

// compare target (folder)
// T:\cnlist\rawdata\WG\2015\3120
// T:\cnlist\rawdata\XX\2015\20150520

def type= "WG"
def findDate = "0122"
def year = "2014"

def srcFilePath = "T:\\cnlist\\appNumber\\${year}${findDate}\\sipo-${type}-${year}.${findDate.substring(0,2)}.${findDate.substring(2,4)}.txt"
// println "srcFilePath = ${srcFilePath}"

// def tarFilePath = "T:\\cnlist\\rawdata\\${type}\\${year}\\${year}${findDate}"
def tarFilePath = "D:\\share\\cnipr\\${type}\\${year}\\${year}${findDate}"

def diffList = [];
def difflog = "diff_log/sipo-find-${type}-nofile-${year}${findDate}-log.txt"

def ln = System.getProperty('line.separator')

File diffFile = new File(difflog)

println "To start comparing raw data [${type}-${year}${findDate}] with app number size..."
println "parse file begin..."

new File(srcFilePath).eachLine { line ->
    
    // def appNo = line.substring(12)
    // println "appNo = " + line.substring(12);
    
    // for back file
    def appNo = line.substring(12).replace(".", "")
    // println "appNo = " + appNo
    
    // wins: ${tarFilePath}\\${appNo}
    // unix: ${tarFilePath}/${appNo}
    if (!new File("${tarFilePath}/${appNo}").exists()) {
        diffList << line
    }
    
}

println diffList.size()

diffList.each{ it ->
    // println it
    diffFile << it << ln
}

println "finished"
