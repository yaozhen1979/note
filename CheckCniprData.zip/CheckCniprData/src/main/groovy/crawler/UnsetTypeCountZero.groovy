/**
 * 臨時性script, 用完即可丟.
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
import org.common.utils.DateUtil

println "to start..."

System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentRawCN = client.getDB("PatentRawCN")

def dayList = utils.DateUtil.getEveryDayInYYYY(1988)

// def testList = ["1985-01-1"]

dayList.each { day ->
    
    def totalCount = 0
    
    patentRawCN.PatentCountCN.find([doDate: DateUtil.parseDate(day)]).each { it -> 
        
        // println "type = ${it.type}, count = ${it.count}"
        
        totalCount += it.count
        
    }
    
    // println "totalCount = ${totalCount}"
    
    if (totalCount == 0) {
        //
        patentRawCN.PatentCountCN.remove([doDate: DateUtil.parseDate(day)])
        println "${day} data remove"
    }
    
}

println "finished..."
