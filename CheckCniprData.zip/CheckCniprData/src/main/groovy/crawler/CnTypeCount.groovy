/**
 * 計算現有DB[PatentRawCN.PatentCountCN]中的type[FM, SD, XX, WG] total count, 和SIPO中的是有一致.
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
import org.common.utils.DateUtil

println "to start..."

System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentRawCN = client.getDB("PatentRawCN")

def yearList = utils.DateUtil.getEveryDayInYearInterval(1985, 2015)

// def testList = ["1985-01-1"]

def totalCount = 0

def type = "FM"

yearList.each { year, dayList ->
    
    def yearCount = 0
    
    dayList.each { day -> 
    
        // type = FM, SD, XX, WG
        patentRawCN.PatentCountCN.find([doDate: DateUtil.parseDate(day), type: ${type}]).each { it ->
    
            // println "type = ${it.type}, count = ${it.count}"
    
            yearCount += it.count
    
        }
    }
    
    totalCount += yearCount
    
    println "${type} ${year} totalCount = ${totalCount}"
}

println "finished..."
