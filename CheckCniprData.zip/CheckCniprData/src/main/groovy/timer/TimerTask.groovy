import java.util.timer.*

def count = 0

new Timer().schedule({ println count++ } as TimerTask, 1000, 3000)
