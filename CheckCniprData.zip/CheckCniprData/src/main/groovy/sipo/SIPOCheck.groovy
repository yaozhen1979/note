@Grab('org.jsoup:jsoup:1.7.1')

/**
 * 給定一個目錄(Q:\Other\SIPO申請號下載)，會盤查所有以年份為主的擋案。
 * 若有重複，會寫到新檔 (-new結尾)，數量與官網不一致會列出來筆數差異。
 */
import groovy.io.FileType

System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' ]

// T:\cnlist\appNumber
def dir = new File("T:/cnlist/appNumber")

dir.eachFileRecurse (FileType.FILES) { file ->
    
    if (file.name == 'sipo.groovy') {
        return
    }
        
    println 'file:' + file.name
    
    def querydate = file.name.substring(5, 9);
    def type = file.name.substring(10, 11) as int;
    def set = new HashSet()
    def cnt = 0;
    
    file.eachLine { line ->
        set << line;
        cnt++;
    }
    
    if (cnt != set.size()) {
        println 'duplicate:' + cnt + ' vs ' + set.size()
        def newfile = new File(dir, file.name + '-new');
        set.each {
            newfile << it << '\n'
        }
        println 'save to new file finish.'
    }
    
    println 'count:' + set.size()
    
    def doc = null;
    def retry = 0;
    while (retry < 10)  {
        
        try {
            doc = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/patentoutline.action").timeout(300000)
                    .data("showType", "1")
                    .data("strWord", "公开（公告）日='${querydate}'")
                    //.data("strWord", "公开（公告）日=BETWEEN['${date.format('yyyy.MM.dd')}','${enddate.format('yyyy.MM.dd')}']")
                    .data("pageSize", '3')
                    .data("pageNow", '1')
                    .data("numFMGB", type == 1 ? "0":"")   //发明公布
                    .data("numFMSQ", type == 2 ? "0":"")
                    .data("numSYXX", type == 3 ? "0":"")
                    .data("numWGSQ", type == 4 ? "0":"")
                    .post();
            break;
        } catch (Exception e) {
            println e
            retry++;
            println 'will retry list:' + retry
        }
    }
    
    if (doc == null) {
        println 'could not get list!';
    }
    
    def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
    def cnt0 = cntt.substring(5, cntt.length()-1) as int
    
    if (cnt0 != set.size()) {
        println 'count error:' + cnt0
    }
    
}

println "finished..."
