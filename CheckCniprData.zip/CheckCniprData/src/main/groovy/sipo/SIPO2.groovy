@Grab('org.jsoup:jsoup:1.7.1')

import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.BasicDBObject
import com.mongodb.DBCursor

/**
 * Sipo 事務數據查詢
 * 官網都是每周三發佈
 * 建庫
 */

def a = ''

System.properties << [ 'http.proxyHost':'10.60.94.21', 'http.proxyPort':'3128' ]

def type = 1    // 1.发明專利  2. 实用新型   3.外观设计
def numType = "18"  //transfer
numType = "7"   //license
numType = ""   //all
def querydate = '2015.04.01';
def ln = System.getProperty('line.separator')

def nextPage = true;
def pageNum = 1;
def pageSize = 20;

MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
def mongoClient = new MongoClient(new ServerAddress("10.60.90.155", 27017),
                    Arrays.asList(credential));
def collection = mongoClient.getDB("AssignmentRawCN").getCollection("AssignmentRawCN")

while (nextPage) {
    def doc = null;
    
    def retry = 0;
    while (retry < 10)  {
        try {
            doc = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/overTran.action").timeout(300000)
                    .data("strWord", "法律状态公告日='${querydate}'")
                    .data("numType", numType)
                    .data("pageSize", pageSize.toString())
                    .data("pageNow", pageNum.toString())
                    .data("numSortMethod", "3")     //按事务数据公告日升序排序
                    .data("numFM", type == 1 ? "0":"")
                    .data("numXX", type == 2 ? "0":"")
                    .data("numWG", type == 3 ? "0":"")
                    .post();
            break;
        } catch (Exception e) {
            retry++;
            println 'will retry list:' + retry
        }
    }
    if (doc == null) {
        println 'could not get list!';
        break;
    }
    
    def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
    def cnt = cntt.substring(5, cntt.length()-1) as int
    def pages = ((cnt + pageSize - 1) / pageSize) as int
    println "cnt:${cnt} pages:${pageNum}/${pages}"
    
    def dodate = new Date().format("yyyy.MM.dd")
    doc.select(".list_dl + table a").each { node->
        def no = node.text()    
        
        def fdoc = null;
        retry = 0;
        while (retry < 10)  {
            try {
                fdoc = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/fullTran.action").timeout(300000)
                        .data("an", no)
                        .post();
                break;
            } catch (Exception e) {
                retry++;
                println 'will retry doc:' + retry
            }
        }
        if (fdoc == null) {
            println 'could not get list!';
            file << num << ln
            return;
        }
        def title = fdoc.select(".flzt_h1tit").text();
        
        def flztxx = fdoc.select(".table_flztxx");
        flztxx.each {
            def tds = it.select("table[cellpadding=3] td")
            def num = tds[1].text()
            def date = tds[5].text()
            def theType = tds[7].text()
            def line = null
            def t = tds[8].html()
            def map = [:]
            t = t.replaceAll(/<br \/>/, "<br>")
            t.split(/<br>/).each {
                def v = it.split(':');
                if (v.length > 1) {
                    if (map[v[0]] == null) {
                        map[v[0]] = v[1]
                    } else {
                        map[v[0] + "_1"] = v[1] //專利轉讓會重複
                    }
                }
            }
            def data = [:]
            data['appNumber'] = num;
            data['date'] = date;
            data['type'] = theType
            data['cnt'] = flztxx.size()
            data['createdTime'] = dodate
            data['detail'] = map
            //println data
            
            DBCursor cursor = collection.find(new BasicDBObject(["appNumber" : num, "date" : date, "type" : theType]))
            if (!cursor.hasNext()) {
                collection.insert(new BasicDBObject(data))
            } else {
                println 'exist!';
            }
        }
    }
    pageNum++
    if (pageNum > pages) {
        break
    }
    
}        
println 'finished!'
