/**
 * 
 */
import utils.MongoUtil

import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// def backupClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def yeatsClient = MongoUtil.connect3X("10.60.91.72", 27017)

def lv2Client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDb = yeatsClient.getDB("TonyDB")

def lv2Db = lv2Client.getDB("PatentInfoCNIPR")

// 5621b541ae240fb34f0ed2bf
def backupData = lv2Db.PatentInfoCNIPR.findOne([_id: new ObjectId("55afdaf4b13b296772e62784")])

// println "backupData = ${backupData}"

tonyDb.IpcData.insert(backupData);

println "finished..."
