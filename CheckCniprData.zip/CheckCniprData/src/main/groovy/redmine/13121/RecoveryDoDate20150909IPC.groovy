/**
 * 處理lv2 cnipr doDate = 2015-09-09, mainIPC, ipcs, mainIPCNormal, ipcsNormal
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
// import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def db127 = MongoUtil.connect2X('yyj', 'yyj', "10.60.90.127", 27017, 'admin')
def db121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentRawCNIPR = db127.getDB("PatentRawCNIPR")
def patentInfoCNIPR = db121.getDB("PatentInfoCNIPR")

File fileLog = new File("log/RecoveryDoDate20150909IPC.log")

// T:\temp\20150921\doDate20150909

new File("T:/temp/20150921/doDate20150909.log").eachLine { line, number ->
// new File("T:/temp/20150921/test.txt").eachLine { line, number ->
    
    def splitData = line.toString().split("=>")
    
    def _id = splitData[0].split("=")[1].trim()
    // println "lv2._id = ${_id}"
    
    def lv2Data = patentInfoCNIPR.PatentInfoCNIPR.findOne([_id: new ObjectId(_id)])
    
    def lv1Id = lv2Data.relRawdatas[-1]._id
    // println "lv1._id = ${lv2Data.relRawdatas[-1]._id}"
    
    // TODO: query lv1 and parse mainIPC && ipcs
    // data.bibliography
    def lv1Data = patentRawCNIPR.PatentRawCNIPR.findOne([_id: lv1Id])
    
    def updateMap = [:]
    
    if (!!lv1Data) {
        //
        def bibliography = lv1Data.data.bibliography.replaceAll(/(?ism)&nbsp;/, "")
        
        // /<input\s+type="hidden"\s+name="strIPC"\s+value="([^\"]+?)">/i
        def mainIPCGroup = bibliography =~ /(?i)<input\s+type="hidden"\s+name="strIPC"\s+value="([^\"]+?)">/
        
        if (mainIPCGroup.size() > 0) {
            
            def rawMainIPC = mainIPCGroup[0][1].replace(/(?ism)\(.+?\)\D*/, "").replace(/\/\/.*/, "").trim();
            // println "rawMainIPC = ${rawMainIPC}"
            
            def mainIPC = originPc(rawMainIPC)
            // println "mainIPC = " + mainIPC
            updateMap << [mainIPC: mainIPC]
            
            def mainIPCNormal = normalizePC(rawMainIPC)
            // println "mainIPCNormal = " + mainIPCNormal
            updateMap << [mainIPCNormal: mainIPCNormal]
            
        } else {
            //
            println "no match pattern..."
            fileLog << line << " => no match pattern" << ln
            
        }
        
        // regex pattern => /(?i)【分类号】<\/strong>([\s\S]*?)<\/td>/
        // regex pattern => /(?i)\s分类号[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
        def ipcsGroup = bibliography =~ /(?i)【分类号】<\/strong>([\s\S]*?)<\/td>/
        
        if (ipcsGroup.size() == 0) {
            
            ipcsGroup = bibliography =~ /(?i)\s分类号[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
            
            if (!ipcsGroup.size() == 0) {
                throw new Exception("ipcsGroup no match pattern")
            }
            
        }
            
        // set original ipcs
        def pcs = [];
        ipcsGroup[0][1].trim().split(/[;；]/).each{ pc ->
            pc = pc.replace(/\(.+?\)[\s\S]*/, "");
            pc = pc.replace(/\/\/.*/, "");
            if (!pc) {
                return;
            }
            pcs.push(originPc(pc));
        };
        // println "pcs = ${pcs}"
        updateMap << [ipcs: pcs]
        
        // set ipcs to normalize
        def normalizePcs = [];
        ipcsGroup[0][1].trim().split(/[;；]/).each{ pc ->
            pc = pc.replace(/\(.+?\)[\s\S]*/, "");
            pc = pc.replace(/\/\/.*/, "");
            if (!pc) {
                return;
            }
            normalizePcs.push(normalizePC(pc));
        };
        // println "normalizePcs = ${normalizePcs}"
        updateMap << [ipcsNormal: normalizePcs]
        
    } else {
        
        fileLog << line << ln
    
    }
    
    // println "updateMap = ${updateMap}"
    
    patentInfoCNIPR.PatentInfoCNIPR.update([_id: new ObjectId(_id)], [$set: updateMap], true, false, new com.mongodb.WriteConcern.Majority())
    
    println "parse line = ${number} => OK"
    
}

println "finished..."

def originPc(pc) {
    
    def pcGroup = pc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S{2,5})(\s)*([\.\(]\S+)?[\)\S]?$/;
    
    if (pcGroup.size() > 0) {
        return pcGroup[0][1] + " " + pcGroup[0][2] + "/" + pcGroup[0][3];
    } else {
        throw new Exception("originPc no match pattern")
    }
    
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 * EX: E02B 15/10 => E02B0015100000
 */
def normalizePC(pc) {
    
    // regex pattern demo => C12N1/21 or C12N1/21(2006.01)I
    def pcGroup = pc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S{2,5})(\s)*([\.\(]\S+)?[\)\S]?$/;
    
    if (pcGroup.size() > 0) {
        return pcGroup[0][1] + StringUtils.leftPad(pcGroup[0][2], 4, '0') + StringUtils.rightPad(pcGroup[0][3], 6, '0')
    } else {
        throw new Exception("normalizePC no match pattern")
    }
    
}
