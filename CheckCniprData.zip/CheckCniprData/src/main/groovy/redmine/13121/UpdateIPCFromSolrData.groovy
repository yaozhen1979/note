// ObjectId("513049c04c7c348d1843e5dd")

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
// import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def db101 = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDB = db101.getDB("TonyDB")
def patentInfoCNIPR = db121.getDB("PatentInfoCNIPR")

/*
 * recovery col
 * 
 * BackupCnMainIPCAndIpcs
 * mainIPC : 原本lv2解析出的[mainIPC]
 * ipcs : 原本lv2解析出的[ipcs]
 * 
 * mainIPCNormal : 正規化欄位
 * ipcsNormal : 正規化欄位
 * 
 */

File fileLog = new File("log/UpdateIPCFromSolrData.log")

def queryMap = [recoveryFlag: [$exists: false]]

//
def cursor = tonyDB.BackupCnMainIPCAndIpcs.find().limit(1)
cursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);

// 11295639
def totalCount = cursor.count()

cursor.eachWithIndex { it, index ->
    
    try {
        
        def updateData = [:]
        
        updateData << [mainIPC: it.mainIPC]
        updateData << [ipcs: it.ipcs]
        //
        updateData << [mainIPCNormal: getMainIPCNormal(it.mainIPC)]
        updateData << [ipcsNormmal: getIpcsNormal(it.ipcs)]
        
        // println "updateData = ${updateData}"
        
        patentInfoCNIPR.PatentInfoCNIPR.update(
            [_id: it._id],
            [$set: updateData]
        )
        
        tonyDB.BackupCnMainIPCAndIpcs.update(
            [_id: it._id],
            [$set: [recoveryFlag: true]]
        )
        
        println "process id = ${it._id}, ${++index} / ${totalCount}"
        
    } catch (Exception e) {
        
        println "it._id = ${it._id} => " + e
        fileLog << "it._id = ${it._id} => " + e << ln
    
    }
        
}

println "finished..."

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015100000
 *
 */
def String getMainIPCNormal(mainIPC) {
    
    // 未正規化 pattern
    def ipcGroup = mainIPC =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    
    if (ipcGroup.size() > 0) {
        
        def updateMainIPC
        
        if (!ipcGroup[0][1] || !ipcGroup[0][2] || !ipcGroup[0][3]) {
            //
            throw new Exception("mainIPC = ${mainIPC} normal pattern error")
        } else {
            
            return ipcGroup[0][1] + StringUtils.leftPad(ipcGroup[0][2], 4, '0') + StringUtils.rightPad(ipcGroup[0][3], 6, '0')
        }
        
    } else {
        //
        // println "no match pattern..."
        throw new Exception("mainIPC = ${mainIPC} no match pattern")
    }
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015100000
 *
 */
def getIpcsNormal(ipcs) {
    //
    return ipcs.inject([]) { result, ipc -> result << getMainIPCNormal(ipc) }
}
