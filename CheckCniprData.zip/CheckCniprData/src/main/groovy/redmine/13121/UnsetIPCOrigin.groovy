/**
 * unset CN LV2 PatentInfoCNIPR 中的錯誤欄位, mainIPCOrigin, ipcsOrigin.
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
// import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def db101 = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDB = db101.getDB("TonyDB")
def patentInfoCNIPR = db121.getDB("PatentInfoCNIPR")

/*
 * TODO: recovery col
 *
 * BackupCnMainIPCAndIpcs
 * mainIPC : 正規化欄位
 * ipcs : 正規化欄位
 *
 * mainIPCOrigin : 原本lv2解析出的[mainIPC]
 * ipcsOrigin : 原本lv2解析出的[ipcs]
 *
 */

File fileLog = new File("log/UnsetIPCOrigin.log")

//
def cursor = tonyDB.BackupCnMainIPCAndIpcs.find([recoveryFlag: true]).limit(0)
cursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);

def totalCount = cursor.count()

cursor.eachWithIndex { it, index ->
    //
    try {
        
        def unsetData = [:]
        
        unsetData << [mainIPCOrigin: ""]
        unsetData << [ipcsOrigin: ""]
        //
        
        // println "unsetData = ${unsetData}"
        
        patentInfoCNIPR.PatentInfoCNIPR.update(
            [_id: it._id],
            [$unset: unsetData]
        )
        
        tonyDB.BackupCnMainIPCAndIpcs.update(
            [_id: it._id],
            [$set: [recoveryFlag: false]]
        )
        
        println "process id = ${it._id}, ${++index} / ${totalCount}"
        fileLog << "process id = ${it._id}, ${++index} / ${totalCount}" << ln
        
    } catch (Exception e) {
        
        println "it._id = ${it._id} => " + e
        fileLog << "it._id = ${it._id} => " + e << ln
    
    }
    
}

println "finished..."
