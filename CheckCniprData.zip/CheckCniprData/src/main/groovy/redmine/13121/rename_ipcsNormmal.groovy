// ObjectId("513049c04c7c348d1843e5dd")

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
// import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def db101 = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDB = db101.getDB("TonyDB")
def patentInfoCNIPR = db121.getDB("PatentInfoCNIPR")

File fileLog = new File("log/rename_ipcsNormmal.groovy")

// def queryMap = [renameIpcsNormmal: [$exists: false]]

//
def cursor = tonyDB.BackupCnMainIPCAndIpcs.find().sort([_id:-1]).limit(0)
cursor.addOption(com.mongodb.Bytes.QUERYOPTION_NOTIMEOUT);

// 11295639
def totalCount = cursor.count()

cursor.eachWithIndex { it, index ->
    
    try {
        
        def lv2Data = patentInfoCNIPR.PatentInfoCNIPR.findOne([_id: it._id])
        
        if (!!lv2Data.ipcsNormmal) {
            
            def updateData = [:] << [ipcsNormal: lv2Data.ipcsNormmal]
            
            // println "updateData = ${updateData}"
            
            patentInfoCNIPR.PatentInfoCNIPR.update(
                [_id: it._id],
                [$set: updateData]
                // true, false, new com.mongodb.WriteConcern.Majority()
            )
            
            patentInfoCNIPR.PatentInfoCNIPR.update(
                [_id: it._id],
                [$unset: ["ipcsNormmal": ""]]
                // true, false, new com.mongodb.WriteConcern.Majority()
            )
            
            tonyDB.BackupCnMainIPCAndIpcs.update(
                [_id: it._id],
                [$set: [renameIpcsNormmal: true]]
            )
            
        }
        
        println "process id = ${it._id}, ${++index} / ${totalCount}"
        
    } catch (Exception e) {
        
        println "it._id = ${it._id} => " + e
        fileLog << "it._id = ${it._id} => " + e << ln
    
    }
        
}

println "finished..."

