import utils.MongoUtil

import org.bson.types.ObjectId
import utils.DateUtil

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def db = client.getDB("PatentInfoCNIPR")

def yeatsClinet = MongoUtil.connect3X("10.60.91.72", 27017)
def tonyDB = yeatsClinet.getDB("TonyDB")


def copyDataNumber = 0

new File("doc/redmine/12864/redmine_12864_err_lv2_id.txt").eachLine { line, number -> 
    
    def objectId = line.toString().trim()
    
    if (!!objectId) {
        
        def queryCount = db.PatentInfoCNIPR.find([_id: new ObjectId(objectId)]).count()
        
        if (queryCount == 0) {
            println "${objectId} dont exists"
        } else if (queryCount > 1) {
            println "${objectId} over one count"
        } else {
            // TODO: insert to yeats db
            def copyData = db.PatentInfoCNIPR.findOne([_id: new ObjectId(objectId)])
            tonyDB.ErrIpcData.insert(copyData)
            println "copy data to yeats db complete => count = ${++copyDataNumber}"
        }
        
    }
    
}

println "finished..."