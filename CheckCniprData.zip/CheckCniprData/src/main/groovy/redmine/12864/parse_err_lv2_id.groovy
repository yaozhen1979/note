import utils.MongoUtil

import org.bson.types.ObjectId
import utils.DateUtil

// def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

// def db = client.getDB("PatentR")

def errCount = 0

def errList = []

new File("doc/redmine/12864/ipc_err.log").eachLine { line, number -> 
    
    // println line.toString()
    def lineStr = line.toString()
    
    if (lineStr.contains("lv2._id") && lineStr.contains("process")) {
        errList << lineStr.find(/\S{24}/)
        // println lineStr.find(/\S{24}/)
    }
    
}

new File("doc/redmine/12864/noDoDate20150909.log").eachLine { line, number -> 
    
    def lineStr = line.toString()
    errList << lineStr.find(/\S{24}/)
    // println lineStr.find(/\S{24}/)
}

errList.toSet().each { it -> 
    println it
}
