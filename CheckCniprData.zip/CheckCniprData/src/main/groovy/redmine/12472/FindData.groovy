// LV1:54db09a9e4b01e025f27bf2c no exists,LV2:54e8484bf911e44bf5fc929e
//

import utils.MongoUtil

import org.bson.types.ObjectId

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")

new File("log/redmine/12472/test.txt").eachLine { line, number -> 
    //
    def id = line.split(",")[1].split(":")[1]
    
    def lv2Id = patentInfoCNIPR.PatentInfoCNIPR.findOne([_id:new ObjectId(id)])
    
    println "${number}, relRawdatas = ${lv2Id.relRawdatas.size()}, ${lv2Id.relRawdatas}"
    
    // relRawdatas = [] << lv2Id.relRawdatas[1] << lv2Id.relRawdatas[2]
    
    // println "${number}, relRawdatas = ${relRawdatas}" 
    
    // patentInfoCNIPR.PatentInfoCNIPR.update([_id:new ObjectId(id)], [$set: [relRawdatas: relRawdatas]])
    
}

println "finished..."
