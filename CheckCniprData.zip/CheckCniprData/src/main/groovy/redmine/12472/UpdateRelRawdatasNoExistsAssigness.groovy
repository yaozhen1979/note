import org.common.utils.DateUtil

import utils.MongoUtil

import org.bson.types.ObjectId

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

/*
 *  path:SD/2010/20100804/200810126761.6,raw exists in 127 and 121
 *  path:FM/2010/20100804/201010118736.0,raw exists in 127
 *  path:FM/2010/20100804/201010118736.0,raw exists in 127 and 121
 *  path:WG/2014/20140604/201330609815.6,no exists
 */

 // log/redmine/12472/find_lv1_raw_data_exists.log
 
 def ln = System.getProperty('line.separator')
 
 def clientOne = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
 def clientTwo = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.127", 27017, 'admin')
 
 def patentInfoCNIPR = clientOne.getDB("PatentInfoCNIPR")
 def patentRawCNIPRFrom121 = clientOne.getDB("PatentRawCNIPR")
 def patentRawCNIPRFrom127 = clientTwo.getDB("PatentRawCNIPR")
 
 File logFile = new File("log/redmine/12472/UpdateRelRawdatasNoExistsAssigness.log")
 File errFile = new File("log/redmine/12472/ErrorUpdateRelRawdatasNoExistsAssigness.log")
 
 def count = 0
 def errCount = 0
 
 println "to start..."
 
 new File("log/redmine/12472/find_lv1_raw_data_exists.log").eachLine { line ->
     
     if (!line.contains("no exists")) {
         //
         def dataIp
         def db;
         
         // 資料如都存在121 || 127, 則以121為主.
         if (line.contains("121") && line.contains("127")) {
             db = patentRawCNIPRFrom121
         } else if (line.contains("121")) {
             db = patentRawCNIPRFrom121
         } else if (line.contains("127")) {
             db = patentRawCNIPRFrom127
         }
         //
         def dataList = line.split(",")
         // type: FM(1), SD(2), SQ(2), WG(2), XK(2), XX(2)
         
         def pathString = dataList[0]
         def type = pathString.split(":")[1].split("/")[0]
         def doDate = pathString.split(":")[1].split("/")[2]
         def appNumber = pathString.split(":")[1].split("/")[3]
         def lv2Id = dataList[2].split(":")[1]
         def lv1Id = dataList[3].split(":")[1]
         
         def stat
         switch(type) {
             case "FM" : stat = 1
                 break
             case "SD" : stat = 2
                 break
             case "SQ" : stat = 2
                 break
             case "WG" : stat = 2
                 break
             case "XK" : stat = 2
                 break
             case "XX" : stat = 2
                 break
             Default :
                 break
         }
         
         //
         def lv1Data = db.PatentRawCNIPR.findOne([_id: new ObjectId(lv1Id)])
         def lv2Data = patentInfoCNIPR.PatentInfoCNIPR.findOne([doDate: DateUtil.parseDate(doDate), appNumber: appNumber, stat: stat])
         // println "data size = ${data.size()}"
         
         if (lv2Data._id.toString() == lv2Id && lv1Data._id.toString() == lv1Id) {
             // def msg = "lv2 data exists"
             // println msg 
             // logFile << msg << ln
             
             updateAssigness(lv1Data, lv2Data, patentInfoCNIPR)
             
             // PatentInfoCNIPR._id=54dc5c33b36f75107110fa22
             logFile << "PatentInfoCNIPR._id=${lv2Id}" << ln
             
             count++
             
         } else {
             // data size = 0 or > 1
             def msg = "err log,[data size = 0 or > 1],${line}"
             println msg
             errFile << msg << ln
             errCount++
         }
         
     } else {
         // no exist
         def msg = "err log,[data no exist],${line}"
         println msg
         errFile << msg << ln
         errCount++
     }
     
 }
 
 println "update count = ${count}"
 println "error count = ${errCount}"
 println "finished..."
 
 /**
  * lv2 relRawdatas no exists
  * 
  * @param lv1Data
  * @param lv1Data
  * @param patentInfoCNIPR
  */
 void updateAssigness(lv1Data, lv2Data, patentInfoCNIPR) {
     
     //
     bibliography = lv1Data.data.bibliography.replaceAll(/(?ism)&nbsp;/, "")
     def assignees = []
     def bibliographyGroup = bibliography =~ /(?i)<input\s+type="hidden"\s+name="strANN"\s+value="([^\"]+)">/
     
     if (bibliographyGroup.size() > 0) {
         // println "bibliographyGroup = ${bibliographyGroup.size()}"
         bibliographyGroup[0][1].trim().split(/[;；]/).each { it ->
             // assignee << ['name':['origin':it]]
             assignees << ['name':['origin':it]]
         }
         
     } else {
         //
         println "no match pattern..."
     }
     
     if (assignees.size() > 0) {
         //
         def addressGroup = bibliography =~ /(?i)(地址:|地址】)[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
         if (addressGroup.size() > 0) {
             // println "addressGroup = ${addressGroup.size()}"
             def address = addressGroup[0][2].trim()
             assignees[0] << ['address':['origin':address]]
         }
         
         def countryGroup = bibliography =~ /(?i)国省代码[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
         if (countryGroup.size() > 0) {
             
             def country = countryGroup[0][1].trim().split(/[;；]/)
             // println "countyr size = ${country.size()}"
             // [国省代码]資料 = 美国;US, 但只取第二個英文國家代碼
             if (country.size() == 2) {
                 //
                 def cc = country[1].trim()
                 if (cc) {
                     assignees[0] << ['country':['origin': (cc ==~ /^\d+$/ ? "CN" : cc.toUpperCase())]]
                 }
             }
             
         }
         
     }
     
     println "assignees = ${assignees}"
     
     lv2Data.mongoSyncFlag.last = new Date()
     println "mongoSyncFlag = ${lv2Data.mongoSyncFlag}"
     
     def newRelRawdatas = []
     if (lv2Data.relRawdatas) {
         // lv2Data.relRawdatas = [] << [_id: lv1Data._id] << lv2Data.relRawdatas
         newRelRawdatas << [_id: lv1Data._id]
         lv2Data.relRawdatas.each { it ->
             newRelRawdatas << it
         }
         
     } else {
         //
         newRelRawdatas << [_id: lv1Data._id]
     }
     lv2Data.relRawdatas = newRelRawdatas
     println "lv2Data.relRawdatas = ${lv2Data.relRawdatas}"
     
     // update data
     patentInfoCNIPR.PatentInfoCNIPR.update([_id:lv2Data._id], [$set: [assignees: assignees, mongoSyncFlag: lv2Data.mongoSyncFlag, relRawdatas: lv2Data.relRawdatas]])
     
     println "update ok..."
         
 }
 