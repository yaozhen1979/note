// 檢查[relRawdatas]是否存在

import utils.MongoUtil

import org.bson.types.ObjectId
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

// Logger logger = LoggerFactory.getLogger(this.class);

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")

def processCount = 0
def noExistsCount = 0
def existsCount = 0
def mergeCount = 0

File noExistsFile = new File("log/redmine/12472/no_exists_relRawdatas_id.txt")
File existsFile = new File("log/redmine/12472/exists_relRawdatas_id.txt")
File mergeFile = new File("log/redmine/12472/merge_docdb_id.txt")

new File("log/redmine/12472/error_assignees_objectId.txt").eachLine { line -> 
    
    def id = line.split(":")[1]
    // println "_id = ${id}"
    
    def data = patentInfoCNIPR.PatentInfoCNIPR.findOne([_id: new ObjectId(id)])
    
    // println "data = ${data}"
    
    // println "data.relRawdatas = ${data.relRawdatas}"
    
    if (!data.relRawdatas) {
        
        // println "relRawdatas no exists"
        noExistsFile << "LV2:${id}" << "," << "type:${data.type}" << "," << "stat:${data.stat}" << "," << "doDate:${new SimpleDateFormat("yyyy-MM-dd").format(data.doDate)}" << ln
        noExistsCount++
        noExistsFile << "-----//" << ln
        
    } else {
        
        // println "TEST = ${data.relRawdatas[0].keySet()[0]}"
        if (data.relRawdatas[0].keySet()[0] == "_docdbId") {
            
            noExistsFile << "LV2:${id}" << "," << "type:${data.type}" << "," << "stat:${data.stat}" << "," << "doDate:${new SimpleDateFormat("yyyy-MM-dd").format(data.doDate)}" << ln
            noExistsCount++
            
            noExistsFile << "merge docdb._docdbId:${data.relRawdatas[-1]._docdbId}" << ln;
            mergeFile << "merge docdb._docdbId:${data.relRawdatas[-1]._docdbId}" << ln;
            mergeCount++
            
            noExistsFile << "-----//" << ln
            
        } else {
        
            // println "relRawdatas exists"
            existsFile << "LV2:${id}" << "," << "type:${data.type}" << "," << "stat:${data.stat}" << "," << "doDate:${new SimpleDateFormat("yyyy-MM-dd").format(data.doDate)}";
            existsFile << ",relRawdatas._id:${data.relRawdatas[0]._id}" << ln;
            existsCount++
            if (data.relRawdatas.size() > 1) {
                println "TEST = ${data._id}"
                existsFile << "merge docdb._docdbId:${data.relRawdatas[-1]._docdbId}" << ln;
                mergeFile << "merge docdb._docdbId:${data.relRawdatas[-1]._docdbId}" << ln;
                mergeCount++
            }
            
            existsFile << "-----//" << ln
            
        }
        
    }
    
    println "processCount = ${++processCount}"
    
}

println "existsCount = ${existsCount}"
println "noExistsCount = ${noExistsCount}"
println "mergeCount = ${mergeCount}"

println "finished..."
