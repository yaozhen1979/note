// LV2: 55875e051a29d121a634870b,type:外观专利,stat:2,doDate:2015-06-10,relRawdatas._id:5586e5219684f2a821e8ee60 => err data test
// LV2: 54e847def911e44bf5fc9003 / LV1: 54f6b220e4b0538275950045 => multi assignees test
// LV2: 55aaefba009e8093c3791904 / LV1: 55a9f74f968475c024cade2d => US country test
// LV2: 55aaf619009e8093c3796edf / LV1: 55aa70399684915055997030 => CN country test
import utils.MongoUtil

import org.bson.types.ObjectId

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

println "to start..."

def ln = System.getProperty('line.separator')

def lv1Client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.127", 27017, 'admin')
def lv2Client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def patentRawCNIPR = lv1Client.getDB("PatentRawCNIPR")
def patentInfoCNIPR = lv2Client.getDB("PatentInfoCNIPR")

def count = 0

// TODO: read file [exists_relRawdatas_id.txt]
new File("log/redmine/12472/exists_relRawdatas_id.txt").eachLine { line ->
    
    if (line.startsWith("LV2:")) {
        
        def lv1Id = line.split(",")[4].split(":")[1]
        def lv2Id = line.split(",")[0].split(":")[1]
        
        println "PatentInfoCNIPR._id=${lv2Id}"
        
        // updateAssigness(lv1Id, lv2Id, patentRawCNIPR, patentInfoCNIPR)
        
        count++
    }
    
}

println "update count = ${count}"

void updateAssigness(final String lv1Id, final String lv2Id, patentRawCNIPR, patentInfoCNIPR) {
    //
    // def lv1Id = "5586e5219684f2a821e8ee60"
    // def lv2Id = "55875e051a29d121a634870b"
    def lv1Query = [_id: new ObjectId(lv1Id)]
    def lv2Query = [_id: new ObjectId(lv2Id)]
    
    def lv2Data = patentInfoCNIPR.PatentInfoCNIPR.findOne(lv2Query)
    // println "relRawdatas = " + lv2Data.relRawdatas.toString().contains("5586e5219684f2a821e8ee60")
    
    if (lv2Data.relRawdatas.toString().contains(lv1Id)) {
        
        def lv1Data = patentRawCNIPR.PatentRawCNIPR.findOne(lv1Query)
        
        // old code => var biblio = doc.data.bibliography.replace(/&nbsp;/ig, "");
        def bibliography = lv1Data.data.bibliography.replaceAll(/(?ism)&nbsp;/, "")
        def assignees = []
        def bibliographyGroup = bibliography =~ /(?i)<input\s+type="hidden"\s+name="strANN"\s+value="([^\"]+)">/
        
        if (bibliographyGroup.size() > 0) {
            // println "bibliographyGroup = ${bibliographyGroup.size()}"
            bibliographyGroup[0][1].trim().split(/[;；]/).each { it ->
                // assignee << ['name':['origin':it]]
                assignees << ['name':['origin':it]]
            }
            
        } else {
            //
            println "no match pattern..."
        }
        
        if (assignees.size() > 0) {
            //
            def addressGroup = bibliography =~ /(?i)(地址:|地址】)[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
            if (addressGroup.size() > 0) {
                // println "addressGroup = ${addressGroup.size()}"
                def address = addressGroup[0][2].trim()
                assignees[0] << ['address':['origin':address]]
            }
            
            def countryGroup = bibliography =~ /(?i)国省代码[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>/
            if (countryGroup.size() > 0) {
                
                def country = countryGroup[0][1].trim().split(/[;；]/)
                // println "countyr size = ${country.size()}"
                // [国省代码]資料 = 美国;US, 但只取第二個英文國家代碼
                if (country.size() == 2) {
                    //
                    def cc = country[1].trim()
                    if (cc) {
                        assignees[0] << ['country':['origin': (cc ==~ /^\d+$/ ? "CN" : cc.toUpperCase())]]
                    }
                }
                
            }
            
        }
        
        println "assignees = ${assignees}"
        
        lv2Data.mongoSyncFlag.last = new Date()
        println "mongoSyncFlag = ${lv2Data.mongoSyncFlag}"
        
        // update data
        // patentInfoCNIPR.PatentInfoCNIPR.update(lv2Query, [$set: [assignees: assignees, mongoSyncFlag: lv2Data.mongoSyncFlag]])
        
        println "update ok..."
        
    } else {
        // lv2Data.relRawdatas.toString().contains(lv1Id)
        println "LV2._id = ${lv2Id}, lv2Data.relRawdatas do not contains LV1._id = ${lv1Id}"
    
    }// end if
    
}

println "finished..."
