/**
 *  modify cn data
 *  (ANAD/"检索共命中")
 *  
 * db.PatentInfoCNIPR.find({appNumber:'201330608772.X', assignees:{$elemMatch: { 'address.origin': {$regex: /此次检索共命中/ }  } }})
 * // TEST 2015-07-16 
 * //                 => 6212 (before 2015-07-08)
 * //                 => 20 (2015-07-08)
 * db.PatentInfoCNIPR.find({assignees:{$elemMatch: { 'address.origin': {$regex: /此次检索共命中/ }  } }}).count()
 * 
 *  
 */
import utils.MongoUtil

import org.bson.types.ObjectId
import org.common.util.DateUtils

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def db = client.getDB("PatentInfoCNIPR")

def count = 0;

File file = new File("error_assignees_objectId.txt")

println "start parsing..."

db.PatentInfoCNIPR.find([
    
    doDate: DateUtils.parseDate("2015-07-08"),
    
    // appNumber: '201330608772.X',
    assignees:[
        $elemMatch: [
            'address.origin': [$regex: /此次检索共命中/ ]
        ]
    ]
    
]).each { it ->

    //
    file << "_id:" << it._id << ln
    println it._id
    count++;
}

// size = 6212
println "objectId count = ${count}"

println "finished..."
