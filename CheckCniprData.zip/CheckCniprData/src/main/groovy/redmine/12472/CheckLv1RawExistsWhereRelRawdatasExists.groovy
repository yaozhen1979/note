/**
 * 檢查資料是存在於 127 or 121
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

println "to start..."

def ln = System.getProperty('line.separator')

def clientOne = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def clientTwo = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.127", 27017, 'admin')

def patentInfoCNIPR = clientOne.getDB("PatentInfoCNIPR")

def patentRawCNIPRFrom121 = clientOne.getDB("PatentRawCNIPR")

def patentRawCNIPRFrom127 = clientTwo.getDB("PatentRawCNIPR")


// exists_relRawdatas_id.txt
new File("log/redmine/12472/exists_relRawdatas_id.txt").eachLine { line ->
    
    if (line.startsWith("LV2:")) {
        
        // find relRawdatas._id -> LV2:55875e051a29d121a634870b,type:外观专利,stat:2,doDate:2015-06-10,relRawdatas._id:5586e5219684f2a821e8ee60
        def lv1Id = line.split(",")[4].split(":")[1]
        
        def lv2Id = line.split(",")[0].split(":")[1]
        
        def lv1Query = [_id: new ObjectId(lv1Id)]
        
        def rawData127 = patentRawCNIPRFrom127.PatentRawCNIPR.findOne(lv1Query)
        def rawData121 = patentRawCNIPRFrom121.PatentRawCNIPR.findOne(lv1Query)
        
        if (rawData127) {
            println "LV1:${lv1Id},raw exists in 127"
        } else if (rawData121) {
            println "LV1:${lv1Id},raw exists in 121"
        } else {
            println "LV1:${lv1Id} no exists,LV2:${lv2Id}"
        }
        
    }
    
}

println "finished..."
