/**
 * 
 */
import utils.MongoUtil

import org.bson.types.ObjectId
import org.common.utils.DateUtil

def ln = System.getProperty('line.separator')

def backupClient = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv2Client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDb = backupClient.getDB("TonyDB")

def lv2Db = lv2Client.getDB("PatentInfoCNIPR")

def backupInfo = ['redmine':12472, 'doDate': new Date()]
 
println "to start..."

new File("log/redmine/12472/error_assignees_objectId.txt") .eachLine { line -> 
    //
    def id = line.split(":")[1]
    
    def backupData = lv2Db.PatentInfoCNIPR.findOne([_id: new ObjectId(id)])
    
    backupData << ["backupInfo": backupInfo]
    
    tonyDb.BackupDB.save(backupData);
    
}


//def backupData = lv2Db.PatentInfoCNIPR.findOne([_id: new ObjectId("5597cdc3b1600e745949d758")])
//
//println "backupData = ${backupData}"
//
//tonyDb.BackupDB.insert(backupData);

println "finished..."
