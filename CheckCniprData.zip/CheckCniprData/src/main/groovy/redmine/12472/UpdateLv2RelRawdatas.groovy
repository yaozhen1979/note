/**
 * 更新特定欄位值
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

println "to start..."

def ln = System.getProperty('line.separator')

def count = 0

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")

def backupClient = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def lv2Client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def tonyDb = backupClient.getDB("TonyDB")
def lv2Db = lv2Client.getDB("PatentInfoCNIPR")

// log/redmine/12472/update_list.txt
new File("").eachLine { line -> 
    //
    
    if (line.startsWith("LV2:")) {
        
        def id = line.split(",")[0].split(":")[1]
        println "_id = " + id
        
        def query = [_id: new ObjectId(id)]
        
        def data = patentInfoCNIPR.PatentInfoCNIPR.findOne(query, [relRawdatas:1])
        
        println "data = ${data}"
        
        def relRawdatas = data.relRawdatas
        
        def dataList = []
        
        dataList << data.relRawdatas[-1]
        
        patentInfoCNIPR.PatentInfoCNIPR.update(query, [$set: [relRawdatas: dataList]])
        
        println "process = ${++count}"
        
    }
    
}

/*
def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")

def query = [_id: new ObjectId("5597d153b1600e74594a2ede")]

def data = patentInfoCNIPR.PatentInfoCNIPR.findOne(query)

def relRawdatas = data.relRawdatas

def dataList = []

dataList << data.relRawdatas[-1]

patentInfoCNIPR.PatentInfoCNIPR.update(query, [$set: [relRawdatas: dataList]])
*/

println "----------------------"
println "finished..."

