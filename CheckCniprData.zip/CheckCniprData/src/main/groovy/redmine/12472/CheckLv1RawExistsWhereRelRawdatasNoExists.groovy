/**
 * 檢查資料是存在於 127 or 121, 並依格式為[path:${path},raw exists in 127( and 121),LV2:${lv2Id},LV1:${rawData121._id}]寫入log, 
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;

println "to start..."

def ln = System.getProperty('line.separator')

def clientOne = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def clientTwo = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.127", 27017, 'admin')

def patentInfoCNIPR = clientOne.getDB("PatentInfoCNIPR")
def patentRawCNIPRFrom121 = clientOne.getDB("PatentRawCNIPR")
def patentRawCNIPRFrom127 = clientTwo.getDB("PatentRawCNIPR")

File logFile = new File("log/redmine/12472/find_lv1_raw_data_exists.log")
def count = 0

// LV2:512db8c275949f0e71723803,type:发明专利,stat:1,doDate:1987-01-07
new File("log/redmine/12472/no_exists_relRawdatas_id.txt").eachLine { line ->
    
    if (line.startsWith("LV2:")) {
        
        def lv2Id = line.split(",")[0].split(":")[1].trim()
        def type = line.split(",")[1].split(":")[1].trim()
        def stat = line.split(",")[2].split(":")[1].trim()
        def doDate =  line.split(",")[3].split(":")[1].trim()
        def year = doDate.substring(0, 4)
        def month = doDate.substring(5, 7)
        def day = doDate.substring(8, 10)
        
        // println "lv2Id = ${lv2Id}, type = ${type}, stat = ${stat}, doDate = ${doDate}"
        
        def lv2Data = patentInfoCNIPR.PatentInfoCNIPR.findOne([_id:new ObjectId(lv2Id)])
        def appNumber = lv2Data.appNumber
        
        /*
         * BOOKS 最早期下載，需要做一些破解動作才有辦法讀到資料  [1983-20110228]
         * newBOOKS 直接連 CNIPR 外部系統下載 [20110301-cur]
         * BOOKS-Bio 連 CNIPR 內部系統下載，僅有書目資料 [20110301-?]
         */
                
        // stat = 1 or 2
        // type = 发明专利 实用新型 外观专利
        def typeCode
        switch(type) {
            case "发明专利" :
            
                if (stat == "1") {
                    typeCode = 'FM'
                } else {
                    //
                    def yearListForSQ = ['1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008']
                    if (yearListForSQ.contains(year)) {
                        
                        if (year == '2008') {
                            def compareDate = "${month}${day}" as int
                            if (compareDate < 903) {
                                typeCode = 'SQ'
                            } else {
                                typeCode = 'SD'
                            }
                        } else {
                            typeCode = 'SQ'
                        }
                        
                    } else {
                        typeCode = 'SD'
                    }
                    
                }
                
                break
            case "实用新型" : 
            
                def yearListForXK = ['1985', '1986', '1987', '1988', '1989', '1990', '1991', '1992', ]
                if (yearListForXK.contains(year)) {
                    typeCode = 'XK'
                } else {
                    typeCode = 'XX'
                }
            
                break
            case "外观专利" : typeCode = 'WG'
                break
            Default :
                break
        }
        
        // FM/2015/20150708/201280065746.X
        def path = "${typeCode}/${year}/${year}${month}${day}/${appNumber}"
        // println "path = ${path}"
        def lv1Query = [path:path]
        
        def rawData127 = patentRawCNIPRFrom127.PatentRawCNIPR.findOne(lv1Query)
        def rawData121 = patentRawCNIPRFrom121.PatentRawCNIPR.findOne(lv1Query)
        
        // 資料如都存在121 || 127, 則以121為主.
        if (rawData121 != null && rawData127 != null) {
            def msg = "path:${path},raw exists in 127 and 121,LV2:${lv2Id},LV1:${rawData121._id}"
            println msg
            logFile << msg << ln
        } else if (rawData121) {
            def msg = "path:${path},raw exists in 121,LV2:${lv2Id},LV1:${rawData121._id}" 
            println msg
            logFile << msg << ln
        } else if (rawData127) {
            def msg = "path:${path},raw exists in 127,LV2:${lv2Id},LV1:${rawData127._id}"
            println msg
            logFile << msg << ln
        } else {
            def msg = "path:${path} no exists,LV2:${lv2Id}"
            println msg
            logFile << msg << ln
        }
        
        count++
    }
    
    
}

println "count = ${count}"
println "finished..."
