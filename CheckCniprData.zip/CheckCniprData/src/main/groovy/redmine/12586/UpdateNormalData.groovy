/**
 * 主要範疇有
 * 1. 公告/公開號正規化後存至 decisionNumberNormal / openNumber，CN + 流水號 + kindcode; ex CN1007060 A
 * 3. 申請號正規化後存至 appNumberNormal，CN + 流水號 + 驗證碼; ex CN1985107612
 * 4. IPC 相關欄位正規化後存至正規化欄位 (無法正規化的專利要存至 error db 追蹤)
 * 
 * ps1. patentNumber 請保持原本格式 (因為涉及到影像擋路徑，待號碼正規化完成後再來進行影像擋路徑相關任務)
 * 
 * stat = 1 => openNumber / openNumberNormal
 * 发明专利
 * 
 * stat = 2 => decisionNumber / decisionNumberNormal
 * 发明专利
 * 外观专利
 * 实用新型
 * 
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil
import org.apache.commons.lang3.StringUtils

import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def dbClient = client.getDB("PatentInfoCNIPR")

new File("doc/redmine/12586/current_date.txt").eachLine { line -> 

    def updateDate = line.toString()
    println "updateDate = ${updateDate}"
    def queryMap = [doDate: DateUtil.parseDate(updateDate)]
    println "queryMap = ${queryMap}"
    //
    updateNormalData(queryMap, dbClient)
    
}

// def queryMap = [_id: new ObjectId("55e1d70331c2a2f74cded8c0")]
// def queryMap = [doDate: DateUtil.parseDate("2010-01-06")]
// println "queryMap = ${queryMap}"
// updateNormalData(queryMap, dbClient)

println "finished..."

/**
 * 
 * @param updateDate
 * @param dbClient
 */
def void updateNormalData (queryMap, dbClient) {
    
    if (!queryMap) {
        throw new Exception("plz input query condition")
    }
    
    def curruntCount = 0
    def totalCount = dbClient.PatentInfoCNIPR.count(queryMap)
    
    dbClient.PatentInfoCNIPR.find(queryMap).each{ it ->
        
        def stat = it.stat
        def updateMap = [:]
        
        println "${formatQueryDate(it.doDate)} - lv2._id = ${it._id} - process ${++curruntCount} / ${totalCount}"
        
        try {
            // 公告/公開號正規化後存至 decisionNumberNormal / openNumberNormal => CN + 流水號 + kindcode; ex CN1007060A
            if (stat == 1) {
                //
                def openNumberNormal = getOpenOrDecisionNumberNormal(it.openNumber, it.kindcode)
                updateMap << [openNumberNormal : openNumberNormal]
                
            } else if (stat == 2) {
                //
                def decisionNumberNormal = getOpenOrDecisionNumberNormal(it.decisionNumber, it.kindcode)
                updateMap << [decisionNumberNormal : decisionNumberNormal]
                
            } else {
                throw new Exception("lv2._id = ${it._id}, wrong stat data...")
            }
            
            // 申請號正規化後存至 appNumberNormal，CN + 流水號 + 驗證碼; ex CN1985107612
            def appNumberNormal = getUpdateAppNumber(it.appNumber)
            updateMap << [appNumberNormal : appNumberNormal]
            
            if (it.type != '外观专利') {
                //
                def mainIPC = getUpdateMainIPC(it.mainIPC)
                def ipcs = getUpdateIpcs(it.ipcs)
                updateMap << [mainIPC : mainIPC]
                updateMap << [ipcs : ipcs]
            } else {
                //
                checkMainLOC(it.mainLOC)
                checkLocs(it.locs)
            }
            
            // update mongoSyncFlag.last / init
            updateMap << [mongoSyncFlag : [init: it.mongoSyncFlag.init, last: new Date()]]
            
            // println "updateMap = ${updateMap}"
            dbClient.PatentInfoCNIPR.update([_id: it._id], [$set: updateMap]);
            
            println "${formatQueryDate(it.doDate)} - lv2._id = ${it._id} - update complete"
            
        } catch (Exception ex) {
            //
            saveErrorNormalCNIPR(dbClient, it, ex)
        }
        
    }
    
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def String getUpdateMainIPC(mainIPC) {
    
    // 如已正規化後, 則return原值.
    if (mainIPC ==~ /^\w{4}\d{4}\d{6}$/) {
        return mainIPC;
    }
    
    // 未正規化 pattern
    def ipcGroup = mainIPC =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    
    if (ipcGroup.size() > 0) {
        
        // println "ipcGroup[0][1] = " + ipcGroup[0][1]
        // println "ipcGroup[0][2] = " + StringUtils.leftPad(ipcGroup[0][2], 4, '0')
        // println "ipcGroup[0][3] = " + StringUtils.leftPad(ipcGroup[0][3], 6, '0')
        // println "ipcGroup[0][4] = " + ipcGroup[0][4]
        
        def updateMainIPC
        
        if (!ipcGroup[0][1] || !ipcGroup[0][2] || !ipcGroup[0][3]) {
            //
            throw new Exception("mainIPC = ${mainIPC} normal pattern error")
        } else {
            
            return ipcGroup[0][1] + StringUtils.leftPad(ipcGroup[0][2], 4, '0') + StringUtils.rightPad(ipcGroup[0][3], 6, '0')
        }
        
    } else {
        //
        // println "no match pattern..."
        throw new Exception("mainIPC = ${mainIPC} no match pattern")
    }
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def getUpdateIpcs(ipcs) {
    //
    return ipcs.inject([]) { result, ipc -> result << getUpdateMainIPC(ipc) }
}

/**
 * mainLOC => 02-04, 基本上在現有的mongo shell中, 已經是以此規則來insert data.
 * 在此只是檢核相關欄位是否存在及其pattern是否正確.
 * 因為有發現CN在1985-09-10中, mainLOC不存在的資料.
 * 
 * @param mainLOC
 * @return
 */
def checkMainLOC(mainLOC) {
    
    if (!mainLOC) {
        throw new Exception("mainLOC dont exist")
    }
    
    if (!(mainLOC ==~ /^\d{2}-\d{2}(-\w{5})?$/)) {
        throw new Exception("mainLOC = ${mainLOC} no match pattern")
    }
    
}

/**
 * locs => 02-04, 基本上在現有的mongo shell中, 已經是以此規則來insert data.
 * 在此只是檢核相關欄位是否存在及其pattern是否正確.
 * 並順便查看locs是否真的只會有一筆資料而已. => CN 真的會有一筆以上的locs資料...
 * 
 * @param locs
 * @return
 */
def checkLocs(locs) {
    
    if (!locs) {
        throw new Exception("locs dont exist")
    }
    
    // if (locs.size() > 1) {
    //     throw new Exception("locs = ${locs} size more than 1")
    // }
    
    checkMainLOC(locs[0]);
    
}

/**
 * 申請號正規化後存至 appNumberNormal，CN + 流水號 + 驗證碼; ex CN1985107612
 * 
 * @param appNumber
 * @return
 */
def String getUpdateAppNumber(appNumber) {
    
    if (!!appNumber) {
        //
        return "CN" + StringUtils.replace(appNumber, ".", "");
    } else {
        throw new Exception("appNumber = ${appNumber} dont exist");
    }
    
}

/**
 * 公告/公開號正規化後存至 decisionNumberNormal / openNumberNormal => CN + 流水號 + kindcode; ex CN1007060A
 * 
 * @param openNumber
 * @return
 */
def String getOpenOrDecisionNumberNormal(numberData, kindcode) {
    
    def numberDataGroup = numberData =~ /^CN\d+[A-Z]?$/ 
    
    if (numberDataGroup.size() > 0) {
        
        def existKindcode = numberDataGroup[0][-1]
        
        if (!!kindcode) {
            //
            if (kindcode == existKindcode) {
                // println "kindcode == existKindcode"
                return numberData
            } else {
                throw new Exception("${numberData} kindcode = ${kindcode} is not equal the exist kindcode = ${existKindcode}");
            }
        } else {
            //
            return numberData
        }
        
    } else {
        throw new Exception("${numberData} no match pattern");
    }
    
}

/**
 * 
 * @param dbClient
 * @param lv2Data
 * @param ex
 */
def void saveErrorNormalCNIPR(dbClient, lv2Data, ex) {
    
    /*
     * errType = 1 => ipc
     * errType = 2 => loc
     * errType = 3 => appNumber
     * errType = 4 => openNumber or decisionNumber
     * 
     */
    def errType;
    def errMsg = ex.toString().split(":")[1].trim();
    // println "errMsg = ${errMsg}"
    
    if (errMsg.contains("IPC")) {
        errType = 1
    } else if (errMsg.contains("LOC")) {
        errType = 2
    } else if (errMsg.contains("appNumber")) {
        errType = 3
    } else {
        errType = 4
    }
    
    def errData = [:]
    errData << [_id: lv2Data._id]
    errData << [errType: errType]
    errData << [errMsg : errMsg]
    errData << [errDoDate: new Date()]
    errData << [doDate: lv2Data.doDate]
    errData << [upDateFlag: false]
    dbClient.ErrorNormalCNIPR.save(errData);
    
    println "${formatQueryDate(lv2Data.doDate)} - lv2._id = ${lv2Data._id} - save error msg complete - " + errMsg
}

def formatQueryDate(queryDate) {
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    return df.format(queryDate)
}
