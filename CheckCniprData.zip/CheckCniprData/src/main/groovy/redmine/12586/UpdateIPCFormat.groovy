// ObjectId("513049c04c7c348d1843e5dd")

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil
import org.apache.commons.lang3.StringUtils

import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def dbClient = client.getDB("PatentInfoCNIPR")

dbClient.PatentInfoCNIPR.find([_id: new ObjectId("513049c04c7c348d1843e5dd")]).each { it ->
    
    try {
        
        println it.mainIPC
        def mainIPC = it.mainIPC
        def updateMainIPC = ipcFormat(mainIPC)
        println updateMainIPC
        
        println it.ipcs
        def updateIpcs = it.ipcs.inject([]) { result, ipc ->
            def updateIPC = ipcFormat(ipc)
            result << updateIPC
        }
        println updateIpcs
        
        //dbClient.PatentInfoCNIPR.update([_id: queryData._id], [$set: [
        //
        //    // mainIPC: 'B60R0022000034',
        //    // ipcs: queryData.ipcs
        //
        //]])
        
    } catch (Exception e) {
        
        println "lv2._id = ${it._id} => " + e
    
    }
        
}

def ipcFormat(ipc) {
    
    if (ipc.length() != 14) {
        throw new Exception("ipc error")
    }
    
    return ipc.substring(0, 8) + StringUtils.rightPad(ipc.substring(8).replace("0", ""), 6, '0')
}

println "finished..."
