import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentRawCN = client.getDB("PatentRawCN")

// PatentCountCN
def doDateList = []

File file = new File("doc/redmine/12586/cn_pub_before_1990.txt")

patentRawCN.PatentCountCN.find([doDate:[$gte: DateUtil.parseDate("1985-09-10"), $lte: DateUtil.parseDate("1990-01-01")]]).each { it ->
    
    println it.doDate
    
    // 1990/1/3
    def doDate = new SimpleDateFormat("yyyy/MM/dd").format(it.doDate)
    
    doDateList << doDate
    
}

doDateList.toSet().sort().each{ it ->
    // println it
    file << it << ln
}

println "finished..."