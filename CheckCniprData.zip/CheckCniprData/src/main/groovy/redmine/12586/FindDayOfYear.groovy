Calendar cal = Calendar.getInstance()
cal.set(1985, 8, 10)

println cal.getTime()

System.out.println(cal.get(Calendar.DAY_OF_YEAR));