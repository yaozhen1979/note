/**
 * 
 */
import utils.MongoUtil

import org.bson.types.ObjectId
import org.common.utils.DateUtil

def ln = System.getProperty('line.separator')

def backupClient = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def lv2Client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def tonyDb = backupClient.getDB("TonyDB")

def lv2Db = lv2Client.getDB("PatentInfoCNIPR")

println "to start..."

def totalCount = lv2Db.PatentInfoCNIPR.count([doDate: DateUtil.parseDate("1985-09-10")])
    
lv2Db.PatentInfoCNIPR.find([doDate: DateUtil.parseDate("1985-09-10")]).eachWithIndex { it, index ->
    //
    it << ['redmine':['bug':12586]]
    
    tonyDb.PatentInfoCNIPR.save(it);
    
    println "process ${index + 1} / ${totalCount}"
}
    
println "finished..."
