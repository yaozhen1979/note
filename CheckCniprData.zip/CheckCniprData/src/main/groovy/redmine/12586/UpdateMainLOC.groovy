/**
 * 更新LV2資料中沒有mainLOC的資料, 已locs中的第一筆來做更新.
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil
import org.apache.commons.lang3.StringUtils

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import com.mongodb.Bytes

println "to start..."

def ln = System.getProperty('line.separator')

File errFile = new File("log/redmine/12586/err_locs/locs_no_exists.txt")

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def dbClient = client.getDB("PatentInfoCNIPR")

// db.ErrorNormalCNIPR.find({errMsg:'mainLOC dont exist'}).limit(5)

// 512fe921304a5deae37c6b61
// 512fe921304a5deae37c6b62
// 512fe921304a5deae37c6b63
// 512fe921304a5deae37c6b64
// 512fe921304a5deae37c6b65

def totalCount = dbClient.ErrorNormalCNIPR.count(errMsg:'mainLOC dont exist', upDateFlag: false)
def currentCount = 0

// 140964 => 2015 - 2002 -> .addOption(Bytes.QUERYOPTION_NOTIMEOUT) -> 73685
// 144146 => 2001 - 1998
// 66684  => 1997 - 1990
// 4214   => before 1990
dbClient.ErrorNormalCNIPR.find(errMsg:'mainLOC dont exist', upDateFlag: false).addOption(Bytes.QUERYOPTION_NOTIMEOUT).limit(0).each { it -> 
    
    // println it
    def queryData = dbClient.PatentInfoCNIPR.findOne([_id: it._id])
    
    if (!queryData.mainLOC) {
        //
        if (!!queryData.locs) {
            
            // println it
            
            // update cnipr lv2 mainLOC data
            def updateMap = [$set: [mainLOC: queryData.locs[0]]]
            //
            dbClient.PatentInfoCNIPR.update([_id: it._id], updateMap)
            dbClient.ErrorNormalCNIPR.update([_id: it._id], [$set: [upDateFlag: true]])
            
        } else {
            //
            def msg = "lv2._id = ${it._id}, locs no exists"
            println msg
            errFile << msg << ln
        }
    }
    
    println "process ${++currentCount} / ${totalCount}"
}

println "finished..."
