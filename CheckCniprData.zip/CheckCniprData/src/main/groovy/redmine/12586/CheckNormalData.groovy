/**
 * check normal data 的數量是否和lv2 data的數量一致
 *
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def dbClient = client.getDB("PatentInfoCNIPR")

new File("doc/redmine/12586/cn_pub_2006.txt").eachLine { line ->

    def updateDate = line.toString()
    println "updateDate = ${updateDate}"
    def queryMap = [doDate: DateUtil.parseDate(updateDate)]
    println "queryMap = ${queryMap}"
    //
    checkNormalData(queryMap, dbClient)
    
}

// def queryMap = [_id: new ObjectId("55e1d70331c2a2f74cded8c0")]
// def queryMap = [doDate: DateUtil.parseDate("2010-01-06")]
// println "queryMap = ${queryMap}"
// checkNormalData(queryMap, dbClient)

println "finished..."

/**
 *
 * @param updateDate
 * @param dbClient
 */
def void checkNormalData (queryMap, dbClient) {
    
    if (!queryMap) {
        throw new Exception("plz input query condition")
    }
    
    def ln = System.getProperty('line.separator')
    
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    def queryDate = df.format(queryMap.doDate)
    File logFile = new File("log/redmine/12586/check_normal_data_${queryDate}.log")
    
    def curruntCount = 0
    def normalCount = 0
    def totalCount = dbClient.PatentInfoCNIPR.count(queryMap)
    
    dbClient.PatentInfoCNIPR.find(queryMap).each{ it ->
        
        def checkAppNumberNormal = true;
        def checkOpenOrDecisionNumberNormal  = true;
        def checkIpcFlag = true
        
        if (!!it.appNumberNormal) {
            checkAppNumberNormal = true;
        } else {
            println "appNumberNormal normal data error"
            checkAppNumberNormal = false;
        }
        
        if (!!it.openNumberNormal || !!it.decisionNumberNormal) {
            checkOpenOrDecisionNumberNormal = true;
        } else {
            println "openNumberNormal or decisionNumberNormal normal data error"
            checkOpenOrDecisionNumberNormal = false;
        }
        
        if (it.type != "外观专利" && it.mainIPC.length() == 14 && it.ipcs[0].length() == 14) {
            checkIpcFlag = true;
        } else if (it.type == "外观专利") {
            // 目前先沒檢查 mainLOC && locs
            checkIpcFlag = true;
        } else {
            println "ipc normal error"
            checkIpcFlag = false;
        }
        
        if (checkAppNumberNormal && checkOpenOrDecisionNumberNormal && checkIpcFlag) {
            normalCount++;
        } else {
            println "lv2._id = ${it._id} normal data error"
            logFile << "lv2._id = ${it._id} normal data error" << ln
        }
        
    }
    
    println "${queryMap} = normalCount = ${normalCount}"
    logFile << "${queryMap} = normalCount = ${normalCount}" << ln
    
    println "${queryMap} = totalCount = ${totalCount}"
    logFile << "${queryMap} = totalCount = ${totalCount}" << ln
    
}
