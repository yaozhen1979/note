// ObjectId("513049c04c7c348d1843e5dd")

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil
import org.apache.commons.lang3.StringUtils

import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')
def dbClient = client.getDB("PatentInfoCNIPR")

// B29C45/20; //B29K 1 05
// ObjectId("512e2c8675949f0e717d8b8f")
def queryData = dbClient.PatentInfoCNIPR.findOne([_id: new ObjectId("512e2c8675949f0e717d8b8f")])

// list.add(0,myObject);

queryData.ipcs.add('B60R0022000034')

println queryData.ipcs

dbClient.PatentInfoCNIPR.update([_id: queryData._id], [$set: [

    // mainIPC: 'B60R0022000034',
    ipcs: queryData.ipcs
    
]])

println "finished..."
