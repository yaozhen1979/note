/**
 * 抓取history最後一筆的rawDataId, 來更新IPC, CPC.
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import jodd.jerry.Jerry
import static jodd.jerry.Jerry.jerry as $
import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.common.utils.DateUtil
import org.utils.StringUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv1Client = client.getDB("PatentRawDOCDB")
def lv2Client = client.getDB("PatentInfoDOCDB")

def ccList = [
    "AM", "AP", "AR", "AT", "AU",
    "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR",
    "UA", "UY",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

ccList.each { cc ->
    def queryMap = [country: cc]
    println "queryMap = ${queryMap}"
    //
    updateIPCAndCPCFormat(queryMap, lv1Client, lv2Client)
}

// 單筆更新
// 557a982ab4411f24f16d9d35 : IPC, CPC 都有
// 557e1d6ba28219ce5ef30b90 : IPC
// 557a98a1b4411f24f16dcf11 : CPC
// 558c7ad3b4411f24f126e1f5 : IPC format = G06K 20060101S
// 558de2dab4411f24f15da712 ???
//def queryMap = [_id: new ObjectId("558de2dab4411f24f15da712")]
//println "queryMap = ${queryMap}"
//updateIPCAndCPCFormat(queryMap, lv1Client, lv2Client)

/**
 * 
 * @param queryMap
 * @param lv1Client
 * @param lv2Client
 */
def void updateIPCAndCPCFormat (queryMap, lv1Client, lv2Client) {
    
    if (!queryMap) {
        throw new Exception("plz input query condition")
    }
    
    def curruntCount = 0
    def totalCount = lv2Client.PatentInfoDOCDB.count(queryMap)
    
    lv2Client.PatentInfoDOCDB.find(queryMap).each { it ->
        
        def updateMap = [:]
        
        println "${it.country} - lv2._id = ${it._id} - process ${++curruntCount} / ${totalCount}"
        
        if (!it.mainIPC && !it.mainCPC) {
            println "${it.country} - lv2._id = ${it._id} - no update"
            return
        }
        
        try {
            
            def lv1Id = it.history[-1].rawDataId
            
            def lv1 = lv1Client.PatentRawDOCDB.findOne([_id: lv1Id])
            
            def output = lv1.data.xml
            def dom = $(output)
            
            if (!!it.mainIPC) {
                
                def mainIPC = getMainIPC(dom)
                def ipcs = getIpcs(dom)
                
                updateMap << [mainIPC : mainIPC]
                updateMap << [ipcs : ipcs]
            }
            
            if (!!it.mainCPC) {
                
                def mainCPC = getMainCPC(dom)
                def cpcs = getCpcs(dom)
                
                updateMap << [mainCPC : mainCPC]
                updateMap << [cpcs : cpcs]
            }
            
            // println "updateMap = ${updateMap}"
            lv2Client.PatentInfoDOCDB.update([_id: it._id], [$set: updateMap]);
            
            println "${it.country} - lv2._id = ${it._id} - update complete"
            
        } catch (Exception ex) {
            //
            // ex.printStackTrace()
            saveErrorIPCorCPCFormat(lv2Client, it, ex)
        }
            
    }  // end find function
    
}  // end updateIPCAndCPCFormat function

def void saveErrorIPCorCPCFormat(dbClient, lv2Data, ex) {
    
    /*
     * errType = 1 => ipc
     * errType = 2 => cpc
     * errType = 3 => other
     *
     */
    def errType;
    def errMsg = ex.toString().split(":")[1].trim();
    // println "errMsg = ${errMsg}"
    
    if (errMsg.contains("IPC")) {
        errType = 1
    } else if (errMsg.contains("CPC")) {
        errType = 2
    } else {
        errType = 3
    }
    
    def errData = [:]
    errData << [_id: lv2Data._id]
    errData << [errType: errType]
    errData << [errMsg : errMsg]
    errData << [errDoDate: new Date()]
    errData << [doDate: lv2Data.doDate]
    errData << [updateFlag: false]
    dbClient.ErrorIPCorCPCFormat.save(errData);
    
    println "${lv2Data.country} - lv2._id = ${lv2Data._id} - save error msg complete - " + errMsg
}

println "finished..."

////////////////////////////////

/**
 *
 * @param dom
 * @return
 */
static getIpcs(Jerry dom) {
        
    def ipcs = []
    dom.find("exch\\:classifications-ipcr > classification-ipcr > text").each{element ->
        def ipc = element.text();
        def text = ipc.split(/(?i)\s+/);
        if (ipc.trim() != '' && text.length > 1) {
            ipcs.push(text[0] + " " + text[1]);
        } else {
            // TODO: special case: ???
            def specialCpcFmt = text[0].split("/")
            if (specialCpcFmt.length == 2) {
                //
                ipcs.push(text[0].substring(0, 4) + " " + text[0].substring(4));
            } else {
                throw new Exception("ipc error format")
            }
        
        }

    };
    
    return ipcs;
}

/**
 *
 * @param dom
 * @return
 */
static getMainIpc(Jerry dom) {
    return !!getIpcs(dom) ? getIpcs(dom)[0] : "";
}

/**
 *
 * @param dom
 * @return
 */
static getIpcsNormal(Jerry dom) {
        
    def ipcs = []
    dom.find("exch\\:classifications-ipcr > classification-ipcr > text").each{element ->
        def ipc = element.text();
        def text = ipc.split(/(?i)\s+/);
        if (ipc.trim() != '' && text.length > 1) {
            ipcs.push(getIPCNormal(text[0] + " " + text[1]));
        } else {
            // TODO: special case: ???
            def specialCpcFmt = text[0].split("/")
            if (specialCpcFmt.length == 2) {
                //
                ipcs.push(getIPCNormal(text[0].substring(0, 4) + " " + text[0].substring(4)));
            } else {
                throw new Exception("ipc error format")
            }
        
        }

    };
    
    return ipcs;
}

/**
 *
 * @param dom
 * @return
 */
static getMainIpcNormal(Jerry dom) {
    return !!getIpcsNormal(dom) ? getIpcsNormal(dom)[0] : "";
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015100000
 *
 */
static String getIPCNormal(String ipc) {
    
    // 如已正規化後, 則return原值.
    if (ipc ==~ /^\w{4}\d{4}\d{6}$/) {
        return ipc;
    }
    
    // 未正規化 pattern
    def ipcGroup1 = ipc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    def ipcGroup2 = ipc.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
    
    if (ipcGroup1.size() > 0) {
        
        if (!ipcGroup1[0][1] || !ipcGroup1[0][2] || !ipcGroup1[0][3]) {
            //
            throw new Exception("ipc = ${ipc} normal pattern error")
        } else {
            return ipcGroup1[0][1] + StringUtil.leftPad(ipcGroup1[0][2], 4, '0') + StringUtil.rightPad(ipcGroup1[0][3], 6, '0')
        }
        
    } else if (ipcGroup2.size() > 0) {
    
        if (!ipcGroup2[0][1] || !ipcGroup2[0][2]) {
            //
            throw new Exception("ipc = ${ipc} normal pattern error")
        } else {
            //
            return ipcGroup2[0][1] + StringUtil.leftPad('', 10, '0')
        }
    
    } else {
        //
        // println "no match pattern..."
        throw new Exception("ipc = ${ipc} no match pattern")
    }
}

/**
 *
 * @param dom
 * @return
 */
static getCpcs(Jerry dom) {
    
    def cpcs = [];
    dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=CPC]").each{ element ->

        def cpc = element.parent().find("classification-symbol").text();
        def text = cpc.split(/(?i)\s+/);
        // println "cpc = ${text}"
        
        if (cpc.trim() != '' && text.length > 1) {
            cpcs.push(text[0] + " " + text[1]);
        } else {
            // special case: lv2._id = 557a98a1b4411f24f16dcf11 => cpc = G01N2291/044
            def specialCpcFmt = text[0].split("/")
            if (specialCpcFmt.length == 2) {
                //
                cpcs.push(text[0].substring(0, 4) + " " + text[0].substring(4));
            } else {
                throw new Exception("cpc error format")
            }
        
        }

    }

    return !cpcs ? "" : cpcs;
}

/**
 *
 * @param dom
 * @return
 */
static getMainCPC(Jerry dom) {
    return !!getCpcs(dom) ? getCpcs(dom)[0] : "";
}

/**
 *
 * @param dom
 * @return
 */
static getCpcsNormal(Jerry dom) {
    
    def cpcs = [];
    dom.find("exch\\:patent-classifications > patent-classification > classification-scheme[scheme=CPC]").each{ element ->

        def cpc = element.parent().find("classification-symbol").text();
        def text = cpc.split(/(?i)\s+/);
        // println "cpc = ${text}"
        
        if (cpc.trim() != '' && text.length > 1) {
            cpcs.push(getCPCNormal(text[0] + " " + text[1]));
        } else {
            // special case: lv2._id = 557a98a1b4411f24f16dcf11 => cpc = G01N2291/044
            def specialCpcFmt = text[0].split("/")
            if (specialCpcFmt.length == 2) {
                //
                cpcs.push(getCPCNormal(text[0].substring(0, 4) + " " + text[0].substring(4)));
            } else {
                throw new Exception("cpc error format")
            }
        
        }

    }

    return !cpcs ? "" : cpcs;
}

/**
 *
 * @param dom
 * @return
 */
static getMainCPCNormal(Jerry dom) {
    return !!getCpcsNormal(dom) ? getCpcsNormal(dom)[0] : "";
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015100000
 *
 */
static String getCPCNormal(String cpc) {
    
    // 如已正規化後, 則return原值.
    if (cpc ==~ /^\w{4}\d{4}\d{6}$/) {
        return cpc;
    }
    
    // 未正規化 pattern
    def cpcGroup1 = cpc.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    def cpcGroup2 = cpc.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
    
    if (cpcGroup1.size() > 0) {
        
        if (!cpcGroup1[0][1] || !cpcGroup1[0][2] || !cpcGroup1[0][3]) {
            //
            throw new Exception("cpc = ${cpc} normal pattern error")
        } else {
            
            return cpcGroup1[0][1] + StringUtil.leftPad(cpcGroup1[0][2], 4, '0') + StringUtil.rightPad(cpcGroup1[0][3], 6, '0')
        }
        
    } else if (cpcGroup2.size() > 0) {
    
        if (!cpcGroup2[0][1] || !cpcGroup2[0][2]) {
            //
            throw new Exception("cpc = ${cpc} normal pattern error")
        } else {
            //
            return cpcGroup2[0][1] + StringUtil.leftPad('', 10, '0')
        }
    
    } else {
        //
        // println "no match pattern..."
        throw new Exception("cpc = ${cpc} no match pattern")
    }
}

