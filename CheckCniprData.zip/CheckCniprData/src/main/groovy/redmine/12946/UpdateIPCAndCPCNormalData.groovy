/**
 * 主要範疇有
 * 1. IPC 相關欄位正規化後存至正規化欄位 (無法正規化的專利要存至 error db 追蹤)
 * 2. CPC 相關欄位正規化後存至正規化欄位 (無法正規化的專利要存至 error db 追蹤)
 * 
 * tag: v1.0.0
 * 
 * TODO: country: DD => 因有重複更新, 所以 tagAndJsfile 會有二筆的UpdateIPCAndCPCNormalData.groovy, 有空時, 可再處理...
 * 
 * 
 * 
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import utils.MongoUtil
import org.apache.commons.lang3.StringUtils

import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def dbClient = client.getDB("PatentInfoDOCDB")

def ccList = [
    // "AM", "AP", "AR", "AT", "AU",
    // "BE", "BG", "BR", "BY",
    // "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR",
    "UA", "UY",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

println "ccList = ${ccList.size()}"

testList = ['AM']

ccList.each { cc ->

    def queryMap = [country: cc]
    println "queryMap = ${queryMap}"
    //
    updateIPCAndCPCNormalData(queryMap, dbClient)
    
}

// 單筆更新
// 557a982ab4411f24f16d9d35 : IPC, CPC 都有
// 557e1d6ba28219ce5ef30b90 : IPC
// 557a98a1b4411f24f16dcf11 : CPC
// 558c7ad3b4411f24f126e1f5 : IPC format = G06K 20060101S
// def queryMap = [_id: new ObjectId("557a98a1b4411f24f16dcf11")]
// println "queryMap = ${queryMap}"
// updateIPCAndCPCNormalData(queryMap, dbClient)

println "finished..."

/**
 *
 * @param updateDate
 * @param dbClient
 */
def void updateIPCAndCPCNormalData (queryMap, dbClient) {
    
    if (!queryMap) {
        throw new Exception("plz input query condition")
    }
    
    def curruntCount = 0
    def totalCount = dbClient.PatentInfoDOCDB.count(queryMap)
    
    dbClient.PatentInfoDOCDB.find(queryMap).each{ it ->
        
        def updateMap = [:]
        
        println "${it.country} - lv2._id = ${it._id} - process ${++curruntCount} / ${totalCount}"
        
        if (!it.mainIPC && !it.mainCPC) {
            println "${it.country} - lv2._id = ${it._id} - no update"
            return
        }
        
        try {
            
            if (!!it.mainIPC) {
                def mainIPC = getUpdateMainIPC(it.mainIPC)
                def ipcs = getUpdateIpcs(it.ipcs)
                updateMap << [mainIPC : mainIPC]
                updateMap << [ipcs : ipcs]
            }
            
            if (!!it.mainCPC) {
                def mainCPC = getUpdateMainCPC(it.mainCPC)
                def cpcs = getUpdateCpcs(it.cpcs)
                updateMap << [mainCPC : mainCPC]
                updateMap << [cpcs : cpcs]
            }
            
            // update mongoSyncFlag.last / init
            updateMap << [mongoSyncFlag : [init: it.mongoSyncFlag.init, basicInfo: it.mongoSyncFlag.basicInfo, last: new Date()]]
            
            // tagAndJsfile file / tag
            updateMap << [tagAndJsfile : it.tagAndJsfile << [file: 'UpdateIPCAndCPCNormalData.groovy', tag: 'v1.0.0']]
            
            println "updateMap = ${updateMap}"
            // dbClient.PatentInfoDOCDB.update([_id: it._id], [$set: updateMap]);
            
            println "${it.country} - lv2._id = ${it._id} - update complete"
            
        } catch (Exception ex) {
            //
            saveErrorNormalDOCDB(dbClient, it, ex)
        }
        
    }
    
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def String getUpdateMainIPC(mainIPC) {
    
    // 如已正規化後, 則return原值.
    if (mainIPC ==~ /^\w{4}\d{4}\d{6}$/) {
        return mainIPC;
    }
    
    // 未正規化 pattern
    def ipcGroup1 = mainIPC.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    def ipcGroup2 = mainIPC.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
    
    if (ipcGroup1.size() > 0) {
        
        if (!ipcGroup1[0][1] || !ipcGroup1[0][2] || !ipcGroup1[0][3]) {
            //
            throw new Exception("mainIPC = ${mainIPC} normal pattern error")
        } else {
            
            return ipcGroup1[0][1] + StringUtils.leftPad(ipcGroup1[0][2], 4, '0') + StringUtils.rightPad(ipcGroup1[0][3], 6, '0')
        }
        
    } else if (ipcGroup2.size() > 0) {
    
        if (!ipcGroup2[0][1] || !ipcGroup2[0][2]) {
            //
            throw new Exception("mainIPC = ${mainIPC} normal pattern error")
        } else {
            //
            return ipcGroup2[0][1] + StringUtils.leftPad('', 10, '0')
        }
    
    } else {
        //
        // println "no match pattern..."
        throw new Exception("mainIPC = ${mainIPC} no match pattern")
    }
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def getUpdateIpcs(ipcs) {
    //
    return ipcs.inject([]) { result, ipc -> result << getUpdateMainIPC(ipc) }
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def String getUpdateMainCPC(mainCPC) {
    
    // 如已正規化後, 則return原值.
    if (mainCPC ==~ /^\w{4}\d{4}\d{6}$/) {
        return mainCPC;
    }
    
    // 未正規化 pattern
    def cpcGroup1 = mainCPC.trim() =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/
    def cpcGroup2 = mainCPC.trim() =~ /^(\S{4})[\s\-]*(\S+)$/
    
    if (cpcGroup1.size() > 0) {
        
        if (!cpcGroup1[0][1] || !cpcGroup1[0][2] || !cpcGroup1[0][3]) {
            //
            throw new Exception("mainCPC = ${mainCPC} normal pattern error")
        } else {
            
            return cpcGroup1[0][1] + StringUtils.leftPad(cpcGroup1[0][2], 4, '0') + StringUtils.rightPad(cpcGroup1[0][3], 6, '0')
        }
        
    } else if (cpcGroup2.size() > 0) {
    
        if (!cpcGroup2[0][1] || !cpcGroup2[0][2]) {
            //
            throw new Exception("mainCPC = ${mainCPC} normal pattern error")
        } else {
            //
            return cpcGroup2[0][1] + StringUtils.leftPad('', 10, '0')
        }
    
    } else {
        //
        // println "no match pattern..."
        throw new Exception("mainCPC = ${mainCPC} no match pattern")
    }
}

/*
 * 更新正規化格式 => section(1碼) + class(2碼) + subclass(1碼) + main-group(4碼，不足在左方補0) + subgroup(6碼，不足在右方補0) => 共14碼
 *
 * EX: E02B 15/10 => E02B0015000010
 *
 */
def getUpdateCpcs(cpcs) {
    //
    return cpcs.inject([]) { result, cpc -> result << getUpdateMainCPC(cpc) }
}

/**
 *
 * @param dbClient
 * @param lv2Data
 * @param ex
 */
def void saveErrorNormalDOCDB(dbClient, lv2Data, ex) {
    
    /*
     * errType = 1 => ipc
     * errType = 2 => cpc
     * errType = 3 => other
     *
     */
    def errType;
    def errMsg = ex.toString().split(":")[1].trim();
    // println "errMsg = ${errMsg}"
    
    if (errMsg.contains("IPC")) {
        errType = 1
    } else if (errMsg.contains("CPC")) {
        errType = 2
    } else {
        errType = 3
    }
    
    def errData = [:]
    errData << [_id: lv2Data._id]
    errData << [errType: errType]
    errData << [errMsg : errMsg]
    errData << [errDoDate: new Date()]
    errData << [doDate: lv2Data.doDate]
    errData << [updateFlag: false]
    dbClient.ErrorNormalDOCDB.save(errData);
    
    println "${lv2Data.country} - lv2._id = ${lv2Data._id} - save error msg complete - " + errMsg
}

def formatQueryDate(queryDate) {
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    return df.format(queryDate)
}
