// check_127_raw_data_by_doDate.txt
// check_121_raw_data_by_doDate.txt

import groovy.json.JsonSlurper
import utils.MongoUtil
import org.bson.types.ObjectId
import org.common.utils.DateUtil
import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;
import java.text.SimpleDateFormat;
import utils.DateUtil
import utils.MailUtil

println "to start..."

def ln = System.getProperty("line.separator")

File fileLog121 = new File("log/redmine/12602/recovery_121_data.txt")
// File fileLog127 = new File("log/redmine/12602/check_127_raw_data_by_doDate.txt")
// File fileLog = new File("log/redmine/12602/check_raw_data_by_doDate.txt")

def client127 = MongoUtil.connect2X('yyj', 'yyj', "10.60.90.127", 27017, 'admin')
def client121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def client101 = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentRawCNIPR127 = client127.getDB("PatentRawCNIPR")
def patentRawCNIPR121 = client121.getDB("PatentRawCNIPR")
def patentRawCN = client101.getDB("PatentRawCN")

try {
    
    fileLog121.eachLine { line ->
        
        def splitData = line.toString().split(',')
        
        def doDate = splitData[0].split("=")[1].trim()
        def dbIp = splitData[1].split("in")[1].trim()
        // println "doDate = ${doDate}, dbIp = ${dbIp}"
        
        def queryDoDate = DateUtil.parseDate(doDate)
        
        def count = patentRawCN.PatentRawCN.count([doDate: queryDoDate])
        println "doDate = ${doDate}, count = ${count}"
        
        if (count == 0) {
            
            if (dbIp == '10.60.90.121') {
                
                def countFrom121 = patentRawCNIPR121.PatentRawCNIPR.count([doDate: queryDoDate])
                
                patentRawCNIPR121.PatentRawCNIPR.find([doDate: queryDoDate]).eachWithIndex { it, index ->
                    
                    patentRawCN.PatentRawCN.save(it)
                    
                    println "doDate = ${doDate} process ${index + 1} / ${countFrom121}"
                }
                
            } else if (dbIp == '10.60.90.127') {
                
                def countFrom127 = patentRawCNIPR127.PatentRawCNIPR.count([doDate: queryDoDate])
                
                patentRawCNIPR127.PatentRawCNIPR.find([doDate: queryDoDate]).eachWithIndex { it, index ->
                    
                    patentRawCN.PatentRawCN.save(it)
                    
                    println "doDate = ${doDate} process ${index + 1} / ${countFrom127}"
                }
            
            }
            
        }
        
    }
    
} catch (e) {
    
    MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "import_raw_data_to_101 Error", e.toString())

    println "e = ${e.toString()}"

}

println "finished..."
