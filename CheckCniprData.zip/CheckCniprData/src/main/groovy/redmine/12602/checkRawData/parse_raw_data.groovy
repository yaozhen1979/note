/**
 * check 127 && 121 在SIPO中的數量是否一致
 */
import utils.MongoUtil
import org.bson.types.ObjectId
import org.common.utils.DateUtil
import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;
import java.text.SimpleDateFormat;
import utils.DateUtil
import utils.MailUtil

println "to start..."

def ln = System.getProperty("line.separator")

def client101 = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// def patentRawCNIPR127 = client127.getDB("PatentRawCNIPR")
// def patentRawCNIPR121 = client121.getDB("PatentRawCNIPR")
def patentRawCN = client101.getDB("PatentRawCN")

// log/redmine/12602/check_raw_data_by_doDate.txt
new File("log/redmine/12602/check_raw_data_by_doDate.txt").eachLine { line -> 
    
    if (line.toString().startsWith("doDate")) {
        def total = 0
        def doDate = line.toString().split(",")[0].split("=")[1].trim()
        println "doDate = ${doDate}"
        patentRawCN.PatentCountCN.find([doDate: DateUtil.parseDate(doDate)]).each {
            total = total + it.count
        }
        println "SIPO count = ${total}"
    }
    
    if (line.toString().startsWith("10.60.90.121")) {
        println line    
    }
    
    if (line.toString().startsWith("10.60.90.127")) {
        println line
    }
    
    if (line.toString() == "data count no match") {
        println "========================"
    }
    
}