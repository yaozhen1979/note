import groovy.json.JsonSlurper
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
// import org.common.utils.DateUtil
import utils.DateUtil

def ln = System.getProperty("line.separator")

File fileLog121 = new File("log/redmine/12602/check_121_raw_data_by_doDate.txt")

File fileLog127 = new File("log/redmine/12602/check_127_raw_data_by_doDate.txt")

File fileLog = new File("log/redmine/12602/check_raw_data_by_doDate.txt")

def client127 = MongoUtil.connect2X('yyj', 'yyj', "10.60.90.127", 27017, 'admin')

def client121 = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentRawCNIPR127 = client127.getDB("PatentRawCNIPR")

def patentRawCNIPR121 = client121.getDB("PatentRawCNIPR")

def checkYear = [
    1985, 1986, 1987, 1988, 1989,
    1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999,
    2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009,
    2010, 2011, 2012, 2013, 2014, 2015
]

def testYear = [1985]

checkYear.each { year ->
    
    new File("doDate/${year}.txt").eachLine { doDate ->
        
        println "check doDate = ${doDate}"
        
        def lv1CountFrom127 = patentRawCNIPR127.PatentRawCNIPR.count(doDate: DateUtil.parseDate(doDate))
        def lv1CountFrom121 = patentRawCNIPR121.PatentRawCNIPR.count(doDate: DateUtil.parseDate(doDate))
        
        if (lv1CountFrom121 > 0 && lv1CountFrom127 > 0) {
            fileLog << "doDate = ${doDate}, data exists in 10.60.90.121 and 10.60.90.127" << ln
            fileLog << "10.60.90.121 count = ${lv1CountFrom121}" << ln
            fileLog << "10.60.90.127 count = ${lv1CountFrom127}" << ln
            if (lv1CountFrom121 != lv1CountFrom127 ) {
                fileLog << "data count no match" << ln    
            } else {
                fileLog << "data count match" << ln
            }
            fileLog << "=======================================" << ln
        } else if (lv1CountFrom127 > 0) {
            fileLog127 << "doDate = ${doDate}, data exists in 10.60.90.127" << ln
        } else if (lv1CountFrom121 > 0) {
            fileLog121 << "doDate = ${doDate}, data exists in 10.60.90.121" << ln
        }
        
    }
    
}

println 'finished!'
