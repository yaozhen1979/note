import groovy.json.JsonSlurper

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import jodd.jerry.Jerry
import static jodd.jerry.Jerry.jerry as $
import utils.MongoUtil

import org.apache.commons.lang3.StringUtils
import org.bson.types.ObjectId
import org.common.utils.DateUtil

println "to start..."

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def tonyDB = client.getDB("TonyDB")

// 2626000
def rows = 1000
def totalCount = 11295639
def totalPage = 11295639 / rows + 1
def current = 2625000 / rows
def showCount = 2625000

while (true) {
    
    try {
        
        for (def i = current; i < totalPage; i++ ) {
            
            println "solr start page = ${i}"
            
            def insertData = [:]
            
            def solrData = solr(i * rows, rows);
            
            def backupDataList = solrData.response.docs
            // println backupDataList
            
            backupDataList.each { backupData ->
                
                // println "backupData = ${backupData}"
                //
                def objectId = backupData.ptopid.replace("CNIPR.", "").trim()
                // println "objectId = ${objectId}"
                insertData << [_id: new ObjectId(objectId)]
                
                def mainIPC = backupData.mainIPC
                // println "mainIPC = ${mainIPC}"
                insertData << [mainIPC: mainIPC]
                
                def ipcs = backupData.ipcs
                // println "ipcs = ${ipcs}"
                insertData << [ipcs: ipcs]
                
                // println "insertData = ${insertData}"
                
                tonyDB.BackupCnMainIPCAndIpcs.save(insertData)
                
                println "solr save ${++showCount} / ${totalCount} ok"
            }
            
        }
        
        if (showCount == totalCount) {
            break;
        }
        
    } catch (Exception ex) {
        
        current = showCount / rows;
        println "ex = ${ex}"
    
    }
    
}

println 'finished!'

//
def solr(start, rows) {
    
    sleep(1000)
    def xml = ("http://10.60.90.160:5566/solr/cn/select?q=mainIPC%3A*+OR+ipcs%3A+*&start=${start}&rows=${rows}&fl=ptopid%2C+mainIPC%2C+ipcs&wt=json").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
