/**
 * check script: 以doDate來check solr index 和 CN Lv2 中的數量差異.
 */
import groovy.json.JsonSlurper
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
// import org.common.utils.DateUtil
import utils.DateUtil

def ln = System.getProperty("line.separator")

def client = MongoUtil.connect2X('patentdata', 'data.cloud.Abc12345', "10.60.90.121", 27017, 'admin')

def patentInfoCNIPR = client.getDB("PatentInfoCNIPR")

def checkYear = [
    1985, 1986, 1987, 1988, 1989, 
    1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 
    2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009,
    2010, 2011, 2012, 2013, 2014, 2015
]

// def testYear = [1985]

def totalDiffCount = 0

checkYear.each { year -> 
    
    new File("doDate/${year}.txt").eachLine { doDate ->
        
        def solrData = solr("doDate:\"${doDate}T00:00:00Z\"");
        def solrCount = solrData.response.numFound
        def lv2Count = patentInfoCNIPR.PatentInfoCNIPR.count(doDate: DateUtil.parseDate(doDate))
        
        if (solrCount != lv2Count) {
            println "solrCount = ${solrCount}"
            println "lv2Count = ${lv2Count}"
            def diffCount = lv2Count - solrCount
            println "${doDate} no match => ${diffCount}"
            totalDiffCount += diffCount
        } else {
            // println "${doDate} match"
        }
        
        
    }
    
}

println "totalDiffCount = ${totalDiffCount}"

println 'finished!'

def solr(querystr) {
    
    def query = java.net.URLEncoder.encode(querystr);
    
    // http://10.60.90.112:5566/solr/cn/select?q=doDate%3A%221985-09-10T00%3A00%3A00Z%22&fl=pto&wt=json
    def xml = ("http://10.60.90.112:5566/solr/cn/select?q=${query}&fl=pto&wt=json").toURL().text
    // def xml = ("http://10.60.90.112:5566/solr/cn/select?q=doDate%3A%221985-09-10T00%3A00%3A00Z%22&fl=pto&wt=json").toURL().text
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(xml)
    return object;
}
