@Grab('org.jsoup:jsoup:1.8.2')

/**
 * Sipo 事務數據查詢
 * 官網都是每周三發佈
 */

def a = ''

System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' ]

def numType = "18"  //transfer
//numType = "7"   //license
def querydate = '2015.09';
File file = new File("T:/cnlist/assignmentTransfer/sipo-${querydate}-${numType}.txt");
def ln = System.getProperty('line.separator')

def nextPage = true;
def pageNum = 1;    //from 1
def pageSize = 10;
println "date: ${querydate} type:${numType}"
while (nextPage) {
    def doc = null;
    
    def retry = 0;
    while (retry < 70)  {
        try {
            println "start parse"
            doc = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/overTran.action").timeout(300000)
                    .data("strWord", "法律状态公告日='${querydate}'")
                    .data("numType", numType)
                    .data("strLicenseCode", "")
                    .data("selected", "")
                    .data("pageSize", pageSize.toString())
                    .data("pageNow", pageNum.toString())
                    .data("numSortMethod", "3")     //按事务数据公告日升序排序
                    .data("numFM", "0")
                    .data("numXX", "0")
                    .data("numWG", "0")
                    .header("Origin", "http://epub.sipo.gov.cn")
                    .header("Referer", "http://epub.sipo.gov.cn/flzt.jsp")
                    .header("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36")
                    .post();
            break;
        } catch (Exception e) {
            retry++;
            if(retry % 10==0) {
                Thread.sleep(1000*60*5)
            }
            println "e = " + e
            println 'will retry list:' + retry
        }
    }
    println "doc:${doc}"
    if (doc == null) {
        println 'could not get list!';
        break;
    }
    
    def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
    def cnt = cntt.substring(5, cntt.length()-1) as int
    def pages = ((cnt + pageSize - 1) / pageSize) as int
    println "cnt:${cnt} pages:${pageNum}/${pages}"
    
    doc.select(".list_dl + table a").each { node->
        def no = node.text()    
        println "no: ${no}"
        def fdoc = null;
        retry = 0;
        while (retry < 70)  {
            try {
                fdoc = org.jsoup.Jsoup.connect("http://epub.sipo.gov.cn/fullTran.action").timeout(300000)
                        .data("an", no)
                        .post();
                break;
            } catch (Exception e) {
                retry++;
                if(retry % 10==0) {
                    Thread.sleep(1000*60*5)
                }
                println 'will retry doc:' + retry
            }
        }
        if (fdoc == null) {
            println 'could not get data!';
            file << num << ln
            return;
        }
        def title = fdoc.select(".flzt_h1tit").text();
        def tds = null;
        
        fdoc.select(".table_flztxx").each {
            def tmp = it.select("table[cellpadding=3] td")
            if (numType == "18" && tmp[7].text() == '专利申请权、专利权的转移' && tds == null) {
                tds = tmp;
            }
            if (numType == "7" && tmp[7].text() == '授权' && tds == null) {
                tds = tmp;
            }
        }
        
        def ipc = null;
        if (numType == "7") {
            fdoc.select(".table_flztxx").each {
                def tmp = it.select("table[cellpadding=3] td")
                def t = tmp[8].html()
                t = t.replaceAll(/<br \/>/, "<br>")
                t.split(/<br>/).each {
                    def v = it.split(':');
                    if (v[0]=='IPC(主分类)') {
                        ipc = v[1];
                    }
                }
            }
        }
        
        def num = tds[1].text()
        def date = tds[5].text()
        def line = null
        if (numType == "18") {
            def t = tds[8].html()
            def map = [:]
            t = t.replaceAll(/<br \/>/, "<br>")
            t.split(/<br>/).each {
                def v = it.split(':');
                if (v.length > 1) {
                    if (map[v[0]] == null)
                        map[v[0]] = v[1]
                }
            }
            if (map['变更前权利人'] == null || map['变更后权利人'] == null || map['IPC(主分类)'] == null) {
                println "${num} err!";
            }
            line = num + '\t' + date + '\t' + map['变更前权利人'] + '\t' + map['变更后权利人'] + '\t' + map['IPC(主分类)'] + '\t' + title
        } else {
            line = num + '\t' + date + '\t' + (ipc==null?"":ipc) + '\t' + title
        }
        //println line
        file << line << ln
    }
    pageNum++
    if (pageNum > pages) {
        break
    }
}        
println 'finished!'
//println doc