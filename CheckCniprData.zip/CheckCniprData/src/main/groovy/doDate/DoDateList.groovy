import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
// import org.common.utils.DateUtil
import utils.DateUtil

def ln = System.getProperty("line.separator")

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentRawCN = client.getDB("PatentRawCN")

def count = patentRawCN.PatentCountCN.count()

println "to start..."

def tempDoDate = ""

patentRawCN.PatentCountCN.find().sort([doDate:1]).limit(0).eachWithIndex { it, index -> 

    // 1985-12-17T00:00:00Z
    def doDate = DateUtil.toISODate(it.doDate, "yyyy-MM-dd")
    
    
    if (tempDoDate != doDate) {
        File doDateFile = new File("doDate/${doDate.substring(0,4)}.txt")
        doDateFile << "${doDate}" << ln
        tempDoDate = doDate
    }
    
    println "process ${index + 1} / ${count}"
}

println "finished..."
