///**
// *  calculate CN check code
// *  ex:
// *  87103893 => 87103893.5
// *  201280061024 => 201280061024.7
// *  1234567890kk => 1234567890kk (error format)
// *
// */

package utils

class CnCheckCodeUtil {
    
    /**
     * 依輸入的appNumber來取得字尾驗證碼
     * 
     * @param appNumber
     * @return
     * @throws Exception
     */
    static String getCheckCode(appNumber) throws Exception {
        
        def mod
        def divisor = 11
        
        if (!!appNumber) {
            
            // check appNumber 是否為 Number
            if (appNumber ==~ /\D+/) {
                throw new Exception("the format of appNumber must be number")
            }
            
            if (appNumber.length() == 12) {
                //
                int x4 = Integer.valueOf(appNumber.charAt(0).toString());
                int x3 = Integer.valueOf(appNumber.charAt(1).toString());
                int x2 = Integer.valueOf(appNumber.charAt(2).toString());
                int x1 = Integer.valueOf(appNumber.charAt(3).toString());
                int y = Integer.valueOf(appNumber.charAt(4).toString());
                int z7 = Integer.valueOf(appNumber.charAt(5).toString());
                int z6 = Integer.valueOf(appNumber.charAt(6).toString());
                int z5 = Integer.valueOf(appNumber.charAt(7).toString());
                int z4 = Integer.valueOf(appNumber.charAt(8).toString());
                int z3 = Integer.valueOf(appNumber.charAt(9).toString());
                int z2 = Integer.valueOf(appNumber.charAt(10).toString());
                int z1 = Integer.valueOf(appNumber.charAt(11).toString());
    
                int total = x4 * 2 + x3 * 3 + x2 * 4 +
                    x1 * 5 + y * 6 + z7 * 7 + z6 * 8 + z5 * 9 +
                    z4 * 2 + z3 * 3 + z2 * 4 + z1 * 5;
    
                mod = total % divisor;
                
            } else if (appNumber.length() == 8) {
    
                int x4 = Integer.valueOf(appNumber.charAt(0).toString());
                int x3 = Integer.valueOf(appNumber.charAt(1).toString());
                int x2 = Integer.valueOf(appNumber.charAt(2).toString());
                int x1 = Integer.valueOf(appNumber.charAt(3).toString());
                int y = Integer.valueOf(appNumber.charAt(4).toString());
                int z7 = Integer.valueOf(appNumber.charAt(5).toString());
                int z6 = Integer.valueOf(appNumber.charAt(6).toString());
                int z5 = Integer.valueOf(appNumber.charAt(7).toString());
    
                int total = x4 * 2 + x3 * 3 + x2 * 4 +
                    x1 * 5 + y * 6 + z7 * 7 + z6 * 8 + z5 * 9;
    
                mod = total % divisor;
    
            } else {
                //
                throw new Exception("appNumber length error")
            }
            
        } else {
            //
            throw new Exception("appNumber is empty or null")
        }
        
        if (mod == 10) {
            return 'X'
        } else {
            return mod.toString();
        }
        
    }  // end getCheckCode
    
}
