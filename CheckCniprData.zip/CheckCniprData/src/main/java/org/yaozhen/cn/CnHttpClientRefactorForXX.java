package org.yaozhen.cn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;



// httpclient 3.X
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;

// htmlparser
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.tags.InputTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CNHttpClientRefactor
 * 
 * @author tonykuo
 *
 */
public class CnHttpClientRefactorForXX {

    static Logger logger = LoggerFactory.getLogger(CnHttpClientRefactorForXX.class);
    // record console log
    static Logger logger_console = null;
    // 錯誤記戴的log
    static Logger logger_error = null;
    // 已取得資料時, 相關tag中查無資料時的log
    static Logger logger_noFiles = null;
    
    String PORT = null;
    String IP = null;
    HttpClient client = null;
    int statusCode;
    byte[] responseBody = null;

    String ROOT = null;
    String SaveDir = null;

    // private String StartYear = null; // 來源端 開始期號
    // private String EndYear = null; // 來源端 結束期號
    
    // TODO: useless ???
    // private int start, end;

    public String TYPE = null;
    public String httpcode = null;
    public String LIST = null;
    private String tempURL = null;

    BufferedWriter listout = null;

    /**
     * EX: 
     * 
     * 10.60.90.171 8080 14 \\10.153.24.83\books\FM 1986 1986 E:\newBOOKS\ C:\cnlist\fm_20140521.txt
     * 
     * SD:
     * 
     * title SD-0415-22-29
     * 
     * java -jar ./CNDownload_20150422.jar 
     * 10.60.90.171 
     * 8080 
     * 17 
     * \\10.153.24.83\\books\\FM 
     * 1986 
     * 1986 
     * E:\\newBOOKS\\ 
     * C:\\cnlist\\SD-0415-22-29.txt
     * 
     * pause
     * 
     * 共有8個輸入參數
     * 
     * @param ip
     * @param port
     * @param type 14:FM, 15:XX, 16:WG, 17:SD
     * @param root ???  
     * @param startyear
     * @param endyear
     * @param savedir 下戴縮存路徑 ???
     * @param list 下戴列表 ???
     */
    public CnHttpClientRefactorForXX(String ip, String port, String type, String root,
            String startyear, String endyear, String savedir, String list) {
        this.IP = ip;
        this.PORT = port;
        this.TYPE = type;
        this.ROOT = root;
        this.SaveDir = savedir;
        // this.StartYear = startyear;
        // this.EndYear = endyear;
        this.LIST = list;
    }

    /**
     * Main
     */
    public static void main(String[] args) {
        
        //////////////////////////////////////////////////////////////////////////////////////////可調整變數
        // TODO: logback config 待調整
        logger_console = LoggerFactory.getLogger("ConsoleLogForXX");
        logger_error = LoggerFactory.getLogger("RunErrorForXX");
        logger_noFiles = LoggerFactory.getLogger("NoFilesForXX");
        // T:\cnlist\rawdata\
        String savedir = "T:\\cnlist\\rawdata\\";       // why call newBOOKS ???
        // T:\cnlist\20150513\sipo-FM-2015.05.13.txt
        // String list = "T:\\cnlist\\appNumber\\20150701\\sipo-XX-2015.07.01.txt";
        // String list = "find_log/sipo-find-XX-nofile-0624-log.txt";
        String list = "log_lv2_gap/find-LV2-gap-XX-20150624-log.txt";
        //////////////////////////////////////////////////////////////////////////////////////////
        
        logger.info("start....");
        logger_console.info("start....");
        
        /*
         * java -jar ./CNDownload_20150422.jar 
         * 10.60.90.171 
         * 8080 
         * 17 
         * \\10.153.24.83\\books\\FM 
         * 1986 
         * 1986 
         * E:\\newBOOKS\\ 
         * C:\\cnlist\\SD-0415-22-29.txt
         */
        //@param type 14:FM, 15:XX, 16:WG, 17:SD
        // 10.60.90.171
        String ip = "10.60.91.78";
        String port = "8080";
        String type = "15";
        // String root = "\\10.153.24.83\\books\\FM " ;  // useless
        // String startyear = "1986";                    // useless
        // String endyear = "1986";                      // useless
        
        CnHttpClientRefactorForXX cnHttpClient = new CnHttpClientRefactorForXX(ip, port,
                type, "", "", "", savedir, list);
        
        cnHttpClient.manage();
        
        logger.info("finished");
        logger_console.info("finished");
        
    }

    /**
     * 控管列表
     */
    public void manage() {

        String patentinlist = null;

        try {
            File newfile = new File(LIST);
            BufferedReader in;

            in = new BufferedReader(new InputStreamReader(new FileInputStream(
                    newfile)));

            while ((patentinlist = in.readLine()) != null) {

                // for log
                if (patentinlist.indexOf("] - ") != -1) {
                    patentinlist = patentinlist.substring(
                            patentinlist.indexOf("] -") + 3).trim();
                }
                    
                // for log
                if (patentinlist.indexOf("]") != -1) {
                    patentinlist = patentinlist.substring(
                            patentinlist.lastIndexOf("]") + 1).trim();
                }
                
                // path = T:\cnlist\rawdata\FM\20150708\201180075697.3\description.xml
                // patentinlist = FM\20150708\201180075697.3
                patentinlist = patentinlist.substring(0, 2) + "\\2015" + patentinlist.substring(2);

                process(patentinlist.substring(
                        patentinlist.lastIndexOf("\\") + 1).trim(),
                        patentinlist);
            }

            in.close();

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 爬一筆專利資訊
     * 
     * @param AN 專利申請號 ???
     * @param SourcePath 專利路徑 ???
     */
    public void process(String AN, String SourcePath) {
        
        logger.info("專利申請號: " + AN + "\t專利路徑: " + SourcePath + "\t");
        logger_console.info("專利申請號: " + AN + "\t專利路徑: " + SourcePath + "\t");

        File newfile = null;
        // 建立HttpClient實體.
        client = new HttpClient();

        client.getHostConfiguration().setHost(IP, Integer.parseInt(PORT));
        
        GetMethod get = null;
        PostMethod post = null;
        String webResult = null;
        
        try {

            // login action
            post = new PostMethod(
                    "/cniprFSK/login.do?method=login&userName=guest&password=123456");
            // 返回狀態值.
            statusCode = client.executeMethod(post);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(post);

            // query form action => 搜尋from
            post = new PostMethod(
                    "/cniprFSK/search.do?method=overviewSearch&area=cn");
            
            // set post data
            NameValuePair[] data = {
                    new NameValuePair("strWhere", "an=('CN" + AN + "%')"),
                    new NameValuePair("iHitPointType", "115"),
                    new NameValuePair("strdb", TYPE),
                    new NameValuePair("txtA", "'" + AN + "'"),
                    new NameValuePair("iOption", "2") };

            post.setRequestBody(data);

            statusCode = client.executeMethod(post);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊(stream方法)
            webResult = getResults(post);

            // 取得strSources
            String sources = getSources(webResult);
            logger.info(sources);
            logger_console.info(sources);

            // System.out.println("##################### 02.查詢結果 #####################");
            
            // TODO: ???
            post = new PostMethod(
                    "/cniprFSK/jsp/zljs/recordFrame.jsp?area=cn&strWhere=N");

            post.setRequestBody(data);

            statusCode = client.executeMethod(post);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(post);

            // 取得被網頁驗證過後的申請號
            String sysAN = getAppNumberFromWeb(webResult);

            if (sysAN == null) {
                // log - SourcePath
                logger_error.error("[找不到該筆專利] - [" + AN + "]" + SourcePath);
                logger.error("[找不到該筆專利] - [" + AN + "]" + SourcePath);
                logger_console.error("[找不到該筆專利] - [" + AN + "]" + SourcePath);
                // 跳離這一次
                return;
            }
            
            post = new PostMethod("/cniprFSK/search.do?method=detailSearch");
            NameValuePair[] data2 = { new NameValuePair("area", "cn"),
                    new NameValuePair("iHitPointType", "115"),
                    new NameValuePair("iOption", "2"),
                    new NameValuePair("index", "0"),
                    new NameValuePair("strChannels", TYPE),
                    new NameValuePair("strSources", sources),
                    new NameValuePair("strWhere", "an=('" + sysAN + "%')") };

            post.setRequestBody(data2);
            statusCode = client.executeMethod(post);
            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }
            // 取得回傳資訊.
            webResult = getResults(post);
            // added by yh for error html
            if (webResult.contains("error.jpg")
                    || webResult.contains("对不起,没有找到相应的检索结果")) {
                logger_error.error("[html fail!找不到該筆專利] - [" + AN + "]"
                        + SourcePath);
                // list_sd.add("[找不到該筆專利] - [" + AN + "]" + SourcePath);
                return;
            }

            // 取得網頁資訊
            // newfile = new File(SaveDir +
            // SourcePath.substring(SourcePath.indexOf("books")) +
            // "\\bibliography.html");
            logger.info(SaveDir + SourcePath);
            logger_console.info(SaveDir + SourcePath);
            newfile = new File(SaveDir + SourcePath + "\\bibliography.html");
            newfile.getParentFile().mkdirs();
            writeFile(webResult, newfile.getAbsolutePath());

            // 外觀設計到此為止
            if (TYPE.equals("16")) {
                return;
            }

            String[] Parameters = getParameterFromViewXML(webResult);
            String CLM_Page = Parameters[0];
            String DES_Page = Parameters[1];
            String DRA_Page = Parameters[2];
            String strPage = Parameters[3];
            String strUrl = Parameters[4];
            String strTI = Parameters[5];
            String pd = Parameters[6];
            String channel = Parameters[7];
            String an = Parameters[8];

            // ** 驗證轉頁後是否正確 **
            if (!sysAN.toLowerCase().equals(an.toLowerCase())) {
                //
                logger_error.error("[轉頁後編碼AN不一致] - [" + AN + "]" + SourcePath);
                return;
            }

            String writedata = null;
            String[] _data = null;

            // 取得申請號日、公開公告(授權)號日
            _data = getNumberInfo(webResult, TYPE);
            writedata = "anum\t" + _data[0] + "\r\nadate\t" + _data[1]
                    + "\r\npnum\t" + _data[2] + "\r\npdate\t" + _data[3];

            // 取得mainipc, ipc
            _data = getIPCInfo(webResult);
            writedata = writedata + "\r\nmipc\t" + _data[0] + "\r\nfcc\t"
                    + _data[1] + "\r\nipcs\t" + _data[2];
            // newfile = new File(SaveDir +
            // SourcePath.substring(SourcePath.indexOf("books")) + "\\ipc.txt");
            newfile = new File(SaveDir + SourcePath + "\\_data.txt");
            newfile.getParentFile().mkdirs();
            writeFile(writedata, newfile.getAbsolutePath());

            // System.out.println("##################### 04.選擇代碼化 #####################");

            post = new PostMethod("/cniprFSK/view.do?method=showXML");

            NameValuePair[] data3 = { new NameValuePair("channel", channel),
                    new NameValuePair("an", sysAN),
                    new NameValuePair("CLM_Page", CLM_Page),
                    new NameValuePair("DES_Page", DES_Page),
                    new NameValuePair("DRA_Page", DRA_Page),
                    new NameValuePair("pd", pd),
                    new NameValuePair("strPage", strPage),
                    new NameValuePair("strTI", strTI),
                    new NameValuePair("strUrl", strUrl) };

            // new NameValuePair("channel", "fmzl_ab,fmzl_ft")

            post.setRequestBody(data3);

            statusCode = client.executeMethod(post);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(post);

            String tempPar = "/cniprFSK/" + getXMLBrowserURL(webResult);

            // System.out.println("##################### 05.進入代碼化 #####################");

            get = new GetMethod(tempPar);
            statusCode = client.executeMethod(get);
            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(get);

            String pageNum = null;
            // System.out.println("##################### 06.進入觸發xml #####################");
            tempURL = intoXML(webResult);
            
            newfile = new File(SaveDir + SourcePath + "\\pagenum.txt");
            newfile.getParentFile().mkdirs();
            pageNum = "clmp\t" + CLM_Page + "\r\ndesp\t" + DES_Page
                    + "\r\ndrap\t" + DRA_Page;
            // 將頁碼寫入
            // writeFile(pageNum, newfile.getAbsolutePath()); // 2013.5.31

            get = new GetMethod(intoXML(webResult));

            statusCode = client.executeMethod(get);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(get);

            tempURL = createXML(webResult);
            String postURL = null;
            postURL = tempURL.substring(tempURL.indexOf("pagenum="));
            tempURL = tempURL.substring(0, tempURL.indexOf("pagenum=") + 8)
                    + CLM_Page + postURL.substring(postURL.indexOf("&"));
            // System.out.println("##################### 07.創造claim xml #####################");
            get = new GetMethod(tempURL);

            statusCode = client.executeMethod(get);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(get);
            if (webResult.isEmpty()) {
                logger.info("[沒有claim] - [" + AN + "]" + SourcePath);
                logger_console.info("[沒有claim] - [" + AN + "]" + SourcePath);
                logger_noFiles.warn("[沒有claim] - [" + AN + "]" + SourcePath);
            }

            // newfile = new File(SaveDir +
            // SourcePath.substring(SourcePath.indexOf("books")) +
            // "\\claim.xml");
            newfile = new File(SaveDir + SourcePath + "\\claim.xml");
            newfile.getParentFile().mkdirs();
            writeFile(webResult, newfile.getAbsolutePath());

            tempURL = tempURL.replace("ft_type=1", "ft_type=2");

            postURL = null;
            postURL = tempURL.substring(tempURL.indexOf("pagenum="));
            tempURL = tempURL.substring(0, tempURL.indexOf("pagenum=") + 8)
                    + DES_Page + postURL.substring(postURL.indexOf("&"));
            // System.out.println("##################### 08.創造des xml #####################");

            get = new GetMethod(tempURL);

            statusCode = client.executeMethod(get);

            if (statusCode != HttpStatus.SC_OK) {
                logger.error("Method failed: " + post.getStatusLine());
                logger_console.error("Method failed: " + post.getStatusLine());
            }

            // 取得回傳資訊.
            webResult = getResults(get);
            if (webResult.isEmpty()) {
                logger.info("[沒有description] - [" + AN + "]"
                        + SourcePath);
                logger_console.info("[沒有description] - [" + AN + "]"
                        + SourcePath);
                logger_noFiles.warn("[沒有description] - [" + AN + "]"
                        + SourcePath);
            }

            newfile = new File(SaveDir + SourcePath + "\\description.xml");
            newfile.getParentFile().mkdirs();
            writeFile(webResult, newfile.getAbsolutePath());

        } catch (Exception e) {
            
            logger.error("error = " + e);
            logger_console.error("error = " + e);
            logger_error.error("[Exception: " + e.getMessage() + "] - "
                    + SourcePath);
            
        } finally {
            
            // ** 無論如何都必須釋放連接.
            post.releaseConnection();
            if (get != null) {
                get.releaseConnection();
            }
                
            client.getHttpConnectionManager().closeIdleConnections(0);
            
        }
    }

    /**
     * 取得號碼相關資訊
     */
    private String[] getNumberInfo(String Webpage, String type) {
        String _numinfo[] = new String[4];

        int start = Webpage.indexOf("申请（专利）号:");
        String temp = Webpage.substring(start);
        temp = temp.substring(0, temp.indexOf("主分类号:"));
        temp = temp.replace("&nbsp;", "");

        /* 開始取得參數 */
        // 申請號
        temp = temp.substring(temp.indexOf("<span"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _numinfo[0] = temp.substring(0, temp.indexOf("</span>")).trim();

        // 申請日
        temp = temp.substring(temp.indexOf("申请日:"));
        temp = temp.substring(temp.indexOf("<span"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _numinfo[1] = temp.substring(0, temp.indexOf("</span>")).trim();

        //
        String grant = null;
        if (type.equals("17")) {
            grant = "授权（公告）号:";
        } else {
            grant = "公开（公告）号:";
        }
        temp = temp.substring(temp.indexOf(grant));
        temp = temp.substring(temp.indexOf("<td"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _numinfo[2] = temp.substring(0, temp.indexOf("</td>")).trim();

        //
        if (type.equals("17")) {
            grant = "授权（公告）日:";
        } else {
            grant = "公开（公告）日:";
        }
        temp = temp.substring(temp.indexOf(grant));
        temp = temp.substring(temp.indexOf("<td"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _numinfo[3] = temp.substring(0, temp.indexOf("</td>")).trim();

        return _numinfo;
    }

    /**
     * 取得IPC相關資訊
     */
    private String[] getIPCInfo(String Webpage) {

        String _ipcinfo[] = new String[3];

        int start = Webpage.indexOf("主分类号:");
        String temp = Webpage.substring(start);
        temp = temp.substring(0, temp.indexOf("优先权:"));
        temp = temp.replace("&nbsp;", "");

        /* 開始取得參數 */
        // main ipc
        temp = temp.substring(temp.indexOf("<td"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _ipcinfo[0] = temp.substring(0, temp.indexOf("</td>")).trim();

        // 範疇分類
        temp = temp.substring(temp.indexOf("范畴分类:"));
        temp = temp.substring(temp.indexOf("<td"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _ipcinfo[1] = temp.substring(0, temp.indexOf("</td>")).trim();

        // ipc
        temp = temp.substring(temp.indexOf("分类号:"));
        temp = temp.substring(temp.indexOf("<td"));
        temp = temp.substring(temp.indexOf(">") + 1);
        _ipcinfo[2] = temp.substring(0, temp.indexOf("</td>")).trim();

        return _ipcinfo;

    }

    /**
     * 取得strSources
     */
    private String getSources(String Webpage) {

        String source = null;

        int start = Webpage.indexOf("<form name=\"searchForm\"");

        String temp = Webpage.substring(start);

        temp = temp.substring(0, temp.indexOf("</form>"));

        /* 開始取得參數 */
        Parser parser = new Parser();
        try {

            parser.setInputHTML(temp);

            NodeFilter filter = new NodeClassFilter(InputTag.class);

            NodeList list = parser.extractAllNodesThatMatch(filter);

            for (int i = 0; i < list.size(); i++) {
                
                InputTag inputTag = (InputTag) list.elementAt(i);

                if (inputTag.getAttribute("name").equals("strSources")) {
                    source = inputTag.getAttribute("value").trim();
                }

            }

        } catch (ParserException e) {
            e.printStackTrace();
        }

        return source;

    }

    /**
     * 寫入檔案至指定目錄
     */
    private void writeFile(String FileContent, String Path) {
        // String str = null;
        try {
            
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(Path), "utf-8"));
            out.write(FileContent);
            out.newLine();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 取得POST回傳結果
     * 
     * @throws IOException
     *             取得回傳結果的例外
     */
    private String getResults(PostMethod POST) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(
                POST.getResponseBodyAsStream(), "UTF-8"));

        StringBuffer resBuffer = new StringBuffer();
        String resTemp = "";
        while ((resTemp = br.readLine()) != null) {
            resBuffer.append(resTemp + "\n");
        }

        return resBuffer.toString();
    }

    /**
     * 取得GET回傳結果
     * 
     * @throws IOException
     *             取得回傳結果的例外
     */
    private String getResults(GetMethod GET) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(
                GET.getResponseBodyAsStream(), "UTF-8"));

        StringBuffer resBuffer = new StringBuffer();
        String resTemp = "";
        while ((resTemp = br.readLine()) != null) {
            resBuffer.append(resTemp + "\n");
        }

        return resBuffer.toString();
    }

    /**
     * TODO: 擷取計算過後的驗證碼 => ???
     */
    private String getAppNumberFromWeb(String Webpage) {

        int start = Webpage.indexOf("navy;\">");

        if (start != -1) {
            start = start + 7;
            String temp = Webpage.substring(start);
            temp = temp.substring(0, temp.indexOf("</a>"));

            return temp.trim();
        } else {
            return null;
        }
        
    }

    /**
     * 取得 ViewXML form 內的所有參數
     */
    private String[] getParameterFromViewXML(String Webpage) {

        /* 先取得 ViewXML form */
        String[] Parameters = new String[9];

        int start = Webpage.indexOf("<form name=\"ViewXML\"");

        String temp = Webpage.substring(start);

        temp = temp.substring(0, temp.indexOf("</form>"));

        /* 開始取得參數 */
        Parser parser = new Parser();
        try {

            parser.setInputHTML(temp);

            NodeFilter filter = new NodeClassFilter(InputTag.class);

            NodeList list = parser.extractAllNodesThatMatch(filter);

            for (int i = 0; i < list.size(); i++) {
                InputTag inputTag = (InputTag) list.elementAt(i);

                if (inputTag.getAttribute("name").equals("CLM_Page")) {
                    Parameters[0] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("DES_Page")) {
                    Parameters[1] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("DRA_Page")) {
                    Parameters[2] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("strPage")) {
                    Parameters[3] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("strUrl")) {
                    Parameters[4] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("strTI")) {
                    Parameters[5] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("pd")) {
                    Parameters[6] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("channel")) {
                    Parameters[7] = inputTag.getAttribute("value");
                }
                    
                if (inputTag.getAttribute("name").equals("an")) {
                    Parameters[8] = inputTag.getAttribute("value");
                }
                    
            }
            
        } catch (ParserException e) {
            e.printStackTrace();
        }

        return Parameters;
    }

    /**
     * 取得觸發 Get URL
     */
    private String getXMLBrowserURL(String Webpage) {
        //
        Webpage = Webpage.substring(Webpage
                .indexOf("jsp/viewPlugin/xml/XML_Browser_Main.jsp"));
        Webpage = Webpage.substring(0, Webpage.indexOf("\""));

        return Webpage.trim();
    }

    /**
     * 取得觸發 Get URL
     */
    private String intoXML(String Webpage) {

        Webpage = Webpage.substring(Webpage.indexOf("/cniprFSK/xml.do"));
        Webpage = Webpage.substring(0, Webpage.indexOf("\""));

        return Webpage.trim();
    }

    private String createXML(String Webpage) {
        // 
        Webpage = Webpage.substring(Webpage
                .indexOf("/cniprFSK/xml.do?method=renderXML"));
        Webpage = Webpage.substring(0, Webpage.indexOf("\""));

        return Webpage.trim();
    }

}
