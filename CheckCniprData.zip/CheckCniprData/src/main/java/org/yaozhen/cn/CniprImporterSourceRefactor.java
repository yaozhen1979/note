package org.yaozhen.cn;

import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentRaw;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawCNIPR;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.kdlib.ProcessEstimaterRefactor;

import com.mongodb.BasicDBObject;

/**
 * CNHttpClientRefactor: CN 導入到 Level 1 的程式
 * 
 * TODO: WG 類型的doDate，這個doDate是經過轉換后的，可能在年初第一周或者年末最後一周有問題，重點觀察 ???
 * 
 * ex:
 * 
 * java -jar "/home/yyj/cn_script/cntestauth/cnimporter.jar"
 * 
 * -mongodb.host 10.60.90.127 -mongodb.name PatentRawCNIPR -mongodb.ac eXlq
 * -mongodb.pd eXlq --cnipr.path "/mnt/patentsource/CN/data/BOOKS" --provider
 * "CNIPR1" --do.path "/mnt/patentsource/CN/data/BOOKS/WG/$1/$2" >> cnipr.log
 * 
 * @author tonykuo
 * 
 */
public class CniprImporterSourceRefactor {

    static Logger log = LoggerFactory
            .getLogger(CniprImporterSourceRefactor.class);

    private static Class<? extends PatentRaw> rawclazz = PatentRawCNIPR.class;

    private static Pto pto = Pto.CNIPR;

    // 為根目錄
    public static final String OPT_CNIPR_PATH = "cnipr.path";
    public static final String OPT_CNIPR_PATH_DEFAULT = "";

    // 要導入 LEVEL 1 數據的目錄
    public static final String OPT_DO_PATH = "do.path";
    public static final String OPT_DO_PATH_DEFALUT = "";

    // 參數WG類型的用 CNIPR1, FM or SD or XX 類型用 CNIPR2 ??? why defualt is "CNIPR" ???
    public static final String OPT_PROVIDER = "provider";
    public static final String OPT_PROVIDER_DEFAULT = "CNIPR";

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, OPT_CNIPR_PATH, true,
                    OPT_CNIPR_PATH_DEFAULT,
                    "CNIPR raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, OPT_DO_PATH, true, OPT_DO_PATH_DEFALUT,
                    "do CNIPR raw data local path, keep empty for cnipr.path"),
            new ArgParser.Option(null, OPT_PROVIDER, true,
                    OPT_PROVIDER_DEFAULT, "Provider saved to DB"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class };

    static {
        ConfigUtils.setSearchBase(CniprImporterSourceRefactor.class);
    }

    public CniprImporterSourceRefactor() {
    }

    private File bookpath;

    private ProcessEstimaterRefactor pe;

    private static String provider;

    /**
     * entry point
     * 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        //
        CniprImporterSourceRefactor cnipr = new CniprImporterSourceRefactor();

        cnipr.worker(args);
    }

    /**
     * 
     * @param args
     * @throws Exception
     */
    public void worker(String[] args) throws Exception {
        
        /*
         * DEV 10.60.90.155/mongodb.name=PatentRawCNIPR/ac=patentdata/pd=data.cloud.Abc12345
         */
        /*
         * LV1 10.60.90.127/ac=yyj/pd=yyj
         */
        args = new String[] { "-mongodb.host", "10.60.90.127", "-mongodb.name",
                "PatentRawCNIPR", "-mongodb.ac", "yyj",
                "-mongodb.pd", "yyj" };

        ArgParser argParser = new ArgParser().addOpt(
                CniprImporterSourceRefactor.class).parse(args);

        // init mongodb setup => ref. MongoAuthInitUtils.java
        MongoAuthInitUtils.reload(argParser);

        // 為根目錄 => local T:\cnlist\rawdata\FM\20150513
        // String argPath = argParser.getOptString(OPT_CNIPR_PATH);
        // TODO: 依類別再調整
        String argPath = "T:/cnlist/rawdata";

        // 要導入 LEVEL 1 數據的目錄 => "T:/cnlist/rawdata/FM/2015/20150715"
        // String argDoPath = argParser.getOptString(OPT_DO_PATH);
        // TODO: 依類別再調整 FM, SD, XX and WG
        // String argDoPath = "T:/cnlist/rawdata/WG/2015/3130";
        String argDoPath = "T:/cnlist/rawdata/XX/2015/20150729";

        // provider = argParser.getOptString(OPT_PROVIDER);
        // TODO: 依類別再調整
        if (argDoPath.contains("/WG/")) {
            provider = "CNIPR1";
        } else {
            provider = "CNIPR2";
        }

        if (log.isDebugEnabled()) {
            log.debug("start, opt: " + argParser.getParsedMap());
        }

        if (argDoPath.isEmpty()) {
            new CniprImporterSourceRefactor(argPath).importDir();
        } else {
            new CniprImporterSourceRefactor(argPath).importDir(new File(
                    argDoPath));
        }

        log.debug("finish");
    }

    /**
     * 
     * @param bookpath
     * @throws UnknownHostException
     */
    public CniprImporterSourceRefactor(String bookpath)
            throws UnknownHostException {
        //
        this.bookpath = new File(bookpath);
        pe = new ProcessEstimaterRefactor(0).setFormat("%2$d");
    }

    /**
     * TOOD: 直接處理根目錄 ???
     * 
     * @return
     * @throws IOException
     */
    public CniprImporterSourceRefactor importDir() throws IOException {
        return importDir(bookpath);
    }

    /**
     * 處理指定目錄 ???
     * 
     * ref: Another builder pattern for
     * Java[http://blog.crisp.se/2013/10/09
     * /perlundholm/another-builder-pattern-for-java]
     * 
     * @param dir
     * @return
     * @throws IOException
     */
    public CniprImporterSourceRefactor importDir(File dir) throws IOException {

        if (dir.isDirectory()) {
            //
            File fileBiblio = dir.toPath().resolve("bibliography.html")
                    .toFile();

            if (fileBiblio.isFile()) {

                File fileClaim = dir.toPath().resolve("claim.xml").toFile();
                File fileDesc = dir.toPath().resolve("description.xml")
                        .toFile();
                
                // TODO: 要在調整path. 20150710 
                String path = bookpath.toPath().relativize(dir.toPath())
                        .toString().replaceAll("\\\\", "/");

                // TODO: WG 類型的doDate，這個doDate是經過轉換后的，可能在年初第一周或者年末最後一周有問題，重點觀察
                // ??? => WG hardcode ...
                Date doDate = DateUtils.parseDate(dir.getParentFile().getName());
                
                // only for WG type => Date doDate = DateUtils.parseDate("20150603");
                // Date doDate = DateUtils.parseDate("20150729");
                
                if (doDate == null) {
                    // process special case
                    while (true) {
                        //
                        Matcher mat;
                        mat = Pattern.compile("(?i)^SD/1992/19921230Z/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtils.parseDate("19921230");
                            break;
                        }

                        mat = Pattern.compile("(?i)^WG/(\\d{4})/\\d{4}/")
                                .matcher(path);

                        if (mat.find()) {
                            doDate = DateUtils.parseDate(mat.group(1) + "0101");
                            break;
                        }

                        break;
                    }
                }

                PatentRawCNIPR.remove(
                        rawclazz,
                        new QueryHelp("path", path).filter("pto",
                                pto.toString()));

                PatentRawCNIPR raw = new PatentRawCNIPR();
                raw.pto = pto;
                raw.path = path;
                raw.data = new BasicDBObject();
                raw.type = "html/json-html";
                raw.provider = provider;
                raw.doDate = doDate;

                // insert data to mongodb
                raw.data.put("bibliography",
                        FileUtils.readFileToString(fileBiblio, "UTF-8"));

                // insert data to mongodb
                if (fileClaim.isFile()) {
                    raw.data.put("claim",
                            FileUtils.readFileToString(fileClaim, "UTF-8"));
                }

                // insert data to mongodb
                if (fileDesc.isFile()) {
                    raw.data.put("description",
                            FileUtils.readFileToString(fileDesc, "UTF-8"));
                }
                
                // show raw.data ???

                raw.save();
                
                // log.debug("doDate = " + doDate);
                pe.addNum().debug(log, 10000, "save: '" + path + "'");

            } else {

                for (File file : dir.listFiles()) {
                    if (file.isDirectory()) {
                        importDir(file);
                    }
                }

            }
        }

        return this;
    }

}
