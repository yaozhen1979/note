package org.yaozhen.cn;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.kdlib.ProcessEstimaterRefactor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tsaikd.java.mongodb.MappedClass;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/**
 * CniprImageImpoterRefactor
 * 
 * 浩子說明:
 * 上傳影像檔：10.60.90.152下面的
 * /home/yyj/cp_cn_auto_update/cniprImageImporter.sh 的腳本
 * 執行腳本，例如：sudo sh cniprImageImporter.sh 3101 20150325
 * 
 * @author tonykuo
 * 
 */
public class CniprImageImpoterRefactor {

    static Logger log = LoggerFactory
            .getLogger(CniprImageImpoterRefactor.class);

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator
            + "MM" + File.separator + "dd");
    
    static Pattern pattern = Pattern.compile("[1-9][\\d]*");
    private String listPath;
    private String sourcePath;
    private String targetPath;
    private ProcessEstimaterRefactor pe;
    private PatentInfo2 patentinfo;
    
    /**
     * 
     * @param sourcepath
     * @param listRootPath
     * @return
     * @throws IOException
     */
    public static String createrList(String sourcepath, String listRootPath)
            throws IOException {
        
        if (sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        }
        
        String listPath = listRootPath + File.separator + "list" + sourcepath
                + ".txt";
        
        if (!(new File(listPath)).exists()) {
            
            File file = new File(listPath.substring(0,
                    listPath.lastIndexOf(File.separator)));
            
            log.info("file.getAbsoluteFile = " + file.getAbsoluteFile());
            
            if (!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            File source = new File(sourcepath);
            if (!source.isDirectory()) {
                return "";
            }
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            for (File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        
        return listPath;
    }
    
    /**
     * 
     * @param src
     * @param des
     */
    private static void copyFile(File src, File des) {
        
        try {
            File pd = des.getParentFile();
            if (!pd.exists()) {
                pd.mkdirs();
            }
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(des);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    /**
     * 
     * @param mongouriStr
     * @param sourcePath
     * @param targetPath
     * @param listPath
     */
    public CniprImageImpoterRefactor(String mongouriStr, String sourcePath,
            String targetPath, String listPath) {
        
        try {
            
            Class<? extends PatentInfo2> infoclazz = PatentInfoCNIPR.class;
            MongoClientURI mongouri = new MongoClientURI(mongouriStr);
            MongoClient mongo;
            mongo = new MongoClient(mongouri);
            DB mongodb = mongo.getDB(mongouri.getDatabase());
            MappedClass.getMappedClass(infoclazz).setDB(mongodb);
            
            this.sourcePath = sourcePath;
            this.targetPath = targetPath;
            this.listPath = listPath;
            
            if (this.sourcePath.endsWith(File.separator)) {
                this.sourcePath = this.sourcePath.substring(0,
                        this.sourcePath.length() - 1);
            }
            
            pe = new ProcessEstimaterRefactor(0).setFormat("%2$d");

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        
    }
    
    /**
     * 
     * @param k2imagePath
     * @param patentPath
     * @throws Exception
     */
    private void uploadImage(String k2imagePath, String patentPath)
            throws Exception {
        
        File patentSrcFile = new File(patentPath);
        File patentDesFile = new File(k2imagePath);
        
        if (!patentDesFile.exists() || !patentDesFile.isDirectory()) {
            patentDesFile.mkdirs();
        }
        
        File[] imageFiles = patentSrcFile.listFiles();
        
        int imageCount = 0;
        
        for (File imageFile : imageFiles) {
            String[] tmp = imageFile.getName()
                    .replace(patentSrcFile.getName() + "_", "").split("\\.");
            String page = tmp[0];
            String type = tmp[1];
            if (type.equalsIgnoreCase("jpg") || type.equalsIgnoreCase("tif")) {
                Matcher matcher = pattern.matcher(page);
                if (matcher.find()) {
                    page = matcher.group(0);
                    String destFilePath = k2imagePath + File.separator + page
                            + "." + type.toLowerCase();
                    copyFile(new File(imageFile.getAbsolutePath()), new File(
                            destFilePath));
                    imageCount++;
                }
            }
        }
        
        if (this.patentinfo.filePageNumber == null
                || this.patentinfo.filePageNumber != imageCount) {
            // filePageNumber ???
            this.patentinfo.filePageNumber = imageCount;
            this.patentinfo.save();
        }
        
    }
    
    /**
     * 
     * @param startPath
     * @throws Exception
     */
    public void importImage(String startPath) throws Exception {
        
        String listPath = createrList(this.sourcePath, this.listPath);
        
        if (!listPath.isEmpty()) {
            
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            String patentPath = "";
            
            if (startPath != null && !startPath.isEmpty()) {
                while ((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if (patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                log.info("start upload from patent path : " + patentPath);
            }
            
            while ((patentPath = listBufferedReader.readLine()) != null) {
                
                patentPath = patentPath.trim();
                
                String patentNumber = patentPath.substring(patentPath
                        .lastIndexOf(File.separator) + 1);
                
                int stat = 2;
                
                if (patentPath.contains("FM")) {
                    //
                    stat = 1;
                } else if (patentPath.contains("WG")) {
                    //
                    String newPatentNumber = patentNumber.substring(0,
                            patentNumber.length() - 1);
                    newPatentNumber = patentNumber.substring(0,
                            patentNumber.length() - 1).toUpperCase()
                            + "."
                            + patentNumber.substring(patentNumber.length() - 1)
                                    .toUpperCase();
                    patentNumber = newPatentNumber;
                }
                
                this.patentinfo = PatentInfoCNIPR.findPN(Pto.CNIPR,
                        patentNumber, stat);
                
                if (this.patentinfo != null) {
                    
                    String k2imagePath = this.targetPath + File.separator
                            + "cn" + stat
                            + this.patentinfo.kindcode.toLowerCase()
                            + File.separator
                            + dateFormat.format(patentinfo.doDate)
                            + File.separator + patentNumber.toLowerCase()
                            + File.separator + "fullImage";
                    
                    pe.addNum().debug(log, 10000,
                            "source:" + patentPath + ", dest:" + k2imagePath);
                    
                    log.info("k2imagePath = " + k2imagePath);
                    log.info("patentPath = " + patentPath);
                    
                    this.uploadImage(k2imagePath, patentPath);
                } else {
                    log.info("patentnumber:'" + patentNumber + "'[" + stat
                            + "]" + " not find!");
                }
                
            }
            
            listFileReader.close();
            listBufferedReader.close();
            
        }
    }
    
    /**
     * entry point
     * 
     * @param args
     */
    public static void main(String[] args) {
        
        Options options = new Options();
        
        options.addOption("m", "Mongo uri string", true, "");
        options.addOption("s", "Source path", true, "");
        options.addOption("t", "Target path", true, "");
        options.addOption("p", "start Path", true, "");
        options.addOption("l", "List path", true, "");
        
        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new PosixParser();
        
        CommandLine cmd = null;
        
        // mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]
        // 10.60.90.101:27017/admin -u patentdata -p data.cloud.Abc12345
        String mongouri = "mongodb://patentdata:data.cloud.Abc12345@10.60.90.121:27017/admin";
        // 
        String sourcePath;
        //
        String targetPath;
        //
        String startPath;
        //
        String listPath;
        
        try {
            
            cmd = parser.parse(options, args);
            mongouri = cmd.getOptionValue("m");
            sourcePath = cmd.getOptionValue("s");
            targetPath = cmd.getOptionValue("t");
            startPath = cmd.getOptionValue("p");
            listPath = cmd.getOptionValue("l");
            
            if (mongouri == null || mongouri.isEmpty() || sourcePath == null
                    || sourcePath.isEmpty() || targetPath == null
                    || targetPath.isEmpty() || listPath == null
                    || listPath.isEmpty()) {
                //
                throw new ParseException("");
            }
            
        } catch (ParseException e) {
            formatter.printHelp("CniprImageImpoter.jar", options);
            return;
        }
        
//        mongouri = "";
//        sourcePath = "";
//        targetPath = "";
//        listPath = "";
//        startPath = "";
        
        log.info("mongouri = " + mongouri);
        log.info("sourcePath = " + sourcePath);
        log.info("targetPath = " + targetPath);
        log.info("listPath = " + listPath);
        log.info("startPath = " + startPath);
        
        CniprImageImpoterRefactor imageImpoter = new CniprImageImpoterRefactor(
                mongouri, sourcePath, targetPath, listPath);
        
        try {
            //
            imageImpoter.importImage(startPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

}
