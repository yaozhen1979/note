package org.yaozhen.cn;

import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentinfo2.PatentInfoCNIPR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ArgParser;
import org.tsaikd.java.utils.ConfigUtils;
import org.tsaikd.java.utils.ProcessEstimater;

/**
 * CniprAutoImageImpoterRefactor
 * 
 * 浩子說明: 上傳影像檔：10.60.90.152下面的 /home/yyj/cp_cn_auto_update/cniprImageImporter.sh
 * 的腳本 執行腳本，例如：sudo sh cniprImageImporter.sh 3114 20150408
 * 
 * ac patentdata
 * pd data.cloud.Abc12345
 * 
 * @author tonykuo
 * 
 */
public class CniprAutoImageImpoterRefactor {

    static Log log = LogFactory.getLog(CniprAutoImageImpoterRefactor.class);

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy" + File.separator
            + "MM" + File.separator + "dd");

    static Pattern pattern = Pattern.compile("[1-9][\\d]*");
    private static String listPath;
    private static String sourcePath;
    private static String targetPath;
    private ProcessEstimater pe;
    private PatentInfo2 patentinfo;
    private static String startPath;
    public static final String opt_source_path = "source.path";
    public static final String opt_source_path_default = "";

    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "";

    public static final String opt_start_path = "start.path";
    public static final String opt_start_path_default = "";

    public static final String opt_list_path = "list.path";
    public static final String opt_list_path_default = "";

    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_source_path, true,
                    opt_source_path_default,
                    "CNIPR raw data local path, like /mnt/kangaroo"),
            new ArgParser.Option(null, opt_target_path, true,
                    opt_target_path_default,
                    "do CNIPR raw data local path, keep empty for cnipr.path"),
            new ArgParser.Option(null, opt_start_path, true,
                    opt_start_path_default, "Provider saved to DB"),
            new ArgParser.Option(null, opt_list_path, true,
                    opt_list_path_default, "Provider saved to DB"), };

    public static final Class<?>[] optDep = { MongoAuthInitUtils.class };

    static {
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(CniprAutoImageImpoterRefactor.class);
    }

    public CniprAutoImageImpoterRefactor() throws UnknownHostException {
        pe = new ProcessEstimater(0).setFormat("%2$d");

    }
    
    /**
     * 
     * @param sourcepath
     * @param listRootPath
     * @return
     * @throws IOException
     */
    public static String createrList(String sourcepath, String listRootPath)
            throws IOException {
        
        if (sourcepath.endsWith(File.separator)) {
            sourcepath = sourcepath.substring(0, sourcepath.length() - 1);
        }
        
        // C:/log/cnipr/img/20150325\list//10.62.41.110/rawdata/patentsource/originaldata/CN/image/BOOKS/FM/2015/20150325.txt
        // C:/log/cnipr/img/20150325/originaldata/CN/image/BOOKS/FM/2015/20150325.txt
        // String listPath = listRootPath + File.separator + "list" + sourcepath + ".txt";
        String listPath = "C:\\log\\cnipr\\img\\20150408\\originaldata\\CN\\image\\BOOKS\\FM\\2015\\20150408.txt";
        log.info("listPath = " + listPath);
        
        if (!(new File(listPath)).exists()) {
            //
            // File file = new File(listPath.substring(0, listPath.lastIndexOf(File.separator)));
            File file = new File(listPath.substring(0, listPath.lastIndexOf("/")));
            //
            log.info(file.getAbsoluteFile());
            
            if (!file.exists() || file.isDirectory()) {
                file.mkdirs();
            }
            
            File source = new File(sourcepath);
            
            if (!source.isDirectory()) {
                return "";
            }
            
            File[] patents = source.listFiles();
            FileWriter fw = new FileWriter(listPath);
            BufferedWriter bw = new BufferedWriter(fw);
            
            for (File patent : patents) {
                bw.write(patent.getAbsolutePath());
                bw.newLine();
            }
            bw.close();
            fw.close();
        }
        
        return listPath;
    }

    private static void copyFile(File src, File des) {
        //
        InputStream in = null;
        OutputStream out = null;
        
        try {
            
            File pd = des.getParentFile();
            
            if (!pd.exists()) {
                pd.mkdirs();
            }
            
            in = new FileInputStream(src);
            out = new FileOutputStream(des);
            
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //
            try {
                in.close();
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
        }
    }
    
    /**
     * 
     * @param k2imagePath
     * @param patentPath
     * @throws Exception
     */
    public void uploadImage(String k2imagePath, String patentPath)
            throws Exception {
        
        File patentSrcFile = new File(patentPath);
        File patentDesFile = new File(k2imagePath);
        
        if (!patentDesFile.exists() || !patentDesFile.isDirectory()) {
            patentDesFile.mkdirs();
        }
        
        File[] imageFiles = patentSrcFile.listFiles();
        
        int imageCount = 0;
        
        for (File imageFile : imageFiles) {
            String[] tmp = imageFile.getName()
                    .replace(patentSrcFile.getName() + "_", "").split("\\.");
            String page = tmp[0];
            String type = tmp[1];
            if (type.equalsIgnoreCase("jpg") || type.equalsIgnoreCase("tif")) {
                
                Matcher matcher = pattern.matcher(page);
                //
                if (matcher.find()) {
                    
                    page = matcher.group(0);
                  
                    String destFilePath = k2imagePath + File.separator + page
                            + "." + type.toLowerCase();
                    //
                    copyFile(new File(imageFile.getAbsolutePath()), new File(
                            destFilePath));
                    
                    imageCount++;
                }
            }
        }
        
        if (this.patentinfo.filePageNumber == null
                || this.patentinfo.filePageNumber != imageCount) {
            //
            this.patentinfo.filePageNumber = imageCount;
            this.patentinfo.save();
        }
        
    }

    /**
     * 
     * @param startPath
     * @throws Exception
     */
    public void importImage(String startPath) throws Exception {
        
        log.info("into importImage...");
        
        // TODO: ??? 
        //  C:/log/cnipr/img/20150325\list//10.62.41.110/rawdata/patentsource/originaldata/CN/image/BOOKS/FM/2015/20150325.txt
        String listPath = createrList(this.sourcePath, this.listPath);

        if (!listPath.isEmpty()) {
            
            FileReader listFileReader = new FileReader(listPath);
            BufferedReader listBufferedReader = new BufferedReader(
                    listFileReader);
            
            String patentPath = "";

            // TODO: startPath ???
            if (startPath != null && !startPath.isEmpty()) {
                //
                while ((patentPath = listBufferedReader.readLine()) != null) {
                    patentPath = patentPath.trim();
                    if (patentPath.equals(startPath.trim())) {
                        break;
                    }
                }
                
                log.info("start upload from patent path : " + patentPath);
            }

            while ((patentPath = listBufferedReader.readLine()) != null) {

                patentPath = patentPath.trim();
                
                String patentNumber = patentPath.substring(patentPath
                        .lastIndexOf(File.separator) + 1);
                int stat = 2;
                
                if (patentPath.contains("FM")) {
                    stat = 1;
                } else if (patentPath.contains("WG")) {
                    String newPatentNumber = patentNumber.substring(0,
                            patentNumber.length() - 1);
                    newPatentNumber = patentNumber.substring(0,
                            patentNumber.length() - 1).toUpperCase()
                            + "."
                            + patentNumber.substring(patentNumber.length() - 1)
                                    .toUpperCase();
                    patentNumber = newPatentNumber;
                }
                
                // TODO: DB connection setting ???
                this.patentinfo = PatentInfoCNIPR.findPN(Pto.CNIPR,
                        patentNumber, stat);
                
                if (this.patentinfo != null) {
                    
                    String k2imagePath = this.targetPath + File.separator
                            + "cn" + stat
                            + this.patentinfo.kindcode.toLowerCase()
                            + File.separator
                            + dateFormat.format(patentinfo.doDate)
                            + File.separator + patentNumber.toLowerCase()
                            + File.separator + "fullImage";
                    pe.addNum().debug(log, 10000,
                            "source:" + patentPath + ", dest:" + k2imagePath);
                    
                    log.info("k2imagePath = " + k2imagePath);
                    log.info("patentPath = " + patentPath);
                    
                    this.uploadImage(k2imagePath, patentPath);
                    
                } else {
                    //
                    log.info("patentnumber:'" + patentNumber + "'[" + stat
                            + "]" + " not find!");
                    
                }
            }
            
            listFileReader.close();
            listBufferedReader.close();
            
        }

    }
    
    /**
     * entry point
     * 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        CniprAutoImageImpoterRefactor cnipr = new CniprAutoImageImpoterRefactor();
        cnipr.worker(args);

    }
    
    public void worker(String[] args) throws Exception {

        try {
            
            ArgParser argParser = new ArgParser().addOpt(
                    CniprAutoImageImpoterRefactor.class).parse(args);
            
            MongoAuthInitUtils.reload(argParser);
            
            /*
             * FM, SD, XX image soure path => 
             * /mnt/patentsource/CN/image/BOOKS/FM/${QueryYear}/${QueryOther}
             * 
             * => \\10.62.41.110\rawdata\patentsource\originaldata\CN\image\BOOKS\FM\2015\20150325
             * 
             * WG image source path => 
             * /mnt/patentsource/CN/image/BOOKS/WG/${QueryYear}/${QueryWG}
             * 
             * => \\10.62.41.110\rawdata\patentsource\originaldata\CN\image\BOOKS\WG\2015\3112
             * 
             */
            // sourcePath = argParser.getOptString(opt_source_path);
            sourcePath = "\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\CN\\image\\BOOKS\\FM\\2015\\20150408";
            
            /*
             *  image target path => /mnt/nhdell/patent_cn/data
             *  => \\10.60.95.12\patentimg\patent_cn\data
             *  
             */
            // targetPath = argParser.getOptString(opt_target_path);
            targetPath = "\\\\10.60.95.12\\patentimg\\patent_cn\\data";
            
            /*
             *  log path ??? => /home/haoyou/d
             *  => C:\log\cnipr\img\20150325
             *  
             */
            // listPath = argParser.getOptString(opt_list_path);
            listPath = "C:\\log\\cnipr\\img\\20150408";
            
            // useless ???
            startPath = argParser.getOptString(opt_start_path);
            
            if (sourcePath == null || sourcePath.isEmpty()
                    || targetPath == null || targetPath.isEmpty()) {
                throw new ParseException("");
            }
            
        } catch (ParseException e) {
            System.out.println("error ...");
            return;
        }

        CniprAutoImageImpoterRefactor cnipr = new CniprAutoImageImpoterRefactor();
        cnipr.importImage(startPath);

    }

}
