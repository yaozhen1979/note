package org.yaozhen.jsoup;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Demo3 {

    public static void main(String[] args) throws IOException {

        // http://apod.nasa.gov/apod/ap140827.html
        Document doc = Jsoup.connect("http://apod.nasa.gov/apod/ap140827.html").get();
        Element queryBody = doc.select("center").first();
        
        String htmlBoby = queryBody.html();
        System.out.println(htmlBoby);
        
        System.out.println("h1 text:" + queryBody.select("h1").text());
        
        // System.out.println(queryBody.select("a").size());
        Element hdImgLink = queryBody.select("a").get(1);
        System.out.println("HD Img:" + hdImgLink.attr("abs:href"));
        
        // System.out.println(queryBody.select("img").size());
        Element imgLink = queryBody.select("img").first();
        System.out.println("Original Img:" + imgLink.attr("abs:src"));
        
        System.out.println("======================");
        
        // Explanation
        Element explanationNode = doc.select("center").get(1).nextElementSibling();
        System.out.println("Explanation:" + explanationNode.html());
        
    }

}
