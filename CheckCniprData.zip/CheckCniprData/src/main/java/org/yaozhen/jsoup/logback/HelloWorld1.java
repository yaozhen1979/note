/**
 * Logback: the reliable, generic, fast and flexible logging framework.
 * Copyright (C) 1999-2013, QOS.ch. All rights reserved.
 *
 * This program and the accompanying materials are dual-licensed under
 * either the terms of the Eclipse Public License v1.0 as published by
 * the Eclipse Foundation
 *
 *   or (per the licensee's choosing)
 *
 * under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation.
 */
package org.yaozhen.jsoup.logback;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HelloWorld1 {

  public static void main(String[] args) {

    Logger logger = LoggerFactory.getLogger(HelloWorld1.class);
    logger.debug("Hello world.");
    
    Logger noFilesLogger = LoggerFactory.getLogger("NoFiles");
    noFilesLogger.warn("warm message");
    
    Logger testLogger = LoggerFactory.getLogger("Test");
    testLogger.error("error message");
    
  }
}
