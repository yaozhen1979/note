package org.yaozhen.jsoup.httpclient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

public class GetResponseHeader {

    public static void main(String[] args) throws ClientProtocolException,
            IOException {

        long start = System.currentTimeMillis();

        // http://apod.nasa.gov/apod/image/1408/m20m21_feynes.jpg
        HttpClient client = HttpClientBuilder.create().build();

        // HttpGet request = new HttpGet("http://mkyong.com");
        HttpGet request = new HttpGet(
                "http://apod.nasa.gov/apod/image/1408/m20m21_feynes.jpg");

        HttpResponse response = client.execute(request);

        int statusCode = response.getStatusLine().getStatusCode();
        System.out.println("Response returned status code " + statusCode);

        if (HttpStatus.SC_OK == statusCode) {
            // handle 200 OK
            // get all headers
            Header[] headers = response.getAllHeaders();
            for (Header header : headers) {
                System.out.println("Key : " + header.getName() + " ,Value : "
                        + header.getValue());
            }

        } else if (HttpStatus.SC_NOT_FOUND == statusCode) {
            // TODO: handle 404 Not Found
        } else {
            // TODO: handle other codes here
        }

        // get header by 'key'
        String server = response.getFirstHeader("Server").getValue();
        System.out.println("server:" + server);

        // get header 'Content-Length'
        double contentLength = Double.valueOf(response.getFirstHeader("Content-Length")
                .getValue());
        System.out.println("Content-Length:" + contentLength);

        System.out.println("protocol version:" + response.getProtocolVersion());

        // TODO: download file ???
        System.out.println("response isStreaming:"
                + response.getEntity().isStreaming());
        System.out.println("response conetent length:"
                + response.getEntity().getContentLength());

        System.out.println("ms for block n was: "
                + (System.currentTimeMillis() - start));

        if (response.getEntity().isStreaming()) {
            InputStream is = new BufferedInputStream(response.getEntity()
                    .getContent());
            OutputStream os = new BufferedOutputStream(new FileOutputStream(
                    "download_from_httpclient.jpg"));

            byte[] b = new byte[1024];
            int length;

            System.out.println("downloading file...");

            double tolLength = 0;
            while ((length = is.read(b)) != -1) {
                os.write(b, 0, length);
                tolLength = tolLength + length;
                System.out.println("tolLength:" + tolLength);
                if (contentLength > 0) {
                    System.out.println("Percentace: "
                            + Math.round((tolLength / contentLength * 100.0)) + "%");
                }
            }

            is.close();
            os.close();

            System.out.println("downloading file end...");
        }

        System.out.println("ms for download file was: "
                + (System.currentTimeMillis() - start));

    }

}
