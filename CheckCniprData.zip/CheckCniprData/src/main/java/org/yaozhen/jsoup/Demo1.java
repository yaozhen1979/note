package org.yaozhen.jsoup;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Demo1 {

    public static void main(String[] args) throws IOException {
 
        // http://apod.nasa.gov/apod/archivepix.html
        Document doc = Jsoup.connect("http://apod.nasa.gov/apod/archivepix.html").get();
        // String title = doc.title();
        // System.out.println("title:" + title);
        
        //
//        Elements queryLinks = doc.select("b > a");
//        for (Element link : queryLinks) {
//            System.out.println(link.text());
//            System.out.println(link.attr("href"));
//        }
        
        Element queryBody = doc.select("b").first();
        // System.out.println(queryBody.html());
        String[] parseHtml = queryBody.html().split("<br\\s*\\/?>");
        for (String lineText : parseHtml) {
            // System.out.println(lineText);
            Document innerDoc = Jsoup.parse(lineText, "http://apod.nasa.gov/apod/");
            Element link = innerDoc.select("a").first();
            String text = innerDoc.body().text();
            String linkHref = link.attr("abs:href");
            String linkText = link.text();
            System.out.println(text);
            System.out.println(linkHref);
            System.out.println(linkText);
            System.out.println("==============================");
        }
        
    }

}
