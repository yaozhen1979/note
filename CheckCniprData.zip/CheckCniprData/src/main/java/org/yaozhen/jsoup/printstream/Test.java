package org.yaozhen.jsoup.printstream;

public class Test {

    public static void main(String[] args) throws InterruptedException {
        // TODO Auto-generated method stub
        System.out.print("hello");
        Thread.sleep(1000); // Just to give the user a chance to see "hello".
        System.out.print("\b\b\b\b\b");
        System.out.print("world");
    }

}
