package org.yaozhen.jsoup;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Demo2 {

    public static void main(String[] args) throws IOException, ParseException {
        
        List<Map<String, Object>> listMap = new ArrayList<Map<String, Object>>();
        Map<String, Object> dataMap = null;
        
        // http://apod.nasa.gov/apod/archivepix.html
        Document doc = Jsoup.connect("http://apod.nasa.gov/apod/archivepix.html").get();
        
        Element queryBody = doc.select("b").first();
        // System.out.println(queryBody.html());
        String[] parseHtml = queryBody.html().split("<br\\s*\\/?>");
        for (String lineText : parseHtml) {
            
            // System.out.println(lineText);
            Document innerDoc = Jsoup.parse(lineText, "http://apod.nasa.gov/apod/");
            Element link = innerDoc.select("a").first();
            
            // 資料列文字
            String rowText = innerDoc.body().text();
            
            // 資料連結
            String linkHref = link.attr("abs:href");
            
            // 資料連結文字
            String linkText = link.text();
            
            // 資料日期
            String linkDate = rowText.split(":")[0];
            
            System.out.println(rowText);
            System.out.println(linkHref);
            System.out.println(linkText);
            System.out.println(linkDate);
            System.out.println("==============================");
            
            dataMap = new HashMap<String, Object>();
            dataMap.put("rowText", rowText);
            dataMap.put("linkHref", linkHref);
            dataMap.put("linkText", linkText);
            dataMap.put("linkDate", transDateString(linkDate));
            
            listMap.add(dataMap);
            
        }
        
        System.out.println("total data size:" + listMap.size());
        
        Map<String, Object> mapData = listMap.get(2);
        for (Map.Entry<String, Object> entry : mapData.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        
    }
    
    /**
     * 日期字串 轉換成 日期
     * 
     * @param dateString
     * @return
     * @throws ParseException 
     */
    public static Date transDateString(String dateString) throws ParseException {
        
        // 2014 August 31
        // December 21 1999
        
        SimpleDateFormat formatter = null;
        Date date = null;
        
        // dateInString = "December 21 1999";
        // dateInString = "2014 August 31";
        
        // regex [a-zA-Z]+\s{1}\d{2}\s{1}\d{4} = December 21 1999
        if (dateString.matches("[a-zA-Z]+\\s{1}\\d{2}\\s{1}\\d{4}")) {
            //
            formatter = new SimpleDateFormat("MMM dd yyyy", Locale.ENGLISH);
        } else if (dateString.matches("\\d{4}\\s{1}[A-Za-z]+\\s{1}\\d{2}")) {
            // regex \d{4}\s{1}[A-Za-z]+\s{1}\d{2} = 2014 August 31
            formatter = new SimpleDateFormat("yyyy MMM dd", Locale.ENGLISH);
        }
        
        date = formatter.parse(dateString);
        System.out.println(date);
        System.out.println(formatter.format(date));
        
        return date;
    }

}
