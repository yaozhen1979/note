package org.yaozhen.jsoup;

import java.io.File;
import java.io.IOException;

public class CreateTempFileDemo {
    
    public static void main(String[] args) throws IOException {
        //File.createTempFile("test", ".txt");
        System.out.println(System.getProperty("java.io.tmpdir"));
    }
    
}
