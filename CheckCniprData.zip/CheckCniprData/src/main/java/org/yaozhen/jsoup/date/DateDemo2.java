package org.yaozhen.jsoup.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateDemo2 {

    public static void main(String[] args) throws ParseException {
        
        // 2014 August 31
        // December 21 1999
        
        SimpleDateFormat formatter = null;
        String dateInString = null;
        Date date = null;
        
        // dateInString = "December 21 1999";
        
        dateInString = "2014 August 31";
        
        // regex [a-zA-Z]+\s{1}\d{2}\s{1}\d{4} = December 21 1999
        if (dateInString.matches("[a-zA-Z]+\\s{1}\\d{2}\\s{1}\\d{4}")) {
            
            //
            formatter = new SimpleDateFormat("MMM dd yyyy", Locale.ENGLISH);
            
        } else if (dateInString.matches("\\d{4}\\s{1}[A-Za-z]+\\s{1}\\d{2}")) {
            
            // regex \d{4}\s{1}[A-Za-z]+\s{1}\d{2} = 2014 August 31
            formatter = new SimpleDateFormat("yyyy MMM dd", Locale.ENGLISH);
            
        }
        
        date = formatter.parse(dateInString);
        System.out.println(date);
        System.out.println(formatter.format(date));

    }

}
