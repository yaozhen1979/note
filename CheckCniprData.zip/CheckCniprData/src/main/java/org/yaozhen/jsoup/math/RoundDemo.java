package org.yaozhen.jsoup.math;


public class RoundDemo {

    public static void main(String[] args) {
        
        System.out.println(1.03 - .42);
        
        // 小數後二位, 四捨五入
        double val = 200.345555;
        val = val*100;
        val = Math.round(val);
        val = val /100;
        System.out.println(val);

        // 無條件捨去
        val = 200.344555;
        val = val*100;
        val = (double)((int) val);
        val = val /100;
        System.out.println(val);
        
        // java default Math api, it only return the long type. 
        System.out.println(Math.round(100.53));
        
    }

}
