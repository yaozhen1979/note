package org.yaozhen.jsoup;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

public class SaveImageFromUrl {

    public static void main(String[] args) throws Exception {
        
        
        // String imageUrl = "http://www.avajava.com/images/avajavalogo.jpg";
        String imageUrl = "http://apod.nasa.gov/apod/image/1408/MG_0098jacques_Dierick.jpg";
        String destinationFile = "image_3.jpg";

        saveImage(imageUrl, destinationFile);
        
        System.out.println("save image ok");
    }
    
    public static void saveImage(String imageUrl, String destinationFile)
            throws IOException {
        
        URL url = new URL(imageUrl);
        InputStream is = new BufferedInputStream(url.openStream());
        OutputStream os = new BufferedOutputStream(new FileOutputStream(destinationFile));

        byte[] b = new byte[1024];
        int length;
        while ((length = is.read(b)) != -1) {
            os.write(b, 0, length);
        }

        is.close();
        os.close();
        
    }

}