package org.yaozhen.jsoup.math;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class NumberFormat {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        System.out.println(new DecimalFormat("#,###,###.00").format(new BigDecimal(1000000).longValue()) + "*");
    }

}
