package org.yaozhen.test;

public class RemoteFileList {
    
    // 10.62.41.110\rawdata
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
