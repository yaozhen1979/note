package org.yaozhen.test;

public class HelloWorld {

    public String sayHello() {
        return "hello world";
    }
    
    public static void main(String[] args) {
        //
        System.out.println(new HelloWorld().sayHello());
    }

}
