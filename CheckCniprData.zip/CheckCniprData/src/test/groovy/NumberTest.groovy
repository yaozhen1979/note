[1993..2008].each { 
    println it
}

def year = 2007

def test = [1993..2008]
println "XX = " + test.contains(2000)


println "" + [1..5].contains(3)