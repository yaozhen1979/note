import utils.CnCheckCodeUtil

println CnCheckCodeUtil.getCheckCode("85300106")