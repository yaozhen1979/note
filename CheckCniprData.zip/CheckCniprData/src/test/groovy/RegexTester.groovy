import org.apache.commons.lang3.StringUtils

// C07D 401/12
// G01N2291/044
// G06K 20060101S
// A61K 31/445
// G08G 1/01
// G08G1/01(2006.01)I
// G08G1//042(2006.01)I
// G11B33
def mainCPC = 'G11B33'

def cpcGroup1 = mainCPC =~ /^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/

def cpcGroup2 = mainCPC =~ /^(\S{4})[\s\-]*(\S+)$/

println "cpcGroup1.size() = ${cpcGroup1.size()}"

if (cpcGroup1.size() > 0) {
    
    def updateMainCPC
    
    if (!cpcGroup1[0][1] || !cpcGroup1[0][2] || !cpcGroup1[0][3]) {
        //
        throw new Exception("mainCPC = ${mainCPC} normal pattern error")
    } else {
    
        println '' +  cpcGroup1[0][1] + StringUtils.leftPad(cpcGroup1[0][2], 4, '0') + StringUtils.leftPad(cpcGroup1[0][3], 6, '0')
    }
    
} else if (cpcGroup2.size() > 0) {

    def updateMainCPC
    
    if (!cpcGroup2[0][1] || !cpcGroup2[0][2]) {
        //
        throw new Exception("mainCPC = ${mainCPC} normal pattern error")
    } else {
    
        println '' +  cpcGroup2[0][1] + StringUtils.leftPad('', 10, '0')
    }

} else {
    //
    // println "no match pattern..."
    throw new Exception("mainCPC = ${mainCPC} no match pattern")
}