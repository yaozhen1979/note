/*
 *  path:SD/2010/20100804/200810126761.6,raw exists in 127 and 121
 *  path:FM/2010/20100804/201010118736.0,raw exists in 127
 *  path:FM/2010/20100804/201010118736.0,raw exists in 127 and 121
 *  path:WG/2014/20140604/201330609815.6 no exists
 */

 def dataIp = ["121", "127"]
 
 def pathString = "path:FM/2010/20100804/201010118736.0,raw exists in 127"
 
 def dataList = pathString.split(",")
 
 def path = dataList[0]
 
 def ip = dataList[1]
 
 
 println "test = " + pathString.contains("no exists")
  
 
 