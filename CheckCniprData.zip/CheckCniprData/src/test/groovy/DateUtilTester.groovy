import utils.DateUtil

println DateUtil.getEveryDayInYYYY(1985)

// println DateUtil.getEveryDayInYearInterval(2010, 2011)