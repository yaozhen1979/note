//
import java.text.SimpleDateFormat;

def findDate = "20150624"

println "${findDate.substring(0,4)}.${findDate.substring(4,6)}.${findDate.substring(6,8)}"


SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")

println "date = ${sdf.format(new Date())}"