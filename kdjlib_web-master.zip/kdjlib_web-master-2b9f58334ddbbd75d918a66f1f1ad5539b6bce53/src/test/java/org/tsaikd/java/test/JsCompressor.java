package org.tsaikd.java.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class JsCompressor {

	static Log log = LogFactory.getLog(JsCompressor.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		//2013/10/24 genchi  git上的code沒有test/jsCompressor.xml
//		log.debug("Start");
//		System.out.println(new File(".").getAbsolutePath());
//		HtmlCompressor.compressFromXml("test/jsCompressor.xml");
//		System.out.println(new File(".").getAbsolutePath());
//		log.debug("End");
	}

}
