1. composite -gravity south patent_cloud_img.png 1.TIF composite_img_south_color.TIF => 浮水印 約多5K

2. composite -gravity south -compress Zip  patent_cloud_img.png 1.TIF composite_img_south_color.TIF => 彩色 約多35K

3. 
-------------------------------------------- CN PDF to TIF
convert -density 300 -compress Group4 2012301979675.pdf image_new_%d.tif
Version: ImageMagick 6.9.1-2 Q16 x64 2015-04-14 http://www.imagemagick.org

ref: http://www.imagemagick.org/Usage/annotating/#overlay