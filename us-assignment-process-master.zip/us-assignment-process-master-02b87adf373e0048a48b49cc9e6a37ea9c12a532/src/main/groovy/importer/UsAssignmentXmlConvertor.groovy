package importer

import importer.jaxb.patentAssignment.PatentAssignment

import javax.xml.bind.JAXBElement

import util.xmlUtils.XmlConverter

class UsAssignmentXmlConvertor extends XmlConverter {

    public UsAssignmentXmlConvertor(){
        jaxbPath = "importer.jaxb.patentAssignment";
        xsdFilename = "assignment.xsd";
        xsdFileStream = this.getClass().getResourceAsStream("xsd/" + xsdFilename);
        rootClass = PatentAssignment.class

    }
    
    @Override
    protected String xml2Json(InputStream xml) throws Exception {
        init();
        PatentAssignment doc = ((JAXBElement<PatentAssignment>) unmarshal(xml)).getValue()
        return marshal(doc)
    }

}
