package importer

import java.util.logging.Level

import groovy.json.JsonSlurper

import org.apache.commons.lang3.StringUtils
import org.bson.Document
import org.slf4j.LoggerFactory

import util.UnzipImporter
import util.mongo.UsAssignmentMongoTmp101
import util.xmlUtils.XmlConverter
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.DBCollection

/**
 * Import and Marshall USPTO patent-assignment data 
 * (https://bulkdata.uspto.gov/data2/patent/assignment/) 
 * @author yeatschung
 *
 */
class UsAssignmentImporter extends UnzipImporter {

    DBCollection toColl
    DBCollection errColl
    XmlConverter xmlConverter
    
    static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
    
    static {
        mongoLogger.setLevel(Level.INFO);
    }
    
    /**
     * @param dir: a file or the directory with zip files
     */
    UsAssignmentImporter(String dir){
        super(dir)
        xmlConverter = new UsAssignmentXmlConvertor()
        
        String toDbname = 'AssignmentMarshallUS'
        String toCollname = 'AssignmentMarshallUS'
        String errDbname = toDbname
        String errCollname = 'ErrAssignmentMarshallUS'

//        toColl = new MongoUtil( "patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, toDbname).getDb().getCollection(toCollname)
//        errColl = new MongoUtil( "patentdata", "data.cloud.Abc12345", "10.60.90.101", 27017, errDbname).getDb().getCollection(errCollname)
        toColl = new UsAssignmentMongoTmp101(toDbname).getDb().getCollection(toCollname)
        errColl = new UsAssignmentMongoTmp101(errDbname).getDb().getCollection(errCollname)

    }

    @Override
    public void save(InputStream input, String filename) {
        Document metaData = parseFilename(filename)

        BufferedReader br = new BufferedReader( new InputStreamReader(input));
        StringBuffer content = new StringBuffer()
        String line

        int Count = 0
        boolean isContent = false

        while ((line = br.readLine()) != null){

            if(isContent){
                // start of content
                content.append(line.trim())

                if(line.trim().equalsIgnoreCase("</patent-assignment>")){ // end of content

                    // import
                    Document doc = new Document(metaData)
                    doc['docId'] = StringUtils.substringBeforeLast(metaData['path'], '.xml') + '_' + Count.toString()
                    doc['isHoliday'] = false
                    doc['data'] = new Document(['xml': content.toString()]) 
                    importMongo(doc)
                    
                    // truncate
                    isContent = false
                    content =  new StringBuffer()
                    
                    if(Count % 10000 == 0) log.info('Current Status: ' + Count + ' had finished. (' + filename + ')')
                }
            }else if(line.trim().equalsIgnoreCase("<patent-assignment>")){ // start case
                Count = Count + 1
                isContent = true
                content.append(line.trim())
            }else if(line.trim().contains("<data-available-code>N</data-available-code>")){ // holiday case 
                Document doc = new Document(metaData)
                doc['docId'] = StringUtils.substringBeforeLast(metaData['path'], '.xml') + '_' + Count.toString()
                doc['isHoliday'] = true
                doc['data'] = new Document(['xml': '<data-available-code>N</data-available-code>'])
                log.info( 'Holiday case: ' + filename )
                importMongo(doc)
                return
            }
        }
        log.info( 'Total Count: ' + Count + ' had finished. ( ' + filename + ')')
    }

    protected Document marshall(String xml){
        return new Document(new JsonSlurper().parseText(xmlConverter.xml2Json(xml)))
    }
    
    protected void importMongo(Document doc){
        try{
            if(!doc['isHoliday']) doc['data'] = marshall(doc['data']['xml'])
            toColl.update(new Document('docId', doc['docId']), doc, true)
        }catch(Exception e){
            Document err = new Document(['Error':e.message, 'ErrorStakeTrace':e.stackTrace.toString()])
            errColl.save(err)
        }
    }

    protected Document parseFilename(String filename){
        Document doc = new Document()
        doc['country'] = 'us'
        doc['path'] = StringUtils.substringAfterLast(filename, '/')
        doc['provider'] = 'bulkdata.uspto.gov'
        doc['type'] = 'xml/xml'
        doc['uploadTime'] = Calendar.getInstance(TimeZone.getTimeZone("GMT")).getTime() 
        return doc
    }

    static main(args) {

        // Sample Case
//        String root = 'C:/Users/yeatschung/Documents/USPTO-Assignment/ad20150525.zip'
        // Holiday Sample
//        String root = 'C:/Users/yeatschung/Documents/USPTO-Assignment/ad20151226.zip'
        
        // Batch Case
//        String root = 'C:/Users/yeatschung/Documents/USPTO-Assignment/ad20141231-13.zip'

        // 
        String root = 'C:/Users/yeatschung/Documents/USPTO-Assignment/Data'
        
        List pats = new ArrayList([/[\s\S]*\.xml$/])
        println 'start import'

        new UsAssignmentImporter(root).importFiles(pats)
        println 'done'
    }
}
