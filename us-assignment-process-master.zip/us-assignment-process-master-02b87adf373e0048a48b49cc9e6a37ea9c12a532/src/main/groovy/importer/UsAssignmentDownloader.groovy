package importer

import org.apache.commons.io.IOUtils
import org.apache.http.HttpHost
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.joda.time.LocalDate
import org.joda.time.format.DateTimeFormat
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.http.PCHttpClient

class UsAssignmentDownloader {

    HttpClient client
    static final String urlbase = 'https://bulkdata.uspto.gov/data2/patent/assignment/'
    protected static Logger log = LoggerFactory.getLogger(UsAssignmentDownloader.class)
    
    UsAssignmentDownloader(){
        client = new PCHttpClient().getClient()
    }

    /**
     * get url to the local file
     * @param url
     * @param filename
     */
    void downloadOne(String url, String filename){
        URI uri = new URI(url)
        log.info('start download: ' + uri.toString())
        try{
            HttpResponse res = client.execute(new HttpHost(uri.getHost()), new HttpGet(uri.toString()))
            
            if(res.statusLine.statusCode == 200){   // 'HTTP/1.1 200 OK'
                FileOutputStream fos = new FileOutputStream( new File(filename))
                IOUtils.copy( new BufferedInputStream(res.getEntity().getContent()), fos)
                fos.close()
                log.info( url + ' download success.')
            }else{
                log.error(res.statusLine.toString())
            }                        

        }catch(Exception e){
            log.error( e.toString())
            log.error(url + ' download fail.')
        }
    }
    
    /**
     * 
     * @param startDate
     * @param endDate
     */
    void download(LocalDate startDate, LocalDate endDate, String output='./'){
        assert startDate.isAfter(new LocalDate('2015-12-31')) : "data from 2016-01-01"
        if(!new File(output).exists()) new File(output).mkdirs()
        
        LocalDate tmpDate = startDate
        while(tmpDate.isBefore(endDate)){
            String curFilename = 'ad' + DateTimeFormat.forPattern('yyyyMMdd').print(tmpDate) + '.zip'
            downloadOne(this.urlbase + curFilename , output + curFilename)
            tmpDate = tmpDate.plusDays(1)
            sleep(3000)
        }
    }
    
    /**
     * download data before today from a specified start date   
     * @param startDate
     */
    void download(LocalDate startDate, String output='./'){
        download(startDate, LocalDate.now(), output)
    }
    
    static main(args) {
        UsAssignmentDownloader downloader = new UsAssignmentDownloader()
        downloader.download( new LocalDate('2016-01-20'))
        println 'done'
    }
}
