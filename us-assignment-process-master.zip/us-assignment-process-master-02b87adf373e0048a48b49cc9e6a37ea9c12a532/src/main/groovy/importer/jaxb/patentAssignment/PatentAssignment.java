//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.01.22 於 08:36:15 AM CST 
//


package importer.jaxb.patentAssignment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>patent-assignment complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="patent-assignment"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}assignment-record"/&gt;
 *         &lt;element ref="{}patent-assignors"/&gt;
 *         &lt;element ref="{}patent-assignees"/&gt;
 *         &lt;element ref="{}patent-properties"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "patent-assignment", propOrder = {
    "assignmentRecord",
    "patentAssignors",
    "patentAssignees",
    "patentProperties"
})
public class PatentAssignment {

    @XmlElement(name = "assignment-record", required = true)
    protected AssignmentRecord assignmentRecord;
    @XmlElement(name = "patent-assignors", required = true)
    protected PatentAssignors patentAssignors;
    @XmlElement(name = "patent-assignees", required = true)
    protected PatentAssignees patentAssignees;
    @XmlElement(name = "patent-properties", required = true)
    protected PatentProperties patentProperties;

    /**
     * 取得 assignmentRecord 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AssignmentRecord }
     *     
     */
    public AssignmentRecord getAssignmentRecord() {
        return assignmentRecord;
    }

    /**
     * 設定 assignmentRecord 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AssignmentRecord }
     *     
     */
    public void setAssignmentRecord(AssignmentRecord value) {
        this.assignmentRecord = value;
    }

    /**
     * 取得 patentAssignors 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentAssignors }
     *     
     */
    public PatentAssignors getPatentAssignors() {
        return patentAssignors;
    }

    /**
     * 設定 patentAssignors 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentAssignors }
     *     
     */
    public void setPatentAssignors(PatentAssignors value) {
        this.patentAssignors = value;
    }

    /**
     * 取得 patentAssignees 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentAssignees }
     *     
     */
    public PatentAssignees getPatentAssignees() {
        return patentAssignees;
    }

    /**
     * 設定 patentAssignees 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentAssignees }
     *     
     */
    public void setPatentAssignees(PatentAssignees value) {
        this.patentAssignees = value;
    }

    /**
     * 取得 patentProperties 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentProperties }
     *     
     */
    public PatentProperties getPatentProperties() {
        return patentProperties;
    }

    /**
     * 設定 patentProperties 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentProperties }
     *     
     */
    public void setPatentProperties(PatentProperties value) {
        this.patentProperties = value;
    }

}
