//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.01.22 於 08:36:15 AM CST 
//


package importer.jaxb.patentAssignment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>patent-assignee complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="patent-assignee"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}name"/&gt;
 *         &lt;element ref="{}address-1" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-2" minOccurs="0"/&gt;
 *         &lt;element ref="{}city" minOccurs="0"/&gt;
 *         &lt;element ref="{}state" minOccurs="0"/&gt;
 *         &lt;element ref="{}country-name" minOccurs="0"/&gt;
 *         &lt;element ref="{}postcode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "patent-assignee", propOrder = {
    "name",
    "address1",
    "address2",
    "city",
    "state",
    "countryName",
    "postcode"
})
public class PatentAssignee {

    @XmlElement(required = true)
    protected Name name;
    @XmlElement(name = "address-1")
    protected Address1 address1;
    @XmlElement(name = "address-2")
    protected Address2 address2;
    protected City city;
    protected State state;
    @XmlElement(name = "country-name")
    protected CountryName countryName;
    protected Postcode postcode;

    /**
     * 取得 name 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Name }
     *     
     */
    public Name getName() {
        return name;
    }

    /**
     * 設定 name 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Name }
     *     
     */
    public void setName(Name value) {
        this.name = value;
    }

    /**
     * 取得 address1 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address1 }
     *     
     */
    public Address1 getAddress1() {
        return address1;
    }

    /**
     * 設定 address1 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address1 }
     *     
     */
    public void setAddress1(Address1 value) {
        this.address1 = value;
    }

    /**
     * 取得 address2 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Address2 }
     *     
     */
    public Address2 getAddress2() {
        return address2;
    }

    /**
     * 設定 address2 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Address2 }
     *     
     */
    public void setAddress2(Address2 value) {
        this.address2 = value;
    }

    /**
     * 取得 city 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link City }
     *     
     */
    public City getCity() {
        return city;
    }

    /**
     * 設定 city 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link City }
     *     
     */
    public void setCity(City value) {
        this.city = value;
    }

    /**
     * 取得 state 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link State }
     *     
     */
    public State getState() {
        return state;
    }

    /**
     * 設定 state 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link State }
     *     
     */
    public void setState(State value) {
        this.state = value;
    }

    /**
     * 取得 countryName 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CountryName }
     *     
     */
    public CountryName getCountryName() {
        return countryName;
    }

    /**
     * 設定 countryName 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryName }
     *     
     */
    public void setCountryName(CountryName value) {
        this.countryName = value;
    }

    /**
     * 取得 postcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Postcode }
     *     
     */
    public Postcode getPostcode() {
        return postcode;
    }

    /**
     * 設定 postcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Postcode }
     *     
     */
    public void setPostcode(Postcode value) {
        this.postcode = value;
    }

}
