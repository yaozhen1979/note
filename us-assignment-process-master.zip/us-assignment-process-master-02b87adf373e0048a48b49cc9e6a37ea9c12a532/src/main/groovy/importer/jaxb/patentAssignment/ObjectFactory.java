//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.01.22 於 08:36:15 AM CST 
//


package importer.jaxb.patentAssignment;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the importer.jaxb.patentAssignment package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UsPatentAssignments_QNAME = new QName("", "us-patent-assignments");
    private final static QName _ActionKeyCode_QNAME = new QName("", "action-key-code");
    private final static QName _TransactionDate_QNAME = new QName("", "transaction-date");
    private final static QName _PatentAssignments_QNAME = new QName("", "patent-assignments");
    private final static QName _Date_QNAME = new QName("", "date");
    private final static QName _DataAvailableCode_QNAME = new QName("", "data-available-code");
    private final static QName _PatentAssignment_QNAME = new QName("", "patent-assignment");
    private final static QName _AssignmentRecord_QNAME = new QName("", "assignment-record");
    private final static QName _PatentAssignors_QNAME = new QName("", "patent-assignors");
    private final static QName _PatentAssignees_QNAME = new QName("", "patent-assignees");
    private final static QName _PatentProperties_QNAME = new QName("", "patent-properties");
    private final static QName _ReelNo_QNAME = new QName("", "reel-no");
    private final static QName _FrameNo_QNAME = new QName("", "frame-no");
    private final static QName _LastUpdateDate_QNAME = new QName("", "last-update-date");
    private final static QName _PurgeIndicator_QNAME = new QName("", "purge-indicator");
    private final static QName _RecordedDate_QNAME = new QName("", "recorded-date");
    private final static QName _PageCount_QNAME = new QName("", "page-count");
    private final static QName _Correspondent_QNAME = new QName("", "correspondent");
    private final static QName _ConveyanceText_QNAME = new QName("", "conveyance-text");
    private final static QName _PatentAssignor_QNAME = new QName("", "patent-assignor");
    private final static QName _PatentAssignee_QNAME = new QName("", "patent-assignee");
    private final static QName _PatentProperty_QNAME = new QName("", "patent-property");
    private final static QName _Name_QNAME = new QName("", "name");
    private final static QName _Address1_QNAME = new QName("", "address-1");
    private final static QName _Address2_QNAME = new QName("", "address-2");
    private final static QName _Address3_QNAME = new QName("", "address-3");
    private final static QName _Address4_QNAME = new QName("", "address-4");
    private final static QName _ExecutionDate_QNAME = new QName("", "execution-date");
    private final static QName _DateAcknowledged_QNAME = new QName("", "date-acknowledged");
    private final static QName _City_QNAME = new QName("", "city");
    private final static QName _State_QNAME = new QName("", "state");
    private final static QName _CountryName_QNAME = new QName("", "country-name");
    private final static QName _Postcode_QNAME = new QName("", "postcode");
    private final static QName _DocumentId_QNAME = new QName("", "document-id");
    private final static QName _InventionTitle_QNAME = new QName("", "invention-title");
    private final static QName _Country_QNAME = new QName("", "country");
    private final static QName _DocNumber_QNAME = new QName("", "doc-number");
    private final static QName _Kind_QNAME = new QName("", "kind");
    private final static QName _B_QNAME = new QName("", "b");
    private final static QName _I_QNAME = new QName("", "i");
    private final static QName _U_QNAME = new QName("", "u");
    private final static QName _Sup_QNAME = new QName("", "sup");
    private final static QName _Sub_QNAME = new QName("", "sub");
    private final static QName _Smallcaps_QNAME = new QName("", "smallcaps");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: importer.jaxb.patentAssignment
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UsPatentAssignments }
     * 
     */
    public UsPatentAssignments createUsPatentAssignments() {
        return new UsPatentAssignments();
    }

    /**
     * Create an instance of {@link ActionKeyCode }
     * 
     */
    public ActionKeyCode createActionKeyCode() {
        return new ActionKeyCode();
    }

    /**
     * Create an instance of {@link TransactionDate }
     * 
     */
    public TransactionDate createTransactionDate() {
        return new TransactionDate();
    }

    /**
     * Create an instance of {@link PatentAssignments }
     * 
     */
    public PatentAssignments createPatentAssignments() {
        return new PatentAssignments();
    }

    /**
     * Create an instance of {@link Date }
     * 
     */
    public Date createDate() {
        return new Date();
    }

    /**
     * Create an instance of {@link DataAvailableCode }
     * 
     */
    public DataAvailableCode createDataAvailableCode() {
        return new DataAvailableCode();
    }

    /**
     * Create an instance of {@link PatentAssignment }
     * 
     */
    public PatentAssignment createPatentAssignment() {
        return new PatentAssignment();
    }

    /**
     * Create an instance of {@link AssignmentRecord }
     * 
     */
    public AssignmentRecord createAssignmentRecord() {
        return new AssignmentRecord();
    }

    /**
     * Create an instance of {@link PatentAssignors }
     * 
     */
    public PatentAssignors createPatentAssignors() {
        return new PatentAssignors();
    }

    /**
     * Create an instance of {@link PatentAssignees }
     * 
     */
    public PatentAssignees createPatentAssignees() {
        return new PatentAssignees();
    }

    /**
     * Create an instance of {@link PatentProperties }
     * 
     */
    public PatentProperties createPatentProperties() {
        return new PatentProperties();
    }

    /**
     * Create an instance of {@link ReelNo }
     * 
     */
    public ReelNo createReelNo() {
        return new ReelNo();
    }

    /**
     * Create an instance of {@link FrameNo }
     * 
     */
    public FrameNo createFrameNo() {
        return new FrameNo();
    }

    /**
     * Create an instance of {@link LastUpdateDate }
     * 
     */
    public LastUpdateDate createLastUpdateDate() {
        return new LastUpdateDate();
    }

    /**
     * Create an instance of {@link PurgeIndicator }
     * 
     */
    public PurgeIndicator createPurgeIndicator() {
        return new PurgeIndicator();
    }

    /**
     * Create an instance of {@link RecordedDate }
     * 
     */
    public RecordedDate createRecordedDate() {
        return new RecordedDate();
    }

    /**
     * Create an instance of {@link PageCount }
     * 
     */
    public PageCount createPageCount() {
        return new PageCount();
    }

    /**
     * Create an instance of {@link Correspondent }
     * 
     */
    public Correspondent createCorrespondent() {
        return new Correspondent();
    }

    /**
     * Create an instance of {@link ConveyanceText }
     * 
     */
    public ConveyanceText createConveyanceText() {
        return new ConveyanceText();
    }

    /**
     * Create an instance of {@link PatentAssignor }
     * 
     */
    public PatentAssignor createPatentAssignor() {
        return new PatentAssignor();
    }

    /**
     * Create an instance of {@link PatentAssignee }
     * 
     */
    public PatentAssignee createPatentAssignee() {
        return new PatentAssignee();
    }

    /**
     * Create an instance of {@link PatentProperty }
     * 
     */
    public PatentProperty createPatentProperty() {
        return new PatentProperty();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link Address1 }
     * 
     */
    public Address1 createAddress1() {
        return new Address1();
    }

    /**
     * Create an instance of {@link Address2 }
     * 
     */
    public Address2 createAddress2() {
        return new Address2();
    }

    /**
     * Create an instance of {@link Address3 }
     * 
     */
    public Address3 createAddress3() {
        return new Address3();
    }

    /**
     * Create an instance of {@link Address4 }
     * 
     */
    public Address4 createAddress4() {
        return new Address4();
    }

    /**
     * Create an instance of {@link ExecutionDate }
     * 
     */
    public ExecutionDate createExecutionDate() {
        return new ExecutionDate();
    }

    /**
     * Create an instance of {@link DateAcknowledged }
     * 
     */
    public DateAcknowledged createDateAcknowledged() {
        return new DateAcknowledged();
    }

    /**
     * Create an instance of {@link City }
     * 
     */
    public City createCity() {
        return new City();
    }

    /**
     * Create an instance of {@link State }
     * 
     */
    public State createState() {
        return new State();
    }

    /**
     * Create an instance of {@link CountryName }
     * 
     */
    public CountryName createCountryName() {
        return new CountryName();
    }

    /**
     * Create an instance of {@link Postcode }
     * 
     */
    public Postcode createPostcode() {
        return new Postcode();
    }

    /**
     * Create an instance of {@link DocumentId }
     * 
     */
    public DocumentId createDocumentId() {
        return new DocumentId();
    }

    /**
     * Create an instance of {@link InventionTitle }
     * 
     */
    public InventionTitle createInventionTitle() {
        return new InventionTitle();
    }

    /**
     * Create an instance of {@link Country }
     * 
     */
    public Country createCountry() {
        return new Country();
    }

    /**
     * Create an instance of {@link DocNumber }
     * 
     */
    public DocNumber createDocNumber() {
        return new DocNumber();
    }

    /**
     * Create an instance of {@link Kind }
     * 
     */
    public Kind createKind() {
        return new Kind();
    }

    /**
     * Create an instance of {@link B }
     * 
     */
    public B createB() {
        return new B();
    }

    /**
     * Create an instance of {@link I }
     * 
     */
    public I createI() {
        return new I();
    }

    /**
     * Create an instance of {@link U }
     * 
     */
    public U createU() {
        return new U();
    }

    /**
     * Create an instance of {@link Sup }
     * 
     */
    public Sup createSup() {
        return new Sup();
    }

    /**
     * Create an instance of {@link Sub }
     * 
     */
    public Sub createSub() {
        return new Sub();
    }

    /**
     * Create an instance of {@link Smallcaps }
     * 
     */
    public Smallcaps createSmallcaps() {
        return new Smallcaps();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UsPatentAssignments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "us-patent-assignments")
    public JAXBElement<UsPatentAssignments> createUsPatentAssignments(UsPatentAssignments value) {
        return new JAXBElement<UsPatentAssignments>(_UsPatentAssignments_QNAME, UsPatentAssignments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActionKeyCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "action-key-code")
    public JAXBElement<ActionKeyCode> createActionKeyCode(ActionKeyCode value) {
        return new JAXBElement<ActionKeyCode>(_ActionKeyCode_QNAME, ActionKeyCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "transaction-date")
    public JAXBElement<TransactionDate> createTransactionDate(TransactionDate value) {
        return new JAXBElement<TransactionDate>(_TransactionDate_QNAME, TransactionDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignments")
    public JAXBElement<PatentAssignments> createPatentAssignments(PatentAssignments value) {
        return new JAXBElement<PatentAssignments>(_PatentAssignments_QNAME, PatentAssignments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Date }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date")
    public JAXBElement<Date> createDate(Date value) {
        return new JAXBElement<Date>(_Date_QNAME, Date.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataAvailableCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "data-available-code")
    public JAXBElement<DataAvailableCode> createDataAvailableCode(DataAvailableCode value) {
        return new JAXBElement<DataAvailableCode>(_DataAvailableCode_QNAME, DataAvailableCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignment }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignment")
    public JAXBElement<PatentAssignment> createPatentAssignment(PatentAssignment value) {
        return new JAXBElement<PatentAssignment>(_PatentAssignment_QNAME, PatentAssignment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssignmentRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "assignment-record")
    public JAXBElement<AssignmentRecord> createAssignmentRecord(AssignmentRecord value) {
        return new JAXBElement<AssignmentRecord>(_AssignmentRecord_QNAME, AssignmentRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignors")
    public JAXBElement<PatentAssignors> createPatentAssignors(PatentAssignors value) {
        return new JAXBElement<PatentAssignors>(_PatentAssignors_QNAME, PatentAssignors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignees }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignees")
    public JAXBElement<PatentAssignees> createPatentAssignees(PatentAssignees value) {
        return new JAXBElement<PatentAssignees>(_PatentAssignees_QNAME, PatentAssignees.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentProperties }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-properties")
    public JAXBElement<PatentProperties> createPatentProperties(PatentProperties value) {
        return new JAXBElement<PatentProperties>(_PatentProperties_QNAME, PatentProperties.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReelNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "reel-no")
    public JAXBElement<ReelNo> createReelNo(ReelNo value) {
        return new JAXBElement<ReelNo>(_ReelNo_QNAME, ReelNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FrameNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "frame-no")
    public JAXBElement<FrameNo> createFrameNo(FrameNo value) {
        return new JAXBElement<FrameNo>(_FrameNo_QNAME, FrameNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastUpdateDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-update-date")
    public JAXBElement<LastUpdateDate> createLastUpdateDate(LastUpdateDate value) {
        return new JAXBElement<LastUpdateDate>(_LastUpdateDate_QNAME, LastUpdateDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PurgeIndicator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "purge-indicator")
    public JAXBElement<PurgeIndicator> createPurgeIndicator(PurgeIndicator value) {
        return new JAXBElement<PurgeIndicator>(_PurgeIndicator_QNAME, PurgeIndicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecordedDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "recorded-date")
    public JAXBElement<RecordedDate> createRecordedDate(RecordedDate value) {
        return new JAXBElement<RecordedDate>(_RecordedDate_QNAME, RecordedDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PageCount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "page-count")
    public JAXBElement<PageCount> createPageCount(PageCount value) {
        return new JAXBElement<PageCount>(_PageCount_QNAME, PageCount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Correspondent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "correspondent")
    public JAXBElement<Correspondent> createCorrespondent(Correspondent value) {
        return new JAXBElement<Correspondent>(_Correspondent_QNAME, Correspondent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConveyanceText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conveyance-text")
    public JAXBElement<ConveyanceText> createConveyanceText(ConveyanceText value) {
        return new JAXBElement<ConveyanceText>(_ConveyanceText_QNAME, ConveyanceText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignor")
    public JAXBElement<PatentAssignor> createPatentAssignor(PatentAssignor value) {
        return new JAXBElement<PatentAssignor>(_PatentAssignor_QNAME, PatentAssignor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentAssignee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-assignee")
    public JAXBElement<PatentAssignee> createPatentAssignee(PatentAssignee value) {
        return new JAXBElement<PatentAssignee>(_PatentAssignee_QNAME, PatentAssignee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentProperty }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-property")
    public JAXBElement<PatentProperty> createPatentProperty(PatentProperty value) {
        return new JAXBElement<PatentProperty>(_PatentProperty_QNAME, PatentProperty.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Name }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name")
    public JAXBElement<Name> createName(Name value) {
        return new JAXBElement<Name>(_Name_QNAME, Name.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-1")
    public JAXBElement<Address1> createAddress1(Address1 value) {
        return new JAXBElement<Address1>(_Address1_QNAME, Address1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-2")
    public JAXBElement<Address2> createAddress2(Address2 value) {
        return new JAXBElement<Address2>(_Address2_QNAME, Address2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address3 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-3")
    public JAXBElement<Address3> createAddress3(Address3 value) {
        return new JAXBElement<Address3>(_Address3_QNAME, Address3 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address4 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-4")
    public JAXBElement<Address4> createAddress4(Address4 value) {
        return new JAXBElement<Address4>(_Address4_QNAME, Address4 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExecutionDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "execution-date")
    public JAXBElement<ExecutionDate> createExecutionDate(ExecutionDate value) {
        return new JAXBElement<ExecutionDate>(_ExecutionDate_QNAME, ExecutionDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateAcknowledged }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date-acknowledged")
    public JAXBElement<DateAcknowledged> createDateAcknowledged(DateAcknowledged value) {
        return new JAXBElement<DateAcknowledged>(_DateAcknowledged_QNAME, DateAcknowledged.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link City }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "city")
    public JAXBElement<City> createCity(City value) {
        return new JAXBElement<City>(_City_QNAME, City.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link State }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state")
    public JAXBElement<State> createState(State value) {
        return new JAXBElement<State>(_State_QNAME, State.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CountryName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country-name")
    public JAXBElement<CountryName> createCountryName(CountryName value) {
        return new JAXBElement<CountryName>(_CountryName_QNAME, CountryName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Postcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postcode")
    public JAXBElement<Postcode> createPostcode(Postcode value) {
        return new JAXBElement<Postcode>(_Postcode_QNAME, Postcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "document-id")
    public JAXBElement<DocumentId> createDocumentId(DocumentId value) {
        return new JAXBElement<DocumentId>(_DocumentId_QNAME, DocumentId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventionTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "invention-title")
    public JAXBElement<InventionTitle> createInventionTitle(InventionTitle value) {
        return new JAXBElement<InventionTitle>(_InventionTitle_QNAME, InventionTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Country }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country")
    public JAXBElement<Country> createCountry(Country value) {
        return new JAXBElement<Country>(_Country_QNAME, Country.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-number")
    public JAXBElement<DocNumber> createDocNumber(DocNumber value) {
        return new JAXBElement<DocNumber>(_DocNumber_QNAME, DocNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Kind }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "kind")
    public JAXBElement<Kind> createKind(Kind value) {
        return new JAXBElement<Kind>(_Kind_QNAME, Kind.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link B }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b")
    public JAXBElement<B> createB(B value) {
        return new JAXBElement<B>(_B_QNAME, B.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link I }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i")
    public JAXBElement<I> createI(I value) {
        return new JAXBElement<I>(_I_QNAME, I.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link U }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u")
    public JAXBElement<U> createU(U value) {
        return new JAXBElement<U>(_U_QNAME, U.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup")
    public JAXBElement<Sup> createSup(Sup value) {
        return new JAXBElement<Sup>(_Sup_QNAME, Sup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub")
    public JAXBElement<Sub> createSub(Sub value) {
        return new JAXBElement<Sub>(_Sub_QNAME, Sub.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Smallcaps }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps")
    public JAXBElement<Smallcaps> createSmallcaps(Smallcaps value) {
        return new JAXBElement<Smallcaps>(_Smallcaps_QNAME, Smallcaps.class, null, value);
    }

}
