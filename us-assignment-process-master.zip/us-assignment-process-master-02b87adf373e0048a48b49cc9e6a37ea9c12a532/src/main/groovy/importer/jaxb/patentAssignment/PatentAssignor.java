//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.01.22 於 08:36:15 AM CST 
//


package importer.jaxb.patentAssignment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>patent-assignor complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="patent-assignor"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}name"/&gt;
 *         &lt;element ref="{}execution-date" minOccurs="0"/&gt;
 *         &lt;element ref="{}date-acknowledged" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "patent-assignor", propOrder = {
    "name",
    "executionDate",
    "dateAcknowledged"
})
public class PatentAssignor {

    @XmlElement(required = true)
    protected Name name;
    @XmlElement(name = "execution-date")
    protected ExecutionDate executionDate;
    @XmlElement(name = "date-acknowledged")
    protected DateAcknowledged dateAcknowledged;

    /**
     * 取得 name 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Name }
     *     
     */
    public Name getName() {
        return name;
    }

    /**
     * 設定 name 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Name }
     *     
     */
    public void setName(Name value) {
        this.name = value;
    }

    /**
     * 取得 executionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExecutionDate }
     *     
     */
    public ExecutionDate getExecutionDate() {
        return executionDate;
    }

    /**
     * 設定 executionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExecutionDate }
     *     
     */
    public void setExecutionDate(ExecutionDate value) {
        this.executionDate = value;
    }

    /**
     * 取得 dateAcknowledged 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DateAcknowledged }
     *     
     */
    public DateAcknowledged getDateAcknowledged() {
        return dateAcknowledged;
    }

    /**
     * 設定 dateAcknowledged 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DateAcknowledged }
     *     
     */
    public void setDateAcknowledged(DateAcknowledged value) {
        this.dateAcknowledged = value;
    }

}
