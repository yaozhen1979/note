//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.01.22 於 08:36:15 AM CST 
//


package importer.jaxb.patentAssignment;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>us-patent-assignments complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="us-patent-assignments"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}action-key-code"/&gt;
 *         &lt;element ref="{}transaction-date"/&gt;
 *         &lt;element ref="{}patent-assignments"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="date-produced" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "us-patent-assignments", propOrder = {
    "actionKeyCode",
    "transactionDate",
    "patentAssignments"
})
public class UsPatentAssignments {

    @XmlElement(name = "action-key-code", required = true)
    protected ActionKeyCode actionKeyCode;
    @XmlElement(name = "transaction-date", required = true)
    protected TransactionDate transactionDate;
    @XmlElement(name = "patent-assignments", required = true)
    protected PatentAssignments patentAssignments;
    @XmlAttribute(name = "dtd-version")
    @XmlSchemaType(name = "anySimpleType")
    protected String dtdVersion;
    @XmlAttribute(name = "date-produced")
    @XmlSchemaType(name = "anySimpleType")
    protected String dateProduced;

    /**
     * 取得 actionKeyCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ActionKeyCode }
     *     
     */
    public ActionKeyCode getActionKeyCode() {
        return actionKeyCode;
    }

    /**
     * 設定 actionKeyCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ActionKeyCode }
     *     
     */
    public void setActionKeyCode(ActionKeyCode value) {
        this.actionKeyCode = value;
    }

    /**
     * 取得 transactionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TransactionDate }
     *     
     */
    public TransactionDate getTransactionDate() {
        return transactionDate;
    }

    /**
     * 設定 transactionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionDate }
     *     
     */
    public void setTransactionDate(TransactionDate value) {
        this.transactionDate = value;
    }

    /**
     * 取得 patentAssignments 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentAssignments }
     *     
     */
    public PatentAssignments getPatentAssignments() {
        return patentAssignments;
    }

    /**
     * 設定 patentAssignments 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentAssignments }
     *     
     */
    public void setPatentAssignments(PatentAssignments value) {
        this.patentAssignments = value;
    }

    /**
     * 取得 dtdVersion 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * 設定 dtdVersion 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * 取得 dateProduced 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateProduced() {
        return dateProduced;
    }

    /**
     * 設定 dateProduced 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateProduced(String value) {
        this.dateProduced = value;
    }

}
