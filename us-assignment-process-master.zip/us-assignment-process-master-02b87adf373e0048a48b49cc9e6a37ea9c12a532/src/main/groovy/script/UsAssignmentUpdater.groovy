package script

import importer.UsAssignmentDownloader
import importer.UsAssignmentImporter

import org.bson.Document
import org.joda.time.LocalDate
import org.joda.time.format.DateTimeFormat
import org.slf4j.LoggerFactory

import util.mongo.UsAssignmentMongoTmp101
import ch.qos.logback.classic.Level
import ch.qos.logback.classic.Logger

import com.mongodb.DBCollection
import com.mongodb.DBObject

/**
 * Us assignment download & import to mongo
 * @author yeatschung
 *
 */
class UsAssignmentUpdater {

    LocalDate startDate
    
    protected static Logger log = LoggerFactory.getLogger(UsAssignmentUpdater.class)
    static Logger mongoLogger = LoggerFactory.getLogger("org.mongodb.driver");
    static {
        mongoLogger.setLevel(Level.INFO);
    }
    
    UsAssignmentUpdater(){
    }

    /**    
     * automatic find the date without data
     */
    void findStartDate(){
        //////////////////////////
        String toDbname = 'AssignmentMarshallUS'
        String toCollname = 'AssignmentMarshallUS'
        DBCollection toColl = new UsAssignmentMongoTmp101(toDbname).getDb().getCollection(toCollname)
        //////////////////////////

        LocalDate start = new LocalDate('2016-01-01')
        while(start.isBefore(LocalDate.now())){
            String path = 'ad' + DateTimeFormat.forPattern('yyyyMMdd').print(start) + '.xml'
            
            if(!toColl.findOne(new Document('path', path))){ // can't find
                this.startDate = start 
                break
            }
            start = start.plusDays(1)
        }
        this.startDate = start
    }
    
    void run(){
        if(startDate.isBefore(LocalDate.now())){
            log.info('start download from ' + DateTimeFormat.forPattern('yyyyMMdd').print(startDate))
            download()
            log.info('start import ' + DateTimeFormat.forPattern('yyyyMMdd').print(startDate))
            importData()
        }else{
            log.info('already updated to latest')
        }
    }
    
    void download(){
        new UsAssignmentDownloader().download(startDate, getoutputDir())
    }
    
    void importData(){
        List pats = new ArrayList([/[\s\S]*\.xml$/])
        new UsAssignmentImporter(getoutputDir()).importFiles(pats)
    }
    
    String getoutputDir(){
        return './' + DateTimeFormat.forPattern('yyyyMMdd').print(LocalDate.now()) + '/'
    }
    
    static main(args) {
        
        UsAssignmentUpdater Updater = new UsAssignmentUpdater()
        
/////////////////////////////        
//        use specified time
        Updater.setStartDate(new LocalDate('2016-01-21'))
//        auto update date finding
//        Updater.findStartDate()
/////////////////////////////
        

        Updater.run()
        
    }

}
