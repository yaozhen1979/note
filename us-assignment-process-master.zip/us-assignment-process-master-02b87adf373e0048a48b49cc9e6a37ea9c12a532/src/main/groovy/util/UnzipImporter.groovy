package util

import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * 遞迴的解壓縮，須實作 save 方法
 * @author yeatschung
 *
 */
abstract class UnzipImporter {
    
    protected final static String ZIP_EXTENSION = '.zip';
    protected final static int BUFFER_SIZE = 4096;
    protected static Logger log = LoggerFactory.getLogger(UnzipImporter.class)
    
    protected String root
    protected boolean isDir

    UnzipImporter(String root){
        this.root = FilenameUtils.separatorsToUnix(root)        
        this.isDir = new File(root).isDirectory()
        
        assert isDir | new File(root).isFile() : 'root must be path of file or directory'
    }
    
    abstract void save(InputStream input, String filename)
    
    /**
     * Find files by regular expression and save the file
     * the save method should be impliment in each import situation
     * @param pats : regular expression list for finding import files 
     * @param unzip : recursively find the files match with the pats
     */
    public void importFiles(List<String> pats, boolean unzip=true){
        
        if(isDir){
            log.info('Unzipping Directory: ' + root)
            
            pats.each{pat -> 
                List<String> filenames = getFiles(pat)
                filenames.each{filename->
                    if(!filename.endsWith(ZIP_EXTENSION) && new File(filename).isFile()){
                        save(new FileInputStream(new File(filename)), filename)
                    }
                }
            }

            if(unzip){
                List<String> zipfiles = getFiles(/[\s\S]*\.zip/)
                log.info('start unzip')
                zipfiles.each{ zipfile->
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
                    copy(new FileInputStream(new File(zipfile)), outputStream, BUFFER_SIZE)
                    unzipInMemory(outputStream, getZipdirName(zipfile), pats)
                    outputStream.close()
                }
            }
            
        }else{ // root is a file
            log.info('Unzipping File: ' + root)
            
            if(match(root, pats)){
                save(new FileInputStream(new File(root)), root)
            }else if(root.endsWith(ZIP_EXTENSION) && unzip){
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
                copy(new FileInputStream(new File(root)), outputStream, BUFFER_SIZE)
                unzipInMemory(outputStream, getZipdirName(root), pats)
            }
        }
    }
    
    /**
     * recursively unzip file in memery
     * @param zippedFileOS
     * @param root : unzip file directory 
     * @param pats : regular expression list for finding import files
     */
    protected void unzipInMemory(ByteArrayOutputStream zippedFileOS, String root, List<String> pats) {
        try {
            ZipInputStream inputStream = new ZipInputStream(new BufferedInputStream(new ByteArrayInputStream(zippedFileOS.toByteArray())));
            ZipEntry entry;
            
            while ((entry = inputStream.getNextEntry()) != null) {
                if (!entry.isDirectory()) {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    if (entry.getName().endsWith(ZIP_EXTENSION)) {                        
                        copy(inputStream, outputStream, BUFFER_SIZE)
                        unzipInMemory(outputStream, root + getZipdirName(entry.getName()), pats)
                        outputStream.close()
                    }else if(match(entry.getName(), pats)){
//                        copy(inputStream, outputStream, BUFFER_SIZE)
//                        save(new BufferedInputStream(new ByteArrayInputStream(outputStream.toByteArray())), root+entry.getName())
                        save(inputStream, root+entry.getName())
                    }
                }
            }
            inputStream.close();
        } catch (Exception e) {
            log.error(e.message)
            log.error(e.stackTrace.toString())
        }
    }
    
    /**
     * Remove string ending '.zip' and add '/'
     */
    protected static String getZipdirName(String zip){
        FilenameUtils.separatorsToUnix(StringUtils.removeEnd(zip, ZIP_EXTENSION)) + '/'
    }
    
    
    /**
     * buffer copy from InputStream to OutputStream
     * @param input
     * @param output
     * @param bufferSize
     */
    protected static void copy(InputStream input, OutputStream output, int bufferSize = BUFFER_SIZE){
        int count;
        byte[] data = new byte[bufferSize];
        
        BufferedOutputStream out = new BufferedOutputStream( output, bufferSize);
        while ((count = input.read(data, 0, bufferSize)) != -1) {
            out.write(data, 0, count);
        }
        out.flush();
        out.close();
    }
    
    /*
     * match with regular expression
     */
    public static boolean match(String str, List<String> pats){
        for(i in pats){
            if(str.matches(i))  return true
        }
        return false
    }
    
    /**
     * find file in the sourceDir by regular expression
     * @param pat
     * @return
     */
    protected List<String> getFiles(String pat){
        return new FileNameByRegexFinder().getFileNames(root, pat).collect{file ->
            FilenameUtils.separatorsToUnix(file)
        }
    }


}
