package util.mongo
/**
 * 連上 10.60.90.121 正式機
 * @author yeatschung
 *
 */
class UsAssignmentMongoTmp101 extends MongoUtil{

    static final String account = "tmpus"
    static final String password = "tmpus"
    static final String ip = "10.60.90.101"
    static final Integer port = 27017
    static String dbname = null
    
    UsAssignmentMongoTmp101(dbname = null){        
        super(account, password, ip, port, dbname)
    }
}
