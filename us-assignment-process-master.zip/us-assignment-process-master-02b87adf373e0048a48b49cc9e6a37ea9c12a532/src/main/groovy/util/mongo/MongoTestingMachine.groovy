package util.mongo
/**
 * 連上 155 測試機
 * @author yeatschung
 *
 */
public class MongoTestingMachine extends MongoUtil{

    static final String account = "patentdata"
    static final String password = "data.cloud.Abc12345"
    static final String ip = "10.60.90.155"
    static final Integer port = 27017
    static String dbname = null
    
    MongoTestingMachine(dbname=null){
        super(account, password, ip, port, dbname)
    }
}
