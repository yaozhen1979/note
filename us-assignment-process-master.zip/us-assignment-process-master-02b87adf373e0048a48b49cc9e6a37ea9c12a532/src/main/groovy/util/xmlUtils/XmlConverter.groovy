package util.xmlUtils;

import groovy.util.slurpersupport.GPathResult

import java.util.logging.Logger
import java.util.regex.Pattern

import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBElement
import javax.xml.bind.JAXBException
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.apache.commons.lang3.StringUtils
import org.bson.Document
import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType

import patentdata.utils.CDataProcess
import util.MapUtility;

public abstract class XmlConverter {

    private boolean inited;
    protected Unmarshaller unmarshaller;
    private Marshaller marshaller;
    protected Logger logger = Logger.getLogger("");

    protected String jaxbPath; // jaxb package 位置 Ex:
                               // "wipo.jaxb.publishedApp"
    protected String xsdFilename; // xsd 檔案路徑全名
    protected String moxyOxmFilename; 
    protected InputStream xsdFileStream; // xsd Stream
    protected InputStream importMoxyBinding;
    protected Class<?> rootClass; // 傳 root class
    protected CDataProcess cDataProcess;
    protected ArrayList<CDataPath> cDataPaths = new ArrayList<CDataPath>();
    
    public XmlConverter() {
        super();
    }
    

    /**
     * 用 xml string 直接轉成 json string
     * 
     * @param xml
     * @return
     * @throws Exception
     */
    protected String xml2Json(String xml) throws Exception {
        return xml2Json(new ByteArrayInputStream(xml.getBytes("utf-8")));
    }

    /**
     * 
     * @throws Exception
     */
    protected void init() throws Exception {

        if (inited) {
            return;
        }
//        logger.info("xsd file: " + xsdFile + "\njaxb path: " + jaxbPath);
        // xsdFile
        JAXBContext jc = JAXBContext.newInstance(jaxbPath);
        unmarshaller = jc.createUnmarshaller();

        // validation xsd
        SchemaFactory sf = SchemaFactory
                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new StreamSource( (InputStream) xsdFileStream));

        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();

/////////////////////////////
        if(importMoxyBinding != null){
            List<InputStream> moxyBindings = new ArrayList<>();
            moxyBindings.add(importMoxyBinding);
            props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings);
        }
////////////////////////////

        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        // WoPublishedApplication 為 jaxb 中的 root element
        JAXBContext jc1 = JAXBContext.newInstance(jaxbPath,
                rootClass.getClassLoader(), props);

        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        inited = true;

    }

    protected abstract String xml2Json(InputStream xml) throws Exception;

    protected JAXBElement<?> unmarshal(InputStream xml) throws JAXBException {
        return (JAXBElement<?>) unmarshaller.unmarshal(xml);
    }

    protected String marshal(Object jaxbElement) throws JAXBException {
        StringWriter sw = new StringWriter();
        marshaller.marshal(jaxbElement, sw);
        return sw.toString();
    }


    public Document getRelatedFile(){
        Document doc = new Document("xsd", xsdFilename);
        if(moxyOxmFilename != null){
            doc.append("moxy", moxyOxmFilename);
        }
        return doc;
    }

    /**
     * to CData 
     * @param doc
     * @param xmlContent
     * @return
     * @throws IOException
     * @throws Exception
     */
    public Document toCData(Document doc, String xmlContent) throws IOException, Exception{
        GPathResult root = new XmlSlurper().parseText(cDataProcess.transfer(xmlContent))
        
        GPathResult curNode
        Document curDoc
        Boolean exist
        cDataPaths.each{ cDataPath ->
            for(int i=0; i<cDataPath.length; i++){
                curDoc = doc
                curNode = root
                exist = true

                cDataPath.getTokens(i).eachWithIndex{token, index-> // find the target element
                    if(index>0){ // not root element
                        if(curDoc instanceof Map && curDoc.containsKey(token)){
                              if(!(token == cDataPath.elementName)){ // 不是最後一層就往下找取得 
                                curDoc = curDoc[token]
                              }
                            curNode = curNode[token]
                        }else{
                            exist = false
                            return
                        }
                    }
                }
                                
                if(!exist){
                    continue
                }

                // element exist case
                String insertKey = getInsertKey(curNode.name())
                if(cDataPath.unboundeds[i]){ // array form
                    curNode.eachWithIndex{ content, index ->
                        curDoc[cDataPath.elementName][index] = MapUtility.subMap(curDoc[cDataPath.elementName][index], cDataPath.getRetainKeys())
                        curDoc[cDataPath.elementName][index][insertKey] = node2String(content)
                    }
                }else{ // object form
                    curDoc[cDataPath.elementName] = MapUtility.subMap(curDoc[cDataPath.elementName], cDataPath.getRetainKeys())
                    curDoc[cDataPath.elementName][insertKey] = node2String(curNode)
                }
            }
        }
        return doc
    }
    
    
    /**
     * Convert GPathResult to String and remove first \n
     * @param node
     * @return
     */
    protected String node2String(GPathResult node){
        return StringUtils.stripStart(node.toString(), "\n")
    }
    
    protected String getInsertKey(String elementName){
//        return elementName + '_CData'
        return 'CData'
    }
    
    /**
     * generate regular expression for extract specific tag
     * result: (.*)(<element.*</element>)(.*)
     * @param element
     * @return
     */
    protected Pattern generateXmltagRE(String element){
        return Pattern.compile("([\\s\\S]*)(<" + element + "[\\s\\S]*?>[\\s\\S]*?<\\/" + element + ">)([\\s\\S]*)")
    }
    
    
    /**
     * initialize CDataProcess instance
     */
    protected void initCDataProcess(){
        ArrayList<String> paths = new ArrayList<String>()
        cDataPaths.each{ cDataPath -> 
            paths.addAll(cDataPath.paths)
        }
        cDataProcess = new CDataProcess(true, paths.toArray(new String[paths.size()]))
    }

    /**
     * remove specified xml tag from str
     * @param str
     * @param tag
     * @return
     */
    protected String cutElement(String str, String tag){
        return str.replaceAll(generateXmltagRE(tag)){ full, pat1, pat2, pat3 -> 
            return pat1 + pat3
        }
    }

}