package util.xmlUtils

import org.apache.commons.lang3.StringUtils


/**
 * 
 * @author yeatschung
 *
 */
class CDataPath {
    
    int length
    String elementName      // 最底層 element 名
    Set attributeSet        // element 具有的 attribute     
    Set seperatedElementSet // 需額外保留的 element
    Set retainKeys          // 為上兩集合的聯集
    ArrayList<String> paths // CDataProcess 使用路徑
    ArrayList<Boolean> unboundeds   // xsd 上是否為 unbounded
    
    CDataPath(String elementName ,Set attributeSet, Set seperatedElementSet){
        this.elementName = elementName
        this.attributeSet = attributeSet
        this.seperatedElementSet = seperatedElementSet
        this.paths = new ArrayList<String>()
        this.unboundeds = new ArrayList<String>()
        this.length = 0
        retainKeys = new HashSet<String>()
        if(this.attributeSet != null){ 
            retainKeys.addAll(this.attributeSet)
        }
        if(this.seperatedElementSet != null){
            retainKeys.addAll(this.seperatedElementSet)
        }
    }
    
    void addPath(String path, Boolean unbounded){
        paths.add(path)
        unboundeds.add(unbounded)
        length += 1
    }

    String[] getTokens(int index){
        return StringUtils.split(paths[index], '/')
    }
    
    Set getRetainKeys(){
        return this.retainKeys
    }
}
