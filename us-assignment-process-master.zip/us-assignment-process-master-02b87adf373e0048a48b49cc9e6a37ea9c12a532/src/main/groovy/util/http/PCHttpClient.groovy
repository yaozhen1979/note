package util.http

import org.apache.http.HttpHost
import org.apache.http.auth.AuthScope
import org.apache.http.auth.Credentials
import org.apache.http.auth.UsernamePasswordCredentials
import org.apache.http.client.CredentialsProvider
import org.apache.http.client.HttpClient
import org.apache.http.impl.client.BasicCredentialsProvider
import org.apache.http.impl.client.HttpClientBuilder

class PCHttpClient {
    
    AuthScope auth
    Credentials cred
    HttpHost proxy
    
    PCHttpClient(){
        this.auth = new AuthScope("10.60.94.21", 3128)
        this.cred = new UsernamePasswordCredentials("docker", "Abc.2015")
        this.proxy = new HttpHost('10.60.94.21', 3128, 'http')
    }

    HttpClientBuilder getHttpClientBuilder(){
        HttpClientBuilder httpbuilder = HttpClientBuilder.create()
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider()
        credentialsProvider.setCredentials( auth, cred)
        httpbuilder.setDefaultCredentialsProvider(credentialsProvider)
        httpbuilder.setProxy(proxy)
        return httpbuilder
    }
    
    HttpClient getClient(){
        return this.getHttpClientBuilder().build()
    }

}
