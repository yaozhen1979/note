package util

import java.util.regex.Matcher

import org.bson.Document

class MapUtility {

    /**
     * sort a map by key 
     * @param map
     * @return
     */
    static Document sortMap(Map map){
        return new Document(new TreeMap<String, Object>(map))
    }

    /**
     * sort a map by provided order of keys 
     * @param map
     * @param orderKeys
     * @return
     */
    static Map sortMap(Map map, List orderKeys){

        Set keySet = map.keySet()
        Map result = new LinkedHashMap()

        orderKeys.each{key->
            if(keySet.contains(key)){
                result.put(key, map[key])
            }
        }
        result.putAll(new TreeMap<String, Object>(map))
        return result
    }
    
    /**
     * Convert matcher to Map, each matched value is used to be the value of the keys in the corresponding order  
     * @param matcher
     * @param keys
     * @return
     */
    static Map<String, String> matcher2Map(Matcher matcher, List<String> keys){
        assert matcher.groupCount() == keys.size() : "Error: The length of Matcher and keys must be the same"
        
        Map<String, String> map = new HashMap<String, String>()
        for(int i: 0 .. matcher.groupCount()-1){
            map.put(keys[i], matcher[0][i+1])
        }
        return map
    }
    
    /**
     * return submap with key listed in the keylist  
     * @param doc
     * @param keyList
     * @return
     */
    static Document subMap(Map doc, List keyList){
        Document result = new Document()
        keyList.each{key ->
            if(doc.containsKey(key)){
                result.put(key, doc.get(key))
            }
        }
        return result
    }
    
    /**
     * return submap with key listed in the keySet
     * @param doc
     * @param keySet
     * @return
     */
    static Document subMap(Map doc, Set keySet){
        Document result = new Document()
        keySet.each{key ->
            if(doc.containsKey(key)){
                result.put(key, doc.get(key))
            }
        }
        return result
    }
}
