wget --proxy-user=docker --proxy-password=Abc.2015 --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | \
  sudo apt-key add -
sudo apt-get update


wget --proxy-user=docker --proxy-password=Abc.2015 https://get.docker.com/ -O install-docker.sh



//
sudo apt-key adv --keyserver-options http-proxy=http://docker:Abc.2015@10.60.94.21:3128 --keyserver hkp://keyserver.ubuntu.com:80 --recv 7F0CEB10

apt-key adv --keyserver-options http-proxy=http://docker:Abc.2015@10.60.94.21:3128 --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys 36A1D7869245C8950F966E92D8576A8BA88D21E9


-----------------------------------------------
docker postgresql install document

0. run docker images => docker run -it base/ubuntu:origin bash

1. web => http://www.postgresql.org/download/linux/ubuntu/

2. Create the file /etc/apt/sources.list.d/pgdg.list, and add a line for the repository
   
       deb http://apt.postgresql.org/pub/repos/apt/ utopic-pgdg main
   
   Import the repository signing key, and update the package lists

       wget --proxy-user=docker --proxy-password=Abc.2015 --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
	   
       apt-get update
	   
3. install 

       apt-get install postgresql-9.4
	   
   The repository contains many different packages including third party addons. The most common and important packages are (substitute the version number as required):

       postgresql-client-9.4 - client libraries and client binaries
       postgresql-9.4 - core database server
       postgresql-contrib-9.4 - additional supplied modules
       libpq-dev - libraries and headers for C language frontend development
       postgresql-server-dev-9.4 - libraries and headers for C language backend development
       pgadmin3 - pgAdmin III graphical administration utility

3.0 execute "service postgresql start"
	   
3.1 ref: http://www.postgresql.org/docs/9.4/static/app-createuser.html

   Now, create a PostgreSQL superuser role that can create databases and other roles. Following Vagrant’s convention the role will be named docker with docker password assigned to it.

      su postgres -c "createuser -P -d -r -s docker"
   
        -P
		--pwprompt
		If given, createuser will issue a prompt for the password of the new user. This is not necessary if you do not plan on using password authentication.
   
        -d
		--createdb
		The new user will be allowed to create databases.
		
		-r
		--createrole
		The new user will be allowed to create new roles (that is, this user will have CREATEROLE privilege).
		
		-s
		--superuser
		The new user will be a superuser.

3.2 ref: http://www.postgresql.org/docs/9.4/static/app-createdb.html

	Create a test database also named docker owned by previously created docker role.

        su postgres -c "createdb -O docker docker"
    
		-O owner
		--owner=owner
		Specifies the database user who will own the new database. (This name is processed as a double-quoted identifier.)

3.3 Adjust PostgreSQL configuration so that remote connections to the database are possible. Make sure that inside 

        /etc/postgresql/9.4/main/pg_hba.conf you have following line:
        
		# 允許外部連線
        host    all             all             0.0.0.0/0               md5
		# use streaming replication

3.4 Additionaly, inside /etc/postgresql/9.4/main/postgresql.conf uncomment listen_addresses like so:

		listen_addresses='*'

3.5 execute "service postgresql restart"
		
4. bash: exit

5. Create an image from our container and assign it a name. The <container_id> is in the Bash prompt; you can also locate it using docker ps -a.

       sudo docker commit <container_id> <your username>/postgresql
	   
6. run the PostgreSQL server via docker.

       docker run -d -p 5432:5432 --name postgres -t <your username>/postgresql /bin/su postgres -c '/usr/lib/postgresql/9.4/bin/postgres -D /var/lib/postgresql/9.4/main -c config_file=/etc/postgresql/9.4/main/postgresql.conf'
	   
7. Connect the PostgreSQL server using psql (You will need the postgresql client installed on the machine. For ubuntu, use something like sudo apt-get install postgresql-client).

       sudo docker inspect -format='{{.NetworkSettings.IPAddress}}' $CONTAINER or docker inspect $CONTAINER | grep IPAddress

	   psql -h $CONTAINER_IP -p 5432 -d docker -U docker -W
	   
ref: 1. http://docker-doc.readthedocs.org/zh_CN/latest/examples/postgresql_service.html
     2. http://zaiste.net/2013/08/docker_postgresql_how_to/


8. ALTER USER TO REPLICATION => ALTER USER [user] WITH REPLICATION;
	   
9. createdb -E UTF8 -T template0 --locale=en_US.utf8 <name>

10. Change a role's password: ALTER ROLE davide WITH PASSWORD 'hu8jmn3';
    Remove a role's password: ALTER ROLE davide WITH PASSWORD NULL;
	
11. Create a role that can log in, but don't give it a password: CREATE ROLE jonathan LOGIN;
    
	Create a role with a password: CREATE USER davide WITH PASSWORD 'jw8s0F4';
    (CREATE USER is the same as CREATE ROLE except that it implies LOGIN.)

    Create a role with a password that is valid until the end of 2004. After one second has ticked in 2005, the password is no longer valid.
    => CREATE ROLE miriam WITH LOGIN PASSWORD 'jw8s0F4' VALID UNTIL '2005-01-01';
	
    Create a role that can create databases and manage roles:
    => CREATE ROLE admin WITH CREATEDB CREATEROLE;
	   
	=> http://www.postgresql.org/docs/9.4/static/app-createuser.html

======================================================
	
12. 

CREATE EXTENSION pgcrypto;

select * from contacts;

CREATE TABLE contacts (  
   id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
   name TEXT,
   email TEXT
);

INSERT INTO contacts (name, email) VALUES  
('Dr Nic Williams','drnic'),
('Brian Mattal','brian'),
('Wayne E. Seguin','wayneeseguin');

====================================================== create db

-- Database: patentdata

-- DROP DATABASE patentdata;

CREATE DATABASE patentdata
  WITH OWNER = patentdata
       ENCODING = 'UTF8'
	   TEMPLATE = template0
       TABLESPACE = pg_default
       LC_COLLATE = 'C'
       LC_CTYPE = 'C'
       CONNECTION LIMIT = -1;
	   
====================================================== create user
-- Role: patentcloud
-- DROP ROLE patentcloud;
CREATE ROLE patentcloud LOGIN
  ENCRYPTED PASSWORD 'md5d8f61d6278fd99c7d73923b71b673e1f'
  SUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION;

-- Role: patentdata
-- DROP ROLE patentdata;
CREATE ROLE patentdata LOGIN
  ENCRYPTED PASSWORD 'md5f9d0bf4a7f651f2109db97ffb7a9fc21'
  SUPERUSER INHERIT CREATEDB CREATEROLE NOREPLICATION;
  
--
CREATE ROLE patentdata LOGIN
  PASSWORD 'patentdata'
  SUPERUSER INHERIT CREATEDB CREATEROLE NOREPLICATION;

======================================================

1. create .bashrc, and edit export PATH=$PATH:/usr/lib/postgresql/9.4/bin/

2. update postgres(db user) password
   - su postgresq psql postgres
   - \password postgres
   - enter new password...
   
======================================================

docker script:
docker run -itd -p 5432:5432 --name postgres_master -v /db/postgres/:/db db/postgres:9.4.4 /bin/bash


=====================================================
select * from pg_stat_activity where datname='patentdata';

select pg_terminate_backend(pid) from pg_stat_activity where datname='patentdata';




