KDJLib
======

KD's java common library

## Usage in gradle

* build.gradle
```
repositories {
	mavenCentral()
	maven {
		url "http://nexus.tsaikd.org/nexus/"
	}
}

dependencies {
	compile 'org.tsaikd.java:KDJLib:+'
}
```

