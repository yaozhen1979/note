# Where they come from:
The arrangement of the tools for TIPO updating, all the necessary file were extracted and properly modified to this project. They come from three projects: 
(1) mongoutil (basically the parser to parse raw data in PatentRawTIPO and transfer them to PatentInfoTIPO. 
(2) patent.download and patent.unzip from indexmaker-patentinfo: for raw data downloading and extraction of zip file in linux machine.
(3) TipoDowload is given by jhanyao which play the role of downloading claim/description and pdf file(Image) as a web cralwer of TIPO official web.


# Protocol of the updating of TIPO.

1) Step1. Downloading the source file ".zip" file to local machine.
   TIPO website provides the brief content of the document, but it lacks claim and description part. 
   Claim and description will be public in the website after one month after the publication date.


TipoRawDownload.java

arguments:  

(1) location to save the file.
    In principle the file should be saved to 
    ex. /mnt/patentsource/TW/TIPO_DATA/Issue20XX or/mnt/patentsource/TW/TIPO_DATA/Pub20XX.

(2) File name according to the website of TIPO. 
    Sometimes the name doesn't be shown in the website, but it does exist.

(3) I or P, I= issue and P= publication.

########## ########## ########## ########## ########## ########## ########## ########## ########## ##########



2) Step2. unzip the file into a unofficial folder,
        and all the files inside were named like the patern "folder"+"patent type"+"series number"

Unzip.java

arguments:
(1) -zip.file.path   :ex. C:\data\temp\patentsource\TW\TIPO_DATA\Issue2016\43002.zip
(2) -unzip.tar.path  :ex. C:\data\temp\twunzip\TIPO_DATA\Pub2015\

Note: the pattern of TIPO_DATA\PubXXXX or TIPO_DATA\IssueXXXX should be followed!!!!!!



########## ########## ########## ########## ########## ########## ########## ########## ########## ##########


Step 3. Import raw data into level 1 

Import raw data into database (default: PatentRawTIPO) in mongoDB. 
目前是用PIMS來操作，實際應用之jar檔如下。

TipoImporterSource.java
arguments:
很奇怪，在command line可用，但是configuration內放不能用。
-tipo.path     :ex.  /home/jhanyao/twunzip/TIPO_DATA/Issue2015  
-do.path       :ex.  42011  
-tipo.status   :ex.  issued  
-provider      :ex.  "TIPO Download"  
-mongodb.host  :ex.  10.60.90.188  
-mongodb.ac    :ex.  cGF0ZW50ZGF0YQ==                #漢瑤用base64的 但我在local端用一般字串不知為何也行，而且在.java檔內找不到程式碼
-mongodb.pd    :ex.  ZGF0YS5jbG91ZC5BYmMxMjM0NQ==

option example:

-tipo.path C:\data\temp\twunzip\TIPO_DATA\Issue2015\ -do.path  42033 -tipo.status issued -provider    "TIPO Download" -mongodb.host  127.0.0.1 -mongodb.ac test -mongodb.pd test



########## ########## ########## ########## ########## ########## ########## ########## ########## ##########
Step 4. Import level 1 (in PatentRawTIPO) into level 2 (in PatentInfoTIPO)

MongoAuthRawTIPO.js

在command line下執行，依據輸入之doDate區間，對該時間區間內的raw data(level 1之內)進行解析，再放入level2

mongo --nodb MongoAuthParseRawTIPO.js --eval "參數"

所有參數必須夾在同一對double quotation mark中間。各參數用";"隔開
參數如下:
(1) q='TIPO Download,西元年月日初始日,西元年月日結束日'    (注意要用,隔開，必小於以及大於)
   第一個參數(TIPO Download)為provider，也就是要找TipoImporterSource放入的那些資料的provider。
(2) user='';password=''; 在原檔案內要用base64編碼的帳號跟密碼，現在考慮用一般ascii字元。
(3) mongo_tar_ip='' :目標database(預設是PatentInfoTIPO)所在之機器ip。
(4) mongo_src_ip='' :來源database(預設是PatentRawTIPO )所在之機器ip。
目前來說，目標db和來源db在同一台機器的mongoDB上。
(5) tag='v1.4.9'


mongo --nodb MongoAuthParseRawTIPO.js --eval "q='TIPO Download,20151129,20151202';user='test';password='test';mongo_tar_ip='127.0.0.1';mongo_src_ip='127.0.0.1';tag='v1.4.9';jsFile='MongoAuthParseRawTIPO.js'"
(Jan 15, 2016)

########## ########## ########## ########## ########## ########## ########## ########## ########## ##########
Step 4. Import raw data (including claim and source) into level 1 
目前也是用PIMS操作，實際應用之jar檔如下。

(b) For claim data from TIPO.
不用先做A，要先做MongoAuthRawTIPO.js
TipoWebImporter.java
-tipo.path C:\data\temp\patentsource\TW\TIPO_WEB_CLAIM\tw2\2015\12\01
-provider "TIPO WebDownload" /m
-mongodb.host 127.0.0.1 
-mongodb.ac test 
-mongodb.pd test

-tipo.path C:\data\temp\patentsource\TW\TIPO_WEB_CLAIM\tw2\2015\12\01 -provider "TIPO WebDownload" -mongodb.host 127.0.0.1 -mongodb.ac test
########## ########## ########## ########## ########## ########## ########## ########## ########## ##########

Step 4. Import data from level 1 to level 2.

MongoAuthRawTIPO.js

在command line下執行，依據輸入之doDate區間，對該時間區間內的raw data(level 1之內)進行解析，再放入level2

mongo --nodb MongoAuthParseRawTIPO.js --eval "參數"

所有參數必須夾在同一對double quotation mark中間。各參數用";"隔開
參數如下:
(1) q='TIPO Download,西元年月日初始日,西元年月日結束日'    (注意要用,隔開，必小於以及大於)
   第一個參數(TIPO Download)為provider，也就是要找TipoImporterSource放入的那些資料的provider。
(2) user='';password=''; 在原檔案內要用base64編碼的帳號跟密碼，現在考慮用一般ascii字元。
(3) mongo_tar_ip='' :目標database(預設是PatentInfoTIPO)所在之機器ip。
(4) mongo_src_ip='' :來源database(預設是PatentRawTIPO )所在之機器ip。
目前來說，目標db和來源db在同一台機器的mongoDB上。
(5) tag='v1.4.9'


mongo --nodb MongoAuthParseRawTIPO.js --eval "q='TIPO Download,20151129,20151202';user='test';password='test';mongo_tar_ip='127.0.0.1';mongo_src_ip='127.0.0.1';tag='v1.4.9';jsFile='MongoAuthParseRawTIPO.js'"
(Jan 15, 2016)
=============================================================== ====================================
TipoAuthImageImporter.java : parse page number and move file，level1內要先有該patent
-mongodb.host 127.0.0.1 -mongodb.name PatentInfoTIPO -source.path  C:\data\temp\patentsource\TW\TIPO_IMAGE_DOWNLOAD\tw2\2016\01\11  -target.path  C:\data\temp\nhdell\patent_tw\data -mongodb.ac test -mongodb.pd test -start.path C:\data\temp\patentsource\TW\TIPO_IMAGE_DOWNLOAD\tw2\2016\01\11\D172978\fullPage.pdf

=====================================================================================================
TipoWebImporter 
-tipo.path C:\data\temp\patentsource\TW\TIPO_WEB_CLAIM\tw2\2015\12\01 -provider "TIPO WebDownload" -mongodb.host 127.0.0.1  -mongodb.ac bladesu -mongodb.pd bladesu

==============================
mongo --nodb MongoAuthParseRawTIPOWeb.js --eval "q='TIPO WebDownload,20151129,20151202';user='test';password='test';mongo_tar_ip='127.0.0.1';mongo_src_ip='127.0.0.1';tag='v1.4.9';jsFile='MongoAuthParseRawTIPOWeb.js'"
==============================
Step2_2. claim下載;pdf下載

com.patentcloud.download.tw.TipoDownload

option:
-target.path  //  /mnt/patentsource/TW/TIPO_IMAGE_DOWNLOAD
-do.date  //  20160101 
-page  //  $1
-pni  // 2
-type //PDF


option:
-target.path  C:\data\temp\patentsource\TW\TIPO_IMAGE_DOWNLOAD -do.date  20151201 -page 0 -pni  2 -type Claim


內容包含一個網頁parser，是台灣tipo網站進階搜尋部分爬蟲。
pni:1   選擇公開公報，不選擇專利公報。
pni:2   選擇專利公報，不選擇公開公報。
在TextArea
===============================================
若下載中斷，該如何處理?
Ans 指定頁面，使用同一支程式繼續爬
===============================================
