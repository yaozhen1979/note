package com.patent.utils

class DataStorageUtil {
    static tempDataStorage(def docMap) {
        def data
        if (!!docMap.data) {
            data = docMap.data
        } else {
            data = [:]
        }
        return data
    }
    
    static tempMongoSyncFlagStorage(def docMap) {
        def mongoSyncFlag
        def mongoSyncFlagInit
        if (!!docMap.mongoSyncFlag) {
            mongoSyncFlagInit = docMap.mongoSyncFlag
            mongoSyncFlag = [mongoSyncFlag : [init : mongoSyncFlagInit, update: new Date()]]
        }else{
            mongoSyncFlag = [:]
        }
        return mongoSyncFlag
    }
}
