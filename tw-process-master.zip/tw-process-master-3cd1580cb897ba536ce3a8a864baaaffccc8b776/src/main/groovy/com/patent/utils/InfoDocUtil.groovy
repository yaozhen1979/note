package com.patent.utils

import com.patent.utils.DateUtil;

/**
 * @author ericxiao
 *
 */
class InfoDocUtil {

    static generateInfoDoc (def doc) {
        def docMap = [:]
        //get bibliographic doc root
        //data.biblio.world-patent-data.exchange-documents.exchange-document.0.bibliographic-data.application-reference.0
        def docBiblioRoot = doc.'data'.'biblio'.'world-patent-data'.'exchange-documents'.'exchange-document'.'0'
        def biblioRoot = docBiblioRoot.'bibliographic-data'

        def patentNumber
        def kindCode
        docMap << [pto :'EPO']
        docMap << [provider :'EPO OPS']
        biblioRoot.'publication-reference'.'0'.'document-id'.each { fieldSet ->

            if (fieldSet.'document-id-type' == 'docdb') {
                def country = fieldSet.'country'
                def docNumber = fieldSet.'doc-number'
                kindCode = fieldSet.'kind'
                patentNumber = country+docNumber+kindCode
            }

            if (doc.'stat' == 1 & fieldSet.'document-id-type' == 'epodoc') {
                def openNumber = fieldSet.'doc-number'
                def openDate = DateUtil.parseDate(fieldSet.'date'.toString())
                docMap << ['openNumber': openNumber]
                docMap << ['openDate': openDate]
                docMap << ['doDate': openDate]
            }

            if (doc.'stat' == 2 & fieldSet.'document-id-type' == 'epodoc') {
                def decisionNumber = fieldSet.'doc-number'
                def decisionDate = DateUtil.parseDate(fieldSet.'date'.toString())
                docMap << ['decisionNumber': decisionNumber]
                docMap << ['decisionDate': decisionDate]
                docMap << ['doDate': decisionDate]

            }

        }
        def stat = doc.'stat'
        docMap << ['patentNumber':patentNumber]
        docMap << ['stat': stat]
        docMap << ['mongoSyncFlag':['init':new Date(), 'basicInfo':new Date(), 'last':new Date()]]
        docMap << ['kindcode':kindCode]

        if (!!docBiblioRoot.'abstract') {
            def brief = docBiblioRoot.'abstract'
            docMap << ['brief': brief]
        }
        if (biblioRoot.'application-reference' == null) {
            throw new Exception('no application biblio have problem!')
        } else {
            def appRef = biblioRoot.'application-reference'.'0'.'document-id'
            def appDate
            def originAppNum
            appRef.each {
                if (it.'document-id-type' == 'epodoc') {
                    appDate = DateUtil.parseDate(it.'date'.toString())
                }
                if (it.'document-id-type' == 'docdb') {
                    originAppNum = it.'doc-number'
                }
            }
            docMap << ['appDate':appDate]

            def appNumber = fixAppNum(originAppNum)
            docMap << [appNumber:appNumber]
        }


        def ipcrs = []
        biblioRoot.'classifications-ipcr'.'classification-ipcr'.each {
            ipcrs << fixIpcrs(it.'text')
        }

        docMap << [ipcrs : ipcrs]
        docMap << [mainIPCR : ipcrs[0]]

        def ipcs = []
        if (!!biblioRoot.'classification-ipc') {
            biblioRoot.'classification-ipc'.'text'.each {ipc ->
                if (ipc.size() > 4) {
                    ipcs << ipc[0..3]+' '+ipc[4..-1]
                } else {
                    ipcs << ipc
                }

            }
            docMap << [ipcs:ipcs]
            docMap << [mainIPCS : ipcs[0]]
        }

        def cpcAry = []
        biblioRoot.'patent-classifications'.'0'.'patent-classification'.each {
            def section = it.'section'
            def classValue = it."class"."value"
            def subClass = it.'subclass'
            def mainGroup = it.'main-group'
            def subGroup = it.'subgroup'
            cpcAry << section + classValue + subClass + ' ' + mainGroup + '/' + subGroup
        }
        docMap << [cpcs:cpcAry]
        docMap << [mainCPC:cpcAry[0]]
        if (!!biblioRoot.'invention-title') {
            def title = biblioRoot.'invention-title'
            docMap << [title:title]
        }

        //generate assignees and inventors
        def assignees = []
        def assiCountry
        def assiName
        def inventors = []
        def inventNameMap = [:]
        def inventCountryMap = [:]
        def inventCountry
        def inventName
        def inventSeq
        if (biblioRoot.'parties'.size() >= 1) {
            if (!!biblioRoot.'parties'.'applicants') {
                biblioRoot.'parties'.'applicants'.'applicant'.each { fieldSet ->
                    if (fieldSet.'data-format' == 'original') {
                        assiName = fieldSet.'applicant-name'.'0'.'name'.'0'.'value'
                    }
                    if (fieldSet.'data-format' == 'epodoc') {
                        assiCountry = getAssiCountry(fieldSet.'applicant-name'.'0'.'name'.'0'.'value')
                    }
                }
                if (!!assiCountry) {
                    assignees << [country:[origin:assiCountry], name:[origin:assiName]]
                } else {
                    assignees << [name:[origin:assiName]]
                }

            }

            if (!!biblioRoot.'parties'.'inventors') {
                biblioRoot.'parties'.'inventors'.'inventor'.each { fieldSet ->
                    if (fieldSet.'data-format' == 'original') {
                        inventName = fieldSet.'inventor-name'.'0'.'name'.'0'.'value'
                        inventSeq = fieldSet.'sequence'
                        inventNameMap << [("$inventSeq"):inventName]
                    }
                    if (fieldSet.'data-format' == 'epodoc') {
                        inventCountry = getAssiCountry(fieldSet.'inventor-name'.'0'.'name'.'0'.'value')
                        inventSeq = fieldSet.'sequence'
                        inventCountryMap << [("$inventSeq"):inventCountry]
                    }

                }
            }
        }

        inventCountryMap.each { key,value ->
            if (!!value) {
                inventors << [country:[origin:inventCountryMap.get(key)], name:[origin:inventNameMap.get(key)]]
            } else {
                inventors << [name:[origin:inventNameMap.get(key)]]
            }

        }//end generate assignees and inventors
        if(!!assignees) {
            docMap << [assignees:assignees]
        }
        if (!!inventors) {
            docMap << [inventors:inventors]
        }
        //generate priority patents
        def priorityPatents = []
        def priorityPatentNum
        def priorityPatentDate
        def priorityPatentPto
        def priorityClaimNum = biblioRoot.'priority-claims'.'priority-claim'.size()
        biblioRoot.'priority-claims'.'priority-claim'.each { fieldSet ->
            if (fieldSet.'document-id'.size() > 1) {
                priorityPatentPto = fieldSet.'document-id'.'0'.'doc-number'[0..1]
                if (priorityClaimNum > 1) {
                    if (priorityPatentPto == 'WO') {
                        def pctAppDate = DateUtil.parseDate(fieldSet.'document-id'.'0'.'date'.toString())
                        def appNumber = fieldSet.'document-id'.'0'.'doc-number'
                        def pctAppCtry = appNumber[6..7]
                        def pctAppNumber
                        if (appNumber[8..-1].size() > 5) {
                            pctAppNumber = pctAppCtry +appNumber[2..5]+appNumber[8..-1]
                        } else {
                            pctAppNumber = pctAppCtry +appNumber[2..5]+'0'+appNumber[8..-1]
                        }
                        docMap << [pctAppNumber : pctAppNumber]
                        docMap << [pctAppDate : pctAppDate]
                    } else if (fieldSet.'kind' == 'national') {
                        if (fieldSet.'document-id'.'0'.'document-id-type' == 'original') {
                        } else {
                        priorityPatentNum = fieldSet.'document-id'.'0'.'doc-number'
                        priorityPatentNum = fixPriorityAppNum(priorityPatentNum)
                        priorityPatentDate = DateUtil.parseDate(fieldSet.'document-id'.'0'.'date'.toString())
                        priorityPatentPto = fieldSet.'document-id'.'0'.'doc-number'[0..1]
                        priorityPatents << [pto:priorityPatentPto, appNumber:priorityPatentNum, appDate:priorityPatentDate]
                        }
                    }
                } else {
                    if (priorityPatentPto == 'WO') {
                        def pctAppDate = DateUtil.parseDate(fieldSet.'document-id'.'0'.'date'.toString())
                        def appNumber = fieldSet.'document-id'.'0'.'doc-number'
                        def pctAppCtry = appNumber[6..7]
                        def pctAppNumber
                        if (appNumber[8..-1].size() > 5) {
                            pctAppNumber = pctAppCtry +appNumber[2..5]+appNumber[8..-1]
                        } else {
                            pctAppNumber = pctAppCtry +appNumber[2..5]+'0'+appNumber[8..-1]
                        }

                        docMap << [pctAppNumber : pctAppNumber]
                        docMap << [pctAppDate : pctAppDate]
                        priorityPatents << [pto:pctAppCtry, appNumber:pctAppNumber, appDate:pctAppDate]
                    } else if (fieldSet.'kind' == 'national') {
                        priorityPatentNum = fieldSet.'document-id'.'0'.'doc-number'
                        priorityPatentNum = fixPriorityAppNum(priorityPatentNum)
                        priorityPatentDate = DateUtil.parseDate(fieldSet.'document-id'.'0'.'date'.toString())
                        priorityPatentPto = fieldSet.'document-id'.'0'.'doc-number'[0..1]
                        priorityPatents << [pto:priorityPatentPto, appNumber:priorityPatentNum, appDate:priorityPatentDate]
                    }

                }

            } else {
                if (fieldSet.'document-id'.'0'.'document-id-type' == 'epodoc') {
                    priorityPatentNum = fieldSet.'document-id'.'0'.'doc-number'
                    priorityPatentNum = fixPriorityAppNum(priorityPatentNum)
                    priorityPatentDate = DateUtil.parseDate(fieldSet.'document-id'.'0'.'date'.toString())
                    priorityPatentPto = fieldSet.'document-id'.'0'.'doc-number'[0..1]
                    priorityPatents << [pto:priorityPatentPto, appNumber:priorityPatentNum, appDate:priorityPatentDate]
                }
            }
        }//end generate priority patent
        if (!!biblioRoot.'references-cited') {
            def citedPatents = []
            def otherReferences = []
            biblioRoot.'references-cited'.'citation'.each { fieldSet ->
                if (!!fieldSet.'patcit') {
                    def citedCountry = fieldSet.'patcit'.'document-id'.'0'.'doc-number'[0..1]
                    def citedPatent = fieldSet.'patcit'.'document-id'.'0'.'doc-number'
                    citedPatents << [pto :citedCountry, patentNumber :citedPatent]

                } else {
                    if (!!fieldSet.'nplcit'.'0') {
                        def ref = fieldSet.'nplcit'.'0'.'text'
                        otherReferences << [ref]
                    } else if (!!fieldSet.'nplcit'.'text') {
                        def ref = fieldSet.'nplcit'.'text'
                        otherReferences << [ref]
                    }
                }
            }
            if (!!citedPatents) {
                docMap << [citedPatents:citedPatents]
            }

            if (!!otherReferences) {
                docMap << [otherReferences:otherReferences]
            }

        }

        docMap << [priorityPatents:priorityPatents]
        def claimDescFlag = docMap.'mongoSyncFlag'
        if (!!doc.'data'.'claims') {
            def docClaims = doc.'data'.'claims'.'world-patent-data'.'fulltext-documents'.'fulltext-document'.'0'.'claims'
            docMap << [claim:docClaims]
            claimDescFlag.remove(2)
            claimDescFlag << [claimDesc:new Date(), last:new Date()]
        }
        if (!!doc.'data'.'description') {
            def docDesc = doc.'data'.'description'.'world-patent-data'.'fulltext-documents'.'fulltext-document'.'0'.'description'
            claimDescFlag.remove(2)
            claimDescFlag.remove(3)
            claimDescFlag << [claimDesc:new Date(), last:new Date()]
            docMap << [decription:docDesc]

        }
        docMap << [mongoSyncFlag:claimDescFlag]
        docMap << [relRawdata:[relMarshalldata:doc._id,relRawData:doc.relId._id]]
        docMap << [tagAndFile : [file:'EpoInfoImporter.groovy',version:'V1.0.0']]
        //                println docMap
        return docMap
    } // end generateInfoDoc

    //fix application number without check code
    static fixAppNum(String originAppNum) {
        if (originAppNum.size() == 8) {
            def total = 0
            def index = 0
            originAppNum.each {

                int num = it.toInteger()
                if (index % 2 == 0) {
                    total += num*1
                    //                    println num
                } else {
                    if ((num*2)/10 >= 1) {
                        //                        println num
                        total += ( 1 + (num*2)%10)
                    } else {
                        //                        println num
                        total += num*2
                    }
                }
                index += 1
            }
            def checkCode = 10 - (total % 10)
            if (checkCode == 10) {
                checkCode = 0
            }
            return originAppNum + '.' + checkCode.toString()
        } else {
            throw new Exception("the app number must be 8 character")
        }

    } //end fixAppNum

    //fix ipcr to our format
    static fixIpcrs (String originIpcr) {
        def ipcr = originIpcr =~ /(?<class>[A-H]{1}\d{2}\S{1})\s+(?<mainGroup>\d{1,3}\/)\s+(?<subGroup>\d+)[\s\S]+/
        def ipcrAnotherRegex = originIpcr =~ /(?<class>[A-H]{1}\d{2}\S{1})[\s\S]+/
        def ipcrClass
        def mainGroup
        def subGroup
        if (ipcr.matches()) {
            ipcrClass = ipcr.group('class')
            mainGroup = ipcr.group('mainGroup')
            subGroup = ipcr.group('subGroup')
            return ipcrClass+' '+mainGroup+subGroup
        } else if (ipcrAnotherRegex.matches()) {
            ipcrClass = ipcrAnotherRegex.group('class')
            return ipcrClass
        } else {
            throw new Exception('wrong regex format for ipcr')
        }

    } //end fixIpcrs

    //get assignees country
    static getAssiCountry (String originName) {
        def country
        def assiName = originName.trim() =~ /.*\[(?<country>\S{2})\]/
        if (assiName.matches()) {
            country = assiName.group('country')
        }
        return country
    } //end getAssiCountry

    //get cited reference country and bibliographic
    static generateOtherRef (String nplcit) {
        def match = nplcit =~ /(?<source>[\W\w\s\d]+),{1}(?<name>.*)/
        def anotherMatch = nplcit =~ /(?<source>[\W\w\s\d]+):{1}(?<name>.*)/
        def source
        def name
        if (match.matches()) {
            source = match.group('source')
            name = match.group('name')
        } else if (anotherMatch.matches()) {
            source = anotherMatch.group('source')
            name = anotherMatch.group('name')
        } else {
            throw new Exception ('no other ref regex match')
        }
        return [source, name]
    } //end generateOtherRef

    static writeError(def errCol, int stat, String errMsg, def doDate, def rawId) {

        def errDoc = [:]
        errDoc << ["stat" : stat]
        errDoc << ["createDate" : new Date()]
        errDoc << ["errMsg" : errMsg]
        errDoc << ["doDate" : doDate]
        errDoc << ["relRawDataId" : rawId]
        errCol.save(errDoc)
    }

    static fixPriorityAppNum (def priorityAppNum) {
        def match = priorityAppNum =~ /\d{2}([A-Z]+)\s{1}(\d+)/
        if (match.matches()) {
            return match.group(1)+match.group(2)
        } else if (priorityAppNum.matches(/[A-Z]{2}\s{1}\d+/)) {
            return priorityAppNum.replace(' ','')
        } else if (priorityAppNum.matches(/[A-Z]{2}\d+/)) {
            return priorityAppNum
        } else if (priorityAppNum.matches(/[A-Z]{2}\d+[UPKDF]?/)) {
            return priorityAppNum
        } else if (priorityAppNum.matches(/IT\d+MI\d+[U]/)) {
            return priorityAppNum
        } else if (priorityAppNum.matches(/[A-Z]{2}\d+[A-Z]{2}\d+[U]?/)){
            if (priorityAppNum[8..-1].size() > 5) {
                priorityAppNum = priorityAppNum[6..7] +priorityAppNum[2..5]+priorityAppNum[8..-1]
            } else {
                priorityAppNum = priorityAppNum[6..7] +priorityAppNum[2..5]+'0'+priorityAppNum[8..-1]
            }
            return priorityAppNum
        } else if (priorityAppNum.matches(/[A-Z]{2}\d+[A-Z]{1}\d+[U]?/)) {
            return priorityAppNum
        } else if (priorityAppNum.matches(/[A-Z]{3}\d+/)) {
            return priorityAppNum
        } else if (priorityAppNum.matches(/[A-Z]{4}\d+[U]/)) {
            return priorityAppNum
        } else {
            throw new Exception ('priority claims no pattern match!')
        }
    }

}

