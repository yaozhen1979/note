package com.patent.utils

import java.io.File;

class FileUtil {
    
    /**
     * 
     * @param file
     */
    static void mkdir(File dir) {
        
        if (!dir.exists()) {
            File parentFile = dir.getParentFile()
            mkdir(parentFile)
        }
        
        dir.mkdirs()
    }
    
    /**
     * 
     * @param source
     * @param dest
     * @throws IOException
     */
    static void copyFileUsingStream(File source, File dest) throws IOException {
        
        InputStream is = null;
        OutputStream os = null;
        
        if (!dest.getParentFile().exists()) {
            FileUtil.mkdir(dest.getParentFile())
        }
        
        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
        
    }  // end copyFileUsingStream
    
}
