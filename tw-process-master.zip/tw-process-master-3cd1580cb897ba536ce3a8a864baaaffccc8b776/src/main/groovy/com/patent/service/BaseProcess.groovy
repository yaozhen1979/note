package com.patent.service;

import java.util.Properties;
import com.patent.utils.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * refactor ???
 * 
 * 只放由讀取config.properties中的資料
 * 
 * @author tonykuo
 *
 */
public abstract class BaseProcess {
    
    protected static Logger log = LoggerFactory.getLogger(BaseProcess.class);
    
    // TODO: load class refactor 
    // protected Properties propertyUtil = PropertiesUtil.load("src/main/resources/config.properties");
    // protected Properties propertyUtil = PropertiesUtil.load("config.properties");
    
    protected final String USER_MAIL = "";
    
    // MONGO DB SETTING
    protected final String MONGODB_USER_NAME = "patentdata2015"
    protected final String MONGODB_PWD = "patentdata2015"
    protected final String MONGODB_IP = "10.60.90.155"
    protected final int MONGODB_PORT = 27017
    
}
