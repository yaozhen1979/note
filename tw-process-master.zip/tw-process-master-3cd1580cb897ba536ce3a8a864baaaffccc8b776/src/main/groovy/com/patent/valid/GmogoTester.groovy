package com.patent.valid
import com.patent.utils.MongoUtil
class GmogoTester{
    static main (String[] args){
        
        def dbClient = MongoUtil.connect2X("patentdata2015", "patentdata2015", "10.60.90.155", 27017, 'admin')
        def db = dbClient.getDB("PatentInfoTIPO");
        def count = db.PatentInfoTIPO.count();
        
        println "count = ${count}"
    }
}


