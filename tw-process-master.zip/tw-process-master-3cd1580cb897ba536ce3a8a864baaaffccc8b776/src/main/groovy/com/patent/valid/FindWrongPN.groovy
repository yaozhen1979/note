package com.patent.valid

import com.patent.utils.MongoUtil
//import org.bson.types.ObjectId
import com.patent.utils.DateUtil
import java.text.SimpleDateFormat
class FindWrongPN {
    static Calendar cal = Calendar.getInstance()
    
    static def addOneDay(Date date) {
        cal.setTime(date);
        cal.add(Calendar.DATE, 1);
        return cal.getTime()
    }
    
    static main(args) {
        // searching condition
        def beginDate = "20151201"
        def endDate = "20160201"
        def stat = 1
        def DBName = "PatentInfoTIPO"
        // return column
        
        
        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        isoFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        
        def qDate1 = DateUtil.parseDate(beginDate);
        def qDate2 = DateUtil.parseDate(endDate);
        
        def dbClient = MongoUtil.connect2X("patentdata", "data.cloud.Abc12345", "10.60.90.121", 27017, 'admin')
        def db = dbClient.getDB(DBName);
        
        // before all, print the title, tag, and basic information:
        def today = new Date()
        println sprintf("Infomation generated date: %s",today)
        println sprintf("Counting column number of document on certain day")
        println sprintf("Name of database: %s",DBName)
        if (stat == 1){
            println "Publication survey:"
        } else if (stat ==2) {
            println "Issue survey:"
        }
        println sprintf( '%10s  %15s %15s %15s', ["Date", "total docs", "description", "claim"])
        
        while (qDate2.after(qDate1) || qDate2.equals(qDate1)){
            
            def doDateString = DateUtil.parseDate(DateUtil.toISODateFormat(qDate1))
            def statValue = stat
            
            def preSearch = db.getCollection("PatentInfoTIPO").findOne([ doDate:doDateString,stat:statValue],[_id:1])
            if (preSearch != null){
                // staring construct rule to select doc in mongoDB.
                
                def singleSearch = db.getCollection("PatentInfoTIPO").find(
                [   doDate: doDateString ,
                    stat: statValue,
                    patentNumber:/D\d\d$/,
                ],[
                    _id:1,
                    doDate:1,
                    patentNumber:1
                ])
                
                singleSearch.each({doc ->
                    println "_id:"+doc.get('_id')+
                    " PN:"+doc.get('patentNumber')+
                    " doDate:"+doc.get('doDate')
                })
            }
            
            // going to next day
            qDate1 = addOneDay(qDate1)
        }
    }
    
}