
package com.patentcloud.TipoImporters;

import com.mongodb.BasicDBObject;
import itec.patent.common.DateUtils;
import itec.patent.common.MongoAuthInitUtils;
import itec.patent.mongodb.Pto;
import itec.patent.mongodb.patentraw.PatentRawTIPO;
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.utils.*;

public class TipoImporterSource {

    public static void main(String args[]) throws Exception {
        TipoImporterSource tipoImporterSource = new TipoImporterSource();
        tipoImporterSource.worker(args);
    }

    public void worker(String args[]) throws Exception {
        ArgParser argParser = (new ArgParser())
                .addOpt(TipoImporterSource.class).parse(args);
        MongoAuthInitUtils.reload(argParser);
        String argPath = argParser.getOptString("tipo.path");
        String argDoVol = argParser.getOptString("do.path");
        String argStatus = argParser.getOptString("tipo.status");
        provider = argParser.getOptString("provider");
        if (log.isDebugEnabled())
            log.debug((new StringBuilder()).append("start, opt: ")
                    .append(argParser.getParsedMap()).toString());
        (new TipoImporterSource(argPath)).importDir(argDoVol, argStatus);
        log.debug("finish");
    }

    public TipoImporterSource(String tipopath) throws UnknownHostException {
        this.tipopath = new File(tipopath);
        pe = (new ProcessEstimater(0L)).setFormat("%2$d");
    }

    public TipoImporterSource() {

    }

    public String ConvertYear2Vol(String argDoYear, String argStatus) {
        String volStr = "";
        if (argDoYear.isEmpty() || argStatus.isEmpty())
            return volStr;
        try {
            int startYear;
            if (argStatus.equalsIgnoreCase("issued"))
                startYear = 1973;
            else if (argStatus.equalsIgnoreCase("published")) {
                startYear = 2002;
            } else {
                log.debug("patent status err");
                throw new Exception("patent status err");
            }
            int yearInt = Integer.parseInt(argDoYear);
            int vol = yearInt - startYear;
            if (vol - 10 < 0)
                volStr = (new StringBuilder()).append("0")
                        .append(Integer.toString(vol)).toString();
            else
                volStr = Integer.toString(vol);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return volStr;
    }

    public Date ConvertVol2Year(String vol, String argStatus) {
        Date date = null;
        String year = "";
        String month = "";
        String day = "";
        int vol2 = Integer.parseInt(vol.substring(vol.length() - 2));
        int startYear = 0;
        try {
            if (argStatus.equalsIgnoreCase("issued")) {
                startYear = 1973;
                int m = vol2 / 3;
                int d = vol2 % 3;
                if (d == 0)
                    day = "21";
                else if (d == 1) {
                    m++;
                    day = "01";
                } else if (d == 2) {
                    m++;
                    day = "11";
                }
                if (m < 10)
                    month = (new StringBuilder()).append("0")
                            .append(Integer.toString(m)).toString();
                else
                    month = Integer.toString(m);
            } else if (argStatus.equalsIgnoreCase("published")) {
                startYear = 2002;
                int m = vol2 / 2;
                int d = vol2 % 2;
                if (d == 0)
                    day = "16";
                else if (d == 1) {
                    m++;
                    day = "01";
                }
                if (m < 10)
                    month = (new StringBuilder()).append("0")
                            .append(Integer.toString(m)).toString();
                else
                    month = Integer.toString(m);
            } else {
                throw new Exception((new StringBuilder())
                        .append("can't recognition tipo status : ")
                        .append(argStatus).toString());
            }
            year = Integer.toString(startYear
                    + Integer.parseInt(vol.substring(0, 2)));
            date = DateUtils.parseDate((new StringBuilder()).append(year)
                    .append("/").append(month).append("/").append(day)
                    .toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public TipoImporterSource importDir(String argDoVol, String argStatus)
            throws IOException {
        File dirs[] = tipopath.listFiles();
        if (argDoVol.isEmpty()) {
            File arr$[] = dirs;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                File dir = arr$[i$];
                importDir(dir, argStatus);
            }

        } else {
            File arr$[] = dirs;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                File dir = arr$[i$];
                if (dir.getName().startsWith(argDoVol))
                    importDir(dir, argStatus);
            }

        }
        return this;
    }

    public TipoImporterSource importDir(File dir, String argStatus)
            throws IOException {
        if (dir.isDirectory()) {
            File filesBiblio[] = dir.listFiles();
            File arr$[] = filesBiblio;
            int len$ = arr$.length;
            for (int i$ = 0; i$ < len$; i$++) {
                File fileBiblio = arr$[i$];
                String absolutePath = fileBiblio.toPath().toString();
                String path = absolutePath.substring(
                        absolutePath.toLowerCase().indexOf("tipo")).replaceAll(
                        "\\\\", "/");
                Date doDate = ConvertVol2Year(dir.getName(), argStatus);
                if (doDate != null) {
                    PatentRawTIPO.remove(
                            rawclazz,
                            (new QueryHelp("path", path)).filter("pto",
                                    pto.toString()));
                    PatentRawTIPO raw = new PatentRawTIPO();
                    raw.pto = pto;
                    raw.path = path;
                    raw.data = new BasicDBObject();
                    raw.type = "text/text";
                    raw.provider = provider;
                    raw.doDate = doDate;
                    raw.data.put("text",
                            FileUtils.readFileToString(fileBiblio, "UTF-8"));
                    raw.save();
                    pe.addNum().debug(
                            log,
                            10000L,
                            (new StringBuilder()).append("save: '")
                                    .append(path).append("'").toString());
                }
            }

        }
        return this;
    }

    static Log log = LogFactory.getLog(TipoImporterSource.class);
    static DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
    private static Class rawclazz = PatentRawTIPO.class;
    private static Pto pto;
    public static final String opt_tipo_path = "tipo.path";
    public static final String opt_tipo_path_default = "\\\\10.153.27.120\\tw_xml\\TIPO \u8CC7\u6599\\\u516C\u544A_00000-37036\\iss";
    public static final String opt_do_vol = "do.path";
    public static final String opt_do_vol_default = "";
    public static final String opt_tipo_status = "tipo.status";
    public static final String opt_tipo_status_default = "issued";
    public static final String opt_provider = "provider";
    public static final String opt_provider_default = "TIPO Purchase";
    public static final Class optDep[] = { MongoAuthInitUtils.class };
    public static org.tsaikd.java.utils.ArgParser.Option opts[] = {
            new org.tsaikd.java.utils.ArgParser.Option(
                    null,
                    "tipo.path",
                    true,
                    "\\\\10.153.27.120\\tw_xml\\TIPO \u8CC7\u6599\\\u516C\u544A_00000-37036\\iss",
                    "TIPO raw data local path, like /mnt/kangaroo"),
            new org.tsaikd.java.utils.ArgParser.Option(null, "do.path", true,
                    "", "year of TIPO raw data, keep empty for tipo.path"),
            new org.tsaikd.java.utils.ArgParser.Option(null, "tipo.status",
                    true, "issued",
                    "issued or published, keep empty for tipo.path"),
            new org.tsaikd.java.utils.ArgParser.Option(null, "provider", true,
                    "TIPO Purchase", "Provider saved to DB") };
    private File tipopath;
    private ProcessEstimater pe;
    private static String provider;

    static {
        pto = Pto.TIPO;
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
        ConfigUtils.setSearchBase(TipoImporterSource.class);
    }
}
