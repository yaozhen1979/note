package com.patentcloud.validator;

public class PDfValidateException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -5151175186046625584L;


    public PDfValidateException(String string) {
        super(string);
    }

}
