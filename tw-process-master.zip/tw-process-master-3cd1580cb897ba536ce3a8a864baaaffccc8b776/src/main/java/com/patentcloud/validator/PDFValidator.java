package com.patentcloud.validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.pdfbox.pdfparser.PDFParser;

public class PDFValidator {
    private InputStream in = null;
    private PDFParser parser = null;
    
    PDFValidator() {
    
    }
    
    public PDFValidator(String filePath) {
        
        this.setParser(filePath);
        
    }
    
    public PDFValidator(File file) {
        
        this.setParser(file);
        
    }
    
    public void setParser(File file) {
        try {
            in = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        this.setParser(in);
    }
    
    public void setParser(InputStream in) {
        
        try {
            this.parser = new PDFParser(in);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    public void setParser(String filePath) {
        
        try {
            in = new FileInputStream(filePath);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        this.setParser(in);
        
    }
    
    public void validate() throws PDfValidateException, IOException {
        
        try {
            parser.parse();
        } catch (IOException e) {
            throw new PDfValidateException("PDF validation fail");
        } finally {
            this.closeAll();
        }
    }
    
    public void closeAll() {

        if (in != null) {
            try {
                in.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) {
        
        PDFValidator validator = new PDFValidator(
                "C:\\data\\temp\\patentsource\\TW\\TIPO_IMAGE_DOWNLOAD\\tw1\\2016\\02\\16\\201607227\\fullPage.pdf");
        try {
            validator.validate();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
