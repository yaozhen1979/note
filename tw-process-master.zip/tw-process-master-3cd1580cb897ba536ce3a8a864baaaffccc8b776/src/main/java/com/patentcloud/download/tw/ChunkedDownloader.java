package com.patentcloud.download.tw;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketException;
import java.net.URL;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.IOUtils;

public class ChunkedDownloader {
    private URL thisURL = null;
    private int fileSize = 0;
    private int chunkSize = 8192;
    private InputStream is = null;
    ByteArrayInputStream bais = null;
    HttpURLConnection connection = null;
    private int offset = 0;
    private Proxy proxy = new Proxy(Proxy.Type.HTTP,
            new InetSocketAddress("10.60.94.151", 808));
    //private Proxy proxy = new Proxy(Proxy.Type.HTTP,
   //         new InetSocketAddress("10.60.94.151", 808));
    private String imgUrl;
    private byte[] buffer;
    
    

    private static final int TCOUNT = 3;
    private CountDownLatch latch =  new CountDownLatch(TCOUNT);
    
    
    ChunkedDownloader(String imgUrl) throws Exception {
        this.imgUrl = imgUrl;
        
        
        
        
        try {
            thisURL = new URL(imgUrl);
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        connect(imgUrl, thisURL);
        fileSize = connection.getContentLength();
        chunkSize = Math.min(fileSize, 5 * 1048576);
        chunkSize = fileSize;
        
    }
    
    private void connect(String imgUrl, URL thisURL, String byteRange) throws SocketException,ConnectException, IOException{
        try {
            connection = (HttpURLConnection) thisURL.openConnection(proxy);
            connection.setRequestProperty("User-agent", "IE/6.0");
            connection.setReadTimeout(90000);// 設定timeout時間
            
            if (byteRange != null) {
                //System.out.println(byteRange);
                connection.setRequestProperty("Range", "bytes=" + byteRange);
            }
            is = connection.getInputStream();
            connection.connect();// 連線
            
            int status = ((HttpURLConnection) connection).getResponseCode();
            switch (status) {
                case java.net.HttpURLConnection.HTTP_GATEWAY_TIMEOUT:// 504
                    System.out.print("連線網址逾時!");
                    break;
                case java.net.HttpURLConnection.HTTP_FORBIDDEN:// 403
                    System.out.print("連線網址禁止!");
                    break;
                case java.net.HttpURLConnection.HTTP_INTERNAL_ERROR:// 500
                    System.out.print("連線網址錯誤或不存在!");
                    break;
                case java.net.HttpURLConnection.HTTP_NOT_FOUND:// 404
                    System.out.print("連線網址不存在!");
                    break;
                case java.net.HttpURLConnection.HTTP_OK:
                    // System.out.print("Connection:OK!");
                    break;
                case java.net.HttpURLConnection.HTTP_PARTIAL:
                    // System.out.print("Partial content response.")
                    break;
                // default:
                // System.out.print("Other connection failure: "+status);
                
            }
            
        } catch (ConnectException e){
            System.out.println("ConnectException");
            throw e;
        } catch (SocketException e){
            System.out.println("SocketException");
            throw e;
        }catch (IOException e) {
            // TODO Auto-generated catch block
            System.out.println("IOException");
            throw e;
        } 
        // System.out.println("Connect to " + imgUrl);
        
    }
    
    private void connect(String imgUrl, URL thisURL) throws SocketException,ConnectException, IOException{
        connect(imgUrl, thisURL, null);
        
    }
    
    public void download() throws IOException {
        
        int read = 0;
        int retry = 0;
        buffer = new byte[fileSize];
        
        //////////////////////
        
        //ExecutorService service = Executors.newFixedThreadPool(TCOUNT);
        
        //////////////////////
        
        
        do {
            int thisSize = Math.min(fileSize - offset, chunkSize);
            try {
                if (chunkSize == fileSize & offset == 0) {
                    //System.out.println("Download all.");
                    this.connect(imgUrl, thisURL);
                } else {
                    this.connect(imgUrl, thisURL, Integer.toString(offset) + "-"
                            + Integer.toString(offset + thisSize));
                }
                read = is.read(buffer, offset, thisSize);
                
                connection.disconnect();
                is.close();
            } catch (Exception e) {
                //e.printStackTrace();
                if (retry > 10) {
                    System.out.println(
                            "Been attempted 10 times for downloading:\n"
                                    + imgUrl);
                    System.out.println(
                            "/////////////////////////////////////////////Exit this process");
                    throw e;
                }
            }
            if (read != -1) {
                offset += read;
                retry = 0;
                //System.out.println(offset*100.0/fileSize+" %");
            } else {
                
                retry++;
            }
            
        } while (offset < fileSize);
        this.close();
        bais = new ByteArrayInputStream(buffer);
    }
    
    public void close() throws IOException {
        if (is != null) {
            is.close();
        }
        if (bais != null) {
            bais.close();
        }
        
    }
    
    public void save(String filePath) throws IOException {
        File fi = new File(filePath);
        this.save(fi);
    }
    
    public void save(File file) throws IOException {
        FileOutputStream fos = null;
        if (bais != null) {
            try {
                fos = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                IOUtils.copy(bais, fos);
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    fos.flush();
                    fos.close();
                }
                if (is != null) {
                    is.close();
                }
            }
        } else {
            System.out.println("No loaded data.");
        }
    }
    
    // public static void main(String[] args) {
    // ChunkedDownloader cd = new ChunkedDownloader(
    // "http://twpat2.tipo.gov.tw/tipotwousr/00074/pdf/gn-D173778.pdf");
    // try {
    // cd.download();
    // } catch (IOException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    // try {
    // cd.save("C:\\data\\temp.pdf");
    // } catch (IOException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    // }
}
