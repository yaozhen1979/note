package com.patentcloud.download.tw;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.cli.ParseException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.htmlparser.Node;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.AndFilter;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.filters.TagNameFilter;
import org.htmlparser.nodes.TagNode;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;
import org.tsaikd.java.utils.ArgParser;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.UnexpectedPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlCheckBoxInput;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlImageInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTextArea;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;
import com.patentcloud.validator.PDFValidator;
import com.patentcloud.validator.PDfValidateException;

public class TipoDownload {
    
    static Log log = LogFactory.getLog(TipoDownload.class);
    
    private final String TIPO_URL = "http://twpat4.tipo.gov.tw/tipotwoc/tipotwkm";
    private static boolean passFailOnePage = false;
    public static int amount = 0; // 下載數量計數
    private static ArrayList<String> lostPage = new ArrayList<String>();
    private RetryLimiter retryLimiter = new RetryLimiter(2);
    
    public static final String opt_target_path = "target.path";
    public static final String opt_target_path_default = "/mnt/patentsource/TW";
    
    public static final String opt_do_date = "do.date";
    public static final String opt_do_date_default = "20150101";
    
    public static final String opt_page = "page";
    public static final String opt_page_default = "0";
    
    public static final String opt_pni = "pni";
    public static final String opt_pni_default = "1";
    
    public static final String opt_type = "type"; // download pdf or claim
    public static final String opt_type_default = "PDF";
    
    private static String path;
    private static int page;
    private static String query;
    private static String pni;
    private static String type;
    private static int totalNum = 600000;
    private static int num = 0;
    private static ArrayList<String> failList_inALoop = new ArrayList<String>();
//     private Proxy proxy = new Proxy(Proxy.Type.HTTP,
//     new InetSocketAddress("10.60.94.41", 3128));
    private Proxy proxy = new Proxy(Proxy.Type.HTTP,
            new InetSocketAddress("10.60.94.151", 808));
    public static ArgParser.Option[] opts = {
            new ArgParser.Option(null, opt_target_path, true,
                    opt_target_path_default, ""),
            new ArgParser.Option(null, opt_do_date, true, opt_do_date_default,
                    ""),
            new ArgParser.Option(null, opt_page, true, opt_page_default, ""),
            new ArgParser.Option(null, opt_pni, true, opt_pni_default, ""),
            new ArgParser.Option(null, opt_type, true, opt_type_default, ""), };
            
    public String getSearchlUrl(String body) {
        Parser parser = Parser.createParser(body, "utf-8");
        String href = "";
        NodeList list = null;
        try {
            list = parser.extractAllNodesThatMatch(new TagNameFilter("a"));
        } catch (ParserException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            Node node = list.elementAt(i);
            if (node.toString().indexOf("進階檢索") >= 0) {
                href = ((TagNode) node).getAttribute("href");
                break;
            }
        }
        return href;
    }
    
    private WebClient webClient;
    
    private String imgUrl;
    
    private String PDFFileURL;
    
    private static int timeoutlimit = 9000;
    
    public WebClient getWebClient() {
        if (webClient == null) {
            webClient = new WebClient();
            // webClient.getOptions().getProxyConfig().setProxyHost("10.60.94.41");
            // webClient.getOptions().getProxyConfig().setProxyPort(3128);
            webClient.getOptions().getProxyConfig()
                    .setProxyHost("10.60.94.151");
            webClient.getOptions().getProxyConfig().setProxyPort(808);
            webClient.getOptions().setJavaScriptEnabled(false);
            webClient.getOptions().setCssEnabled(false);
            // webClient.getOptions()
            // .setHomePage("http://twpat4.tipo.gov.tw/tipotwoc/");
            webClient.getOptions().setTimeout(timeoutlimit);
            
        }
        return webClient;
    }
    
    int getPatentTotalNum(String sHtml) {
        String numberStr = "";
        int begin = 0;
        int end = 0;
        if (sHtml.contains("\u8A73\u7D30\u8CC7\u6599\u5167\u5BB9")) {
            numberStr = "1";
        } else if (sHtml.contains("\u6AA2\u7D22\u7D50\u679C")) {
            begin = sHtml.indexOf("</b> \u5171<font style") + 30;
            end = sHtml.indexOf("</font>\u7B46", begin);
            numberStr = sHtml.substring(begin, end);
        }
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(numberStr);
        if ("".equals(numberStr) || !isNum.matches()) {
            return 0;
        } else {
            return Integer.parseInt(numberStr);
        }
    }
    
    public HtmlPage getNextPage(HtmlPage sourcepage) throws IOException {
        HtmlImageInput nextButton = sourcepage.getElementByName("_IMG_次頁");
        HtmlPage nextPage = null;
        try {
            nextPage = (HtmlPage) nextButton.click();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException();
        }
        return nextPage;
    }
    
    public HtmlPage getCertainPage(HtmlPage sourcepage, int page)
            throws IOException {
        System.out.println("Turn to page: " + page);
        HtmlForm form = (HtmlForm) sourcepage.getElementByName("KM");
        HtmlTextInput input = form.getInputByName("JPAGE");
        input.setValueAttribute(String.valueOf(page));
        HtmlImageInput nextButton = sourcepage.getElementByName("_IMG_顯示結果");
        HtmlPage nextPage = null;
        try {
            nextPage = (HtmlPage) nextButton.click();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException();
        }
        return nextPage;
    }
    
    public HtmlPage getSearchPage(String date, String pni) throws Exception {
        // the page of "Advanced searching in TTPO"
        HtmlPage resultPage = null;
        String query = "ID=" + date + ":" + date;// Only one day?
        HtmlPage mainPage = null;
        String mainPageContent = null;
        String searchUrl = null;
        try {
            mainPage = getWebClient().getPage(TIPO_URL);
            mainPageContent = mainPage.getWebResponse().getContentAsString();
            searchUrl = getSearchlUrl(mainPageContent);
        } catch (Exception e1) {
            throw e1;
        }
        
        HtmlPage searchPage = null;
        try {
            searchPage = getWebClient().getPage(searchUrl);
        } catch (Exception e1) {
            throw e1;
        }
        HtmlCheckBoxInput checkboxp = searchPage.getElementByName("_3_3_S_AA");// pub
        // checkbox
        HtmlCheckBoxInput checkboxi = searchPage.getElementByName("_3_3_S_AG");// issue
        // checkbox
        HtmlTextArea testArea = searchPage.getElementByName("_3_1_X");
        if (pni.equals("1")) {
            checkboxp.setChecked(true);
            checkboxi.setChecked(false);
        } else {
            checkboxp.setChecked(false);
            checkboxi.setChecked(true);
        }
        testArea.setText(query);
        HtmlImageInput searchButton = searchPage.getElementByName("_IMG_檢索@s");
        
        try {
            resultPage = (HtmlPage) searchButton.click();
        } catch (Exception e1) {
            throw e1;
        }
        
        return resultPage;
    }
    
    public int downloadClaim(HtmlPage sourcePage, String path)
            throws Exception {
        String clm = "";
        String desc = "";
        String resultPage = sourcePage.getWebResponse().getContentAsString();
        totalNum = this.getPatentTotalNum(resultPage);
        Matcher mat = Pattern.compile(
                "<td class=sumtd2_PN>.*?<a href=(.*?) title='.*?' class=link02 target=_self>(.*?)</a>",
                Pattern.DOTALL).matcher(resultPage);
        while (mat.find()) {
            String patentUrl = mat.group(1);
            // System.out.println(patentUrl);
            String patNum = mat.group(2).trim();
            
            HtmlPage patentPage = null;
            try {
                patentPage = getWebClient().getPage(patentUrl);
            } catch (SocketTimeoutException e) {
                // e.printStackTrace();
                throw e;
            } catch (FailingHttpStatusCodeException | IOException e) {
                // e.printStackTrace();
                throw e;
            }
            String patentPageContent = patentPage.getWebResponse()
                    .getContentAsString();
                    
            Matcher descMat = Pattern.compile(
                    "<td class=mt1><a href='(.*?)'.*?<img src=/tipotwo/img/pic_tabdesc0\\.gif.*?</a>",
                    Pattern.DOTALL).matcher(patentPageContent);// 取得desc資料頁面
            Matcher clmMat = Pattern.compile(
                    ".*<td class=mt1><a href='(.*?)'.*?<img src=/tipotwo/img/pic_tabclaim0\\.gif.*?</a>",
                    Pattern.DOTALL).matcher(patentPageContent);// 取得clm資料頁面
            if (!patNum.contains("D")) {
                if (clmMat.find()) {
                    String clmUrl = clmMat.group(1);
                    HtmlPage descPage = null;
                    try {
                        descPage = getWebClient().getPage(clmUrl);
                    } catch (SocketTimeoutException e) {
                        e.printStackTrace();
                        throw e;
                    } catch (FailingHttpStatusCodeException | IOException e) {
                        e.printStackTrace();
                    }
                    String descPageContent = descPage.getWebResponse()
                            .getContentAsString();
                    Matcher clmMat1 = Pattern.compile(
                            "<td class=rectd1>專利範圍<td class=rectd2>(.*?)(</table>|<tr)",
                            Pattern.DOTALL).matcher(descPageContent);
                    if (clmMat1.find()) {
                        clm = clmMat1.group(1);
                    }
                }
            }
            if (descMat.find()) {
                String descUrl = descMat.group(1);
                HtmlPage descPage = null;
                try {
                    descPage = getWebClient().getPage(descUrl);
                } catch (FailingHttpStatusCodeException | IOException e) {
                    e.printStackTrace();
                }
                String descPageContent = descPage.getWebResponse()
                        .getContentAsString();
                Matcher descMat1 = Pattern.compile(
                        "<td class=rectd1>詳細說明<td class=rectd2>(.*?)(</table>|<tr)",
                        Pattern.DOTALL).matcher(descPageContent);
                if (descMat1.find()) {
                    desc = descMat1.group(1);
                }
            }
            if (clm.length() > 0 && desc.length() > 0) {
                clm = "<patentClaim>" + clm + "</patentClaim>";
                desc = "<patentDescription>" + desc + "</patentDescription>";
            } else if (clm.length() < 1 && desc.length() > 0) {
                clm = "";
                desc = "<patentDescription>" + desc + "</patentDescription>";
            } else if (desc.length() < 1 && clm.length() > 0) {
                clm = "<patentClaim>" + clm + "</patentClaim>";
                desc = "";
            } else {
                clm = "";
                desc = "";
            }
            if (this.writeClaimToTxt(path, patNum, clm, desc)) {
                amount++;
                System.out.println(
                        num + "/" + totalNum + " Claim download:" + patNum);
                num = num + 1;
                while (amount >= totalNum) {
                    break;
                }
            }
        }
        return totalNum;
    }
    
    public int downloadPDF(HtmlPage sourcePage, String path) throws Exception {
        boolean repeatLoop = false;
        String resultPage = sourcePage.getWebResponse().getContentAsString();
        totalNum = this.getPatentTotalNum(resultPage);
        Matcher mat = Pattern.compile(
                "<td class=sumtd2_PN>.*?<a href=(.*?) title='.*?' class=link02 target=_self>(.*?)</a>",
                Pattern.DOTALL).matcher(resultPage);
                
        // 解析出該搜尋結果頁面內的資訊，知道每篇專利的連結、還有對應要下載的檔案位置。
        LinkedHashMap<String, String> patentDetailLinkMap = new LinkedHashMap<String, String>();
        LinkedHashMap<String, String> fileLocationMap = new LinkedHashMap<String, String>();
        while (mat.find()) {
            String patentUrl = mat.group(1);
            String patNum = mat.group(2).trim();
            String filePath = path + File.separator + "tw" + pni
                    + File.separator + query.substring(0, 4) + File.separator
                    + query.substring(4, 6) + File.separator
                    + query.substring(6) + File.separator + patNum
                    + File.separator + "fullPage.pdf";
            patentDetailLinkMap.put(patNum, patentUrl);
            fileLocationMap.put(patNum, filePath);
            
        }
        
        // 若已經有已下載的檔案的話，先驗證。若沒過，patNum加入待做的工作列表。
        // 若沒有已下載的當案，patNum加入待做的工作列表
        ArrayList<String> toDownloadList = new ArrayList<String>();
        for (Map.Entry<String, String> entry : fileLocationMap.entrySet()) {
            String patNum = entry.getKey();
            String filePath = entry.getValue();
            File fi = new File(filePath);
            if (fi.exists()) {
                PDFValidator validator = null;
                try {
                    validator = new PDFValidator(fi);
                    validator.validate();
                    num += 1;
                } catch (PDfValidateException e1) {
                    toDownloadList.add(patNum);
                } finally {
                    validator.closeAll();
                }
            } else {
                toDownloadList.add(patNum);
            }
        }
        
        // 逐一進入取得連結後下載
        for (String patNum : toDownloadList) {
            File fi = new File(fileLocationMap.get(patNum));
            String singlePatentLink = patentDetailLinkMap.get(patNum);
            new File(fi.getParent()).mkdirs(); // 創建上級目錄
            
            RetryLimiter retryLimiter = new RetryLimiter(2);
            retryLimiter.prepareLog("Can not get " + patNum + "\n");
            
            while (retryLimiter.status()) {
                retryLimiter.tryOnce();
                try {
                    
                    String patentPageContent = getSinglePatentPage(
                            singlePatentLink);
                    // Find the PDF file URL, if we have the patentPageContent.
                    PDFFileURL = getPDFURL(singlePatentLink, patNum,
                            patentPageContent);
                    downloadNValidateImg(patNum, fi, imgUrl, PDFFileURL);
                    // System.out.println("下載後驗證成功");
                    retryLimiter.finish();
                } catch (ConnectException e1) {
                    // 連線有誤，退出重連
                    System.out.println("ConnectException Error\n");
                } catch (SocketTimeoutException e1) {
                    System.out.println("SocketTimeoutException Error\n");
                } catch (PDfValidateException e1) {
                    System.out.println("Downloaded PDF file is wrong\n");
                } catch (Exception e1) {
                    // 根本下載不了或下載後驗證失敗。
                    System.out.println("Other exception\n");
                }
            }
            if (retryLimiter.getLogString() != null) {
                repeatLoop = true;
                System.out.println(retryLimiter.getLogString());
                System.out.println("=======It will retry next loop=======\n\n");
                failList_inALoop.add("Fail to get " + patNum
                        + ", manipulate it by hand please.");
            } else {
                System.out.println("Progress:" + num + "/" + totalNum);
            }
            num += 1;
        }
        
        if (repeatLoop) {
            throw new Exception();
        }
        
        return totalNum;
        
    }
    
    /**
     * @param patentUrl
     * @param patentPageContent
     * @return
     * @throws SocketTimeoutException
     * @throws Exception
     */
    private String getSinglePatentPage(String patentUrl)
            throws SocketTimeoutException, Exception {
        HtmlPage patentPage = null;
        String patentPageContent = null;
        // 若沒辦法load專利列表頁了，跳出process()，從搜尋首頁再來一次。
        try {
            
            patentPage = getWebClient().getPage(patentUrl);
            // System.out.println("試著要看看這個詳細資料的網址內容");
            patentPageContent = patentPage.getWebResponse()
                    .getContentAsString();
            // System.out.println("要到了此網址的內容");
        } catch (SocketTimeoutException e) {
            // e.printStackTrace();
            System.out.println(
                    "SocketTimoutException when accessing single patent page:"
                            + patentUrl);
            throw e;
        } catch (FailingHttpStatusCodeException | IOException e) {
            // e.printStackTrace();
            System.out.println(
                    "FailingHttpStatusCodeException when accessing single patent page:"
                            + patentUrl);
            throw e;
        } catch (Exception e) {
            System.out.println(
                    "Other exception when accessing single patent page:"
                            + patentUrl);
            throw e;
        }
        return patentPageContent;
    }
    
    private String getPDFURL(String patentUrl, String patNum,
            String patentPageContent) throws Exception {
        String resultPage;
        HtmlPage patentPage;
        String PDFFileURLinProcess = null;
        Matcher imgMatch;
        if (patentPageContent != null) {
            // Different regex to find different URL of pdf file.
            if (pni.equals("2")) {
                imgMatch = Pattern.compile(
                        ".*<a href=\"javascript.*?(http:.*?)'.*?<img src=/tipotwo/img/pic_tabgn\\.gif.*?</a>",
                        Pattern.DOTALL).matcher(patentPageContent);
            } else {
                if (pni.equals("1")) {
                    imgMatch = Pattern.compile(
                            ".*<a href=\"javascript.*?(http:.*?)'.*?<img src=/tipotwo/img/pic_taban\\.gif.*?</a>",
                            Pattern.DOTALL).matcher(patentPageContent);
                } else {
                    imgMatch = null;
                    System.out.println("The pni is wrong.");
                }
            }
            
            // 有找到連結，才繼續連進去抓pdf檔連結
            if (imgMatch.find()) {
                // System.out.println("找到存放pdf檔URL的網頁網址了!");
                amount += 1;
                imgUrl = imgMatch.group(1);
                // loading single web page which hides pdf location.
                
                // System.out.println("連連看此存放pdf檔URL之網頁:" + imgUrl);
                
                try {
                    patentPage = getWebClient().getPage(imgUrl);
                    // System.out.println(imgUrl);
                    resultPage = patentPage.getWebResponse()
                            .getContentAsString();
                    PDFFileURLinProcess = this.getSpecificationUrl(resultPage,
                            patNum, Integer.parseInt(pni));
                    // System.out.println(PDFFileURLinProcess);
                    // System.out.println("成功要到了pdf檔URL!");
                } catch (SocketTimeoutException e) {
                    // e.printStackTrace();
                    
                    System.out.println("Timeout for loading page: " + imgUrl);
                    throw e;
                } catch (FailingHttpStatusCodeException | IOException e) {
                    // e.printStackTrace();
                    throw e;
                }
                
            } else {
                System.out.println(
                        "Can not get the PDF URL, can not load this page: "
                                + patentUrl);
                throw new Exception();
            }
        }
        return PDFFileURLinProcess;
    }
    
    private void downloadNValidateImg(String patNum, File fi, String imgUrl,
            String PDFFileURL) throws Exception, IOException {
            
        // downloading single pdf file.
        if (PDFFileURL != null) {
            // 嘗試兩次，不然就跳出。
            retryLimiter = new RetryLimiter(2);
            while (retryLimiter.status()) {
                retryLimiter.tryOnce();
                InputStream inputStream = null;
                FileOutputStream outputStream = null;
                BufferedInputStream bufferedInputStream = null;
                BufferedOutputStream bufferedOutputStream = null;
                
                try {
                    URL url = new URL(PDFFileURL);
                    HttpURLConnection thisConnection = (HttpURLConnection) url
                            .openConnection(proxy);
                    inputStream = thisConnection.getInputStream();
                    outputStream = new FileOutputStream(fi);
                    bufferedInputStream = new BufferedInputStream(inputStream);
                    bufferedOutputStream = new BufferedOutputStream(
                            outputStream);
                            
                    int i = 0;
                    byte[] buffer = new byte[512];
                    while (true) {
                        if (bufferedInputStream.available() < 512) {
                            while (i != -1) {
                                i = bufferedInputStream.read();
                                bufferedOutputStream.write(i);
                            }
                            break;
                        } else {
                            bufferedInputStream.read(buffer);
                            bufferedOutputStream.write(buffer);
                        }
                    }
                    retryLimiter.finish();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println(
                            "Can not download this file: " + PDFFileURL);
                    throw new Exception();
                } finally {
                    bufferedOutputStream.flush();
                    bufferedOutputStream.close();
                    bufferedInputStream.close();
                    outputStream.close();
                    inputStream.close();
                    
                }
            }
            
            PDFValidator validator = null;
            
            try {
                validator = new PDFValidator(fi);
                validator.validate();
                retryLimiter.finish();
                System.out.println("Download success: " + patNum);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                System.out.println("Downloaded File is wrong." + PDFFileURL);
                throw new Exception();
            } finally {
                validator.closeAll();
            }
        }
    }
    
    public int downloadClip(HtmlPage sourcePage, String path)
            throws ParserException, FailingHttpStatusCodeException,
            MalformedURLException, IOException {
        String resultPage = sourcePage.getWebResponse().getContentAsString();
        totalNum = this.getPatentTotalNum(resultPage);
        Matcher mat = Pattern.compile(
                "<td class=sumtd2_PN>.*?<a href=\"(.*?)\".*?class=link02 target=_self>(.*?)</a>",
                Pattern.DOTALL).matcher(resultPage);
                
        while (mat.find()) {
            String SpecificationUrl;
            
            HtmlPage patentPage = null;
            UnexpectedPage imagePDF = null;
            String patentUrl = mat.group(1);
            String patNum = mat.group(2).trim();
            String filePath = path + File.separator + "tw" + pni
                    + File.separator + query.substring(0, 4) + File.separator
                    + query.substring(4, 6) + File.separator
                    + query.substring(6) + File.separator + patNum
                    + File.separator + "firstImage.png";
            // Print a line to find file path.
            // System.out.println("//////////////////////////");
            // System.out.println(filePath);
            File fi = new File(filePath);
            if (!fi.exists()) {
                new File(fi.getParent()).mkdirs();// 创建上级目录
            }
            
            try {
                patentPage = getWebClient().getPage(patentUrl);
            } catch (FailingHttpStatusCodeException | IOException e) {
                e.printStackTrace();
            }
            String patentPageContent = patentPage.getWebResponse()
                    .getContentAsString();
            List<String> iUrl = this
                    .parserSearchResultPageForClip(patentPageContent);
            if (iUrl.size() > 0) {
                String href = iUrl.get(0).substring(0,
                        iUrl.get(0).indexOf("tipotwoc") - 1);
                for (int m = 1; m < iUrl.size() - 1; m++) {
                    SpecificationUrl = href + iUrl.get(m);
                    SpecificationUrl = SpecificationUrl.replaceAll("border=0",
                            "");
                    imagePDF = getWebClient().getPage(SpecificationUrl);
                    InputStream is = null;
                    int retry = 0;
                    while (retry < 10) {
                        try {
                            is = imagePDF.getWebResponse().getContentAsStream();
                            break;
                        } catch (Exception e1) {
                            retry++;
                            System.out.println("net error retry " + retry);
                        } finally {
                            if (retry == 10) {
                                throw new SocketTimeoutException();
                            }
                        }
                    }
                    
                    File file = new File(path + File.separator + "tw" + pni
                            + File.separator + query.substring(0, 4)
                            + File.separator + query.substring(4, 6)
                            + File.separator + query.substring(6)
                            + File.separator + patNum + File.separator + "clip"
                            + File.separator + m + ".png");
                    if (!file.exists()) {
                        new File(file.getParent()).mkdirs();// 创建上级目录
                    }
                    if (m == 1) {
                        File firstFile = new File(path + File.separator + "tw"
                                + pni + File.separator + query.substring(0, 4)
                                + File.separator + query.substring(4, 6)
                                + File.separator + query.substring(6)
                                + File.separator + patNum + File.separator
                                + "firstImage.png");
                        if (!firstFile.exists()) {
                            new File(firstFile.getParent()).mkdirs();// 创建上级目录
                        }
                        
                        FileOutputStream fos = null;
                        try {
                            fos = new FileOutputStream(firstFile);
                            
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        try {
                            IOUtils.copy(is, fos);
                            is = imagePDF.getWebResponse().getContentAsStream();
                            fos = new FileOutputStream(file);
                            IOUtils.copy(is, fos);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        System.out.println(
                                "download success: firstimage for " + patNum);
                    } else {
                        FileOutputStream fos1 = null;
                        
                        try {
                            fos1 = new FileOutputStream(file);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        try {
                            IOUtils.copy(is, fos1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                System.out.println(amount + "/" + totalNum
                        + " download success: " + patNum);
                amount++;
                num = num + 1;
            }
        }
        return amount;
    }
    
    private boolean writePathPdfForClip(ByteArrayOutputStream bOutPdf,
            String fileName, int index) {
        File file = new File(path + fileName + File.separator + "clip"
                + File.separator + index + ".png");
        boolean flag = false;
        if (index == 1) {
            File firstFile = new File(
                    path + fileName + File.separator + "firstImage.png");
            if (!firstFile.exists()) {
                new File(firstFile.getParent()).mkdirs();// 创建上级目录
            }
            java.io.FileOutputStream fos;
            try {
                fos = new java.io.FileOutputStream(firstFile);
                try {
                    fos.write(bOutPdf.toByteArray());
                    flag = true;
                } catch (IOException e) {
                    flag = false;
                    e.printStackTrace();
                }
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        if (!file.exists()) {
            new File(file.getParent()).mkdirs();// 创建上级目录
        }
        
        java.io.FileOutputStream fos;
        try {
            fos = new java.io.FileOutputStream(file);
            try {
                fos.write(bOutPdf.toByteArray());
                flag = true;
            } catch (IOException e) {
                flag = false;
                e.printStackTrace();
            }
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return flag;
    }
    
    private String getSpecificationUrl(String frameBody, String patentNumber,
            int PI) {
        String SpecificationUrl = "";
        NodeFilter tagFilter = new TagNameFilter("frame");
        Parser parser = Parser.createParser(frameBody, "UTF-8");
        NodeList list = null;
        try {
            list = parser.extractAllNodesThatMatch(tagFilter);
        } catch (ParserException e) {
            e.printStackTrace();
        }
        Node node = list.elementAt(0);
        String href = ((TagNode) node).getAttribute("src");
        href = href.substring(0, href.indexOf("tipotwoc/"));
        
        Node node2 = list.elementAt(1);
        String href2 = ((TagNode) node2).getAttribute("src");
        href2 = href2.substring(1, href2.indexOf("pdf/") + 4);
        int i = patentNumber.indexOf("&nbsp");
        if (i > 0) {
            patentNumber = patentNumber.substring(0, i);
        }
        
        if (PI == 1) {
            SpecificationUrl = href + href2 + "pn-" + patentNumber + ".pdf?";
        } else if (PI == 2) {
            SpecificationUrl = href + href2 + "gn-" + patentNumber + ".pdf?";
        }
        return SpecificationUrl;
    }
    
    private boolean writeClaimToTxt(String path, String pn, String claim,
            String description) {
        String file = null;
        boolean flag = false;
        file = path + File.separator + "tw" + pni + File.separator
                + query.substring(0, 4) + File.separator + query.substring(4, 6)
                + File.separator + query.substring(6) + File.separator + pn
                + ".txt";
        File fi = new File(file);
        if (!fi.exists()) {
            new File(fi.getParent()).mkdirs();// 创建上级目录
        }
        try {
            OutputStreamWriter write = new OutputStreamWriter(
                    new FileOutputStream(file), "UTF-8");
            BufferedWriter bw = new BufferedWriter(write);
            String patentNumber = "<patentNumber>" + pn + "</patentNumber>";
            bw.write(patentNumber);
            bw.newLine();
            bw.write(claim);
            bw.newLine();
            bw.write(description);
            bw.close();
            flag = true;
            write.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return flag;
    }
    
    private List<String> parserSearchResultPageForClip(String searchResultBody)
            throws ParserException {
        // 取得專利號
        List<String> paramete = new ArrayList<String>();
        Parser parser = Parser.createParser(searchResultBody, "utf-8");
        NodeFilter filter_constellation_summart = new AndFilter(
                (new TagNameFilter("tr")),
                (new HasAttributeFilter("class", "rectr")));
        NodeList nodeList = parser
                .extractAllNodesThatMatch(filter_constellation_summart);
        if (nodeList.size() > 0) {
            String sHtmlTemp = nodeList.elementAt(0).toHtml();
            String key = "";
            int begin = sHtmlTemp.indexOf("<tr class=rectr");
            int end = sHtmlTemp.indexOf("<tr class=rectr", begin + 15);
            String trHtml = "";
            if (end != -1) {
                trHtml = sHtmlTemp.substring(begin, end);
            } else {
                trHtml = sHtmlTemp.substring(begin);
            }
            if (!trHtml.equals("")) {
                int nameBegin = trHtml.indexOf("<td class=rectd1");
                int nameEnd = trHtml.indexOf(">", nameBegin);
                int namePost = trHtml.indexOf("</td>", nameEnd);
                key = trHtml.substring(nameEnd + 1, namePost);
                key = key.replaceAll("\n", "");
                key = key.replaceAll("<nobr>", "");
                key = key.replaceAll("</nobr>", "");
                key = key.replaceAll("</font>", "");
                key = key.replaceAll("<br>", "");
                if (key.contains("<font")) {
                    int fontBegin = key.indexOf("<font");
                    int fontEnd = key.indexOf(">", fontBegin + 5);
                    key = key.replaceAll(key.substring(fontBegin, fontEnd + 1),
                            "");
                }
            }
            // 取得影像檔地址
            String patentFullPageUrl = "";
            String clipImageUrl = "";
            
            if (key.trim().equals("公告號")) {
                String str = searchResultBody.substring(0,
                        searchResultBody.indexOf("pic_tabgn.gif"));// albert
                // 2010/03/17,
                int i = str.lastIndexOf("onclick=\"harder");
                int j = str.indexOf("pdf", i);
                str = str.substring(i, j);
                patentFullPageUrl = getMidString(str, ",'", "',").trim();
                paramete.add(patentFullPageUrl);
                int m4 = searchResultBody.indexOf("simple_img_red.gif");
                if (m4 != -1) {
                    String s = searchResultBody.substring(m4,
                            searchResultBody.length());
                    while (s.contains("tipotwousr")) {
                        int p = s.indexOf("tipotwousr") - 10;
                        int q = s.indexOf("width", p);
                        String temp = s.substring(p, q);
                        clipImageUrl = temp.replace("<img src=", "");
                        // clipImageUrl = getMidString(temp, "=", "").trim();
                        s = s.substring(s.indexOf("tipotwousr") + 10);
                        paramete.add(clipImageUrl.trim());
                    }
                }
            }
            
            else if (key.trim().equals("公開號")) // added by albert 2011/04/01
            // 處理公開專利變公告專利後的公開專利影像檔地址錯誤。
            {
                int m1 = searchResultBody.indexOf("pic_tabga.gif");
                int m2 = searchResultBody.indexOf("pic_tabga2.gif");
                int m3 = searchResultBody.indexOf("pic_tabgp.gif");
                int m = -1;
                String temp = "";
                if (m1 != -1) {
                    m = m1;
                } else if (m2 != -1) {
                    m = m2;
                }
                int n = searchResultBody.indexOf("pic_tabaa.gif");
                if (n != -1 && m != -1) {
                    temp = searchResultBody.substring(m, n);
                }
                if (temp.indexOf("onclick=\"harder") != -1) // has
                // bulletinImageAddr,
                {
                    int i = temp.indexOf("onclick=\"harder");
                    int j = temp.indexOf("pdf", i);
                    String str = temp.substring(i, j);
                    String bulletinImageAddr = getMidString(str, ",'", "',")
                            .trim();
                    paramete.add(bulletinImageAddr);
                }
                int m4 = searchResultBody.indexOf("simple_img_red.gif");
                if (m4 != -1) {
                    String s = searchResultBody.substring(m4,
                            searchResultBody.length());
                    while (s.contains("tipotwousr")) {
                        int p = s.indexOf("tipotwousr") - 10;
                        int q = s.indexOf("width", p);
                        temp = s.substring(p, q);
                        clipImageUrl = temp.replace("<img src=", "");
                        s = s.substring(s.indexOf("tipotwousr") + 10);
                        paramete.add(clipImageUrl.trim());
                    }
                }
            }
        }
        return paramete;
    }
    
    private static String getMidString(String sInput, String sStartTag,
            String sEndTag) {
        int i, j = -1;
        if ((i = sInput.indexOf(sStartTag)) < 0) {
            return null;
        } else {
            if ((j = sInput.indexOf(sEndTag, i + sStartTag.length())) < 0) {
                return null;
            } else {
                if (i + sStartTag.length() == j) {
                    return null;
                } else {
                    return sInput.substring(i + sStartTag.length(), j);
                }
            }
        }
    }
    
    public static void process() throws ParserException,
            FailingHttpStatusCodeException, MalformedURLException, IOException,
            SocketTimeoutException, Exception {
            
        TipoDownload download = new TipoDownload();
        HtmlPage sourcePage = null;
        HtmlPage nextPage;
        String html = null;
        try {
            sourcePage = download.getSearchPage(query, pni);
            html = sourcePage.getWebResponse().getContentAsString();
            totalNum = download.getPatentTotalNum(html);
        } catch (Exception e) {
            System.out.println("Can not get the first searching result page");
            throw e;
        }
        
        if (type.contains("PDF")) {
            System.out.println("Downloading:" + type);
            if (page < 1) {
                page = 1;// to fit the old applying style.
            }
            
            if (passFailOnePage) {
                passFailOnePage = false;
                page = page + 1;
            }
            int initialPageNum = page;
            int finalPageNum = (int) Math.ceil(totalNum / 10.0);
            System.out.println(
                    "page from " + initialPageNum + " to " + finalPageNum);
            for (int pageNow = initialPageNum; pageNow <= finalPageNum; pageNow++) {
                num = (pageNow - 1) * 10 + 1;
                page = pageNow;
                nextPage = download.getCertainPage(sourcePage, pageNow);
                try {
                    download.downloadPDF(nextPage, path);
                    page = page + 1;
                } catch (Exception e) {
                    // System.out.println("Repeating " + page + " or skip to
                    // next page");
                    throw e;
                }
                
            }
        } else if (type.contains("Claim")) {
            System.out.println("Downloading:" + type);
            if (page < 1) {
                page = 1;// to fit the old applying style.
            }
            int initialPageNum = page;
            int finalPageNum = (int) Math.ceil(totalNum / 10.0);
            System.out.println(
                    "page from " + initialPageNum + " to " + finalPageNum);
            for (int pageNow = initialPageNum; pageNow <= finalPageNum; pageNow++) {
                num = (pageNow - 1) * 10 + 1;
                page = pageNow;
                nextPage = download.getCertainPage(sourcePage, pageNow);
                download.downloadClaim(nextPage, path);
                
            }
        } else {
            System.out.println("Downloading:" + type);
            if (page < 1) {
                download.downloadPDF(sourcePage, path);
            }
            nextPage = download.getNextPage(sourcePage);
            // 跳頁
            for (int pos = 1; pos < page; pos++) {
                nextPage = download.getNextPage(nextPage);
                System.out.println("跳頁至：" + pos);
                amount = amount + 10;
            }
            for (int i = 0; i < totalNum; i += 10) {
                download.downloadPDF(sourcePage, path);
                nextPage = download.getNextPage(nextPage);
                page = page + 1;
            }
        }
    }
    
    public static void processTrigger() throws Exception {
        // 嘗試十次，之後跳出重新進入，並且跳到下個搜尋結果頁開始。
        while (num < totalNum) {
            RetryLimiter retryLimiterForDownloadingProcess = new RetryLimiter(
                    4);
            retryLimiterForDownloadingProcess.prepareLog(
                    "Retry loading first page  too much times. Skip to next result page");
            while (retryLimiterForDownloadingProcess.status()) {
                
                try {
                    retryLimiterForDownloadingProcess.tryOnce();
                    TipoDownload.process();
                    retryLimiterForDownloadingProcess.finish();
                    
                } catch (Exception e) {
                    
                    System.out.println(
                            "Try downlaod the links on this page again.");
                    timeoutlimit = timeoutlimit + 90000;
                    System.out.println("Reset timeout = " + timeoutlimit);
                    
                }
            }
            
            if (retryLimiterForDownloadingProcess.getLogString() != null) {
                System.out.println(
                        retryLimiterForDownloadingProcess.getLogString());
                passFailOnePage = true;
                timeoutlimit = 9000;
                
                // 把此結果頁，無法下載者，都print到螢幕上，句子為Fail to開頭
                for (String log : failList_inALoop) {
                    System.out.println(log);
                }
                failList_inALoop.clear();
                throw new Exception();
            } else {
                System.out.println();
            }
        }
    }
    
    public static void main(String args[])
            throws ParserException, MalformedURLException, IOException {
        ArgParser argParser = null;
        
        try {
            argParser = new ArgParser().addOpt(TipoDownload.class).parse(args);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        type = argParser.getOptString("type");
        path = argParser.getOptString("target.path");
        page = Integer.parseInt(argParser.getOptString("page"));// 跳頁
        query = argParser.getOptString("do.date");
        pni = argParser.getOptString("pni");
        RetryLimiter retryJumpResultPage = new RetryLimiter(3);
        retryJumpResultPage.prepareLog(
                "Even skip to some page, process can not countinue. Time to shup down.");
        while (retryJumpResultPage.status()) {
            retryJumpResultPage.tryOnce();
            try {
                processTrigger();
                retryJumpResultPage.finish();
            } catch (Exception e) {
                System.out.println("skip or shut down ");
                
            }
        }
        if (retryJumpResultPage.getLogString() != null) {
            System.out.println(retryJumpResultPage.getLogString());
        } else {
            System.out.println("Whole process finishes.");
        }
        
    }
}
