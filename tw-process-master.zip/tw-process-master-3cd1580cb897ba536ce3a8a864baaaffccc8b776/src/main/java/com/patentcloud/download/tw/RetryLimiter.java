package com.patentcloud.download.tw;

import java.util.List;

public class RetryLimiter {
    private int retryMaximum = 10;
    private int retryTime = 0;
    private List<String> storedList = null;
    private String logString = null;
    
    public String getLogString() {
        return logString;
    }

    RetryLimiter() {
    
    }
    
    RetryLimiter(int retryMaximum) {
        this.retryMaximum = retryMaximum;
    }
    
    public void tryOnce() {
        retryTime++;
    }
    
    public boolean status() {
        if (retryTime >= retryMaximum) {
            this.reset();
            if (this.storedList != null) {
                this.storedList.add(this.logString);
                this.logString = null;
            }
            return false;
        } else {
            return true;
        }
    }
    
    public void finish() {
        retryTime = retryMaximum;
        this.logString = null;
    }
    
    public void reset() {
        retryTime = 0;
    }
    
    public void prepareLog(List<String> storedList, String logString) {
        this.storedList = storedList;
        this.prepareLog(logString);
    }
    public void prepareLog( String logString) {
        this.logString = logString;
    }
}
