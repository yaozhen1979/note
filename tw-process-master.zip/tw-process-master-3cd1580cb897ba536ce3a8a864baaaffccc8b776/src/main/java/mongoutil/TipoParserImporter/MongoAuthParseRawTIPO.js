﻿// tag='v1.4.0';jsFile='MongoAuthParseRawTIPOReInventors.js
var tag = 'v1.4.9';
var jsFile = 'MongoAuthParseRawTIPO.js';

;
(function() {
	function updateField(doc, field, value) {
		if (value === undefined) {
			delete doc[field];
		} else {
			doc[field] = value;
		}
	}
	function normalizeIPC(doc, pc) {
		pc = pc.replace(/\(\d\d\d\d.\d\d\)/, "").trim()
				.replace(/<b><i>/, "").replace(/<\/i><\/b>/, "");
		// 有出現"(",")"的都判為err
		var mat = pc
				.match(/^(\w{4})[\s\-]*(\w+)[\/:]([^\s\(\)]+)([\s\.][\S+])?$/);
		if (mat) {
			if (mat[4]) {
				return mat[1] + " " + mat[2] + "/" + mat[3] + mat[4];
			} else {
				return mat[1] + " " + mat[2] + "/" + mat[3];
			}
		} else {
			// 早期有特定專利IPC只會出現前三階 ex. H01R
			mat = pc.match(/^\w{4}/);
			if (mat) {
				return mat[0];
			} else {
				logErrorDoc({
					db : dbsrc,
					col : "Error" + colsrc,
					msg : {
						msg : "invalid PC",
						pc : pc
					},
					doc : doc
				});
				return pc;
			}
		}
	}

	function normalizeLOC(doc, pc) {
		var mat = pc.trim().match(/([\d]+)([\-\s\/]*)([\d]*)/);
		if (mat) {
			if (mat[3]) {
				return mat[1] + "-" + mat[3];
			} else {
				return mat[1];
			}
		} else {
			logErrorDoc({
				db : dbsrc,
				col : "Error" + colsrc,
				msg : {
					msg : "invalid PC",
					pc : pc
				},
				doc : doc
			});
			return pc;
		}
	}
	// case太多，這段code沒辦法很完美的解析出台灣title/inventor的多語言問題，留存以做參考用
	function normalizeMultiLangStr(multilangStr) {
		multilangStr = multilangStr.trim();
		var mat = multilangStr.match(/([\w.,;:'"\s]*)$/);
		if (mat && mat[0].trim().length > 0) {
			return {
				origin : multilangStr.replace(mat[0], "").trim(),
				en : mat[0].trim()
			};
		} else {
			return {
				origin : multilangStr.trim(),
			};
		}
	}
	// 先用公開公告日區分
	function getDoDate(doc) {
		if (doc.stat == 1) {
			return doc.openDate;
		} else if (stat == 2) {
			return doc.decisionDate;
		}
	}
	// type 是用來組 KR 專利的專利號
	function normalizeCitedPatent(doc, citedPatent, type) {
		var kindcode;
		var pto;
		if (citedPatent.match(/\s/)) {
			kindcode = citedPatent.split(/\s/)[1];
			citedPatent = citedPatent.split(/\s/)[0];
		}
		mat = citedPatent.match(/^([a-zA-Z]*)(.*)/);
		if (typeof citedCountry[mat[1]] == "undefined") {
			logErrorDoc({
				db : dbsrc,
				col : "Error" + colsrc,
				msg : {
					msg : "undefined cited country",
					cited : mat[1]
				},
				doc : doc
			});
		} else {
			pto = mat[1];
			citedPatent = mat[2];
			if (pto == "USS" || pto == "USUS") {
				pto = "US";
			} else if (pto == "KP") {
				pto = "KR";
			} else if (pto == "TWTWI") {
				pto = "TWI";
			} else if (pto == "TWTW") {
				pto = "TW";
			} else if (pto == "TWTWM") {
				pto = "TWM";
			} else if (pto == "CNCN") {
				pto = "CN";
			} else if (pto == "EPEP") {
				pto = "EP";
			} else if (pto == "MXPA") {
				pto = "MX";
			} else if (pto == "JPP" || pto == "JPJP") {
				pto = "JP";
			} else if (pto == "JPDD") {
				pto = "JPD";
			} else if (pto == "WOWO") {
				pto = "WO";
			} else if (pto == "PCWO") {
				pto = "PCT";
				citedPatent = "WO" + mat[2];
			} else if (pto == "JPWO") {
				pto = "WO";
				citedPatent = "WO" + mat[2];
			} else if (pto == "TWCN") {
				
				
				pto = "TW";
				citedPatent = "CN" + mat[2];
			} else if (pto == "BRPI") {
				pto = "BR";
				citedPatent = "PI" + mat[2];
			}
			// 處理這種case JP11-103777A;US6387428B1
			mat = citedPatent.match(/([a-zA-Z]\d*)$/);
			if (!kindcode && mat) {
				kindcode = mat[1];
				citedPatent = citedPatent.replace(kindcode, "");
			}
			mat = pto.match(/^(CN)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(TM)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(EM)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(AU)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(KR)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(JP)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(TW)([a-zA-Z])/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			mat = pto.match(/^(US)([a-zA-Z]{1,2})/);
			if (mat) {
				pto = mat[1];
				citedPatent = mat[2] + citedPatent;
			}
			// 處理各國格式
			if (pto == "US") {
				// 引證 US 公開有可能會寫這樣 US2005/159138，實際格式應該為 20050159138
				if (citedPatent.match(/\//)) {
					tmp = citedPatent.split(/\//);
					year_code = tmp[0];
					serial_code = tmp[1]
					if (serial_code.length == 6) {
						serial_code = "0" + serial_code;
					}
					citedPatent = year_code + serial_code;
				}
				// 引證 US 公告專利號格式如 6477373
				else if (citedPatent.length == 7) {
					citedPatent = "US00" + citedPatent;
				}
				// I300809 這篇台灣專利的 US 公開引證為 2002068685 ，實際該為 20020068685
				else if (citedPatent.length == 10) {
					mat = citedPatent.match(/^(\d{4})(\d{6})/);
					if (mat) {
						citedPatent = mat[1] + "0" + mat[2];
					}
				}
			} else if (pto == "EP") {
				citedPatent = "EP" + citedPatent.trim();
			} else if (pto == "WO") {
				citedPatent = "WO " + citedPatent.trim();
			} else if (pto == "CN") {
				citedPatent = "CN" + citedPatent;
				// CN 官網的公告號後面會帶 kindcode
				if (kindcode == "B") {
					citedPatent = citedPatent + kindcode
				}
			}
			//
			else if (pto == "KR") {
				citedPatent = citedPatent.replace(/-/, "");
				if (type == "發明") {
					citedPatent = "10" + citedPatent;
				}
				// 目前沒有專利引證韓國 utility 專利
				else if (type == "設計") {
					citedPatent = "20" + citedPatent;
				}
			}
			if(typeof(kindcode)!="undefined"){
			return {
				pto : pto,
				patentNumber : citedPatent,
				kindcode : kindcode
			};
			}else{
				return {
					pto : pto,
					patentNumber : citedPatent
				};
			}
		}
	}

	function dateFormat(date) {
		mat = date.match(/(\d{4})\/?(\d{2})\/*(\d{2})/);
		if (!mat) {
			throw "date format err";
		}
		return todate(mat[1] + "-" + mat[2] + "-" + mat[3])
	}

	function searchPatentInfo(pat) {
		switch (pat.pto) {
		case "USPTO":
		case "US":
		case "TIPO":
		case "TW":
		case "JPO":
		case "JP":
			var dbsearch = mongodb.getDB("PatentInfo" + pat.pto);
			if (!pat.patentNumber) {
				return pat;
			} else {
				citedDoc = getPatentInfo(dbsearch, {
					pto : mapPtos[pat.pto],
					patentNumber : pat.patentNumber
				}) || pat;
				return citedDoc;
			}
		case "CNIPR":
		case "CN":
		case "KIPO":
		case "KR":
			var dbsearch = mongodb.getDB("PatentInfo" + pat.pto);
			if (!pat.patentNumber || !pat.stat) {
				return pat;
			} else {
				citedDoc = getPatentInfo(dbsearch, {
					pto : mapPtos[pat.pto],
					patentNumber : pat.patentNumber,
					stat : toint(2)
				}) || getPatentInfo(dbsearch, {
					pto : mapPtos[pat.pto],
					patentNumber : pat.patentNumber,
					stat : toint(1)
				}) || pat;
				return citedDoc;
			}
		case "EPO":
		case "EP":
		case "WIPO":
		case "WO":
			var dbsearch = mongodb.getDB("PatentInfo" + pat.pto);
			if (!pat.patentNumber || !pat.kindcode) {
				return pat;
			} else {
				try {
					citedDoc = getPatentInfo(dbsearch, {
						pto : mapPtos[pat.pto],
						patentNumber : pat.patentNumber,
						kindcode : pat.kindcode
					}) || pat;
					return citedDoc;
				} catch (e) {
					return pat;
				}
			}
		default:
			return pat;
			break;
		}
	}

	function normalizePriority(doc, priority) {
		if (!priority.match(/\s/)) {
			throw "priority err";
		}
		var tmp = priority.split(/\s/);
		// 德國優先權格式如下..
		// 德國 103 05 288.7 20030210
		// 優先權格式也有下面這種沒有給日期的
		// 美國 US1987104202
		if (tmp.length < 2) {
			throw "priority err";
		}
		if (!mapCountryNames[tmp[0].trim().replace(/\(/, "").replace(/\)/, "")
				.replace(/、/g, "")]) {
			logErrorDoc({
				db : dbsrc,
				col : "Error" + colsrc,
				msg : {
					msg : "priority country not match",
					pto : tmp[0].trim()
				},
				doc : doc
			});
			return {
				patentNumber : tmp[0].trim()
			}
		} else {
			pto = mapCountryNames[tmp[0].trim().replace(/\(/, "").replace(/\)/,
					"").replace(/、/g, "")];
			var patentNumber;
			var appDate;
			if (tmp.length > 2) {
				patentNumber = priority.replace(tmp[0], "").replace(
						tmp[tmp.length - 1], "").trim();
				appDate = dateFormat(tmp[tmp.length - 1].trim());
			} else if (tmp.length == 2) {
				patentNumber = tmp[1].replace(tmp[0], "");
			}
			if (pto == "US") {
				if (patentNumber.match(/,/)) {
					patentNumber = patentNumber.replace(/,/, "");
				}
			}
			return {
				pto : pto,
				patentNumber : patentNumber,
				appDate : appDate
			}
		}
	}

	var mapCountryNames = {
		日本 : "JP",
		美國 : "US",
		美國專利 : "US",
		USA : "US",
		韓國 : "KR",
		中國大陸 : "CN",
		南韓 : "KR",
		德國 : "DE",
		法國 : "FR",
		法國專利 : "FR",
		法國法蘭西 : "FR",
		德國德意志 : "DE",
		瑞士 : "CH",
		英國 : "GB",
		英國專利 : "GB",
		澳大利亞 : "AU",
		澳洲 : "AU",
		中華民國 : "TW",
		新加坡 : "SG",
		歐盟內部市場調和局 : "OHIM",
		OHIM : "OHIM",
		世界智慧財產權組織 : "WO",
		WIPO : "WO",
		WIPO國際局 : "WO",
		世界智慧財產權組織WO : "WO",
		國際WO : "WO",
		專利合作條約 : "PCT",
		專利合作條約PCT : "PCT",
		專利合作條約PCTPC : "PCT",
		合作條約 : "PCT",
		國際專利 : "PCT",
		PCT專利 : "PCT",
		PCT : "PCT",
		香港地區 : "KH",
		丹麥 : "DK",
		荷蘭 : "NL",
		EPC : "EPC",
		義大利 : "IT",
		瑞典 : "SE",
		奧地利 : "AT",
		捷克 : "CZ",
		波蘭 : "PL",
		荷蘭專利 : "PL",
		挪威 : "NO",
		加拿大 : "CA",
		馬來西亞 : "MY",
		芬蘭 : "FI",
		印度尼西亞 : "ID",
		紐西蘭 : "NZ",
		歐盟 : "EU",
		歐洲聯盟 : "EU",
		歐洲專利局 : "EP",
		歐洲 : "EP",
		歐洲專利機構 : "EP",
		歐洲專利 : "EP",
		歐洲專利公約EPCEO : "EP",
		歐洲專利公約EPC : "EP",
		EP : "EP",
		EPO : "EP",
		歐洲專利公約 : "EP",
		歐盟EP : "EP",
		歐洲EU : "EU",
		匈牙利 : "HU",
		克羅埃西亞 : "HR",
		印度 : "IN",
		以色列 : "IL",
		泰國 : "TH",
		保加利亞 : "BG",
		阿根廷 : "AR",
		菲律賓 : "PH",
		南非 : "ZA",
		西班牙 : "ES",
		西班牙專利 : "ES",
		愛爾蘭 : "IE",
		香港 : "KH",
		中國香港 : "KH",
		南非共和國 : "ZA",
		巴西 : "BR",
		北韓 : "KP",
		智利 : "CL",
		比利時 : "BE",
		土耳其 : "TM",
		俄羅斯聯邦 : "RU",
		盧森堡 : "LU",
		盧森堡專利 : "LU",
		埃及 : "EG",
		斯洛維尼亞 : "SI",
		古巴 : "CU",
		希臘 : "GR",
		澳地利 : "AT",
		越南 : "VN",
		墨西哥 : "MX",
		列支敦斯登 : "FL",
		秘魯 : "PE",
		拉脫維亞 : "LVA",
		牙買加 : "JM",
		斯洛伐克 : "CS",
		阿拉伯聯合大公國 : "SA",
		阿拉伯海灣合作理事會專利局 : "SA",
		沙烏地阿拉伯 : "SA",
		葡萄牙 : "PT",
		巴林 : "BH",
		塞爾維亞 : "RS",
		孟加拉 : "BD",
		巴基斯坦 : "PK",
		烏克蘭 : "UA",
		哥倫比亞 : "CO",
		委內瑞拉 : "VE",
		肯亞 : "KE",
		科威特 : "KW",
		烏拉圭 : "UY",
		荷比盧智慧財產局 : "BX",
		多米尼克 : "DM"
	};
	var mapPtos = {
		JP : "JPO",
		US : "USPTO",
		KR : "KIPO",
		CN : "CNIPR",
		DE : "DPMA",
		FR : "INPI",
		CH : "IGE",
		GB : "UJIPO",
		AU : "AU",
		TW : "TIPO",
		SG : "SG",
		OHIM : "OHIM",
		WO : "WIPO",
		KH : "KH"
	};
	// 已確認引證資料有的pto
	var citedCountry = {
		AT : 1, // 奧地利
		AU : 1, // 澳洲
		AUD : 1, // 澳洲
		BE : 1, // 比利時
		BG : 1, // 保加利亞
		BR : 1, // 波利維亞
		BRPI : 1,
		BX : 1, // 荷、比、盧智慧財產局
		CA : 1, // 加拿大
		CH : 1,
		DK : 1, // 丹麥
		CN : 1,
		CNCN : 1,
		CND : 1,
		// I438224 這篇專利疑似打錯的國別...先不校正
		CNI : 1,
		DE : 1,
		EA : 1, // 休達及美利拉
		EM : 1, // 內部市場協調局（OHIM）
		EMD : 1, // 內部市場協調局（OHIM）
		EO : 1, // 待查證
		EP : 1,
		EPEP : 1,
		ES : 1, // 埃立特里亞
		EU : 1, // 歐盟
		FI : 1, // 芬蘭
		FR : 1,
		GB : 1,
		GR : 1, // 希臘
		HK : 1, // 香港
		HU : 1, // 匈牙利
		IB : 1, // International Bureau of WIPO
		IE : 1, // 愛爾蘭
		IS : 1, // 冰島
		IT : 1, // 義大利
		JO : 1, // 約旦王國
		JP : 1,
		JPD : 1,
		JPDD : 1,
		JPG : 1,
		JPH : 1,
		JPJP : 1,
		JPP : 1,
		JPS : 1,
		JPU : 1,
		JPWO : 1,
		KRD : 1,
		KP : 1,
		KR : 1,
		LU : 1, // 盧森堡
		MX : 1, // 墨西哥
		MXPA : 1, // 墨西哥
		NO : 1, // 挪威
		NZ : 1, // 紐西蘭
		NL : 1, // 荷蘭
		PC : 1, // 需要確認..
		PCWO : 1, // PCWO，應該是PCT WO ...待驗證
		PL : 1, // 波蘭
		PT : 1, // 葡萄牙
		RO : 1, // 羅馬尼亞
		RU : 1, // 俄羅斯
		SA : 1, // 沙烏地阿拉伯王國
		SE : 1, // 瑞典
		SG : 1, // 新加坡
		SU : 1, // USSR 蘇聯
		SV : 1, // 薩爾瓦多
		TM : 1, // 土庫曼(中亞)
		TV : 1, // 圖瓦盧
		TW : 1,
		TWCN : 1,
		TWD : 1,
		TWDD : 1,
		TWI : 1,
		TWM : 1,
		TWTW : 1,
		TWTWI : 1,
		TWTWM : 1,
		UA : 1, // 烏克蘭
		UM : 1, // UNITED STATES MINOR OUTLYING ISLANDS 美屬邊疆群島
		US : 1,
		USD : 1,
		USd : 1,
		USDD : 1,
		USH : 1,
		USRE : 1,
		USS : 1,
		USUS : 1,
		UG : 1, // 烏干達
		UZ : 1, // 烏茲別克
		WF : 1, // 沃利斯和富圖納群島
		WO : 1,
		WOWO : 1,
		ZA : 1, // 南非
	};

	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/verifyPatentInfoFieldType.js");
	} catch (e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":",
				"[ERROR] Please run script in mongoutil directory");
		return;
	}

	var colsrc;
	var coltar;
	var dbsrc;
	var dbtar;
	var query;
	coltar = "PatentInfoTIPO";
	colsrc = "PatentRawTIPO";
	dbtar = new Mongo(mongo_tar_ip).getDB("admin");
	dbsrc = new Mongo(mongo_src_ip).getDB("admin");

	dbtar.auth(BASE64.decode(user), BASE64.decode(password));
	dbsrc.auth(BASE64.decode(user), BASE64.decode(password));

	dbtar = dbtar.getSisterDB(coltar);
	dbsrc = dbsrc.getSisterDB(colsrc);

	query = parse_q_for_doDate_and_provider();
	sleep(5000);
	initPatentCol({
		db : dbtar,
		col : coltar
	});
	printlog("counting total documents ...");
	initDebugProcess({
		maxCount : dbsrc[colsrc].find(query).count()
	});
	function parse_q_for_doDate_and_provider() {
		if (typeof (q) == "undefined") {
			throw "empty option 'q', like: 'ICMA,2005' or 'ICMA,2005' or 'ICMA,2005,2008'";
			return;
		} else {
			var qs = q.split(/[,]+/);
			if (qs.length < 2) {
				return {
					provider : qs[0]
				};
			} else if (qs.length < 3) {
				return {
					provider : qs[0],
					doDate : {
						$gte : todate(qs[1])
					}
				};
			} else {
				return {
					provider : qs[0],
					doDate : {
						$gte : todate(qs[1]),
						$lt : todate(qs[2])
					}
				};
			}
		}
	}

	printlog("starting parse");
	dbsrc[colsrc]
			.find(query)
			.sort({
				doDate : 1
			})
			.forEach(
					function(doc) {
						function log(msg) {
							logErrorDoc({
								db: dbsrc,
								col: "Error" + colsrc,
								msg: msg,
								doc: doc,
								console: true
							});
						}
						try {
							var ps = doc.path.split(/[\/]/);
							var path = doc.path;
							var provider = doc.provider;
							var vol = ps[ps.length - 2];
							var patentNumberPattern = "(" + vol
									+ ")([K]?)([MID]?.*)(\.txt)";
							var patentNumber = ps[ps.length - 1]
									.match(patentNumberPattern)[3];
							var mat;
							var biblio = doc.data.text;
							// patent stat
							var stat;
							if (provider == "TIPO Purchase" || path.match(/公告/)
									|| path.match(/Issue/)) {
								stat = toint(2);
							} else if (path.match(/公開/) || path.match(/Pub/)) {
								stat = toint(1);
							}
							if (!stat) {
								throw "stat err";
							}
							// 先判斷appNumber後面有沒有U01結尾
                            // 排除appNumber後面為D+兩碼數字結尾的情況，不更改此種情況的PatentNubmer
							mat = biblio.match(/(<申請號>)([\s\S]*)(<\/申請號>)/);
							if (!mat) {
								throw "no appNumber";
							}
							biblio = biblio.replace(mat[0], "");
							var appNumber = mat[2].trim();
							mat = appNumber.match(/([a-zA-CE-Z]\d*)$/);
							if (mat) {
								if (!patentNumber.match(mat[0])) {
									patentNumber = patentNumber + mat[0]
								}
							}
							var doc2 = getPatentInfo(dbtar, {
								pto : "TIPO",
								patentNumber : patentNumber,
								stat : toint(stat)
							}) || {
								pto : "TIPO",
								patentNumber : patentNumber,
								stat : toint(stat),
								mongoSyncFlag : {
									init : new Date(),
									basicInfo : new Date()
								}
							};
							// patent type ，早期無法分辨type，靠icma資料補
							var type;
							if (patentNumber.substring(0, 1) == "I"
									|| stat == 1) {
								type = "發明";
							} else if (patentNumber.substring(0, 1) == "M") {
								type = "新型";
							} else if (patentNumber.substring(0, 1) == "D") {
								type = "設計";
							}
							updateField(doc2, "type", type);
							if (stat == 2) {
								updateField(doc2, "decisionNumber",
										patentNumber);
							} else if (stat == 1) {
								updateField(doc2, "openNumber", patentNumber);
							} else {
								throw "stat err";
							}
							// patent title
							// 早期可能會有沒title的，要再透過icma xml校正
							// title無法用";"隔出英文摘要
							// 會有下面這種例子
							// 纖維素酯之各向異性組成物;該組成物之製法;纖維素酯或纖維素等之纖維
							mat = biblio.match(/(<專利名稱>)([\s\S]*)(<\/專利名稱>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								var titleAll = mat[2];
								var title;
								title = {
									origin : titleAll.trim()
								};
								updateField(doc2, "title", title);
							}
							// do date , decision date
							mat = biblio
									.match(/(<公告\/公開日>)([\s\S]*)(<\/公告\/公開日>)/);
							if (!mat) {
								throw "no decision date";
							}
							biblio = biblio.replace(mat[0], "");
							var doDate = dateFormat(mat[2].trim());
							if (stat == 2) {
								var decisionDate = doDate;
								updateField(doc2, "decisionDate",
										todate(decisionDate));
								updateField(doc2, "doDate",
										todate(decisionDate));
							} else if (stat == 1) {
								var openDate = doDate;
								updateField(doc2, "openDate", todate(openDate));
								updateField(doc2, "doDate", todate(openDate));
							} else {
								throw "stat err";
							}
							// appDate
							mat = biblio.match(/(<申請日>)([\s\S]*)(<\/申請日>)/);
							if (!mat) {
								throw "no appDate";
							}
							biblio = biblio.replace(mat[0], "");
							var appDate = dateFormat(mat[2].trim());
							updateField(doc2, "appDate", todate(appDate));
							updateField(doc2, "appNumber", appNumber);
							// 如果appnumber
							// certificateNumber , 證書號不一定會有
							mat = biblio.match(/(<證書號>)([\s\S]*)(<\/證書號>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								var certificateNumber = mat[2].trim();
								updateField(doc2, "certificateNumber",
										certificateNumber);
							}
							// ipc , ipcr ,
							// 如果僅有出現(2006.01)，則ipcr == ipc (這段規則要隨著新版釋出ipc
							// update)
							var mainIPC;
							var ipcs = [];
							var mainIPCR;
							var ipcrs = [];
							mat = biblio.match(/(<國際分類>)([\s\S]*)(<\/國際分類>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								var allpcStr = mat[2];
								allpcStr = allpcStr.replace(/<.*?>/g, "")
										.replace(/;;/g, ";").trim();
								// 如果全是由數字組成，判斷其為loc
								if (allpcStr.length == allpcStr.match(/[\d]+/)[0].length) {
									updateField(doc2, "mainLOC", mainLOC);
									updateField(doc2, "locs", locs);
								} else {
									// 處理ipc
									mat = allpcStr
											.match(/;?\(IPC\s+1\-7\)\s*:/);
									// 有ipcr , ipc
									if (mat) {
										var tmp = allpcStr.split(mat[0]);
										var allipcrStr = tmp[0];
										var allipcStr = tmp[1];
										// 處理ipcr
										if (!allipcrStr.match(/;/)) {
											ipcrs[0] = allipcrStr;
										} else {
											ipcrs = allipcrStr.split(/;/);
										}
										mainIPCR = ipcrs[0];
										// 處理ipc
										if (!allipcStr.match(/;/)) {
											ipcs[0] = allipcStr;
										} else {
											ipcs = allipcStr.split(/;/);
										}
										mainIPC = ipcs[0];
										// 僅有ipcr , 則ipcr = ipc
									} else {
										if (!allpcStr.match(/;/)) {
											ipcs[0] = allpcStr;
											ipcrs[0] = ipcs[0];
										} else {
											ipcs = allpcStr.split(/;/);
											ipcrs = ipcs;
										}
										mainIPCR = ipcrs[0];
										mainIPC = mainIPCR;
									}
									mainIPCR = normalizeIPC(doc, mainIPCR);
									for (i = 0; i < ipcrs.length; i++) {
										ipcrs[i] = normalizeIPC(doc, ipcrs[i]);
									}
									updateField(doc2, "mainIPCR", mainIPCR);
									updateField(doc2, "ipcrs", ipcrs);

									mainIPC = normalizeIPC(doc, mainIPC);
									for (i = 0; i < ipcs.length; i++) {
										ipcs[i] = normalizeIPC(doc, ipcs[i]);
									}
									updateField(doc2, "mainIPC", mainIPC);
									updateField(doc2, "ipcs", ipcs);
								}
								// loc
							} else {
								mat = biblio.match(/(<LOC>)([\s\S]*)(<\/LOC>)/)
										|| biblio
												.match(/(<物品類別>)([\s\S]*)(<\/物品類別>)/);
								var mainLOC;
								var locs = [];
								if (mat) {
									biblio = biblio.replace(mat[0], "");
									locs[0] = normalizeLOC(doc, mat[2]);
									mainLOC = locs[0];
									updateField(doc2, "mainLOC", mainLOC);
									updateField(doc2, "locs", locs);
								}
							}
							// 發明人
							// 早期台灣專利會沒有發明人...到甚麼時候確定會有還沒釐清
							var inventors = [];
							mat = biblio.match(/(<發明人>)([\s\S]*)(<\/發明人>)/)
									|| biblio
											.match(/(<發明人名>)([\s\S]*)(<\/發明人名>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								if (!mat[2].match(/;/)) {
									inventors[0] = {
										name : normalizeMultiLangStr(mat[2])
									};
								} else {
									var tmp = mat[2].split(/;/);
									for (i = 0; i < tmp.length; i++) {
										inventors[i] = {
											name : normalizeMultiLangStr(tmp[i])
										};
									}
								}
								updateField(doc2, "inventors", inventors);
							}
							// 申請人
							var assignees = [];
							mat = biblio.match(/(<申請人>)([\s\S]*)(<\/申請人>)/)
									|| biblio
											.match(/(<專利權人>)([\s\S]*)(<\/專利權人>)/)
									|| biblio
											.match(/(<專利權人名>)([\s\S]*)(<\/專利權人名>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								assigneesStr = mat[2];
								count = 0;
								while (true) {
									mat = assigneesStr
											.match(/<name>([\s\S]*?)<\/name>(\s*<addr>.*?<\/addr>)?/i);
									if (!mat) {
										break;
									}
									assigneesStr = assigneesStr.replace(mat[0],
											"");
									if (mat[2]) {
										assignees[count] = {
											name : {
												origin : mat[1].trim()
											},
											address : {
												origin : mat[2].trim()
											}
										};
									} else {
										assignees[count] = {
											name : {
												origin : mat[1].trim()
											}
										};
									}
									count++;
								}
								updateField(doc2, "assignees", assignees);
							}
							// 代理人
							var agents = [];
							mat = biblio.match(/(<代理人>)([\s\S]*)(<\/代理人>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								agentsStr = mat[2];
								count = 0;
								while (true) {
									mat = agentsStr
											.match(/<name>([\s\S]*?)<\/name>(\s*<addr>.*?<\/addr>)?/i);
									if (!mat) {
										break;
									}
									agentsStr = agentsStr.replace(mat[0]);
									if (mat[2]) {
										agents[count] = {
											name : {
												origin : mat[1].trim()
											},
											address : {
												origin : mat[2].trim()
											}
										};
									} else {
										agents[count] = {
											name : {
												origin : mat[1].trim()
											}
										};
									}
									count++;
								}
							}
							updateField(doc2, "agents", agents);
							// 引證資料
							// 要反查引證資料日期..未完成，他國引證還要確認號碼格式
							// 已下狀況視為其他引證
							// 1.如果用空白切超過4個
							// 2.長度超過20個字當作其他文件引證(用escape將非英文以及數字轉成16進為碼)
							// 3.沒有match三個以上的連續數字
							// 4.用"."結尾
							// 5.有":"
							// 6.連續的英文加空白超過5個
							// 7.包含ISBN
							// 8.包含ITRA (找不到ITRA含義...)
							// 9.包含USRFC (找不到含義)
							// 10.包含April (ex. April2001)
							// 11.全都只是數字
							// 12.包含"="
							// 13.空白開頭
							// 14.包含 &
							// 15 R1開頭
							// 16 包含。
							var citedPatents = [];
							var otherReferences = [];
							mat = biblio.match(/(<引證資料>)([\s\S]*)(<\/引證資料>)/)
							var citedPatents_count = 0;
							var otherReferences_count = 0;
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								if (mat[2].match(/;/)) {
									tmp = mat[2].split(/;/);
									for (i = 0; i < tmp.length; i++) {
										var tmp_ref = tmp[i].trim();
										if (tmp_ref.match(/=/)
												|| tmp_ref.match(/\d/)
												|| tmp_ref.match(/April/i)
												|| tmp_ref.match(/USRFC/i)
												|| tmp_ref.match(/ITRA/i)
												|| tmp_ref.match(/ISBN/i)
												|| tmp_ref
														.match(/[a-zA-Z\s]{5,}/)
												|| tmp_ref.match(/:/)
												|| tmp_ref.match(/\.$/)
												|| !tmp_ref.match(/\d{3,}/)
												|| escape(tmp_ref).length > 20
												|| (tmp_ref.match(/\s/) && tmp_ref
														.split(/\s/).length > 4)
												|| tmp_ref.match(/&/)
												|| tmp_ref.match(/^(R1)/)
												|| tmp_ref.match(/。/)) {
											otherReferences[otherReferences_count] = tmp_ref;
											otherReferences_count++;
										} else {
											citedPatents[citedPatents_count] = normalizeCitedPatent(
													doc, tmp_ref, type);
											citedPatents_count++;
										}
									}
								} else {
									tmp_ref = mat[2].trim();
									if (tmp_ref.match(/=/)
											|| !tmp_ref.match(/\D/)
											|| tmp_ref.match(/April/i)
											|| tmp_ref.match(/USRFC/i)
											|| tmp_ref.match(/ITRA/i)
											|| tmp_ref.match(/ISBN/i)
											|| tmp_ref.match(/[a-zA-Z\s]{5,}/)
											|| tmp_ref.match(/:/)
											|| tmp_ref.match(/\.$/)
											|| !tmp_ref.match(/\d{3,}/)
											|| escape(tmp_ref).length > 20
											|| (tmp_ref.match(/\s/) && tmp_ref
													.split(/\s/).length > 4)) {
										otherReferences[0] = tmp_ref;
									} else {
										citedPatents[0] = normalizeCitedPatent(
												doc, tmp_ref, type);
									}
								}
								if (citedPatents.length > 0) {
									updateField(doc2, "citedPatents",
											citedPatents);
								}
								if (otherReferences.length > 0) {
									updateField(doc2, "otherReferences",
											otherReferences);
								}
							}
							// 優先權還未顯示，暫不處理
							var priorityPatents = [];
							mat = biblio.match(/(<優先權>)([\s\S]*)(<\/優先權>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								if (mat[2].match(/;/)) {
									tmp = mat[2].split(/;/);
									if (tmp[0].trim().match(/\s/)) {
										for (i = 0; i < tmp.length; i++) {
											priorityPatents[i] = normalizePriority(
													doc, tmp[i].trim());
										}
										// 後期優先權格式為"美國;61/152,971;20090217"
									} else if (tmp.length % 3 == 0) {
										count = 0;
										for (i = 0; i < tmp.length; i = i + 3) {
											priorityPatents[count] = normalizePriority(
													doc, tmp[i].trim() + " "
															+ tmp[i + 1].trim()
															+ " "
															+ tmp[i + 2].trim());
											count++;
										}
									} else {
										throw "priority err";
									}
								} else {
									priorityPatents[0] = normalizePriority(doc,
											mat[2].trim());
								}
								updateField(doc2, "priorityPatents",
										priorityPatents);
							}
							// 摘要，要注意找岳岑說的奇怪字元例子
							mat = biblio.match(/(<摘要>)([\s\S]*)(<\/摘要>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								var brief = {
									origin : mat[2].trim()
								};
								updateField(doc2, "brief", brief);
							}
							// claim
							mat = biblio.match(/(<專利範圍>)([\s\S]*)(<\/專利範圍>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
								var claim = {
									origin : mat[2].trim()
								};
								updateField(doc2, "claim", claim);
							}
							mat = biblio.match(/(<公報卷期>)([\s\S]*)(<\/公報卷期>)/);
							if (mat) {
								biblio = biblio.replace(mat[0], "");
							}
							doc2.mongoSyncFlag.last = new Date();
							saveRelRawdatas(doc2, doc);
							saveTagAndJsfile(doc2);
							doc2.stat = toint(doc2.stat);
							if (verify(doc2)) {
								dbtar[coltar].save(doc2);
							}else{
								var msg = {
									msg: "type error",
								};
								log(msg);
							}
						} catch (e) {
							logErrorDoc({
								db : dbsrc,
								col : "Error" + colsrc,
								msg : e,
								doc : doc
							});
						}

						debugProcess(doc);
					});
})();
