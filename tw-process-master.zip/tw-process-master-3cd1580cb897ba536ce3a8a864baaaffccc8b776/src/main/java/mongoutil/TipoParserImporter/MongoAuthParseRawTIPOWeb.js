﻿;
(function() {
	function updateField(doc, field, value) {
		if (value === undefined) {
			delete doc[field];
		} else {
			doc[field] = value;
		}
	}

	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/verifyPatentInfoFieldType.js");
	} catch (e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":",
				"[ERROR] Please run script in mongoutil directory");
		return;
	}
	var colsrc;
	var coltar;
	var dbsrc;
	var dbtar;
	var query;
	coltar = "PatentInfoTIPO";
	colsrc = "PatentRawTIPO";
	dbtar = new Mongo(mongo_tar_ip).getDB("admin");
	dbsrc = new Mongo(mongo_src_ip).getDB("admin");
	dbtar.auth(BASE64.decode(user), BASE64.decode(password));
	dbsrc.auth(BASE64.decode(user), BASE64.decode(password));

	dbtar = dbtar.getSisterDB(coltar);
	dbsrc = dbsrc.getSisterDB(colsrc);
	query = parse_q_for_doDate_and_provider(/* queryDate */);
	function parse_q_for_doDate_and_provider(/* q */) {
		if (typeof (q) == "undefined") {
			throw "empty option 'q', like: 'ICMA,2005' or 'ICMA,2005' or 'ICMA,2005,2008'";
			return;
		} else {
			var qs = q.split(/[,]+/);
			if (qs.length < 2) {
				return {
					provider : qs[0]
				};
			} else if (qs.length < 3) {
				return {
					provider : qs[0],
					doDate : {
						$gte : todate(qs[1])
					}
				};
			} else {
				return {
					provider : qs[0],
					doDate : {
						$gte : todate(qs[1]),
						$lt : todate(qs[2])
					}
				};
			}
		}
	}
	printlog("parsing", colsrc, "to", coltar, "in 5 seconds",
			tojsonObject(query));
	sleep(5000);
	initPatentCol({
		db : dbtar,
		col : coltar
	});
	printlog("counting total documents ...");
	initDebugProcess({
		maxCount : dbsrc[colsrc].find(query).count()
	});
	printlog("starting parse");

	dbsrc[colsrc]
			.find(query)
			.sort({
				doDate : 1
			})
			.forEach(
					function(doc) {
						function log(msg) {
							logErrorDoc({
								db : dbsrc,
								col : "Error" + colsrc,
								msg : msg,
								doc : doc,
								console : true
							});
						}

						try {
							var mat;
							var pto = "TIPO";
							var biblio = doc.data.text;
							var provider = "TIPO WebDownload";
							var patentNumber;
							// patent number
							mat = biblio
									.match(/<patentNumber>([\s\S]*)<\/patentNumber>/);
							if (mat) {
								patentNumber = mat[1].trim();
							}
							if (typeof patentNumber != "undefined") {
								doc2 = getPatentInfo(dbtar, {
									pto : pto,
									patentNumber : patentNumber,
								})
							}
							;
							if (doc2 != null) {
								// add a flag to indicate the update of
								// claim&description
								updateField(doc2, "updateDate_ClDe", new Date());
								// claim
								mat = biblio
										.match(/(<patentClaim>)([\s\S]*)(<\/patentClaim>)/);
								if (mat) {
									var claim = {
										origin : mat[2].trim()
									};
									updateField(doc2, "claim", claim);
								}
								// description
								mat = biblio
										.match(/(<patentDescription>)([\s\S]*)(<\/patentDescription>)/);
								if (mat) {
									var description = {
										origin : mat[2].trim()
									};
									updateField(doc2, "description",
											description);
								}
								doc2.mongoSyncFlag.last = new Date();
								saveRelRawdatas(doc2, doc);
								saveTagAndJsfile(doc2);
								doc2.stat=toint(doc2.stat);
								if (verify(doc2)) {
									dbtar[coltar].save(doc2);
								} else {
									var msg = {
										msg : "type error",
									};
									log(msg);
								}
							} else {
								logErrorDoc({
									db : dbsrc,
									col : "Error" + colsrc,
									msg : {
										msg : "no patent",
									},
									doc : doc
								});
							}
						} catch (e) {
							logErrorDoc({
								db : dbsrc,
								col : "Error" + colsrc,
								msg : e,
								doc : doc
							});
						}
						debugProcess(doc);
					});
})();
;
