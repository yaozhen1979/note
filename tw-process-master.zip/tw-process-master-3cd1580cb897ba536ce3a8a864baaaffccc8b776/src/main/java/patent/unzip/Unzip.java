package patent.unzip;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.tsaikd.java.utils.ArgParser;

public class Unzip {
    
    static List<String> fileList = new ArrayList<String>();
    
    public static final String opt_zip_file_path = "zip.file.path";
    public static final String opt_zip_file_path_default = null;

    public static final String opt_unzip_tar_path = "unzip.tar.path";
    public static final String opt_unzip_tar_path_default = null;
    
    public static ArgParser.Option[] opts = {
        new ArgParser.Option(null, opt_zip_file_path, true, opt_zip_file_path_default, ""),
        new ArgParser.Option(null, opt_unzip_tar_path, true, opt_unzip_tar_path_default, ""),
    };
    
    public static List<String> getFileList(File dir) {
        
        File[] files = dir.listFiles();
        for (File f : files) {
            if (f.isDirectory()) {
                getFileList(f);
            } else {
                String path =f.getAbsolutePath();
                if(path.endsWith(".zip")){
                    fileList.add(path);
                }
            }
        }

        return fileList;
    }
    
    public void worker(String[] args) throws Exception{
        ArgParser argParser = new ArgParser().addOpt(Unzip.class).parse(args);
        String pathList=argParser.getOptString(opt_zip_file_path);
        String unzipTarPath=argParser.getOptString(opt_unzip_tar_path);
        
        String[] zipFilePathList= pathList.split(","); //多文件或者路徑用“，”分開
        
        for(String zipFilePath:zipFilePathList){
            System.out.println("Begin unzip ... ");
            File zipFile = new File(zipFilePath);
            if(zipFile.isFile()){
                ZipFileUtil.unzipFile(zipFile, unzipTarPath);
            }else{
                List<String> fileList= getFileList(zipFile);
                ZipFileUtil.unzipFileList(fileList, unzipTarPath);
            }
            System.out.println("Unzip finished");
        }
        
    }
    
    public static void main(String[] args) throws Exception {
        try{
            new Unzip().worker(args);
        } catch(Exception e){
            e.printStackTrace();
        }
    }

}
