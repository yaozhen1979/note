//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>claim-text complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="claim-text"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element ref="{}claim-text"/&gt;
 *         &lt;element ref="{}claim-ref"/&gt;
 *         &lt;element ref="{}b"/&gt;
 *         &lt;element ref="{}i"/&gt;
 *         &lt;element ref="{}u"/&gt;
 *         &lt;element ref="{}o"/&gt;
 *         &lt;element ref="{}sup"/&gt;
 *         &lt;element ref="{}sub"/&gt;
 *         &lt;element ref="{}smallcaps"/&gt;
 *         &lt;element ref="{}br"/&gt;
 *         &lt;element ref="{}pre"/&gt;
 *         &lt;element ref="{}crossref"/&gt;
 *         &lt;element ref="{}figref"/&gt;
 *         &lt;element ref="{}img"/&gt;
 *         &lt;element ref="{}chemistry"/&gt;
 *         &lt;element ref="{}maths"/&gt;
 *         &lt;element ref="{}tables"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "claim-text", propOrder = {
    "content"
})
public class ClaimText {

    @XmlElementRefs({
        @XmlElementRef(name = "sub", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "figref", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "pre", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "crossref", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "b", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "tables", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "claim-ref", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "u", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "sup", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "img", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "br", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "smallcaps", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "maths", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "claim-text", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "i", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "chemistry", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "o", type = JAXBElement.class, required = false)
    })
    @XmlMixed
    protected List<Serializable> content;

    /**
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link Sub }{@code >}
     * {@link JAXBElement }{@code <}{@link Figref }{@code >}
     * {@link JAXBElement }{@code <}{@link Pre }{@code >}
     * {@link JAXBElement }{@code <}{@link Crossref }{@code >}
     * {@link JAXBElement }{@code <}{@link B }{@code >}
     * {@link JAXBElement }{@code <}{@link Tables }{@code >}
     * {@link JAXBElement }{@code <}{@link ClaimRef }{@code >}
     * {@link JAXBElement }{@code <}{@link Sup }{@code >}
     * {@link JAXBElement }{@code <}{@link U }{@code >}
     * {@link JAXBElement }{@code <}{@link Img }{@code >}
     * {@link String }
     * {@link JAXBElement }{@code <}{@link Br }{@code >}
     * {@link JAXBElement }{@code <}{@link Smallcaps }{@code >}
     * {@link JAXBElement }{@code <}{@link I }{@code >}
     * {@link JAXBElement }{@code <}{@link ClaimText }{@code >}
     * {@link JAXBElement }{@code <}{@link Maths }{@code >}
     * {@link JAXBElement }{@code <}{@link O }{@code >}
     * {@link JAXBElement }{@code <}{@link Chemistry }{@code >}
     * 
     * 
     */
    public List<Serializable> getContent() {
        if (content == null) {
            content = new ArrayList<Serializable>();
        }
        return this.content;
    }

}
