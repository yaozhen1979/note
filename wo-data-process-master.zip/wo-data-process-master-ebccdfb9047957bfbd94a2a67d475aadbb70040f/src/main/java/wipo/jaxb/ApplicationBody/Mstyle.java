//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>mstyle complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="mstyle"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}mi"/&gt;
 *           &lt;element ref="{}mn"/&gt;
 *           &lt;element ref="{}mo"/&gt;
 *           &lt;element ref="{}mtext"/&gt;
 *           &lt;element ref="{}ms"/&gt;
 *           &lt;element ref="{}mspace"/&gt;
 *           &lt;element ref="{}mprescripts"/&gt;
 *           &lt;element ref="{}none"/&gt;
 *           &lt;element ref="{}mrow"/&gt;
 *           &lt;element ref="{}mfrac"/&gt;
 *           &lt;element ref="{}msqrt"/&gt;
 *           &lt;element ref="{}mroot"/&gt;
 *           &lt;element ref="{}menclose"/&gt;
 *           &lt;element ref="{}mstyle"/&gt;
 *           &lt;element ref="{}merror"/&gt;
 *           &lt;element ref="{}mpadded"/&gt;
 *           &lt;element ref="{}mphantom"/&gt;
 *           &lt;element ref="{}mfenced"/&gt;
 *           &lt;element ref="{}msub"/&gt;
 *           &lt;element ref="{}msup"/&gt;
 *           &lt;element ref="{}msubsup"/&gt;
 *           &lt;element ref="{}munder"/&gt;
 *           &lt;element ref="{}mover"/&gt;
 *           &lt;element ref="{}munderover"/&gt;
 *           &lt;element ref="{}mmultiscripts"/&gt;
 *           &lt;element ref="{}mtable"/&gt;
 *           &lt;element ref="{}mtr"/&gt;
 *           &lt;element ref="{}mlabeledtr"/&gt;
 *           &lt;element ref="{}mtd"/&gt;
 *           &lt;element ref="{}maligngroup"/&gt;
 *           &lt;element ref="{}malignmark"/&gt;
 *           &lt;element ref="{}maction"/&gt;
 *           &lt;element ref="{}ci"/&gt;
 *           &lt;element ref="{}csymbol"/&gt;
 *           &lt;element ref="{}cn"/&gt;
 *           &lt;element ref="{}integers"/&gt;
 *           &lt;element ref="{}reals"/&gt;
 *           &lt;element ref="{}rationals"/&gt;
 *           &lt;element ref="{}naturalnumbers"/&gt;
 *           &lt;element ref="{}complexes"/&gt;
 *           &lt;element ref="{}primes"/&gt;
 *           &lt;element ref="{}exponentiale"/&gt;
 *           &lt;element ref="{}imaginaryi"/&gt;
 *           &lt;element ref="{}notanumber"/&gt;
 *           &lt;element ref="{}true"/&gt;
 *           &lt;element ref="{}false"/&gt;
 *           &lt;element ref="{}emptyset"/&gt;
 *           &lt;element ref="{}pi"/&gt;
 *           &lt;element ref="{}eulergamma"/&gt;
 *           &lt;element ref="{}infinity"/&gt;
 *           &lt;element ref="{}apply"/&gt;
 *           &lt;element ref="{}fn"/&gt;
 *           &lt;element ref="{}lambda"/&gt;
 *           &lt;element ref="{}reln"/&gt;
 *           &lt;element ref="{}interval"/&gt;
 *           &lt;element ref="{}list"/&gt;
 *           &lt;element ref="{}matrix"/&gt;
 *           &lt;element ref="{}matrixrow"/&gt;
 *           &lt;element ref="{}set"/&gt;
 *           &lt;element ref="{}vector"/&gt;
 *           &lt;element ref="{}piecewise"/&gt;
 *           &lt;element ref="{}semantics"/&gt;
 *           &lt;element ref="{}declare"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute ref="{}xlinkherf"/&gt;
 *       &lt;attribute ref="{}xlinktype"/&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="fontsize" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="fontweight"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="bold"/&gt;
 *             &lt;enumeration value="normal"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fontstyle"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="italic"/&gt;
 *             &lt;enumeration value="normal"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fontfamily" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="color" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="mathvariant" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="mathsize" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="mathcolor" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="mathbackground" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="form"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="infix"/&gt;
 *             &lt;enumeration value="prefix"/&gt;
 *             &lt;enumeration value="postfix"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="fence"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="separator"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="lspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="rspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="stretchy"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="symmetric"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="maxsize" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="minsize" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="largeop"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="movablelimits"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="accent"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="lquote" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="rquote" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="linethickness" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="scriptlevel" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="scriptsizemultiplier" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="scriptminsize" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="background" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="veryverythinmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="verythinmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="thinmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="mediummathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="thickmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="verythickmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="veryverythickmathspace" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="open" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="close" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="separators" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="subscriptshift" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="superscriptshift" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="accentunder"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="rowalign" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="columnalign" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="columnwidth" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="groupalign" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="alignmentscope" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="side"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="left"/&gt;
 *             &lt;enumeration value="right"/&gt;
 *             &lt;enumeration value="leftoverlap"/&gt;
 *             &lt;enumeration value="rightoverlap"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="rowspacing" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="columnspacing" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="rowlines" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="columnlines" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="width" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="frame"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="none"/&gt;
 *             &lt;enumeration value="solid"/&gt;
 *             &lt;enumeration value="dashed"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="framespacing" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="equalrows" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="equalcolumns" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="displaystyle"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="true"/&gt;
 *             &lt;enumeration value="false"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="rowspan" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="columnspan" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="edge"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN"&gt;
 *             &lt;enumeration value="left"/&gt;
 *             &lt;enumeration value="right"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="actiontype" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="selection" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mstyle", propOrder = {
    "miOrMnOrMo"
})
public class Mstyle {

    @XmlElements({
        @XmlElement(name = "mi", type = Mi.class),
        @XmlElement(name = "mn", type = Mn.class),
        @XmlElement(name = "mo", type = Mo.class),
        @XmlElement(name = "mtext", type = Mtext.class),
        @XmlElement(name = "ms", type = Ms.class),
        @XmlElement(name = "mspace", type = Mspace.class),
        @XmlElement(name = "mprescripts", type = Mprescripts.class),
        @XmlElement(name = "none", type = None.class),
        @XmlElement(name = "mrow", type = Mrow.class),
        @XmlElement(name = "mfrac", type = Mfrac.class),
        @XmlElement(name = "msqrt", type = Msqrt.class),
        @XmlElement(name = "mroot", type = Mroot.class),
        @XmlElement(name = "menclose", type = Menclose.class),
        @XmlElement(name = "mstyle", type = Mstyle.class),
        @XmlElement(name = "merror", type = Merror.class),
        @XmlElement(name = "mpadded", type = Mpadded.class),
        @XmlElement(name = "mphantom", type = Mphantom.class),
        @XmlElement(name = "mfenced", type = Mfenced.class),
        @XmlElement(name = "msub", type = Msub.class),
        @XmlElement(name = "msup", type = Msup.class),
        @XmlElement(name = "msubsup", type = Msubsup.class),
        @XmlElement(name = "munder", type = Munder.class),
        @XmlElement(name = "mover", type = Mover.class),
        @XmlElement(name = "munderover", type = Munderover.class),
        @XmlElement(name = "mmultiscripts", type = Mmultiscripts.class),
        @XmlElement(name = "mtable", type = Mtable.class),
        @XmlElement(name = "mtr", type = Mtr.class),
        @XmlElement(name = "mlabeledtr", type = Mlabeledtr.class),
        @XmlElement(name = "mtd", type = Mtd.class),
        @XmlElement(name = "maligngroup", type = Maligngroup.class),
        @XmlElement(name = "malignmark", type = Malignmark.class),
        @XmlElement(name = "maction", type = Maction.class),
        @XmlElement(name = "ci", type = Ci.class),
        @XmlElement(name = "csymbol", type = Csymbol.class),
        @XmlElement(name = "cn", type = Cn.class),
        @XmlElement(name = "integers", type = Integers.class),
        @XmlElement(name = "reals", type = Reals.class),
        @XmlElement(name = "rationals", type = Rationals.class),
        @XmlElement(name = "naturalnumbers", type = Naturalnumbers.class),
        @XmlElement(name = "complexes", type = Complexes.class),
        @XmlElement(name = "primes", type = Primes.class),
        @XmlElement(name = "exponentiale", type = Exponentiale.class),
        @XmlElement(name = "imaginaryi", type = Imaginaryi.class),
        @XmlElement(name = "notanumber", type = Notanumber.class),
        @XmlElement(name = "true", type = True.class),
        @XmlElement(name = "false", type = False.class),
        @XmlElement(name = "emptyset", type = Emptyset.class),
        @XmlElement(name = "pi", type = Pi.class),
        @XmlElement(name = "eulergamma", type = Eulergamma.class),
        @XmlElement(name = "infinity", type = Infinity.class),
        @XmlElement(name = "apply", type = Apply.class),
        @XmlElement(name = "fn", type = Fn.class),
        @XmlElement(name = "lambda", type = Lambda.class),
        @XmlElement(name = "reln", type = Reln.class),
        @XmlElement(name = "interval", type = Interval.class),
        @XmlElement(name = "list", type = wipo.jaxb.ApplicationBody.List.class),
        @XmlElement(name = "matrix", type = Matrix.class),
        @XmlElement(name = "matrixrow", type = Matrixrow.class),
        @XmlElement(name = "set", type = Set.class),
        @XmlElement(name = "vector", type = Vector.class),
        @XmlElement(name = "piecewise", type = Piecewise.class),
        @XmlElement(name = "semantics", type = Semantics.class),
        @XmlElement(name = "declare", type = Declare.class)
    })
    protected java.util.List<Object> miOrMnOrMo;
    @XmlAttribute(name = "xlinkherf")
    protected String xlinkherf;
    @XmlAttribute(name = "xlinktype")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String xlinktype;
    @XmlAttribute(name = "class")
    @XmlSchemaType(name = "anySimpleType")
    protected String clazz;
    @XmlAttribute(name = "style")
    @XmlSchemaType(name = "anySimpleType")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    @XmlSchemaType(name = "anySimpleType")
    protected String other;
    @XmlAttribute(name = "fontsize")
    @XmlSchemaType(name = "anySimpleType")
    protected String fontsize;
    @XmlAttribute(name = "fontweight")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fontweight;
    @XmlAttribute(name = "fontstyle")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fontstyle;
    @XmlAttribute(name = "fontfamily")
    @XmlSchemaType(name = "anySimpleType")
    protected String fontfamily;
    @XmlAttribute(name = "color")
    @XmlSchemaType(name = "anySimpleType")
    protected String color;
    @XmlAttribute(name = "mathvariant")
    @XmlSchemaType(name = "anySimpleType")
    protected String mathvariant;
    @XmlAttribute(name = "mathsize")
    @XmlSchemaType(name = "anySimpleType")
    protected String mathsize;
    @XmlAttribute(name = "mathcolor")
    @XmlSchemaType(name = "anySimpleType")
    protected String mathcolor;
    @XmlAttribute(name = "mathbackground")
    @XmlSchemaType(name = "anySimpleType")
    protected String mathbackground;
    @XmlAttribute(name = "form")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String form;
    @XmlAttribute(name = "fence")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String fence;
    @XmlAttribute(name = "separator")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String separator;
    @XmlAttribute(name = "lspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String lspace;
    @XmlAttribute(name = "rspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String rspace;
    @XmlAttribute(name = "stretchy")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String stretchy;
    @XmlAttribute(name = "symmetric")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String symmetric;
    @XmlAttribute(name = "maxsize")
    @XmlSchemaType(name = "anySimpleType")
    protected String maxsize;
    @XmlAttribute(name = "minsize")
    @XmlSchemaType(name = "anySimpleType")
    protected String minsize;
    @XmlAttribute(name = "largeop")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String largeop;
    @XmlAttribute(name = "movablelimits")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String movablelimits;
    @XmlAttribute(name = "accent")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String accent;
    @XmlAttribute(name = "lquote")
    @XmlSchemaType(name = "anySimpleType")
    protected String lquote;
    @XmlAttribute(name = "rquote")
    @XmlSchemaType(name = "anySimpleType")
    protected String rquote;
    @XmlAttribute(name = "linethickness")
    @XmlSchemaType(name = "anySimpleType")
    protected String linethickness;
    @XmlAttribute(name = "scriptlevel")
    @XmlSchemaType(name = "anySimpleType")
    protected String scriptlevel;
    @XmlAttribute(name = "scriptsizemultiplier")
    @XmlSchemaType(name = "anySimpleType")
    protected String scriptsizemultiplier;
    @XmlAttribute(name = "scriptminsize")
    @XmlSchemaType(name = "anySimpleType")
    protected String scriptminsize;
    @XmlAttribute(name = "background")
    @XmlSchemaType(name = "anySimpleType")
    protected String background;
    @XmlAttribute(name = "veryverythinmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String veryverythinmathspace;
    @XmlAttribute(name = "verythinmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String verythinmathspace;
    @XmlAttribute(name = "thinmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String thinmathspace;
    @XmlAttribute(name = "mediummathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String mediummathspace;
    @XmlAttribute(name = "thickmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String thickmathspace;
    @XmlAttribute(name = "verythickmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String verythickmathspace;
    @XmlAttribute(name = "veryverythickmathspace")
    @XmlSchemaType(name = "anySimpleType")
    protected String veryverythickmathspace;
    @XmlAttribute(name = "open")
    @XmlSchemaType(name = "anySimpleType")
    protected String open;
    @XmlAttribute(name = "close")
    @XmlSchemaType(name = "anySimpleType")
    protected String close;
    @XmlAttribute(name = "separators")
    @XmlSchemaType(name = "anySimpleType")
    protected String separators;
    @XmlAttribute(name = "subscriptshift")
    @XmlSchemaType(name = "anySimpleType")
    protected String subscriptshift;
    @XmlAttribute(name = "superscriptshift")
    @XmlSchemaType(name = "anySimpleType")
    protected String superscriptshift;
    @XmlAttribute(name = "accentunder")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String accentunder;
    @XmlAttribute(name = "align")
    @XmlSchemaType(name = "anySimpleType")
    protected String align;
    @XmlAttribute(name = "rowalign")
    @XmlSchemaType(name = "anySimpleType")
    protected String rowalign;
    @XmlAttribute(name = "columnalign")
    @XmlSchemaType(name = "anySimpleType")
    protected String columnalign;
    @XmlAttribute(name = "columnwidth")
    @XmlSchemaType(name = "anySimpleType")
    protected String columnwidth;
    @XmlAttribute(name = "groupalign")
    @XmlSchemaType(name = "anySimpleType")
    protected String groupalign;
    @XmlAttribute(name = "alignmentscope")
    @XmlSchemaType(name = "anySimpleType")
    protected String alignmentscope;
    @XmlAttribute(name = "side")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String side;
    @XmlAttribute(name = "rowspacing")
    @XmlSchemaType(name = "anySimpleType")
    protected String rowspacing;
    @XmlAttribute(name = "columnspacing")
    @XmlSchemaType(name = "anySimpleType")
    protected String columnspacing;
    @XmlAttribute(name = "rowlines")
    @XmlSchemaType(name = "anySimpleType")
    protected String rowlines;
    @XmlAttribute(name = "columnlines")
    @XmlSchemaType(name = "anySimpleType")
    protected String columnlines;
    @XmlAttribute(name = "width")
    @XmlSchemaType(name = "anySimpleType")
    protected String width;
    @XmlAttribute(name = "frame")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String frame;
    @XmlAttribute(name = "framespacing")
    @XmlSchemaType(name = "anySimpleType")
    protected String framespacing;
    @XmlAttribute(name = "equalrows")
    @XmlSchemaType(name = "anySimpleType")
    protected String equalrows;
    @XmlAttribute(name = "equalcolumns")
    @XmlSchemaType(name = "anySimpleType")
    protected String equalcolumns;
    @XmlAttribute(name = "displaystyle")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String displaystyle;
    @XmlAttribute(name = "rowspan")
    @XmlSchemaType(name = "anySimpleType")
    protected String rowspan;
    @XmlAttribute(name = "columnspan")
    @XmlSchemaType(name = "anySimpleType")
    protected String columnspan;
    @XmlAttribute(name = "edge")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String edge;
    @XmlAttribute(name = "actiontype")
    @XmlSchemaType(name = "anySimpleType")
    protected String actiontype;
    @XmlAttribute(name = "selection")
    @XmlSchemaType(name = "anySimpleType")
    protected String selection;

    /**
     * Gets the value of the miOrMnOrMo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miOrMnOrMo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiOrMnOrMo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Mi }
     * {@link Mn }
     * {@link Mo }
     * {@link Mtext }
     * {@link Ms }
     * {@link Mspace }
     * {@link Mprescripts }
     * {@link None }
     * {@link Mrow }
     * {@link Mfrac }
     * {@link Msqrt }
     * {@link Mroot }
     * {@link Menclose }
     * {@link Mstyle }
     * {@link Merror }
     * {@link Mpadded }
     * {@link Mphantom }
     * {@link Mfenced }
     * {@link Msub }
     * {@link Msup }
     * {@link Msubsup }
     * {@link Munder }
     * {@link Mover }
     * {@link Munderover }
     * {@link Mmultiscripts }
     * {@link Mtable }
     * {@link Mtr }
     * {@link Mlabeledtr }
     * {@link Mtd }
     * {@link Maligngroup }
     * {@link Malignmark }
     * {@link Maction }
     * {@link Ci }
     * {@link Csymbol }
     * {@link Cn }
     * {@link Integers }
     * {@link Reals }
     * {@link Rationals }
     * {@link Naturalnumbers }
     * {@link Complexes }
     * {@link Primes }
     * {@link Exponentiale }
     * {@link Imaginaryi }
     * {@link Notanumber }
     * {@link True }
     * {@link False }
     * {@link Emptyset }
     * {@link Pi }
     * {@link Eulergamma }
     * {@link Infinity }
     * {@link Apply }
     * {@link Fn }
     * {@link Lambda }
     * {@link Reln }
     * {@link Interval }
     * {@link wipo.jaxb.ApplicationBody.List }
     * {@link Matrix }
     * {@link Matrixrow }
     * {@link Set }
     * {@link Vector }
     * {@link Piecewise }
     * {@link Semantics }
     * {@link Declare }
     * 
     * 
     */
    public java.util.List<Object> getMiOrMnOrMo() {
        if (miOrMnOrMo == null) {
            miOrMnOrMo = new ArrayList<Object>();
        }
        return this.miOrMnOrMo;
    }

    /**
     * 取得 xlinkherf 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinkherf() {
        return xlinkherf;
    }

    /**
     * 設定 xlinkherf 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinkherf(String value) {
        this.xlinkherf = value;
    }

    /**
     * 取得 xlinktype 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinktype() {
        return xlinktype;
    }

    /**
     * 設定 xlinktype 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinktype(String value) {
        this.xlinktype = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 fontsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontsize() {
        return fontsize;
    }

    /**
     * 設定 fontsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontsize(String value) {
        this.fontsize = value;
    }

    /**
     * 取得 fontweight 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontweight() {
        return fontweight;
    }

    /**
     * 設定 fontweight 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontweight(String value) {
        this.fontweight = value;
    }

    /**
     * 取得 fontstyle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontstyle() {
        return fontstyle;
    }

    /**
     * 設定 fontstyle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontstyle(String value) {
        this.fontstyle = value;
    }

    /**
     * 取得 fontfamily 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFontfamily() {
        return fontfamily;
    }

    /**
     * 設定 fontfamily 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFontfamily(String value) {
        this.fontfamily = value;
    }

    /**
     * 取得 color 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColor() {
        return color;
    }

    /**
     * 設定 color 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColor(String value) {
        this.color = value;
    }

    /**
     * 取得 mathvariant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathvariant() {
        return mathvariant;
    }

    /**
     * 設定 mathvariant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathvariant(String value) {
        this.mathvariant = value;
    }

    /**
     * 取得 mathsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathsize() {
        return mathsize;
    }

    /**
     * 設定 mathsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathsize(String value) {
        this.mathsize = value;
    }

    /**
     * 取得 mathcolor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathcolor() {
        return mathcolor;
    }

    /**
     * 設定 mathcolor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathcolor(String value) {
        this.mathcolor = value;
    }

    /**
     * 取得 mathbackground 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMathbackground() {
        return mathbackground;
    }

    /**
     * 設定 mathbackground 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMathbackground(String value) {
        this.mathbackground = value;
    }

    /**
     * 取得 form 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForm() {
        return form;
    }

    /**
     * 設定 form 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForm(String value) {
        this.form = value;
    }

    /**
     * 取得 fence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFence() {
        return fence;
    }

    /**
     * 設定 fence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFence(String value) {
        this.fence = value;
    }

    /**
     * 取得 separator 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeparator() {
        return separator;
    }

    /**
     * 設定 separator 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeparator(String value) {
        this.separator = value;
    }

    /**
     * 取得 lspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLspace() {
        return lspace;
    }

    /**
     * 設定 lspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLspace(String value) {
        this.lspace = value;
    }

    /**
     * 取得 rspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRspace() {
        return rspace;
    }

    /**
     * 設定 rspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRspace(String value) {
        this.rspace = value;
    }

    /**
     * 取得 stretchy 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStretchy() {
        return stretchy;
    }

    /**
     * 設定 stretchy 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStretchy(String value) {
        this.stretchy = value;
    }

    /**
     * 取得 symmetric 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymmetric() {
        return symmetric;
    }

    /**
     * 設定 symmetric 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymmetric(String value) {
        this.symmetric = value;
    }

    /**
     * 取得 maxsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxsize() {
        return maxsize;
    }

    /**
     * 設定 maxsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxsize(String value) {
        this.maxsize = value;
    }

    /**
     * 取得 minsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinsize() {
        return minsize;
    }

    /**
     * 設定 minsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinsize(String value) {
        this.minsize = value;
    }

    /**
     * 取得 largeop 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLargeop() {
        return largeop;
    }

    /**
     * 設定 largeop 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLargeop(String value) {
        this.largeop = value;
    }

    /**
     * 取得 movablelimits 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMovablelimits() {
        return movablelimits;
    }

    /**
     * 設定 movablelimits 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMovablelimits(String value) {
        this.movablelimits = value;
    }

    /**
     * 取得 accent 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccent() {
        return accent;
    }

    /**
     * 設定 accent 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccent(String value) {
        this.accent = value;
    }

    /**
     * 取得 lquote 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLquote() {
        return lquote;
    }

    /**
     * 設定 lquote 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLquote(String value) {
        this.lquote = value;
    }

    /**
     * 取得 rquote 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRquote() {
        return rquote;
    }

    /**
     * 設定 rquote 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRquote(String value) {
        this.rquote = value;
    }

    /**
     * 取得 linethickness 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinethickness() {
        return linethickness;
    }

    /**
     * 設定 linethickness 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinethickness(String value) {
        this.linethickness = value;
    }

    /**
     * 取得 scriptlevel 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptlevel() {
        return scriptlevel;
    }

    /**
     * 設定 scriptlevel 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptlevel(String value) {
        this.scriptlevel = value;
    }

    /**
     * 取得 scriptsizemultiplier 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptsizemultiplier() {
        return scriptsizemultiplier;
    }

    /**
     * 設定 scriptsizemultiplier 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptsizemultiplier(String value) {
        this.scriptsizemultiplier = value;
    }

    /**
     * 取得 scriptminsize 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScriptminsize() {
        return scriptminsize;
    }

    /**
     * 設定 scriptminsize 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScriptminsize(String value) {
        this.scriptminsize = value;
    }

    /**
     * 取得 background 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackground() {
        return background;
    }

    /**
     * 設定 background 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackground(String value) {
        this.background = value;
    }

    /**
     * 取得 veryverythinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVeryverythinmathspace() {
        return veryverythinmathspace;
    }

    /**
     * 設定 veryverythinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVeryverythinmathspace(String value) {
        this.veryverythinmathspace = value;
    }

    /**
     * 取得 verythinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerythinmathspace() {
        return verythinmathspace;
    }

    /**
     * 設定 verythinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerythinmathspace(String value) {
        this.verythinmathspace = value;
    }

    /**
     * 取得 thinmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThinmathspace() {
        return thinmathspace;
    }

    /**
     * 設定 thinmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThinmathspace(String value) {
        this.thinmathspace = value;
    }

    /**
     * 取得 mediummathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMediummathspace() {
        return mediummathspace;
    }

    /**
     * 設定 mediummathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMediummathspace(String value) {
        this.mediummathspace = value;
    }

    /**
     * 取得 thickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThickmathspace() {
        return thickmathspace;
    }

    /**
     * 設定 thickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThickmathspace(String value) {
        this.thickmathspace = value;
    }

    /**
     * 取得 verythickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerythickmathspace() {
        return verythickmathspace;
    }

    /**
     * 設定 verythickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerythickmathspace(String value) {
        this.verythickmathspace = value;
    }

    /**
     * 取得 veryverythickmathspace 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVeryverythickmathspace() {
        return veryverythickmathspace;
    }

    /**
     * 設定 veryverythickmathspace 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVeryverythickmathspace(String value) {
        this.veryverythickmathspace = value;
    }

    /**
     * 取得 open 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpen() {
        return open;
    }

    /**
     * 設定 open 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpen(String value) {
        this.open = value;
    }

    /**
     * 取得 close 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClose() {
        return close;
    }

    /**
     * 設定 close 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClose(String value) {
        this.close = value;
    }

    /**
     * 取得 separators 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeparators() {
        return separators;
    }

    /**
     * 設定 separators 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeparators(String value) {
        this.separators = value;
    }

    /**
     * 取得 subscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriptshift() {
        return subscriptshift;
    }

    /**
     * 設定 subscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriptshift(String value) {
        this.subscriptshift = value;
    }

    /**
     * 取得 superscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperscriptshift() {
        return superscriptshift;
    }

    /**
     * 設定 superscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperscriptshift(String value) {
        this.superscriptshift = value;
    }

    /**
     * 取得 accentunder 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccentunder() {
        return accentunder;
    }

    /**
     * 設定 accentunder 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccentunder(String value) {
        this.accentunder = value;
    }

    /**
     * 取得 align 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlign() {
        return align;
    }

    /**
     * 設定 align 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlign(String value) {
        this.align = value;
    }

    /**
     * 取得 rowalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowalign() {
        return rowalign;
    }

    /**
     * 設定 rowalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowalign(String value) {
        this.rowalign = value;
    }

    /**
     * 取得 columnalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnalign() {
        return columnalign;
    }

    /**
     * 設定 columnalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnalign(String value) {
        this.columnalign = value;
    }

    /**
     * 取得 columnwidth 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnwidth() {
        return columnwidth;
    }

    /**
     * 設定 columnwidth 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnwidth(String value) {
        this.columnwidth = value;
    }

    /**
     * 取得 groupalign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupalign() {
        return groupalign;
    }

    /**
     * 設定 groupalign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupalign(String value) {
        this.groupalign = value;
    }

    /**
     * 取得 alignmentscope 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlignmentscope() {
        return alignmentscope;
    }

    /**
     * 設定 alignmentscope 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlignmentscope(String value) {
        this.alignmentscope = value;
    }

    /**
     * 取得 side 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSide() {
        return side;
    }

    /**
     * 設定 side 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSide(String value) {
        this.side = value;
    }

    /**
     * 取得 rowspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowspacing() {
        return rowspacing;
    }

    /**
     * 設定 rowspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowspacing(String value) {
        this.rowspacing = value;
    }

    /**
     * 取得 columnspacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnspacing() {
        return columnspacing;
    }

    /**
     * 設定 columnspacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnspacing(String value) {
        this.columnspacing = value;
    }

    /**
     * 取得 rowlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowlines() {
        return rowlines;
    }

    /**
     * 設定 rowlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowlines(String value) {
        this.rowlines = value;
    }

    /**
     * 取得 columnlines 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnlines() {
        return columnlines;
    }

    /**
     * 設定 columnlines 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnlines(String value) {
        this.columnlines = value;
    }

    /**
     * 取得 width 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWidth() {
        return width;
    }

    /**
     * 設定 width 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWidth(String value) {
        this.width = value;
    }

    /**
     * 取得 frame 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrame() {
        return frame;
    }

    /**
     * 設定 frame 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrame(String value) {
        this.frame = value;
    }

    /**
     * 取得 framespacing 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFramespacing() {
        return framespacing;
    }

    /**
     * 設定 framespacing 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFramespacing(String value) {
        this.framespacing = value;
    }

    /**
     * 取得 equalrows 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualrows() {
        return equalrows;
    }

    /**
     * 設定 equalrows 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualrows(String value) {
        this.equalrows = value;
    }

    /**
     * 取得 equalcolumns 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqualcolumns() {
        return equalcolumns;
    }

    /**
     * 設定 equalcolumns 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqualcolumns(String value) {
        this.equalcolumns = value;
    }

    /**
     * 取得 displaystyle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplaystyle() {
        return displaystyle;
    }

    /**
     * 設定 displaystyle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplaystyle(String value) {
        this.displaystyle = value;
    }

    /**
     * 取得 rowspan 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowspan() {
        return rowspan;
    }

    /**
     * 設定 rowspan 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowspan(String value) {
        this.rowspan = value;
    }

    /**
     * 取得 columnspan 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnspan() {
        return columnspan;
    }

    /**
     * 設定 columnspan 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnspan(String value) {
        this.columnspan = value;
    }

    /**
     * 取得 edge 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEdge() {
        return edge;
    }

    /**
     * 設定 edge 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEdge(String value) {
        this.edge = value;
    }

    /**
     * 取得 actiontype 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActiontype() {
        return actiontype;
    }

    /**
     * 設定 actiontype 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActiontype(String value) {
        this.actiontype = value;
    }

    /**
     * 取得 selection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelection() {
        return selection;
    }

    /**
     * 設定 selection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelection(String value) {
        this.selection = value;
    }

}
