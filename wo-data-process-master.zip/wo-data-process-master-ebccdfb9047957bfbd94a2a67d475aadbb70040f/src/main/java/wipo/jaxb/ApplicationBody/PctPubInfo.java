//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>pct-pub-info complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="pct-pub-info"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}wo-published-text"/&gt;
 *         &lt;element ref="{}pct-art64" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pct-pub-info", propOrder = {
    "woPublishedText",
    "pctArt64"
})
public class PctPubInfo {

    @XmlElement(name = "wo-published-text", required = true)
    protected WoPublishedText woPublishedText;
    @XmlElement(name = "pct-art64")
    protected List<PctArt64> pctArt64;

    /**
     * 取得 woPublishedText 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link WoPublishedText }
     *     
     */
    public WoPublishedText getWoPublishedText() {
        return woPublishedText;
    }

    /**
     * 設定 woPublishedText 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link WoPublishedText }
     *     
     */
    public void setWoPublishedText(WoPublishedText value) {
        this.woPublishedText = value;
    }

    /**
     * Gets the value of the pctArt64 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pctArt64 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPctArt64().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PctArt64 }
     * 
     * 
     */
    public List<PctArt64> getPctArt64() {
        if (pctArt64 == null) {
            pctArt64 = new ArrayList<PctArt64>();
        }
        return this.pctArt64;
    }

}
