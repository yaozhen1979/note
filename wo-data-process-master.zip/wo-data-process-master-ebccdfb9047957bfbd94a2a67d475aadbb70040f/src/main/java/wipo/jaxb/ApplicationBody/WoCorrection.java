//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>wo-correction complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="wo-correction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}document-id" minOccurs="0"/&gt;
 *         &lt;element ref="{}type-of-correction" minOccurs="0"/&gt;
 *         &lt;element ref="{}wo-repub-code"/&gt;
 *         &lt;element ref="{}wo-pubnum" minOccurs="0"/&gt;
 *         &lt;element ref="{}wo-dtext" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "wo-correction", propOrder = {
    "documentId",
    "typeOfCorrection",
    "woRepubCode",
    "woPubnum",
    "woDtext"
})
public class WoCorrection {

    @XmlElement(name = "document-id")
    protected DocumentId documentId;
    @XmlElement(name = "type-of-correction")
    protected TypeOfCorrection typeOfCorrection;
    @XmlElement(name = "wo-repub-code", required = true)
    protected WoRepubCode woRepubCode;
    @XmlElement(name = "wo-pubnum")
    protected WoPubnum woPubnum;
    @XmlElement(name = "wo-dtext")
    protected List<WoDtext> woDtext;

    /**
     * 取得 documentId 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DocumentId }
     *     
     */
    public DocumentId getDocumentId() {
        return documentId;
    }

    /**
     * 設定 documentId 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentId }
     *     
     */
    public void setDocumentId(DocumentId value) {
        this.documentId = value;
    }

    /**
     * 取得 typeOfCorrection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TypeOfCorrection }
     *     
     */
    public TypeOfCorrection getTypeOfCorrection() {
        return typeOfCorrection;
    }

    /**
     * 設定 typeOfCorrection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TypeOfCorrection }
     *     
     */
    public void setTypeOfCorrection(TypeOfCorrection value) {
        this.typeOfCorrection = value;
    }

    /**
     * 取得 woRepubCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link WoRepubCode }
     *     
     */
    public WoRepubCode getWoRepubCode() {
        return woRepubCode;
    }

    /**
     * 設定 woRepubCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link WoRepubCode }
     *     
     */
    public void setWoRepubCode(WoRepubCode value) {
        this.woRepubCode = value;
    }

    /**
     * 取得 woPubnum 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link WoPubnum }
     *     
     */
    public WoPubnum getWoPubnum() {
        return woPubnum;
    }

    /**
     * 設定 woPubnum 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link WoPubnum }
     *     
     */
    public void setWoPubnum(WoPubnum value) {
        this.woPubnum = value;
    }

    /**
     * Gets the value of the woDtext property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the woDtext property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWoDtext().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WoDtext }
     * 
     * 
     */
    public List<WoDtext> getWoDtext() {
        if (woDtext == null) {
            woDtext = new ArrayList<WoDtext>();
        }
        return this.woDtext;
    }

}
