//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>momentabout complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="momentabout"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}csymbol"/&gt;
 *           &lt;element ref="{}ci"/&gt;
 *           &lt;element ref="{}cn"/&gt;
 *           &lt;element ref="{}apply"/&gt;
 *           &lt;element ref="{}reln"/&gt;
 *           &lt;element ref="{}lambda"/&gt;
 *           &lt;element ref="{}condition"/&gt;
 *           &lt;element ref="{}declare"/&gt;
 *           &lt;element ref="{}sep"/&gt;
 *           &lt;element ref="{}semantics"/&gt;
 *           &lt;element ref="{}annotation"/&gt;
 *           &lt;element ref="{}annotation-xml"/&gt;
 *           &lt;element ref="{}integers"/&gt;
 *           &lt;element ref="{}reals"/&gt;
 *           &lt;element ref="{}rationals"/&gt;
 *           &lt;element ref="{}naturalnumbers"/&gt;
 *           &lt;element ref="{}complexes"/&gt;
 *           &lt;element ref="{}primes"/&gt;
 *           &lt;element ref="{}exponentiale"/&gt;
 *           &lt;element ref="{}imaginaryi"/&gt;
 *           &lt;element ref="{}notanumber"/&gt;
 *           &lt;element ref="{}true"/&gt;
 *           &lt;element ref="{}false"/&gt;
 *           &lt;element ref="{}emptyset"/&gt;
 *           &lt;element ref="{}pi"/&gt;
 *           &lt;element ref="{}eulergamma"/&gt;
 *           &lt;element ref="{}infinity"/&gt;
 *           &lt;element ref="{}interval"/&gt;
 *           &lt;element ref="{}list"/&gt;
 *           &lt;element ref="{}matrix"/&gt;
 *           &lt;element ref="{}matrixrow"/&gt;
 *           &lt;element ref="{}set"/&gt;
 *           &lt;element ref="{}vector"/&gt;
 *           &lt;element ref="{}piecewise"/&gt;
 *           &lt;element ref="{}lowlimit"/&gt;
 *           &lt;element ref="{}uplimit"/&gt;
 *           &lt;element ref="{}bvar"/&gt;
 *           &lt;element ref="{}degree"/&gt;
 *           &lt;element ref="{}logbase"/&gt;
 *           &lt;element ref="{}momentabout"/&gt;
 *           &lt;element ref="{}domainofapplication"/&gt;
 *           &lt;element ref="{}inverse"/&gt;
 *           &lt;element ref="{}ident"/&gt;
 *           &lt;element ref="{}domain"/&gt;
 *           &lt;element ref="{}codomain"/&gt;
 *           &lt;element ref="{}image"/&gt;
 *           &lt;element ref="{}abs"/&gt;
 *           &lt;element ref="{}conjugate"/&gt;
 *           &lt;element ref="{}exp"/&gt;
 *           &lt;element ref="{}factorial"/&gt;
 *           &lt;element ref="{}arg"/&gt;
 *           &lt;element ref="{}real"/&gt;
 *           &lt;element ref="{}imaginary"/&gt;
 *           &lt;element ref="{}floor"/&gt;
 *           &lt;element ref="{}ceiling"/&gt;
 *           &lt;element ref="{}not"/&gt;
 *           &lt;element ref="{}ln"/&gt;
 *           &lt;element ref="{}sin"/&gt;
 *           &lt;element ref="{}cos"/&gt;
 *           &lt;element ref="{}tan"/&gt;
 *           &lt;element ref="{}sec"/&gt;
 *           &lt;element ref="{}csc"/&gt;
 *           &lt;element ref="{}cot"/&gt;
 *           &lt;element ref="{}sinh"/&gt;
 *           &lt;element ref="{}cosh"/&gt;
 *           &lt;element ref="{}tanh"/&gt;
 *           &lt;element ref="{}sech"/&gt;
 *           &lt;element ref="{}csch"/&gt;
 *           &lt;element ref="{}coth"/&gt;
 *           &lt;element ref="{}arcsin"/&gt;
 *           &lt;element ref="{}arccos"/&gt;
 *           &lt;element ref="{}arctan"/&gt;
 *           &lt;element ref="{}arccosh"/&gt;
 *           &lt;element ref="{}arccot"/&gt;
 *           &lt;element ref="{}arccoth"/&gt;
 *           &lt;element ref="{}arccsc"/&gt;
 *           &lt;element ref="{}arccsch"/&gt;
 *           &lt;element ref="{}arcsec"/&gt;
 *           &lt;element ref="{}arcsech"/&gt;
 *           &lt;element ref="{}arcsinh"/&gt;
 *           &lt;element ref="{}arctanh"/&gt;
 *           &lt;element ref="{}determinant"/&gt;
 *           &lt;element ref="{}transpose"/&gt;
 *           &lt;element ref="{}card"/&gt;
 *           &lt;element ref="{}quotient"/&gt;
 *           &lt;element ref="{}divide"/&gt;
 *           &lt;element ref="{}power"/&gt;
 *           &lt;element ref="{}rem"/&gt;
 *           &lt;element ref="{}implies"/&gt;
 *           &lt;element ref="{}vectorproduct"/&gt;
 *           &lt;element ref="{}scalarproduct"/&gt;
 *           &lt;element ref="{}outerproduct"/&gt;
 *           &lt;element ref="{}setdiff"/&gt;
 *           &lt;element ref="{}fn"/&gt;
 *           &lt;element ref="{}compose"/&gt;
 *           &lt;element ref="{}plus"/&gt;
 *           &lt;element ref="{}times"/&gt;
 *           &lt;element ref="{}max"/&gt;
 *           &lt;element ref="{}min"/&gt;
 *           &lt;element ref="{}gcd"/&gt;
 *           &lt;element ref="{}lcm"/&gt;
 *           &lt;element ref="{}and"/&gt;
 *           &lt;element ref="{}or"/&gt;
 *           &lt;element ref="{}xor"/&gt;
 *           &lt;element ref="{}union"/&gt;
 *           &lt;element ref="{}intersect"/&gt;
 *           &lt;element ref="{}cartesianproduct"/&gt;
 *           &lt;element ref="{}mean"/&gt;
 *           &lt;element ref="{}sdev"/&gt;
 *           &lt;element ref="{}variance"/&gt;
 *           &lt;element ref="{}median"/&gt;
 *           &lt;element ref="{}mode"/&gt;
 *           &lt;element ref="{}selector"/&gt;
 *           &lt;element ref="{}root"/&gt;
 *           &lt;element ref="{}minus"/&gt;
 *           &lt;element ref="{}log"/&gt;
 *           &lt;element ref="{}int"/&gt;
 *           &lt;element ref="{}diff"/&gt;
 *           &lt;element ref="{}partialdiff"/&gt;
 *           &lt;element ref="{}divergence"/&gt;
 *           &lt;element ref="{}grad"/&gt;
 *           &lt;element ref="{}curl"/&gt;
 *           &lt;element ref="{}laplacian"/&gt;
 *           &lt;element ref="{}sum"/&gt;
 *           &lt;element ref="{}product"/&gt;
 *           &lt;element ref="{}limit"/&gt;
 *           &lt;element ref="{}moment"/&gt;
 *           &lt;element ref="{}exists"/&gt;
 *           &lt;element ref="{}forall"/&gt;
 *           &lt;element ref="{}neq"/&gt;
 *           &lt;element ref="{}factorof"/&gt;
 *           &lt;element ref="{}in"/&gt;
 *           &lt;element ref="{}notin"/&gt;
 *           &lt;element ref="{}notsubset"/&gt;
 *           &lt;element ref="{}notprsubset"/&gt;
 *           &lt;element ref="{}tendsto"/&gt;
 *           &lt;element ref="{}eq"/&gt;
 *           &lt;element ref="{}leq"/&gt;
 *           &lt;element ref="{}lt"/&gt;
 *           &lt;element ref="{}geq"/&gt;
 *           &lt;element ref="{}gt"/&gt;
 *           &lt;element ref="{}equivalent"/&gt;
 *           &lt;element ref="{}approx"/&gt;
 *           &lt;element ref="{}subset"/&gt;
 *           &lt;element ref="{}prsubset"/&gt;
 *           &lt;element ref="{}mi"/&gt;
 *           &lt;element ref="{}mn"/&gt;
 *           &lt;element ref="{}mo"/&gt;
 *           &lt;element ref="{}mtext"/&gt;
 *           &lt;element ref="{}ms"/&gt;
 *           &lt;element ref="{}mspace"/&gt;
 *           &lt;element ref="{}mrow"/&gt;
 *           &lt;element ref="{}mfrac"/&gt;
 *           &lt;element ref="{}msqrt"/&gt;
 *           &lt;element ref="{}mroot"/&gt;
 *           &lt;element ref="{}menclose"/&gt;
 *           &lt;element ref="{}mstyle"/&gt;
 *           &lt;element ref="{}merror"/&gt;
 *           &lt;element ref="{}mpadded"/&gt;
 *           &lt;element ref="{}mphantom"/&gt;
 *           &lt;element ref="{}mfenced"/&gt;
 *           &lt;element ref="{}msub"/&gt;
 *           &lt;element ref="{}msup"/&gt;
 *           &lt;element ref="{}msubsup"/&gt;
 *           &lt;element ref="{}munder"/&gt;
 *           &lt;element ref="{}mover"/&gt;
 *           &lt;element ref="{}munderover"/&gt;
 *           &lt;element ref="{}mmultiscripts"/&gt;
 *           &lt;element ref="{}mtable"/&gt;
 *           &lt;element ref="{}mtr"/&gt;
 *           &lt;element ref="{}mlabeledtr"/&gt;
 *           &lt;element ref="{}mtd"/&gt;
 *           &lt;element ref="{}maligngroup"/&gt;
 *           &lt;element ref="{}malignmark"/&gt;
 *           &lt;element ref="{}maction"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute ref="{}xlinkherf"/&gt;
 *       &lt;attribute ref="{}xlinktype"/&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "momentabout", propOrder = {
    "csymbolOrCiOrCn"
})
public class Momentabout {

    @XmlElements({
        @XmlElement(name = "csymbol", type = Csymbol.class),
        @XmlElement(name = "ci", type = Ci.class),
        @XmlElement(name = "cn", type = Cn.class),
        @XmlElement(name = "apply", type = Apply.class),
        @XmlElement(name = "reln", type = Reln.class),
        @XmlElement(name = "lambda", type = Lambda.class),
        @XmlElement(name = "condition", type = Condition.class),
        @XmlElement(name = "declare", type = Declare.class),
        @XmlElement(name = "sep", type = Sep.class),
        @XmlElement(name = "semantics", type = Semantics.class),
        @XmlElement(name = "annotation", type = Annotation.class),
        @XmlElement(name = "annotation-xml", type = AnnotationXml.class),
        @XmlElement(name = "integers", type = Integers.class),
        @XmlElement(name = "reals", type = Reals.class),
        @XmlElement(name = "rationals", type = Rationals.class),
        @XmlElement(name = "naturalnumbers", type = Naturalnumbers.class),
        @XmlElement(name = "complexes", type = Complexes.class),
        @XmlElement(name = "primes", type = Primes.class),
        @XmlElement(name = "exponentiale", type = Exponentiale.class),
        @XmlElement(name = "imaginaryi", type = Imaginaryi.class),
        @XmlElement(name = "notanumber", type = Notanumber.class),
        @XmlElement(name = "true", type = True.class),
        @XmlElement(name = "false", type = False.class),
        @XmlElement(name = "emptyset", type = Emptyset.class),
        @XmlElement(name = "pi", type = Pi.class),
        @XmlElement(name = "eulergamma", type = Eulergamma.class),
        @XmlElement(name = "infinity", type = Infinity.class),
        @XmlElement(name = "interval", type = Interval.class),
        @XmlElement(name = "list", type = wipo.jaxb.ApplicationBody.List.class),
        @XmlElement(name = "matrix", type = Matrix.class),
        @XmlElement(name = "matrixrow", type = Matrixrow.class),
        @XmlElement(name = "set", type = Set.class),
        @XmlElement(name = "vector", type = Vector.class),
        @XmlElement(name = "piecewise", type = Piecewise.class),
        @XmlElement(name = "lowlimit", type = Lowlimit.class),
        @XmlElement(name = "uplimit", type = Uplimit.class),
        @XmlElement(name = "bvar", type = Bvar.class),
        @XmlElement(name = "degree", type = Degree.class),
        @XmlElement(name = "logbase", type = Logbase.class),
        @XmlElement(name = "momentabout", type = Momentabout.class),
        @XmlElement(name = "domainofapplication", type = Domainofapplication.class),
        @XmlElement(name = "inverse", type = Inverse.class),
        @XmlElement(name = "ident", type = Ident.class),
        @XmlElement(name = "domain", type = Domain.class),
        @XmlElement(name = "codomain", type = Codomain.class),
        @XmlElement(name = "image", type = Image.class),
        @XmlElement(name = "abs", type = Abs.class),
        @XmlElement(name = "conjugate", type = Conjugate.class),
        @XmlElement(name = "exp", type = Exp.class),
        @XmlElement(name = "factorial", type = Factorial.class),
        @XmlElement(name = "arg", type = Arg.class),
        @XmlElement(name = "real", type = Real.class),
        @XmlElement(name = "imaginary", type = Imaginary.class),
        @XmlElement(name = "floor", type = Floor.class),
        @XmlElement(name = "ceiling", type = Ceiling.class),
        @XmlElement(name = "not", type = Not.class),
        @XmlElement(name = "ln", type = Ln.class),
        @XmlElement(name = "sin", type = Sin.class),
        @XmlElement(name = "cos", type = Cos.class),
        @XmlElement(name = "tan", type = Tan.class),
        @XmlElement(name = "sec", type = Sec.class),
        @XmlElement(name = "csc", type = Csc.class),
        @XmlElement(name = "cot", type = Cot.class),
        @XmlElement(name = "sinh", type = Sinh.class),
        @XmlElement(name = "cosh", type = Cosh.class),
        @XmlElement(name = "tanh", type = Tanh.class),
        @XmlElement(name = "sech", type = Sech.class),
        @XmlElement(name = "csch", type = Csch.class),
        @XmlElement(name = "coth", type = Coth.class),
        @XmlElement(name = "arcsin", type = Arcsin.class),
        @XmlElement(name = "arccos", type = Arccos.class),
        @XmlElement(name = "arctan", type = Arctan.class),
        @XmlElement(name = "arccosh", type = Arccosh.class),
        @XmlElement(name = "arccot", type = Arccot.class),
        @XmlElement(name = "arccoth", type = Arccoth.class),
        @XmlElement(name = "arccsc", type = Arccsc.class),
        @XmlElement(name = "arccsch", type = Arccsch.class),
        @XmlElement(name = "arcsec", type = Arcsec.class),
        @XmlElement(name = "arcsech", type = Arcsech.class),
        @XmlElement(name = "arcsinh", type = Arcsinh.class),
        @XmlElement(name = "arctanh", type = Arctanh.class),
        @XmlElement(name = "determinant", type = Determinant.class),
        @XmlElement(name = "transpose", type = Transpose.class),
        @XmlElement(name = "card", type = Card.class),
        @XmlElement(name = "quotient", type = Quotient.class),
        @XmlElement(name = "divide", type = Divide.class),
        @XmlElement(name = "power", type = Power.class),
        @XmlElement(name = "rem", type = Rem.class),
        @XmlElement(name = "implies", type = Implies.class),
        @XmlElement(name = "vectorproduct", type = Vectorproduct.class),
        @XmlElement(name = "scalarproduct", type = Scalarproduct.class),
        @XmlElement(name = "outerproduct", type = Outerproduct.class),
        @XmlElement(name = "setdiff", type = Setdiff.class),
        @XmlElement(name = "fn", type = Fn.class),
        @XmlElement(name = "compose", type = Compose.class),
        @XmlElement(name = "plus", type = Plus.class),
        @XmlElement(name = "times", type = Times.class),
        @XmlElement(name = "max", type = Max.class),
        @XmlElement(name = "min", type = Min.class),
        @XmlElement(name = "gcd", type = Gcd.class),
        @XmlElement(name = "lcm", type = Lcm.class),
        @XmlElement(name = "and", type = And.class),
        @XmlElement(name = "or", type = Or.class),
        @XmlElement(name = "xor", type = Xor.class),
        @XmlElement(name = "union", type = Union.class),
        @XmlElement(name = "intersect", type = Intersect.class),
        @XmlElement(name = "cartesianproduct", type = Cartesianproduct.class),
        @XmlElement(name = "mean", type = Mean.class),
        @XmlElement(name = "sdev", type = Sdev.class),
        @XmlElement(name = "variance", type = Variance.class),
        @XmlElement(name = "median", type = Median.class),
        @XmlElement(name = "mode", type = Mode.class),
        @XmlElement(name = "selector", type = Selector.class),
        @XmlElement(name = "root", type = Root.class),
        @XmlElement(name = "minus", type = Minus.class),
        @XmlElement(name = "log", type = Log.class),
        @XmlElement(name = "int", type = Int.class),
        @XmlElement(name = "diff", type = Diff.class),
        @XmlElement(name = "partialdiff", type = Partialdiff.class),
        @XmlElement(name = "divergence", type = Divergence.class),
        @XmlElement(name = "grad", type = Grad.class),
        @XmlElement(name = "curl", type = Curl.class),
        @XmlElement(name = "laplacian", type = Laplacian.class),
        @XmlElement(name = "sum", type = Sum.class),
        @XmlElement(name = "product", type = Product.class),
        @XmlElement(name = "limit", type = Limit.class),
        @XmlElement(name = "moment", type = Moment.class),
        @XmlElement(name = "exists", type = Exists.class),
        @XmlElement(name = "forall", type = Forall.class),
        @XmlElement(name = "neq", type = Neq.class),
        @XmlElement(name = "factorof", type = Factorof.class),
        @XmlElement(name = "in", type = In.class),
        @XmlElement(name = "notin", type = Notin.class),
        @XmlElement(name = "notsubset", type = Notsubset.class),
        @XmlElement(name = "notprsubset", type = Notprsubset.class),
        @XmlElement(name = "tendsto", type = Tendsto.class),
        @XmlElement(name = "eq", type = Eq.class),
        @XmlElement(name = "leq", type = Leq.class),
        @XmlElement(name = "lt", type = Lt.class),
        @XmlElement(name = "geq", type = Geq.class),
        @XmlElement(name = "gt", type = Gt.class),
        @XmlElement(name = "equivalent", type = Equivalent.class),
        @XmlElement(name = "approx", type = Approx.class),
        @XmlElement(name = "subset", type = Subset.class),
        @XmlElement(name = "prsubset", type = Prsubset.class),
        @XmlElement(name = "mi", type = Mi.class),
        @XmlElement(name = "mn", type = Mn.class),
        @XmlElement(name = "mo", type = Mo.class),
        @XmlElement(name = "mtext", type = Mtext.class),
        @XmlElement(name = "ms", type = Ms.class),
        @XmlElement(name = "mspace", type = Mspace.class),
        @XmlElement(name = "mrow", type = Mrow.class),
        @XmlElement(name = "mfrac", type = Mfrac.class),
        @XmlElement(name = "msqrt", type = Msqrt.class),
        @XmlElement(name = "mroot", type = Mroot.class),
        @XmlElement(name = "menclose", type = Menclose.class),
        @XmlElement(name = "mstyle", type = Mstyle.class),
        @XmlElement(name = "merror", type = Merror.class),
        @XmlElement(name = "mpadded", type = Mpadded.class),
        @XmlElement(name = "mphantom", type = Mphantom.class),
        @XmlElement(name = "mfenced", type = Mfenced.class),
        @XmlElement(name = "msub", type = Msub.class),
        @XmlElement(name = "msup", type = Msup.class),
        @XmlElement(name = "msubsup", type = Msubsup.class),
        @XmlElement(name = "munder", type = Munder.class),
        @XmlElement(name = "mover", type = Mover.class),
        @XmlElement(name = "munderover", type = Munderover.class),
        @XmlElement(name = "mmultiscripts", type = Mmultiscripts.class),
        @XmlElement(name = "mtable", type = Mtable.class),
        @XmlElement(name = "mtr", type = Mtr.class),
        @XmlElement(name = "mlabeledtr", type = Mlabeledtr.class),
        @XmlElement(name = "mtd", type = Mtd.class),
        @XmlElement(name = "maligngroup", type = Maligngroup.class),
        @XmlElement(name = "malignmark", type = Malignmark.class),
        @XmlElement(name = "maction", type = Maction.class)
    })
    protected java.util.List<Object> csymbolOrCiOrCn;
    @XmlAttribute(name = "xlinkherf")
    protected String xlinkherf;
    @XmlAttribute(name = "xlinktype")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String xlinktype;
    @XmlAttribute(name = "class")
    @XmlSchemaType(name = "anySimpleType")
    protected String clazz;
    @XmlAttribute(name = "style")
    @XmlSchemaType(name = "anySimpleType")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    @XmlSchemaType(name = "anySimpleType")
    protected String other;

    /**
     * Gets the value of the csymbolOrCiOrCn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the csymbolOrCiOrCn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCsymbolOrCiOrCn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Csymbol }
     * {@link Ci }
     * {@link Cn }
     * {@link Apply }
     * {@link Reln }
     * {@link Lambda }
     * {@link Condition }
     * {@link Declare }
     * {@link Sep }
     * {@link Semantics }
     * {@link Annotation }
     * {@link AnnotationXml }
     * {@link Integers }
     * {@link Reals }
     * {@link Rationals }
     * {@link Naturalnumbers }
     * {@link Complexes }
     * {@link Primes }
     * {@link Exponentiale }
     * {@link Imaginaryi }
     * {@link Notanumber }
     * {@link True }
     * {@link False }
     * {@link Emptyset }
     * {@link Pi }
     * {@link Eulergamma }
     * {@link Infinity }
     * {@link Interval }
     * {@link wipo.jaxb.ApplicationBody.List }
     * {@link Matrix }
     * {@link Matrixrow }
     * {@link Set }
     * {@link Vector }
     * {@link Piecewise }
     * {@link Lowlimit }
     * {@link Uplimit }
     * {@link Bvar }
     * {@link Degree }
     * {@link Logbase }
     * {@link Momentabout }
     * {@link Domainofapplication }
     * {@link Inverse }
     * {@link Ident }
     * {@link Domain }
     * {@link Codomain }
     * {@link Image }
     * {@link Abs }
     * {@link Conjugate }
     * {@link Exp }
     * {@link Factorial }
     * {@link Arg }
     * {@link Real }
     * {@link Imaginary }
     * {@link Floor }
     * {@link Ceiling }
     * {@link Not }
     * {@link Ln }
     * {@link Sin }
     * {@link Cos }
     * {@link Tan }
     * {@link Sec }
     * {@link Csc }
     * {@link Cot }
     * {@link Sinh }
     * {@link Cosh }
     * {@link Tanh }
     * {@link Sech }
     * {@link Csch }
     * {@link Coth }
     * {@link Arcsin }
     * {@link Arccos }
     * {@link Arctan }
     * {@link Arccosh }
     * {@link Arccot }
     * {@link Arccoth }
     * {@link Arccsc }
     * {@link Arccsch }
     * {@link Arcsec }
     * {@link Arcsech }
     * {@link Arcsinh }
     * {@link Arctanh }
     * {@link Determinant }
     * {@link Transpose }
     * {@link Card }
     * {@link Quotient }
     * {@link Divide }
     * {@link Power }
     * {@link Rem }
     * {@link Implies }
     * {@link Vectorproduct }
     * {@link Scalarproduct }
     * {@link Outerproduct }
     * {@link Setdiff }
     * {@link Fn }
     * {@link Compose }
     * {@link Plus }
     * {@link Times }
     * {@link Max }
     * {@link Min }
     * {@link Gcd }
     * {@link Lcm }
     * {@link And }
     * {@link Or }
     * {@link Xor }
     * {@link Union }
     * {@link Intersect }
     * {@link Cartesianproduct }
     * {@link Mean }
     * {@link Sdev }
     * {@link Variance }
     * {@link Median }
     * {@link Mode }
     * {@link Selector }
     * {@link Root }
     * {@link Minus }
     * {@link Log }
     * {@link Int }
     * {@link Diff }
     * {@link Partialdiff }
     * {@link Divergence }
     * {@link Grad }
     * {@link Curl }
     * {@link Laplacian }
     * {@link Sum }
     * {@link Product }
     * {@link Limit }
     * {@link Moment }
     * {@link Exists }
     * {@link Forall }
     * {@link Neq }
     * {@link Factorof }
     * {@link In }
     * {@link Notin }
     * {@link Notsubset }
     * {@link Notprsubset }
     * {@link Tendsto }
     * {@link Eq }
     * {@link Leq }
     * {@link Lt }
     * {@link Geq }
     * {@link Gt }
     * {@link Equivalent }
     * {@link Approx }
     * {@link Subset }
     * {@link Prsubset }
     * {@link Mi }
     * {@link Mn }
     * {@link Mo }
     * {@link Mtext }
     * {@link Ms }
     * {@link Mspace }
     * {@link Mrow }
     * {@link Mfrac }
     * {@link Msqrt }
     * {@link Mroot }
     * {@link Menclose }
     * {@link Mstyle }
     * {@link Merror }
     * {@link Mpadded }
     * {@link Mphantom }
     * {@link Mfenced }
     * {@link Msub }
     * {@link Msup }
     * {@link Msubsup }
     * {@link Munder }
     * {@link Mover }
     * {@link Munderover }
     * {@link Mmultiscripts }
     * {@link Mtable }
     * {@link Mtr }
     * {@link Mlabeledtr }
     * {@link Mtd }
     * {@link Maligngroup }
     * {@link Malignmark }
     * {@link Maction }
     * 
     * 
     */
    public java.util.List<Object> getCsymbolOrCiOrCn() {
        if (csymbolOrCiOrCn == null) {
            csymbolOrCiOrCn = new ArrayList<Object>();
        }
        return this.csymbolOrCiOrCn;
    }

    /**
     * 取得 xlinkherf 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinkherf() {
        return xlinkherf;
    }

    /**
     * 設定 xlinkherf 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinkherf(String value) {
        this.xlinkherf = value;
    }

    /**
     * 取得 xlinktype 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinktype() {
        return xlinktype;
    }

    /**
     * 設定 xlinktype 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinktype(String value) {
        this.xlinktype = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

}
