//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>book complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="book"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}text"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}author" maxOccurs="unbounded" minOccurs="0"/&gt;
 *           &lt;choice&gt;
 *             &lt;element ref="{}book-title" maxOccurs="unbounded"/&gt;
 *             &lt;element ref="{}conference"/&gt;
 *           &lt;/choice&gt;
 *           &lt;sequence&gt;
 *             &lt;element ref="{}subtitle" minOccurs="0"/&gt;
 *             &lt;element ref="{}subname" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}edition" minOccurs="0"/&gt;
 *             &lt;element ref="{}imprint" minOccurs="0"/&gt;
 *             &lt;element ref="{}descrip" minOccurs="0"/&gt;
 *             &lt;element ref="{}series" minOccurs="0"/&gt;
 *             &lt;element ref="{}absno" minOccurs="0"/&gt;
 *             &lt;element ref="{}location" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}isbn" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}pubid" minOccurs="0"/&gt;
 *             &lt;element ref="{}vid" minOccurs="0"/&gt;
 *             &lt;element ref="{}bookno" minOccurs="0"/&gt;
 *             &lt;element ref="{}notes" minOccurs="0"/&gt;
 *             &lt;element ref="{}class" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}keyword" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}cpyrt" minOccurs="0"/&gt;
 *             &lt;element ref="{}refno" maxOccurs="unbounded" minOccurs="0"/&gt;
 *             &lt;element ref="{}doi" minOccurs="0"/&gt;
 *             &lt;element ref="{}ino" minOccurs="0"/&gt;
 *             &lt;element ref="{}issn" minOccurs="0"/&gt;
 *           &lt;/sequence&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "book", propOrder = {
    "text",
    "author",
    "bookTitle",
    "conference",
    "subtitle",
    "subname",
    "edition",
    "imprint",
    "descrip",
    "series",
    "absno",
    "location",
    "isbn",
    "pubid",
    "vid",
    "bookno",
    "notes",
    "clazz",
    "keyword",
    "cpyrt",
    "refno",
    "doi",
    "ino",
    "issn"
})
public class Book {

    protected Text text;
    protected List<Author> author;
    @XmlElement(name = "book-title")
    protected List<BookTitle> bookTitle;
    protected Conference conference;
    protected Subtitle subtitle;
    protected List<Subname> subname;
    protected Edition edition;
    protected Imprint imprint;
    protected Descrip descrip;
    protected Series series;
    protected Absno absno;
    protected List<Location> location;
    protected List<Isbn> isbn;
    protected Pubid pubid;
    protected Vid vid;
    protected Bookno bookno;
    protected Notes notes;
    @XmlElement(name = "class")
    protected List<Class> clazz;
    protected List<Keyword> keyword;
    protected Cpyrt cpyrt;
    protected List<Refno> refno;
    protected Doi doi;
    protected Ino ino;
    protected Issn issn;

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the author property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Author }
     * 
     * 
     */
    public List<Author> getAuthor() {
        if (author == null) {
            author = new ArrayList<Author>();
        }
        return this.author;
    }

    /**
     * Gets the value of the bookTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bookTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBookTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BookTitle }
     * 
     * 
     */
    public List<BookTitle> getBookTitle() {
        if (bookTitle == null) {
            bookTitle = new ArrayList<BookTitle>();
        }
        return this.bookTitle;
    }

    /**
     * 取得 conference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Conference }
     *     
     */
    public Conference getConference() {
        return conference;
    }

    /**
     * 設定 conference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Conference }
     *     
     */
    public void setConference(Conference value) {
        this.conference = value;
    }

    /**
     * 取得 subtitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Subtitle }
     *     
     */
    public Subtitle getSubtitle() {
        return subtitle;
    }

    /**
     * 設定 subtitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Subtitle }
     *     
     */
    public void setSubtitle(Subtitle value) {
        this.subtitle = value;
    }

    /**
     * Gets the value of the subname property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subname property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubname().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Subname }
     * 
     * 
     */
    public List<Subname> getSubname() {
        if (subname == null) {
            subname = new ArrayList<Subname>();
        }
        return this.subname;
    }

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Edition }
     *     
     */
    public Edition getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Edition }
     *     
     */
    public void setEdition(Edition value) {
        this.edition = value;
    }

    /**
     * 取得 imprint 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Imprint }
     *     
     */
    public Imprint getImprint() {
        return imprint;
    }

    /**
     * 設定 imprint 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Imprint }
     *     
     */
    public void setImprint(Imprint value) {
        this.imprint = value;
    }

    /**
     * 取得 descrip 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Descrip }
     *     
     */
    public Descrip getDescrip() {
        return descrip;
    }

    /**
     * 設定 descrip 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Descrip }
     *     
     */
    public void setDescrip(Descrip value) {
        this.descrip = value;
    }

    /**
     * 取得 series 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Series }
     *     
     */
    public Series getSeries() {
        return series;
    }

    /**
     * 設定 series 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Series }
     *     
     */
    public void setSeries(Series value) {
        this.series = value;
    }

    /**
     * 取得 absno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Absno }
     *     
     */
    public Absno getAbsno() {
        return absno;
    }

    /**
     * 設定 absno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Absno }
     *     
     */
    public void setAbsno(Absno value) {
        this.absno = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the location property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Location }
     * 
     * 
     */
    public List<Location> getLocation() {
        if (location == null) {
            location = new ArrayList<Location>();
        }
        return this.location;
    }

    /**
     * Gets the value of the isbn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the isbn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIsbn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Isbn }
     * 
     * 
     */
    public List<Isbn> getIsbn() {
        if (isbn == null) {
            isbn = new ArrayList<Isbn>();
        }
        return this.isbn;
    }

    /**
     * 取得 pubid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Pubid }
     *     
     */
    public Pubid getPubid() {
        return pubid;
    }

    /**
     * 設定 pubid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Pubid }
     *     
     */
    public void setPubid(Pubid value) {
        this.pubid = value;
    }

    /**
     * 取得 vid 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Vid }
     *     
     */
    public Vid getVid() {
        return vid;
    }

    /**
     * 設定 vid 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Vid }
     *     
     */
    public void setVid(Vid value) {
        this.vid = value;
    }

    /**
     * 取得 bookno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Bookno }
     *     
     */
    public Bookno getBookno() {
        return bookno;
    }

    /**
     * 設定 bookno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Bookno }
     *     
     */
    public void setBookno(Bookno value) {
        this.bookno = value;
    }

    /**
     * 取得 notes 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Notes }
     *     
     */
    public Notes getNotes() {
        return notes;
    }

    /**
     * 設定 notes 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Notes }
     *     
     */
    public void setNotes(Notes value) {
        this.notes = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clazz property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClazz().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Class }
     * 
     * 
     */
    public List<Class> getClazz() {
        if (clazz == null) {
            clazz = new ArrayList<Class>();
        }
        return this.clazz;
    }

    /**
     * Gets the value of the keyword property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyword property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyword().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Keyword }
     * 
     * 
     */
    public List<Keyword> getKeyword() {
        if (keyword == null) {
            keyword = new ArrayList<Keyword>();
        }
        return this.keyword;
    }

    /**
     * 取得 cpyrt 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Cpyrt }
     *     
     */
    public Cpyrt getCpyrt() {
        return cpyrt;
    }

    /**
     * 設定 cpyrt 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Cpyrt }
     *     
     */
    public void setCpyrt(Cpyrt value) {
        this.cpyrt = value;
    }

    /**
     * Gets the value of the refno property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the refno property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRefno().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Refno }
     * 
     * 
     */
    public List<Refno> getRefno() {
        if (refno == null) {
            refno = new ArrayList<Refno>();
        }
        return this.refno;
    }

    /**
     * 取得 doi 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Doi }
     *     
     */
    public Doi getDoi() {
        return doi;
    }

    /**
     * 設定 doi 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Doi }
     *     
     */
    public void setDoi(Doi value) {
        this.doi = value;
    }

    /**
     * 取得 ino 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Ino }
     *     
     */
    public Ino getIno() {
        return ino;
    }

    /**
     * 設定 ino 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Ino }
     *     
     */
    public void setIno(Ino value) {
        this.ino = value;
    }

    /**
     * 取得 issn 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Issn }
     *     
     */
    public Issn getIssn() {
        return issn;
    }

    /**
     * 設定 issn 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Issn }
     *     
     */
    public void setIssn(Issn value) {
        this.issn = value;
    }

}
