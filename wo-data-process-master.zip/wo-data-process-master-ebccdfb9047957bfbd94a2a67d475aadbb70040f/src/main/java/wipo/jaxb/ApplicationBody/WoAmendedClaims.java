//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>wo-amended-claims complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="wo-amended-claims"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}amend-statement" minOccurs="0"/&gt;
 *           &lt;choice&gt;
 *             &lt;element ref="{}amend-body"/&gt;
 *             &lt;choice maxOccurs="unbounded"&gt;
 *               &lt;element ref="{}delete-object"/&gt;
 *               &lt;sequence&gt;
 *                 &lt;choice&gt;
 *                   &lt;element ref="{}insert-before-object"/&gt;
 *                   &lt;element ref="{}insert-after-object"/&gt;
 *                   &lt;element ref="{}replace-object"/&gt;
 *                 &lt;/choice&gt;
 *               &lt;/sequence&gt;
 *             &lt;/choice&gt;
 *           &lt;/choice&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{}text" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="claim-type" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "wo-amended-claims", propOrder = {
    "amendStatement",
    "amendBody",
    "deleteObjectOrInsertBeforeObjectOrInsertAfterObject",
    "text"
})
public class WoAmendedClaims {

    @XmlElement(name = "amend-statement")
    protected AmendStatement amendStatement;
    @XmlElement(name = "amend-body")
    protected AmendBody amendBody;
    @XmlElements({
        @XmlElement(name = "delete-object", type = DeleteObject.class),
        @XmlElement(name = "insert-before-object", type = InsertBeforeObject.class),
        @XmlElement(name = "insert-after-object", type = InsertAfterObject.class),
        @XmlElement(name = "replace-object", type = ReplaceObject.class)
    })
    protected List<Object> deleteObjectOrInsertBeforeObjectOrInsertAfterObject;
    protected Text text;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    @XmlSchemaType(name = "anySimpleType")
    protected String lang;
    @XmlAttribute(name = "claim-type")
    @XmlSchemaType(name = "anySimpleType")
    protected String claimType;
    @XmlAttribute(name = "status")
    @XmlSchemaType(name = "anySimpleType")
    protected String status;

    /**
     * 取得 amendStatement 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AmendStatement }
     *     
     */
    public AmendStatement getAmendStatement() {
        return amendStatement;
    }

    /**
     * 設定 amendStatement 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AmendStatement }
     *     
     */
    public void setAmendStatement(AmendStatement value) {
        this.amendStatement = value;
    }

    /**
     * 取得 amendBody 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AmendBody }
     *     
     */
    public AmendBody getAmendBody() {
        return amendBody;
    }

    /**
     * 設定 amendBody 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AmendBody }
     *     
     */
    public void setAmendBody(AmendBody value) {
        this.amendBody = value;
    }

    /**
     * Gets the value of the deleteObjectOrInsertBeforeObjectOrInsertAfterObject property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deleteObjectOrInsertBeforeObjectOrInsertAfterObject property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeleteObjectOrInsertBeforeObjectOrInsertAfterObject().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DeleteObject }
     * {@link InsertBeforeObject }
     * {@link InsertAfterObject }
     * {@link ReplaceObject }
     * 
     * 
     */
    public List<Object> getDeleteObjectOrInsertBeforeObjectOrInsertAfterObject() {
        if (deleteObjectOrInsertBeforeObjectOrInsertAfterObject == null) {
            deleteObjectOrInsertBeforeObjectOrInsertAfterObject = new ArrayList<Object>();
        }
        return this.deleteObjectOrInsertBeforeObjectOrInsertAfterObject;
    }

    /**
     * 取得 text 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Text }
     *     
     */
    public Text getText() {
        return text;
    }

    /**
     * 設定 text 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Text }
     *     
     */
    public void setText(Text value) {
        this.text = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 claimType 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimType() {
        return claimType;
    }

    /**
     * 設定 claimType 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimType(String value) {
        this.claimType = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
