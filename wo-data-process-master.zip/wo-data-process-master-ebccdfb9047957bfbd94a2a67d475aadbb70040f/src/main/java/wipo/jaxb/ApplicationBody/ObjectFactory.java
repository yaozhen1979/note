//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the wipo.jaxb.ApplicationBody package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Mspace_QNAME = new QName("", "mspace");
    private final static QName _Mprescripts_QNAME = new QName("", "mprescripts");
    private final static QName _None_QNAME = new QName("", "none");
    private final static QName _Malignmark_QNAME = new QName("", "malignmark");
    private final static QName _Maligngroup_QNAME = new QName("", "maligngroup");
    private final static QName _Mglyph_QNAME = new QName("", "mglyph");
    private final static QName _Sep_QNAME = new QName("", "sep");
    private final static QName _Integers_QNAME = new QName("", "integers");
    private final static QName _Reals_QNAME = new QName("", "reals");
    private final static QName _Rationals_QNAME = new QName("", "rationals");
    private final static QName _Naturalnumbers_QNAME = new QName("", "naturalnumbers");
    private final static QName _Complexes_QNAME = new QName("", "complexes");
    private final static QName _Primes_QNAME = new QName("", "primes");
    private final static QName _Exponentiale_QNAME = new QName("", "exponentiale");
    private final static QName _Imaginaryi_QNAME = new QName("", "imaginaryi");
    private final static QName _Notanumber_QNAME = new QName("", "notanumber");
    private final static QName _True_QNAME = new QName("", "true");
    private final static QName _False_QNAME = new QName("", "false");
    private final static QName _Emptyset_QNAME = new QName("", "emptyset");
    private final static QName _Pi_QNAME = new QName("", "pi");
    private final static QName _Eulergamma_QNAME = new QName("", "eulergamma");
    private final static QName _Infinity_QNAME = new QName("", "infinity");
    private final static QName _Inverse_QNAME = new QName("", "inverse");
    private final static QName _Domain_QNAME = new QName("", "domain");
    private final static QName _Codomain_QNAME = new QName("", "codomain");
    private final static QName _Image_QNAME = new QName("", "image");
    private final static QName _Ident_QNAME = new QName("", "ident");
    private final static QName _Compose_QNAME = new QName("", "compose");
    private final static QName _Exp_QNAME = new QName("", "exp");
    private final static QName _Abs_QNAME = new QName("", "abs");
    private final static QName _Arg_QNAME = new QName("", "arg");
    private final static QName _Real_QNAME = new QName("", "real");
    private final static QName _Imaginary_QNAME = new QName("", "imaginary");
    private final static QName _Conjugate_QNAME = new QName("", "conjugate");
    private final static QName _Factorial_QNAME = new QName("", "factorial");
    private final static QName _Floor_QNAME = new QName("", "floor");
    private final static QName _Ceiling_QNAME = new QName("", "ceiling");
    private final static QName _Minus_QNAME = new QName("", "minus");
    private final static QName _Quotient_QNAME = new QName("", "quotient");
    private final static QName _Divide_QNAME = new QName("", "divide");
    private final static QName _Power_QNAME = new QName("", "power");
    private final static QName _Rem_QNAME = new QName("", "rem");
    private final static QName _Plus_QNAME = new QName("", "plus");
    private final static QName _Max_QNAME = new QName("", "max");
    private final static QName _Min_QNAME = new QName("", "min");
    private final static QName _Times_QNAME = new QName("", "times");
    private final static QName _Gcd_QNAME = new QName("", "gcd");
    private final static QName _Lcm_QNAME = new QName("", "lcm");
    private final static QName _Root_QNAME = new QName("", "root");
    private final static QName _Exists_QNAME = new QName("", "exists");
    private final static QName _Forall_QNAME = new QName("", "forall");
    private final static QName _And_QNAME = new QName("", "and");
    private final static QName _Or_QNAME = new QName("", "or");
    private final static QName _Xor_QNAME = new QName("", "xor");
    private final static QName _Not_QNAME = new QName("", "not");
    private final static QName _Implies_QNAME = new QName("", "implies");
    private final static QName _Divergence_QNAME = new QName("", "divergence");
    private final static QName _Grad_QNAME = new QName("", "grad");
    private final static QName _Curl_QNAME = new QName("", "curl");
    private final static QName _Laplacian_QNAME = new QName("", "laplacian");
    private final static QName _Log_QNAME = new QName("", "log");
    private final static QName _Int_QNAME = new QName("", "int");
    private final static QName _Diff_QNAME = new QName("", "diff");
    private final static QName _Partialdiff_QNAME = new QName("", "partialdiff");
    private final static QName _Ln_QNAME = new QName("", "ln");
    private final static QName _Card_QNAME = new QName("", "card");
    private final static QName _Setdiff_QNAME = new QName("", "setdiff");
    private final static QName _Union_QNAME = new QName("", "union");
    private final static QName _Intersect_QNAME = new QName("", "intersect");
    private final static QName _Cartesianproduct_QNAME = new QName("", "cartesianproduct");
    private final static QName _Sum_QNAME = new QName("", "sum");
    private final static QName _Product_QNAME = new QName("", "product");
    private final static QName _Limit_QNAME = new QName("", "limit");
    private final static QName _Sin_QNAME = new QName("", "sin");
    private final static QName _Cos_QNAME = new QName("", "cos");
    private final static QName _Tan_QNAME = new QName("", "tan");
    private final static QName _Sec_QNAME = new QName("", "sec");
    private final static QName _Csc_QNAME = new QName("", "csc");
    private final static QName _Cot_QNAME = new QName("", "cot");
    private final static QName _Sinh_QNAME = new QName("", "sinh");
    private final static QName _Cosh_QNAME = new QName("", "cosh");
    private final static QName _Tanh_QNAME = new QName("", "tanh");
    private final static QName _Sech_QNAME = new QName("", "sech");
    private final static QName _Csch_QNAME = new QName("", "csch");
    private final static QName _Coth_QNAME = new QName("", "coth");
    private final static QName _Arcsin_QNAME = new QName("", "arcsin");
    private final static QName _Arccos_QNAME = new QName("", "arccos");
    private final static QName _Arctan_QNAME = new QName("", "arctan");
    private final static QName _Arccosh_QNAME = new QName("", "arccosh");
    private final static QName _Arccot_QNAME = new QName("", "arccot");
    private final static QName _Arccoth_QNAME = new QName("", "arccoth");
    private final static QName _Arccsc_QNAME = new QName("", "arccsc");
    private final static QName _Arccsch_QNAME = new QName("", "arccsch");
    private final static QName _Arcsec_QNAME = new QName("", "arcsec");
    private final static QName _Arcsech_QNAME = new QName("", "arcsech");
    private final static QName _Arcsinh_QNAME = new QName("", "arcsinh");
    private final static QName _Arctanh_QNAME = new QName("", "arctanh");
    private final static QName _Mean_QNAME = new QName("", "mean");
    private final static QName _Sdev_QNAME = new QName("", "sdev");
    private final static QName _Variance_QNAME = new QName("", "variance");
    private final static QName _Median_QNAME = new QName("", "median");
    private final static QName _Mode_QNAME = new QName("", "mode");
    private final static QName _Moment_QNAME = new QName("", "moment");
    private final static QName _Determinant_QNAME = new QName("", "determinant");
    private final static QName _Transpose_QNAME = new QName("", "transpose");
    private final static QName _Vectorproduct_QNAME = new QName("", "vectorproduct");
    private final static QName _Scalarproduct_QNAME = new QName("", "scalarproduct");
    private final static QName _Outerproduct_QNAME = new QName("", "outerproduct");
    private final static QName _Selector_QNAME = new QName("", "selector");
    private final static QName _Neq_QNAME = new QName("", "neq");
    private final static QName _Factorof_QNAME = new QName("", "factorof");
    private final static QName _Eq_QNAME = new QName("", "eq");
    private final static QName _Equivalent_QNAME = new QName("", "equivalent");
    private final static QName _Approx_QNAME = new QName("", "approx");
    private final static QName _Gt_QNAME = new QName("", "gt");
    private final static QName _Lt_QNAME = new QName("", "lt");
    private final static QName _Geq_QNAME = new QName("", "geq");
    private final static QName _Leq_QNAME = new QName("", "leq");
    private final static QName _In_QNAME = new QName("", "in");
    private final static QName _Notin_QNAME = new QName("", "notin");
    private final static QName _Notsubset_QNAME = new QName("", "notsubset");
    private final static QName _Notprsubset_QNAME = new QName("", "notprsubset");
    private final static QName _Subset_QNAME = new QName("", "subset");
    private final static QName _Prsubset_QNAME = new QName("", "prsubset");
    private final static QName _Tendsto_QNAME = new QName("", "tendsto");
    private final static QName _Ci_QNAME = new QName("", "ci");
    private final static QName _Csymbol_QNAME = new QName("", "csymbol");
    private final static QName _Cn_QNAME = new QName("", "cn");
    private final static QName _Apply_QNAME = new QName("", "apply");
    private final static QName _Reln_QNAME = new QName("", "reln");
    private final static QName _Lambda_QNAME = new QName("", "lambda");
    private final static QName _Condition_QNAME = new QName("", "condition");
    private final static QName _Declare_QNAME = new QName("", "declare");
    private final static QName _Semantics_QNAME = new QName("", "semantics");
    private final static QName _Annotation_QNAME = new QName("", "annotation");
    private final static QName _AnnotationXml_QNAME = new QName("", "annotation-xml");
    private final static QName _Interval_QNAME = new QName("", "interval");
    private final static QName _Set_QNAME = new QName("", "set");
    private final static QName _List_QNAME = new QName("", "list");
    private final static QName _Vector_QNAME = new QName("", "vector");
    private final static QName _Matrix_QNAME = new QName("", "matrix");
    private final static QName _Matrixrow_QNAME = new QName("", "matrixrow");
    private final static QName _Piecewise_QNAME = new QName("", "piecewise");
    private final static QName _Piece_QNAME = new QName("", "piece");
    private final static QName _Otherwise_QNAME = new QName("", "otherwise");
    private final static QName _Fn_QNAME = new QName("", "fn");
    private final static QName _Lowlimit_QNAME = new QName("", "lowlimit");
    private final static QName _Uplimit_QNAME = new QName("", "uplimit");
    private final static QName _Bvar_QNAME = new QName("", "bvar");
    private final static QName _Degree_QNAME = new QName("", "degree");
    private final static QName _Logbase_QNAME = new QName("", "logbase");
    private final static QName _Momentabout_QNAME = new QName("", "momentabout");
    private final static QName _Domainofapplication_QNAME = new QName("", "domainofapplication");
    private final static QName _Mstyle_QNAME = new QName("", "mstyle");
    private final static QName _Merror_QNAME = new QName("", "merror");
    private final static QName _Mphantom_QNAME = new QName("", "mphantom");
    private final static QName _Mrow_QNAME = new QName("", "mrow");
    private final static QName _Mfrac_QNAME = new QName("", "mfrac");
    private final static QName _Msqrt_QNAME = new QName("", "msqrt");
    private final static QName _Menclose_QNAME = new QName("", "menclose");
    private final static QName _Mroot_QNAME = new QName("", "mroot");
    private final static QName _Msub_QNAME = new QName("", "msub");
    private final static QName _Msup_QNAME = new QName("", "msup");
    private final static QName _Msubsup_QNAME = new QName("", "msubsup");
    private final static QName _Mmultiscripts_QNAME = new QName("", "mmultiscripts");
    private final static QName _Munder_QNAME = new QName("", "munder");
    private final static QName _Mover_QNAME = new QName("", "mover");
    private final static QName _Munderover_QNAME = new QName("", "munderover");
    private final static QName _Mtable_QNAME = new QName("", "mtable");
    private final static QName _Mtr_QNAME = new QName("", "mtr");
    private final static QName _Mlabeledtr_QNAME = new QName("", "mlabeledtr");
    private final static QName _Mtd_QNAME = new QName("", "mtd");
    private final static QName _Maction_QNAME = new QName("", "maction");
    private final static QName _Mfenced_QNAME = new QName("", "mfenced");
    private final static QName _Mpadded_QNAME = new QName("", "mpadded");
    private final static QName _Mi_QNAME = new QName("", "mi");
    private final static QName _Mn_QNAME = new QName("", "mn");
    private final static QName _Mo_QNAME = new QName("", "mo");
    private final static QName _Mtext_QNAME = new QName("", "mtext");
    private final static QName _Ms_QNAME = new QName("", "ms");
    private final static QName _Math_QNAME = new QName("", "math");
    private final static QName _Table_QNAME = new QName("", "table");
    private final static QName _Tgroup_QNAME = new QName("", "tgroup");
    private final static QName _Colspec_QNAME = new QName("", "colspec");
    private final static QName _Thead_QNAME = new QName("", "thead");
    private final static QName _Tbody_QNAME = new QName("", "tbody");
    private final static QName _Row_QNAME = new QName("", "row");
    private final static QName _Entry_QNAME = new QName("", "entry");
    private final static QName _Title_QNAME = new QName("", "title");
    private final static QName _WoApplicationBody_QNAME = new QName("", "wo-application-body");
    private final static QName _WoAmendedClaims_QNAME = new QName("", "wo-amended-claims");
    private final static QName _ReplaceObject_QNAME = new QName("", "replace-object");
    private final static QName _InsertAfterObject_QNAME = new QName("", "insert-after-object");
    private final static QName _InsertBeforeObject_QNAME = new QName("", "insert-before-object");
    private final static QName _DeleteObject_QNAME = new QName("", "delete-object");
    private final static QName _AmendBody_QNAME = new QName("", "amend-body");
    private final static QName _Drawings_QNAME = new QName("", "drawings");
    private final static QName _Figure_QNAME = new QName("", "figure");
    private final static QName _Abstract_QNAME = new QName("", "abstract");
    private final static QName _AbstSolution_QNAME = new QName("", "abst-solution");
    private final static QName _AbstProblem_QNAME = new QName("", "abst-problem");
    private final static QName _AmendStatement_QNAME = new QName("", "amend-statement");
    private final static QName _Claims_QNAME = new QName("", "claims");
    private final static QName _Claim_QNAME = new QName("", "claim");
    private final static QName _ClaimRef_QNAME = new QName("", "claim-ref");
    private final static QName _Description_QNAME = new QName("", "description");
    private final static QName _CitationList_QNAME = new QName("", "citation-list");
    private final static QName _NonPatentLiterature_QNAME = new QName("", "non-patent-literature");
    private final static QName _PatentLiterature_QNAME = new QName("", "patent-literature");
    private final static QName _SequenceListText_QNAME = new QName("", "sequence-list-text");
    private final static QName _ReferenceToDepositedBiologicalMaterial_QNAME = new QName("", "reference-to-deposited-biological-material");
    private final static QName _ReferenceSignsList_QNAME = new QName("", "reference-signs-list");
    private final static QName _IndustrialApplicability_QNAME = new QName("", "industrial-applicability");
    private final static QName _ModeForInvention_QNAME = new QName("", "mode-for-invention");
    private final static QName _BestMode_QNAME = new QName("", "best-mode");
    private final static QName _DescriptionOfEmbodiments_QNAME = new QName("", "description-of-embodiments");
    private final static QName _EmbodimentsExample_QNAME = new QName("", "embodiments-example");
    private final static QName _DescriptionOfDrawings_QNAME = new QName("", "description-of-drawings");
    private final static QName _SummaryOfInvention_QNAME = new QName("", "summary-of-invention");
    private final static QName _Disclosure_QNAME = new QName("", "disclosure");
    private final static QName _AdvantageousEffects_QNAME = new QName("", "advantageous-effects");
    private final static QName _TechSolution_QNAME = new QName("", "tech-solution");
    private final static QName _TechProblem_QNAME = new QName("", "tech-problem");
    private final static QName _BackgroundArt_QNAME = new QName("", "background-art");
    private final static QName _TechnicalField_QNAME = new QName("", "technical-field");
    private final static QName _P_QNAME = new QName("", "p");
    private final static QName _TableExternalDoc_QNAME = new QName("", "table-external-doc");
    private final static QName _Tables_QNAME = new QName("", "tables");
    private final static QName _Dl_QNAME = new QName("", "dl");
    private final static QName _Dt_QNAME = new QName("", "dt");
    private final static QName _Ul_QNAME = new QName("", "ul");
    private final static QName _Li_QNAME = new QName("", "li");
    private final static QName _Maths_QNAME = new QName("", "maths");
    private final static QName _Chemistry_QNAME = new QName("", "chemistry");
    private final static QName _Chem_QNAME = new QName("", "chem");
    private final static QName _Ol_QNAME = new QName("", "ol");
    private final static QName _Img_QNAME = new QName("", "img");
    private final static QName _Figref_QNAME = new QName("", "figref");
    private final static QName _Crossref_QNAME = new QName("", "crossref");
    private final static QName _BioDeposit_QNAME = new QName("", "bio-deposit");
    private final static QName _Nplcit_QNAME = new QName("", "nplcit");
    private final static QName _Refno_QNAME = new QName("", "refno");
    private final static QName _Class_QNAME = new QName("", "class");
    private final static QName _Subname_QNAME = new QName("", "subname");
    private final static QName _Author_QNAME = new QName("", "author");
    private final static QName _Addressbook_QNAME = new QName("", "addressbook");
    private final static QName _Email_QNAME = new QName("", "email");
    private final static QName _Patcit_QNAME = new QName("", "patcit");
    private final static QName _Pre_QNAME = new QName("", "pre");
    private final static QName _Heading_QNAME = new QName("", "heading");
    private final static QName _InventionTitle_QNAME = new QName("", "invention-title");
    private final static QName _U_QNAME = new QName("", "u");
    private final static QName _O_QNAME = new QName("", "o");
    private final static QName _DocPage_QNAME = new QName("", "doc-page");
    private final static QName _ApplicationReference_QNAME = new QName("", "application-reference");
    private final static QName _IsrStatus_QNAME = new QName("", "isr-status");
    private final static QName _WoDtext_QNAME = new QName("", "wo-dtext");
    private final static QName _PublicationReference_QNAME = new QName("", "publication-reference");
    private final static QName _DocumentId_QNAME = new QName("", "document-id");
    private final static QName _Name_QNAME = new QName("", "name");
    private final static QName _Statement_QNAME = new QName("", "statement");
    private final static QName _ClaimText_QNAME = new QName("", "claim-text");
    private final static QName _Dd_QNAME = new QName("", "dd");
    private final static QName _Term_QNAME = new QName("", "term");
    private final static QName _BioAccno_QNAME = new QName("", "bio-accno");
    private final static QName _Depositary_QNAME = new QName("", "depositary");
    private final static QName _Othercit_QNAME = new QName("", "othercit");
    private final static QName _Online_QNAME = new QName("", "online");
    private final static QName _Srchdate_QNAME = new QName("", "srchdate");
    private final static QName _Srchterm_QNAME = new QName("", "srchterm");
    private final static QName _Datecit_QNAME = new QName("", "datecit");
    private final static QName _Avail_QNAME = new QName("", "avail");
    private final static QName _Hostno_QNAME = new QName("", "hostno");
    private final static QName _History_QNAME = new QName("", "history");
    private final static QName _Misc_QNAME = new QName("", "misc");
    private final static QName _Revised_QNAME = new QName("", "revised");
    private final static QName _Accepted_QNAME = new QName("", "accepted");
    private final static QName _Received_QNAME = new QName("", "received");
    private final static QName _Hosttitle_QNAME = new QName("", "hosttitle");
    private final static QName _OnlineTitle_QNAME = new QName("", "online-title");
    private final static QName _Article_QNAME = new QName("", "article");
    private final static QName _Artid_QNAME = new QName("", "artid");
    private final static QName _Book_QNAME = new QName("", "book");
    private final static QName _Keyword_QNAME = new QName("", "keyword");
    private final static QName _Bookno_QNAME = new QName("", "bookno");
    private final static QName _Location_QNAME = new QName("", "location");
    private final static QName _Line_QNAME = new QName("", "line");
    private final static QName _Linel_QNAME = new QName("", "linel");
    private final static QName _Linef_QNAME = new QName("", "linef");
    private final static QName _Para_QNAME = new QName("", "para");
    private final static QName _Paral_QNAME = new QName("", "paral");
    private final static QName _Paraf_QNAME = new QName("", "paraf");
    private final static QName _Column_QNAME = new QName("", "column");
    private final static QName _Coll_QNAME = new QName("", "coll");
    private final static QName _Colf_QNAME = new QName("", "colf");
    private final static QName _Pp_QNAME = new QName("", "pp");
    private final static QName _Ppl_QNAME = new QName("", "ppl");
    private final static QName _Ppf_QNAME = new QName("", "ppf");
    private final static QName _Chapter_QNAME = new QName("", "chapter");
    private final static QName _Sersect_QNAME = new QName("", "sersect");
    private final static QName _Serpart_QNAME = new QName("", "serpart");
    private final static QName _Absno_QNAME = new QName("", "absno");
    private final static QName _Series_QNAME = new QName("", "series");
    private final static QName _Msn_QNAME = new QName("", "msn");
    private final static QName _Mst_QNAME = new QName("", "mst");
    private final static QName _Edition_QNAME = new QName("", "edition");
    private final static QName _Subtitle_QNAME = new QName("", "subtitle");
    private final static QName _Conference_QNAME = new QName("", "conference");
    private final static QName _Confdate_QNAME = new QName("", "confdate");
    private final static QName _Confsponsor_QNAME = new QName("", "confsponsor");
    private final static QName _Confplace_QNAME = new QName("", "confplace");
    private final static QName _Confno_QNAME = new QName("", "confno");
    private final static QName _Conftitle_QNAME = new QName("", "conftitle");
    private final static QName _BookTitle_QNAME = new QName("", "book-title");
    private final static QName _Serial_QNAME = new QName("", "serial");
    private final static QName _Doi_QNAME = new QName("", "doi");
    private final static QName _Cpyrt_QNAME = new QName("", "cpyrt");
    private final static QName _Ino_QNAME = new QName("", "ino");
    private final static QName _Vid_QNAME = new QName("", "vid");
    private final static QName _Pubid_QNAME = new QName("", "pubid");
    private final static QName _Isbn_QNAME = new QName("", "isbn");
    private final static QName _Issn_QNAME = new QName("", "issn");
    private final static QName _Notes_QNAME = new QName("", "notes");
    private final static QName _Descrip_QNAME = new QName("", "descrip");
    private final static QName _Imprint_QNAME = new QName("", "imprint");
    private final static QName _Pubdate_QNAME = new QName("", "pubdate");
    private final static QName _Time_QNAME = new QName("", "time");
    private final static QName _Edate_QNAME = new QName("", "edate");
    private final static QName _Sdate_QNAME = new QName("", "sdate");
    private final static QName _Issue_QNAME = new QName("", "issue");
    private final static QName _Alttitle_QNAME = new QName("", "alttitle");
    private final static QName _Sertitle_QNAME = new QName("", "sertitle");
    private final static QName _Atl_QNAME = new QName("", "atl");
    private final static QName _Url_QNAME = new QName("", "url");
    private final static QName _Fax_QNAME = new QName("", "fax");
    private final static QName _Phone_QNAME = new QName("", "phone");
    private final static QName _Ead_QNAME = new QName("", "ead");
    private final static QName _Address_QNAME = new QName("", "address");
    private final static QName _Postcode_QNAME = new QName("", "postcode");
    private final static QName _State_QNAME = new QName("", "state");
    private final static QName _County_QNAME = new QName("", "county");
    private final static QName _City_QNAME = new QName("", "city");
    private final static QName _Street_QNAME = new QName("", "street");
    private final static QName _Building_QNAME = new QName("", "building");
    private final static QName _AddressFloor_QNAME = new QName("", "address-floor");
    private final static QName _Room_QNAME = new QName("", "room");
    private final static QName _Pobox_QNAME = new QName("", "pobox");
    private final static QName _Mailcode_QNAME = new QName("", "mailcode");
    private final static QName _Address5_QNAME = new QName("", "address-5");
    private final static QName _Address4_QNAME = new QName("", "address-4");
    private final static QName _Address3_QNAME = new QName("", "address-3");
    private final static QName _Address2_QNAME = new QName("", "address-2");
    private final static QName _Address1_QNAME = new QName("", "address-1");
    private final static QName _RegisteredNumber_QNAME = new QName("", "registered-number");
    private final static QName _Synonym_QNAME = new QName("", "synonym");
    private final static QName _Department_QNAME = new QName("", "department");
    private final static QName _Orgname_QNAME = new QName("", "orgname");
    private final static QName _Role_QNAME = new QName("", "role");
    private final static QName _Iid_QNAME = new QName("", "iid");
    private final static QName _Suffix_QNAME = new QName("", "suffix");
    private final static QName _MiddleName_QNAME = new QName("", "middle-name");
    private final static QName _FirstName_QNAME = new QName("", "first-name");
    private final static QName _LastName_QNAME = new QName("", "last-name");
    private final static QName _Prefix_QNAME = new QName("", "prefix");
    private final static QName _RelPassage_QNAME = new QName("", "rel-passage");
    private final static QName _RelClaims_QNAME = new QName("", "rel-claims");
    private final static QName _Category_QNAME = new QName("", "category");
    private final static QName _Passage_QNAME = new QName("", "passage");
    private final static QName _Text_QNAME = new QName("", "text");
    private final static QName _B_QNAME = new QName("", "b");
    private final static QName _I_QNAME = new QName("", "i");
    private final static QName _Smallcaps_QNAME = new QName("", "smallcaps");
    private final static QName _Sub_QNAME = new QName("", "sub");
    private final static QName _Sup_QNAME = new QName("", "sup");
    private final static QName _Sub2_QNAME = new QName("", "sub2");
    private final static QName _Sup2_QNAME = new QName("", "sup2");
    private final static QName _WoPublicationInfo_QNAME = new QName("", "wo-publication-info");
    private final static QName _WoPubnum_QNAME = new QName("", "wo-pubnum");
    private final static QName _PctPubInfo_QNAME = new QName("", "pct-pub-info");
    private final static QName _WoPublishedText_QNAME = new QName("", "wo-published-text");
    private final static QName _WoTextLetterCode_QNAME = new QName("", "wo-text-letter-code");
    private final static QName _PctArt64_QNAME = new QName("", "pct-art64");
    private final static QName _WoBioMaterialAfterPub_QNAME = new QName("", "wo-bio-material-after-pub");
    private final static QName _RelevantDate_QNAME = new QName("", "relevant-date");
    private final static QName _ReceivedAtIb_QNAME = new QName("", "received-at-ib");
    private final static QName _WoCorrection_QNAME = new QName("", "wo-correction");
    private final static QName _Dtext_QNAME = new QName("", "dtext");
    private final static QName _Br_QNAME = new QName("", "br");
    private final static QName _WoRepubCode_QNAME = new QName("", "wo-repub-code");
    private final static QName _TypeOfCorrection_QNAME = new QName("", "type-of-correction");
    private final static QName _Date_QNAME = new QName("", "date");
    private final static QName _Kind_QNAME = new QName("", "kind");
    private final static QName _DocNumber_QNAME = new QName("", "doc-number");
    private final static QName _Country_QNAME = new QName("", "country");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: wipo.jaxb.ApplicationBody
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Mspace }
     * 
     */
    public Mspace createMspace() {
        return new Mspace();
    }

    /**
     * Create an instance of {@link Mprescripts }
     * 
     */
    public Mprescripts createMprescripts() {
        return new Mprescripts();
    }

    /**
     * Create an instance of {@link None }
     * 
     */
    public None createNone() {
        return new None();
    }

    /**
     * Create an instance of {@link Malignmark }
     * 
     */
    public Malignmark createMalignmark() {
        return new Malignmark();
    }

    /**
     * Create an instance of {@link Maligngroup }
     * 
     */
    public Maligngroup createMaligngroup() {
        return new Maligngroup();
    }

    /**
     * Create an instance of {@link Mglyph }
     * 
     */
    public Mglyph createMglyph() {
        return new Mglyph();
    }

    /**
     * Create an instance of {@link Sep }
     * 
     */
    public Sep createSep() {
        return new Sep();
    }

    /**
     * Create an instance of {@link Integers }
     * 
     */
    public Integers createIntegers() {
        return new Integers();
    }

    /**
     * Create an instance of {@link Reals }
     * 
     */
    public Reals createReals() {
        return new Reals();
    }

    /**
     * Create an instance of {@link Rationals }
     * 
     */
    public Rationals createRationals() {
        return new Rationals();
    }

    /**
     * Create an instance of {@link Naturalnumbers }
     * 
     */
    public Naturalnumbers createNaturalnumbers() {
        return new Naturalnumbers();
    }

    /**
     * Create an instance of {@link Complexes }
     * 
     */
    public Complexes createComplexes() {
        return new Complexes();
    }

    /**
     * Create an instance of {@link Primes }
     * 
     */
    public Primes createPrimes() {
        return new Primes();
    }

    /**
     * Create an instance of {@link Exponentiale }
     * 
     */
    public Exponentiale createExponentiale() {
        return new Exponentiale();
    }

    /**
     * Create an instance of {@link Imaginaryi }
     * 
     */
    public Imaginaryi createImaginaryi() {
        return new Imaginaryi();
    }

    /**
     * Create an instance of {@link Notanumber }
     * 
     */
    public Notanumber createNotanumber() {
        return new Notanumber();
    }

    /**
     * Create an instance of {@link True }
     * 
     */
    public True createTrue() {
        return new True();
    }

    /**
     * Create an instance of {@link False }
     * 
     */
    public False createFalse() {
        return new False();
    }

    /**
     * Create an instance of {@link Emptyset }
     * 
     */
    public Emptyset createEmptyset() {
        return new Emptyset();
    }

    /**
     * Create an instance of {@link Pi }
     * 
     */
    public Pi createPi() {
        return new Pi();
    }

    /**
     * Create an instance of {@link Eulergamma }
     * 
     */
    public Eulergamma createEulergamma() {
        return new Eulergamma();
    }

    /**
     * Create an instance of {@link Infinity }
     * 
     */
    public Infinity createInfinity() {
        return new Infinity();
    }

    /**
     * Create an instance of {@link Inverse }
     * 
     */
    public Inverse createInverse() {
        return new Inverse();
    }

    /**
     * Create an instance of {@link Domain }
     * 
     */
    public Domain createDomain() {
        return new Domain();
    }

    /**
     * Create an instance of {@link Codomain }
     * 
     */
    public Codomain createCodomain() {
        return new Codomain();
    }

    /**
     * Create an instance of {@link Image }
     * 
     */
    public Image createImage() {
        return new Image();
    }

    /**
     * Create an instance of {@link Ident }
     * 
     */
    public Ident createIdent() {
        return new Ident();
    }

    /**
     * Create an instance of {@link Compose }
     * 
     */
    public Compose createCompose() {
        return new Compose();
    }

    /**
     * Create an instance of {@link Exp }
     * 
     */
    public Exp createExp() {
        return new Exp();
    }

    /**
     * Create an instance of {@link Abs }
     * 
     */
    public Abs createAbs() {
        return new Abs();
    }

    /**
     * Create an instance of {@link Arg }
     * 
     */
    public Arg createArg() {
        return new Arg();
    }

    /**
     * Create an instance of {@link Real }
     * 
     */
    public Real createReal() {
        return new Real();
    }

    /**
     * Create an instance of {@link Imaginary }
     * 
     */
    public Imaginary createImaginary() {
        return new Imaginary();
    }

    /**
     * Create an instance of {@link Conjugate }
     * 
     */
    public Conjugate createConjugate() {
        return new Conjugate();
    }

    /**
     * Create an instance of {@link Factorial }
     * 
     */
    public Factorial createFactorial() {
        return new Factorial();
    }

    /**
     * Create an instance of {@link Floor }
     * 
     */
    public Floor createFloor() {
        return new Floor();
    }

    /**
     * Create an instance of {@link Ceiling }
     * 
     */
    public Ceiling createCeiling() {
        return new Ceiling();
    }

    /**
     * Create an instance of {@link Minus }
     * 
     */
    public Minus createMinus() {
        return new Minus();
    }

    /**
     * Create an instance of {@link Quotient }
     * 
     */
    public Quotient createQuotient() {
        return new Quotient();
    }

    /**
     * Create an instance of {@link Divide }
     * 
     */
    public Divide createDivide() {
        return new Divide();
    }

    /**
     * Create an instance of {@link Power }
     * 
     */
    public Power createPower() {
        return new Power();
    }

    /**
     * Create an instance of {@link Rem }
     * 
     */
    public Rem createRem() {
        return new Rem();
    }

    /**
     * Create an instance of {@link Plus }
     * 
     */
    public Plus createPlus() {
        return new Plus();
    }

    /**
     * Create an instance of {@link Max }
     * 
     */
    public Max createMax() {
        return new Max();
    }

    /**
     * Create an instance of {@link Min }
     * 
     */
    public Min createMin() {
        return new Min();
    }

    /**
     * Create an instance of {@link Times }
     * 
     */
    public Times createTimes() {
        return new Times();
    }

    /**
     * Create an instance of {@link Gcd }
     * 
     */
    public Gcd createGcd() {
        return new Gcd();
    }

    /**
     * Create an instance of {@link Lcm }
     * 
     */
    public Lcm createLcm() {
        return new Lcm();
    }

    /**
     * Create an instance of {@link Root }
     * 
     */
    public Root createRoot() {
        return new Root();
    }

    /**
     * Create an instance of {@link Exists }
     * 
     */
    public Exists createExists() {
        return new Exists();
    }

    /**
     * Create an instance of {@link Forall }
     * 
     */
    public Forall createForall() {
        return new Forall();
    }

    /**
     * Create an instance of {@link And }
     * 
     */
    public And createAnd() {
        return new And();
    }

    /**
     * Create an instance of {@link Or }
     * 
     */
    public Or createOr() {
        return new Or();
    }

    /**
     * Create an instance of {@link Xor }
     * 
     */
    public Xor createXor() {
        return new Xor();
    }

    /**
     * Create an instance of {@link Not }
     * 
     */
    public Not createNot() {
        return new Not();
    }

    /**
     * Create an instance of {@link Implies }
     * 
     */
    public Implies createImplies() {
        return new Implies();
    }

    /**
     * Create an instance of {@link Divergence }
     * 
     */
    public Divergence createDivergence() {
        return new Divergence();
    }

    /**
     * Create an instance of {@link Grad }
     * 
     */
    public Grad createGrad() {
        return new Grad();
    }

    /**
     * Create an instance of {@link Curl }
     * 
     */
    public Curl createCurl() {
        return new Curl();
    }

    /**
     * Create an instance of {@link Laplacian }
     * 
     */
    public Laplacian createLaplacian() {
        return new Laplacian();
    }

    /**
     * Create an instance of {@link Log }
     * 
     */
    public Log createLog() {
        return new Log();
    }

    /**
     * Create an instance of {@link Int }
     * 
     */
    public Int createInt() {
        return new Int();
    }

    /**
     * Create an instance of {@link Diff }
     * 
     */
    public Diff createDiff() {
        return new Diff();
    }

    /**
     * Create an instance of {@link Partialdiff }
     * 
     */
    public Partialdiff createPartialdiff() {
        return new Partialdiff();
    }

    /**
     * Create an instance of {@link Ln }
     * 
     */
    public Ln createLn() {
        return new Ln();
    }

    /**
     * Create an instance of {@link Card }
     * 
     */
    public Card createCard() {
        return new Card();
    }

    /**
     * Create an instance of {@link Setdiff }
     * 
     */
    public Setdiff createSetdiff() {
        return new Setdiff();
    }

    /**
     * Create an instance of {@link Union }
     * 
     */
    public Union createUnion() {
        return new Union();
    }

    /**
     * Create an instance of {@link Intersect }
     * 
     */
    public Intersect createIntersect() {
        return new Intersect();
    }

    /**
     * Create an instance of {@link Cartesianproduct }
     * 
     */
    public Cartesianproduct createCartesianproduct() {
        return new Cartesianproduct();
    }

    /**
     * Create an instance of {@link Sum }
     * 
     */
    public Sum createSum() {
        return new Sum();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link Limit }
     * 
     */
    public Limit createLimit() {
        return new Limit();
    }

    /**
     * Create an instance of {@link Sin }
     * 
     */
    public Sin createSin() {
        return new Sin();
    }

    /**
     * Create an instance of {@link Cos }
     * 
     */
    public Cos createCos() {
        return new Cos();
    }

    /**
     * Create an instance of {@link Tan }
     * 
     */
    public Tan createTan() {
        return new Tan();
    }

    /**
     * Create an instance of {@link Sec }
     * 
     */
    public Sec createSec() {
        return new Sec();
    }

    /**
     * Create an instance of {@link Csc }
     * 
     */
    public Csc createCsc() {
        return new Csc();
    }

    /**
     * Create an instance of {@link Cot }
     * 
     */
    public Cot createCot() {
        return new Cot();
    }

    /**
     * Create an instance of {@link Sinh }
     * 
     */
    public Sinh createSinh() {
        return new Sinh();
    }

    /**
     * Create an instance of {@link Cosh }
     * 
     */
    public Cosh createCosh() {
        return new Cosh();
    }

    /**
     * Create an instance of {@link Tanh }
     * 
     */
    public Tanh createTanh() {
        return new Tanh();
    }

    /**
     * Create an instance of {@link Sech }
     * 
     */
    public Sech createSech() {
        return new Sech();
    }

    /**
     * Create an instance of {@link Csch }
     * 
     */
    public Csch createCsch() {
        return new Csch();
    }

    /**
     * Create an instance of {@link Coth }
     * 
     */
    public Coth createCoth() {
        return new Coth();
    }

    /**
     * Create an instance of {@link Arcsin }
     * 
     */
    public Arcsin createArcsin() {
        return new Arcsin();
    }

    /**
     * Create an instance of {@link Arccos }
     * 
     */
    public Arccos createArccos() {
        return new Arccos();
    }

    /**
     * Create an instance of {@link Arctan }
     * 
     */
    public Arctan createArctan() {
        return new Arctan();
    }

    /**
     * Create an instance of {@link Arccosh }
     * 
     */
    public Arccosh createArccosh() {
        return new Arccosh();
    }

    /**
     * Create an instance of {@link Arccot }
     * 
     */
    public Arccot createArccot() {
        return new Arccot();
    }

    /**
     * Create an instance of {@link Arccoth }
     * 
     */
    public Arccoth createArccoth() {
        return new Arccoth();
    }

    /**
     * Create an instance of {@link Arccsc }
     * 
     */
    public Arccsc createArccsc() {
        return new Arccsc();
    }

    /**
     * Create an instance of {@link Arccsch }
     * 
     */
    public Arccsch createArccsch() {
        return new Arccsch();
    }

    /**
     * Create an instance of {@link Arcsec }
     * 
     */
    public Arcsec createArcsec() {
        return new Arcsec();
    }

    /**
     * Create an instance of {@link Arcsech }
     * 
     */
    public Arcsech createArcsech() {
        return new Arcsech();
    }

    /**
     * Create an instance of {@link Arcsinh }
     * 
     */
    public Arcsinh createArcsinh() {
        return new Arcsinh();
    }

    /**
     * Create an instance of {@link Arctanh }
     * 
     */
    public Arctanh createArctanh() {
        return new Arctanh();
    }

    /**
     * Create an instance of {@link Mean }
     * 
     */
    public Mean createMean() {
        return new Mean();
    }

    /**
     * Create an instance of {@link Sdev }
     * 
     */
    public Sdev createSdev() {
        return new Sdev();
    }

    /**
     * Create an instance of {@link Variance }
     * 
     */
    public Variance createVariance() {
        return new Variance();
    }

    /**
     * Create an instance of {@link Median }
     * 
     */
    public Median createMedian() {
        return new Median();
    }

    /**
     * Create an instance of {@link Mode }
     * 
     */
    public Mode createMode() {
        return new Mode();
    }

    /**
     * Create an instance of {@link Moment }
     * 
     */
    public Moment createMoment() {
        return new Moment();
    }

    /**
     * Create an instance of {@link Determinant }
     * 
     */
    public Determinant createDeterminant() {
        return new Determinant();
    }

    /**
     * Create an instance of {@link Transpose }
     * 
     */
    public Transpose createTranspose() {
        return new Transpose();
    }

    /**
     * Create an instance of {@link Vectorproduct }
     * 
     */
    public Vectorproduct createVectorproduct() {
        return new Vectorproduct();
    }

    /**
     * Create an instance of {@link Scalarproduct }
     * 
     */
    public Scalarproduct createScalarproduct() {
        return new Scalarproduct();
    }

    /**
     * Create an instance of {@link Outerproduct }
     * 
     */
    public Outerproduct createOuterproduct() {
        return new Outerproduct();
    }

    /**
     * Create an instance of {@link Selector }
     * 
     */
    public Selector createSelector() {
        return new Selector();
    }

    /**
     * Create an instance of {@link Neq }
     * 
     */
    public Neq createNeq() {
        return new Neq();
    }

    /**
     * Create an instance of {@link Factorof }
     * 
     */
    public Factorof createFactorof() {
        return new Factorof();
    }

    /**
     * Create an instance of {@link Eq }
     * 
     */
    public Eq createEq() {
        return new Eq();
    }

    /**
     * Create an instance of {@link Equivalent }
     * 
     */
    public Equivalent createEquivalent() {
        return new Equivalent();
    }

    /**
     * Create an instance of {@link Approx }
     * 
     */
    public Approx createApprox() {
        return new Approx();
    }

    /**
     * Create an instance of {@link Gt }
     * 
     */
    public Gt createGt() {
        return new Gt();
    }

    /**
     * Create an instance of {@link Lt }
     * 
     */
    public Lt createLt() {
        return new Lt();
    }

    /**
     * Create an instance of {@link Geq }
     * 
     */
    public Geq createGeq() {
        return new Geq();
    }

    /**
     * Create an instance of {@link Leq }
     * 
     */
    public Leq createLeq() {
        return new Leq();
    }

    /**
     * Create an instance of {@link In }
     * 
     */
    public In createIn() {
        return new In();
    }

    /**
     * Create an instance of {@link Notin }
     * 
     */
    public Notin createNotin() {
        return new Notin();
    }

    /**
     * Create an instance of {@link Notsubset }
     * 
     */
    public Notsubset createNotsubset() {
        return new Notsubset();
    }

    /**
     * Create an instance of {@link Notprsubset }
     * 
     */
    public Notprsubset createNotprsubset() {
        return new Notprsubset();
    }

    /**
     * Create an instance of {@link Subset }
     * 
     */
    public Subset createSubset() {
        return new Subset();
    }

    /**
     * Create an instance of {@link Prsubset }
     * 
     */
    public Prsubset createPrsubset() {
        return new Prsubset();
    }

    /**
     * Create an instance of {@link Tendsto }
     * 
     */
    public Tendsto createTendsto() {
        return new Tendsto();
    }

    /**
     * Create an instance of {@link Ci }
     * 
     */
    public Ci createCi() {
        return new Ci();
    }

    /**
     * Create an instance of {@link Csymbol }
     * 
     */
    public Csymbol createCsymbol() {
        return new Csymbol();
    }

    /**
     * Create an instance of {@link Cn }
     * 
     */
    public Cn createCn() {
        return new Cn();
    }

    /**
     * Create an instance of {@link Apply }
     * 
     */
    public Apply createApply() {
        return new Apply();
    }

    /**
     * Create an instance of {@link Reln }
     * 
     */
    public Reln createReln() {
        return new Reln();
    }

    /**
     * Create an instance of {@link Lambda }
     * 
     */
    public Lambda createLambda() {
        return new Lambda();
    }

    /**
     * Create an instance of {@link Condition }
     * 
     */
    public Condition createCondition() {
        return new Condition();
    }

    /**
     * Create an instance of {@link Declare }
     * 
     */
    public Declare createDeclare() {
        return new Declare();
    }

    /**
     * Create an instance of {@link Semantics }
     * 
     */
    public Semantics createSemantics() {
        return new Semantics();
    }

    /**
     * Create an instance of {@link Annotation }
     * 
     */
    public Annotation createAnnotation() {
        return new Annotation();
    }

    /**
     * Create an instance of {@link AnnotationXml }
     * 
     */
    public AnnotationXml createAnnotationXml() {
        return new AnnotationXml();
    }

    /**
     * Create an instance of {@link Interval }
     * 
     */
    public Interval createInterval() {
        return new Interval();
    }

    /**
     * Create an instance of {@link Set }
     * 
     */
    public Set createSet() {
        return new Set();
    }

    /**
     * Create an instance of {@link List }
     * 
     */
    public List createList() {
        return new List();
    }

    /**
     * Create an instance of {@link Vector }
     * 
     */
    public Vector createVector() {
        return new Vector();
    }

    /**
     * Create an instance of {@link Matrix }
     * 
     */
    public Matrix createMatrix() {
        return new Matrix();
    }

    /**
     * Create an instance of {@link Matrixrow }
     * 
     */
    public Matrixrow createMatrixrow() {
        return new Matrixrow();
    }

    /**
     * Create an instance of {@link Piecewise }
     * 
     */
    public Piecewise createPiecewise() {
        return new Piecewise();
    }

    /**
     * Create an instance of {@link Piece }
     * 
     */
    public Piece createPiece() {
        return new Piece();
    }

    /**
     * Create an instance of {@link Otherwise }
     * 
     */
    public Otherwise createOtherwise() {
        return new Otherwise();
    }

    /**
     * Create an instance of {@link Fn }
     * 
     */
    public Fn createFn() {
        return new Fn();
    }

    /**
     * Create an instance of {@link Lowlimit }
     * 
     */
    public Lowlimit createLowlimit() {
        return new Lowlimit();
    }

    /**
     * Create an instance of {@link Uplimit }
     * 
     */
    public Uplimit createUplimit() {
        return new Uplimit();
    }

    /**
     * Create an instance of {@link Bvar }
     * 
     */
    public Bvar createBvar() {
        return new Bvar();
    }

    /**
     * Create an instance of {@link Degree }
     * 
     */
    public Degree createDegree() {
        return new Degree();
    }

    /**
     * Create an instance of {@link Logbase }
     * 
     */
    public Logbase createLogbase() {
        return new Logbase();
    }

    /**
     * Create an instance of {@link Momentabout }
     * 
     */
    public Momentabout createMomentabout() {
        return new Momentabout();
    }

    /**
     * Create an instance of {@link Domainofapplication }
     * 
     */
    public Domainofapplication createDomainofapplication() {
        return new Domainofapplication();
    }

    /**
     * Create an instance of {@link Mstyle }
     * 
     */
    public Mstyle createMstyle() {
        return new Mstyle();
    }

    /**
     * Create an instance of {@link Merror }
     * 
     */
    public Merror createMerror() {
        return new Merror();
    }

    /**
     * Create an instance of {@link Mphantom }
     * 
     */
    public Mphantom createMphantom() {
        return new Mphantom();
    }

    /**
     * Create an instance of {@link Mrow }
     * 
     */
    public Mrow createMrow() {
        return new Mrow();
    }

    /**
     * Create an instance of {@link Mfrac }
     * 
     */
    public Mfrac createMfrac() {
        return new Mfrac();
    }

    /**
     * Create an instance of {@link Msqrt }
     * 
     */
    public Msqrt createMsqrt() {
        return new Msqrt();
    }

    /**
     * Create an instance of {@link Menclose }
     * 
     */
    public Menclose createMenclose() {
        return new Menclose();
    }

    /**
     * Create an instance of {@link Mroot }
     * 
     */
    public Mroot createMroot() {
        return new Mroot();
    }

    /**
     * Create an instance of {@link Msub }
     * 
     */
    public Msub createMsub() {
        return new Msub();
    }

    /**
     * Create an instance of {@link Msup }
     * 
     */
    public Msup createMsup() {
        return new Msup();
    }

    /**
     * Create an instance of {@link Msubsup }
     * 
     */
    public Msubsup createMsubsup() {
        return new Msubsup();
    }

    /**
     * Create an instance of {@link Mmultiscripts }
     * 
     */
    public Mmultiscripts createMmultiscripts() {
        return new Mmultiscripts();
    }

    /**
     * Create an instance of {@link Munder }
     * 
     */
    public Munder createMunder() {
        return new Munder();
    }

    /**
     * Create an instance of {@link Mover }
     * 
     */
    public Mover createMover() {
        return new Mover();
    }

    /**
     * Create an instance of {@link Munderover }
     * 
     */
    public Munderover createMunderover() {
        return new Munderover();
    }

    /**
     * Create an instance of {@link Mtable }
     * 
     */
    public Mtable createMtable() {
        return new Mtable();
    }

    /**
     * Create an instance of {@link Mtr }
     * 
     */
    public Mtr createMtr() {
        return new Mtr();
    }

    /**
     * Create an instance of {@link Mlabeledtr }
     * 
     */
    public Mlabeledtr createMlabeledtr() {
        return new Mlabeledtr();
    }

    /**
     * Create an instance of {@link Mtd }
     * 
     */
    public Mtd createMtd() {
        return new Mtd();
    }

    /**
     * Create an instance of {@link Maction }
     * 
     */
    public Maction createMaction() {
        return new Maction();
    }

    /**
     * Create an instance of {@link Mfenced }
     * 
     */
    public Mfenced createMfenced() {
        return new Mfenced();
    }

    /**
     * Create an instance of {@link Mpadded }
     * 
     */
    public Mpadded createMpadded() {
        return new Mpadded();
    }

    /**
     * Create an instance of {@link Mi }
     * 
     */
    public Mi createMi() {
        return new Mi();
    }

    /**
     * Create an instance of {@link Mn }
     * 
     */
    public Mn createMn() {
        return new Mn();
    }

    /**
     * Create an instance of {@link Mo }
     * 
     */
    public Mo createMo() {
        return new Mo();
    }

    /**
     * Create an instance of {@link Mtext }
     * 
     */
    public Mtext createMtext() {
        return new Mtext();
    }

    /**
     * Create an instance of {@link Ms }
     * 
     */
    public Ms createMs() {
        return new Ms();
    }

    /**
     * Create an instance of {@link Math }
     * 
     */
    public Math createMath() {
        return new Math();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link Tgroup }
     * 
     */
    public Tgroup createTgroup() {
        return new Tgroup();
    }

    /**
     * Create an instance of {@link Colspec }
     * 
     */
    public Colspec createColspec() {
        return new Colspec();
    }

    /**
     * Create an instance of {@link Thead }
     * 
     */
    public Thead createThead() {
        return new Thead();
    }

    /**
     * Create an instance of {@link Tbody }
     * 
     */
    public Tbody createTbody() {
        return new Tbody();
    }

    /**
     * Create an instance of {@link Row }
     * 
     */
    public Row createRow() {
        return new Row();
    }

    /**
     * Create an instance of {@link Entry }
     * 
     */
    public Entry createEntry() {
        return new Entry();
    }

    /**
     * Create an instance of {@link Title }
     * 
     */
    public Title createTitle() {
        return new Title();
    }

    /**
     * Create an instance of {@link WoApplicationBody }
     * 
     */
    public WoApplicationBody createWoApplicationBody() {
        return new WoApplicationBody();
    }

    /**
     * Create an instance of {@link WoAmendedClaims }
     * 
     */
    public WoAmendedClaims createWoAmendedClaims() {
        return new WoAmendedClaims();
    }

    /**
     * Create an instance of {@link ReplaceObject }
     * 
     */
    public ReplaceObject createReplaceObject() {
        return new ReplaceObject();
    }

    /**
     * Create an instance of {@link InsertAfterObject }
     * 
     */
    public InsertAfterObject createInsertAfterObject() {
        return new InsertAfterObject();
    }

    /**
     * Create an instance of {@link InsertBeforeObject }
     * 
     */
    public InsertBeforeObject createInsertBeforeObject() {
        return new InsertBeforeObject();
    }

    /**
     * Create an instance of {@link DeleteObject }
     * 
     */
    public DeleteObject createDeleteObject() {
        return new DeleteObject();
    }

    /**
     * Create an instance of {@link AmendBody }
     * 
     */
    public AmendBody createAmendBody() {
        return new AmendBody();
    }

    /**
     * Create an instance of {@link Drawings }
     * 
     */
    public Drawings createDrawings() {
        return new Drawings();
    }

    /**
     * Create an instance of {@link Figure }
     * 
     */
    public Figure createFigure() {
        return new Figure();
    }

    /**
     * Create an instance of {@link Abstract }
     * 
     */
    public Abstract createAbstract() {
        return new Abstract();
    }

    /**
     * Create an instance of {@link AbstSolution }
     * 
     */
    public AbstSolution createAbstSolution() {
        return new AbstSolution();
    }

    /**
     * Create an instance of {@link AbstProblem }
     * 
     */
    public AbstProblem createAbstProblem() {
        return new AbstProblem();
    }

    /**
     * Create an instance of {@link AmendStatement }
     * 
     */
    public AmendStatement createAmendStatement() {
        return new AmendStatement();
    }

    /**
     * Create an instance of {@link Claims }
     * 
     */
    public Claims createClaims() {
        return new Claims();
    }

    /**
     * Create an instance of {@link Claim }
     * 
     */
    public Claim createClaim() {
        return new Claim();
    }

    /**
     * Create an instance of {@link ClaimRef }
     * 
     */
    public ClaimRef createClaimRef() {
        return new ClaimRef();
    }

    /**
     * Create an instance of {@link Description }
     * 
     */
    public Description createDescription() {
        return new Description();
    }

    /**
     * Create an instance of {@link CitationList }
     * 
     */
    public CitationList createCitationList() {
        return new CitationList();
    }

    /**
     * Create an instance of {@link NonPatentLiterature }
     * 
     */
    public NonPatentLiterature createNonPatentLiterature() {
        return new NonPatentLiterature();
    }

    /**
     * Create an instance of {@link PatentLiterature }
     * 
     */
    public PatentLiterature createPatentLiterature() {
        return new PatentLiterature();
    }

    /**
     * Create an instance of {@link SequenceListText }
     * 
     */
    public SequenceListText createSequenceListText() {
        return new SequenceListText();
    }

    /**
     * Create an instance of {@link ReferenceToDepositedBiologicalMaterial }
     * 
     */
    public ReferenceToDepositedBiologicalMaterial createReferenceToDepositedBiologicalMaterial() {
        return new ReferenceToDepositedBiologicalMaterial();
    }

    /**
     * Create an instance of {@link ReferenceSignsList }
     * 
     */
    public ReferenceSignsList createReferenceSignsList() {
        return new ReferenceSignsList();
    }

    /**
     * Create an instance of {@link IndustrialApplicability }
     * 
     */
    public IndustrialApplicability createIndustrialApplicability() {
        return new IndustrialApplicability();
    }

    /**
     * Create an instance of {@link ModeForInvention }
     * 
     */
    public ModeForInvention createModeForInvention() {
        return new ModeForInvention();
    }

    /**
     * Create an instance of {@link BestMode }
     * 
     */
    public BestMode createBestMode() {
        return new BestMode();
    }

    /**
     * Create an instance of {@link DescriptionOfEmbodiments }
     * 
     */
    public DescriptionOfEmbodiments createDescriptionOfEmbodiments() {
        return new DescriptionOfEmbodiments();
    }

    /**
     * Create an instance of {@link EmbodimentsExample }
     * 
     */
    public EmbodimentsExample createEmbodimentsExample() {
        return new EmbodimentsExample();
    }

    /**
     * Create an instance of {@link DescriptionOfDrawings }
     * 
     */
    public DescriptionOfDrawings createDescriptionOfDrawings() {
        return new DescriptionOfDrawings();
    }

    /**
     * Create an instance of {@link SummaryOfInvention }
     * 
     */
    public SummaryOfInvention createSummaryOfInvention() {
        return new SummaryOfInvention();
    }

    /**
     * Create an instance of {@link Disclosure }
     * 
     */
    public Disclosure createDisclosure() {
        return new Disclosure();
    }

    /**
     * Create an instance of {@link AdvantageousEffects }
     * 
     */
    public AdvantageousEffects createAdvantageousEffects() {
        return new AdvantageousEffects();
    }

    /**
     * Create an instance of {@link TechSolution }
     * 
     */
    public TechSolution createTechSolution() {
        return new TechSolution();
    }

    /**
     * Create an instance of {@link TechProblem }
     * 
     */
    public TechProblem createTechProblem() {
        return new TechProblem();
    }

    /**
     * Create an instance of {@link BackgroundArt }
     * 
     */
    public BackgroundArt createBackgroundArt() {
        return new BackgroundArt();
    }

    /**
     * Create an instance of {@link TechnicalField }
     * 
     */
    public TechnicalField createTechnicalField() {
        return new TechnicalField();
    }

    /**
     * Create an instance of {@link P }
     * 
     */
    public P createP() {
        return new P();
    }

    /**
     * Create an instance of {@link TableExternalDoc }
     * 
     */
    public TableExternalDoc createTableExternalDoc() {
        return new TableExternalDoc();
    }

    /**
     * Create an instance of {@link Tables }
     * 
     */
    public Tables createTables() {
        return new Tables();
    }

    /**
     * Create an instance of {@link Dl }
     * 
     */
    public Dl createDl() {
        return new Dl();
    }

    /**
     * Create an instance of {@link Dt }
     * 
     */
    public Dt createDt() {
        return new Dt();
    }

    /**
     * Create an instance of {@link Ul }
     * 
     */
    public Ul createUl() {
        return new Ul();
    }

    /**
     * Create an instance of {@link Li }
     * 
     */
    public Li createLi() {
        return new Li();
    }

    /**
     * Create an instance of {@link Maths }
     * 
     */
    public Maths createMaths() {
        return new Maths();
    }

    /**
     * Create an instance of {@link Chemistry }
     * 
     */
    public Chemistry createChemistry() {
        return new Chemistry();
    }

    /**
     * Create an instance of {@link Chem }
     * 
     */
    public Chem createChem() {
        return new Chem();
    }

    /**
     * Create an instance of {@link Ol }
     * 
     */
    public Ol createOl() {
        return new Ol();
    }

    /**
     * Create an instance of {@link Img }
     * 
     */
    public Img createImg() {
        return new Img();
    }

    /**
     * Create an instance of {@link Figref }
     * 
     */
    public Figref createFigref() {
        return new Figref();
    }

    /**
     * Create an instance of {@link Crossref }
     * 
     */
    public Crossref createCrossref() {
        return new Crossref();
    }

    /**
     * Create an instance of {@link BioDeposit }
     * 
     */
    public BioDeposit createBioDeposit() {
        return new BioDeposit();
    }

    /**
     * Create an instance of {@link Nplcit }
     * 
     */
    public Nplcit createNplcit() {
        return new Nplcit();
    }

    /**
     * Create an instance of {@link Refno }
     * 
     */
    public Refno createRefno() {
        return new Refno();
    }

    /**
     * Create an instance of {@link Class }
     * 
     */
    public Class createClass() {
        return new Class();
    }

    /**
     * Create an instance of {@link Subname }
     * 
     */
    public Subname createSubname() {
        return new Subname();
    }

    /**
     * Create an instance of {@link Author }
     * 
     */
    public Author createAuthor() {
        return new Author();
    }

    /**
     * Create an instance of {@link Addressbook }
     * 
     */
    public Addressbook createAddressbook() {
        return new Addressbook();
    }

    /**
     * Create an instance of {@link Email }
     * 
     */
    public Email createEmail() {
        return new Email();
    }

    /**
     * Create an instance of {@link Patcit }
     * 
     */
    public Patcit createPatcit() {
        return new Patcit();
    }

    /**
     * Create an instance of {@link Pre }
     * 
     */
    public Pre createPre() {
        return new Pre();
    }

    /**
     * Create an instance of {@link Heading }
     * 
     */
    public Heading createHeading() {
        return new Heading();
    }

    /**
     * Create an instance of {@link InventionTitle }
     * 
     */
    public InventionTitle createInventionTitle() {
        return new InventionTitle();
    }

    /**
     * Create an instance of {@link U }
     * 
     */
    public U createU() {
        return new U();
    }

    /**
     * Create an instance of {@link O }
     * 
     */
    public O createO() {
        return new O();
    }

    /**
     * Create an instance of {@link DocPage }
     * 
     */
    public DocPage createDocPage() {
        return new DocPage();
    }

    /**
     * Create an instance of {@link ApplicationReference }
     * 
     */
    public ApplicationReference createApplicationReference() {
        return new ApplicationReference();
    }

    /**
     * Create an instance of {@link IsrStatus }
     * 
     */
    public IsrStatus createIsrStatus() {
        return new IsrStatus();
    }

    /**
     * Create an instance of {@link WoDtext }
     * 
     */
    public WoDtext createWoDtext() {
        return new WoDtext();
    }

    /**
     * Create an instance of {@link PublicationReference }
     * 
     */
    public PublicationReference createPublicationReference() {
        return new PublicationReference();
    }

    /**
     * Create an instance of {@link DocumentId }
     * 
     */
    public DocumentId createDocumentId() {
        return new DocumentId();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link Statement }
     * 
     */
    public Statement createStatement() {
        return new Statement();
    }

    /**
     * Create an instance of {@link ClaimText }
     * 
     */
    public ClaimText createClaimText() {
        return new ClaimText();
    }

    /**
     * Create an instance of {@link Dd }
     * 
     */
    public Dd createDd() {
        return new Dd();
    }

    /**
     * Create an instance of {@link Term }
     * 
     */
    public Term createTerm() {
        return new Term();
    }

    /**
     * Create an instance of {@link BioAccno }
     * 
     */
    public BioAccno createBioAccno() {
        return new BioAccno();
    }

    /**
     * Create an instance of {@link Depositary }
     * 
     */
    public Depositary createDepositary() {
        return new Depositary();
    }

    /**
     * Create an instance of {@link Othercit }
     * 
     */
    public Othercit createOthercit() {
        return new Othercit();
    }

    /**
     * Create an instance of {@link Online }
     * 
     */
    public Online createOnline() {
        return new Online();
    }

    /**
     * Create an instance of {@link Srchdate }
     * 
     */
    public Srchdate createSrchdate() {
        return new Srchdate();
    }

    /**
     * Create an instance of {@link Srchterm }
     * 
     */
    public Srchterm createSrchterm() {
        return new Srchterm();
    }

    /**
     * Create an instance of {@link Datecit }
     * 
     */
    public Datecit createDatecit() {
        return new Datecit();
    }

    /**
     * Create an instance of {@link Avail }
     * 
     */
    public Avail createAvail() {
        return new Avail();
    }

    /**
     * Create an instance of {@link Hostno }
     * 
     */
    public Hostno createHostno() {
        return new Hostno();
    }

    /**
     * Create an instance of {@link History }
     * 
     */
    public History createHistory() {
        return new History();
    }

    /**
     * Create an instance of {@link Misc }
     * 
     */
    public Misc createMisc() {
        return new Misc();
    }

    /**
     * Create an instance of {@link Revised }
     * 
     */
    public Revised createRevised() {
        return new Revised();
    }

    /**
     * Create an instance of {@link Accepted }
     * 
     */
    public Accepted createAccepted() {
        return new Accepted();
    }

    /**
     * Create an instance of {@link Received }
     * 
     */
    public Received createReceived() {
        return new Received();
    }

    /**
     * Create an instance of {@link Hosttitle }
     * 
     */
    public Hosttitle createHosttitle() {
        return new Hosttitle();
    }

    /**
     * Create an instance of {@link OnlineTitle }
     * 
     */
    public OnlineTitle createOnlineTitle() {
        return new OnlineTitle();
    }

    /**
     * Create an instance of {@link Article }
     * 
     */
    public Article createArticle() {
        return new Article();
    }

    /**
     * Create an instance of {@link Artid }
     * 
     */
    public Artid createArtid() {
        return new Artid();
    }

    /**
     * Create an instance of {@link Book }
     * 
     */
    public Book createBook() {
        return new Book();
    }

    /**
     * Create an instance of {@link Keyword }
     * 
     */
    public Keyword createKeyword() {
        return new Keyword();
    }

    /**
     * Create an instance of {@link Bookno }
     * 
     */
    public Bookno createBookno() {
        return new Bookno();
    }

    /**
     * Create an instance of {@link Location }
     * 
     */
    public Location createLocation() {
        return new Location();
    }

    /**
     * Create an instance of {@link Line }
     * 
     */
    public Line createLine() {
        return new Line();
    }

    /**
     * Create an instance of {@link Linel }
     * 
     */
    public Linel createLinel() {
        return new Linel();
    }

    /**
     * Create an instance of {@link Linef }
     * 
     */
    public Linef createLinef() {
        return new Linef();
    }

    /**
     * Create an instance of {@link Para }
     * 
     */
    public Para createPara() {
        return new Para();
    }

    /**
     * Create an instance of {@link Paral }
     * 
     */
    public Paral createParal() {
        return new Paral();
    }

    /**
     * Create an instance of {@link Paraf }
     * 
     */
    public Paraf createParaf() {
        return new Paraf();
    }

    /**
     * Create an instance of {@link Column }
     * 
     */
    public Column createColumn() {
        return new Column();
    }

    /**
     * Create an instance of {@link Coll }
     * 
     */
    public Coll createColl() {
        return new Coll();
    }

    /**
     * Create an instance of {@link Colf }
     * 
     */
    public Colf createColf() {
        return new Colf();
    }

    /**
     * Create an instance of {@link Pp }
     * 
     */
    public Pp createPp() {
        return new Pp();
    }

    /**
     * Create an instance of {@link Ppl }
     * 
     */
    public Ppl createPpl() {
        return new Ppl();
    }

    /**
     * Create an instance of {@link Ppf }
     * 
     */
    public Ppf createPpf() {
        return new Ppf();
    }

    /**
     * Create an instance of {@link Chapter }
     * 
     */
    public Chapter createChapter() {
        return new Chapter();
    }

    /**
     * Create an instance of {@link Sersect }
     * 
     */
    public Sersect createSersect() {
        return new Sersect();
    }

    /**
     * Create an instance of {@link Serpart }
     * 
     */
    public Serpart createSerpart() {
        return new Serpart();
    }

    /**
     * Create an instance of {@link Absno }
     * 
     */
    public Absno createAbsno() {
        return new Absno();
    }

    /**
     * Create an instance of {@link Series }
     * 
     */
    public Series createSeries() {
        return new Series();
    }

    /**
     * Create an instance of {@link Msn }
     * 
     */
    public Msn createMsn() {
        return new Msn();
    }

    /**
     * Create an instance of {@link Mst }
     * 
     */
    public Mst createMst() {
        return new Mst();
    }

    /**
     * Create an instance of {@link Edition }
     * 
     */
    public Edition createEdition() {
        return new Edition();
    }

    /**
     * Create an instance of {@link Subtitle }
     * 
     */
    public Subtitle createSubtitle() {
        return new Subtitle();
    }

    /**
     * Create an instance of {@link Conference }
     * 
     */
    public Conference createConference() {
        return new Conference();
    }

    /**
     * Create an instance of {@link Confdate }
     * 
     */
    public Confdate createConfdate() {
        return new Confdate();
    }

    /**
     * Create an instance of {@link Confsponsor }
     * 
     */
    public Confsponsor createConfsponsor() {
        return new Confsponsor();
    }

    /**
     * Create an instance of {@link Confplace }
     * 
     */
    public Confplace createConfplace() {
        return new Confplace();
    }

    /**
     * Create an instance of {@link Confno }
     * 
     */
    public Confno createConfno() {
        return new Confno();
    }

    /**
     * Create an instance of {@link Conftitle }
     * 
     */
    public Conftitle createConftitle() {
        return new Conftitle();
    }

    /**
     * Create an instance of {@link BookTitle }
     * 
     */
    public BookTitle createBookTitle() {
        return new BookTitle();
    }

    /**
     * Create an instance of {@link Serial }
     * 
     */
    public Serial createSerial() {
        return new Serial();
    }

    /**
     * Create an instance of {@link Doi }
     * 
     */
    public Doi createDoi() {
        return new Doi();
    }

    /**
     * Create an instance of {@link Cpyrt }
     * 
     */
    public Cpyrt createCpyrt() {
        return new Cpyrt();
    }

    /**
     * Create an instance of {@link Ino }
     * 
     */
    public Ino createIno() {
        return new Ino();
    }

    /**
     * Create an instance of {@link Vid }
     * 
     */
    public Vid createVid() {
        return new Vid();
    }

    /**
     * Create an instance of {@link Pubid }
     * 
     */
    public Pubid createPubid() {
        return new Pubid();
    }

    /**
     * Create an instance of {@link Isbn }
     * 
     */
    public Isbn createIsbn() {
        return new Isbn();
    }

    /**
     * Create an instance of {@link Issn }
     * 
     */
    public Issn createIssn() {
        return new Issn();
    }

    /**
     * Create an instance of {@link Notes }
     * 
     */
    public Notes createNotes() {
        return new Notes();
    }

    /**
     * Create an instance of {@link Descrip }
     * 
     */
    public Descrip createDescrip() {
        return new Descrip();
    }

    /**
     * Create an instance of {@link Imprint }
     * 
     */
    public Imprint createImprint() {
        return new Imprint();
    }

    /**
     * Create an instance of {@link Pubdate }
     * 
     */
    public Pubdate createPubdate() {
        return new Pubdate();
    }

    /**
     * Create an instance of {@link Time }
     * 
     */
    public Time createTime() {
        return new Time();
    }

    /**
     * Create an instance of {@link Edate }
     * 
     */
    public Edate createEdate() {
        return new Edate();
    }

    /**
     * Create an instance of {@link Sdate }
     * 
     */
    public Sdate createSdate() {
        return new Sdate();
    }

    /**
     * Create an instance of {@link Issue }
     * 
     */
    public Issue createIssue() {
        return new Issue();
    }

    /**
     * Create an instance of {@link Alttitle }
     * 
     */
    public Alttitle createAlttitle() {
        return new Alttitle();
    }

    /**
     * Create an instance of {@link Sertitle }
     * 
     */
    public Sertitle createSertitle() {
        return new Sertitle();
    }

    /**
     * Create an instance of {@link Atl }
     * 
     */
    public Atl createAtl() {
        return new Atl();
    }

    /**
     * Create an instance of {@link Url }
     * 
     */
    public Url createUrl() {
        return new Url();
    }

    /**
     * Create an instance of {@link Fax }
     * 
     */
    public Fax createFax() {
        return new Fax();
    }

    /**
     * Create an instance of {@link Phone }
     * 
     */
    public Phone createPhone() {
        return new Phone();
    }

    /**
     * Create an instance of {@link Ead }
     * 
     */
    public Ead createEad() {
        return new Ead();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link Postcode }
     * 
     */
    public Postcode createPostcode() {
        return new Postcode();
    }

    /**
     * Create an instance of {@link State }
     * 
     */
    public State createState() {
        return new State();
    }

    /**
     * Create an instance of {@link County }
     * 
     */
    public County createCounty() {
        return new County();
    }

    /**
     * Create an instance of {@link City }
     * 
     */
    public City createCity() {
        return new City();
    }

    /**
     * Create an instance of {@link Street }
     * 
     */
    public Street createStreet() {
        return new Street();
    }

    /**
     * Create an instance of {@link Building }
     * 
     */
    public Building createBuilding() {
        return new Building();
    }

    /**
     * Create an instance of {@link AddressFloor }
     * 
     */
    public AddressFloor createAddressFloor() {
        return new AddressFloor();
    }

    /**
     * Create an instance of {@link Room }
     * 
     */
    public Room createRoom() {
        return new Room();
    }

    /**
     * Create an instance of {@link Pobox }
     * 
     */
    public Pobox createPobox() {
        return new Pobox();
    }

    /**
     * Create an instance of {@link Mailcode }
     * 
     */
    public Mailcode createMailcode() {
        return new Mailcode();
    }

    /**
     * Create an instance of {@link Address5 }
     * 
     */
    public Address5 createAddress5() {
        return new Address5();
    }

    /**
     * Create an instance of {@link Address4 }
     * 
     */
    public Address4 createAddress4() {
        return new Address4();
    }

    /**
     * Create an instance of {@link Address3 }
     * 
     */
    public Address3 createAddress3() {
        return new Address3();
    }

    /**
     * Create an instance of {@link Address2 }
     * 
     */
    public Address2 createAddress2() {
        return new Address2();
    }

    /**
     * Create an instance of {@link Address1 }
     * 
     */
    public Address1 createAddress1() {
        return new Address1();
    }

    /**
     * Create an instance of {@link RegisteredNumber }
     * 
     */
    public RegisteredNumber createRegisteredNumber() {
        return new RegisteredNumber();
    }

    /**
     * Create an instance of {@link Synonym }
     * 
     */
    public Synonym createSynonym() {
        return new Synonym();
    }

    /**
     * Create an instance of {@link Department }
     * 
     */
    public Department createDepartment() {
        return new Department();
    }

    /**
     * Create an instance of {@link Orgname }
     * 
     */
    public Orgname createOrgname() {
        return new Orgname();
    }

    /**
     * Create an instance of {@link Role }
     * 
     */
    public Role createRole() {
        return new Role();
    }

    /**
     * Create an instance of {@link Iid }
     * 
     */
    public Iid createIid() {
        return new Iid();
    }

    /**
     * Create an instance of {@link Suffix }
     * 
     */
    public Suffix createSuffix() {
        return new Suffix();
    }

    /**
     * Create an instance of {@link MiddleName }
     * 
     */
    public MiddleName createMiddleName() {
        return new MiddleName();
    }

    /**
     * Create an instance of {@link FirstName }
     * 
     */
    public FirstName createFirstName() {
        return new FirstName();
    }

    /**
     * Create an instance of {@link LastName }
     * 
     */
    public LastName createLastName() {
        return new LastName();
    }

    /**
     * Create an instance of {@link Prefix }
     * 
     */
    public Prefix createPrefix() {
        return new Prefix();
    }

    /**
     * Create an instance of {@link RelPassage }
     * 
     */
    public RelPassage createRelPassage() {
        return new RelPassage();
    }

    /**
     * Create an instance of {@link RelClaims }
     * 
     */
    public RelClaims createRelClaims() {
        return new RelClaims();
    }

    /**
     * Create an instance of {@link Category }
     * 
     */
    public Category createCategory() {
        return new Category();
    }

    /**
     * Create an instance of {@link Passage }
     * 
     */
    public Passage createPassage() {
        return new Passage();
    }

    /**
     * Create an instance of {@link Text }
     * 
     */
    public Text createText() {
        return new Text();
    }

    /**
     * Create an instance of {@link B }
     * 
     */
    public B createB() {
        return new B();
    }

    /**
     * Create an instance of {@link I }
     * 
     */
    public I createI() {
        return new I();
    }

    /**
     * Create an instance of {@link Smallcaps }
     * 
     */
    public Smallcaps createSmallcaps() {
        return new Smallcaps();
    }

    /**
     * Create an instance of {@link Sub }
     * 
     */
    public Sub createSub() {
        return new Sub();
    }

    /**
     * Create an instance of {@link Sup }
     * 
     */
    public Sup createSup() {
        return new Sup();
    }

    /**
     * Create an instance of {@link Sub2 }
     * 
     */
    public Sub2 createSub2() {
        return new Sub2();
    }

    /**
     * Create an instance of {@link Sup2 }
     * 
     */
    public Sup2 createSup2() {
        return new Sup2();
    }

    /**
     * Create an instance of {@link WoPublicationInfo }
     * 
     */
    public WoPublicationInfo createWoPublicationInfo() {
        return new WoPublicationInfo();
    }

    /**
     * Create an instance of {@link WoPubnum }
     * 
     */
    public WoPubnum createWoPubnum() {
        return new WoPubnum();
    }

    /**
     * Create an instance of {@link PctPubInfo }
     * 
     */
    public PctPubInfo createPctPubInfo() {
        return new PctPubInfo();
    }

    /**
     * Create an instance of {@link WoPublishedText }
     * 
     */
    public WoPublishedText createWoPublishedText() {
        return new WoPublishedText();
    }

    /**
     * Create an instance of {@link WoTextLetterCode }
     * 
     */
    public WoTextLetterCode createWoTextLetterCode() {
        return new WoTextLetterCode();
    }

    /**
     * Create an instance of {@link PctArt64 }
     * 
     */
    public PctArt64 createPctArt64() {
        return new PctArt64();
    }

    /**
     * Create an instance of {@link WoBioMaterialAfterPub }
     * 
     */
    public WoBioMaterialAfterPub createWoBioMaterialAfterPub() {
        return new WoBioMaterialAfterPub();
    }

    /**
     * Create an instance of {@link RelevantDate }
     * 
     */
    public RelevantDate createRelevantDate() {
        return new RelevantDate();
    }

    /**
     * Create an instance of {@link ReceivedAtIb }
     * 
     */
    public ReceivedAtIb createReceivedAtIb() {
        return new ReceivedAtIb();
    }

    /**
     * Create an instance of {@link WoCorrection }
     * 
     */
    public WoCorrection createWoCorrection() {
        return new WoCorrection();
    }

    /**
     * Create an instance of {@link Dtext }
     * 
     */
    public Dtext createDtext() {
        return new Dtext();
    }

    /**
     * Create an instance of {@link Br }
     * 
     */
    public Br createBr() {
        return new Br();
    }

    /**
     * Create an instance of {@link WoRepubCode }
     * 
     */
    public WoRepubCode createWoRepubCode() {
        return new WoRepubCode();
    }

    /**
     * Create an instance of {@link TypeOfCorrection }
     * 
     */
    public TypeOfCorrection createTypeOfCorrection() {
        return new TypeOfCorrection();
    }

    /**
     * Create an instance of {@link Date }
     * 
     */
    public Date createDate() {
        return new Date();
    }

    /**
     * Create an instance of {@link Kind }
     * 
     */
    public Kind createKind() {
        return new Kind();
    }

    /**
     * Create an instance of {@link DocNumber }
     * 
     */
    public DocNumber createDocNumber() {
        return new DocNumber();
    }

    /**
     * Create an instance of {@link Country }
     * 
     */
    public Country createCountry() {
        return new Country();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mspace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mspace")
    public JAXBElement<Mspace> createMspace(Mspace value) {
        return new JAXBElement<Mspace>(_Mspace_QNAME, Mspace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mprescripts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mprescripts")
    public JAXBElement<Mprescripts> createMprescripts(Mprescripts value) {
        return new JAXBElement<Mprescripts>(_Mprescripts_QNAME, Mprescripts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link None }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "none")
    public JAXBElement<None> createNone(None value) {
        return new JAXBElement<None>(_None_QNAME, None.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Malignmark }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "malignmark")
    public JAXBElement<Malignmark> createMalignmark(Malignmark value) {
        return new JAXBElement<Malignmark>(_Malignmark_QNAME, Malignmark.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Maligngroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maligngroup")
    public JAXBElement<Maligngroup> createMaligngroup(Maligngroup value) {
        return new JAXBElement<Maligngroup>(_Maligngroup_QNAME, Maligngroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mglyph }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mglyph")
    public JAXBElement<Mglyph> createMglyph(Mglyph value) {
        return new JAXBElement<Mglyph>(_Mglyph_QNAME, Mglyph.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sep }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sep")
    public JAXBElement<Sep> createSep(Sep value) {
        return new JAXBElement<Sep>(_Sep_QNAME, Sep.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "integers")
    public JAXBElement<Integers> createIntegers(Integers value) {
        return new JAXBElement<Integers>(_Integers_QNAME, Integers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Reals }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "reals")
    public JAXBElement<Reals> createReals(Reals value) {
        return new JAXBElement<Reals>(_Reals_QNAME, Reals.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rationals }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rationals")
    public JAXBElement<Rationals> createRationals(Rationals value) {
        return new JAXBElement<Rationals>(_Rationals_QNAME, Rationals.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Naturalnumbers }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "naturalnumbers")
    public JAXBElement<Naturalnumbers> createNaturalnumbers(Naturalnumbers value) {
        return new JAXBElement<Naturalnumbers>(_Naturalnumbers_QNAME, Naturalnumbers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Complexes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "complexes")
    public JAXBElement<Complexes> createComplexes(Complexes value) {
        return new JAXBElement<Complexes>(_Complexes_QNAME, Complexes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Primes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "primes")
    public JAXBElement<Primes> createPrimes(Primes value) {
        return new JAXBElement<Primes>(_Primes_QNAME, Primes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exponentiale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "exponentiale")
    public JAXBElement<Exponentiale> createExponentiale(Exponentiale value) {
        return new JAXBElement<Exponentiale>(_Exponentiale_QNAME, Exponentiale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Imaginaryi }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "imaginaryi")
    public JAXBElement<Imaginaryi> createImaginaryi(Imaginaryi value) {
        return new JAXBElement<Imaginaryi>(_Imaginaryi_QNAME, Imaginaryi.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notanumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notanumber")
    public JAXBElement<Notanumber> createNotanumber(Notanumber value) {
        return new JAXBElement<Notanumber>(_Notanumber_QNAME, Notanumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link True }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "true")
    public JAXBElement<True> createTrue(True value) {
        return new JAXBElement<True>(_True_QNAME, True.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link False }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "false")
    public JAXBElement<False> createFalse(False value) {
        return new JAXBElement<False>(_False_QNAME, False.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Emptyset }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "emptyset")
    public JAXBElement<Emptyset> createEmptyset(Emptyset value) {
        return new JAXBElement<Emptyset>(_Emptyset_QNAME, Emptyset.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pi }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pi")
    public JAXBElement<Pi> createPi(Pi value) {
        return new JAXBElement<Pi>(_Pi_QNAME, Pi.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Eulergamma }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "eulergamma")
    public JAXBElement<Eulergamma> createEulergamma(Eulergamma value) {
        return new JAXBElement<Eulergamma>(_Eulergamma_QNAME, Eulergamma.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Infinity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "infinity")
    public JAXBElement<Infinity> createInfinity(Infinity value) {
        return new JAXBElement<Infinity>(_Infinity_QNAME, Infinity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Inverse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "inverse")
    public JAXBElement<Inverse> createInverse(Inverse value) {
        return new JAXBElement<Inverse>(_Inverse_QNAME, Inverse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Domain }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "domain")
    public JAXBElement<Domain> createDomain(Domain value) {
        return new JAXBElement<Domain>(_Domain_QNAME, Domain.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Codomain }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "codomain")
    public JAXBElement<Codomain> createCodomain(Codomain value) {
        return new JAXBElement<Codomain>(_Codomain_QNAME, Codomain.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Image }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "image")
    public JAXBElement<Image> createImage(Image value) {
        return new JAXBElement<Image>(_Image_QNAME, Image.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ident }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ident")
    public JAXBElement<Ident> createIdent(Ident value) {
        return new JAXBElement<Ident>(_Ident_QNAME, Ident.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Compose }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "compose")
    public JAXBElement<Compose> createCompose(Compose value) {
        return new JAXBElement<Compose>(_Compose_QNAME, Compose.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "exp")
    public JAXBElement<Exp> createExp(Exp value) {
        return new JAXBElement<Exp>(_Exp_QNAME, Exp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Abs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abs")
    public JAXBElement<Abs> createAbs(Abs value) {
        return new JAXBElement<Abs>(_Abs_QNAME, Abs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arg }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arg")
    public JAXBElement<Arg> createArg(Arg value) {
        return new JAXBElement<Arg>(_Arg_QNAME, Arg.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Real }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "real")
    public JAXBElement<Real> createReal(Real value) {
        return new JAXBElement<Real>(_Real_QNAME, Real.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Imaginary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "imaginary")
    public JAXBElement<Imaginary> createImaginary(Imaginary value) {
        return new JAXBElement<Imaginary>(_Imaginary_QNAME, Imaginary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Conjugate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conjugate")
    public JAXBElement<Conjugate> createConjugate(Conjugate value) {
        return new JAXBElement<Conjugate>(_Conjugate_QNAME, Conjugate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Factorial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "factorial")
    public JAXBElement<Factorial> createFactorial(Factorial value) {
        return new JAXBElement<Factorial>(_Factorial_QNAME, Factorial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Floor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "floor")
    public JAXBElement<Floor> createFloor(Floor value) {
        return new JAXBElement<Floor>(_Floor_QNAME, Floor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ceiling }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ceiling")
    public JAXBElement<Ceiling> createCeiling(Ceiling value) {
        return new JAXBElement<Ceiling>(_Ceiling_QNAME, Ceiling.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Minus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "minus")
    public JAXBElement<Minus> createMinus(Minus value) {
        return new JAXBElement<Minus>(_Minus_QNAME, Minus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Quotient }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "quotient")
    public JAXBElement<Quotient> createQuotient(Quotient value) {
        return new JAXBElement<Quotient>(_Quotient_QNAME, Quotient.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Divide }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "divide")
    public JAXBElement<Divide> createDivide(Divide value) {
        return new JAXBElement<Divide>(_Divide_QNAME, Divide.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Power }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "power")
    public JAXBElement<Power> createPower(Power value) {
        return new JAXBElement<Power>(_Power_QNAME, Power.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rem")
    public JAXBElement<Rem> createRem(Rem value) {
        return new JAXBElement<Rem>(_Rem_QNAME, Rem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Plus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "plus")
    public JAXBElement<Plus> createPlus(Plus value) {
        return new JAXBElement<Plus>(_Plus_QNAME, Plus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Max }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "max")
    public JAXBElement<Max> createMax(Max value) {
        return new JAXBElement<Max>(_Max_QNAME, Max.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Min }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "min")
    public JAXBElement<Min> createMin(Min value) {
        return new JAXBElement<Min>(_Min_QNAME, Min.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Times }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "times")
    public JAXBElement<Times> createTimes(Times value) {
        return new JAXBElement<Times>(_Times_QNAME, Times.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Gcd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "gcd")
    public JAXBElement<Gcd> createGcd(Gcd value) {
        return new JAXBElement<Gcd>(_Gcd_QNAME, Gcd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Lcm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lcm")
    public JAXBElement<Lcm> createLcm(Lcm value) {
        return new JAXBElement<Lcm>(_Lcm_QNAME, Lcm.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Root }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "root")
    public JAXBElement<Root> createRoot(Root value) {
        return new JAXBElement<Root>(_Root_QNAME, Root.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exists }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "exists")
    public JAXBElement<Exists> createExists(Exists value) {
        return new JAXBElement<Exists>(_Exists_QNAME, Exists.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Forall }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "forall")
    public JAXBElement<Forall> createForall(Forall value) {
        return new JAXBElement<Forall>(_Forall_QNAME, Forall.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link And }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "and")
    public JAXBElement<And> createAnd(And value) {
        return new JAXBElement<And>(_And_QNAME, And.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Or }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "or")
    public JAXBElement<Or> createOr(Or value) {
        return new JAXBElement<Or>(_Or_QNAME, Or.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Xor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "xor")
    public JAXBElement<Xor> createXor(Xor value) {
        return new JAXBElement<Xor>(_Xor_QNAME, Xor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Not }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "not")
    public JAXBElement<Not> createNot(Not value) {
        return new JAXBElement<Not>(_Not_QNAME, Not.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Implies }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "implies")
    public JAXBElement<Implies> createImplies(Implies value) {
        return new JAXBElement<Implies>(_Implies_QNAME, Implies.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Divergence }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "divergence")
    public JAXBElement<Divergence> createDivergence(Divergence value) {
        return new JAXBElement<Divergence>(_Divergence_QNAME, Divergence.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Grad }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "grad")
    public JAXBElement<Grad> createGrad(Grad value) {
        return new JAXBElement<Grad>(_Grad_QNAME, Grad.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Curl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "curl")
    public JAXBElement<Curl> createCurl(Curl value) {
        return new JAXBElement<Curl>(_Curl_QNAME, Curl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Laplacian }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "laplacian")
    public JAXBElement<Laplacian> createLaplacian(Laplacian value) {
        return new JAXBElement<Laplacian>(_Laplacian_QNAME, Laplacian.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Log }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "log")
    public JAXBElement<Log> createLog(Log value) {
        return new JAXBElement<Log>(_Log_QNAME, Log.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Int }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "int")
    public JAXBElement<Int> createInt(Int value) {
        return new JAXBElement<Int>(_Int_QNAME, Int.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Diff }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "diff")
    public JAXBElement<Diff> createDiff(Diff value) {
        return new JAXBElement<Diff>(_Diff_QNAME, Diff.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Partialdiff }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "partialdiff")
    public JAXBElement<Partialdiff> createPartialdiff(Partialdiff value) {
        return new JAXBElement<Partialdiff>(_Partialdiff_QNAME, Partialdiff.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ln }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ln")
    public JAXBElement<Ln> createLn(Ln value) {
        return new JAXBElement<Ln>(_Ln_QNAME, Ln.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Card }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "card")
    public JAXBElement<Card> createCard(Card value) {
        return new JAXBElement<Card>(_Card_QNAME, Card.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Setdiff }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "setdiff")
    public JAXBElement<Setdiff> createSetdiff(Setdiff value) {
        return new JAXBElement<Setdiff>(_Setdiff_QNAME, Setdiff.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Union }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "union")
    public JAXBElement<Union> createUnion(Union value) {
        return new JAXBElement<Union>(_Union_QNAME, Union.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Intersect }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "intersect")
    public JAXBElement<Intersect> createIntersect(Intersect value) {
        return new JAXBElement<Intersect>(_Intersect_QNAME, Intersect.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cartesianproduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cartesianproduct")
    public JAXBElement<Cartesianproduct> createCartesianproduct(Cartesianproduct value) {
        return new JAXBElement<Cartesianproduct>(_Cartesianproduct_QNAME, Cartesianproduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sum }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sum")
    public JAXBElement<Sum> createSum(Sum value) {
        return new JAXBElement<Sum>(_Sum_QNAME, Sum.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Product }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "product")
    public JAXBElement<Product> createProduct(Product value) {
        return new JAXBElement<Product>(_Product_QNAME, Product.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Limit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "limit")
    public JAXBElement<Limit> createLimit(Limit value) {
        return new JAXBElement<Limit>(_Limit_QNAME, Limit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sin")
    public JAXBElement<Sin> createSin(Sin value) {
        return new JAXBElement<Sin>(_Sin_QNAME, Sin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cos")
    public JAXBElement<Cos> createCos(Cos value) {
        return new JAXBElement<Cos>(_Cos_QNAME, Cos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tan }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tan")
    public JAXBElement<Tan> createTan(Tan value) {
        return new JAXBElement<Tan>(_Tan_QNAME, Tan.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sec }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sec")
    public JAXBElement<Sec> createSec(Sec value) {
        return new JAXBElement<Sec>(_Sec_QNAME, Sec.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Csc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "csc")
    public JAXBElement<Csc> createCsc(Csc value) {
        return new JAXBElement<Csc>(_Csc_QNAME, Csc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cot }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cot")
    public JAXBElement<Cot> createCot(Cot value) {
        return new JAXBElement<Cot>(_Cot_QNAME, Cot.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sinh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sinh")
    public JAXBElement<Sinh> createSinh(Sinh value) {
        return new JAXBElement<Sinh>(_Sinh_QNAME, Sinh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cosh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cosh")
    public JAXBElement<Cosh> createCosh(Cosh value) {
        return new JAXBElement<Cosh>(_Cosh_QNAME, Cosh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tanh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tanh")
    public JAXBElement<Tanh> createTanh(Tanh value) {
        return new JAXBElement<Tanh>(_Tanh_QNAME, Tanh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sech }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sech")
    public JAXBElement<Sech> createSech(Sech value) {
        return new JAXBElement<Sech>(_Sech_QNAME, Sech.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Csch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "csch")
    public JAXBElement<Csch> createCsch(Csch value) {
        return new JAXBElement<Csch>(_Csch_QNAME, Csch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Coth }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coth")
    public JAXBElement<Coth> createCoth(Coth value) {
        return new JAXBElement<Coth>(_Coth_QNAME, Coth.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arcsin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arcsin")
    public JAXBElement<Arcsin> createArcsin(Arcsin value) {
        return new JAXBElement<Arcsin>(_Arcsin_QNAME, Arcsin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccos")
    public JAXBElement<Arccos> createArccos(Arccos value) {
        return new JAXBElement<Arccos>(_Arccos_QNAME, Arccos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arctan }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arctan")
    public JAXBElement<Arctan> createArctan(Arctan value) {
        return new JAXBElement<Arctan>(_Arctan_QNAME, Arctan.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccosh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccosh")
    public JAXBElement<Arccosh> createArccosh(Arccosh value) {
        return new JAXBElement<Arccosh>(_Arccosh_QNAME, Arccosh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccot }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccot")
    public JAXBElement<Arccot> createArccot(Arccot value) {
        return new JAXBElement<Arccot>(_Arccot_QNAME, Arccot.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccoth }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccoth")
    public JAXBElement<Arccoth> createArccoth(Arccoth value) {
        return new JAXBElement<Arccoth>(_Arccoth_QNAME, Arccoth.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccsc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccsc")
    public JAXBElement<Arccsc> createArccsc(Arccsc value) {
        return new JAXBElement<Arccsc>(_Arccsc_QNAME, Arccsc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arccsch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arccsch")
    public JAXBElement<Arccsch> createArccsch(Arccsch value) {
        return new JAXBElement<Arccsch>(_Arccsch_QNAME, Arccsch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arcsec }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arcsec")
    public JAXBElement<Arcsec> createArcsec(Arcsec value) {
        return new JAXBElement<Arcsec>(_Arcsec_QNAME, Arcsec.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arcsech }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arcsech")
    public JAXBElement<Arcsech> createArcsech(Arcsech value) {
        return new JAXBElement<Arcsech>(_Arcsech_QNAME, Arcsech.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arcsinh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arcsinh")
    public JAXBElement<Arcsinh> createArcsinh(Arcsinh value) {
        return new JAXBElement<Arcsinh>(_Arcsinh_QNAME, Arcsinh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Arctanh }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "arctanh")
    public JAXBElement<Arctanh> createArctanh(Arctanh value) {
        return new JAXBElement<Arctanh>(_Arctanh_QNAME, Arctanh.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mean")
    public JAXBElement<Mean> createMean(Mean value) {
        return new JAXBElement<Mean>(_Mean_QNAME, Mean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sdev }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sdev")
    public JAXBElement<Sdev> createSdev(Sdev value) {
        return new JAXBElement<Sdev>(_Sdev_QNAME, Sdev.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Variance }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "variance")
    public JAXBElement<Variance> createVariance(Variance value) {
        return new JAXBElement<Variance>(_Variance_QNAME, Variance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Median }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "median")
    public JAXBElement<Median> createMedian(Median value) {
        return new JAXBElement<Median>(_Median_QNAME, Median.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mode")
    public JAXBElement<Mode> createMode(Mode value) {
        return new JAXBElement<Mode>(_Mode_QNAME, Mode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Moment }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "moment")
    public JAXBElement<Moment> createMoment(Moment value) {
        return new JAXBElement<Moment>(_Moment_QNAME, Moment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Determinant }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "determinant")
    public JAXBElement<Determinant> createDeterminant(Determinant value) {
        return new JAXBElement<Determinant>(_Determinant_QNAME, Determinant.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Transpose }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "transpose")
    public JAXBElement<Transpose> createTranspose(Transpose value) {
        return new JAXBElement<Transpose>(_Transpose_QNAME, Transpose.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Vectorproduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "vectorproduct")
    public JAXBElement<Vectorproduct> createVectorproduct(Vectorproduct value) {
        return new JAXBElement<Vectorproduct>(_Vectorproduct_QNAME, Vectorproduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Scalarproduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "scalarproduct")
    public JAXBElement<Scalarproduct> createScalarproduct(Scalarproduct value) {
        return new JAXBElement<Scalarproduct>(_Scalarproduct_QNAME, Scalarproduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Outerproduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "outerproduct")
    public JAXBElement<Outerproduct> createOuterproduct(Outerproduct value) {
        return new JAXBElement<Outerproduct>(_Outerproduct_QNAME, Outerproduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Selector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selector")
    public JAXBElement<Selector> createSelector(Selector value) {
        return new JAXBElement<Selector>(_Selector_QNAME, Selector.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Neq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "neq")
    public JAXBElement<Neq> createNeq(Neq value) {
        return new JAXBElement<Neq>(_Neq_QNAME, Neq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Factorof }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "factorof")
    public JAXBElement<Factorof> createFactorof(Factorof value) {
        return new JAXBElement<Factorof>(_Factorof_QNAME, Factorof.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Eq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "eq")
    public JAXBElement<Eq> createEq(Eq value) {
        return new JAXBElement<Eq>(_Eq_QNAME, Eq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Equivalent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "equivalent")
    public JAXBElement<Equivalent> createEquivalent(Equivalent value) {
        return new JAXBElement<Equivalent>(_Equivalent_QNAME, Equivalent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Approx }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "approx")
    public JAXBElement<Approx> createApprox(Approx value) {
        return new JAXBElement<Approx>(_Approx_QNAME, Approx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Gt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "gt")
    public JAXBElement<Gt> createGt(Gt value) {
        return new JAXBElement<Gt>(_Gt_QNAME, Gt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Lt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lt")
    public JAXBElement<Lt> createLt(Lt value) {
        return new JAXBElement<Lt>(_Lt_QNAME, Lt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Geq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "geq")
    public JAXBElement<Geq> createGeq(Geq value) {
        return new JAXBElement<Geq>(_Geq_QNAME, Geq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Leq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "leq")
    public JAXBElement<Leq> createLeq(Leq value) {
        return new JAXBElement<Leq>(_Leq_QNAME, Leq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link In }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "in")
    public JAXBElement<In> createIn(In value) {
        return new JAXBElement<In>(_In_QNAME, In.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notin }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notin")
    public JAXBElement<Notin> createNotin(Notin value) {
        return new JAXBElement<Notin>(_Notin_QNAME, Notin.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notsubset }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notsubset")
    public JAXBElement<Notsubset> createNotsubset(Notsubset value) {
        return new JAXBElement<Notsubset>(_Notsubset_QNAME, Notsubset.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notprsubset }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notprsubset")
    public JAXBElement<Notprsubset> createNotprsubset(Notprsubset value) {
        return new JAXBElement<Notprsubset>(_Notprsubset_QNAME, Notprsubset.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subset }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subset")
    public JAXBElement<Subset> createSubset(Subset value) {
        return new JAXBElement<Subset>(_Subset_QNAME, Subset.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Prsubset }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prsubset")
    public JAXBElement<Prsubset> createPrsubset(Prsubset value) {
        return new JAXBElement<Prsubset>(_Prsubset_QNAME, Prsubset.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tendsto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tendsto")
    public JAXBElement<Tendsto> createTendsto(Tendsto value) {
        return new JAXBElement<Tendsto>(_Tendsto_QNAME, Tendsto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ci }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ci")
    public JAXBElement<Ci> createCi(Ci value) {
        return new JAXBElement<Ci>(_Ci_QNAME, Ci.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Csymbol }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "csymbol")
    public JAXBElement<Csymbol> createCsymbol(Csymbol value) {
        return new JAXBElement<Csymbol>(_Csymbol_QNAME, Csymbol.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cn")
    public JAXBElement<Cn> createCn(Cn value) {
        return new JAXBElement<Cn>(_Cn_QNAME, Cn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Apply }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "apply")
    public JAXBElement<Apply> createApply(Apply value) {
        return new JAXBElement<Apply>(_Apply_QNAME, Apply.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Reln }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "reln")
    public JAXBElement<Reln> createReln(Reln value) {
        return new JAXBElement<Reln>(_Reln_QNAME, Reln.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Lambda }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lambda")
    public JAXBElement<Lambda> createLambda(Lambda value) {
        return new JAXBElement<Lambda>(_Lambda_QNAME, Lambda.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Condition }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "condition")
    public JAXBElement<Condition> createCondition(Condition value) {
        return new JAXBElement<Condition>(_Condition_QNAME, Condition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Declare }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "declare")
    public JAXBElement<Declare> createDeclare(Declare value) {
        return new JAXBElement<Declare>(_Declare_QNAME, Declare.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Semantics }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "semantics")
    public JAXBElement<Semantics> createSemantics(Semantics value) {
        return new JAXBElement<Semantics>(_Semantics_QNAME, Semantics.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Annotation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "annotation")
    public JAXBElement<Annotation> createAnnotation(Annotation value) {
        return new JAXBElement<Annotation>(_Annotation_QNAME, Annotation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnotationXml }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "annotation-xml")
    public JAXBElement<AnnotationXml> createAnnotationXml(AnnotationXml value) {
        return new JAXBElement<AnnotationXml>(_AnnotationXml_QNAME, AnnotationXml.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Interval }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "interval")
    public JAXBElement<Interval> createInterval(Interval value) {
        return new JAXBElement<Interval>(_Interval_QNAME, Interval.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Set }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "set")
    public JAXBElement<Set> createSet(Set value) {
        return new JAXBElement<Set>(_Set_QNAME, Set.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "list")
    public JAXBElement<List> createList(List value) {
        return new JAXBElement<List>(_List_QNAME, List.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Vector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "vector")
    public JAXBElement<Vector> createVector(Vector value) {
        return new JAXBElement<Vector>(_Vector_QNAME, Vector.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Matrix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "matrix")
    public JAXBElement<Matrix> createMatrix(Matrix value) {
        return new JAXBElement<Matrix>(_Matrix_QNAME, Matrix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Matrixrow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "matrixrow")
    public JAXBElement<Matrixrow> createMatrixrow(Matrixrow value) {
        return new JAXBElement<Matrixrow>(_Matrixrow_QNAME, Matrixrow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Piecewise }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "piecewise")
    public JAXBElement<Piecewise> createPiecewise(Piecewise value) {
        return new JAXBElement<Piecewise>(_Piecewise_QNAME, Piecewise.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Piece }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "piece")
    public JAXBElement<Piece> createPiece(Piece value) {
        return new JAXBElement<Piece>(_Piece_QNAME, Piece.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Otherwise }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "otherwise")
    public JAXBElement<Otherwise> createOtherwise(Otherwise value) {
        return new JAXBElement<Otherwise>(_Otherwise_QNAME, Otherwise.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fn")
    public JAXBElement<Fn> createFn(Fn value) {
        return new JAXBElement<Fn>(_Fn_QNAME, Fn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Lowlimit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lowlimit")
    public JAXBElement<Lowlimit> createLowlimit(Lowlimit value) {
        return new JAXBElement<Lowlimit>(_Lowlimit_QNAME, Lowlimit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Uplimit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "uplimit")
    public JAXBElement<Uplimit> createUplimit(Uplimit value) {
        return new JAXBElement<Uplimit>(_Uplimit_QNAME, Uplimit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Bvar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bvar")
    public JAXBElement<Bvar> createBvar(Bvar value) {
        return new JAXBElement<Bvar>(_Bvar_QNAME, Bvar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Degree }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "degree")
    public JAXBElement<Degree> createDegree(Degree value) {
        return new JAXBElement<Degree>(_Degree_QNAME, Degree.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Logbase }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "logbase")
    public JAXBElement<Logbase> createLogbase(Logbase value) {
        return new JAXBElement<Logbase>(_Logbase_QNAME, Logbase.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Momentabout }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "momentabout")
    public JAXBElement<Momentabout> createMomentabout(Momentabout value) {
        return new JAXBElement<Momentabout>(_Momentabout_QNAME, Momentabout.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Domainofapplication }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "domainofapplication")
    public JAXBElement<Domainofapplication> createDomainofapplication(Domainofapplication value) {
        return new JAXBElement<Domainofapplication>(_Domainofapplication_QNAME, Domainofapplication.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mstyle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mstyle")
    public JAXBElement<Mstyle> createMstyle(Mstyle value) {
        return new JAXBElement<Mstyle>(_Mstyle_QNAME, Mstyle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Merror }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "merror")
    public JAXBElement<Merror> createMerror(Merror value) {
        return new JAXBElement<Merror>(_Merror_QNAME, Merror.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mphantom }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mphantom")
    public JAXBElement<Mphantom> createMphantom(Mphantom value) {
        return new JAXBElement<Mphantom>(_Mphantom_QNAME, Mphantom.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mrow }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mrow")
    public JAXBElement<Mrow> createMrow(Mrow value) {
        return new JAXBElement<Mrow>(_Mrow_QNAME, Mrow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mfrac }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfrac")
    public JAXBElement<Mfrac> createMfrac(Mfrac value) {
        return new JAXBElement<Mfrac>(_Mfrac_QNAME, Mfrac.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msqrt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msqrt")
    public JAXBElement<Msqrt> createMsqrt(Msqrt value) {
        return new JAXBElement<Msqrt>(_Msqrt_QNAME, Msqrt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Menclose }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "menclose")
    public JAXBElement<Menclose> createMenclose(Menclose value) {
        return new JAXBElement<Menclose>(_Menclose_QNAME, Menclose.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mroot }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mroot")
    public JAXBElement<Mroot> createMroot(Mroot value) {
        return new JAXBElement<Mroot>(_Mroot_QNAME, Mroot.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msub }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msub")
    public JAXBElement<Msub> createMsub(Msub value) {
        return new JAXBElement<Msub>(_Msub_QNAME, Msub.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msup")
    public JAXBElement<Msup> createMsup(Msup value) {
        return new JAXBElement<Msup>(_Msup_QNAME, Msup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msubsup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msubsup")
    public JAXBElement<Msubsup> createMsubsup(Msubsup value) {
        return new JAXBElement<Msubsup>(_Msubsup_QNAME, Msubsup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mmultiscripts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mmultiscripts")
    public JAXBElement<Mmultiscripts> createMmultiscripts(Mmultiscripts value) {
        return new JAXBElement<Mmultiscripts>(_Mmultiscripts_QNAME, Mmultiscripts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Munder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munder")
    public JAXBElement<Munder> createMunder(Munder value) {
        return new JAXBElement<Munder>(_Munder_QNAME, Munder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mover }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mover")
    public JAXBElement<Mover> createMover(Mover value) {
        return new JAXBElement<Mover>(_Mover_QNAME, Mover.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Munderover }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "munderover")
    public JAXBElement<Munderover> createMunderover(Munderover value) {
        return new JAXBElement<Munderover>(_Munderover_QNAME, Munderover.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mtable }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtable")
    public JAXBElement<Mtable> createMtable(Mtable value) {
        return new JAXBElement<Mtable>(_Mtable_QNAME, Mtable.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mtr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtr")
    public JAXBElement<Mtr> createMtr(Mtr value) {
        return new JAXBElement<Mtr>(_Mtr_QNAME, Mtr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mlabeledtr }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mlabeledtr")
    public JAXBElement<Mlabeledtr> createMlabeledtr(Mlabeledtr value) {
        return new JAXBElement<Mlabeledtr>(_Mlabeledtr_QNAME, Mlabeledtr.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mtd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtd")
    public JAXBElement<Mtd> createMtd(Mtd value) {
        return new JAXBElement<Mtd>(_Mtd_QNAME, Mtd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Maction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maction")
    public JAXBElement<Maction> createMaction(Maction value) {
        return new JAXBElement<Maction>(_Maction_QNAME, Maction.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mfenced }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mfenced")
    public JAXBElement<Mfenced> createMfenced(Mfenced value) {
        return new JAXBElement<Mfenced>(_Mfenced_QNAME, Mfenced.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mpadded }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mpadded")
    public JAXBElement<Mpadded> createMpadded(Mpadded value) {
        return new JAXBElement<Mpadded>(_Mpadded_QNAME, Mpadded.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mi }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mi")
    public JAXBElement<Mi> createMi(Mi value) {
        return new JAXBElement<Mi>(_Mi_QNAME, Mi.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mn")
    public JAXBElement<Mn> createMn(Mn value) {
        return new JAXBElement<Mn>(_Mn_QNAME, Mn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mo")
    public JAXBElement<Mo> createMo(Mo value) {
        return new JAXBElement<Mo>(_Mo_QNAME, Mo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mtext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mtext")
    public JAXBElement<Mtext> createMtext(Mtext value) {
        return new JAXBElement<Mtext>(_Mtext_QNAME, Mtext.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ms }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ms")
    public JAXBElement<Ms> createMs(Ms value) {
        return new JAXBElement<Ms>(_Ms_QNAME, Ms.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Math }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "math")
    public JAXBElement<Math> createMath(Math value) {
        return new JAXBElement<Math>(_Math_QNAME, Math.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Table }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table")
    public JAXBElement<Table> createTable(Table value) {
        return new JAXBElement<Table>(_Table_QNAME, Table.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tgroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tgroup")
    public JAXBElement<Tgroup> createTgroup(Tgroup value) {
        return new JAXBElement<Tgroup>(_Tgroup_QNAME, Tgroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Colspec }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colspec")
    public JAXBElement<Colspec> createColspec(Colspec value) {
        return new JAXBElement<Colspec>(_Colspec_QNAME, Colspec.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Thead }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "thead")
    public JAXBElement<Thead> createThead(Thead value) {
        return new JAXBElement<Thead>(_Thead_QNAME, Thead.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tbody }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tbody")
    public JAXBElement<Tbody> createTbody(Tbody value) {
        return new JAXBElement<Tbody>(_Tbody_QNAME, Tbody.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Row }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "row")
    public JAXBElement<Row> createRow(Row value) {
        return new JAXBElement<Row>(_Row_QNAME, Row.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Entry }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "entry")
    public JAXBElement<Entry> createEntry(Entry value) {
        return new JAXBElement<Entry>(_Entry_QNAME, Entry.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Title }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "title")
    public JAXBElement<Title> createTitle(Title value) {
        return new JAXBElement<Title>(_Title_QNAME, Title.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoApplicationBody }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-application-body")
    public JAXBElement<WoApplicationBody> createWoApplicationBody(WoApplicationBody value) {
        return new JAXBElement<WoApplicationBody>(_WoApplicationBody_QNAME, WoApplicationBody.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoAmendedClaims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-amended-claims")
    public JAXBElement<WoAmendedClaims> createWoAmendedClaims(WoAmendedClaims value) {
        return new JAXBElement<WoAmendedClaims>(_WoAmendedClaims_QNAME, WoAmendedClaims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReplaceObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "replace-object")
    public JAXBElement<ReplaceObject> createReplaceObject(ReplaceObject value) {
        return new JAXBElement<ReplaceObject>(_ReplaceObject_QNAME, ReplaceObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertAfterObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insert-after-object")
    public JAXBElement<InsertAfterObject> createInsertAfterObject(InsertAfterObject value) {
        return new JAXBElement<InsertAfterObject>(_InsertAfterObject_QNAME, InsertAfterObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertBeforeObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insert-before-object")
    public JAXBElement<InsertBeforeObject> createInsertBeforeObject(InsertBeforeObject value) {
        return new JAXBElement<InsertBeforeObject>(_InsertBeforeObject_QNAME, InsertBeforeObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "delete-object")
    public JAXBElement<DeleteObject> createDeleteObject(DeleteObject value) {
        return new JAXBElement<DeleteObject>(_DeleteObject_QNAME, DeleteObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmendBody }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amend-body")
    public JAXBElement<AmendBody> createAmendBody(AmendBody value) {
        return new JAXBElement<AmendBody>(_AmendBody_QNAME, AmendBody.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Drawings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "drawings")
    public JAXBElement<Drawings> createDrawings(Drawings value) {
        return new JAXBElement<Drawings>(_Drawings_QNAME, Drawings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Figure }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figure")
    public JAXBElement<Figure> createFigure(Figure value) {
        return new JAXBElement<Figure>(_Figure_QNAME, Figure.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Abstract }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abstract")
    public JAXBElement<Abstract> createAbstract(Abstract value) {
        return new JAXBElement<Abstract>(_Abstract_QNAME, Abstract.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstSolution }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abst-solution")
    public JAXBElement<AbstSolution> createAbstSolution(AbstSolution value) {
        return new JAXBElement<AbstSolution>(_AbstSolution_QNAME, AbstSolution.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AbstProblem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "abst-problem")
    public JAXBElement<AbstProblem> createAbstProblem(AbstProblem value) {
        return new JAXBElement<AbstProblem>(_AbstProblem_QNAME, AbstProblem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmendStatement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amend-statement")
    public JAXBElement<AmendStatement> createAmendStatement(AmendStatement value) {
        return new JAXBElement<AmendStatement>(_AmendStatement_QNAME, AmendStatement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Claims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claims")
    public JAXBElement<Claims> createClaims(Claims value) {
        return new JAXBElement<Claims>(_Claims_QNAME, Claims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Claim }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim")
    public JAXBElement<Claim> createClaim(Claim value) {
        return new JAXBElement<Claim>(_Claim_QNAME, Claim.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim-ref")
    public JAXBElement<ClaimRef> createClaimRef(ClaimRef value) {
        return new JAXBElement<ClaimRef>(_ClaimRef_QNAME, ClaimRef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Description }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description")
    public JAXBElement<Description> createDescription(Description value) {
        return new JAXBElement<Description>(_Description_QNAME, Description.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CitationList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "citation-list")
    public JAXBElement<CitationList> createCitationList(CitationList value) {
        return new JAXBElement<CitationList>(_CitationList_QNAME, CitationList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonPatentLiterature }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "non-patent-literature")
    public JAXBElement<NonPatentLiterature> createNonPatentLiterature(NonPatentLiterature value) {
        return new JAXBElement<NonPatentLiterature>(_NonPatentLiterature_QNAME, NonPatentLiterature.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PatentLiterature }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patent-literature")
    public JAXBElement<PatentLiterature> createPatentLiterature(PatentLiterature value) {
        return new JAXBElement<PatentLiterature>(_PatentLiterature_QNAME, PatentLiterature.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SequenceListText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sequence-list-text")
    public JAXBElement<SequenceListText> createSequenceListText(SequenceListText value) {
        return new JAXBElement<SequenceListText>(_SequenceListText_QNAME, SequenceListText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReferenceToDepositedBiologicalMaterial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "reference-to-deposited-biological-material")
    public JAXBElement<ReferenceToDepositedBiologicalMaterial> createReferenceToDepositedBiologicalMaterial(ReferenceToDepositedBiologicalMaterial value) {
        return new JAXBElement<ReferenceToDepositedBiologicalMaterial>(_ReferenceToDepositedBiologicalMaterial_QNAME, ReferenceToDepositedBiologicalMaterial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReferenceSignsList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "reference-signs-list")
    public JAXBElement<ReferenceSignsList> createReferenceSignsList(ReferenceSignsList value) {
        return new JAXBElement<ReferenceSignsList>(_ReferenceSignsList_QNAME, ReferenceSignsList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IndustrialApplicability }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "industrial-applicability")
    public JAXBElement<IndustrialApplicability> createIndustrialApplicability(IndustrialApplicability value) {
        return new JAXBElement<IndustrialApplicability>(_IndustrialApplicability_QNAME, IndustrialApplicability.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModeForInvention }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mode-for-invention")
    public JAXBElement<ModeForInvention> createModeForInvention(ModeForInvention value) {
        return new JAXBElement<ModeForInvention>(_ModeForInvention_QNAME, ModeForInvention.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BestMode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "best-mode")
    public JAXBElement<BestMode> createBestMode(BestMode value) {
        return new JAXBElement<BestMode>(_BestMode_QNAME, BestMode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DescriptionOfEmbodiments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description-of-embodiments")
    public JAXBElement<DescriptionOfEmbodiments> createDescriptionOfEmbodiments(DescriptionOfEmbodiments value) {
        return new JAXBElement<DescriptionOfEmbodiments>(_DescriptionOfEmbodiments_QNAME, DescriptionOfEmbodiments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EmbodimentsExample }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "embodiments-example")
    public JAXBElement<EmbodimentsExample> createEmbodimentsExample(EmbodimentsExample value) {
        return new JAXBElement<EmbodimentsExample>(_EmbodimentsExample_QNAME, EmbodimentsExample.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DescriptionOfDrawings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description-of-drawings")
    public JAXBElement<DescriptionOfDrawings> createDescriptionOfDrawings(DescriptionOfDrawings value) {
        return new JAXBElement<DescriptionOfDrawings>(_DescriptionOfDrawings_QNAME, DescriptionOfDrawings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SummaryOfInvention }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "summary-of-invention")
    public JAXBElement<SummaryOfInvention> createSummaryOfInvention(SummaryOfInvention value) {
        return new JAXBElement<SummaryOfInvention>(_SummaryOfInvention_QNAME, SummaryOfInvention.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Disclosure }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "disclosure")
    public JAXBElement<Disclosure> createDisclosure(Disclosure value) {
        return new JAXBElement<Disclosure>(_Disclosure_QNAME, Disclosure.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdvantageousEffects }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "advantageous-effects")
    public JAXBElement<AdvantageousEffects> createAdvantageousEffects(AdvantageousEffects value) {
        return new JAXBElement<AdvantageousEffects>(_AdvantageousEffects_QNAME, AdvantageousEffects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechSolution }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tech-solution")
    public JAXBElement<TechSolution> createTechSolution(TechSolution value) {
        return new JAXBElement<TechSolution>(_TechSolution_QNAME, TechSolution.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechProblem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tech-problem")
    public JAXBElement<TechProblem> createTechProblem(TechProblem value) {
        return new JAXBElement<TechProblem>(_TechProblem_QNAME, TechProblem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BackgroundArt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "background-art")
    public JAXBElement<BackgroundArt> createBackgroundArt(BackgroundArt value) {
        return new JAXBElement<BackgroundArt>(_BackgroundArt_QNAME, BackgroundArt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TechnicalField }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "technical-field")
    public JAXBElement<TechnicalField> createTechnicalField(TechnicalField value) {
        return new JAXBElement<TechnicalField>(_TechnicalField_QNAME, TechnicalField.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link P }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "p")
    public JAXBElement<P> createP(P value) {
        return new JAXBElement<P>(_P_QNAME, P.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TableExternalDoc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "table-external-doc")
    public JAXBElement<TableExternalDoc> createTableExternalDoc(TableExternalDoc value) {
        return new JAXBElement<TableExternalDoc>(_TableExternalDoc_QNAME, TableExternalDoc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tables }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tables")
    public JAXBElement<Tables> createTables(Tables value) {
        return new JAXBElement<Tables>(_Tables_QNAME, Tables.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dl")
    public JAXBElement<Dl> createDl(Dl value) {
        return new JAXBElement<Dl>(_Dl_QNAME, Dl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dt")
    public JAXBElement<Dt> createDt(Dt value) {
        return new JAXBElement<Dt>(_Dt_QNAME, Dt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ul }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ul")
    public JAXBElement<Ul> createUl(Ul value) {
        return new JAXBElement<Ul>(_Ul_QNAME, Ul.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Li }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "li")
    public JAXBElement<Li> createLi(Li value) {
        return new JAXBElement<Li>(_Li_QNAME, Li.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Maths }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maths")
    public JAXBElement<Maths> createMaths(Maths value) {
        return new JAXBElement<Maths>(_Maths_QNAME, Maths.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chemistry }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chemistry")
    public JAXBElement<Chemistry> createChemistry(Chemistry value) {
        return new JAXBElement<Chemistry>(_Chemistry_QNAME, Chemistry.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chem")
    public JAXBElement<Chem> createChem(Chem value) {
        return new JAXBElement<Chem>(_Chem_QNAME, Chem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ol }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ol")
    public JAXBElement<Ol> createOl(Ol value) {
        return new JAXBElement<Ol>(_Ol_QNAME, Ol.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Img }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "img")
    public JAXBElement<Img> createImg(Img value) {
        return new JAXBElement<Img>(_Img_QNAME, Img.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Figref }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "figref")
    public JAXBElement<Figref> createFigref(Figref value) {
        return new JAXBElement<Figref>(_Figref_QNAME, Figref.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Crossref }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "crossref")
    public JAXBElement<Crossref> createCrossref(Crossref value) {
        return new JAXBElement<Crossref>(_Crossref_QNAME, Crossref.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioDeposit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-deposit")
    public JAXBElement<BioDeposit> createBioDeposit(BioDeposit value) {
        return new JAXBElement<BioDeposit>(_BioDeposit_QNAME, BioDeposit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Nplcit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "nplcit")
    public JAXBElement<Nplcit> createNplcit(Nplcit value) {
        return new JAXBElement<Nplcit>(_Nplcit_QNAME, Nplcit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Refno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "refno")
    public JAXBElement<Refno> createRefno(Refno value) {
        return new JAXBElement<Refno>(_Refno_QNAME, Refno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Class }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "class")
    public JAXBElement<Class> createClass(Class value) {
        return new JAXBElement<Class>(_Class_QNAME, Class.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subname")
    public JAXBElement<Subname> createSubname(Subname value) {
        return new JAXBElement<Subname>(_Subname_QNAME, Subname.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Author }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "author")
    public JAXBElement<Author> createAuthor(Author value) {
        return new JAXBElement<Author>(_Author_QNAME, Author.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addressbook }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressbook")
    public JAXBElement<Addressbook> createAddressbook(Addressbook value) {
        return new JAXBElement<Addressbook>(_Addressbook_QNAME, Addressbook.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Email }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "email")
    public JAXBElement<Email> createEmail(Email value) {
        return new JAXBElement<Email>(_Email_QNAME, Email.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Patcit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "patcit")
    public JAXBElement<Patcit> createPatcit(Patcit value) {
        return new JAXBElement<Patcit>(_Patcit_QNAME, Patcit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pre }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pre")
    public JAXBElement<Pre> createPre(Pre value) {
        return new JAXBElement<Pre>(_Pre_QNAME, Pre.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Heading }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "heading")
    public JAXBElement<Heading> createHeading(Heading value) {
        return new JAXBElement<Heading>(_Heading_QNAME, Heading.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InventionTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "invention-title")
    public JAXBElement<InventionTitle> createInventionTitle(InventionTitle value) {
        return new JAXBElement<InventionTitle>(_InventionTitle_QNAME, InventionTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link U }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "u")
    public JAXBElement<U> createU(U value) {
        return new JAXBElement<U>(_U_QNAME, U.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link O }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "o")
    public JAXBElement<O> createO(O value) {
        return new JAXBElement<O>(_O_QNAME, O.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocPage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-page")
    public JAXBElement<DocPage> createDocPage(DocPage value) {
        return new JAXBElement<DocPage>(_DocPage_QNAME, DocPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "application-reference")
    public JAXBElement<ApplicationReference> createApplicationReference(ApplicationReference value) {
        return new JAXBElement<ApplicationReference>(_ApplicationReference_QNAME, ApplicationReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IsrStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "isr-status")
    public JAXBElement<IsrStatus> createIsrStatus(IsrStatus value) {
        return new JAXBElement<IsrStatus>(_IsrStatus_QNAME, IsrStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoDtext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-dtext")
    public JAXBElement<WoDtext> createWoDtext(WoDtext value) {
        return new JAXBElement<WoDtext>(_WoDtext_QNAME, WoDtext.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublicationReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "publication-reference")
    public JAXBElement<PublicationReference> createPublicationReference(PublicationReference value) {
        return new JAXBElement<PublicationReference>(_PublicationReference_QNAME, PublicationReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "document-id")
    public JAXBElement<DocumentId> createDocumentId(DocumentId value) {
        return new JAXBElement<DocumentId>(_DocumentId_QNAME, DocumentId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Name }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name")
    public JAXBElement<Name> createName(Name value) {
        return new JAXBElement<Name>(_Name_QNAME, Name.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Statement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "statement")
    public JAXBElement<Statement> createStatement(Statement value) {
        return new JAXBElement<Statement>(_Statement_QNAME, Statement.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "claim-text")
    public JAXBElement<ClaimText> createClaimText(ClaimText value) {
        return new JAXBElement<ClaimText>(_ClaimText_QNAME, ClaimText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dd")
    public JAXBElement<Dd> createDd(Dd value) {
        return new JAXBElement<Dd>(_Dd_QNAME, Dd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Term }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "term")
    public JAXBElement<Term> createTerm(Term value) {
        return new JAXBElement<Term>(_Term_QNAME, Term.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioAccno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bio-accno")
    public JAXBElement<BioAccno> createBioAccno(BioAccno value) {
        return new JAXBElement<BioAccno>(_BioAccno_QNAME, BioAccno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Depositary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "depositary")
    public JAXBElement<Depositary> createDepositary(Depositary value) {
        return new JAXBElement<Depositary>(_Depositary_QNAME, Depositary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Othercit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "othercit")
    public JAXBElement<Othercit> createOthercit(Othercit value) {
        return new JAXBElement<Othercit>(_Othercit_QNAME, Othercit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Online }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "online")
    public JAXBElement<Online> createOnline(Online value) {
        return new JAXBElement<Online>(_Online_QNAME, Online.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Srchdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "srchdate")
    public JAXBElement<Srchdate> createSrchdate(Srchdate value) {
        return new JAXBElement<Srchdate>(_Srchdate_QNAME, Srchdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Srchterm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "srchterm")
    public JAXBElement<Srchterm> createSrchterm(Srchterm value) {
        return new JAXBElement<Srchterm>(_Srchterm_QNAME, Srchterm.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Datecit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "datecit")
    public JAXBElement<Datecit> createDatecit(Datecit value) {
        return new JAXBElement<Datecit>(_Datecit_QNAME, Datecit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Avail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "avail")
    public JAXBElement<Avail> createAvail(Avail value) {
        return new JAXBElement<Avail>(_Avail_QNAME, Avail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Hostno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hostno")
    public JAXBElement<Hostno> createHostno(Hostno value) {
        return new JAXBElement<Hostno>(_Hostno_QNAME, Hostno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link History }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "history")
    public JAXBElement<History> createHistory(History value) {
        return new JAXBElement<History>(_History_QNAME, History.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Misc }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "misc")
    public JAXBElement<Misc> createMisc(Misc value) {
        return new JAXBElement<Misc>(_Misc_QNAME, Misc.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Revised }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "revised")
    public JAXBElement<Revised> createRevised(Revised value) {
        return new JAXBElement<Revised>(_Revised_QNAME, Revised.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Accepted }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accepted")
    public JAXBElement<Accepted> createAccepted(Accepted value) {
        return new JAXBElement<Accepted>(_Accepted_QNAME, Accepted.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Received }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "received")
    public JAXBElement<Received> createReceived(Received value) {
        return new JAXBElement<Received>(_Received_QNAME, Received.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Hosttitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "hosttitle")
    public JAXBElement<Hosttitle> createHosttitle(Hosttitle value) {
        return new JAXBElement<Hosttitle>(_Hosttitle_QNAME, Hosttitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OnlineTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "online-title")
    public JAXBElement<OnlineTitle> createOnlineTitle(OnlineTitle value) {
        return new JAXBElement<OnlineTitle>(_OnlineTitle_QNAME, OnlineTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Article }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "article")
    public JAXBElement<Article> createArticle(Article value) {
        return new JAXBElement<Article>(_Article_QNAME, Article.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Artid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "artid")
    public JAXBElement<Artid> createArtid(Artid value) {
        return new JAXBElement<Artid>(_Artid_QNAME, Artid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Book }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "book")
    public JAXBElement<Book> createBook(Book value) {
        return new JAXBElement<Book>(_Book_QNAME, Book.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Keyword }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "keyword")
    public JAXBElement<Keyword> createKeyword(Keyword value) {
        return new JAXBElement<Keyword>(_Keyword_QNAME, Keyword.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Bookno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bookno")
    public JAXBElement<Bookno> createBookno(Bookno value) {
        return new JAXBElement<Bookno>(_Bookno_QNAME, Bookno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Location }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "location")
    public JAXBElement<Location> createLocation(Location value) {
        return new JAXBElement<Location>(_Location_QNAME, Location.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Line }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "line")
    public JAXBElement<Line> createLine(Line value) {
        return new JAXBElement<Line>(_Line_QNAME, Line.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Linel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linel")
    public JAXBElement<Linel> createLinel(Linel value) {
        return new JAXBElement<Linel>(_Linel_QNAME, Linel.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Linef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "linef")
    public JAXBElement<Linef> createLinef(Linef value) {
        return new JAXBElement<Linef>(_Linef_QNAME, Linef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Para }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "para")
    public JAXBElement<Para> createPara(Para value) {
        return new JAXBElement<Para>(_Para_QNAME, Para.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Paral }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paral")
    public JAXBElement<Paral> createParal(Paral value) {
        return new JAXBElement<Paral>(_Paral_QNAME, Paral.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Paraf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paraf")
    public JAXBElement<Paraf> createParaf(Paraf value) {
        return new JAXBElement<Paraf>(_Paraf_QNAME, Paraf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Column }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "column")
    public JAXBElement<Column> createColumn(Column value) {
        return new JAXBElement<Column>(_Column_QNAME, Column.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Coll }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "coll")
    public JAXBElement<Coll> createColl(Coll value) {
        return new JAXBElement<Coll>(_Coll_QNAME, Coll.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Colf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "colf")
    public JAXBElement<Colf> createColf(Colf value) {
        return new JAXBElement<Colf>(_Colf_QNAME, Colf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pp }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pp")
    public JAXBElement<Pp> createPp(Pp value) {
        return new JAXBElement<Pp>(_Pp_QNAME, Pp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ppl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppl")
    public JAXBElement<Ppl> createPpl(Ppl value) {
        return new JAXBElement<Ppl>(_Ppl_QNAME, Ppl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ppf }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ppf")
    public JAXBElement<Ppf> createPpf(Ppf value) {
        return new JAXBElement<Ppf>(_Ppf_QNAME, Ppf.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Chapter }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chapter")
    public JAXBElement<Chapter> createChapter(Chapter value) {
        return new JAXBElement<Chapter>(_Chapter_QNAME, Chapter.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sersect }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sersect")
    public JAXBElement<Sersect> createSersect(Sersect value) {
        return new JAXBElement<Sersect>(_Sersect_QNAME, Sersect.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Serpart }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "serpart")
    public JAXBElement<Serpart> createSerpart(Serpart value) {
        return new JAXBElement<Serpart>(_Serpart_QNAME, Serpart.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Absno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "absno")
    public JAXBElement<Absno> createAbsno(Absno value) {
        return new JAXBElement<Absno>(_Absno_QNAME, Absno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Series }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "series")
    public JAXBElement<Series> createSeries(Series value) {
        return new JAXBElement<Series>(_Series_QNAME, Series.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Msn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "msn")
    public JAXBElement<Msn> createMsn(Msn value) {
        return new JAXBElement<Msn>(_Msn_QNAME, Msn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mst }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mst")
    public JAXBElement<Mst> createMst(Mst value) {
        return new JAXBElement<Mst>(_Mst_QNAME, Mst.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Edition }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edition")
    public JAXBElement<Edition> createEdition(Edition value) {
        return new JAXBElement<Edition>(_Edition_QNAME, Edition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Subtitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "subtitle")
    public JAXBElement<Subtitle> createSubtitle(Subtitle value) {
        return new JAXBElement<Subtitle>(_Subtitle_QNAME, Subtitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Conference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conference")
    public JAXBElement<Conference> createConference(Conference value) {
        return new JAXBElement<Conference>(_Conference_QNAME, Conference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confdate")
    public JAXBElement<Confdate> createConfdate(Confdate value) {
        return new JAXBElement<Confdate>(_Confdate_QNAME, Confdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confsponsor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confsponsor")
    public JAXBElement<Confsponsor> createConfsponsor(Confsponsor value) {
        return new JAXBElement<Confsponsor>(_Confsponsor_QNAME, Confsponsor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confplace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confplace")
    public JAXBElement<Confplace> createConfplace(Confplace value) {
        return new JAXBElement<Confplace>(_Confplace_QNAME, Confplace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Confno }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confno")
    public JAXBElement<Confno> createConfno(Confno value) {
        return new JAXBElement<Confno>(_Confno_QNAME, Confno.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Conftitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conftitle")
    public JAXBElement<Conftitle> createConftitle(Conftitle value) {
        return new JAXBElement<Conftitle>(_Conftitle_QNAME, Conftitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BookTitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "book-title")
    public JAXBElement<BookTitle> createBookTitle(BookTitle value) {
        return new JAXBElement<BookTitle>(_BookTitle_QNAME, BookTitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Serial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "serial")
    public JAXBElement<Serial> createSerial(Serial value) {
        return new JAXBElement<Serial>(_Serial_QNAME, Serial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Doi }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doi")
    public JAXBElement<Doi> createDoi(Doi value) {
        return new JAXBElement<Doi>(_Doi_QNAME, Doi.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Cpyrt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cpyrt")
    public JAXBElement<Cpyrt> createCpyrt(Cpyrt value) {
        return new JAXBElement<Cpyrt>(_Cpyrt_QNAME, Cpyrt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ino }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ino")
    public JAXBElement<Ino> createIno(Ino value) {
        return new JAXBElement<Ino>(_Ino_QNAME, Ino.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Vid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "vid")
    public JAXBElement<Vid> createVid(Vid value) {
        return new JAXBElement<Vid>(_Vid_QNAME, Vid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pubid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pubid")
    public JAXBElement<Pubid> createPubid(Pubid value) {
        return new JAXBElement<Pubid>(_Pubid_QNAME, Pubid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Isbn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "isbn")
    public JAXBElement<Isbn> createIsbn(Isbn value) {
        return new JAXBElement<Isbn>(_Isbn_QNAME, Isbn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Issn }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issn")
    public JAXBElement<Issn> createIssn(Issn value) {
        return new JAXBElement<Issn>(_Issn_QNAME, Issn.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Notes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "notes")
    public JAXBElement<Notes> createNotes(Notes value) {
        return new JAXBElement<Notes>(_Notes_QNAME, Notes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Descrip }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "descrip")
    public JAXBElement<Descrip> createDescrip(Descrip value) {
        return new JAXBElement<Descrip>(_Descrip_QNAME, Descrip.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Imprint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "imprint")
    public JAXBElement<Imprint> createImprint(Imprint value) {
        return new JAXBElement<Imprint>(_Imprint_QNAME, Imprint.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pubdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pubdate")
    public JAXBElement<Pubdate> createPubdate(Pubdate value) {
        return new JAXBElement<Pubdate>(_Pubdate_QNAME, Pubdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Time }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "time")
    public JAXBElement<Time> createTime(Time value) {
        return new JAXBElement<Time>(_Time_QNAME, Time.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Edate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "edate")
    public JAXBElement<Edate> createEdate(Edate value) {
        return new JAXBElement<Edate>(_Edate_QNAME, Edate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sdate")
    public JAXBElement<Sdate> createSdate(Sdate value) {
        return new JAXBElement<Sdate>(_Sdate_QNAME, Sdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Issue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "issue")
    public JAXBElement<Issue> createIssue(Issue value) {
        return new JAXBElement<Issue>(_Issue_QNAME, Issue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Alttitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "alttitle")
    public JAXBElement<Alttitle> createAlttitle(Alttitle value) {
        return new JAXBElement<Alttitle>(_Alttitle_QNAME, Alttitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sertitle }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sertitle")
    public JAXBElement<Sertitle> createSertitle(Sertitle value) {
        return new JAXBElement<Sertitle>(_Sertitle_QNAME, Sertitle.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Atl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "atl")
    public JAXBElement<Atl> createAtl(Atl value) {
        return new JAXBElement<Atl>(_Atl_QNAME, Atl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Url }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "url")
    public JAXBElement<Url> createUrl(Url value) {
        return new JAXBElement<Url>(_Url_QNAME, Url.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fax }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fax")
    public JAXBElement<Fax> createFax(Fax value) {
        return new JAXBElement<Fax>(_Fax_QNAME, Fax.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Phone }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "phone")
    public JAXBElement<Phone> createPhone(Phone value) {
        return new JAXBElement<Phone>(_Phone_QNAME, Phone.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ead }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ead")
    public JAXBElement<Ead> createEad(Ead value) {
        return new JAXBElement<Ead>(_Ead_QNAME, Ead.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address")
    public JAXBElement<Address> createAddress(Address value) {
        return new JAXBElement<Address>(_Address_QNAME, Address.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Postcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postcode")
    public JAXBElement<Postcode> createPostcode(Postcode value) {
        return new JAXBElement<Postcode>(_Postcode_QNAME, Postcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link State }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state")
    public JAXBElement<State> createState(State value) {
        return new JAXBElement<State>(_State_QNAME, State.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link County }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "county")
    public JAXBElement<County> createCounty(County value) {
        return new JAXBElement<County>(_County_QNAME, County.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link City }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "city")
    public JAXBElement<City> createCity(City value) {
        return new JAXBElement<City>(_City_QNAME, City.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Street }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "street")
    public JAXBElement<Street> createStreet(Street value) {
        return new JAXBElement<Street>(_Street_QNAME, Street.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Building }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "building")
    public JAXBElement<Building> createBuilding(Building value) {
        return new JAXBElement<Building>(_Building_QNAME, Building.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressFloor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-floor")
    public JAXBElement<AddressFloor> createAddressFloor(AddressFloor value) {
        return new JAXBElement<AddressFloor>(_AddressFloor_QNAME, AddressFloor.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Room }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "room")
    public JAXBElement<Room> createRoom(Room value) {
        return new JAXBElement<Room>(_Room_QNAME, Room.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pobox }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pobox")
    public JAXBElement<Pobox> createPobox(Pobox value) {
        return new JAXBElement<Pobox>(_Pobox_QNAME, Pobox.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Mailcode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "mailcode")
    public JAXBElement<Mailcode> createMailcode(Mailcode value) {
        return new JAXBElement<Mailcode>(_Mailcode_QNAME, Mailcode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address5 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-5")
    public JAXBElement<Address5> createAddress5(Address5 value) {
        return new JAXBElement<Address5>(_Address5_QNAME, Address5 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address4 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-4")
    public JAXBElement<Address4> createAddress4(Address4 value) {
        return new JAXBElement<Address4>(_Address4_QNAME, Address4 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address3 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-3")
    public JAXBElement<Address3> createAddress3(Address3 value) {
        return new JAXBElement<Address3>(_Address3_QNAME, Address3 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-2")
    public JAXBElement<Address2> createAddress2(Address2 value) {
        return new JAXBElement<Address2>(_Address2_QNAME, Address2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address1 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "address-1")
    public JAXBElement<Address1> createAddress1(Address1 value) {
        return new JAXBElement<Address1>(_Address1_QNAME, Address1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisteredNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "registered-number")
    public JAXBElement<RegisteredNumber> createRegisteredNumber(RegisteredNumber value) {
        return new JAXBElement<RegisteredNumber>(_RegisteredNumber_QNAME, RegisteredNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Synonym }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "synonym")
    public JAXBElement<Synonym> createSynonym(Synonym value) {
        return new JAXBElement<Synonym>(_Synonym_QNAME, Synonym.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Department }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "department")
    public JAXBElement<Department> createDepartment(Department value) {
        return new JAXBElement<Department>(_Department_QNAME, Department.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Orgname }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "orgname")
    public JAXBElement<Orgname> createOrgname(Orgname value) {
        return new JAXBElement<Orgname>(_Orgname_QNAME, Orgname.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Role }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "role")
    public JAXBElement<Role> createRole(Role value) {
        return new JAXBElement<Role>(_Role_QNAME, Role.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Iid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "iid")
    public JAXBElement<Iid> createIid(Iid value) {
        return new JAXBElement<Iid>(_Iid_QNAME, Iid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Suffix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix")
    public JAXBElement<Suffix> createSuffix(Suffix value) {
        return new JAXBElement<Suffix>(_Suffix_QNAME, Suffix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MiddleName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "middle-name")
    public JAXBElement<MiddleName> createMiddleName(MiddleName value) {
        return new JAXBElement<MiddleName>(_MiddleName_QNAME, MiddleName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FirstName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "first-name")
    public JAXBElement<FirstName> createFirstName(FirstName value) {
        return new JAXBElement<FirstName>(_FirstName_QNAME, FirstName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LastName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "last-name")
    public JAXBElement<LastName> createLastName(LastName value) {
        return new JAXBElement<LastName>(_LastName_QNAME, LastName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Prefix }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "prefix")
    public JAXBElement<Prefix> createPrefix(Prefix value) {
        return new JAXBElement<Prefix>(_Prefix_QNAME, Prefix.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelPassage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rel-passage")
    public JAXBElement<RelPassage> createRelPassage(RelPassage value) {
        return new JAXBElement<RelPassage>(_RelPassage_QNAME, RelPassage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelClaims }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "rel-claims")
    public JAXBElement<RelClaims> createRelClaims(RelClaims value) {
        return new JAXBElement<RelClaims>(_RelClaims_QNAME, RelClaims.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Category }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "category")
    public JAXBElement<Category> createCategory(Category value) {
        return new JAXBElement<Category>(_Category_QNAME, Category.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Passage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "passage")
    public JAXBElement<Passage> createPassage(Passage value) {
        return new JAXBElement<Passage>(_Passage_QNAME, Passage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Text }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "text")
    public JAXBElement<Text> createText(Text value) {
        return new JAXBElement<Text>(_Text_QNAME, Text.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link B }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "b")
    public JAXBElement<B> createB(B value) {
        return new JAXBElement<B>(_B_QNAME, B.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link I }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "i")
    public JAXBElement<I> createI(I value) {
        return new JAXBElement<I>(_I_QNAME, I.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Smallcaps }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smallcaps")
    public JAXBElement<Smallcaps> createSmallcaps(Smallcaps value) {
        return new JAXBElement<Smallcaps>(_Smallcaps_QNAME, Smallcaps.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub")
    public JAXBElement<Sub> createSub(Sub value) {
        return new JAXBElement<Sub>(_Sub_QNAME, Sub.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup")
    public JAXBElement<Sup> createSup(Sup value) {
        return new JAXBElement<Sup>(_Sup_QNAME, Sup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sub2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sub2")
    public JAXBElement<Sub2> createSub2(Sub2 value) {
        return new JAXBElement<Sub2>(_Sub2_QNAME, Sub2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Sup2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sup2")
    public JAXBElement<Sup2> createSup2(Sup2 value) {
        return new JAXBElement<Sup2>(_Sup2_QNAME, Sup2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoPublicationInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-publication-info")
    public JAXBElement<WoPublicationInfo> createWoPublicationInfo(WoPublicationInfo value) {
        return new JAXBElement<WoPublicationInfo>(_WoPublicationInfo_QNAME, WoPublicationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoPubnum }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-pubnum")
    public JAXBElement<WoPubnum> createWoPubnum(WoPubnum value) {
        return new JAXBElement<WoPubnum>(_WoPubnum_QNAME, WoPubnum.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PctPubInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pct-pub-info")
    public JAXBElement<PctPubInfo> createPctPubInfo(PctPubInfo value) {
        return new JAXBElement<PctPubInfo>(_PctPubInfo_QNAME, PctPubInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoPublishedText }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-published-text")
    public JAXBElement<WoPublishedText> createWoPublishedText(WoPublishedText value) {
        return new JAXBElement<WoPublishedText>(_WoPublishedText_QNAME, WoPublishedText.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoTextLetterCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-text-letter-code")
    public JAXBElement<WoTextLetterCode> createWoTextLetterCode(WoTextLetterCode value) {
        return new JAXBElement<WoTextLetterCode>(_WoTextLetterCode_QNAME, WoTextLetterCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PctArt64 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pct-art64")
    public JAXBElement<PctArt64> createPctArt64(PctArt64 value) {
        return new JAXBElement<PctArt64>(_PctArt64_QNAME, PctArt64 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoBioMaterialAfterPub }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-bio-material-after-pub")
    public JAXBElement<WoBioMaterialAfterPub> createWoBioMaterialAfterPub(WoBioMaterialAfterPub value) {
        return new JAXBElement<WoBioMaterialAfterPub>(_WoBioMaterialAfterPub_QNAME, WoBioMaterialAfterPub.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RelevantDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "relevant-date")
    public JAXBElement<RelevantDate> createRelevantDate(RelevantDate value) {
        return new JAXBElement<RelevantDate>(_RelevantDate_QNAME, RelevantDate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReceivedAtIb }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "received-at-ib")
    public JAXBElement<ReceivedAtIb> createReceivedAtIb(ReceivedAtIb value) {
        return new JAXBElement<ReceivedAtIb>(_ReceivedAtIb_QNAME, ReceivedAtIb.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoCorrection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-correction")
    public JAXBElement<WoCorrection> createWoCorrection(WoCorrection value) {
        return new JAXBElement<WoCorrection>(_WoCorrection_QNAME, WoCorrection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Dtext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dtext")
    public JAXBElement<Dtext> createDtext(Dtext value) {
        return new JAXBElement<Dtext>(_Dtext_QNAME, Dtext.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Br }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "br")
    public JAXBElement<Br> createBr(Br value) {
        return new JAXBElement<Br>(_Br_QNAME, Br.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WoRepubCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wo-repub-code")
    public JAXBElement<WoRepubCode> createWoRepubCode(WoRepubCode value) {
        return new JAXBElement<WoRepubCode>(_WoRepubCode_QNAME, WoRepubCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TypeOfCorrection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "type-of-correction")
    public JAXBElement<TypeOfCorrection> createTypeOfCorrection(TypeOfCorrection value) {
        return new JAXBElement<TypeOfCorrection>(_TypeOfCorrection_QNAME, TypeOfCorrection.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Date }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date")
    public JAXBElement<Date> createDate(Date value) {
        return new JAXBElement<Date>(_Date_QNAME, Date.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Kind }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "kind")
    public JAXBElement<Kind> createKind(Kind value) {
        return new JAXBElement<Kind>(_Kind_QNAME, Kind.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocNumber }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "doc-number")
    public JAXBElement<DocNumber> createDocNumber(DocNumber value) {
        return new JAXBElement<DocNumber>(_DocNumber_QNAME, DocNumber.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Country }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country")
    public JAXBElement<Country> createCountry(Country value) {
        return new JAXBElement<Country>(_Country_QNAME, Country.class, null, value);
    }

}
