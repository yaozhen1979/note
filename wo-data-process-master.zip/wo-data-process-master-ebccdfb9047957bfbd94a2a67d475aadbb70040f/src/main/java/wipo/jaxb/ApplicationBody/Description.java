//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>description complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="description"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}doc-page" maxOccurs="unbounded"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}invention-title" minOccurs="0"/&gt;
 *           &lt;choice maxOccurs="unbounded"&gt;
 *             &lt;element ref="{}technical-field"/&gt;
 *             &lt;element ref="{}background-art"/&gt;
 *             &lt;element ref="{}disclosure"/&gt;
 *             &lt;element ref="{}summary-of-invention"/&gt;
 *             &lt;element ref="{}description-of-drawings"/&gt;
 *             &lt;element ref="{}description-of-embodiments"/&gt;
 *             &lt;element ref="{}best-mode"/&gt;
 *             &lt;element ref="{}mode-for-invention"/&gt;
 *             &lt;element ref="{}industrial-applicability"/&gt;
 *             &lt;element ref="{}reference-signs-list"/&gt;
 *             &lt;element ref="{}reference-to-deposited-biological-material"/&gt;
 *             &lt;element ref="{}sequence-list-text"/&gt;
 *             &lt;element ref="{}citation-list"/&gt;
 *             &lt;sequence maxOccurs="unbounded"&gt;
 *               &lt;element ref="{}heading" maxOccurs="unbounded" minOccurs="0"/&gt;
 *               &lt;element ref="{}p" maxOccurs="unbounded"/&gt;
 *             &lt;/sequence&gt;
 *           &lt;/choice&gt;
 *         &lt;/sequence&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "description", propOrder = {
    "docPage",
    "inventionTitle",
    "technicalFieldOrBackgroundArtOrDisclosure"
})
public class Description {

    @XmlElement(name = "doc-page")
    protected List<DocPage> docPage;
    @XmlElement(name = "invention-title")
    protected InventionTitle inventionTitle;
    @XmlElements({
        @XmlElement(name = "technical-field", type = TechnicalField.class),
        @XmlElement(name = "background-art", type = BackgroundArt.class),
        @XmlElement(name = "disclosure", type = Disclosure.class),
        @XmlElement(name = "summary-of-invention", type = SummaryOfInvention.class),
        @XmlElement(name = "description-of-drawings", type = DescriptionOfDrawings.class),
        @XmlElement(name = "description-of-embodiments", type = DescriptionOfEmbodiments.class),
        @XmlElement(name = "best-mode", type = BestMode.class),
        @XmlElement(name = "mode-for-invention", type = ModeForInvention.class),
        @XmlElement(name = "industrial-applicability", type = IndustrialApplicability.class),
        @XmlElement(name = "reference-signs-list", type = ReferenceSignsList.class),
        @XmlElement(name = "reference-to-deposited-biological-material", type = ReferenceToDepositedBiologicalMaterial.class),
        @XmlElement(name = "sequence-list-text", type = SequenceListText.class),
        @XmlElement(name = "citation-list", type = CitationList.class),
        @XmlElement(name = "heading", type = Heading.class),
        @XmlElement(name = "p", type = P.class)
    })
    protected List<Object> technicalFieldOrBackgroundArtOrDisclosure;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    @XmlSchemaType(name = "anySimpleType")
    protected String lang;
    @XmlAttribute(name = "status")
    @XmlSchemaType(name = "anySimpleType")
    protected String status;

    /**
     * Gets the value of the docPage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docPage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocPage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocPage }
     * 
     * 
     */
    public List<DocPage> getDocPage() {
        if (docPage == null) {
            docPage = new ArrayList<DocPage>();
        }
        return this.docPage;
    }

    /**
     * 取得 inventionTitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InventionTitle }
     *     
     */
    public InventionTitle getInventionTitle() {
        return inventionTitle;
    }

    /**
     * 設定 inventionTitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InventionTitle }
     *     
     */
    public void setInventionTitle(InventionTitle value) {
        this.inventionTitle = value;
    }

    /**
     * Gets the value of the technicalFieldOrBackgroundArtOrDisclosure property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the technicalFieldOrBackgroundArtOrDisclosure property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTechnicalFieldOrBackgroundArtOrDisclosure().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TechnicalField }
     * {@link BackgroundArt }
     * {@link Disclosure }
     * {@link SummaryOfInvention }
     * {@link DescriptionOfDrawings }
     * {@link DescriptionOfEmbodiments }
     * {@link BestMode }
     * {@link ModeForInvention }
     * {@link IndustrialApplicability }
     * {@link ReferenceSignsList }
     * {@link ReferenceToDepositedBiologicalMaterial }
     * {@link SequenceListText }
     * {@link CitationList }
     * {@link Heading }
     * {@link P }
     * 
     * 
     */
    public List<Object> getTechnicalFieldOrBackgroundArtOrDisclosure() {
        if (technicalFieldOrBackgroundArtOrDisclosure == null) {
            technicalFieldOrBackgroundArtOrDisclosure = new ArrayList<Object>();
        }
        return this.technicalFieldOrBackgroundArtOrDisclosure;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
