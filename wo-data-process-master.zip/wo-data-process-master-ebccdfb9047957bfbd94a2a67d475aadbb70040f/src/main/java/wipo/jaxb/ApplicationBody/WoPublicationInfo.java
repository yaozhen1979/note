//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>wo-publication-info complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="wo-publication-info"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}wo-correction" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}wo-bio-material-after-pub" minOccurs="0"/&gt;
 *         &lt;element ref="{}isr-status" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}pct-pub-info" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}wo-pubnum" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "wo-publication-info", propOrder = {
    "woCorrection",
    "woBioMaterialAfterPub",
    "isrStatus",
    "pctPubInfo",
    "woPubnum"
})
public class WoPublicationInfo {

    @XmlElement(name = "wo-correction")
    protected List<WoCorrection> woCorrection;
    @XmlElement(name = "wo-bio-material-after-pub")
    protected WoBioMaterialAfterPub woBioMaterialAfterPub;
    @XmlElement(name = "isr-status")
    protected List<IsrStatus> isrStatus;
    @XmlElement(name = "pct-pub-info")
    protected List<PctPubInfo> pctPubInfo;
    @XmlElement(name = "wo-pubnum")
    protected WoPubnum woPubnum;

    /**
     * Gets the value of the woCorrection property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the woCorrection property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWoCorrection().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WoCorrection }
     * 
     * 
     */
    public List<WoCorrection> getWoCorrection() {
        if (woCorrection == null) {
            woCorrection = new ArrayList<WoCorrection>();
        }
        return this.woCorrection;
    }

    /**
     * 取得 woBioMaterialAfterPub 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link WoBioMaterialAfterPub }
     *     
     */
    public WoBioMaterialAfterPub getWoBioMaterialAfterPub() {
        return woBioMaterialAfterPub;
    }

    /**
     * 設定 woBioMaterialAfterPub 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link WoBioMaterialAfterPub }
     *     
     */
    public void setWoBioMaterialAfterPub(WoBioMaterialAfterPub value) {
        this.woBioMaterialAfterPub = value;
    }

    /**
     * Gets the value of the isrStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the isrStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIsrStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IsrStatus }
     * 
     * 
     */
    public List<IsrStatus> getIsrStatus() {
        if (isrStatus == null) {
            isrStatus = new ArrayList<IsrStatus>();
        }
        return this.isrStatus;
    }

    /**
     * Gets the value of the pctPubInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pctPubInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPctPubInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PctPubInfo }
     * 
     * 
     */
    public List<PctPubInfo> getPctPubInfo() {
        if (pctPubInfo == null) {
            pctPubInfo = new ArrayList<PctPubInfo>();
        }
        return this.pctPubInfo;
    }

    /**
     * 取得 woPubnum 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link WoPubnum }
     *     
     */
    public WoPubnum getWoPubnum() {
        return woPubnum;
    }

    /**
     * 設定 woPubnum 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link WoPubnum }
     *     
     */
    public void setWoPubnum(WoPubnum value) {
        this.woPubnum = value;
    }

}
