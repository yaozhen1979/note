//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.17 於 05:44:44 PM CST 
//


package wipo.jaxb.ApplicationBody;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>msup complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType name="msup"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}mi"/&gt;
 *           &lt;element ref="{}mn"/&gt;
 *           &lt;element ref="{}mo"/&gt;
 *           &lt;element ref="{}mtext"/&gt;
 *           &lt;element ref="{}ms"/&gt;
 *           &lt;element ref="{}mspace"/&gt;
 *           &lt;element ref="{}mprescripts"/&gt;
 *           &lt;element ref="{}none"/&gt;
 *           &lt;element ref="{}mrow"/&gt;
 *           &lt;element ref="{}mfrac"/&gt;
 *           &lt;element ref="{}msqrt"/&gt;
 *           &lt;element ref="{}mroot"/&gt;
 *           &lt;element ref="{}menclose"/&gt;
 *           &lt;element ref="{}mstyle"/&gt;
 *           &lt;element ref="{}merror"/&gt;
 *           &lt;element ref="{}mpadded"/&gt;
 *           &lt;element ref="{}mphantom"/&gt;
 *           &lt;element ref="{}mfenced"/&gt;
 *           &lt;element ref="{}msub"/&gt;
 *           &lt;element ref="{}msup"/&gt;
 *           &lt;element ref="{}msubsup"/&gt;
 *           &lt;element ref="{}munder"/&gt;
 *           &lt;element ref="{}mover"/&gt;
 *           &lt;element ref="{}munderover"/&gt;
 *           &lt;element ref="{}mmultiscripts"/&gt;
 *           &lt;element ref="{}mtable"/&gt;
 *           &lt;element ref="{}mtr"/&gt;
 *           &lt;element ref="{}mlabeledtr"/&gt;
 *           &lt;element ref="{}mtd"/&gt;
 *           &lt;element ref="{}maligngroup"/&gt;
 *           &lt;element ref="{}malignmark"/&gt;
 *           &lt;element ref="{}maction"/&gt;
 *           &lt;element ref="{}ci"/&gt;
 *           &lt;element ref="{}csymbol"/&gt;
 *           &lt;element ref="{}cn"/&gt;
 *           &lt;element ref="{}integers"/&gt;
 *           &lt;element ref="{}reals"/&gt;
 *           &lt;element ref="{}rationals"/&gt;
 *           &lt;element ref="{}naturalnumbers"/&gt;
 *           &lt;element ref="{}complexes"/&gt;
 *           &lt;element ref="{}primes"/&gt;
 *           &lt;element ref="{}exponentiale"/&gt;
 *           &lt;element ref="{}imaginaryi"/&gt;
 *           &lt;element ref="{}notanumber"/&gt;
 *           &lt;element ref="{}true"/&gt;
 *           &lt;element ref="{}false"/&gt;
 *           &lt;element ref="{}emptyset"/&gt;
 *           &lt;element ref="{}pi"/&gt;
 *           &lt;element ref="{}eulergamma"/&gt;
 *           &lt;element ref="{}infinity"/&gt;
 *           &lt;element ref="{}apply"/&gt;
 *           &lt;element ref="{}fn"/&gt;
 *           &lt;element ref="{}lambda"/&gt;
 *           &lt;element ref="{}reln"/&gt;
 *           &lt;element ref="{}interval"/&gt;
 *           &lt;element ref="{}list"/&gt;
 *           &lt;element ref="{}matrix"/&gt;
 *           &lt;element ref="{}matrixrow"/&gt;
 *           &lt;element ref="{}set"/&gt;
 *           &lt;element ref="{}vector"/&gt;
 *           &lt;element ref="{}piecewise"/&gt;
 *           &lt;element ref="{}semantics"/&gt;
 *           &lt;element ref="{}declare"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute ref="{}xlinkherf"/&gt;
 *       &lt;attribute ref="{}xlinktype"/&gt;
 *       &lt;attribute name="class" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="style" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="xref" type="{http://www.w3.org/2001/XMLSchema}IDREF" /&gt;
 *       &lt;attribute name="other" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *       &lt;attribute name="superscriptshift" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "msup", propOrder = {
    "miOrMnOrMo"
})
public class Msup {

    @XmlElements({
        @XmlElement(name = "mi", type = Mi.class),
        @XmlElement(name = "mn", type = Mn.class),
        @XmlElement(name = "mo", type = Mo.class),
        @XmlElement(name = "mtext", type = Mtext.class),
        @XmlElement(name = "ms", type = Ms.class),
        @XmlElement(name = "mspace", type = Mspace.class),
        @XmlElement(name = "mprescripts", type = Mprescripts.class),
        @XmlElement(name = "none", type = None.class),
        @XmlElement(name = "mrow", type = Mrow.class),
        @XmlElement(name = "mfrac", type = Mfrac.class),
        @XmlElement(name = "msqrt", type = Msqrt.class),
        @XmlElement(name = "mroot", type = Mroot.class),
        @XmlElement(name = "menclose", type = Menclose.class),
        @XmlElement(name = "mstyle", type = Mstyle.class),
        @XmlElement(name = "merror", type = Merror.class),
        @XmlElement(name = "mpadded", type = Mpadded.class),
        @XmlElement(name = "mphantom", type = Mphantom.class),
        @XmlElement(name = "mfenced", type = Mfenced.class),
        @XmlElement(name = "msub", type = Msub.class),
        @XmlElement(name = "msup", type = Msup.class),
        @XmlElement(name = "msubsup", type = Msubsup.class),
        @XmlElement(name = "munder", type = Munder.class),
        @XmlElement(name = "mover", type = Mover.class),
        @XmlElement(name = "munderover", type = Munderover.class),
        @XmlElement(name = "mmultiscripts", type = Mmultiscripts.class),
        @XmlElement(name = "mtable", type = Mtable.class),
        @XmlElement(name = "mtr", type = Mtr.class),
        @XmlElement(name = "mlabeledtr", type = Mlabeledtr.class),
        @XmlElement(name = "mtd", type = Mtd.class),
        @XmlElement(name = "maligngroup", type = Maligngroup.class),
        @XmlElement(name = "malignmark", type = Malignmark.class),
        @XmlElement(name = "maction", type = Maction.class),
        @XmlElement(name = "ci", type = Ci.class),
        @XmlElement(name = "csymbol", type = Csymbol.class),
        @XmlElement(name = "cn", type = Cn.class),
        @XmlElement(name = "integers", type = Integers.class),
        @XmlElement(name = "reals", type = Reals.class),
        @XmlElement(name = "rationals", type = Rationals.class),
        @XmlElement(name = "naturalnumbers", type = Naturalnumbers.class),
        @XmlElement(name = "complexes", type = Complexes.class),
        @XmlElement(name = "primes", type = Primes.class),
        @XmlElement(name = "exponentiale", type = Exponentiale.class),
        @XmlElement(name = "imaginaryi", type = Imaginaryi.class),
        @XmlElement(name = "notanumber", type = Notanumber.class),
        @XmlElement(name = "true", type = True.class),
        @XmlElement(name = "false", type = False.class),
        @XmlElement(name = "emptyset", type = Emptyset.class),
        @XmlElement(name = "pi", type = Pi.class),
        @XmlElement(name = "eulergamma", type = Eulergamma.class),
        @XmlElement(name = "infinity", type = Infinity.class),
        @XmlElement(name = "apply", type = Apply.class),
        @XmlElement(name = "fn", type = Fn.class),
        @XmlElement(name = "lambda", type = Lambda.class),
        @XmlElement(name = "reln", type = Reln.class),
        @XmlElement(name = "interval", type = Interval.class),
        @XmlElement(name = "list", type = wipo.jaxb.ApplicationBody.List.class),
        @XmlElement(name = "matrix", type = Matrix.class),
        @XmlElement(name = "matrixrow", type = Matrixrow.class),
        @XmlElement(name = "set", type = Set.class),
        @XmlElement(name = "vector", type = Vector.class),
        @XmlElement(name = "piecewise", type = Piecewise.class),
        @XmlElement(name = "semantics", type = Semantics.class),
        @XmlElement(name = "declare", type = Declare.class)
    })
    protected java.util.List<Object> miOrMnOrMo;
    @XmlAttribute(name = "xlinkherf")
    protected String xlinkherf;
    @XmlAttribute(name = "xlinktype")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String xlinktype;
    @XmlAttribute(name = "class")
    @XmlSchemaType(name = "anySimpleType")
    protected String clazz;
    @XmlAttribute(name = "style")
    @XmlSchemaType(name = "anySimpleType")
    protected String style;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "xref")
    @XmlIDREF
    @XmlSchemaType(name = "IDREF")
    protected Object xref;
    @XmlAttribute(name = "other")
    @XmlSchemaType(name = "anySimpleType")
    protected String other;
    @XmlAttribute(name = "superscriptshift")
    @XmlSchemaType(name = "anySimpleType")
    protected String superscriptshift;

    /**
     * Gets the value of the miOrMnOrMo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the miOrMnOrMo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMiOrMnOrMo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Mi }
     * {@link Mn }
     * {@link Mo }
     * {@link Mtext }
     * {@link Ms }
     * {@link Mspace }
     * {@link Mprescripts }
     * {@link None }
     * {@link Mrow }
     * {@link Mfrac }
     * {@link Msqrt }
     * {@link Mroot }
     * {@link Menclose }
     * {@link Mstyle }
     * {@link Merror }
     * {@link Mpadded }
     * {@link Mphantom }
     * {@link Mfenced }
     * {@link Msub }
     * {@link Msup }
     * {@link Msubsup }
     * {@link Munder }
     * {@link Mover }
     * {@link Munderover }
     * {@link Mmultiscripts }
     * {@link Mtable }
     * {@link Mtr }
     * {@link Mlabeledtr }
     * {@link Mtd }
     * {@link Maligngroup }
     * {@link Malignmark }
     * {@link Maction }
     * {@link Ci }
     * {@link Csymbol }
     * {@link Cn }
     * {@link Integers }
     * {@link Reals }
     * {@link Rationals }
     * {@link Naturalnumbers }
     * {@link Complexes }
     * {@link Primes }
     * {@link Exponentiale }
     * {@link Imaginaryi }
     * {@link Notanumber }
     * {@link True }
     * {@link False }
     * {@link Emptyset }
     * {@link Pi }
     * {@link Eulergamma }
     * {@link Infinity }
     * {@link Apply }
     * {@link Fn }
     * {@link Lambda }
     * {@link Reln }
     * {@link Interval }
     * {@link wipo.jaxb.ApplicationBody.List }
     * {@link Matrix }
     * {@link Matrixrow }
     * {@link Set }
     * {@link Vector }
     * {@link Piecewise }
     * {@link Semantics }
     * {@link Declare }
     * 
     * 
     */
    public java.util.List<Object> getMiOrMnOrMo() {
        if (miOrMnOrMo == null) {
            miOrMnOrMo = new ArrayList<Object>();
        }
        return this.miOrMnOrMo;
    }

    /**
     * 取得 xlinkherf 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinkherf() {
        return xlinkherf;
    }

    /**
     * 設定 xlinkherf 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinkherf(String value) {
        this.xlinkherf = value;
    }

    /**
     * 取得 xlinktype 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXlinktype() {
        return xlinktype;
    }

    /**
     * 設定 xlinktype 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXlinktype(String value) {
        this.xlinktype = value;
    }

    /**
     * 取得 clazz 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * 設定 clazz 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * 取得 style 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * 設定 style 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 xref 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getXref() {
        return xref;
    }

    /**
     * 設定 xref 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setXref(Object value) {
        this.xref = value;
    }

    /**
     * 取得 other 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOther() {
        return other;
    }

    /**
     * 設定 other 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOther(String value) {
        this.other = value;
    }

    /**
     * 取得 superscriptshift 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuperscriptshift() {
        return superscriptshift;
    }

    /**
     * 設定 superscriptshift 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuperscriptshift(String value) {
        this.superscriptshift = value;
    }

}
