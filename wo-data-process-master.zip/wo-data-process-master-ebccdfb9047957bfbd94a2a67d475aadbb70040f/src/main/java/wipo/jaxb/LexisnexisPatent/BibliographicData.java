//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}publication-reference" minOccurs="0"/&gt;
 *         &lt;element ref="{}original-publication-kind" minOccurs="0"/&gt;
 *         &lt;element ref="{}application-reference" minOccurs="0"/&gt;
 *         &lt;element ref="{}application-series-code" minOccurs="0"/&gt;
 *         &lt;element ref="{}language-of-filing" minOccurs="0"/&gt;
 *         &lt;element ref="{}language-of-publication" minOccurs="0"/&gt;
 *         &lt;element ref="{}priority-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{}dates-of-public-availability" minOccurs="0"/&gt;
 *         &lt;element ref="{}dates-rights-effective" minOccurs="0"/&gt;
 *         &lt;element ref="{}annual-serial-number" minOccurs="0"/&gt;
 *         &lt;element ref="{}kind-of-official-gazette" minOccurs="0"/&gt;
 *         &lt;element ref="{}corrected-publication-date" minOccurs="0"/&gt;
 *         &lt;element ref="{}application-number-of-republication" minOccurs="0"/&gt;
 *         &lt;element ref="{}corrected-publication-category" minOccurs="0"/&gt;
 *         &lt;element ref="{}gist-of-correction" minOccurs="0"/&gt;
 *         &lt;element ref="{}article-of-correction" minOccurs="0"/&gt;
 *         &lt;element ref="{}correction-text" minOccurs="0"/&gt;
 *         &lt;element ref="{}translation-submission-date" minOccurs="0"/&gt;
 *         &lt;element ref="{}term-of-grant" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-ipc" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-ipcr" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-cpc" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-cpcno" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-locarno" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-national" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-ecla" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-f-term" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-ipc-original" minOccurs="0"/&gt;
 *         &lt;element ref="{}classifications-ipcr-original" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification-national-original" minOccurs="0"/&gt;
 *         &lt;element ref="{}field-of-search" minOccurs="0"/&gt;
 *         &lt;element ref="{}number-of-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{}exemplary-claim" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}independent-claim" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}figures" minOccurs="0"/&gt;
 *         &lt;element ref="{}invention-title" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}botanic" minOccurs="0"/&gt;
 *         &lt;element ref="{}official-remarks" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{}references-cited" minOccurs="0"/&gt;
 *         &lt;element ref="{}related-documents" minOccurs="0"/&gt;
 *         &lt;element ref="{}parties" minOccurs="0"/&gt;
 *         &lt;element ref="{}examiners" minOccurs="0"/&gt;
 *         &lt;element ref="{}designation-of-states" minOccurs="0"/&gt;
 *         &lt;element ref="{}date-pct-article-22-39-fulfilled" minOccurs="0"/&gt;
 *         &lt;element ref="{}pct-or-regional-filing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}pct-or-regional-publishing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}ep-publishing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{}previously-filed-application" minOccurs="0"/&gt;
 *         &lt;element ref="{}patent-family" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="lang" use="required" type="{}language-type" /&gt;
 *       &lt;attribute name="date-changed" type="{}date-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "publicationReference",
    "originalPublicationKind",
    "applicationReference",
    "applicationSeriesCode",
    "languageOfFiling",
    "languageOfPublication",
    "priorityClaims",
    "datesOfPublicAvailability",
    "datesRightsEffective",
    "annualSerialNumber",
    "kindOfOfficialGazette",
    "correctedPublicationDate",
    "applicationNumberOfRepublication",
    "correctedPublicationCategory",
    "gistOfCorrection",
    "articleOfCorrection",
    "correctionText",
    "translationSubmissionDate",
    "termOfGrant",
    "classificationIpc",
    "classificationsIpcr",
    "classificationsCpc",
    "classificationsCpcno",
    "classificationLocarno",
    "classificationNational",
    "classificationsEcla",
    "classificationsFTerm",
    "classificationIpcOriginal",
    "classificationsIpcrOriginal",
    "classificationNationalOriginal",
    "fieldOfSearch",
    "numberOfClaims",
    "exemplaryClaim",
    "independentClaim",
    "figures",
    "inventionTitle",
    "botanic",
    "officialRemarks",
    "referencesCited",
    "relatedDocuments",
    "parties",
    "examiners",
    "designationOfStates",
    "datePctArticle2239Fulfilled",
    "pctOrRegionalFilingData",
    "pctOrRegionalPublishingData",
    "epPublishingData",
    "previouslyFiledApplication",
    "patentFamily"
})
@XmlRootElement(name = "bibliographic-data")
public class BibliographicData {

    @XmlElement(name = "publication-reference")
    protected PublicationReference publicationReference;
    @XmlElement(name = "original-publication-kind")
    protected String originalPublicationKind;
    @XmlElement(name = "application-reference")
    protected ApplicationReference applicationReference;
    @XmlElement(name = "application-series-code")
    protected String applicationSeriesCode;
    @XmlElement(name = "language-of-filing")
    protected String languageOfFiling;
    @XmlElement(name = "language-of-publication")
    protected String languageOfPublication;
    @XmlElement(name = "priority-claims")
    protected PriorityClaims priorityClaims;
    @XmlElement(name = "dates-of-public-availability")
    protected DatesOfPublicAvailability datesOfPublicAvailability;
    @XmlElement(name = "dates-rights-effective")
    protected DatesRightsEffective datesRightsEffective;
    @XmlElement(name = "annual-serial-number")
    protected String annualSerialNumber;
    @XmlElement(name = "kind-of-official-gazette")
    protected KindOfOfficialGazette kindOfOfficialGazette;
    @XmlElement(name = "corrected-publication-date")
    protected CorrectedPublicationDate correctedPublicationDate;
    @XmlElement(name = "application-number-of-republication")
    protected String applicationNumberOfRepublication;
    @XmlElement(name = "corrected-publication-category")
    protected String correctedPublicationCategory;
    @XmlElement(name = "gist-of-correction")
    protected String gistOfCorrection;
    @XmlElement(name = "article-of-correction")
    protected ArticleOfCorrection articleOfCorrection;
    @XmlElement(name = "correction-text")
    protected CorrectionText correctionText;
    @XmlElement(name = "translation-submission-date")
    protected TranslationSubmissionDate translationSubmissionDate;
    @XmlElement(name = "term-of-grant")
    protected TermOfGrant termOfGrant;
    @XmlElement(name = "classification-ipc")
    protected ClassificationIpc classificationIpc;
    @XmlElement(name = "classifications-ipcr")
    protected ClassificationsIpcr classificationsIpcr;
    @XmlElement(name = "classifications-cpc")
    protected ClassificationsCpc classificationsCpc;
    @XmlElement(name = "classifications-cpcno")
    protected ClassificationsCpcno classificationsCpcno;
    @XmlElement(name = "classification-locarno")
    protected ClassificationLocarno classificationLocarno;
    @XmlElement(name = "classification-national")
    protected ClassificationNational classificationNational;
    @XmlElement(name = "classifications-ecla")
    protected ClassificationsEcla classificationsEcla;
    @XmlElement(name = "classifications-f-term")
    protected ClassificationsFTerm classificationsFTerm;
    @XmlElement(name = "classification-ipc-original")
    protected ClassificationIpcOriginal classificationIpcOriginal;
    @XmlElement(name = "classifications-ipcr-original")
    protected ClassificationsIpcrOriginal classificationsIpcrOriginal;
    @XmlElement(name = "classification-national-original")
    protected ClassificationNationalOriginal classificationNationalOriginal;
    @XmlElement(name = "field-of-search")
    protected FieldOfSearch fieldOfSearch;
    @XmlElement(name = "number-of-claims")
    protected NumberOfClaims numberOfClaims;
    @XmlElement(name = "exemplary-claim")
    protected List<String> exemplaryClaim;
    @XmlElement(name = "independent-claim")
    protected List<String> independentClaim;
    protected Figures figures;
    @XmlElement(name = "invention-title")
    protected List<InventionTitle> inventionTitle;
    protected Botanic botanic;
    @XmlElement(name = "official-remarks")
    protected List<OfficialRemarks> officialRemarks;
    @XmlElement(name = "references-cited")
    protected ReferencesCited referencesCited;
    @XmlElement(name = "related-documents")
    protected RelatedDocuments relatedDocuments;
    protected Parties parties;
    protected Examiners examiners;
    @XmlElement(name = "designation-of-states")
    protected DesignationOfStates designationOfStates;
    @XmlElement(name = "date-pct-article-22-39-fulfilled")
    protected DatePctArticle2239Fulfilled datePctArticle2239Fulfilled;
    @XmlElement(name = "pct-or-regional-filing-data")
    protected PctOrRegionalFilingData pctOrRegionalFilingData;
    @XmlElement(name = "pct-or-regional-publishing-data")
    protected PctOrRegionalPublishingData pctOrRegionalPublishingData;
    @XmlElement(name = "ep-publishing-data")
    protected EpPublishingData epPublishingData;
    @XmlElement(name = "previously-filed-application")
    protected PreviouslyFiledApplication previouslyFiledApplication;
    @XmlElement(name = "patent-family")
    protected PatentFamily patentFamily;
    @XmlAttribute(name = "lang", required = true)
    protected String lang;
    @XmlAttribute(name = "date-changed")
    protected String dateChanged;

    /**
     * 取得 publicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PublicationReference }
     *     
     */
    public PublicationReference getPublicationReference() {
        return publicationReference;
    }

    /**
     * 設定 publicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PublicationReference }
     *     
     */
    public void setPublicationReference(PublicationReference value) {
        this.publicationReference = value;
    }

    /**
     * 取得 originalPublicationKind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalPublicationKind() {
        return originalPublicationKind;
    }

    /**
     * 設定 originalPublicationKind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalPublicationKind(String value) {
        this.originalPublicationKind = value;
    }

    /**
     * 取得 applicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationReference }
     *     
     */
    public ApplicationReference getApplicationReference() {
        return applicationReference;
    }

    /**
     * 設定 applicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationReference }
     *     
     */
    public void setApplicationReference(ApplicationReference value) {
        this.applicationReference = value;
    }

    /**
     * 取得 applicationSeriesCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationSeriesCode() {
        return applicationSeriesCode;
    }

    /**
     * 設定 applicationSeriesCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationSeriesCode(String value) {
        this.applicationSeriesCode = value;
    }

    /**
     * 取得 languageOfFiling 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguageOfFiling() {
        return languageOfFiling;
    }

    /**
     * 設定 languageOfFiling 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguageOfFiling(String value) {
        this.languageOfFiling = value;
    }

    /**
     * 取得 languageOfPublication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguageOfPublication() {
        return languageOfPublication;
    }

    /**
     * 設定 languageOfPublication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguageOfPublication(String value) {
        this.languageOfPublication = value;
    }

    /**
     * 取得 priorityClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PriorityClaims }
     *     
     */
    public PriorityClaims getPriorityClaims() {
        return priorityClaims;
    }

    /**
     * 設定 priorityClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityClaims }
     *     
     */
    public void setPriorityClaims(PriorityClaims value) {
        this.priorityClaims = value;
    }

    /**
     * 取得 datesOfPublicAvailability 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public DatesOfPublicAvailability getDatesOfPublicAvailability() {
        return datesOfPublicAvailability;
    }

    /**
     * 設定 datesOfPublicAvailability 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public void setDatesOfPublicAvailability(DatesOfPublicAvailability value) {
        this.datesOfPublicAvailability = value;
    }

    /**
     * 取得 datesRightsEffective 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatesRightsEffective }
     *     
     */
    public DatesRightsEffective getDatesRightsEffective() {
        return datesRightsEffective;
    }

    /**
     * 設定 datesRightsEffective 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatesRightsEffective }
     *     
     */
    public void setDatesRightsEffective(DatesRightsEffective value) {
        this.datesRightsEffective = value;
    }

    /**
     * 取得 annualSerialNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnnualSerialNumber() {
        return annualSerialNumber;
    }

    /**
     * 設定 annualSerialNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnnualSerialNumber(String value) {
        this.annualSerialNumber = value;
    }

    /**
     * 取得 kindOfOfficialGazette 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link KindOfOfficialGazette }
     *     
     */
    public KindOfOfficialGazette getKindOfOfficialGazette() {
        return kindOfOfficialGazette;
    }

    /**
     * 設定 kindOfOfficialGazette 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link KindOfOfficialGazette }
     *     
     */
    public void setKindOfOfficialGazette(KindOfOfficialGazette value) {
        this.kindOfOfficialGazette = value;
    }

    /**
     * 取得 correctedPublicationDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CorrectedPublicationDate }
     *     
     */
    public CorrectedPublicationDate getCorrectedPublicationDate() {
        return correctedPublicationDate;
    }

    /**
     * 設定 correctedPublicationDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrectedPublicationDate }
     *     
     */
    public void setCorrectedPublicationDate(CorrectedPublicationDate value) {
        this.correctedPublicationDate = value;
    }

    /**
     * 取得 applicationNumberOfRepublication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationNumberOfRepublication() {
        return applicationNumberOfRepublication;
    }

    /**
     * 設定 applicationNumberOfRepublication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationNumberOfRepublication(String value) {
        this.applicationNumberOfRepublication = value;
    }

    /**
     * 取得 correctedPublicationCategory 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrectedPublicationCategory() {
        return correctedPublicationCategory;
    }

    /**
     * 設定 correctedPublicationCategory 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrectedPublicationCategory(String value) {
        this.correctedPublicationCategory = value;
    }

    /**
     * 取得 gistOfCorrection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGistOfCorrection() {
        return gistOfCorrection;
    }

    /**
     * 設定 gistOfCorrection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGistOfCorrection(String value) {
        this.gistOfCorrection = value;
    }

    /**
     * 取得 articleOfCorrection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ArticleOfCorrection }
     *     
     */
    public ArticleOfCorrection getArticleOfCorrection() {
        return articleOfCorrection;
    }

    /**
     * 設定 articleOfCorrection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ArticleOfCorrection }
     *     
     */
    public void setArticleOfCorrection(ArticleOfCorrection value) {
        this.articleOfCorrection = value;
    }

    /**
     * 取得 correctionText 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CorrectionText }
     *     
     */
    public CorrectionText getCorrectionText() {
        return correctionText;
    }

    /**
     * 設定 correctionText 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrectionText }
     *     
     */
    public void setCorrectionText(CorrectionText value) {
        this.correctionText = value;
    }

    /**
     * 取得 translationSubmissionDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TranslationSubmissionDate }
     *     
     */
    public TranslationSubmissionDate getTranslationSubmissionDate() {
        return translationSubmissionDate;
    }

    /**
     * 設定 translationSubmissionDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslationSubmissionDate }
     *     
     */
    public void setTranslationSubmissionDate(TranslationSubmissionDate value) {
        this.translationSubmissionDate = value;
    }

    /**
     * 取得 termOfGrant 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link TermOfGrant }
     *     
     */
    public TermOfGrant getTermOfGrant() {
        return termOfGrant;
    }

    /**
     * 設定 termOfGrant 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link TermOfGrant }
     *     
     */
    public void setTermOfGrant(TermOfGrant value) {
        this.termOfGrant = value;
    }

    /**
     * 取得 classificationIpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpc }
     *     
     */
    public ClassificationIpc getClassificationIpc() {
        return classificationIpc;
    }

    /**
     * 設定 classificationIpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpc }
     *     
     */
    public void setClassificationIpc(ClassificationIpc value) {
        this.classificationIpc = value;
    }

    /**
     * 取得 classificationsIpcr 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public ClassificationsIpcr getClassificationsIpcr() {
        return classificationsIpcr;
    }

    /**
     * 設定 classificationsIpcr 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsIpcr }
     *     
     */
    public void setClassificationsIpcr(ClassificationsIpcr value) {
        this.classificationsIpcr = value;
    }

    /**
     * 取得 classificationsCpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsCpc }
     *     
     */
    public ClassificationsCpc getClassificationsCpc() {
        return classificationsCpc;
    }

    /**
     * 設定 classificationsCpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsCpc }
     *     
     */
    public void setClassificationsCpc(ClassificationsCpc value) {
        this.classificationsCpc = value;
    }

    /**
     * 取得 classificationsCpcno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsCpcno }
     *     
     */
    public ClassificationsCpcno getClassificationsCpcno() {
        return classificationsCpcno;
    }

    /**
     * 設定 classificationsCpcno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsCpcno }
     *     
     */
    public void setClassificationsCpcno(ClassificationsCpcno value) {
        this.classificationsCpcno = value;
    }

    /**
     * 取得 classificationLocarno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationLocarno }
     *     
     */
    public ClassificationLocarno getClassificationLocarno() {
        return classificationLocarno;
    }

    /**
     * 設定 classificationLocarno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationLocarno }
     *     
     */
    public void setClassificationLocarno(ClassificationLocarno value) {
        this.classificationLocarno = value;
    }

    /**
     * 取得 classificationNational 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationNational }
     *     
     */
    public ClassificationNational getClassificationNational() {
        return classificationNational;
    }

    /**
     * 設定 classificationNational 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationNational }
     *     
     */
    public void setClassificationNational(ClassificationNational value) {
        this.classificationNational = value;
    }

    /**
     * 取得 classificationsEcla 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsEcla }
     *     
     */
    public ClassificationsEcla getClassificationsEcla() {
        return classificationsEcla;
    }

    /**
     * 設定 classificationsEcla 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsEcla }
     *     
     */
    public void setClassificationsEcla(ClassificationsEcla value) {
        this.classificationsEcla = value;
    }

    /**
     * 取得 classificationsFTerm 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsFTerm }
     *     
     */
    public ClassificationsFTerm getClassificationsFTerm() {
        return classificationsFTerm;
    }

    /**
     * 設定 classificationsFTerm 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsFTerm }
     *     
     */
    public void setClassificationsFTerm(ClassificationsFTerm value) {
        this.classificationsFTerm = value;
    }

    /**
     * 取得 classificationIpcOriginal 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpcOriginal }
     *     
     */
    public ClassificationIpcOriginal getClassificationIpcOriginal() {
        return classificationIpcOriginal;
    }

    /**
     * 設定 classificationIpcOriginal 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpcOriginal }
     *     
     */
    public void setClassificationIpcOriginal(ClassificationIpcOriginal value) {
        this.classificationIpcOriginal = value;
    }

    /**
     * 取得 classificationsIpcrOriginal 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationsIpcrOriginal }
     *     
     */
    public ClassificationsIpcrOriginal getClassificationsIpcrOriginal() {
        return classificationsIpcrOriginal;
    }

    /**
     * 設定 classificationsIpcrOriginal 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationsIpcrOriginal }
     *     
     */
    public void setClassificationsIpcrOriginal(ClassificationsIpcrOriginal value) {
        this.classificationsIpcrOriginal = value;
    }

    /**
     * 取得 classificationNationalOriginal 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationNationalOriginal }
     *     
     */
    public ClassificationNationalOriginal getClassificationNationalOriginal() {
        return classificationNationalOriginal;
    }

    /**
     * 設定 classificationNationalOriginal 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationNationalOriginal }
     *     
     */
    public void setClassificationNationalOriginal(ClassificationNationalOriginal value) {
        this.classificationNationalOriginal = value;
    }

    /**
     * 取得 fieldOfSearch 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FieldOfSearch }
     *     
     */
    public FieldOfSearch getFieldOfSearch() {
        return fieldOfSearch;
    }

    /**
     * 設定 fieldOfSearch 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldOfSearch }
     *     
     */
    public void setFieldOfSearch(FieldOfSearch value) {
        this.fieldOfSearch = value;
    }

    /**
     * 取得 numberOfClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NumberOfClaims }
     *     
     */
    public NumberOfClaims getNumberOfClaims() {
        return numberOfClaims;
    }

    /**
     * 設定 numberOfClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NumberOfClaims }
     *     
     */
    public void setNumberOfClaims(NumberOfClaims value) {
        this.numberOfClaims = value;
    }

    /**
     * Gets the value of the exemplaryClaim property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exemplaryClaim property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExemplaryClaim().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getExemplaryClaim() {
        if (exemplaryClaim == null) {
            exemplaryClaim = new ArrayList<String>();
        }
        return this.exemplaryClaim;
    }

    /**
     * Gets the value of the independentClaim property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the independentClaim property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIndependentClaim().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getIndependentClaim() {
        if (independentClaim == null) {
            independentClaim = new ArrayList<String>();
        }
        return this.independentClaim;
    }

    /**
     * 取得 figures 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Figures }
     *     
     */
    public Figures getFigures() {
        return figures;
    }

    /**
     * 設定 figures 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Figures }
     *     
     */
    public void setFigures(Figures value) {
        this.figures = value;
    }

    /**
     * Gets the value of the inventionTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the inventionTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInventionTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InventionTitle }
     * 
     * 
     */
    public List<InventionTitle> getInventionTitle() {
        if (inventionTitle == null) {
            inventionTitle = new ArrayList<InventionTitle>();
        }
        return this.inventionTitle;
    }

    /**
     * 取得 botanic 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Botanic }
     *     
     */
    public Botanic getBotanic() {
        return botanic;
    }

    /**
     * 設定 botanic 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Botanic }
     *     
     */
    public void setBotanic(Botanic value) {
        this.botanic = value;
    }

    /**
     * Gets the value of the officialRemarks property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the officialRemarks property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOfficialRemarks().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OfficialRemarks }
     * 
     * 
     */
    public List<OfficialRemarks> getOfficialRemarks() {
        if (officialRemarks == null) {
            officialRemarks = new ArrayList<OfficialRemarks>();
        }
        return this.officialRemarks;
    }

    /**
     * 取得 referencesCited 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ReferencesCited }
     *     
     */
    public ReferencesCited getReferencesCited() {
        return referencesCited;
    }

    /**
     * 設定 referencesCited 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ReferencesCited }
     *     
     */
    public void setReferencesCited(ReferencesCited value) {
        this.referencesCited = value;
    }

    /**
     * 取得 relatedDocuments 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link RelatedDocuments }
     *     
     */
    public RelatedDocuments getRelatedDocuments() {
        return relatedDocuments;
    }

    /**
     * 設定 relatedDocuments 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link RelatedDocuments }
     *     
     */
    public void setRelatedDocuments(RelatedDocuments value) {
        this.relatedDocuments = value;
    }

    /**
     * 取得 parties 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Parties }
     *     
     */
    public Parties getParties() {
        return parties;
    }

    /**
     * 設定 parties 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Parties }
     *     
     */
    public void setParties(Parties value) {
        this.parties = value;
    }

    /**
     * 取得 examiners 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Examiners }
     *     
     */
    public Examiners getExaminers() {
        return examiners;
    }

    /**
     * 設定 examiners 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Examiners }
     *     
     */
    public void setExaminers(Examiners value) {
        this.examiners = value;
    }

    /**
     * 取得 designationOfStates 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DesignationOfStates }
     *     
     */
    public DesignationOfStates getDesignationOfStates() {
        return designationOfStates;
    }

    /**
     * 設定 designationOfStates 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DesignationOfStates }
     *     
     */
    public void setDesignationOfStates(DesignationOfStates value) {
        this.designationOfStates = value;
    }

    /**
     * 取得 datePctArticle2239Fulfilled 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatePctArticle2239Fulfilled }
     *     
     */
    public DatePctArticle2239Fulfilled getDatePctArticle2239Fulfilled() {
        return datePctArticle2239Fulfilled;
    }

    /**
     * 設定 datePctArticle2239Fulfilled 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePctArticle2239Fulfilled }
     *     
     */
    public void setDatePctArticle2239Fulfilled(DatePctArticle2239Fulfilled value) {
        this.datePctArticle2239Fulfilled = value;
    }

    /**
     * 取得 pctOrRegionalFilingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public PctOrRegionalFilingData getPctOrRegionalFilingData() {
        return pctOrRegionalFilingData;
    }

    /**
     * 設定 pctOrRegionalFilingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public void setPctOrRegionalFilingData(PctOrRegionalFilingData value) {
        this.pctOrRegionalFilingData = value;
    }

    /**
     * 取得 pctOrRegionalPublishingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public PctOrRegionalPublishingData getPctOrRegionalPublishingData() {
        return pctOrRegionalPublishingData;
    }

    /**
     * 設定 pctOrRegionalPublishingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public void setPctOrRegionalPublishingData(PctOrRegionalPublishingData value) {
        this.pctOrRegionalPublishingData = value;
    }

    /**
     * 取得 epPublishingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EpPublishingData }
     *     
     */
    public EpPublishingData getEpPublishingData() {
        return epPublishingData;
    }

    /**
     * 設定 epPublishingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EpPublishingData }
     *     
     */
    public void setEpPublishingData(EpPublishingData value) {
        this.epPublishingData = value;
    }

    /**
     * 取得 previouslyFiledApplication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PreviouslyFiledApplication }
     *     
     */
    public PreviouslyFiledApplication getPreviouslyFiledApplication() {
        return previouslyFiledApplication;
    }

    /**
     * 設定 previouslyFiledApplication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PreviouslyFiledApplication }
     *     
     */
    public void setPreviouslyFiledApplication(PreviouslyFiledApplication value) {
        this.previouslyFiledApplication = value;
    }

    /**
     * 取得 patentFamily 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PatentFamily }
     *     
     */
    public PatentFamily getPatentFamily() {
        return patentFamily;
    }

    /**
     * 設定 patentFamily 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PatentFamily }
     *     
     */
    public void setPatentFamily(PatentFamily value) {
        this.patentFamily = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 dateChanged 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateChanged() {
        return dateChanged;
    }

    /**
     * 設定 dateChanged 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateChanged(String value) {
        this.dateChanged = value;
    }

}
