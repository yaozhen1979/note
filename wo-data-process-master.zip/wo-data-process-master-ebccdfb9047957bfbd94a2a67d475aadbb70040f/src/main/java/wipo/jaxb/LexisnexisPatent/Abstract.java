//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element ref="{}doc-page" maxOccurs="unbounded"/&gt;
 *         &lt;sequence&gt;
 *           &lt;element ref="{}abst-problem"/&gt;
 *           &lt;element ref="{}abst-solution"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;choice maxOccurs="unbounded"&gt;
 *           &lt;element ref="{}heading"/&gt;
 *           &lt;element ref="{}p"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/choice&gt;
 *       &lt;attGroup ref="{}equivalent-source"/&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{}language-type" /&gt;
 *       &lt;attribute name="format" type="{}format-type" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="date-changed" type="{}date-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "docPage",
    "abstProblem",
    "abstSolution",
    "headingOrP"
})
@XmlRootElement(name = "abstract")
public class Abstract {

    @XmlElement(name = "doc-page")
    protected List<DocPage> docPage;
    @XmlElement(name = "abst-problem")
    protected AbstProblem abstProblem;
    @XmlElement(name = "abst-solution")
    protected AbstSolution abstSolution;
    @XmlElements({
        @XmlElement(name = "heading", type = Heading.class),
        @XmlElement(name = "p", type = P.class)
    })
    protected List<Object> headingOrP;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    protected String lang;
    @XmlAttribute(name = "format")
    protected FormatType format;
    @XmlAttribute(name = "status")
    protected String status;
    @XmlAttribute(name = "date-changed")
    protected String dateChanged;
    @XmlAttribute(name = "generated")
    protected Boolean generated;
    @XmlAttribute(name = "country")
    protected String country;
    @XmlAttribute(name = "doc-number")
    protected String docNumber;
    @XmlAttribute(name = "kind")
    protected String kind;

    /**
     * Gets the value of the docPage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docPage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocPage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocPage }
     * 
     * 
     */
    public List<DocPage> getDocPage() {
        if (docPage == null) {
            docPage = new ArrayList<DocPage>();
        }
        return this.docPage;
    }

    /**
     * 取得 abstProblem 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbstProblem }
     *     
     */
    public AbstProblem getAbstProblem() {
        return abstProblem;
    }

    /**
     * 設定 abstProblem 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbstProblem }
     *     
     */
    public void setAbstProblem(AbstProblem value) {
        this.abstProblem = value;
    }

    /**
     * 取得 abstSolution 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AbstSolution }
     *     
     */
    public AbstSolution getAbstSolution() {
        return abstSolution;
    }

    /**
     * 設定 abstSolution 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AbstSolution }
     *     
     */
    public void setAbstSolution(AbstSolution value) {
        this.abstSolution = value;
    }

    /**
     * Gets the value of the headingOrP property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headingOrP property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeadingOrP().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Heading }
     * {@link P }
     * 
     * 
     */
    public List<Object> getHeadingOrP() {
        if (headingOrP == null) {
            headingOrP = new ArrayList<Object>();
        }
        return this.headingOrP;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 format 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FormatType }
     *     
     */
    public FormatType getFormat() {
        return format;
    }

    /**
     * 設定 format 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FormatType }
     *     
     */
    public void setFormat(FormatType value) {
        this.format = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * 取得 dateChanged 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateChanged() {
        return dateChanged;
    }

    /**
     * 設定 dateChanged 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateChanged(String value) {
        this.dateChanged = value;
    }

    /**
     * 取得 generated 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGenerated() {
        return generated;
    }

    /**
     * 設定 generated 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGenerated(Boolean value) {
        this.generated = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 docNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocNumber() {
        return docNumber;
    }

    /**
     * 設定 docNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocNumber(String value) {
        this.docNumber = value;
    }

    /**
     * 取得 kind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * 設定 kind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

}
