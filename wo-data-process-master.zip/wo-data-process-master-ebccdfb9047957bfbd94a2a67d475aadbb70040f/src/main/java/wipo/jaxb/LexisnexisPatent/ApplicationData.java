//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}application" minOccurs="0"/&gt;
 *         &lt;element ref="{}examiner" minOccurs="0"/&gt;
 *         &lt;element ref="{}group-art-unit" minOccurs="0"/&gt;
 *         &lt;element ref="{}confirmation-number" minOccurs="0"/&gt;
 *         &lt;element ref="{}attorney-docket-number" minOccurs="0"/&gt;
 *         &lt;element ref="{}classification" minOccurs="0"/&gt;
 *         &lt;element ref="{}first-named-inventor" minOccurs="0"/&gt;
 *         &lt;element ref="{}entity-status" minOccurs="0"/&gt;
 *         &lt;element ref="{}customer-number" minOccurs="0"/&gt;
 *         &lt;element ref="{}status" minOccurs="0"/&gt;
 *         &lt;element ref="{}data-location" minOccurs="0"/&gt;
 *         &lt;element ref="{}earliest-publication" minOccurs="0"/&gt;
 *         &lt;element ref="{}publication" minOccurs="0"/&gt;
 *         &lt;element ref="{}aia-first-inventor-to-file" minOccurs="0"/&gt;
 *         &lt;element ref="{}title-of-invention" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "application",
    "examiner",
    "groupArtUnit",
    "confirmationNumber",
    "attorneyDocketNumber",
    "classification",
    "firstNamedInventor",
    "entityStatus",
    "customerNumber",
    "status",
    "dataLocation",
    "earliestPublication",
    "publication",
    "aiaFirstInventorToFile",
    "titleOfInvention"
})
@XmlRootElement(name = "application-data")
public class ApplicationData {

    protected Application application;
    protected Examiner examiner;
    @XmlElement(name = "group-art-unit")
    protected String groupArtUnit;
    @XmlElement(name = "confirmation-number")
    protected String confirmationNumber;
    @XmlElement(name = "attorney-docket-number")
    protected String attorneyDocketNumber;
    protected Classification classification;
    @XmlElement(name = "first-named-inventor")
    protected FirstNamedInventor firstNamedInventor;
    @XmlElement(name = "entity-status")
    protected String entityStatus;
    @XmlElement(name = "customer-number")
    protected String customerNumber;
    protected Status status;
    @XmlElement(name = "data-location")
    protected DataLocation dataLocation;
    @XmlElement(name = "earliest-publication")
    protected EarliestPublication earliestPublication;
    protected Publication publication;
    @XmlElement(name = "aia-first-inventor-to-file")
    protected Boolean aiaFirstInventorToFile;
    @XmlElement(name = "title-of-invention")
    protected String titleOfInvention;

    /**
     * 取得 application 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Application }
     *     
     */
    public Application getApplication() {
        return application;
    }

    /**
     * 設定 application 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Application }
     *     
     */
    public void setApplication(Application value) {
        this.application = value;
    }

    /**
     * 取得 examiner 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Examiner }
     *     
     */
    public Examiner getExaminer() {
        return examiner;
    }

    /**
     * 設定 examiner 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Examiner }
     *     
     */
    public void setExaminer(Examiner value) {
        this.examiner = value;
    }

    /**
     * 取得 groupArtUnit 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupArtUnit() {
        return groupArtUnit;
    }

    /**
     * 設定 groupArtUnit 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupArtUnit(String value) {
        this.groupArtUnit = value;
    }

    /**
     * 取得 confirmationNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmationNumber() {
        return confirmationNumber;
    }

    /**
     * 設定 confirmationNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmationNumber(String value) {
        this.confirmationNumber = value;
    }

    /**
     * 取得 attorneyDocketNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttorneyDocketNumber() {
        return attorneyDocketNumber;
    }

    /**
     * 設定 attorneyDocketNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttorneyDocketNumber(String value) {
        this.attorneyDocketNumber = value;
    }

    /**
     * 取得 classification 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Classification }
     *     
     */
    public Classification getClassification() {
        return classification;
    }

    /**
     * 設定 classification 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Classification }
     *     
     */
    public void setClassification(Classification value) {
        this.classification = value;
    }

    /**
     * 取得 firstNamedInventor 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FirstNamedInventor }
     *     
     */
    public FirstNamedInventor getFirstNamedInventor() {
        return firstNamedInventor;
    }

    /**
     * 設定 firstNamedInventor 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FirstNamedInventor }
     *     
     */
    public void setFirstNamedInventor(FirstNamedInventor value) {
        this.firstNamedInventor = value;
    }

    /**
     * 取得 entityStatus 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntityStatus() {
        return entityStatus;
    }

    /**
     * 設定 entityStatus 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntityStatus(String value) {
        this.entityStatus = value;
    }

    /**
     * 取得 customerNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNumber() {
        return customerNumber;
    }

    /**
     * 設定 customerNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNumber(String value) {
        this.customerNumber = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Status }
     *     
     */
    public Status getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Status }
     *     
     */
    public void setStatus(Status value) {
        this.status = value;
    }

    /**
     * 取得 dataLocation 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DataLocation }
     *     
     */
    public DataLocation getDataLocation() {
        return dataLocation;
    }

    /**
     * 設定 dataLocation 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DataLocation }
     *     
     */
    public void setDataLocation(DataLocation value) {
        this.dataLocation = value;
    }

    /**
     * 取得 earliestPublication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EarliestPublication }
     *     
     */
    public EarliestPublication getEarliestPublication() {
        return earliestPublication;
    }

    /**
     * 設定 earliestPublication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EarliestPublication }
     *     
     */
    public void setEarliestPublication(EarliestPublication value) {
        this.earliestPublication = value;
    }

    /**
     * 取得 publication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Publication }
     *     
     */
    public Publication getPublication() {
        return publication;
    }

    /**
     * 設定 publication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Publication }
     *     
     */
    public void setPublication(Publication value) {
        this.publication = value;
    }

    /**
     * 取得 aiaFirstInventorToFile 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAiaFirstInventorToFile() {
        return aiaFirstInventorToFile;
    }

    /**
     * 設定 aiaFirstInventorToFile 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAiaFirstInventorToFile(Boolean value) {
        this.aiaFirstInventorToFile = value;
    }

    /**
     * 取得 titleOfInvention 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitleOfInvention() {
        return titleOfInvention;
    }

    /**
     * 設定 titleOfInvention 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitleOfInvention(String value) {
        this.titleOfInvention = value;
    }

}
