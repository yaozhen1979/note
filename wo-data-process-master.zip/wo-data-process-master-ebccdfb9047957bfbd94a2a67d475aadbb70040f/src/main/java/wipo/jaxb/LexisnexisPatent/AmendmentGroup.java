//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;all&gt;
 *         &lt;element ref="{}purpose-of-statement" minOccurs="0"/&gt;
 *         &lt;element ref="{}deleted-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{}number-of-amended-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{}document-code" minOccurs="0"/&gt;
 *         &lt;element ref="{}amendment-item" minOccurs="0"/&gt;
 *         &lt;element ref="{}amendment-way" minOccurs="0"/&gt;
 *         &lt;element ref="{}amendment-content" minOccurs="0"/&gt;
 *       &lt;/all&gt;
 *       &lt;attribute name="num" use="required" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" /&gt;
 *       &lt;attribute name="lang" type="{}language-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "amendment-group")
public class AmendmentGroup {

    @XmlElement(name = "purpose-of-statement")
    protected String purposeOfStatement;
    @XmlElement(name = "deleted-claims")
    protected String deletedClaims;
    @XmlElement(name = "number-of-amended-claims")
    protected NumberOfAmendedClaims numberOfAmendedClaims;
    @XmlElement(name = "document-code")
    protected String documentCode;
    @XmlElement(name = "amendment-item")
    protected String amendmentItem;
    @XmlElement(name = "amendment-way")
    protected String amendmentWay;
    @XmlElement(name = "amendment-content")
    protected AmendmentContent amendmentContent;
    @XmlAttribute(name = "num", required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger num;
    @XmlAttribute(name = "lang")
    protected String lang;

    /**
     * 取得 purposeOfStatement 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurposeOfStatement() {
        return purposeOfStatement;
    }

    /**
     * 設定 purposeOfStatement 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurposeOfStatement(String value) {
        this.purposeOfStatement = value;
    }

    /**
     * 取得 deletedClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeletedClaims() {
        return deletedClaims;
    }

    /**
     * 設定 deletedClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeletedClaims(String value) {
        this.deletedClaims = value;
    }

    /**
     * 取得 numberOfAmendedClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NumberOfAmendedClaims }
     *     
     */
    public NumberOfAmendedClaims getNumberOfAmendedClaims() {
        return numberOfAmendedClaims;
    }

    /**
     * 設定 numberOfAmendedClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NumberOfAmendedClaims }
     *     
     */
    public void setNumberOfAmendedClaims(NumberOfAmendedClaims value) {
        this.numberOfAmendedClaims = value;
    }

    /**
     * 取得 documentCode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentCode() {
        return documentCode;
    }

    /**
     * 設定 documentCode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentCode(String value) {
        this.documentCode = value;
    }

    /**
     * 取得 amendmentItem 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmendmentItem() {
        return amendmentItem;
    }

    /**
     * 設定 amendmentItem 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmendmentItem(String value) {
        this.amendmentItem = value;
    }

    /**
     * 取得 amendmentWay 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmendmentWay() {
        return amendmentWay;
    }

    /**
     * 設定 amendmentWay 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmendmentWay(String value) {
        this.amendmentWay = value;
    }

    /**
     * 取得 amendmentContent 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AmendmentContent }
     *     
     */
    public AmendmentContent getAmendmentContent() {
        return amendmentContent;
    }

    /**
     * 設定 amendmentContent 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AmendmentContent }
     *     
     */
    public void setAmendmentContent(AmendmentContent value) {
        this.amendmentContent = value;
    }

    /**
     * 取得 num 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNum() {
        return num;
    }

    /**
     * 設定 num 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNum(BigInteger value) {
        this.num = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

}
