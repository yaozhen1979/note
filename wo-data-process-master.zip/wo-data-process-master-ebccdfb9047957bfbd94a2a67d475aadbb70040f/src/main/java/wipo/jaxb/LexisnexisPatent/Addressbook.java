//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;sequence&gt;
 *           &lt;group ref="{}name-group"/&gt;
 *           &lt;element ref="{}address" minOccurs="0"/&gt;
 *           &lt;element ref="{}phone" minOccurs="0"/&gt;
 *           &lt;element ref="{}fax" minOccurs="0"/&gt;
 *           &lt;element ref="{}email" minOccurs="0"/&gt;
 *           &lt;element ref="{}url" minOccurs="0"/&gt;
 *           &lt;element ref="{}ead" minOccurs="0"/&gt;
 *           &lt;element ref="{}dtext" minOccurs="0"/&gt;
 *         &lt;/sequence&gt;
 *         &lt;element ref="{}text"/&gt;
 *       &lt;/choice&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *       &lt;attribute name="lang" type="{}language-type" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "content"
})
@XmlRootElement(name = "addressbook")
public class Addressbook {

    @XmlElementRefs({
        @XmlElementRef(name = "email", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "suffix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "registered-number", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "dtext", type = Dtext.class, required = false),
        @XmlElementRef(name = "synonym", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name-standardized", type = NameStandardized.class, required = false),
        @XmlElementRef(name = "address", type = Address.class, required = false),
        @XmlElementRef(name = "orgname-normalized", type = OrgnameNormalized.class, required = false),
        @XmlElementRef(name = "role", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ead", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "department", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "orgname-standardized", type = OrgnameStandardized.class, required = false),
        @XmlElementRef(name = "last-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "issuing-office", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "phone", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "text", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "prefix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "fax", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "first-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name-normalized", type = NameNormalized.class, required = false),
        @XmlElementRef(name = "iid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name", type = Name.class, required = false),
        @XmlElementRef(name = "orgname", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "middle-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "url", type = JAXBElement.class, required = false)
    })
    protected List<Object> content;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;
    @XmlAttribute(name = "lang")
    protected String lang;

    /**
     * 取得其餘的內容模型. 
     * 
     * <p>
     * 基於下列原因, 您取得此 "catch-all" 特性: 
     * 綱要的兩個不同部分均使用欄位名稱 "Orgname". 請參閱: 
     * file:/C:/Users/yeatschung/Documents/ggts-workspace/wo-data-processor/src/main/java/wipo/xsd/lexisnexis-patent-document_v1-13-modified.xsd 的第 7902 行
     * file:/C:/Users/yeatschung/Documents/ggts-workspace/wo-data-processor/src/main/java/wipo/xsd/lexisnexis-patent-document_v1-13-modified.xsd 的第 7892 行
     * <p>
     * 為去除此特性, 請將特性自訂項目套用至下列兩個宣告的
     * 其中之一, 以變更它們的名稱: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Dtext }
     * {@link NameStandardized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Address }
     * {@link OrgnameNormalized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link OrgnameStandardized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link NameNormalized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Name }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getContent() {
        if (content == null) {
            content = new ArrayList<Object>();
        }
        return this.content;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

}
