//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>applicant-type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * <p>
 * <pre>
 * &lt;simpleType name="applicant-type"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="applicant"/&gt;
 *     &lt;enumeration value="applicant-inventor"/&gt;
 *     &lt;enumeration value="assignee"/&gt;
 *     &lt;enumeration value="inventor"/&gt;
 *     &lt;enumeration value="legal-representative"/&gt;
 *     &lt;enumeration value="obligated-assignee"/&gt;
 *     &lt;enumeration value="party-of-interest"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "applicant-type")
@XmlEnum
public enum ApplicantType {

    @XmlEnumValue("applicant")
    APPLICANT("applicant"),
    @XmlEnumValue("applicant-inventor")
    APPLICANT_INVENTOR("applicant-inventor"),
    @XmlEnumValue("assignee")
    ASSIGNEE("assignee"),
    @XmlEnumValue("inventor")
    INVENTOR("inventor"),
    @XmlEnumValue("legal-representative")
    LEGAL_REPRESENTATIVE("legal-representative"),
    @XmlEnumValue("obligated-assignee")
    OBLIGATED_ASSIGNEE("obligated-assignee"),
    @XmlEnumValue("party-of-interest")
    PARTY_OF_INTEREST("party-of-interest");
    private final String value;

    ApplicantType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ApplicantType fromValue(String v) {
        for (ApplicantType c: ApplicantType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
