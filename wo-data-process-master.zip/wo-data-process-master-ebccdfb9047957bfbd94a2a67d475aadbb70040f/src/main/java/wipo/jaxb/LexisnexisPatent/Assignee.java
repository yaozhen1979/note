//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}name"/&gt;
 *         &lt;element ref="{}name-standardized" minOccurs="0"/&gt;
 *         &lt;element ref="{}name-normalized" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-1" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-2" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-3" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-4" minOccurs="0"/&gt;
 *         &lt;element ref="{}address-5" minOccurs="0"/&gt;
 *         &lt;element ref="{}postcode" minOccurs="0"/&gt;
 *         &lt;element ref="{}city" minOccurs="0"/&gt;
 *         &lt;element ref="{}state" minOccurs="0"/&gt;
 *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "name",
    "nameStandardized",
    "nameNormalized",
    "address1",
    "address2",
    "address3",
    "address4",
    "address5",
    "postcode",
    "city",
    "state",
    "country"
})
@XmlRootElement(name = "assignee")
public class Assignee {

    @XmlElement(required = true)
    protected Name name;
    @XmlElement(name = "name-standardized")
    protected NameStandardized nameStandardized;
    @XmlElement(name = "name-normalized")
    protected NameNormalized nameNormalized;
    @XmlElement(name = "address-1")
    protected String address1;
    @XmlElement(name = "address-2")
    protected String address2;
    @XmlElement(name = "address-3")
    protected String address3;
    @XmlElement(name = "address-4")
    protected String address4;
    @XmlElement(name = "address-5")
    protected String address5;
    protected String postcode;
    protected String city;
    protected String state;
    protected String country;

    /**
     * 取得 name 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Name }
     *     
     */
    public Name getName() {
        return name;
    }

    /**
     * 設定 name 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Name }
     *     
     */
    public void setName(Name value) {
        this.name = value;
    }

    /**
     * 取得 nameStandardized 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NameStandardized }
     *     
     */
    public NameStandardized getNameStandardized() {
        return nameStandardized;
    }

    /**
     * 設定 nameStandardized 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NameStandardized }
     *     
     */
    public void setNameStandardized(NameStandardized value) {
        this.nameStandardized = value;
    }

    /**
     * 取得 nameNormalized 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NameNormalized }
     *     
     */
    public NameNormalized getNameNormalized() {
        return nameNormalized;
    }

    /**
     * 設定 nameNormalized 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NameNormalized }
     *     
     */
    public void setNameNormalized(NameNormalized value) {
        this.nameNormalized = value;
    }

    /**
     * 取得 address1 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * 設定 address1 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * 取得 address2 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * 設定 address2 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * 取得 address3 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * 設定 address3 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress3(String value) {
        this.address3 = value;
    }

    /**
     * 取得 address4 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * 設定 address4 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress4(String value) {
        this.address4 = value;
    }

    /**
     * 取得 address5 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress5() {
        return address5;
    }

    /**
     * 設定 address5 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress5(String value) {
        this.address5 = value;
    }

    /**
     * 取得 postcode 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * 設定 postcode 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostcode(String value) {
        this.postcode = value;
    }

    /**
     * 取得 city 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * 設定 city 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * 取得 state 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * 設定 state 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

}
