//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2015.12.18 於 04:34:12 PM CST 
//


package wipo.jaxb.LexisnexisPatent;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;group ref="{}name-group"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "content"
})
@XmlRootElement(name = "assistant-examiner")
public class AssistantExaminer {

    @XmlElementRefs({
        @XmlElementRef(name = "suffix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "registered-number", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "synonym", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name-standardized", type = NameStandardized.class, required = false),
        @XmlElementRef(name = "orgname-normalized", type = OrgnameNormalized.class, required = false),
        @XmlElementRef(name = "role", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "department", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "orgname-standardized", type = OrgnameStandardized.class, required = false),
        @XmlElementRef(name = "last-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "issuing-office", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "prefix", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "first-name", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name-normalized", type = NameNormalized.class, required = false),
        @XmlElementRef(name = "iid", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name", type = Name.class, required = false),
        @XmlElementRef(name = "orgname", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "middle-name", type = JAXBElement.class, required = false)
    })
    protected List<Object> content;

    /**
     * 取得其餘的內容模型. 
     * 
     * <p>
     * 基於下列原因, 您取得此 "catch-all" 特性: 
     * 綱要的兩個不同部分均使用欄位名稱 "Orgname". 請參閱: 
     * file:/C:/Users/yeatschung/Documents/ggts-workspace/wo-data-processor/src/main/java/wipo/xsd/lexisnexis-patent-document_v1-13-modified.xsd 的第 7902 行
     * file:/C:/Users/yeatschung/Documents/ggts-workspace/wo-data-processor/src/main/java/wipo/xsd/lexisnexis-patent-document_v1-13-modified.xsd 的第 7892 行
     * <p>
     * 為去除此特性, 請將特性自訂項目套用至下列兩個宣告的
     * 其中之一, 以變更它們的名稱: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link NameStandardized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link OrgnameNormalized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link OrgnameStandardized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link NameNormalized }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Name }
     * 
     * 
     */
    public List<Object> getContent() {
        if (content == null) {
            content = new ArrayList<Object>();
        }
        return this.content;
    }

}
