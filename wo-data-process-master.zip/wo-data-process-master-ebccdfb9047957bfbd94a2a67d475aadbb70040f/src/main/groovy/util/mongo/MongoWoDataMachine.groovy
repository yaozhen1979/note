package util.mongo
/**
 * 連上 10.60.90.121 正式機
 * @author yeatschung
 *
 */
class MongoWoDataMachine extends MongoUtil{

    static final String ip = "10.60.90.121"
    static final Integer port = 27017
    
    MongoWoDataMachine(){
        super( this.getResourceAsStream( this.getSimpleName() + '.config'), ip, port)
    }
}
