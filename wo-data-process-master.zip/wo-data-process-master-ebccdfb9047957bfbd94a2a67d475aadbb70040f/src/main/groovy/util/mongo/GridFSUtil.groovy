package util.mongo

import org.bson.Document

import com.mongodb.gridfs.GridFSDBFile

class GridFSUtil {

    /**
     * convert content in GridFSDBFile to a document
     * @param file
     * @return
     */
    static Document toDoc(GridFSDBFile file){
        Document doc = new Document()
        file.keySet().each{key->
            doc.put(key, file.get(key))
        }
        return doc
    }
}
