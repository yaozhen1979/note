package util.mongo

import java.nio.charset.StandardCharsets

import org.apache.commons.io.IOUtils

import com.gmongo.GMongoClient
import com.mongodb.DB
import com.mongodb.MongoClient
import com.mongodb.MongoClientOptions
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.WriteConcern

public class MongoUtil {

    public static final int CONNECT_TIMEOUT = 60000   
    protected String account
    protected String password
    protected String ip
    protected int port
    
    MongoUtil(){        
    }
    
    MongoUtil(InputStream is, String ip, int port){
        Properties prop = new Properties()
        prop.load(is)
        init(prop.getProperty("Account"), prop.getProperty("Password"), ip, port)
    }
    
    MongoUtil(String account, String password, String ip, int port) {
        init(account, password, ip, port)
    }
    
    protected void init(String account, String password, String ip, int port){
        this.account = account;
        this.password = password;
        this.ip = ip;
        this.port = port
    }
    
    GMongoClient getClient() {
        return getGMongoClient()
    }
    
    GMongoClient getGMongoClient(){
        return new GMongoClient(new ServerAddress(ip, port), [getCredential()], getMongoOptions())
    }
    
    DB getDb(String dbName){
        return getClient().getDB(dbName)
    }
    
    private MongoClientOptions getMongoOptions(){
        return MongoClientOptions.builder().writeConcern(WriteConcern.JOURNALED).connectTimeout(CONNECT_TIMEOUT).build()
    }
    
    private MongoCredential getCredential(){
        return MongoCredential.createCredential(account, "admin", password as char[]);
    }
}
