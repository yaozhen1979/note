package util.mongo

import com.mongodb.DB

class MongoWoNewDataMachine extends MongoUtil {

    static final String ip = "10.60.90.101"
    static final Integer port = 27017
    
    MongoWoNewDataMachine(){
        super( this.getResourceAsStream( this.getSimpleName() + '.config'), ip, port)
    }
}
