package util.mongo


/**
 * 連上 155 測試機
 * @author yeatschung
 *
 */
public class MongoTestingMachine extends MongoUtil{

    static final String ip = "10.60.90.155"
    static final Integer port = 27017
    
    MongoTestingMachine(){
        super( this.getResourceAsStream( this.getSimpleName() + '.config'), ip, port)
    }
}
