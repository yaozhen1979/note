package util

import java.awt.image.RenderedImage
import java.text.SimpleDateFormat

import javax.imageio.ImageIO

import org.apache.commons.io.IOUtils

import com.sun.media.jai.codec.ByteArraySeekableStream
import com.sun.media.jai.codec.ImageCodec
import com.sun.media.jai.codec.ImageDecoder
import com.sun.media.jai.codec.SeekableStream
import com.sun.media.jai.codec.TIFFDecodeParam

class ImageUtility {

    /**
     * decode .g4 compression to .png file 
     * @param is : input .g4 compression
     * @param f : output file
     */
    public static void decodeG4ToPng(InputStream is, File f){
        SeekableStream s = new ByteArraySeekableStream(IOUtils.toByteArray(is))
        ImageDecoder dec = ImageCodec.createImageDecoder("tiff", s, new TIFFDecodeParam());
        RenderedImage op = dec.decodeAsRenderedImage();
        FileOutputStream fos = new FileOutputStream(f);
        ImageIO.write(op, 'png', fos)
        fos.close();
    }
    
    /**
     * build path for formal path
     * Ex: /wo1a1/2016/03/03/wo2016029234a1
     * @param map with keys: kindcode(String), doDate(Date), openNumber()
     * @return
     */
    public static String buildFormalPath(Map map){
        String kc = map['kindcode'].toString().toLowerCase()
        return '/' + 'wo1' + kc +
                '/' + new SimpleDateFormat("yyyy").format(map['doDate']) +
                '/' + new SimpleDateFormat("MM").format(map['doDate']) +
                '/' + new SimpleDateFormat("dd").format(map['doDate']) +
                '/' + 'wo' + map['openNumber'] + kc + '/'
    }
    
    
}
