package util

import org.apache.commons.cli.HelpFormatter
import org.apache.commons.cli.Option
import org.apache.commons.cli.Options
/**
 * 寫入常用的 option 和 格式驗證
 * @author yeatschung
 *
 */
class ArgsUtility {

    /**
     * Option.builder('sd').hasArg().longOpt('start date').desc('starting date for query range.  Example: 2000-01-01').build()
     * @return
     */
    static Option startDate(){
        return Option.builder('sd').hasArg().longOpt('start date').desc('starting date for query range.  Example: 2000-01-01').build()
    } 
    
    /**
     * Option.builder('ed').hasArg().longOpt('end date').desc('end date for query range.  Example: 2000-01-01').build()
     * @return
     */
    static Option endDate(){
        return Option.builder('ed').hasArg().longOpt('end date').desc('end date for query range.  Example: 2000-01-01').build()
    }
    
    /**
     * Option.builder('xml').required().hasArg().longOpt('xmltypAbb').desc('Xmltype abbreviation Example: WPA, WAB, OPA, LNP').build()
     * @return
     */
    static Option xmlTypeAbb(){
        return Option.builder('xml').hasArg().longOpt('xmltypAbb').desc('Xmltype abbreviation Example: WPA, WAB, OPA, LNP').build()
    }
    
    /**
     * Option.builder('p').required().hasArg().longOpt('provider').desc('provider for query.  Example: WIPO DVD, WIPO Disk, WIPO Ftp').build()
     * @return
     */
    static Option provider(){
        return Option.builder('p').hasArg().longOpt('provider').desc('provider for query.  Example: WIPO DVD, WIPO Disk, WIPO Ftp').build()
    }
    
    /**
     * Option.builder('rw').hasArg().longOpt('release week').desc('query by release week.  Example: 2015-51').build()
     * @return
     */
    static Option releaseWeek(){
        return Option.builder('rw').hasArg().longOpt('release week').desc('query by release week.  Example: 2015-51').build()
    }
    
    static void printHelp(Class<?> cla, Options options){
        String header = cla.simpleName + " usage\n"
        new HelpFormatter().printHelp( cla.simpleName, header, options, "\n", true)
    }
}
