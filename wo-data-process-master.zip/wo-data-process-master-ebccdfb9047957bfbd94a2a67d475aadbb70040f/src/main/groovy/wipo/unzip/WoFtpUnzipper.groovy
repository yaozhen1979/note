package wipo.unzip

import java.util.zip.ZipException;

import org.apache.commons.io.FileUtils
import org.apache.commons.lang3.StringUtils

/**
 * 20151120 
 * ftp 資料目前需解壓縮的檔案為 claim & description 的全文資料，分為兩種格式
 *  wo-published-application-body.xml: 資料夾
 *  
 * @author yeatschung
 *
 */
class WoFtpUnzipper extends Unzipper {

    private String year     // 資料年份
    private String week     // 周數
    private File source   // 資料夾路徑
    private File target   // 解壓縮路徑

    public WoFtpUnzipper(String source, String target) throws IOException {
        // TODO Auto-generated constructor stub
        this.source = new File(fixSeperator(source))
        this.target = new File(fixSeperator(target))

        if(!init()){
            log.warn("init unsuccess")
        }
        log.info("source: " + source + "\ttarget:" + target)
    }


    private boolean init(){
        List<File> zips = getZipFilelist(source)

        // year & week parseing
        CharSequence pattern = /([\d]{4})-([\d]{2})(-JP)?\.zip$/

        // 回傳比對結果
        for(def zip :zips){
            def isMatched = zip.toString()=~pattern
            if(isMatched){
                this.year = isMatched[0][1]
                this.week = isMatched[0][2]
                log.info("Processing year: "+ year+ "\tweek: "+ week)
                return true
            }
        }

        return false
    }

    void runUnzip(){

        log.debug("First layer unzipping")
        unzipRaw()
        log.debug("Second layer unzipping")
        unzipXml()
    }

    /**
     * 
     * @param source
     * @param target
     */
    private void unzipRaw(){    // extract .zip

        List<File> zips = getZipFilelist(source)

        // first layer unzip
        unzipList(zips,  target, /\.zip$/)
    }

    /**
     * unzip WO second layer folder structure
     * @param source
     * @param target
     */
    private void unzipXml(){
        List<File> zips = getZipFilelist(target)
        unzipList(zips,  null, /\.xml$/)

        // TODO 確認數量

        // zip woapp
        // remove zip file
        log.info("unzip finished, removing temp .zip")
        zips.each{ zip->
            FileUtils.deleteQuietly(zip)
        }
    }

    static main(args) {

        String src = "C:/Users/yeatschung/Documents/WIPO/201501/ftp/text/012015/testFolder"
        String tar = "./2015/FTP/week01"
        new WoFtpUnzipper(src, tar).runUnzip()
        println "done"
    }

}
