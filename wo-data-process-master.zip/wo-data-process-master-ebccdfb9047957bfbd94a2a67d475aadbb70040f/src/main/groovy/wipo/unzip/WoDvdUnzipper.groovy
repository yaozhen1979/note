package wipo.unzip

import org.apache.commons.io.FileUtils
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.filefilter.DirectoryFileFilter
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class WoDvdUnzipper extends Unzipper {

    private Logger log = LoggerFactory.getLogger(WoDvdUnzipper.class)
    private List<File> sources = []// 資料夾路徑
    private File target   // 解壓縮路徑

    /**
     * 所有需要解壓縮的 pattern, 目前只解 
     *      wo-published-application.xml
     *      wo-published-application-ocr.pdf
     */    
//    private final List<String> unzipPatterns = [/-gazette-section-ii.xml$/, /wo-published-application.xml$/, /wo-published-application-ocr.pdf$/];
    private final List<String> unzipPatterns = [ /wo-published-application.xml$/, /wo-published-application-ocr.pdf$/];

    public WoDvdUnzipper(String src, String tar, boolean batch=false) {
        this.target = new File(fixSeperator(tar))
        if(batch){
            if(!init(src)){
                log.debug("init unsuccess")
            }
            log.info("init success")
        }else{
            sources.push(new File(FilenameUtils.separatorsToUnix(src)))            
        }
    }

    /**
     * 修正路徑命名 week00_1, week00_2
     * @param src 
     * @return
     */
    private boolean init(String src){
        String path = fixSeperator(src.replace(/_[\d]+$/, ""))

        if(new File(src).isDirectory()){// week00 只有單一位置
            this.sources.push(new File(src))
        }else{
            for(i in 1..5){
                File cur = new File(src + "_$i")
                if(cur.isDirectory()){
                    this.sources.push(cur)
                }else{
                    break
                }
            }
        }
        // TODO 用 XXXXXX-gazette-section-ii.xml extract year, week

        return true
    }

    /**
     * 20151123 run dvd unzip 
     */
    void runUnzip(){
        // 複製資料夾結構
        target.mkdirs()
        
        long gazCopyStart = System.currentTimeMillis()
        
        // copy gazette 
//        String gazettePattern = /.*-gazette-section-ii.xml$/
//        def gazette = new FileNameByRegexFinder().getFileNames(sources[0].toString(), gazettePattern)
//        if (gazette.size() != 0){
//            File file = new File(gazette[0])
//            copyByStream(new FileInputStream(file), new FileOutputStream(new File(target.toString() + FILE_SEPARATOR + file.getName())))
//            long gazCopyEnd = System.currentTimeMillis()
//            log.debug("Copy gazette: " + (gazCopyEnd - gazCopyStart))
//        }

        // unzip other data
        sources.each{src->
            
            long DirCopyStart = System.currentTimeMillis()
            FileUtils.copyDirectory(src, target, DirectoryFileFilter.DIRECTORY)
            long DirCopyEnd = System.currentTimeMillis()
            log.debug("Copy Dir: src:$src\ttar:$target" + ( DirCopyEnd - DirCopyStart))
            
            
            extractDir(src)
            
        }
        
        
    }
    
    /**
     * extract target zipped file in the src
     * @param src: 
     */
    private void extractDir(File src){
        long ZipGatStart = System.currentTimeMillis()
        List<File> zips = getZipFilelist(src)
        long ZipGatEnd = System.currentTimeMillis()
        log.debug("get zip: " + (ZipGatEnd - ZipGatStart))
        
        
        long unzipStart = System.currentTimeMillis()
        zips.each{zip->
            String unzipDirectory = target.toString() + FILE_SEPARATOR + getRelativeDirectory(src, zip)
            for(String pat: unzipPatterns){
                unzip(zip, new File(unzipDirectory), pat)
            }
        }
        long unzipEnd = System.currentTimeMillis()
        log.debug("unzip: " + (unzipEnd - unzipStart))
    }
    
    
    private String getRelativeDirectory(File base, File zip){
        return fixSeperator(StringUtils.substringBeforeLast(base.toURI().relativize(zip.toURI()).getPath(), '.zip'))
    }


    static main(args) {
        
        String src = "C:/Users/yeatschung/Documents/WIPO/2015/DVD/week49"
//        String tar = "C:/Users/yeatschung/Documents/WIPO/201549/week49_error_unzip"
        String tar = "C:/Users/yeatschung/Documents/WIPO/2015/DVD/testTarget"
//        String src = "C:/Users/yeatschung/Documents/WIPO/201549/week49_corrected"
//        String tar = "C:/Users/yeatschung/Documents/WIPO/201549/week49_corrected_unzip"
        println 'start unziping'
        long start = System.currentTimeMillis()
        new WoDvdUnzipper(src, tar).runUnzip()
        println 'Unzip to file Cost: ' + (System.currentTimeMillis()-start).toString()
        
        println "done"
    }

}
