package wipo.unzip


import java.util.zip.ZipException
import java.util.zip.ZipFile

import org.apache.commons.io.FileUtils
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory


public class Unzipper {

    static Logger log = LoggerFactory.getLogger(Unzipper.class)
    protected static final String FILE_SEPARATOR = System.getProperty("file.separator")
    protected final int BUFF_SIZE = 4096;

    /** 
     * unzip 所有 zips 到相同 output directory
     */
    void unzipList(List<File> zips, File outputDir, filter=/.*/){
        println "start unzipList"
        zips.each{ zip->
            unzip(zip, outputDir, filter)
        }
    }

    /**
     * upzip 清單中解壓出特定檔案到 output directory
     * 20151120 改成一次吃一個 zip 檔
     *      zip 內部的結構會一併複製
     * 
     * @param zips : zip file list 或  單獨 zip 檔案字串 
     * @param outputDir: output directory, 未輸入則解壓縮至 zip 檔案目錄 
     * @param filter: regular expression to find the target files 
     */
    void unzip(File zip, File outputDir, filter=/.*/){
        if(!zip.path.endsWith('.zip')){
            // check input must be .zip
            log.info(zip + "\tfile format error: .zip only")
        }

        if(!outputDir){
            // 解壓縮至此: 未輸入 output Directory 使用 zips 路徑
            outputDir = new File(StringUtils.substringBeforeLast(zip.toString(), '.zip') )
        }


        try{
            def zipFile = new ZipFile(zip)

            zipFile.entries().each{ entry ->

                if(entry =~ filter){
                    // output path build
                    String out = outputDir.toString() + FILE_SEPARATOR + entry.toString()

                    if(out.endsWith(FILE_SEPARATOR)){
                        log.debug( entry.toString() + "return")
                        return
                    }

                    // make directory
                    makeParentDirectory(out)

                    // unzip to file
                    File outFile = new File(out)
                    unzeipFileByStream(zipFile.getInputStream(entry), new FileOutputStream(outFile))
                }
            }
            zipFile.close()
        }catch(Exception e){
            log.debug(e, e);
        }
    }

    /**
     *  unzip File from stream
     */
    protected void unzeipFileByStream(InputStream zipIs, OutputStream os) throws ZipException, FileNotFoundException,
    IOException {
        copyByStream(zipIs, os)
    }
    
    protected void copyByStream(InputStream is, OutputStream os)throws IOException, FileNotFoundException{
        
        int readLen = -1;
        byte[] buff = new byte[BUFF_SIZE];

        //Loop until End of File and write the contents to the output stream
        while ((readLen = is.read(buff)) != -1) {
            os.write(buff, 0, readLen);
        }
    }

    /**
     *  修正 file seperator 成系統預設
     *  * 目前更改位置四散 => 可能改成 run 時統一改
     */
    protected String fixSeperator(String str){
        String fixpattern = (FILE_SEPARATOR.equals("\\"))? "\\\\": FILE_SEPARATOR
        return  str.replaceAll("[\\\\/]", fixpattern)
    }

    /**
     * 建立檔案必須路徑的資料夾 
     * @param filepath
     */
    protected void makeParentDirectory(String filepath){
        new File(StringUtils.substringBeforeLast(fixSeperator(filepath), FILE_SEPARATOR)).mkdirs()
    }

    /**
     *  取出資料夾 zip 檔
     *  @param src
     */
    protected List<File> getZipFilelist(File src){
        String[] extension = ["zip"]
        return FileUtils.listFiles(src, extension, true)
    }
}
