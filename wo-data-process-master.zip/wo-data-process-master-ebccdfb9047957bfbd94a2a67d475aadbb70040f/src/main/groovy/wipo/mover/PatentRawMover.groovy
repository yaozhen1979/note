package wipo.mover

import java.text.SimpleDateFormat

import org.apache.commons.cli.CommandLine
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.Options
import org.apache.commons.io.IOUtils
import org.bson.Document
import org.bson.types.ObjectId
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.ArgsUtility
import util.mongo.MongoWoDataMachine
import util.mongo.MongoWoNewDataMachine
import wipo.importer.extractor.WoRawProcessor

import com.mongodb.BasicDBObject
import com.mongodb.DB
import com.mongodb.DBCollection
import com.mongodb.DBCursor
import com.mongodb.gridfs.GridFS
import com.mongodb.gridfs.GridFSDBFile
import com.mongodb.gridfs.GridFSInputFile

/**
 * mainly used for moving rawdata from 121 to 101 
 * @author yeatschung
 *
 */
class PatentRawMover {

    static Logger log = LoggerFactory.getLogger(PatentRawMover.class)
    DBCollection fromColl
    DBCollection errColl
    GridFS toGridFs
    Document query
    boolean debug

    PatentRawMover(String[] args){
        
        parseArgs(args)

        if(debug){
//            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//            Date strDate = formatter.parse("2015-12-01")
//            Date endDate = formatter.parse("2015-12-31")
//            String provider = 'WIPO '
//            query = new Document(["doDate":[$gt: strDate, $lt: endDate], "provider":provider])
            
//            fail: query = new Document([ "_id" : new ObjectId('51b747b3526bac826073a933')])
//            query = new Document([ "_id" : new ObjectId('51b422d2526b531475e24d5a')])

            query = new Document([ "_id": [$in: 
                    [
//                        new ObjectId('51b747b3526bac826073a933'),
//                        new ObjectId('51b422d2526b531475e24d5a'),
//                        new ObjectId('51b42f03526b531475e275ba'),
//                        new ObjectId('51b1d00c526b2f1f589c8eb9'),
//                        new ObjectId('51b18fb5526b2f1f589bbce5'),
//                        new ObjectId('51b18e73526b2f1f589bb861'),
//                        new ObjectId('51b18e27526b2f1f589bb756'),
//                        new ObjectId('51b181d7526b2f1f589b9133'),
//                        new ObjectId('51b16e97526b2f1f589b4fdd'),
//                        new ObjectId('51b16646526b2f1f589b316a'),
//                        new ObjectId('51b16014526b2f1f589b1b90'),
//                        new ObjectId('51b15fdc526b2f1f589b1ab4'),
//                        new ObjectId('51b15fdb526b2f1f589b1ab2'),
//                        new ObjectId('51b15fd4526b2f1f589b1a8b'),
//                        new ObjectId('51b07e2c526b07664f113eb9'),
//                        new ObjectId('51b07967526b07664f112d2d'),
//                        new ObjectId('51b07954526b07664f112ce0'),
//                        new ObjectId('51b07944526b07664f112ca3'),
//                        new ObjectId('51b0792f526b07664f112c53'),
//                        new ObjectId('51b0792d526b07664f112c4b'),
//                        new ObjectId('51b0792c526b07664f112c49'),
//                        new ObjectId('51b0791b526b07664f112c0c'),
//                        new ObjectId('51b07909526b07664f112bc5'),
//                        new ObjectId('51b07903526b07664f112ba9'),
//                        new ObjectId('51b078f8526b07664f112b7e'),
//                        new ObjectId('51b078f7526b07664f112b7c'),
//                        new ObjectId('51b078ee526b07664f112b59'),
//                        new ObjectId('51b078de526b07664f112b0c'),
//                        new ObjectId('51b0706b526b07664f110bbf'),
//                        new ObjectId('51b07037526b07664f110ae6'),
//                        new ObjectId('51b069ec526b07664f10f3bd'),
//                        new ObjectId('51b061b3526b07664f10d649'),
//                        new ObjectId('51b05c54526b07664f10c26f'),
//                        new ObjectId('51b04c4a526b07664f108a34'),
                        
                        // ipc modification
//                        new ObjectId('53ff6d4cd08ee6910a2d3f68'),

                        // kind code error                        
//                        new ObjectId('51b061f4526b07664f10d733'),
//                        new ObjectId('51b061b2526b07664f10d648'),
//                        new ObjectId('51b061b1526b07664f10d643'),

                        
                        // date error
                        new ObjectId('51bf40ba526b46fd7045c63a'),
                        new ObjectId('51b85cf0526bac82607717aa'),
                        new ObjectId('51b42b9e526b531475e26bcd'),
                        new ObjectId('51b85cef526bac82607717a9'),
                        new ObjectId('51b22fa7526b2f1f589dc73f'),
                        new ObjectId('51b056a8526b07664f10adba'),
                        new ObjectId('51b1b961526b2f1f589c435c'),
                        new ObjectId('51b1b80d526b2f1f589c3e9f'),
                        new ObjectId('51b3075f526b531475dec691'),
                        new ObjectId('51b2df8f526b2f1f589ff712'),
                        new ObjectId('51b85cef526bac82607717a8'),
                        new ObjectId('51b2d734526b2f1f589fda1c'),
                        new ObjectId('51b071cd526b07664f1110ca'),
                        
                    ]
                ]])
            
        }

        //////////////////////////
        // manually setting region
        String fromDBname = "PatentRawWIPO"
        String fromCollname = "PatentRawWIPO"
        fromColl = new MongoWoDataMachine().getDb(fromDBname)."$fromCollname"


        String toDBname = 'PatentRawWIPO'
        String toBucketname = 'PatentRawWIPOGridFS'
        DB to = new MongoWoNewDataMachine().getDb(toDBname)
        // use testing machine
//        DB to = new MongoTestingMachine(toDBname).getDb()
        
        String errDBname = toDBname
        String errCollname = "ErrorPatentWIPOGridFS"
        errColl = new MongoWoNewDataMachine().getDb(errDBname)."$errCollname"
//        errColl = new MongoTestingMachine(errDBname).getDb()."$errCollname"
        
        
        //////////////////////////

        toGridFs = new GridFS(to, toBucketname)
    }

    //    void moveData(Document query){
    void moveData(){
        log.info('Used query :' + query.toString())
        
        DBCursor results = fromColl.find(query)//.sort(["doDate":-1])
        int length = results.size()

        results.eachWithIndex{ it, index->
            if(index % 500 == 0){
                log.info("current status: " + index + "/" + length)
            }
            Document doc = new Document(['oldObjectId' : it['_id']])

            try{
                doc.putAll(WoRawProcessor.process(it['data']['xml'], it['path']))
                
                if(!!it['correction']){
                    doc.put('correction', it['correction'])
                }
                
                removeAll(toGridFs.find(new BasicDBObject('oldObjectId' , doc['oldObjectId'])))                
                GridFSInputFile input = toGridFs.createFile(IOUtils.toInputStream(it['data']['xml'], 'utf-8'), it['path'])
                doc.each{key, val->
                    input.put(key, val)
                }
                input.save()

            }catch(Exception e){
                log.info( 'id: ' + it['_id'].toString() + 'insert fail')
                doc.putAll(it)
                doc.remove('_id')
                doc['err'] = e.message
                errColl.insert(doc)
            }
        }
    }

    void removeAll(List<GridFSDBFile> list){
        list.each{ it.remove() }
    }

    void parseArgs(String[] args){
        if(!args){
            debug = true
            log.info("debug mode running")
            return
        }
        
        Options options = new Options()
        options.addOption(ArgsUtility.startDate())
        options.addOption(ArgsUtility.endDate())
        options.addOption(ArgsUtility.provider())

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try{
            CommandLine cli = new DefaultParser().parse( options, args)
            Date strDate = formatter.parse((cli.hasOption('sd'))? cli.getParsedOptionValue('sd') : "1950-01-01")
            Date endDate = formatter.parse((cli.hasOption('ed'))? cli.getParsedOptionValue('ed') : "2050-01-01")
            query = new Document(["doDate":[$gt: strDate, $lt: endDate]])
            
            if(cli.hasOption('p')){
                String provider = cli.getOptionValue('p')
                if(!(new HashSet(['WIPO DVD', 'WIPO Disk', 'WIPO Ftp']).contains(provider))){
                    throw new Exception('provider must in WIPO DVD, WIPO Disk, WIPO Ftp')
                }
                query.put('provider', provider)
            }
            
        }catch(Exception e){
            println e.message
            ArgsUtility.printHelp(this.class, options)
            System.exit(0)
        }
        return
    }

    static main(args) {
        new PatentRawMover(args).moveData()
        println "done"
    }
}
