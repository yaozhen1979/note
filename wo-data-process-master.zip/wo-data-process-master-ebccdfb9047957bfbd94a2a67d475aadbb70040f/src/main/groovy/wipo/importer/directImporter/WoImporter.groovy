package wipo.importer.directImporter

import org.apache.commons.io.FilenameUtils
import org.bson.Document

import com.mongodb.DBCollection
import com.mongodb.gridfs.GridFS
import com.mongodb.gridfs.GridFSInputFile

abstract class WoImporter {
    
    protected File sourceDir
//    protected String provider
    protected String toDbname
//    protected DB db
    protected String toBucketname
    protected DBCollection errColl
    protected GridFS toGridFs
    
    WoImporter(String dir){
//        System.setProperty("DEBUG.MONGO", "false")
        sourceDir = new File(FilenameUtils.separatorsToUnix(dir))
//        db = new MongoTestingMachine(dbname).getDb()
//        TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
    }
    
    protected void save(Document doc, InputStream input, String filename){
        try{
            GridFSInputFile gridFile = toGridFs.createFile(input, filename)
            doc.each{key, val->
                gridFile.put(key, val)
            }
            gridFile.save()
        }catch(Exception e){
            Document err = doc
            err.remove('_id')
            err['err'] = e.message
            err['stackTrace'] = e.stackTrace.toString()
            println 'Exception'
            errColl.insert(err)
        }
    }

    /**
     * find file in the sourceDir by regular expression 
     * @param regex
     * @return
     */
    protected List<String> getFile(String regex){
        return new FileNameByRegexFinder().getFileNames(sourceDir.toString(), regex)
    }

}
