package wipo.importer.directImporter

import org.bson.Document
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.mongo.MongoTestingMachine
import wipo.importer.extractor.WoRawProcessor

import com.mongodb.DB
import com.mongodb.gridfs.GridFS
import com.mongodb.gridfs.GridFSInputFile

class WoDvdImporter extends WoImporter{

    static Logger log = LoggerFactory.getLogger(WoDvdImporter.class)
//    private final gazRawColl = "GazetteRaw"

    
    WoDvdImporter(String dir){
        super(dir)
        super.toDbname = "PatentRawWIPO"
        super.toBucketname = "Week49Error"
        DB to = new MongoTestingMachine(toDbname).getDb()
        toGridFs = new GridFS(to, toBucketname)
    }


    public void run(){
        //Find gazettle & process
//        List<String> gazette = getFile(/.*-gazette-section-ii.xml$/)
//
//        // parse & insert Mongo
//        if(gazette){
//            db."$gazRawColl".insert( parseGazettle( new File(gazette[0])))
//            log.info('gazette inserted')
//        }else{
//            log.info('gazette-section-ii.xml not found.')
//        }


        //Find published application & process
        List<String> pubApps = getFile(/wo-published-application.xml$/)
        log.info('Number of wo-published-application.xml :' + pubApps.size())
        pubApps.eachWithIndex{pubApp, index->
            // parse & insert Mongo
            if(index % 500 == 0){
                log.info('Current status :' + "$index/" + pubApps.size())
            }
            
            try{
                Document doc = WoRawProcessor.process(new File(pubApp))
                
                GridFSInputFile input = toGridFs.createFile(new FileInputStream(new File(pubApp)), new File(pubApp).absolutePath)
                doc.each{key, val->
                    input.put(key, val)
                }
                input.save()
            }catch(Exception e){
                
            }
            
        }
        log.info('Finish: ' + pubApps.size() + '/' + pubApps.size())
    }

//    /**
//     * parse information in the File of gazettle 
//     * @param gazFile
//     * @return
//     * @throws IOException
//     */
//    private Document parseGazettle(File gaz) throws IOException{
//        String gazettePattern = /.*[\/\\]([\d]{2})([\d]{4})-gazette-section-ii.xml$/
//        List<String> gazetteKeys = ["doWeek", "doYear"]
//
//        Document doc = woRawBasic(gaz)
//
//        Matcher matcher = (gaz.toString() =~ gazettePattern)
//        if(matcher){
//            Map map = matcher2Map( matcher, gazetteKeys)
//            doc['releaseWeek'] = map["doYear"] + '-' + map["doWeek"]
//        }
//        return doc
//    }

    /**
     * parse information in the File of published Application 
     * @param pubAppFile
     * @return
     * @throws IOException
     */
//    private Document parsePublishedApplication(File pubApp) throws IOException{
//        Document doc = new Document()
//        // 從 xml 截取資訊
//        doc.putAll(woRawBasic(pubApp))
//        log.debug(pubApp.toString() + " finished")
//        return doc
//    }

    static main(args) {
        println 'error 49'
        String src = "C:/Users/yeatschung/Documents/WIPO/201549/week49_error_unzip"
        new WoDvdImporter(src).run()
        println "done"
    }

}
