package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import org.apache.commons.lang3.StringUtils
import org.bson.Document

class LexisnexisPatentDocumentMetaInfoExtractor extends MetaInfoExtractor {

    public LexisnexisPatentDocumentMetaInfoExtractor() {
    }

    public LexisnexisPatentDocumentMetaInfoExtractor(GPathResult root,
            String path) {
        super(root, path);
    }

    @Override
    public String getProvider() {
        return 'WIPO Disk';
    }

    /**
     * 2011065801
     * 8912944
     */
    @Override
    protected String getOpenNumber(String str) {
        int prefix = Integer.valueOf(str.substring(0, 4))
        if(prefix>1970 && prefix<=2020){
            return getYear(str.substring(0, 4)) + StringUtils.leftPad(str.substring(4), 6, '0')
        }else{
            return getYear(str.substring(0, 2)) + StringUtils.leftPad(str.substring(2), 6, '0')
        }
    }

    @Override
    protected String getXmlAbbriviation() {
        return 'LNP';
    }

    @Override
    public Document parsePath() {
        return new Document();
    }

    @Override
    public Document parseXml() {
        Document doc = new Document()
        doc['openNumber'] = getOpenNumber(root.'bibliographic-data'.'publication-reference'.'document-id'.'doc-number'.toString())
        doc['kindcode'] = root.'bibliographic-data'.'publication-reference'.'document-id'.'kind'.toString()
        doc['doDate'] = getWoDoDateByNode(root.'bibliographic-data')
        
//        doc['doDate'] = getDate(root.'@date-changed'.toString())
        return doc;
    }

}
