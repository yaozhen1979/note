package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import java.util.regex.Matcher

import org.bson.Document

import util.MapUtility

/**
 * @author yeatschung
 */
class OcrPublishedApplicationMetaInfoExtractor extends MetaInfoExtractor {

//    public OcrPublishedApplicationMetaInfoExtractor() {
//        super();
//    }

    public OcrPublishedApplicationMetaInfoExtractor(GPathResult root,
    String path) {
        super(root, path);
    }


    /**
     * 2015000001 -> WO2015000001
     */
    @Override
    protected String getOpenNumber(String str) {
        return "$str";
    }

    @Override
    protected String getXmlAbbriviation() {
        return 'OPA'
    }

    /**
     * extract releaseWeek
     */
    @Override
    public Document parsePath() {
        Document doc = new Document()

        String ocrPubAppPattern = /.*[\/\\]([\d]{4})-([\d]{2})[\/\\].*[\/\\]WO([\d]{4})([\d]{6})([\w]{2})([\w]{2})\.xml$/
        List<String> ocrPubAppKeys = ["doYear", "doWeek", "woYear", "woNumber", "repubtype", "kindcode"]
        Matcher matcher = (path =~ ocrPubAppPattern)
        if(matcher.matches()){
            Map<String, String> map = MapUtility.matcher2Map(matcher, ocrPubAppKeys)
            doc['releaseWeek'] = map["doYear"] + "-" + map["doWeek"]
            return doc
        }else{
            // 舊版路徑
            ocrPubAppPattern = /^([\d]{4}).*week([\d]{2}).*/
            matcher = (path =~ ocrPubAppPattern)
            if(matcher.matches()){
                doc['releaseWeek'] = path.replaceAll(ocrPubAppPattern){full, yr, week ->
                    return yr + '-' + week
                }
                return doc
            }
        }        
        return doc
    }

    /**
     * extract 
     */
    @Override
    public Document parseXml() {
        Document doc = new Document()
        doc['openNumber'] = getOpenNumber(root.'@doc-number'.toString())
        doc['kindcode'] = root.'@kind'.toString()
        doc['doDate'] = getDate(root.'@date-publ'.toString())
        return doc;
    }

    @Override
    public String getProvider() {
        return 'WIPO Ftp'
    }

    /**
     *  return relative path base on default path root
     *  default path root: 20XX-XX.zip
     */
    @Override
    public String formatPath() {
        return path.replaceAll(/[\s\S]*\/((\d{4})-(\d{2})\/[\s\S]*.xml)/){full, pat1, year, week->
            return  pat1
        }
    }

}
