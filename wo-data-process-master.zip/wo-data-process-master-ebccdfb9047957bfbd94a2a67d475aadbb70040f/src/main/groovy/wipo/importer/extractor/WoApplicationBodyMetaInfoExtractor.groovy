package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import java.util.regex.Matcher

import org.bson.Document

import util.MapUtility

/**
 * @author 20151212 yeatschung
 */
class WoApplicationBodyMetaInfoExtractor extends MetaInfoExtractor {

    public WoApplicationBodyMetaInfoExtractor() {
        super();
    }

    public WoApplicationBodyMetaInfoExtractor(GPathResult root, String path) {
        super(root, path);
    }

    @Override
    protected String getXmlAbbriviation(){
        return 'WAB'
    }

    /**
     * raw: 15/000099
     */
    @Override
    public String getOpenNumber(String str) {
        String pat = /([\d]{2})\/([\d]{6})/
        return str.replaceAll(pat){full, yr, num ->
            return getYear(yr) + num
        }
    }


    /**
     * extract kindcode
     */
    @Override
    public Document parsePath() {
        String appBodyPattern = /.*WO([\d]{4})([\d]{6})([\w]{2})([\w]{2})[\/\\]wo-published-application-body.xml$/
        List<String> appBodyKeys = ["woYear", "woNumber", "repubtype", "kindcode"]

        Document doc = new Document()
        Matcher matcher = (path =~ appBodyPattern)
        if(matcher.matches()){
            Map<String, String> map = MapUtility.matcher2Map(matcher, appBodyKeys)
            doc['kindcode'] = map["kindcode"]
        }
        return doc
    }

    /**
     * extract: openNumber, releaseWeek, doDate
     */
    @Override
    public Document parseXml() {
        Document doc = new Document()
        doc['openNumber'] = getOpenNumber(root.'publication-reference'.'document-id'.'doc-number'.toString())
        doc['doDate'] = getWoDoDateByNode(root)
        doc['releaseWeek'] = getReleaseWeekByNode(root)
        return doc
    }

    @Override
    public String getProvider() {
        return 'WIPO Ftp'
    }

    /**
     * return relative path base on default path root
     * default path root: 20XX-XX-JP.zip
     */
    @Override
    public String formatPath() {
        return path.replaceAll(/[\s\S]*\/((\d{4})-(\d{2})-JP\/[\s\S]*.xml)/){full, pat1, year, week->
            return  pat1
        }
    }
}
