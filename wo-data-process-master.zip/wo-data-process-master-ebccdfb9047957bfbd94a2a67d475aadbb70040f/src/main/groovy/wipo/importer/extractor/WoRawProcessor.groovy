package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import org.apache.commons.io.input.BOMInputStream
import org.bson.Document

import util.MapUtility
import wipo.importer.extractor.LexisnexisPatentDocumentMetaInfoExtractor
import wipo.importer.extractor.MetaInfoExtractor
import wipo.importer.extractor.OcrPublishedApplicationMetaInfoExtractor
import wipo.importer.extractor.WoApplicationBodyMetaInfoExtractor
import wipo.importer.extractor.WoPublishedApplication

/**
 * 使用 xml 路徑和內容 截取相關資訊
 *  可用介面: 
 *      File
 *      String, String path
 *      InputStream, String path
 * @author yeatschung
 *
 */
class WoRawProcessor {

    public static Document process(File file) throws Exception{
        FileInputStream fis = new FileInputStream(file)
        Document result = process(new FileInputStream(file), file.path)
        fis.close()
        return result
    }

    /**
     * @param xml : xml String 
     * @param path : file path
     * @return
     */
    public static Document process(String xml, String path='') throws Exception {
        return process(IOUtils.toInputStream(xml, 'utf-8'), path)
    }

    public static Document process(InputStream xml, String path='') throws Exception{
        path = FilenameUtils.separatorsToUnix(path)
        Document doc = new Document()
        doc['contentType'] = 'xml/xml'
        String xmlString = xmlPreprocess(xml)
        MetaInfoExtractor extractor = getExtractor(new XmlSlurper().parseText(xmlString), path)

        doc.putAll(extractor.parsePath())
        doc.putAll(extractor.parseXml())
        doc['path'] = extractor.formatPath()        
        doc['xmltype'] = extractor.getXmltype()
        doc['xmltypeAbb'] = extractor.getXmlAbbriviation()
        doc['provider'] = extractor.getProvider()
        doc['docId'] = extractor.getDocId(doc)
        doc['tag'] = 'WoRawProcessor.v0'
        return MapUtility.sortMap(doc)
    }

    private static String xmlPreprocess(InputStream xml){
        return IOUtils.toString( new BOMInputStream(xml), 'utf-8').replaceFirst("<!DOCTYPE .*?\\.dtd\">", "")
    }


    private static MetaInfoExtractor getExtractor(GPathResult root,  String path) throws Exception{

        switch (root.name()){
            case 'wo-application-body':
                return new WoApplicationBodyMetaInfoExtractor(root, path)

            case 'wo-ocr-published-application':
                return new OcrPublishedApplicationMetaInfoExtractor(root, path)

            case 'wo-published-application':
                return new WoPublishedApplication(root, path)

            case 'lexisnexis-patent-document':
                return new LexisnexisPatentDocumentMetaInfoExtractor(root, path)

            default:
                throw new Exception('unknown root:' + root.name())
        }
    }

//    static main(args) {
//
//        //                String filename = 'src/main/resource/data/Example/WO2015000099NWA1/wo-published-application-body.xml'
////                String filename = 'src/main/resource/data/Example/wo-published-application.xml'
//                
//        // ocr example
////                String filename = 'src/main/resource/data/Example/WO2015000001NWA1.xml'
//        // LN example
////        String filename = 'src/main/resource/data/Example/WO8707987A1.xml'
//        String filename = 'src/tester/resource/xml/LN_DateError_WO2004001356A2_2003-end-of-year.xml'
////        String filename = 'src/main/resource/data/wo-application-body/WO2015026215RXA9/wo-published-application-body.xml'
////        String filename = 'src/main/resource/data/LN/WO2011065801A2.xml'
//        Document doc =  WoRawProcessor.process(new File(filename));
//
//        println doc
//        println 'done'
//    }
}
