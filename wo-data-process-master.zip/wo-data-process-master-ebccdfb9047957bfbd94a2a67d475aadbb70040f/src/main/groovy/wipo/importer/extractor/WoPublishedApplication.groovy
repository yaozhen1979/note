package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import org.apache.commons.lang3.StringUtils
import org.bson.Document

class WoPublishedApplication extends MetaInfoExtractor {

    public WoPublishedApplication() {
    }

    public WoPublishedApplication(GPathResult root, String path) {
        super(root, path);
    }

    @Override
    public String getProvider() {
        return 'WIPO DVD';
    }

    /**
     * 2015/000001 -> 2015000001
     */
    @Override
    protected String getOpenNumber(String str) {
        String yr = getYear(StringUtils.substringBefore(str, '/'))
        String num = StringUtils.substringAfter(str, '/')
        return "$yr$num"
    }

    @Override
    protected String getXmlAbbriviation() {
        return 'WPA'
    }

    @Override
    public Document parsePath() {
        return new Document()
    }

    /**
     * extract: openNumber, kindcode, releaseWeek, doDate
     */
    @Override
    public Document parseXml() {
        Document doc = new Document()
        doc['openNumber'] = getOpenNumber(root.'wo-bibliographic-data'.'publication-reference'.'document-id'.'doc-number'.toString())
        doc['kindcode'] = root.'wo-bibliographic-data'.'publication-reference'.'document-id'.'kind'.toString()
        doc['doDate'] = getWoDoDateByNode(root.'wo-bibliographic-data')
        doc['releaseWeek'] = getReleaseWeekByNode(root.'wo-bibliographic-data')
        
        return doc
    }

    @Override
    public String formatPath() {
        CharSequence regx = /[\s\S]*\/((\d{4})\/week\d{2}[\s\S]*)/
        return path.replaceAll(regx){full, pat1, year->
            return  pat1
        }
    }
}
