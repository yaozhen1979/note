package wipo.importer.extractor

import groovy.util.slurpersupport.GPathResult

import java.text.SimpleDateFormat

import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang3.StringUtils
import org.bson.Document

/**
 * @author 20151213 yeatschung
 */
abstract class MetaInfoExtractor {
    protected String path       // extract 的檔案路徑加檔名
    protected GPathResult root  // 用 XmlSlurper 轉成的 xml object

//    MetaInfoExtractor(){}

    MetaInfoExtractor(GPathResult root, String path){
        this.root = root
        this.path = FilenameUtils.separatorsToUnix(path)
    }

    /**
     * docId : openNumnber + kindcode + doDate + xmltypeAbb
     * Ex:
     * patentNumber: WO123456A1 => removed 20151214
     * doDate: 20150130
     * xmltypeAbb: 
     * provider: WIPO Disk
     * 
     */
    public String getDocId(Document doc) throws Exception{
        List<String> usedKey = ['openNumber', 'kindcode', 'doDate', 'xmltypeAbb']
        Set keySet = doc.keySet()

        if(!keySet.containsAll(usedKey)){
            throw new Exception('Error01: Cant get docid from missing field. \nkeySet:' + keySet)
        }

        if(!checkKindcode(doc['kindcode'])){  
            throw new Exception('Error02: Error kindcode format. kindcode :' + doc['kindcode'])
        }
        
        if(!checkOpenNumber(doc['openNumber'])){
            throw new Exception('Error03: Error openNumber format. openNUmber :' + doc['openNumber'])
        }

        if(!(doc['doDate'] instanceof Date)){
            throw new Exception('Error04: ' + 'doDate is not a Date object')
        }

        Calendar cal = Calendar.getInstance()
        cal.add(Calendar.YEAR, 1)
        Date nextYear = cal.getTime()
        if(nextYear.before(doc['doDate'])){
            throw new Exception('Error05: ' + 'doDate is unacceptible')
        }

        int year = Integer.valueOf(new SimpleDateFormat("yyyy").format(doc['doDate']))
        if(Integer.valueOf(doc['openNumber'].toString().substring(0, 4)) > year+1){
            throw new Exception('Error06: ' + doc['openNumber'].toString() + doc['doDate'].toString() + "year of openNumber larger than doDate")
        }

        return doc['openNumber'] + doc['kindcode'] + '/' + new SimpleDateFormat("yyyyMMdd").format(doc['doDate']) + '/' + doc['xmltypeAbb']
    }


    protected boolean checkKindcode(String str){
        return str.matches(/[\w]{2}/)
    }

    protected boolean checkOpenNumber(String str){
        return str.matches(/(19|20)[\d]{2}[\d]{6}/)
    }


    //    abstract public Document getMetaInfo() throws Exception

    /**
     * publication date
     * format: yyyyMMdd, Ex: 20150108
     * @param date
     * @return
     */
    protected Date getDate(String date){
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd")
        format.setTimeZone(TimeZone.getTimeZone("GMT"))
        return format.parse(date)
    }
    
    /**
     * 從下咧三個位置找最新時間
     * .'wo-publication-info'.'wo-correction'.'document-id'.'date'
     * .'publication-reference'.'document-id'.'date'
     * 'application-reference'.'document-id'.'date'
     * @return
     */
    protected Date getWoDoDateByNode(GPathResult gpath){
        Date tmp
        Date latest = getDate(gpath.'publication-reference'.'document-id'.'date'.toString())
        if(!(gpath.'wo-publication-info'.'wo-correction'.isEmpty())){ // without correction
            tmp = getDate(gpath.'wo-publication-info'.'wo-correction'.'document-id'.'date'.toString().substring(0, 8))
            latest = (latest.after(tmp))? latest : tmp
        }
        if(!(gpath.'application-reference'.'document-id'.'date'.isEmpty())){
            tmp = getDate(gpath.'application-reference'.'document-id'.'date'.toString())
            latest = (latest.after(tmp))? latest : tmp
        }
        return latest
    }

    /**
     * .'wo-publication-info'.'wo-correction'.'wo-pubnum'
     * .'wo-publication-info'.'wo-pubnum'
     * @param gpath
     * @return
     */
    protected String getReleaseWeekByNode(GPathResult gpath){
        if(gpath.'wo-publication-info'.'wo-correction'.isEmpty()){ // without correction
            return getReleaseWeek(gpath.'wo-publication-info'.'wo-pubnum'.toString())
        }else{ // with correction
            return getReleaseWeek(gpath.'wo-publication-info'.'wo-correction'.'wo-pubnum'.toString().substring(0, 7))
        }
    }

    abstract public String getProvider()

    /**
     * format: WOYYYYXXXXXX EX: WO2015000001
     * @return 
     */
    abstract protected String getOpenNumber(String str)

    /**
     * 01/2015 => 2015-01
     * @param pubnum
     * @return
     */
    protected String getReleaseWeek(String pubnum){
        return StringUtils.substringAfter(pubnum, '/') + '-' + StringUtils.substringBefore(pubnum, '/')
    }

    abstract protected String getXmlAbbriviation()

    /**
     * root element name of the processing xml 
     * @return
     */
    public String getXmltype(){
        return root.name()
    }

    /**
     * Covert to 4 digit year
     * @param yr
     * @return
     */
    protected String getYear(String yr){
        if(yr.length()<4){
            return (yr.toInteger()<70)?  "20$yr" : "19$yr"
        }
        return yr
    }

    abstract public Document parsePath()

    abstract public Document parseXml()
    
    /**
     * 20160105 current version: for path XXXX/DVD/... or XXXX/Ftp/...
     * @param absPath
     * @return
     */
    public String formatPath(){
        return path.replaceAll(/[\s\S]*((19|20)[\d]{2}\/(DVD|Ftp)\/[\s\S]*)/){full, pat1, pat2, pat3->
            return  pat1
        }
    }
}
