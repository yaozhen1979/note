package wipo.importer

import java.awt.image.RenderedImage
import java.text.SimpleDateFormat

import javax.imageio.ImageIO

import org.apache.commons.cli.CommandLine
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.HelpFormatter
import org.apache.commons.cli.Option
import org.apache.commons.cli.Options
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.StringUtils
import org.bson.Document

import util.ImageUtility
import wipo.importer.extractor.WoRawProcessor

import com.sun.media.jai.codec.ByteArraySeekableStream
import com.sun.media.jai.codec.ImageCodec
import com.sun.media.jai.codec.ImageDecoder
import com.sun.media.jai.codec.SeekableStream
import com.sun.media.jai.codec.TIFFDecodeParam

/**
 * for import the first image aquired from wipo ftp 
 * @author yeatschung
 */
class WoFtpImageImporter extends UnzipImporter {
    
    private String target
    int Count
    
    /**
     *  Regular expression for finding target images
     *  firstImage: /[\s\S]*\_fp\.g4$/
     */
    private final static List<String> PATS = [/[\s\S]*\_fp\.g4$/]

    WoFtpImageImporter(String source, String target, int threadNumber){
        super(source, threadNumber)
        this.logFreq = 50
        this.target = StringUtils.removeEnd(FilenameUtils.separatorsToUnix(target), "/")        
        this.Count = 0

        new File(target).mkdirs()
    }

    @Override
    public void save(InputStream input, String filename) {
        String bibFilename = StringUtils.substringBeforeLast(filename, '/') + '/wo-published-application.xml'
        Document obj = WoRawProcessor.process( new File( bibFilename))
        
        // import file
        String formatPath = this.target + ImageUtility.buildFormalPath(obj);
        new File(StringUtils.substringBeforeLast(formatPath, '/')).mkdirs()
        ImageUtility.decodeG4ToPng(input, new File(formatPath + 'firstImage.png'))
    }

    public void importFiles(){
        super.importFiles(WoFtpImageImporter.PATS)
        
    }
    
    static CommandLine parseArgs(String[] args){
        Options options = new Options()
        options.addOption(Option.builder('src').required().hasArg().longOpt('source directory').desc('the source directory of the DVD files Ex: /mnt/patentsource/WIPO/pct/2015/week01').build())
        options.addOption('tar', 'target directory', true, 'the target directory for image importing Ex: /mnt/nhdell/patent_wo/data')
        options.addOption('n', 'thread number', true, 'the thread number (integer) used for the process. Default: Runtime.getRuntime().availableProcessors()')
        
        CommandLine cli
        try{
            cli = new DefaultParser().parse( options, args)
        }catch(Exception e){
            String header = "WoFtpImageImporter usage\n"
            new HelpFormatter().printHelp("WoFtpImageImporter", header, options, "\n", true)
            System.exit(0)
        }
        return cli
    }

    protected void printInfo(){
        log.info('image source: ' + root)
        log.info('image target: ' + target)
    }


    public static main(args) {

        String source
        String target
        int threadNumber
        
        if(args){
            CommandLine cli = parseArgs(args)
            source = cli.getParsedOptionValue('src')
            target = (cli.hasOption('tar'))? cli.getParsedOptionValue('tar'): '/mnt/nhdell/patent_wo/data'
            threadNumber = (cli.hasOption('n'))? Integer.valueOf(cli.getParsedOptionValue('n')): Runtime.getRuntime().availableProcessors()
        }else{ // debug mode
            source = 'C:/Users/yeatschung.SCIENBIZIP/Documents/WIPO/2015/Ftp-Biblio/042016/PCT_042016.tar/042016'
            target = 'C:/Users/yeatschung.SCIENBIZIP/Documents/WIPO/2015/Ftp-Biblio/042016/PCT_042016.tar/'
            threadNumber = Runtime.getRuntime().availableProcessors()
            println 'debug mode is running'
        }
        
        WoFtpImageImporter woFtp = new WoFtpImageImporter(source, target, threadNumber)
        woFtp.printInfo()
        woFtp.importFiles()
        println 'done'
    }
}
