package wipo.importer

import java.awt.image.RenderedImage
import java.text.SimpleDateFormat

import javax.imageio.ImageIO

import org.apache.commons.cli.CommandLine
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.HelpFormatter
import org.apache.commons.cli.Option
import org.apache.commons.cli.Options
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.StringUtils
import org.bson.Document

import util.mongo.MongoWoNewDataMachine

import com.mongodb.DBCollection
import com.mongodb.DBObject
import com.sun.media.jai.codec.ByteArraySeekableStream
import com.sun.media.jai.codec.ImageCodec
import com.sun.media.jai.codec.ImageDecoder
import com.sun.media.jai.codec.SeekableStream
import com.sun.media.jai.codec.TIFFDecodeParam

class WoDvdImageImport extends UnzipImporter {

    DBCollection metaInfoColl   // a collection with meta-data
    String target
    int Count
    
    /**
     *  Regular expression for finding target images
     *  fullImage: /[\s\S]*wo-published-application-ocr\.pdf$/
     *  firstImage: /[\s\S]*\_fp\.g4$/
     */
    private final static List<String> PATS = [/[\s\S]*wo-published-application-ocr\.pdf$/, /[\s\S]*\_fp\.g4$/] 

    WoDvdImageImport(String source, String target, int threadNumber){
        super(source, threadNumber)
        this.target = StringUtils.removeEnd(FilenameUtils.separatorsToUnix(target), "/")
        Count = 0

        String metaInfoDbname = "PatentRawWIPO"
        String metaInfoCollname = "PatentRawWIPOGridFS.files"

        new File(target).mkdirs()
        metaInfoColl = new MongoWoNewDataMachine().getDb(metaInfoDbname).getCollection(metaInfoCollname)
    }

    @Override
    public void save(InputStream input, String filename) {

        // find & check meta data from mongo
        DBObject obj = metaInfoColl.findOne(buildQuery(filename))
        if(!obj){
            log.error('file record not found in mongo: ' + filename);
            return
        }else if(!obj.keySet().containsAll(['kindcode', 'doDate', 'openNumber'])){
            log.error('file missing some metadata in mongo: ' + filename)
            log.error('check if the raw data had been imported to mongo' + MongoWoNewDataMachine.getIp() + ':' + MongoWoNewDataMachine.getPort())
            return
        }

        // import file
        String formatPath = buildFormalPath(obj)
        new File(StringUtils.substringBeforeLast(formatPath, '/')).mkdirs()
        if(filename.endsWith('.g4')){   // import first image
            importTiffImage(input, new File(formatPath + 'firstImage.png'))
        }else if(filename.endsWith('.pdf')){    // import full page image
            importPdf(input, new File(formatPath + 'fullPage.pdf'))
        }
    }

    /**
     * importPdf
     * @param is
     * @param f
     */
    protected void importPdf(InputStream is, File f){
        FileOutputStream fos = new FileOutputStream(f)
        copy(is, new FileOutputStream(f), BUFFER_SIZE)
        fos.close()
    }

    /**
     * decode the tiff to png  
     * @param is
     * @param f
     */
    protected void importTiffImage(InputStream is, File f){
        SeekableStream s = new ByteArraySeekableStream(IOUtils.toByteArray(is))
        ImageDecoder dec = ImageCodec.createImageDecoder("tiff", s, new TIFFDecodeParam());
        RenderedImage op = dec.decodeAsRenderedImage();
        FileOutputStream fos = new FileOutputStream(f);
        ImageIO.write(op, 'png', fos)
        fos.close();
    }

    /**
     * build query to find the document in mongo
     * @param str
     * @return
     */
    protected static Document buildQuery(String str){
        SimpleDateFormat format = new SimpleDateFormat("ddMMyyyy")
        format.setTimeZone(TimeZone.getTimeZone("GMT"))
        CharSequence regx = /[\s\S]*\/WO(\d{4})_(\d{6})_(\d{8})\/[\s\S]*$/
        Document query
        str.replaceAll(regx){full, openYear, openSeq, doDate->
            query = new Document(["doDate": format.parse(doDate), 'openNumber': openYear.toString()+openSeq.toString()])
        }
        return query
    }

    /**
     * build path for formal path
     * @param map
     * @return
     */
    protected String buildFormalPath(Map map){
        String kc = map['kindcode'].toString().toLowerCase()
        return target + '/' + 'wo1' + kc +
                '/' + new SimpleDateFormat("yyyy").format(map['doDate']) +
                '/' + new SimpleDateFormat("MM").format(map['doDate']) +
                '/' + new SimpleDateFormat("dd").format(map['doDate']) +
                '/' + 'wo' + map['openNumber'] + kc + '/'
    }

    static CommandLine parseArgs(String[] args){
        Options options = new Options()
        options.addOption(Option.builder('src').required().hasArg().longOpt('source directory').desc('the source directory of the DVD files Ex: /mnt/patentsource/WIPO/pct/2015/week01').build())
        options.addOption('tar', 'target directory', true, 'the target directory for image importing Ex: /mnt/nhdell/patent_wo/data')
        options.addOption('n', 'thread number', true, 'the thread number (integer) used for the process. Default: Runtime.getRuntime().availableProcessors()')
        
        CommandLine cli
        try{
            cli = new DefaultParser().parse( options, args)
        }catch(Exception e){
            String header = "WoDvdImageImport usage\n"
            new HelpFormatter().printHelp("WoDvdImageImport", header, options, "\n", true)
            System.exit(0)
        }
        return cli
    }

    protected void printInfo(){
        log.info('image source: ' + root)
        log.info('image target: ' + target)
    }


    public static main(args) {

        String source
        String target
        int threadNumber
        
        if(args){
            CommandLine cli = parseArgs(args)
            source = cli.getParsedOptionValue('src')
            target = (cli.hasOption('tar'))? cli.getParsedOptionValue('tar'): '/mnt/nhdell/patent_wo/data'
            threadNumber = (cli.hasOption('n'))? Integer.valueOf(cli.getParsedOptionValue('n')): Runtime.getRuntime().availableProcessors()
        }else{ // debug mode
            source = 'C:/Users/yeatschung/Documents/WIPO/2015/DVD/2015/week49_corrected02'
            target = 'C:/Users/yeatschung/Documents/WIPO/2015/DVD/2015/TestImageTarget'
            threadNumber = Runtime.getRuntime().availableProcessors()
            println 'debug mode is running'
        }
        
        WoDvdImageImport woDvd = new WoDvdImageImport(source, target, threadNumber)
        woDvd.printInfo()
        woDvd.logFreq = 500
        woDvd.importFiles(WoDvdImageImport.PATS)
        println 'done'
    }
}
