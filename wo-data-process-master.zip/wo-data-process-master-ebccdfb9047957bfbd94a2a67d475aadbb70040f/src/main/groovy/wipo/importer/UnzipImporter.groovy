package wipo.importer

import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

import org.apache.commons.io.FileUtils
import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * 遞迴的解壓縮，須實作 save 方法
 * 20160129 add concurrent method 
 * @author yeatschung
 *
 */
abstract class UnzipImporter {

    protected final static String ZIP_EXTENSION = '.zip';
    protected final static int BUFFER_SIZE = 4096;
    
    protected static Logger log = LoggerFactory.getLogger(UnzipImporter.class)
    protected ExecutorService threadPool
    protected AtomicInteger curCount = new AtomicInteger()
    protected int threadNumber
    protected int retainedFactor        // the factor of pending quene number over the threadNumber 
    protected int logFreq
    protected String root

    UnzipImporter(){
        this('')
    }

    UnzipImporter(String root){
        this(root, Runtime.getRuntime().availableProcessors())
    }

    UnzipImporter(String root, int threadNumber){
        this.root = normalizePath(root)
        this.threadNumber = threadNumber
        this.logFreq = 100
        this.retainedFactor = 4 
    }

    /**
     * core procedure to be impliment
     */
    abstract void save(InputStream input, String filename) throws Exception

    /**
     * Find files by regular expression and save the file
     * the save method should be impliment in each import situation
     * @param pats : regular expression list for finding import files 
     * @param unzip : recursively find the files match with the pats
     */
    public void importFiles(List<String> pats, boolean unzip = true) throws IOException{

        // initialization
        root = normalizePath(root)
        List<String> filenames = getInitList()
        curCount.set(0)

        int retainedSize = retainedFactor * threadNumber
//        threadPool = Executors.newFixedThreadPool(threadNumber)
        ArrayBlockingQueue queue = new ArrayBlockingQueue<Runnable>(retainedSize * 2)
        threadPool = new ThreadPoolExecutor(threadNumber, threadNumber, 0L, TimeUnit.MILLISECONDS, queue)
        
        log.info('Process with thread Number: ' + threadNumber)

        
        // core procedure
        filenames.each{filename ->

            // block - busy waiting
            while(queue.size()> retainedSize){
                Thread.sleep(1000)                
            }
            
            
            FileInputStream fis
            if(match(filename, pats) && !filename.endsWith(ZIP_EXTENSION) && new File(filename).isFile()){
                // save
                fis = new FileInputStream(new File(filename))                
                threadPool.execute(new Saver(fis, filename))

            }else if(unzip && filename.endsWith(ZIP_EXTENSION)){
                // unzip zip file
                fis = new FileInputStream(new File(filename))
                unzipImport(fis, getZipdirName(filename), pats)
            }
        }

        threadPool.shutdown()
        if(threadPool.awaitTermination(1, TimeUnit.DAYS)){
            //wait untail finished
            log.info('Total : ' + this.curCount.get() + ' files has been saved.')
            log.info('finished.')
        }
    }

    /**
     *      * recursively unzip file in memery
     * @param is
     * @param root : unzip file directory
     * @param pats : regular expression list for finding import files
     */
    protected void unzipImport(InputStream is, String root, List<String> pats) {
        try {
            ZipInputStream zipIS = new ZipInputStream(is);
            ZipEntry entry;

            while ((entry = zipIS.getNextEntry()) != null) {
                if (!entry.isDirectory()) {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

                    if (entry.getName().endsWith(ZIP_EXTENSION)) {
                        copy(zipIS, outputStream, BUFFER_SIZE)
                        unzipImport(new ByteArrayInputStream(outputStream.toByteArray()), root + getZipdirName(entry.getName()), pats)

                    }else if(match(root + entry.getName(), pats)){
                        copy(zipIS, outputStream, BUFFER_SIZE)
                        threadPool.execute(new Saver(new ByteArrayInputStream(outputStream.toByteArray()), root + entry.getName()))
                    }
                    outputStream.close()
                }
            }
            zipIS.close()
            
        } catch (Exception e) {
            log.error(e.message)
            log.error(e.stackTrace.toString())
        }
    }



    /**
     * Remove string ending '.zip' and add '/'
     */
    protected static String getZipdirName(String zip){
        FilenameUtils.separatorsToUnix(StringUtils.removeEnd(zip, ZIP_EXTENSION)) + '/'
    }

    /**
     * normalize path to absolute, canonical with linux seperator
     * @param path
     * @return
     */
    protected static String normalizePath(String path){
        return FilenameUtils.separatorsToUnix(FilenameUtils.normalizeNoEndSeparator(new File(path).getAbsolutePath()))
    }

    /**
     * save with multi-thread process
     * @author yeatschung
     */
    protected class Saver implements Runnable {
        private InputStream input
        private String filename

        Saver(InputStream input, String filename){
            this.input = input
            this.filename = filename
        }
        @Override
        public void run() {
            try{
                UnzipImporter.this.save(input, filename)
            }catch (Exception e){
                log.error('File: ' + filename + ' fail.\n' + e.message)
            }
            int tmpCount = UnzipImporter.this.curCount.incrementAndGet()
            if(tmpCount % logFreq == 0){
                log.info('Current Status: ' + tmpCount + ' files processed...' )
            }
            
            input.close()
        }
    }

    protected List<String> getInitList() throws IOException{
        // initialization
        File rootFile = new File(root)
        List<String> filenames
        if(!rootFile.canRead()){
            throw new IOException('file path: ' + root + 'does not exist. \n Please check if the root  has been set correctly')
        }else if(rootFile.isDirectory()){
            filenames = FileUtils.listFiles( rootFile, null, true).collect(){ FilenameUtils.separatorsToUnix( it.toString())}
        }else{
            filenames =  [root]
        }
        return filenames
    }


    /**
     * copy InputStream to OutputStream
     * @param input
     * @param output
     * @param bufferSize
     */
    protected void copy(InputStream input, OutputStream output, int bufferSize = BUFFER_SIZE){
        int tmpCount;
        byte[] data = new byte[bufferSize];

        BufferedOutputStream out = new BufferedOutputStream( output, bufferSize);
        while ((tmpCount = input.read(data, 0, bufferSize)) != -1) {
            out.write(data, 0, tmpCount);
        }
        out.flush();
        out.close();
    }

    /*
     * match with regular expression
     */
    public static boolean match(String str, List<String> pats){
        for(i in pats){
            if(str.matches(i))  return true
        }
        return false
    }
}
