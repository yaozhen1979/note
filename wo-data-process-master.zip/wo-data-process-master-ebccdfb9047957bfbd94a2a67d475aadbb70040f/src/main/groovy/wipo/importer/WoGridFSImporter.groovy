package wipo.importer

import org.apache.commons.cli.CommandLine
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.HelpFormatter
import org.apache.commons.cli.Option
import org.apache.commons.cli.Options
import org.apache.commons.io.IOUtils
import org.apache.commons.lang3.StringUtils
import org.bson.Document

import util.mongo.MongoTestingMachine
import util.mongo.MongoUtil
import util.mongo.MongoWoNewDataMachine
import wipo.importer.extractor.WoRawProcessor

import com.mongodb.BasicDBObject
import com.mongodb.DB
import com.mongodb.DBCollection
import com.mongodb.gridfs.GridFS
import com.mongodb.gridfs.GridFSInputFile

public class WoGridFSImporter extends UnzipImporter {

    protected DBCollection errColl
    protected GridFS toGridFs
    
    /**
     *  Regular expression for finding target images
     *  DVD-WPA: /[\s\S]*wo-published-application.xml$/
     *  FTP-OPA: /[\s\S]*WO[\d]{10}[\w]{4}\.xml$/
     *  FTP-WAB: /[\s\S]*wo-published-application-body.xml$/
     */
    private final static List<String> PATS = [/[\s\S]*wo-published-application.xml$/, /[\s\S]*WO[\d]{10}[\w]{4}\.xml$/, /[\s\S]*wo-published-application-body.xml$/]

    /**
     * Construct from Builder
     * @param source
     * @param toGridFs
     * @param errColl
     * @param threadNumber
     */
    private WoGridFSImporter(String source, GridFS toGridFs, DBCollection errColl, int threadNumber){
        super(source, threadNumber)
        this.errColl = errColl
        this.toGridFs = toGridFs
    }

    /**
     * Builder for the WoGridFSImporter
     * @author yeatschung
     */
    public static final class Builder{
        
        private String source
        private WoGridFSImporter woGridFSImporter
        private MongoUtil mongoUtil
        
        public String toDbname = "PatentRawWIPO"
        public String toBucketname = "PatentRawWIPOGridFS"
        public String errCollname = "ErrorGridFs"
        public int threadNumber = Runtime.getRuntime().availableProcessors()
        
        public static Builder builder(){
            return new Builder()
        }
        
        public Builder setSource(String source){
            this.source = source
            return this
        }
        
        public Builder useTestingMachine(){
            this.mongoUtil = new MongoTestingMachine()
            return this
        }
        public Builder useMongoWoNewDataMachine(){
            this.mongoUtil = new MongoWoNewDataMachine()
            return this
        }
        
        // Manually specified machine target.  Example Schema: 10.60.90.181:5432/account/password
        public Builder setMachine(String target){
            List<String> tar = StringUtils.splitByWholeSeparator(target, '/')
            this.mongoUtil = new MongoUtil(tar[1], tar[2], StringUtils.substringBefore(tar[0]), StringUtils.substringAfter(tar[0]))
            return this
        }

        public WoGridFSImporter build(){
            DB to = mongoUtil.getDb(toDbname)
            return new WoGridFSImporter(source, new GridFS(to, toBucketname), to.getCollection(errCollname), threadNumber)
        }
    }
    
    @Override
    public void save(InputStream input, String filename) {
        byte[] inputByte = IOUtils.toByteArray(input)
        
        try{
            Document doc = WoRawProcessor.process(new ByteArrayInputStream(inputByte), filename)
            toGridFs.find(new BasicDBObject('docId' , doc['docId'])).each{it.remove()}

            GridFSInputFile gridFile = toGridFs.createFile(new ByteArrayInputStream(inputByte), doc['path'])
            doc.each{key, val->
                gridFile.put(key, val)
            }
            
            gridFile.save()
        }catch(Exception e){
            Document err = new Document()            
            err['data'] = new String(inputByte, "UTF-8")
            err['path'] = filename
            err['err'] = e.message
            err['stackTrace'] = e.stackTrace.toString()
            println 'Exception'
            errColl.insert(err)
        }
        
    }
    
    public void importFiles(){
        importFiles(this.PATS)
    }
    
    static CommandLine parseArgs(String[] args){
        Options options = new Options()
        options.addOption(Option.builder('src').required().hasArg().longOpt('source directory').desc('the source directory of the DVD files Ex: /mnt/patentsource/WIPO/pct/2015/week01').build())
        options.addOption(Option.builder('test').longOpt('testing machine').desc('use testing machine ').build())
        options.addOption(Option.builder('tar').longOpt('specified target machine').desc('Example Schema: 10.60.90.181:5432/account/password').build())
        options.addOption(Option.builder('n').hasArg().longOpt('thread number').desc('the thread number (integer) used for the process. Default: Runtime.getRuntime().availableProcessors()').build())
        CommandLine cli
        try{
            cli = new DefaultParser().parse( options, args)
        }catch(Exception e){
            String header = "WoGridFSImporter usage\n"
            new HelpFormatter().printHelp("WoGridFSImporter", header, options, "\n", true)
            System.exit(0)
        }
        return cli
    }
    
    static main(args) { 

        WoGridFSImporter.Builder builder = WoGridFSImporter.Builder.builder()

        if(args){
            CommandLine cli = WoGridFSImporter.parseArgs(args)
            println cli.getParsedOptionValue('src')
            builder = builder.setSource( cli.getParsedOptionValue('src')).useMongoWoNewDataMachine()
            
            if(cli.hasOption('test')){
                builder = builder.useTestingMachine()
            }else if(cli.hasOption('tar')){
                builder = builder.setMachine(cli.getParsedOptionValue('tar'))
            }
            
        }else{  // debug
            String root = 'C:/Users/yeatschung/Documents/WIPO/2015/DVD-FTP'
            builder = builder.setSource(root).useTestingMachine()
        }

        println 'start import'
        builder.build().importFiles()
        
        println "done"
    }
    
}
