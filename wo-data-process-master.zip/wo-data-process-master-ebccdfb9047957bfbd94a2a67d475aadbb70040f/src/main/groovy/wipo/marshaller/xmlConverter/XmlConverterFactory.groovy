package wipo.marshaller.xmlConverter;

class XmlConverterFactory {
    public static final String XMLTYPE_WPA = 'WPA'
    public static final String XMLTYPE_OPA = 'OPA'
    public static final String XMLTYPE_WAB = 'WAB'
    public static final String XMLTYPE_LNP = 'LNP'
    
    private XmlConverter WPAConverter
    private XmlConverter OPAConverter
    private XmlConverter WABConverter
    private XmlConverter LNPConverter
    
    public XmlConverter getConverter(String xmltype){
        switch (xmltype){
            case XMLTYPE_WPA:
                if(!WPAConverter){
                    WPAConverter = new WoPublishedApplicationXmlConverter()
                }
                return WPAConverter
                
            case XMLTYPE_OPA:
                if(!OPAConverter){
                    OPAConverter = new WoOcrPublishedApplicationXmlConverter()
                }
                return OPAConverter
                
            case XMLTYPE_WAB:
                if(!WABConverter){
                    WABConverter = new WoApplicationBodyXmlConverter()
                }
                return WABConverter
                
            case XMLTYPE_LNP:
                if(!LNPConverter){
                    LNPConverter = new LexisnexisPatentXmlConverter() 
                }
                return LNPConverter
        }
    } 
    
    public static XmlConverter getInstance(String xmltype){
         switch (xmltype){
             case XMLTYPE_WPA:
                 return new WoPublishedApplicationXmlConverter()
                 
             case XMLTYPE_OPA:
                 return new WoOcrPublishedApplicationXmlConverter()
                 
             case XMLTYPE_WAB:
                 return new WoApplicationBodyXmlConverter()
                 
             case XMLTYPE_LNP:
                 return new LexisnexisPatentXmlConverter()
         }
    }
}
