package wipo.marshaller.xmlConverter;

import groovy.util.slurpersupport.GPathResult

import java.util.logging.Logger
import java.util.regex.Pattern

import javax.script.ScriptEngineManager
import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBElement
import javax.xml.bind.JAXBException
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.apache.commons.collections.MapUtils
import org.apache.commons.lang3.StringUtils
import org.bson.Document
import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType

import patentdata.utils.CDataProcess
import util.CDataPath
import util.MapUtility

public abstract class XmlConverter {

    private boolean inited;
    protected Unmarshaller unmarshaller;
    private Marshaller marshaller;
    protected Logger logger = Logger.getLogger("");

    protected String jaxbPath; // jaxb package 位置 Ex:
                               // "wipo.jaxb.publishedApp"
    protected String xsdFilename; // xsd 檔案路徑全名
    protected String moxyOxmFilename; 
    protected InputStream xsdFileStream; // xsd Stream
    protected InputStream importMoxyBinding;
    protected Class<?> rootClass; // 傳 root class
    public CDataProcess cDataProcess;
    protected ArrayList<CDataPath> cDataPaths = new ArrayList<CDataPath>();
    
    public XmlConverter() {
        super();
    }
    

    /**
     * 用 xml string 直接轉成 json string
     * 
     * @param xml
     * @return
     * @throws Exception
     */
    protected String xml2Json(String xml) throws Exception {
        return xml2Json(new ByteArrayInputStream(xml.getBytes("utf-8")));
    }

    /**
     * 
     * @throws Exception
     */
    protected void init() throws Exception {

        if (inited) {
            return;
        }
//        logger.info("xsd file: " + xsdFile + "\njaxb path: " + jaxbPath);
        // xsdFile
        JAXBContext jc = JAXBContext.newInstance(jaxbPath);
        unmarshaller = jc.createUnmarshaller();

        // validation xsd
        SchemaFactory sf = SchemaFactory
                .newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);

//        Schema schema = sf.newSchema(new StreamSource(new FileInputStream(
//                xsdFileStream)));
        Schema schema = sf.newSchema(new StreamSource( (InputStream) xsdFileStream));

        unmarshaller.setSchema(schema);

        Map<String, Object> props = new HashMap<>();

/////////////////////////////
        // // InputStream importMoxyBinding =
        // rootClass.getResourceAsStream("oxm.xml");
        if(importMoxyBinding != null){
            List<InputStream> moxyBindings = new ArrayList<>();
            moxyBindings.add(importMoxyBinding);
            props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings);
        }
////////////////////////////

        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false);
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON);

        // WoPublishedApplication 為 jaxb 中的 root element
        JAXBContext jc1 = JAXBContext.newInstance(jaxbPath,
                rootClass.getClassLoader(), props);

        marshaller = jc1.createMarshaller();
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE,
                "application/json");
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        inited = true;

    }

    protected abstract String xml2Json(InputStream xml) throws Exception;

    protected JAXBElement<?> unmarshal(InputStream xml) throws JAXBException {
        return (JAXBElement<?>) unmarshaller.unmarshal(xml);
    }

    protected String marshal(Object jaxbElement) throws JAXBException {
        StringWriter sw = new StringWriter();
        marshaller.marshal(jaxbElement, sw);
        return sw.toString();
    }


    public Document getRelatedFile(){
        Document doc = new Document("xsd", xsdFilename);
        if(moxyOxmFilename != null){
            doc.append("moxy", moxyOxmFilename);
        }
        return doc;
    }

    /**
     * to CData
     * @param doc
     * @param xmlContent
     * @return
     * @throws IOException
     * @throws Exception
     */
    public Document toMongoDoc2(Document doc, String xmlContent) throws IOException, Exception{
        GPathResult root = new XmlSlurper().parseText(cDataProcess.transfer(xmlContent))
        
        cDataPaths.each{ cDataPath ->
            for(int i=0; i<cDataPath.length; i++){
                
                // check target exist
                GPathResult curNode = root
                cDataPath.getTokens(i).eachWithIndex{token, index->
                    if(index>0){  // not root element
                        curNode = curNode[token]
                    }
                }
                if(curNode.isEmpty()) continue
                
                // element exist case: get the operating entry                
                Object obj = doc              
                cDataPath.getTokens(i).eachWithIndex{token, index-> // find the target element
                    if(index>0 && token != cDataPath.elementName){ // not root element & target (due to call by reference in modification step)
                        obj = MapUtils.getObject(obj, token)
                    }
                }

                // modify the target value
                String insertKey = getInsertKey()
                if(cDataPath.unboundeds[i]){ // array form
                    curNode.eachWithIndex{ content, index ->
                        obj[cDataPath.elementName][index] = MapUtility.subMap(obj[cDataPath.elementName][index], cDataPath.getRetainKeys())
                        obj[cDataPath.elementName][index][insertKey] = node2String(content)
                    }
                }else{ // object form
                    obj[cDataPath.elementName] = MapUtility.subMap(obj[cDataPath.elementName], cDataPath.getRetainKeys())
                    obj[cDataPath.elementName][insertKey] = node2String(curNode) 
                }
                
            }
        }
        
        return doc
    }
    
    /**
     * Convert GPathResult to String and remove first \n
     * @param node
     * @return
     */
    protected String node2String(GPathResult node){
        return StringUtils.stripStart(node.toString(), "\n")
    }
    
    protected String getInsertKey(){
        return 'CData'
    }
    
    /**
     * generate regular expression for extract specific tag
     * result: (.*)(<element.*</element>)(.*)
     * @param element
     * @return
     */
    protected Pattern generateXmltagRE(String element){
        return Pattern.compile("([\\s\\S]*)(<" + element + "[\\s\\S]*?>[\\s\\S]*?<\\/" + element + ">)([\\s\\S]*)")
    }
    
    
    /**
     * initialize CDataProcess instance
     */
    protected void initCDataProcess(){
        ArrayList<String> paths = new ArrayList<String>()
        cDataPaths.each{ cDataPath -> 
            paths.addAll(cDataPath.paths)
        }
        cDataProcess = new CDataProcess(true, paths.toArray(new String[paths.size()]))
    }

    /**
     * remove specified xml tag from str
     * @param str
     * @param tag
     * @return
     */
    protected String cutElement(String str, String tag){
        return str.replaceAll(generateXmltagRE(tag)){ full, pat1, pat2, pat3 -> 
            return pat1 + pat3
        }
    }

}