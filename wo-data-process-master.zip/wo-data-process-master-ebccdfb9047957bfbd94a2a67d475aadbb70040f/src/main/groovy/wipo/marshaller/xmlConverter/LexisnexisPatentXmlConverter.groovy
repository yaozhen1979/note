package wipo.marshaller.xmlConverter;

import javax.xml.bind.JAXBElement

import util.CDataPath
import wipo.jaxb.LexisnexisPatent.LexisnexisPatentDocumentType


public class LexisnexisPatentXmlConverter extends XmlConverter {

    private Set<String> descriptionAttributeSet
    private Set<String> claimsAttributeSet
    private Set<String> InventionTitleAttributeSet
    
    public LexisnexisPatentXmlConverter() {
        rootClass = LexisnexisPatentDocumentType.class;
        jaxbPath = "wipo.jaxb.LexisnexisPatent";
        xsdFilename = "lexisnexis-patent-document_v1-13-modified.xsd";
        moxyOxmFilename = "LexisnexisPatentOxm.xml";
        xsdFileStream = this.getClass().getResourceAsStream("xsd/" + xsdFilename);
        importMoxyBinding = this.getClass().getResourceAsStream("oxm/" + moxyOxmFilename);
        
        // for CData processing
        CDataPath abstractCDataPath = new CDataPath("abstract", new HashSet<String>(["id", "lang", "format", "claim-type", "status", "date-changed", "generated", "country", "doc-number", "kind"]), null)
        abstractCDataPath.addPath('/lexisnexis-patent-document/abstract', true)
        cDataPaths.add(abstractCDataPath)
        
        CDataPath inventionTitleCDataPath = new CDataPath("invention-title", new HashSet<String>(["id", "lang", "format", "date-changed", "generated", "country", "doc-number", "kind"]), null)
        inventionTitleCDataPath.addPath('/lexisnexis-patent-document/bibliographic-data/invention-title', true)
        cDataPaths.add(inventionTitleCDataPath)
        
        CDataPath descriptionCDataPath = new CDataPath("description", new HashSet<String>(["id", "lang", "format", "status", "date-changed", "generated", "country", "doc-number", "kind"]), new HashSet<String>(["invention-title"]))
        descriptionCDataPath.addPath('/lexisnexis-patent-document/description', true)
        cDataPaths.add(descriptionCDataPath)

        CDataPath claimsCDataPath = new CDataPath("claims", new HashSet<String>(["id", "lang", "format", "claim-type", "status", "date-changed", "generated", "country", "doc-number", "kind"]), new HashSet<String>(["claim-statement"]))
        claimsCDataPath.addPath('/lexisnexis-patent-document/claims', true)
        cDataPaths.add(claimsCDataPath)
                
        initCDataProcess()
    }

    @Override
    protected String xml2Json(InputStream xml) throws Exception {
        init();
        LexisnexisPatentDocumentType lexisnexisPatentDocumentType =  ((JAXBElement<LexisnexisPatentDocumentType>) super.unmarshaller.unmarshal(xml)).getValue()
        lexisnexisPatentDocumentType
        
        for(int i=0; i<lexisnexisPatentDocumentType.claims.size(); i++){
            lexisnexisPatentDocumentType.claims[i].claim = null
        }
        
        for(int i=0; i<lexisnexisPatentDocumentType.description.size(); i++){
            lexisnexisPatentDocumentType.description[i].summaryOrRelatedAppsOrGovtInterest = null
        }
        return marshal(lexisnexisPatentDocumentType);
    }


}
