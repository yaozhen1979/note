package wipo.marshaller.xmlConverter;

import javax.xml.bind.JAXBElement

import util.CDataPath
import wipo.jaxb.OcrPublishedApp.WoOcrPublishedApplication

/**
 * jaxbPath: jaxb生成的位置
 * xsdFile: .xsd 檔案位置
 * WoPublishedApplication: root
 * @author yeatschung
 *
 */
public class WoOcrPublishedApplicationXmlConverter extends XmlConverter {
    private Set<String> descriptionAttributeSet
    private Set<String> claimsAttributeSet
    private Set<String> amendedClaimsAttributeSet
    
    public WoOcrPublishedApplicationXmlConverter(){
        rootClass = WoOcrPublishedApplication.class;
        jaxbPath = "wipo.jaxb.OcrPublishedApp";
        xsdFilename = "wo-ocr-published-application-modified.xsd";
        xsdFileStream = this.getClass().getResourceAsStream("xsd/" + xsdFilename);
        
        // for CData processing
        CDataPath amendedClaimsCDataPath = new CDataPath("amended-claims", new HashSet<String>(["id", "lang"]), new HashSet<String>(["amended-claims-statement"]))
        amendedClaimsCDataPath.addPath('/wo-ocr-published-application/amended-claims', true)
        cDataPaths.add(amendedClaimsCDataPath)
        
        CDataPath claimsCDataPath = new CDataPath("claims", new HashSet<String>(["id", "lang"]), null)
        claimsCDataPath.addPath('/wo-ocr-published-application/claims', true)
        cDataPaths.add(claimsCDataPath)
        
        CDataPath descriptionCDataPath = new CDataPath("description", new HashSet<String>(["id", "lang", "status"]), null)
        descriptionCDataPath.addPath('/wo-ocr-published-application/description', false)
        cDataPaths.add(descriptionCDataPath)
        initCDataProcess()
    }
   
    @Override
    public String xml2Json(InputStream xml) throws Exception {
        init();
        @SuppressWarnings("unchecked")        
        WoOcrPublishedApplication doc = ((JAXBElement<WoOcrPublishedApplication>) unmarshal(xml)).getValue();
        return marshal(doc);
    }
    
//    public Document toMongoDoc(Document doc, String xmlContent) throws IOException, Exception {
//        GPathResult root = new XmlSlurper().parseText(cDataProcess.transfer(xmlContent));
//        toCData(doc, 'description', root.'description', descriptionAttributeSet)
//        toCData(doc, 'claims', root.'claims', claimsAttributeSet)
//        toCData(doc, 'amended-claims', root.'amended-claims', amendedClaimsAttributeSet)
//        
//        
////        List curlist = new ArrayList<Object>()
////        curlist.add(doc['description']) 
////        toCData2(curlist, root.'description', descriptionAttributeSet)
////        curlist.remove(0)
////        curlist.add(doc['claims'])
////        toCData2(curlist, root.'claims', claimsAttributeSet)
//        
////        toCData3(new HashMap(['key':doc['description']]), root.'description', descriptionAttributeSet)
////        toCData3(new HashMap(['key':doc['claims']]), root.'claims', claimsAttributeSet)
////        if(doc['description'] instanceof List){
////            doc['description'] = new Document(['CData':node2String(root.'description')])
////        }else if(doc['description'] instanceof Map){
////            retainKey(doc['description'], descriptionAttributeSet)
////            doc['description']['CData'] = node2String(root.'description')
////        }
////        
////        if(doc['claims'] instanceof List){
////            doc['claims'] = new Document(['CData':node2String(root.'claims')])
////        }else if(doc['claims'] instanceof Map){
////            retainKey(doc['claims'], claimsAttributeSet)
////            doc['claims']['CData'] = node2String(root.'claims')
////        }
//        return doc
//    }
    
}
