package wipo.marshaller.xmlConverter;

import javax.xml.bind.JAXBElement

import util.CDataPath
import wipo.jaxb.PublishedApp.WoPublishedApplication

public class WoPublishedApplicationXmlConverter extends XmlConverter {
    private Set<String> abstractAttributeSet
    private Set<String> inventionTitleAttributeSet

    public WoPublishedApplicationXmlConverter() {
        rootClass = WoPublishedApplication.class;
        jaxbPath = "wipo.jaxb.PublishedApp";
        xsdFilename = "wo-published-application-v1-7-modified-v02.xsd";
        moxyOxmFilename = "PublishedApplicationOxm.xml";
        xsdFileStream = this.getClass().getResourceAsStream("xsd/" + xsdFilename);
        importMoxyBinding = this.getClass().getResourceAsStream("oxm/" + moxyOxmFilename);
        
        // for CData processing
//        String[] path = ["/wo-published-application/abstract", "/wo-published-application/wo-bibliographic-data/invention-title"]
        
        CDataPath abstractCDataPath = new CDataPath("abstract", new HashSet<String>(["id", "lang", "status"]), null)
        
        abstractCDataPath.addPath("/wo-published-application/abstract", true)
        abstractCDataPath.addPath("/wo-published-application/wo-xml-application/abstract", false)
        abstractCDataPath.addPath("/wo-published-application/wo-amended-claims/amend-body/abstract", false)
        cDataPaths.add(abstractCDataPath)
        
        CDataPath inventionTitleCDataPath = new CDataPath("invention-title", new HashSet<String>([ "id", "lang"]), null)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-bibliographic-data/invention-title", true)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-amended-claims/insert-after-object/invention-title", false)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-amended-claims/replace-object/invention-title", false)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-amended-claims/insert-before-object/invention-title", false)
        inventionTitleCDataPath.addPath("/wo-published-application/description/invention-title", false)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-xml-application/description/invention-title", false)
        inventionTitleCDataPath.addPath("/wo-published-application/wo-amended-claims/amend-body/description/invention-title", false)
        cDataPaths.add(inventionTitleCDataPath)
        initCDataProcess()
//        cDataProcess = new CDataProcess(true, "/wo-published-application/abstract",
////            "/wo-published-application/wo-xml-application/abstract",
////            "/wo-published-application/wo-amended-claims/amend-body/abstract",
////            "/wo-published-application/wo-bibliographic-data/invention-title/invention-title",
//            
////            "/wo-published-application/wo-amended-claims/insert-after-object", 
//            "/wo-published-application/wo-bibliographic-data/invention-title");
//        abstractAttributeSet = new HashSet<String>(["id", "lang", "status"])
//        inventionTitleAttributeSet = new HashSet<String>([ "id", "lang", "b", "i", "u", "o", "sup", "sub"])
    }

    @Override
    public String xml2Json(InputStream xml) throws Exception {
        init();

        @SuppressWarnings("unchecked")
                WoPublishedApplication doc = ((JAXBElement<WoPublishedApplication>) unmarshal(xml))
                .getValue();
        return marshal(doc);
    }

//    @Override
//    public Document toMongoDoc(Document doc, String xmlContent) throws IOException, Exception {
//        GPathResult root = new XmlSlurper().parseText(cDataProcess.transfer(xmlContent));
//        
//        root.'abstract'.eachWithIndex{ content, index ->
//            toCData(doc['abstract'], index, content, abstractAttributeSet)
//        }
//        root.'wo-bibliographic-data'.'invention-title'.eachWithIndex{ content, index ->
//            toCData(doc['wo-bibliographic-data']['invention-title'], index, content, inventionTitleAttributeSet)
//        }
//        return doc;
//    }
}
