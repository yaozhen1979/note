package wipo.marshaller.xmlConverter;

import javax.xml.bind.JAXBElement

import org.apache.commons.io.IOUtils
import org.bson.Document

import util.CDataPath
import wipo.jaxb.ApplicationBody.WoApplicationBody

/**
 * jaxbPath: jaxb生成的位置
 * xsdFile: .xsd 檔案位置
 * WoPublishedApplication: root
 * @author yeatschung
 *
 */
public class WoApplicationBodyXmlConverter extends XmlConverter {
    
    private Set<String> descriptionAttributeSet
    private Set<String> claimsAttributeSet
        
    public WoApplicationBodyXmlConverter(){
        super();
        jaxbPath = "wipo.jaxb.ApplicationBody";
        xsdFilename = "wo-application-body-v1-7-modified.xsd";
        xsdFileStream = this.getClass().getResourceAsStream("xsd/" + xsdFilename);
        rootClass = WoApplicationBody.class;
        
        // for CData processing
        CDataPath claimsCDataPath = new CDataPath("claims", new HashSet<String>(["id", "lang", "claim-type", "status"]), new HashSet<String>(["doc-page"]))
        claimsCDataPath.addPath('/wo-application-body/claims', false)
        claimsCDataPath.addPath('/wo-application-body/wo-amended-claims/amend-body/claims', false)
        cDataPaths.add(claimsCDataPath)
        
        CDataPath descriptionCDataPath = new CDataPath("description", new HashSet<String>(["id", "lang", "status"]), new HashSet<String>(['doc-page', 'invention-title']))
        descriptionCDataPath.addPath('/wo-application-body/description', false)
        descriptionCDataPath.addPath('/wo-application-body/wo-amended-claims/amend-body/description', false)
        cDataPaths.add(descriptionCDataPath)
        initCDataProcess()
    }
    
    @Override
    protected String xml2Json(InputStream xml) throws Exception {
        init();
        WoApplicationBody woApplicationBody = ((JAXBElement<WoApplicationBody>) super.unmarshaller.unmarshal(ipFilter(xml))).getValue()
        
        if(woApplicationBody != null && woApplicationBody.description != null){
            woApplicationBody.description.technicalFieldOrBackgroundArtOrDisclosure = null
        }
        
        if(woApplicationBody != null && woApplicationBody.claims != null){
            woApplicationBody.claims.claim = null
        }
        
        if (woApplicationBody != null && woApplicationBody.woAmendedClaims != null && woApplicationBody.woAmendedClaims.amendBody != null){
//            woApplicationBody.woAmendedClaims.amendBody.claims = null
            woApplicationBody.woAmendedClaims.amendBody.claims.claim = null
        }
        
        return marshal(woApplicationBody);
    }
    
    
    private InputStream ipFilter(InputStream xml) throws Exception {
        String target = "<!DOCTYPE wo-application-body .*?\\.dtd\">";
        String xmlString = IOUtils.toString( xml, "utf-8").replaceFirst(target, "");   
        return(new ByteArrayInputStream(xmlString.getBytes("utf-8")));
    }

    public Document toMongoDoc2(Document doc, String xmlContent) throws IOException, Exception{
        super.toMongoDoc2(doc, IOUtils.toString( ipFilter(IOUtils.toInputStream(xmlContent, 'utf-8')), 'utf-8'))
    }
    
//    @Override
//    public Document toMongoDoc(Document doc, String xmlContent)
//            throws IOException, Exception {
//        
//        return null;
//    }
    
//    
//    public static void main(String[] args){
//        
//        System.out.println(111);
//        WoApplicationBodyXmlConvertor woApp = new WoApplicationBodyXmlConvertor();
//        
//        try{
//            woApp.test(woApp);
//        }catch(Exception e){
//            System.out.println(e.getStackTrace());
//        }
//    }
}
