package wipo.marshaller
import groovy.json.JsonSlurper

import java.text.SimpleDateFormat

import org.apache.commons.cli.CommandLine
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.Options
import org.apache.commons.io.IOUtils
import org.apache.commons.io.input.BOMInputStream
import org.bson.Document
import org.bson.types.ObjectId
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import util.ArgsUtility
import util.MapUtility
import util.mongo.GridFSUtil
import util.mongo.MongoTestingMachine
import util.mongo.MongoWoNewDataMachine
import wipo.marshaller.xmlConverter.XmlConverter
import wipo.marshaller.xmlConverter.XmlConverterFactory

import com.mongodb.BasicDBObject
import com.mongodb.Bytes
import com.mongodb.DB
import com.mongodb.DBCollection
import com.mongodb.DBCursor
import com.mongodb.MongoCursorNotFoundException
import com.mongodb.gridfs.GridFS
import com.mongodb.gridfs.GridFSDBFile

class WoMarshaller {
    static Logger log = LoggerFactory.getLogger(WoMarshaller.class)

    DBCollection fromColl
    GridFS fromGridFs
    DBCollection toColl
    DBCollection errColl
    Document query
    boolean debug
    int curIndex
    int length
    XmlConverterFactory xmlConverterFactory

    static final List<String> usedKey = ['docId', 'doDate', 'kindcode', 'openNumber', 'releaseWeek', 'xmltype', 'xmltypeAbb', 'filename']

    WoMarshaller(String[] args){

        String toDBname
        String toCollname
        DB toDB
        curIndex = 0
        parseArgs(args)

        if(debug){
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date strDate = formatter.parse("2009-08-10")
            Date endDate = formatter.parse("2011-08-21")
//            query = new Document(["doDate":[$gt: strDate, $lt: endDate], "xmltypeAbb":'LNP'])
//                        query = new Document(['docId': '2011067944A1/20110609/WAB'])
//                        query = new Document(['docId': '2006088865A1/20060824/WPA'])
//                        query = new Document(['docId': '1978000015A1/19781221/LNP'])
            query = new Document([ "docId": [$in:
                [
//                    '2004078228B1/20051013/LNP',
//                    '2001009665A3/20010208/LNP',
//                    '2001003042B1/20010308/LNP',
//                    '1993020020A3/19931125/LNP',
//                    '1991015349A3/19911128/LNP',
//                    '1991009096A3/19910725/LNP',
//                    '1991006059A3/19910530/LNP',
//                    '1991002447A3/19910418/LNP',
//                    '1990004323A3/19900628/LNP',
//                    '1989010372A3/19891116/LNP',
//                    '1989003863A3/19890601/LNP',
//                    '1988010444A3/19890223/LNP',
//                    '1988010224A3/19890126/LNP',
//                    '1988006886A3/19890112/LNP',
//                    '1988006615A3/19881006/LNP',
//                    '1988004951A3/19880825/LNP',
//                    '1988004313A3/19880714/LNP',
//                    '1988003553A3/19880811/LNP',
//                    '1988002763A3/19880505/LNP',
//                    '1988002691A3/19880728/LNP',
//                    '1988002690A3/19880728/LNP',
//                    '1988002089A3/19880407/LNP',
//                    '1988001138A3/19880421/LNP',
//                    '1988000950A3/19880324/LNP',
//                    '1988000611A3/19880324/LNP',
//                    '1988000603A3/19880324/LNP',
//                    '1988000200A3/19880421/LNP',
//                    '1987005927A3/19880324/LNP',
//                    '1987003613A3/19870911/LNP',
//                    '1987000032A3/19870312/LNP',
//                    '1986006756A3/19861218/LNP',
//                    '1985004289A3/19851024/LNP',
//                    '1984003188A3/19840816/LNP',
//                    '1981003327A2/19811126/LNP',
                    
                    // ipc modification
//                    '2014120969A1/20140807/WPA',
                    
                    // kind error
//                    '1985005264A1/19851205/LNP',
//                    '1985004289A1/19850926/LNP',
//                    '1985003838A2/19850812/LNP',
                    
                    // date error
                    '2007109735A3/20070927/LNP',
                    '2008082726A3/20080710/LNP',
                    '2001051353A1/20010719/LNP',
                    '2007120563A3/20071025/LNP',
                    '1996033173A2/19961024/LNP',
                    '1983004188A1/19831208/LNP',
                    '1993004728A1/19930318/LNP',
                    '1993014278A1/19930722/LNP',
                    '1999011647A1/19990311/LNP',
                    '1998036037A1/19980820/LNP',
                    '2007030902A3/20070322/LNP',
                    '1998029384A1/19980709/LNP',
                    '1987006338A1/19871022/LNP',
                    
                    
                ]
            ]])
        
//            // Testing target
            toDBname = 'PatentRawWIPO'
            toCollname = 'PatentMarshallManual0426'
            toDB = new MongoTestingMachine().getDb(toDBname)
            // regular target
//            toDBname = 'PatentMarshallWIPO'
//            toCollname = 'PatentMarshallWIPO'
//            toDB = new MongoWoNewDataMachine().getDb(toDBname)
            

        }else{
            // regular target
            toDBname = 'PatentMarshallWIPO'
            toCollname = 'PatentMarshallWIPO'
            toDB = new MongoWoNewDataMachine().getDb(toDBname)
        }

        // mongo connection
        // mongo 101 connection
        String fromDBname = "PatentRawWIPO"
        String fromBucketname = "PatentRawWIPOGridFS"
        DB fromDB = new MongoWoNewDataMachine().getDb(fromDBname)

        // Error collction
        String errSchemaColl = "ErrorSchema"
        fromGridFs = new GridFS(fromDB, fromBucketname)
        fromColl = fromDB."${fromBucketname}.files"
        errColl = toDB."$errSchemaColl"
        toColl = toDB."$toCollname"

        xmlConverterFactory = new XmlConverterFactory()

    }

    void marshallData(){
        log.info("use query:" + query.toString())
        DBCursor dbCursor = fromColl.find(query).addOption(Bytes.QUERYOPTION_NOTIMEOUT)
        length = dbCursor.size()
        log.info('Query finished: result size ' + length)
        //        runMarshall(dbCursor, curIndex)

        while(curIndex < length){
            try{
                runMarshall(dbCursor, curIndex)
            }catch(MongoCursorNotFoundException e){
                log.error(e.message)
                log.error('reconnecting ...')
                dbCursor = fromColl.find(query)
            }
        }        

    }

    private void runMarshall(DBCursor cursor, int skipNumber){
        float curRatio
        XmlConverter xmlConverter

        cursor.skip(skipNumber).eachWithIndex{ curDBCur, index ->
            if(index % 500 == 0) {
                curIndex = index + skipNumber
                curRatio = curIndex/length
                log.info("current status: ${curIndex}/${length} (${curRatio})")
            }

            try{
                Document currentResult = MapUtility.subMap(GridFSUtil.toDoc(curDBCur), usedKey)
                xmlConverter = xmlConverterFactory.getConverter(currentResult['xmltypeAbb'])

                currentResult['tags'] = new Document(['processor':'WoMasheller', 'files':xmlConverter.getRelatedFile()])
                GridFSDBFile currentGridFSD = fromGridFs.findOne(new BasicDBObject( ['docId': currentResult['docId']]))
                String currentXml = toXmlString(currentGridFSD.getInputStream())
                String jsonstr = xmlConverter.xml2Json(currentXml)
                currentResult['data'] = xmlConverter.toMongoDoc2(new Document(new JsonSlurper().parseText(jsonstr)), currentXml)
                toColl.update(['docId': currentResult['docId']], currentResult, true)

            }catch(Exception e){
                Document err = new Document(GridFSUtil.toDoc(curDBCur))
                err.remove('_id')
                err['err'] = e.message
                err['stackTrace'] = e.stackTrace.toString()
                println 'exception'
                errColl << err
            }
        }

        curIndex = length
        log.info("current status: ${curIndex}/${length} (1.00)")
    }


    public static String toXmlString(InputStream xml){
        return IOUtils.toString( new BOMInputStream(xml), 'utf-8')
    }


    void parseArgs(String[] args){
        if(!args){
            debug = true
            log.info("debug mode running")
            return
        }else{
            debug = false
        }

        Options options = new Options()
        options.addOption(ArgsUtility.startDate())
        options.addOption(ArgsUtility.endDate())
        options.addOption(ArgsUtility.xmlTypeAbb())
        options.addOption(ArgsUtility.releaseWeek())

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try{
            CommandLine cli = new DefaultParser().parse( options, args)
            Date strDate = formatter.parse((cli.hasOption('sd'))? cli.getParsedOptionValue('sd') : "1950-01-01")
            Date endDate = formatter.parse((cli.hasOption('ed'))? cli.getParsedOptionValue('ed') : "2050-01-01")
            query = new Document("doDate":[$gt: strDate, $lt: endDate])

            if(cli.hasOption('xml')){
                String xmltypeAbb = cli.getOptionValue('xml')
                if(!(new HashSet(['WPA', 'OPA', 'LNP', 'WAB']).contains(xmltypeAbb))){
                    throw new Exception('xml must be one of the following words: WPA, OPA, LNP, WAB')
                }
                query.put('xmltypeAbb', xmltypeAbb)
            }

            if(cli.hasOption('rw')){
                query.put('releaseWeek', cli.getParsedOptionValue('rw') )
            }

        }catch(Exception e){
            println e.message
            ArgsUtility.printHelp(this.class, options)
            System.exit(0)
        }
        return
    }


    static main(args) {
        new WoMarshaller(args).marshallData()
        log.info("Done")
    }
}
