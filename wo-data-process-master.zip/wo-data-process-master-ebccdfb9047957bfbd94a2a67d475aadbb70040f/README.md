# wo-data-processor

## wipo.importer
 - UnzipImporter: Streaming 解壓縮的方法，須實作 save function
 - GridFSImporter: import 至 GridFS
 - WoDvdImageImport: 從 WO DVD import 影像檔, 解碼
 - TODO: WoDVDImporter: 直接 import WoDVD 書目、影像檔   


### wipo.importer.extractor
處理 raw data 的 metadata

  
## wipo.marshaller
展開 raw data

- xmlConvertor : 使用個別 xml schema (.xsd) 驗證及展開對應的 xml
- WoMarshaller : 將 mongo 中的 raw data 展開並存入 mongo 

## wipo.mover
搬移舊資料 - 舊mongo 移到 3.0 存成 GridFS 的形式

## wipo.unzip
@deprecated 解壓縮到檔案，改用 UnzipImporter  