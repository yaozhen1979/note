package org.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class XMLGregorianCalendarTester {

    public static void main(String[] args) throws DatatypeConfigurationException {
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(2015, 7, 5);
        GregorianCalendar c = new GregorianCalendar();
        c.setTime(calendar.getTime());
        XMLGregorianCalendar date2 = DatatypeFactory.newInstance()
                .newXMLGregorianCalendar(c);
        
        System.out.println(date2);
        
    }

}
