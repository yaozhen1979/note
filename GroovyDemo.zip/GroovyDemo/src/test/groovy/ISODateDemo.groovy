import java.text.DateFormat
import java.text.SimpleDateFormat

def now = new Date();

// GMT UTC
TimeZone tz = TimeZone.getTimeZone("UTC");
DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
df.setTimeZone(tz);
String nowAsISO = df.format(now);

println "now = ${nowAsISO}"

DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
println "local time zone = ${df2.format(now)}"
