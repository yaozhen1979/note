import static jodd.jerry.Jerry.jerry as $

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient

import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

Logger logger = LoggerFactory.getLogger(this.class);

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

//
// def queryData = patentRawDOCDB.PatentRawDOCDB.findOne(_id: new ObjectId("5579499f60b2872f2499b37a"));

// IL => 13793
// FR => 232789
// ES => 32274
// TW => 0
// WO => 3061742
// US => 
def country = "KR"

def totalCount = patentRawDOCDB.PatentRawDOCDB.count([country: country, fileType: 0])

def currentSize = 0

def overTwoTitleSize = 0

patentRawDOCDB.PatentRawDOCDB.find([country: country, fileType: 0]).each { it ->
// _id: new ObjectId("5579499f60b2872f2499b37a")   
// patentRawDOCDB.PatentRawDOCDB.find([_id: new ObjectId("5579499f60b2872f2499b37a") ]).limit(1).each { it ->
 
    def output = it.data.xml
    def dom = $(output)
    def titleSize = dom.find('exch\\:invention-title').size()
    if (titleSize > 1) {
        logger.info("${country},${it._id}, title data is over 1...");
        overTwoTitleSize++
    }
    
    def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
    
    println consoleLog
}


//def output = queryData.data.xml
//
//def dom = $(output)
//
//println "find data size = " + dom.find('exch\\:invention-title').size()
//
//def originalTitle = dom.find('exch\\:invention-title[data-format="original"]')
//
//def docdbaTitle = dom.find('exch\\:invention-title[data-format="docdba"]')
//
//def docdbTitle = dom.find('exch\\:invention-title[data-format="docdb"]')
//
//println "parsing..."
//
//println "original title = " + originalTitle.text()
//
//println "docdb title = " + docdbTitle.text()
//
//println "docdba title = " + docdbaTitle.text()

println "overTwoTitleSize = ${overTwoTitleSize}"

println "finished..."

def parseDate(String date) {
    //
    if (data == null) {
        return null;
    }

    DateFormat fmtInput = new SimpleDateFormat("yyyy-MM-dd");
    try {
        fmtInput.setTimeZone(TimeZone.getTimeZone("GMT"));
        return fmtInput.parse(date);
    } catch (ParseException e) {
        e.printStackTrace();
    }
    return null;
}