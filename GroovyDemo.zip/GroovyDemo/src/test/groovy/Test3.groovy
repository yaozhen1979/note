

def line = "2015-07-08 16:09:38,339 [main] INFO  JerryTest - IL,557949a160b2872f2499c11e, title data is over 2..."

def dataList = line.split(" - ")[1].split(",")

println dataList[0].trim() + "-" + dataList[1].trim()
