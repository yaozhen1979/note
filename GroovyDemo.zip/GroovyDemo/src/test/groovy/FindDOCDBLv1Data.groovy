// import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.common.utils.DateUtil
import org.bson.types.ObjectId

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
// def lv2Client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [lv2Auth])

def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

// 
def queryData = patentRawDOCDB.PatentRawDOCDB.findOne(_id: new ObjectId("5577000460b27c4751a0623c"));

println "queryData = ${queryData.data.xml}"

// 22371884