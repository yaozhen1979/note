def checkFile = ["_data.txt", "bibliography.html", "claim.xml", "description.xml"]

checkFile.remove("_data.txt");
checkFile.remove("claim.xml")

println checkFile