def test = [1, 3, 5, 7, 9, 11, 13, 15]

println test[-1]