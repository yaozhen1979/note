package org.img;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class LoadAndShow extends JPanel {
    
    private static final String PATH = "/change/to/your/path/test.tif";
    private BufferedImage image;
    private Dimension size = new Dimension();

    public LoadAndShow(BufferedImage image) {
        this.image = image;
        size.setSize(image.getWidth(), image.getHeight());
    }

    protected void paintComponent(Graphics g) {
        int x = (getWidth() - size.width) / 2;
        int y = (getHeight() - size.height) / 2;
        g.drawImage(image, x, y, this);
    }

    public Dimension getPreferredSize() {
        return size;
    }

    public static void main(String[] args) throws IOException {
        BufferedImage image = ImageIO.read(new File(PATH));
        LoadAndShow test = new LoadAndShow(image);
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(new JScrollPane(test));
        f.setSize(400, 400);
        f.setLocation(200, 200);
        f.setVisible(true);
    }
}
