/**
 * TODO: 處理從EPO所下戴的ZIP File, 解壓縮 XML 至相關目錄.
 */
package net.lingala.zip4j.tony;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.unzip.UnzipUtil;

public class ExtractDocdbData {
    
    private final int BUFF_SIZE = 4096;
    
    /**
     * 
     * @param zipFilePath T:/cn_img/20150819/TIFFWG_20150819_001.zip
     * @param destinationFolderPath T:/cn_img/20150819
     * @param type WG
     */
    public ExtractDocdbData(String zipFilePath, String destinationFolderPath, String path) {
        
        ZipInputStream is = null;
        OutputStream os = null;
        
        try {
            // Initiate the ZipFile => T:\cn_img\20150819\TIFFWG_20150819_001
            ZipFile zipFile = new ZipFile(zipFilePath);
            String destinationPath = destinationFolderPath + "/" + path;
            
            if (!zipFile.isValidZipFile()) {  
                throw new ZipException("bad zip file...");  
            } else {
                System.out.println("good zip file");
            }
            
            // If zip file is password protected then set the password
            if (zipFile.isEncrypted()) {
                zipFile.setPassword("password");
            } else {
                System.out.println("no Encrypt...");
            }
            
            // Get the list of file headers from the zip file
            List fileHeaderList = zipFile.getFileHeaders();
            
            for (int i = 0; i < fileHeaderList.size(); i++) {
                
                FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
                //
                if (fileHeader != null) {
                    
                    // new ZipFile(fileHeader.get)
                    
                    //Build the output file => Name: WG\2015\3133\2015300586668\000003.JPG
                    String fileName = fileHeader.getFileName();
                    
                    if (fileName.endsWith(".zip")) {
                        
                        // System.out.println("File Name = " + fileName);
                        
                        String[] fileNameList= fileName.split("/");
                        
                        String outFilePath = destinationPath + "/" + fileNameList[3];
                        File outFile = new File(outFilePath);
                        
                        //Checks if the file is a directory
                        if (fileHeader.isDirectory()) {
                            outFile.mkdirs();
                            return;
                        }
                        
                        //Check if the directories(including parent directories)
                        //in the output file path exists
                        File parentDir = outFile.getParentFile();
                        if (!parentDir.exists()) {
                            parentDir.mkdirs(); //If not create those directories
                        }
                        
                        is = zipFile.getInputStream(fileHeader);
                        os = new FileOutputStream(outFile);
                        
                        int readLen = -1;
                        byte[] buff = new byte[BUFF_SIZE];
                        
                        while ((readLen = is.read(buff)) != -1) {
                            os.write(buff, 0, readLen);
                        }
                        
                        is.close();
                        os.close();
                        
                        UnzipUtil.applyFileAttributes(fileHeader, outFile);
                        
                        System.out.println("Done extracting: " + outFilePath);
                        
                        //
                        ZipFile innerZipFile = new ZipFile(outFilePath);
                        // D:\share\docdb\Cr-Del\201527
                        List innerZipFileHeaderList = innerZipFile.getFileHeaders();
                        
                        for (int j = 0; j < innerZipFileHeaderList.size(); j++) {
                            
                            FileHeader innerFileHeader = (FileHeader)innerZipFileHeaderList.get(j);
                            String innerFileName = innerFileHeader.getFileName();
                            System.out.println("Done extracting innerFileName = " + innerFileName);
                            // TODO:
                            innerZipFile.extractFile(innerFileName, destinationFolderPath + "/" + path + "/unzip");
                            // innerZipFile.extractFile(innerFileName, "D:/share/docdb/Cr-Del/201527/unzip");
                        }
                        
                    }
                        
                        
                } else {
                    System.err.println("FileHeader does not exist");
                }
            }
                
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        
        long startTime = System.nanoTime();
        
        /**
         * T:\docdb\data\Amend\2015\docdb_xml_201527_Amend_001.zip\docdb_xml_201527_Amend_001\Root\DOC\
         */
        
        // TODO: 
        String year = "2015";
        String period = "29";
        String processPeriod = year + period;
        
        String unzipFolder = "D:/share/docdb/Amend";
        // String unzipFolder = "D:/share/docdb/Cr-Del";
        
        new ExtractDocdbData("T:/docdb/data/Amend/2015/docdb_xml_" + processPeriod + "_Amend_001.zip", unzipFolder, processPeriod);
        // new ExtractDocdbData("T:/docdb/data/Cr-Del/2015/" + period + "/docdb_xml_" + processPeriod + "_CreateDelete_001.zip", unzipFolder, processPeriod);
        
        
        long stopTime = System.nanoTime();
        
        long duration = stopTime - startTime;
        
        System.out.println(TimeUnit.SECONDS.convert(duration, TimeUnit.NANOSECONDS));
    }

}
