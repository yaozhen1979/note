/**
 * fileType => 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
 */
import utils.MongoUtil
import org.common.utils.DateUtil
import org.bson.types.ObjectId

import static jodd.jerry.Jerry.jerry as $

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

println "to start..."
//
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "127.0.0.1", 27017, 'admin')

// TODO: for local test => TonyDB
// def localClient = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "127.0.0.1", 27017, 'admin')

def db = client.getDB("TonyDB")

def aryData = []

aryData << ['docdbDoDate': DateUtil.parseDate("2015-01-08"), 'status': 'B'] << ['docdbDoDate': DateUtil.parseDate("2015-01-08"), 'status': 'A'] << ['docdbDoDate': DateUtil.parseDate("2015-01-08"), 'status': 'A']

def insertData = [
    'history': aryData
]

db.ArrayTest.insert(insertData);

println "finished..."
