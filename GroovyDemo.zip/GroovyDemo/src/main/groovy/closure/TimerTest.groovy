import groovy.time.TimeCategory
import groovy.time.TimeDuration

def timeCalculateClosure = { closure ->

    def timeStart = new Date()

    closure()

    def timeStop = new Date()

    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    println duration
}

def test() {
    def total = 0
    for (def i = 0; i < 1000; i++) {
        total += i
    }
    println "total is ${total}"
}

timeCalculateClosure{ test() }