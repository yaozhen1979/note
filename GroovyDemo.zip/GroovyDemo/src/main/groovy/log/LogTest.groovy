@Grapes([
    @Grab(group='org.slf4j', module='slf4j-api', version='1.7.12'),
    @Grab(group='ch.qos.logback', module='logback-core', version='1.1.3'),
    @Grab(group='ch.qos.logback', module='logback-classic', version='1.1.3')
])

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

Logger logger = LoggerFactory.getLogger(this.class);

logger.info("log test");
logger.info("log test II");