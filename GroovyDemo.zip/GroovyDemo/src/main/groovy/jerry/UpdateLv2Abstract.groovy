/**
 * update DOCDB LV2 Abstract
 */
import groovy.time.*
import utils.MongoUtil

import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static jodd.jerry.Jerry.jerry as $

// Logger logger = LoggerFactory.getLogger(this.class);

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def country = "CN"

def timeStart = new Date()

def patentRawDOCDB = client.getDB("PatentRawDOCDB")
def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

def totalCount = 0
def currentCount = 0
def errCount = 0

def filePath = "log_for_docdb_lv1/err_abstract_objectId/CN-err-abstract-objectId.txt"
// def filePath = "log_for_docdb_lv1/err_abstract_objectId/test.txt"

new File(filePath).eachLine { line ->
    if (line.toString().trim() != "") {
        totalCount++
    }
}

println "totalCount = ${totalCount}"

// log_for_update_lv2_title
File lv2ObjectIdLog = new File("log_for_update_lv2_abstract/${country}_lv2_objectId.log")
File errLog = new File("log_for_update_lv2_abstract/${country}_err.log")

new File(filePath).eachLine { line ->
    
    //
    def lv1Id = line.toString().trim()
    def lv1Doc = patentRawDOCDB.PatentRawDOCDB.findOne(_id: new ObjectId(lv1Id))
    
    // println "country = ${document.country}"
    
    def output = lv1Doc.data.xml
    def dom = $(output)
    
    def patentNumber = dom.find('exch\\:bibliographic-data > exch\\:publication-reference[data-format="docdb"]').find("doc-number").text()
    // println "patentNumber = ${patentNumber}"
    
    // 'exch\\:exchange-document'
    def kindcode = dom.find('exch\\:exchange-document').attr('kind')
    // println "kindcode = ${kindcode}"
    
    def count = patentInfoDOCDB.PatentInfoDOCDB.count([country:country, patentNumber:patentNumber, kindcode:kindcode])
    
    if (count == 1) {
        
        def lv2Doc = patentInfoDOCDB.PatentInfoDOCDB.findOne([country:country, patentNumber:patentNumber, kindcode:kindcode])
        
        def briefList = dom.find('exch\\:abstract')
        def brief = [:]
        
        /*
         *  判斷 data-format = "docdba" 的 abstract-source 是否為 translation,
         *  否則通常為 national office
         */
        def isTranslation = false;
        
        briefList.each { it ->
            
            // println it.attr('lang')
            // println it.attr('data-format')
            
            if (it.attr('lang') != null) {
                
                if (it.attr('abstract-source') == 'translation') {
                    isTranslation = true;
                    brief.put(it.attr('lang'), it.text())
                } else if (isTranslation == false) {
                    brief.put(it.attr('lang'), it.text())
                }
                
            }
            
            if (it.attr('data-format') == 'original') {
                brief.put("original", it.text())
            }
            
        }
        
        // println "brief = ${brief}"
        
        patentInfoDOCDB.PatentInfoDOCDB.update(
            [_id: lv2Doc._id],
            [$set: [
                brief: brief
            ]]
        );
        
        // write lv2 objectId to mike
        lv2ObjectIdLog << lv2Doc._id << ln
        
        println "[country=${country},LV1=${lv1Doc._id},LV2=${lv2Doc._id}] are processing update data = ${++currentCount} / ${totalCount}"
        
    } else {
    
        errLog << lv1Doc._id << ln
        errCount++;
        
        println "[country=${country},LV1=${lv1Doc._id} are processing error data = ${++currentCount} / ${totalCount}"
        
    }
    
}

println "total count = ${currentCount} / ${totalCount}"
println "errCount = ${errCount}"
println "finished..."

def timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
println duration
