/**
 * update DOCDB LV2 Title And Abstract
 */
import groovy.time.*
import utils.MongoUtil

import org.bson.types.ObjectId
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import static jodd.jerry.Jerry.jerry as $

// Logger logger = LoggerFactory.getLogger(this.class);

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

/*
 *  [
 *   "AM", "AP", "AR", "AT", "AU", 
 *   "BA", "BE", "BG", "BR", "BY", 
 *   "CA", "CH", "CL", "CN", "CO", "CR", "CS ", "CU", "CY", "CZ", 
 *   "DD", "DE", "DZ", "DK", "DO"
 *   "EA", "EC", "EE", "EG", "EP", "ES", 
 *   "FI", "FR", 
 *   "GB", "GC", "GE", "GR", "GT", 
 *   "HK", "HN", "HR", "HU", 
 *   "ID", "IE", "IL", "IN", "IS", "IT", "JO", "JP", "KE", "KG", "KR", "KZ", 
 *   "LT", "LU", "LV", "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", 
 *   "MY", "NI", "NL", "NO", "NZ", "OA", "PA", "PE", "PH", "PL", "PT", 
 *   "RO", "RS", "RU", "SE", "SG", "SI", "SK", "SM", "SU", "SV", "TH", 
 *   "TJ", "TN", "TR", "TT", "TW", "UA", "US", "UY", "UZ", "VN", "WO", 
 *   "YU", "ZA", "ZM", "ZW"
 *  ]
 */
def ccList = [
    "DK", "DO",
    "HK", "HN", "HR", "HU", "ID", "IE", "IL", "IN", "IS", "IT", "JO", 
    "KE", "KG", "KZ", "LT", "LU", "LV", "MA", "MC", "MD", "ME", "MN", 
    "MT", "MW", "MX", "MY", "NI", "NL", "NO", "NZ", "OA", "PA", "PE", 
    "PH", "PL", "PT", "RO", "RS", "RU", "SE", "SG", "SI", "SK", "SM", 
    "SU", "SV", "TH", "TJ", "TN", "TR", "TT", "UA", "UY", "UZ", "VN", 
    "YU", "ZA", "ZM", "ZW"
]

def testList = ["AU", "DD", "BG", "IT"]

def timeStart = new Date()

def patentRawDOCDB = client.getDB("PatentRawDOCDB")
def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

testList.each { cc -> 
    
    def currentCount = 0
    def errCount = 0
    def updateCount = 0
    def noUpdateCount = 0
    
    // 查詢條件
    def query = [country: cc]
    // CN: 557b7e05b4411f24f17ab80f => title, brief 都有更新
    // 
    // def query = [_id: new ObjectId("558c7322b4411f24f123a4bb")]
    
    //
    File updateLog = new File("log_for_update_lv2_title_and_abstract/${cc}_update.log")
    // File errLog = new File("log_for_update_lv2_title_and_abstract/${cc}_err.log")
    
    def totalCount = patentInfoDOCDB.PatentInfoDOCDB.count(query)
    // println "totalCount = ${totalCount}"
    
    patentInfoDOCDB.PatentInfoDOCDB.find(query).each { lv2Data -> 
        
        // println "lv2._id = ${lv2Data._id}"
        
        def historyList = lv2Data.history
        
        // import: 只找最後一筆的raw data id來更新
        def lastRawDataId = historyList[-1].rawDataId
        // println "lastRawDataId = " + lastRawDataId
        
        def lv1Data = patentRawDOCDB.PatentRawDOCDB.findOne([_id: lastRawDataId])
        
        def rawXml = lv1Data.data.xml
        
        // let jerry to parse xml data
        def dom = $(rawXml)
        //
        def updateData = [:]
        
        def titleList = dom.find('exch\\:invention-title')
        
        if (titleList.size() > 0) {
            //
            def title = titleList.inject([:]) { result, title ->
                
                // println title.attr('lang')
                // println title.attr('data-format')
                
                if (title.attr('lang') != null) {
                    result.put(title.attr('lang'), title.text())
                }
                
                if (title.attr('data-format') == 'original') {
                    result.put("original", title.text())
                }
                
                return result
            }
            
            // println "title = ${title}"
            updateData << ['title': title]
            
        } 
        
        //
        def briefList = dom.find('exch\\:abstract')
        
        if (briefList.size() > 0) {
            /*
             *  判斷 data-format = "docdba" 的 abstract-source 是否為 translation,
             *  否則通常為 national office
             */
            def isTranslation = false;
            
            def brief = briefList.inject([:]) { result, brief ->
                
                // println it.attr('lang')
                // println it.attr('data-format')
                
                if (brief.attr('lang') != null) {
                    
                    if (brief.attr('abstract-source') == 'translation') {
                        isTranslation = true;
                        result.put(brief.attr('lang'), brief.text())
                    } else if (isTranslation == false) {
                        result.put(brief.attr('lang'), brief.text())
                    }
                    
                }
                
                if (brief.attr('data-format') == 'original') {
                    result.put("original", brief.text())
                }
                
                return result
            }
            
            // println "brief = ${brief}"
            updateData << ['brief' : brief]
            
        }
        
        if (updateData.size() > 0) {
            //
            // updateData << ['redmine':['bug':12789, 'status':'in progress']]
            //
            def mongoSyncFlag = lv2Data.mongoSyncFlag
            mongoSyncFlag << ['last': new Date()]
            updateData << ['mongoSyncFlag': mongoSyncFlag]
            //
            // println "updateData = ${updateData}"
            
            // TODO: 如為測試, 可先comment
            patentInfoDOCDB.PatentInfoDOCDB.update(
                [_id: lv2Data._id],
                [$set: updateData]
            );
        
            //
            updateCount++
        
        } else {
            //
            def noUpdateMsg = "update lv2._id = ${lv2Data._id} from lv1._id = ${lastRawDataId.toString()}, no title and no brief need to update..."
            println noUpdateMsg
            updateLog << noUpdateMsg << ln
            //
            noUpdateCount++
        }
        
        currentCount++;
        
        def msg = "update lv2._id = ${lv2Data._id} from lv1._id = ${lastRawDataId.toString()} , processing  = ${currentCount} / ${totalCount}"
        updateLog << msg << ln
        println msg
        // println "errCount = ${errCount}"
        
    }
    
    updateLog << "updateCount = ${updateCount}"  << ln
    updateLog << "noUpdateCount = ${noUpdateCount}" << ln
    
}  // end ccList each

println "====================================================="
println "finished..."

def timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
println duration
