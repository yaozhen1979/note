/**
 * update DOCDB LV2 Title And Abstract
 */
import groovy.time.*
import utils.MongoUtil

import org.bson.types.ObjectId
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

import org.bson.types.ObjectId
import org.common.utils.DateUtil

import static jodd.jerry.Jerry.jerry as $

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

// Logger logger = LoggerFactory.getLogger(this.class);

def ln = System.getProperty('line.separator')

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def cc = "BG"

File file = new File("log/redmine/12789/12789_for_${cc}.log")

def idList = []

file.eachLine { line ->
    
    if (line.toString().startsWith("lv2._id")) {
        
        def data = line.toString().split("=")
        
        idList << data[1].trim()
        
    }
    
}

//def idList = [
//    "5591d169b4411f24f1ee509a",
//    "5591d169b4411f24f1ee5123"
//]

def timeStart = new Date()

def patentRawDOCDB = client.getDB("PatentRawDOCDB")
def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

def sizeOfBulk = 1000

idList.each { objectId ->
    
    def currentCount = 0
    def errCount = 0
    def updateCount = 0
    def noUpdateCount = 0
    def countOfBulk = 0
    
    // 查詢條件:
    // country: JP
    // for doDate: db.PatentInfoDOCDB.find({country:"JP", doDate: {$gte: ISODate("1913-01-01T00:00:00Z"), $lt:ISODate("1993-01-01T00:00:00Z")} }).count() => 10368826
    // for doDate: db.PatentInfoDOCDB.find({country:"JP", doDate: {$gte: ISODate("1993-01-01T22:00:00Z")} }).count() => 12036972
    
    // country: CN
    // def query = [country: cc, doDate: [$gte: DateUtil.parseDate("2011-01-01"), $lt:DateUtil.parseDate("2015-02-26")]]
    def query = [_id: new ObjectId(objectId)]
    
    // only query country
    // def query = [country: cc]

    // for test data => CN: 557b7e05b4411f24f17ab80f => title, brief 都有更新
    // def query = [_id: new ObjectId("557b7e05b4411f24f17ab80f")]
    
    //
    File updateLog = new File("log_for_update_lv2_title_and_abstract/${cc}_update_by_id.log")
    // File errLog = new File("log_for_update_lv2_title_and_abstract/${cc}_err.log")
    
    def totalCount = patentInfoDOCDB.PatentInfoDOCDB.count(query)
    // println "totalCount = ${totalCount}"
    
    BulkWriteOperation updateBulk = patentInfoDOCDB.PatentInfoDOCDB.initializeOrderedBulkOperation()
    
    patentInfoDOCDB.PatentInfoDOCDB.find(query).each { lv2Data ->
        
        // println "lv2._id = ${lv2Data._id}"
        
        def historyList = lv2Data.history
        // println "historyList = ${historyList}"
        
        // important: 只找最後一筆的raw data id來更新
        def lastRawDataId;
        if (historyList.size() == 1) {
            lastRawDataId = historyList[-1].rawDataId
        } else {
            lastRawDataId = historyList[-2].rawDataId
        }
        // println "lastRawDataId = " + lastRawDataId
        
        def lv1Data = patentRawDOCDB.PatentRawDOCDB.findOne([_id: new ObjectId(lastRawDataId.toString())])
        if (lv1Data == null) {
            println "lv2._id = ${lv2Data._id}"
        }
        
        def rawXml = lv1Data.data.xml
        
        // let jerry to parse xml data
        def dom = $(rawXml)
        //
        def updateData = [:]
        
        def titleList = dom.find('exch\\:invention-title')
        
        if (titleList.size() > 0) {
            //
            def title = titleList.inject([:]) { result, title ->
                
                // println title.attr('lang')
                // println title.attr('data-format')
                
                if (title.attr('lang') != null) {
                    result.put(title.attr('lang'), title.text())
                }
                
                if (title.attr('data-format') == 'original') {
                    result.put("original", title.text())
                }
                
                return result
            }
            
            // println "title = ${title}"
            updateData << ['title': title]
            
        }
        
        //
        def briefList = dom.find('exch\\:abstract')
        
        if (briefList.size() > 0) {
            /*
             *  判斷 data-format = "docdba" 的 abstract-source 是否為 translation,
             *  否則通常為 national office
             */
            def isTranslation = false;
            
            def brief = briefList.inject([:]) { result, brief ->
                
                // println it.attr('lang')
                // println it.attr('data-format')
                
                if (brief.attr('lang') != null) {
                    
                    if (brief.attr('abstract-source') == 'translation') {
                        isTranslation = true;
                        result.put(brief.attr('lang'), brief.text())
                    } else if (isTranslation == false) {
                        result.put(brief.attr('lang'), brief.text())
                    }
                    
                }
                
                if (brief.attr('data-format') == 'original') {
                    result.put("original", brief.text())
                }
                
                return result
            }
            
            // println "brief = ${brief}"
            updateData << ['brief' : brief]
            
        }
        
        if (updateData.size() > 0) {
            //
            // updateData << ['isUpdateTitleAndBrief':true]
            //
            def mongoSyncFlag = lv2Data.mongoSyncFlag
            mongoSyncFlag << ['last': new Date()]
            updateData << ['mongoSyncFlag': mongoSyncFlag]
            //
            // println "updateData = ${updateData}"
            
            // 如為測試, 可先comment
            // builder.find(new BasicDBObject("_id", 1)).updateOne(new BasicDBObject("$set", new BasicDBObject("x", 2)));
            def updateMap = [$set: updateData]
            updateBulk.find(new BasicDBObject("_id", lv2Data._id)).updateOne(new BasicDBObject(updateMap))
            
            /*
            updateBulk.update(
                [_id: lv2Data._id],
                [$set: updateData]
            );
            */
        
            //
            updateCount++
            countOfBulk++
            
            // countOfBulk == sizeOfBulk 時, 則執行bulk execute.
            if (countOfBulk.mod(sizeOfBulk) == 0) {
                //
                println "batch update ...."
                //
                updateBulk.execute()
                // init bulk again
                updateBulk = patentInfoDOCDB.PatentInfoDOCDB.initializeOrderedBulkOperation()
                countOfBulk = 0
            }
        
        } else {
            //
            def noUpdateMsg = "update lv2._id = ${lv2Data._id} from lv1._id = ${lastRawDataId.toString()}, no title and no brief need to update..."
            println noUpdateMsg
            updateLog << noUpdateMsg << ln
            //
            noUpdateCount++
        }
        
        currentCount++;
        
        def msg = "update lv2._id = ${lv2Data._id} from lv1._id = ${lastRawDataId.toString()} , processing  = ${currentCount} / ${totalCount}"
        updateLog << msg << ln
        println msg
        // println "errCount = ${errCount}"
        
    }   // end collection find...
    
    // execute rest bulk count
    if (countOfBulk > 0) {
        //
        println "batch update ...."
        updateBulk.execute()
    }
    
    updateLog << "updateCount = ${updateCount}"  << ln
    updateLog << "noUpdateCount = ${noUpdateCount}" << ln
    
}  // end ccList each

println "====================================================="
println "finished..."

def timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
println duration
