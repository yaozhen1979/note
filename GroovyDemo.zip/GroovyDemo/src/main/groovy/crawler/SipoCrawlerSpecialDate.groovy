import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import groovy.time.*

def timeStart = new Date()
println "to start..."

System.properties << [ 'http.proxyHost':'10.60.94.41', 'http.proxyPort':'3128' ]

def client = MongoUtil.connect3X('datateamcn', 'hadfhastr', "10.60.90.101", 27017, 'admin')

def patentRawCN = client.getDB("PatentRawCN")

File errLog = new File("log/SipoCrawlerSpecialDate.log")

def SIPO_URL = "http://epub.sipo.gov.cn/patentoutline.action"
def typeList = [1, 2, 3, 4]

def dateList = ['20160203']

dateList.each { date ->

    def querydate = date.substring(0,4) + "." + date.substring(4,6) + "." + date.substring(6,8)

    typeList.each { type ->
        //
        def doc = null;
        def retry = 0;
        def typeCode;
        def ln = System.getProperty('line.separator')
        // def date = Date.parse('yyyy.MM.dd', querydate);
        def pageNum = 1;
        def pageSize = 20;
        // 專利筆數
        def cnt = 0
        // 專利類型中文說明 => 发明公布, 发明授权, 实用新型, 外观设计
        def patentCnType

        switch(type) {
            case 1 :
                typeCode = 'FM'
                patentCnType = '发明公布'
                break
            case 2 :
                typeCode = 'SD'
                patentCnType = '发明授权'
                break
            case 3 : 
                typeCode = 'XX'
                patentCnType = '实用新型'
                break
            case 4 : 
                typeCode = 'WG'
                patentCnType = '外观设计'
                break
            Default :
                break
        }

        while (retry < 10)  {

            try {
                // for 列表模式
                // showType=0&strWord=公开（公告）日='2015.05.06'&numSortMethod=0&strLicenseCode=&selected=fmsq&numFMGB=&numFMSQ=4609&numSYXX=&numWGSQ=&pageSize=10&pageNow=1
                doc = org.jsoup.Jsoup.connect(SIPO_URL).timeout(300000)
                        .data("showType", "0")
                        //.data("strWord", "公开（公告）日=BETWEEN['${date.format('yyyy.MM.dd')}','${enddate.format('yyyy.MM.dd')}']")
                        .data("strWord", "公开（公告）日='${querydate}'")
                        .data("pageSize", pageSize.toString())
                        .data("pageNow", pageNum.toString())
                        .data("numFMGB", type == 1 ? "0":"")   // 發明公佈
                        .data("numFMSQ", type == 2 ? "0":"")
                        .data("numSYXX", type == 3 ? "0":"")
                        .data("numWGSQ", type == 4 ? "0":"")
                        .post();
                break;
            } catch (Exception e) {
                retry++;
                println 'will retry list:' + retry
                println "Exception = ${e}"
            }

        }   // end while loop

        if (doc == null) {
            println 'could not get list!';
            throw new Exception("could note get list = ${querydate}")
        }

        // ex: 发明公布：16786件 => cx_nojg > 抱歉，没有您要查询的结果！
        // println "msg = " + doc.select(".cx_nojg").select("span").text()
        if (!doc.select(".cx_nojg").select("span").text().contains("抱歉，没有您要查询的结果！")) {

            def cntt = doc.select(".lxxz_dl").first().select("a").first().text()
            println "cntt = ${cntt}/${querydate}"

            cnt = cntt.substring(5, cntt.length()-1) as int
            println "cnt = ${cnt}/${querydate}"
            //
            // TODO: save to sql db / mongodb

        } else {
            // 发明公布, 发明授权, 实用新型, 外观设计
            println "${typeCode}:${querydate}:count=0"
            errLog << "${typeCode}:${querydate}:count=0" << ln
        }

        // TODO: refactor ???
        def sipoData = patentRawCN.PatentCountCN.findOne([type:"${typeCode}", doDate: DateUtil.parseDate(date)])

        if (sipoData) {

            sipoData.count = cnt

        } else {
            //
            def dataMap = [:]
            dataMap << [type: "${typeCode}"]
            dataMap << [typeCN: "${patentCnType}"]
            dataMap << [count: cnt]
            dataMap << [doDate: DateUtil.parseDate(date)]
            dataMap << [checkLv1ByTypeFlag: false]             // 是否依專利類型來和Lv1做數量上的檢證
            dataMap << [checkAppNumberByTypeFlag: false]       // 是否依專利類型來和Sipo所下戴來的申請號資料做數量上的檢證

            sipoData = dataMap
        }

        patentRawCN.PatentCountCN.save(sipoData)
    }

}

println "finished..."
