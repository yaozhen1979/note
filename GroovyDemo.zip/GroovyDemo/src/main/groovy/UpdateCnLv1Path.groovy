/**
 * 修正CNIPR LV1 path -> 20150513 FM, SD, XX
 * 
 * FM/20150513/201280038864.1 -> FM/2015/20150513/201280038864.1
 * 
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import com.sun.org.apache.bcel.internal.generic.DDIV;

def client = MongoUtils.connect('yyj', 'yyj', "10.60.90.127", 27017, 'admin')

def db = client.getDB("PatentRawCNIPR")

/*
 * FM:16330
 * db.getCollection('PatentRawCNIPR').find({path: {$regex: /FM\/20150513/ }}).limit(2)
 */

def totalCount = db.PatentRawCNIPR.find([path: [$regex: /XX\/20150513/]]).count()

def current = 0

db.PatentRawCNIPR.find([path: [$regex: /XX\/20150513/]]).limit(0).each { data -> 
    
    def path = data.path
    // println "path = ${path}"
    
    def pathList = path.split("/")
    // println "pathList = ${pathList}"
    
    def updatePath = pathList[0] + "/2015/" + pathList[1] + "/" + pathList[2]   
    // println "updatePath = ${updatePath}"
    
    //def type = data.getClass()
    //println "type = ${type}"
    
    db.PatentRawCNIPR.update(
        [_id: data._id],
        [$set: [
            path: updatePath
        ]]
    );
    
    def consoleLog = "_id = ${data._id} are processing update data = ${++current} / ${totalCount}"
    println consoleLog
    
}

println "finished..."
