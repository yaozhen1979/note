new File("doc/temp.txt").eachLine { line -> 
    println line
}