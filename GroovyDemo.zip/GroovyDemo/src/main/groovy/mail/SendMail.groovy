/**
 * smtp.auth=false
 * smtp.from=Patentcloud <service@patentcloud.com>
 * smtp.username=
 * smtp.password=
 * smtp.host=10.60.94.110
 * smtp.port=25
 *
 * @author tonykuo
 *
 */
import org.apache.commons.mail.DefaultAuthenticator
import org.apache.commons.mail.Email
import org.apache.commons.mail.SimpleEmail


Email email = new SimpleEmail();
email.setHostName("10.60.94.110");
email.setSmtpPort(25);
// email.setAuthenticator(new DefaultAuthenticator("username", "password"));
// email.setSSLOnConnect(true);
email.setFrom("service@patentcloud.com");
email.setSubject("TestMail");
email.setMsg("This is a test mail ... :-)");
// email.addTo("tonykuo@patentcloud.com", "tony kuo");
// email.addTo("mikelin@patentcloud.com", "tony kuo");
email.addTo("webber.larch@gmail.com", "tony kuo");
email.send();

println "finished..."
