import mail.MailUtil

MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "TestMail", "This is a test mail ... :-)")

println "send mail ok..."