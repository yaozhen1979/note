/**
 * 檢查由CNIPR下戴回的資料中的_data.txt, 其appNumber和folder name的appNumber是否一樣
 * 
 * _data.txt
 * bibliography.html
 * claim.xml
 * description.xml
 * 
 */

// T:\cnlist\rawdata\FM\20150624\201110266030.3

def type = "XX"
def findDate = "20150624"
// def findDate = "20150000"
// def appNumber = "201110266030.3"

def emptyFileList = [];

def count = 0

def ln = System.getProperty('line.separator')

File log = new File("log/checkCniprRawData-${type}-${findDate}}.txt")
 
File rawFolder = new File("T:/cnlist/rawdata/${type}/${findDate}")

println "checking..."

rawFolder.eachFile() { outerFile ->
        
    def folderName = outerFile.name
    
    if (outerFile.isDirectory()) {
        
        def checkFile = ["_data.txt", "bibliography.html", "claim.xml", "description.xml"]
        
        outerFile.eachFile() { innerFile ->
            
            // println innerFile.name
            
            if (innerFile.name == '_data.txt') {
                
                checkFile.remove(innerFile.name)
                def dataMap = [:]
                innerFile.eachLine { line ->
                    def data = line.split("[\\s|\\t]")
                    if (data.size() > 1) {
                        dataMap.put(data[0], data[1])
                    }
                }
                // println dataMap
                if (!dataMap.get("anum").contains(folderName)) {
                    println "appNumber [${folderName}] check no good..."
                    log << "appNumber [${folderName}] check no good..." << ln
                } else {
                    // println "appNumber [${folderName}] check good..."
                }
            }
            
            if (innerFile.name == 'bibliography.html' || innerFile.name == 'claim.xml' || innerFile.name == 'description.xml') {
                //
                checkFile.remove(innerFile.name)
                //
                def fileContent = "";
                                
                innerFile.eachLine { line ->
                    fileContent = fileContent << line
                }
                                                
                if (fileContent.toString().trim().length() == 0) {
                    // emptyFileList << "${folderName}/${innerFile.getName()}"
                    println  "empty file = ${folderName}/${innerFile.getName()}"
                    log << "empty file = ${folderName}/${innerFile.getName()}" << ln
                }
                
            }
            
        }
        
        // println "checkFile = ${checkFile}"
        
        if (checkFile.size() == 0) {
            // println "all file exist..."
        } else {
            println "${checkFile} dont exist"
            log << "${checkFile} dont exist"
        }
        
        println "===============================================${++count}"
        log << "===============================================${count}" << ln
        
    }
    
}
 
println "finished..."
