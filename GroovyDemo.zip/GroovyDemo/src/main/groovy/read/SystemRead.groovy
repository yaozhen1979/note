class SystemRead {

    static void main(args) {

        // def read = System.in.read();
        // println "read = " + read
        
        def file = new File("log/replicated_amend_log.txt").readLines()
        println file
        
        def firstLine
        new File("log/replicated_amend_log.txt").withReader { firstLine = it.readLine() }
        println firstLine
        
        new File("log/replicated_amend_log.txt").withReader('UTF-8') { reader -> 
            
            reader.eachLine { line ->
                println line
            }
            
        }
        
        // def process = "cmd /c java -version".execute()
        // println "${process.text}"
        
//        System.in.eachLine() { line ->
//            if(line.equals("exit"))
//                System.exit(1)
//            else
//                println "you entered: $line"
//        }
        
    }
}