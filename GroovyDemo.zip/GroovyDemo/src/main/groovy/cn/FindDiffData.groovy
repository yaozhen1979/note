package cn

import org.common.utils.DateUtil

import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress

class FindDiffData {

    static main(args) {
        
        File file = new File("log/20160413/delete_ptopid.txt")
        
        def lv2Auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
        def lv2Client = new GMongoClient(new ServerAddress("127.0.0.1", 27017), [lv2Auth])
        
        def sourceDB = lv2Client.getDB("PatentInfoCNIPR")
        def targetDB = lv2Client.getDB("PatentInfoCNIPR")
        
        println "start to backup..."
        
        int count = 0;
        
        def query = [doDate: DateUtil.parseDate("2016-02-17"), kindcode: 'S']
        
        sourceDB.WG_DoDate_20160217.find(query).limit(0).each { data ->
            
            // println "data = " + data
            println "copy data : ${++count}"
            def findData = targetDB.PatentInfoCNIPR.findOne([_id: data._id])
            if (!findData) {
                file << "ptopid = CNIPR.${data._id.toString()}" << "\r\n"
            }
        }
        
        println "finished"
    }

}
