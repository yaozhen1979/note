def test = [ "C12N 1/21" , "C12N 1/36" , "A61K 39/02" , "A61P 31/04" , "A61P 37/04" , "C12R 1/01"]

// println test.collect { it.replaceAll(/^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/) { result, group1, group2, group3, group4  -> result =    } }