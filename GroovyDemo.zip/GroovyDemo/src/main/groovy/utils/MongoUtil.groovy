package utils

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient

class MongoUtil {
    
    static GMongoClient connect3X(userId, userPwd, ip, port,  defaultCollection) {
        
        def auth = MongoCredential.createCredential(userId, defaultCollection, userPwd as char[])
        def client = new GMongoClient(new ServerAddress(ip, port), [auth])
        
        return client
    }
    
    static GMongoClient connect2X(userId, userPwd, ip, port,  defaultCollection) {
        
        def auth = MongoCredential.createMongoCRCredential(userId, defaultCollection, userPwd as char[])
        def client = new GMongoClient(new ServerAddress(ip, port), [auth])
        
        return client
    }
    
}