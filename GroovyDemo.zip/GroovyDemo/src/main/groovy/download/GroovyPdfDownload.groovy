
System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128']

new File("doc/test.pdf").withOutputStream { out ->
    out << new URL("http://pimg-fpiw.uspto.gov/fdd/46/073/091/0.pdf").openStream()
}

println "finished..."