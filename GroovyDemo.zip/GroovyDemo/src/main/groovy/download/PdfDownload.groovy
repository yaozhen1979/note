/**
 * httpclient 4.X 要如何設定 proxy ???
 */
import org.apache.commons.io.IOUtils
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.DefaultHttpClient

// http://pimg-fpiw.uspto.gov/fdd/47/073/091/0.pdf

System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' , 'http.proxyUser':'tonykuo', 'http.proxyPassword':'Yaozhen4321']

HttpClient httpclient = new DefaultHttpClient();

HttpGet httpget = new HttpGet("http://pimg-fpiw.uspto.gov/fdd/47/073/091/0.pdf");

HttpResponse response = httpclient.execute(httpget);
HttpEntity entity = response.getEntity();
if (entity != null) {
    long len = entity.getContentLength();
    InputStream inputStream = entity.getContent();
    // write the file to whether you want it.
    OutputStream outputStream = new FileOutputStream(new File("doc/test.pdf"));
    IOUtils.copy(inputStream, outputStream);
    outputStream.close();
}

println "finished..."