println "to start..."

File file1 = new File("log/temp/lv1Id.log")
def lv1Data = []
file1.eachLine { line ->
    lv1Data << line.toString()
}

File file2 = new File("log/temp/lv2Id.log")
def lv2Data = []
file2.eachLine { line ->
    lv2Data << line.toString()
}

println "lv1Data size = ${lv1Data.size()}"
println "lv2Data size = ${lv2Data.size()}"

println compare(lv1Data, lv2Data)

println "finished..."

def compare(List<String> list1, List<String> list2){

    Collections.sort(list1);
    Collections.sort(list2);
    //
    list1.removeAll(list2);
    
    return list1
}

