// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-03-05T00:00:00Z"), fileType:1, 'data.xml':{$regex: /status=\"D\"/}}).count();
// db.PatentInfoDOCDB.find({history: {$elemMatch: {docdbDoDate: ISODate("2015-03-05T00:00:00Z"), status: 'D'} }})

// 557b7e05b4411f24f17ab80f
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

def client = MongoUtils.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv1Db = client.getDB("PatentRawDOCDB")
def lv2Db = client.getDB("PatentInfoDOCDB")

def rawId = []

lv1Db.PatentRawDOCDB.find([docdbDoDate: DateUtils.parseDate("2015-03-05"), fileType:1, 'data.xml':[$regex: /status=\"D\"/]]).each { lv1 ->
    
    rawId << lv1._id
    
}

println "rawId size = ${rawId.size()}"
println "rawId = ${rawId}"

def lv2RawId = []
lv2Db.PatentInfoDOCDB.find(['history.docdbDoDate':DateUtils.parseDate("2015-03-05"), 'history.status':'D']).each { lv2 ->
    
    lv2RawId << lv2.history
    
}

println "lv2RawId size = ${lv2RawId.size()}"
println "lv2RawId = ${lv2RawId}"

println "finished..."
