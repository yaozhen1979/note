/**
 * 依doc/amend_replicated_data.txt所提供的LV2重複_id, 來查詢LV1._id
 */
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

def client = MongoUtils.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentInfoDOCDB")
def lv1Db = client.getDB("PatentRawDOCDB")

def queryDate = "2015-03-05"

def count = 0
def replicatedDataCount = 0

new File("doc/amend_replicated_data.txt").eachLine { line -> 
    
    def objectId = line.split("=")[1].toString().trim()
    println "${++count} -> Lv2 objectId = ${objectId}"
    
    db.PatentInfoDOCDB.find([_id: new ObjectId(objectId)]).each { it ->
        
        def country = it.country
        def patentNumber = it.patentNumber
        def kindcode = it.kindcode
        def stat = it.stat
        
        println "country = ${country}, patentNumber = ${patentNumber}, kindcode = ${kindcode}, stat = ${stat}"
        
        // TODO: 確認查詢條件
        lv1Db.PatentRawDOCDB.find([
            docdbDoDate: DateUtil.parseDate(queryDate),
            country: country, 
            fileType:2, 
            kindCode:kindcode, 
            // doc-number="0177137"
            'data.xml': [$regex : "doc-number=\"${patentNumber}\""]
        ]).each { rawData ->
            replicatedDataCount++
            println "rawData._id = ${rawData._id}"
        }
        
        println "==========================="
    }
    
}

println "replicatedDataCount = ${replicatedDataCount}"

println "finished..."
