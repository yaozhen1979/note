/**
 * 更新重複amend data為backfile的狀態
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil

import org.bson.types.ObjectId

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")

// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-01-01T00:00:00Z"), fileType: 2}).count()

println "start querying..."

// db.PatentInfoDOCDB.find({country:'IS', status:{$exists:true}}).count()

// raw id = 
patentInfoDOCDB.PatentInfoDOCDB.find(_id: new ObjectId("558c50cbb4411f24f11510ba")).each{it -> 
    
    // _id
    println "_id = ${it._id}"
    
    // history
    def historyList = []
    historyList << it.history[0]
    println "history = ${historyList}"
    
    // relRawdatas
    def relRawdatasList = []
    relRawdatasList << it.relRawdatas[0]
    println "relRawdatas = ${relRawdatasList}"
    
    // tagAndJsfile
    def tagAndJsfileList = []
    tagAndJsfileList << it.tagAndJsfile[0]
    println "tagAndJsfile = ${tagAndJsfileList}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id], 
        [$set: [ 
            history: historyList, relRawdatas: relRawdatasList, tagAndJsfile: tagAndJsfileList
        ]]
    );
    
    
}

println "finished..."
