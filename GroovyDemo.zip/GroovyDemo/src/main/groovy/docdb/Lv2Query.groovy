// 557b7e05b4411f24f17ab80f
import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentInfoDOCDB")

//  US20120221896A1
// def query = [_id: new ObjectId("558c50cbb4411f24f11510ba")]
// CA2242833A1
// def query = [country:'CA', patentNumber:'2242833', kindcode:'A1']
def query = [country:'AM']

// println "count = " + db.PatentInfoDOCDB.count(query)

//db.PatentInfoDOCDB.find(query).limit(0).each { it ->
//
//    // println "lv2 id = ${it._id}"
//    //it.history.each { history -> println history }
//    
//    println it
//    
//}

// ObjectId("55a85430b4411f24f11a6cde")
db.PatentInfoDOCDB.find([_id: new ObjectId("55a85430b4411f24f11a6cde")]).each { it ->

    println it
    // it.history.each { history -> println history }

}

//def count = db.PatentInfoDOCDB.count(['history.docdbDoDate':DateUtils.parseDate("2015-03-05"), 'history.status':'A'])
//println "count = ${count}"

//def count = db.ErrorPatentInfoDOCDB.find(['doc.docdbDoDate':DateUtils.parseDate("2015-03-05"), 'doc.fileType':2]).count()
//println "count = ${count}"

//db.ErrorPatentInfoDOCDB.find().sort([_id: -1]).limit(1).each { it -> 
//    println it
//}

println "finished..."
