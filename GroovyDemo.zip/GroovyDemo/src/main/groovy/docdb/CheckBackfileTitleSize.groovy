/**
 * 找出LV1中的資料, 有超過出現一次以上的title
 */
import static jodd.jerry.Jerry.jerry as $

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.common.utils.DateUtil
import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

Logger logger = LoggerFactory.getLogger(this.class);

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

// AM => 0
// AP => 0
// IL => 13793
// DE => 800604
// FR => 232789
// ES => 32274
// TW => 0
// WO => 3061742
// US => 0
// EP => 4653405
// CN => 152097
// JP => 8
// KR => 247
// ====================^^^ 13
def country = ""

// def query = [country: country, fileType: 0];

def query = [docdbDoDate: DateUtil.parseDate("2015-1-8"), fileType: 1];

def totalCount = patentRawDOCDB.PatentRawDOCDB.count(query)

def currentSize = 0

def overTwoTitleSize = 0

// logger.info("check ${country} title...");

patentRawDOCDB.PatentRawDOCDB.find(query).each { it ->
// _id: new ObjectId("5579499f60b2872f2499b37a")
// patentRawDOCDB.PatentRawDOCDB.find([_id: new ObjectId("5579499f60b2872f2499b37a") ]).limit(1).each { it ->
 
    def output = it.data.xml
    def dom = $(output)
    def titleSize = dom.find('exch\\:invention-title').size()
    if (titleSize > 1) {
        logger.info("${country},${it._id}, title data is over 1...");
        overTwoTitleSize++
    }
    
    def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
    
    println consoleLog
}

println "overTwoTitleSize = ${overTwoTitleSize}"

println "finished..."

