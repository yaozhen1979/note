/**
 * update 2015-01-01 Ament 這一期的 history.rawdataId -> history.rawDataId
 *
 */

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo

import org.bson.types.ObjectId

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")

println "start querying..."

def query = ['history.docdbDoDate': parseDate("2015-01-01"), 'history.status': 'A']

// def query = [_id: new ObjectId("557a9878b4411f24f16dbf68")]

def totalCount = patentInfoDOCDB.PatentInfoDOCDB.find(query).count()

def currentSize = 0;

def errCount = 0

patentInfoDOCDB.PatentInfoDOCDB.find(query).each{ it ->
    
    // patentInfoDOCDB.BackupDOCDB.insert(it);
    
    def historyList = []
    
    it.history.each { data ->
        
        if (data['rawdataId'] != null) {
            println "${it._ids}"
            errCount++;
        }
        
//         if (data['rawdataId'] != null) {
//             
//             def history = [:]
//             history << ["rawDataId":data.rawdataId]
//             history << ["docdbDoDate":data.docdbDoDate]
//             history << ["status":data.status]
//             //
//             historyList << history
//             
//         } else {
//             
//             historyList << data
//         
//         }
        
    }
    
    // println "historyList = ${historyList}"
    
    /*
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$set: [
            history: historyList
        ]]
    );
    */
    
    def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
    println consoleLog
    
}

println "errCount = ${errCount}"

println "finished..."

def parseDate(String date) {
    
    if (date == null) {
        return null;
    }

    DateFormat fmtInput = new SimpleDateFormat("yyyy-MM-dd");
    try {
        fmtInput.setTimeZone(TimeZone.getTimeZone("GMT"));
        return fmtInput.parse(date);
    } catch (ParseException e) {
        e.printStackTrace();
    }
    return null;
}
