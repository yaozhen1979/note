/**
 * 依所傳入的檔案, 解析出objectId.
 */
import groovy.time.*

def country = "CN"
def logFile = "CN-log-2015-07-09T11-24-30.txt"

def path = "log_for_docdb_lv1/${logFile}"

File parseFile = new File("log_for_docdb_lv1/parse/${country}_update_tilte.txt") 

println "start parsing..."

def timeStart = new Date()

def ln = System.getProperty('line.separator')

File f = new File(path);

f.withReader("UTF-8") { br ->
    br.eachLine { line -> 
        // println line;
        def dataList = line.split(" - ")[1].split(",")
        // println dataList[0].trim() + "-" + dataList[1].trim()
        parseFile << dataList[1].trim() << ln
        
    }
}

def timeStop = new Date()

TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
println duration
