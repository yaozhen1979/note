import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil
import org.bson.types.ObjectId

def lv2Auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def lv2Client = new GMongoClient(new ServerAddress("127.0.0.1", 27017), [lv2Auth])

def sourceDB = lv2Client.getDB("PatentInfoCNIPR")
def targetDB = lv2Client.getDB("PatentInfoCNIPR")

println "start to backup..."

int count = 0;

def query = [doDate: DateUtil.parseDate("2016-02-17"), kindcode: 'S']

sourceDB.PatentInfoCNIPR.find(query).limit(0).each { data ->
    
    // println "data = " + data
    println "copy data : ${++count}"
    targetDB.WG_DoDate_20160217.save(data)
    
}

// assert patentInfoDOCDB.BackupDOCDB.find().size() == 1

println "finished..."
