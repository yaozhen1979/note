/**
 * 計算 DOCDB Ament && Cr-Del 的數量
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentRawDOCDB = mongoDbClient.getDB("PatentRawDOCDB")

// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-01-01T00:00:00Z"), fileType: 2}).count()

println "start querying..."

// def lv1DataSize = patentRawCNIPR.PatentRawCNIPR.find(doDate: ['$gt' : DateUtil.parseDate("2015-05-26")]).size()
// def amendDataSize = patentRawDOCDB.PatentRawDOCDB.find(docdbDoDate: DateUtils.parseDate("2015-01-01"), fileType: 2).size();

for (def i = 1; i < 31; i++) {
    def queryDate = "2015-6-${i}"
    // println "Date = ${DateUtils.parseDate(queryDate)}"
    def backfileSize = patentRawDOCDB.PatentRawDOCDB.find(docdbDoDate: DateUtils.parseDate(queryDate), fileType: 0).size();
    def createdeleteDataSize = patentRawDOCDB.PatentRawDOCDB.find(docdbDoDate: DateUtils.parseDate(queryDate), fileType: 1).size();
    def amendDataSize = patentRawDOCDB.PatentRawDOCDB.find(docdbDoDate: DateUtils.parseDate(queryDate), fileType: 2).size();
    
    // println "${queryDate} => Backfile Data Size = ${backfileSize} / Amend Data Size = ${amendDataSize} / CreateDelete Data Size = ${createdeleteDataSize}"
    println "${queryDate}\t${amendDataSize}\t${createdeleteDataSize}"
    
}

// println "amendDataSize = $amendDataSize"

println "finished..."