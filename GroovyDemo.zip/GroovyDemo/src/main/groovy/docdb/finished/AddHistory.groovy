/**
 * 增加backfile中的history欄位
 * 
 * 2015.07.14 已完成.
 * 
 */
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.bson.types.ObjectId

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
// def lv2Client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [lv2Auth])

def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

// AM:OK,
def countryList = [
    "AP", "AR", "AT", "AU", 
    "BA", "BE", "BG", "BR", "BY", 
    "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ", 
    "DD", "DE", "DZ", "EA", "EC", "EE", "EG", "EP", "ES"
]

// def countryList = ["AM"]

countryList.each { country ->
    
    def currentSize = 0
    def noExistCount = patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: false]]).count()
    
    println "${country} noExistCount = ${noExistCount}"
    
//    patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: false]]).each { data ->
//        
//        def historyList = []
//        def history = [:]
//        
//        history << ["rawDataId":data.relRawdatas[0]._id]
//        history << ["docdbDoDate":data.docdbDoDate]
//        history << ["status":"B"]
//        
//        historyList << history
//        
//        patentInfoDOCDB.PatentInfoDOCDB.update(
//            [_id: data._id],
//            [$set: [
//                history: historyList
//            ]]
//        );
//        
//        def consoleLog = "${country}._id = ${data._id} are processing update data = ${++currentSize} / ${noExistCount}"
//        println consoleLog
//        
//    }
    
}

//countryList.each { country -> 
//    
//    def existSize = patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: true]]).count()
//    
//    def noExistSize = patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: false]]).count()
//    
//    print "${country} history exists = " + existSize
//    
//    print "\t"
//    
//    print "${country} history no exists= " + noExistSize
//    
//    print "\t"
//    
//    print "total size = " + (noExistSize + existSize) + "\n"
//    
//}

println "finished..."

