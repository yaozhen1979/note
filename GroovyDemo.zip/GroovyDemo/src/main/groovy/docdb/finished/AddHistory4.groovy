// import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.bson.types.ObjectId

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
// def lv2Client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [lv2Auth])

def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

def countryList = ["US"]

countryList.each { country ->
    
    def currentSize = 0
    def noExistCount = patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: false]]).count()
    
    patentInfoDOCDB.PatentInfoDOCDB.find([country: country, history:[$exists: false]]).each { data ->
        
        def historyList = []
        def history = [:]
        
        history << ["rawDataId":data.relRawdatas[0]._id]
        history << ["docdbDoDate":data.docdbDoDate]
        history << ["status":"B"]
        
        historyList << history
        
        // println historyList
        
        patentInfoDOCDB.PatentInfoDOCDB.update(
            [_id: data._id],
            [$set: [
                history: historyList
            ]]
        );
        
        def consoleLog = "${country}._id = ${data._id} are processing update data = ${++currentSize} / ${noExistCount}"
        println consoleLog
        
    }
    
}

println "finished..."

