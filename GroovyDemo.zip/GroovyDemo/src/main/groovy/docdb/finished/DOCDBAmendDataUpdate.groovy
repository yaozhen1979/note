/**
 * 處理 DOCDB Amend data 重複修改時資料錯誤的問題
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')
// File updateFile = new File("log/patentInfoDOCDB-20150101-update-log.txt")

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentRawDOCDB = mongoDbClient.getDB("PatentRawDOCDB")
def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")

println "start updating..."

def currentDataSize = 0;

def query = [_id: new ObjectId("558bfdd4b4411f24f10526eb")]

def totalDataSize = patentInfoDOCDB.PatentInfoDOCDB.count(query)

patentInfoDOCDB.PatentInfoDOCDB.find(query).each{it ->
    
    // _id 
    println "_id = ${it._id}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$unset: [
            history: ['history.docdbDoDate': DateUtil.parseDate("2015-1-1")] 
        ]]
    );
    
    def relRawdatasList = []
    def relRawdatas = [:]
    relRawdatas << it.relRawdatas[0]
    relRawdatasList << relRawdatas
    println "relRawdatas = ${relRawdatasList}"
    
    def tagAndJsfileList = []
    def tagAndJsfile = [:]
    tagAndJsfile << it.tagAndJsfile[0]
    tagAndJsfileList << tagAndJsfile
    println "tagAndJsfileList = ${tagAndJsfileList}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$set: [
            relRawdatas: relRawdatasList,
            tagAndJsfile: tagAndJsfileList
        ]]
    );

    def consoleLog = "_id = ${it._id} are processing update data = ${++currentDataSize} / ${totalDataSize}"

    println consoleLog
    
    // updateFile << consoleLog << ln
    
}

// println "queryDataSize = ${queryDataSize}"

println "finished..."
