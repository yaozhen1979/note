import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')
File updateFile = new File("log/patentInfoDOCDB-20150101-update-log.txt")

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentRawDOCDB = mongoDbClient.getDB("PatentRawDOCDB")
def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")

println "start updating..."

def currentDataSize = 0;
def totalDataSize = patentInfoDOCDB.PatentInfoDOCDB.count(docdbDoDate: DateUtil.parseDate("2015-1-1"), status: [$exists: true])

// US => _id = 55979a3cb4411f24f10c2f98 => 為20150101 cr-del 這一期所新的資料

patentInfoDOCDB.PatentInfoDOCDB.find(country: "IS", status:[$exists:true]).each{it ->
// patentInfoDOCDB.PatentInfoDOCDB.find(_id: new ObjectId("55979a3cb4411f24f10c2f98")).each{it ->

// patentInfoDOCDB.PatentInfoDOCDB.find(docdbDoDate: DateUtil.parseDate("2015-1-1"), status: [$exists: true]).each{it ->
    
    // _id
    // println "_id = ${it._id}"
    
    // status
    // println "status = ${it.status}"
    
    // relRawdatas
    // println "relRawdatas = ${it.relRawdatas}"
    
    // tagAndJsfile
    // println "tagAndJsfile = ${it.tagAndJsfile}"
    
    def statusList = []
    statusList << it.status[0]
    
    // println "test size = ${it.relRawdatas.size()}"
    
    def historyList = []
    if (it.relRawdatas.size() > 1) {
        it.relRawdatas.each { rawData ->
            def history = [:]
            history << [rawDataId: rawData._id]
            history << [docdbDoDate: patentRawDOCDB.PatentRawDOCDB.findOne(_id: rawData._id).docdbDoDate]
            history << [status: 'C']
            //
            historyList << history
        }
    } else {
        
        def history = [:]
        history << [rawDataId: it.relRawdatas[0]._id]
        history << [docdbDoDate: it.docdbDoDate]
        history << [status: 'C']
        //
        historyList << history
    }
    
    // println "historyList = ${historyList}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$set: [
            history: historyList
        ]]
    );

    def consoleLog = "_id = ${it._id} are processing update data = ${++currentDataSize} / ${totalDataSize}"

    println consoleLog
    
    updateFile << consoleLog << ln
    
}

// println "queryDataSize = ${queryDataSize}"

println "finished..."
