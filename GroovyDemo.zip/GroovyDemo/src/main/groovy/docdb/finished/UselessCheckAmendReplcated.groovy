//
//println "checking..."
//
//// docdb_20150101_amend.txt
//File checkFile = new File("log/docdb_20150101_amend.txt");
//
//File replicatedFile = new File("log/replicated_amend_log.txt")
//
//def ln = System.getProperty('line.separator')
//
//// 2015-07-07 12:01:01 (INFO) update PatentInfoDOCDB.id = 558de68fb4411f24f15e04b4
//
//checkFile.eachLine { line -> 
//    //
//    if (line.contains("update PatentInfoDOCDB.id")) {
//        def objectId = line.substring(55).trim()
//        // println "objectId = ${objectId}"
//        
//        def count = 0
//        checkFile.eachLine { innerLine ->
//            if (innerLine.contains(objectId)) {
//                count++;
//            }
//        }
//        if (count > 1) {
//            println "objectId = ${objectId} => replicate ${count}"
//            replicatedFile << objectId << ln
//        }
//        
//    }
//    
//}
//
//println "finished..."