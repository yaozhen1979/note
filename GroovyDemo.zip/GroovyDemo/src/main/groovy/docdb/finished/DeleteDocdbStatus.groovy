/**
 * 處理 LV2 在執行 Cr-Del 時, 所多加的欄位 status && docdbDoDate roll back
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')
// File updateFile = new File("log/patentInfoDOCDB-20150101-update-log.txt")

def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])

//
def patentRawDOCDB = mongoDbClient.getDB("PatentRawDOCDB")
def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")

println "start updating..."

def currentDataSize = 0;

// db.PatentInfoDOCDB.find({ "docdbDoDate": ISODate("2015-01-01T00:00:00Z"), "status": {$exists: true} }).limit(1)
def query = [docdbDoDate: DateUtil.parseDate("2015-1-1"), status: [$exists: true]]

// def query = [_id: new ObjectId("557c7c47b4411f24f1aff6b2")]

def totalDataSize = patentInfoDOCDB.PatentInfoDOCDB.count(query)

println "totalDataSize = ${totalDataSize}"

patentInfoDOCDB.PatentInfoDOCDB.find(query).each{it ->
    
    // _id
    // println "_id = ${it._id}"
    
    // status
    // println "status = ${it.status[0]}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$unset: [
            status: ['status': [$elemMatch: 'C']]
        ]]
    );
    
    // history[0].docdbDoDate
    // println "history[0].docdbDoDate = ${it.history[0].docdbDoDate}"
    
    patentInfoDOCDB.PatentInfoDOCDB.update(
        [_id: it._id],
        [$set: [
            docdbDoDate: it.history[0].docdbDoDate
        ]]
    );

    def consoleLog = "_id = ${it._id} are processing update data = ${++currentDataSize} / ${totalDataSize}"

    println consoleLog
    
    // updateFile << consoleLog << ln
    
}

// println "queryDataSize = ${queryDataSize}"

println "finished..."
