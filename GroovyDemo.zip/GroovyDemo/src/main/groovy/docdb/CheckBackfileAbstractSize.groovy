/**
 * 找出LV1中的資料, 有超過出現一次以上的abstract
 */
import static jodd.jerry.Jerry.jerry as $

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.common.utils.DateUtil
import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Logger logger = LoggerFactory.getLogger(this.class);

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

def country = ""

// def query = [country: country, fileType: 0];

def query = [docdbDoDate: DateUtil.parseDate("2015-1-8"), fileType: 1];

def totalCount = patentRawDOCDB.PatentRawDOCDB.count(query)

def currentSize = 0

def overTwoAbstractSize = 0

def err = []

// logger.info("check ${country} title...");

patentRawDOCDB.PatentRawDOCDB.find(query).each { it ->
    
    def output = it.data.xml
    def dom = $(output)
    
    def abstractSize = dom.find('exch\\:abstract').size()
    
    if (abstractSize > 1) {
        println("${country},${it._id}, abstract data is over 1...");
        overTwoAbstractSize++
        err << it._id
    }
    
    def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
    
    println consoleLog
    
}

println "overTwoAbstractSize = ${overTwoAbstractSize}"
println "err = ${err}"
println "finished..."

