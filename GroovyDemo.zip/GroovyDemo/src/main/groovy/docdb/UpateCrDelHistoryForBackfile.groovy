///**
// * update 2015-01-01 Cr-Del 這一期的 backfile status = 'B'
// * 
// * oneSize = 11
// * twoSize = 98098
// * otherSize = 0
// */
//
//import com.gmongo.GMongoClient
//import com.mongodb.MongoCredential
//import com.mongodb.ServerAddress
//import com.gmongo.GMongo
//import org.common.util.DateUtils
//
//def mongoDbAuth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
//def mongoDbClient = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [mongoDbAuth])
//
////
//def patentInfoDOCDB = mongoDbClient.getDB("PatentInfoDOCDB")
//
//// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-01-01T00:00:00Z"), fileType: 2}).count()
//
//println "start querying..."
//
//def query = ['history.docdbDoDate': DateUtils.parseDate("2015-1-1"), 'history.status': 'B']
//
//def totalCount = patentInfoDOCDB.PatentInfoDOCDB.find(query).count()
//
//def currentSize = 0;
//
//def oneSize = 0
//
//def twoSize = 0
//
//def otherSize = 0
//
//patentInfoDOCDB.PatentInfoDOCDB.find(query).limit(0).each{ it ->
//    
//    // TODO:
//    
//    def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
//    
//    def historyList = []
//    
//    // println "history size = " + it.history.size()
//    
//    if (it.history.size() == 1) {
//        oneSize++
//    } else if (it.history.size() == 2) {
//        
//        twoSize++
//        
//        /*
//        it.history[0].status = 'B'
//        historyList = it.history
//        // println historyList
//        
//        patentInfoDOCDB.PatentInfoDOCDB.update(
//            [_id: it._id],
//            [$set: [
//                history: historyList
//            ]]
//        );
//        */
//        
//    } else {
//        otherSize++
//    }
//    
//    println consoleLog
//    
//}
//
//println "oneSize = ${oneSize}"
//println "twoSize = ${twoSize}"
//println "otherSize = ${otherSize}"
//
//println "finished..."
