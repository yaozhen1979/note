// parse doc/docdb_country.txt to list

File file = new File("doc/docdb_country.txt")

// File file = new File("doc/check_lv1_title_country.txt")

def countryList = []

file.eachLine { line ->
    
    if (line.toString().trim().length() != 0) {
        countryList << "\"${line.toString().trim()}\""
    }
    
}

println countryList.sort()

println "countryList size = ${countryList.size()}"

println "finished..."