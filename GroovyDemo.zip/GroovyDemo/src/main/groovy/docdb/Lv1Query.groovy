// 557b7e05b4411f24f17ab80f
import utils.MongoUtil

import org.bson.types.ObjectId

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentRawDOCDB")

// DE: 5594e37460b28933d0d8e6c9 只有德文title, brief for Cr-Del
// DE: 557b962160b22fd0904ace5e 只有德文title, brief for backfile

// def query = [country:'AM']
def query = [_id: new ObjectId("5575669d96848230b659ce98")]


db.PatentRawDOCDB.find(query).each { it -> 
    println it.data.xml
}

println "count = " + db.PatentRawDOCDB.count(query)

// println "count = " + db.PatentRawDOCDB.find(query << ["regularFlag":true]).count()

println "finished..."
