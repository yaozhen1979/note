// 557b7e05b4411f24f17ab80f
import utils.MongoUtil

import org.bson.types.ObjectId

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentRawDOCDB")

// DE: 5594e37460b28933d0d8e6c9 只有德文title, brief for Cr-Del
// DE: 557b962160b22fd0904ace5e 只有德文title, brief for backfile
db.ErrorPatentRawDOCDB.find().limit(1).each { it ->
    
    println it
    
}

println "finished..."