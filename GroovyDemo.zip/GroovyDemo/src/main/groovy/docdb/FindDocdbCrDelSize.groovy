// 557b7e05b4411f24f17ab80f
import utils.MongoUtil

import org.bson.types.ObjectId
import org.common.utils.DateUtil

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentRawDOCDB")

// DE: 5594e37460b28933d0d8e6c9 只有德文title, brief for Cr-Del
// DE: 557b962160b22fd0904ace5e 只有德文title, brief for backfile

def query = "2015-03-12"

// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-03-26T00:00:00Z"), fileType:1, 'data.xml':{$regex: /status=\"C\"/}}).count();
def createCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"C\"/]])
println "createCount = ${createCount}"

def deleteCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"D\"/]])
println "deleteCount = ${deleteCount}"

println "finished..."
