/**
 * 依傳入的[country list], 找出LV1中的資料, 有超過出現一次以上的title
 */
import static jodd.jerry.Jerry.jerry as $

import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import org.common.utils.DateUtil
import org.bson.types.ObjectId
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

Logger logger = LoggerFactory.getLogger(this.class);

def auth = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [auth])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

// AM => 0
// AP => 0
// IL => 13793
// DE => 800604
// FR => 232789
// ES => 32274
// TW => 0
// WO => 3061742
// US => 0
// EP => 4653405
// CN => 152097
// JP => 8
// KR => 247
// ====================^^^ 已查詢完13國

// 共82個
def countryList = [
    "AR", "AT", "AU", 
    "BE", "BG", "BR", "BY", 
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ", 
    "DD", "DZ", "EA", "EC", "EE", "EG", "FI", "GB", "GC", "GE", "GR", "GT", 
    "HK", "HN", "HR", "HU", "ID", "IE", "IN", "IS", "IT", "JO", "KE", 
    "LT", "LU", "LV", "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX","MY", 
    "NI", "NL", "NO", "NZ", "OA", "PA", "PE", "PH", "PL", "PT", "RO", "RS", "RU", 
    "SE", "SG", "SI", "SK", "SM", "SU", "SV", "TH", "TJ", "TN", "TR", "UA", "UY", 
    "VN", "YU", "ZA", "ZM", "ZW"
]

def ln = System.getProperty('line.separator')

countryList.each { country -> 
    
    File errFile = new File("log_for_docdb_lv1/err_objectId/${country}-err-tilte-objectId.txt")
    File logFile = new File("log_for_docdb_lv1/${country}-log.txt")
    
    def totalCount = patentRawDOCDB.PatentRawDOCDB.count([country: country, fileType: 0])
    
    def currentSize = 0
    
    def overTwoTitleSize = 0
    
    patentRawDOCDB.PatentRawDOCDB.find([country: country, fileType: 0]).each { it ->
        
        def output = it.data.xml
        def dom = $(output)
        
        def titleSize = dom.find('exch\\:invention-title').size()
        
        if (titleSize > 1) {
            
            errFile << it._id << ln
            
            logFile << "${country},${it._id}, title data is over 1..." << ln
            
            overTwoTitleSize++
        }
        
        def consoleLog = "_id = ${it._id} are processing update data = ${++currentSize} / ${totalCount}"
        
        println consoleLog
        
    }
    
    def result = "${country} -> overTwoTitleSize = ${overTwoTitleSize}"
    
    println result
    
    logFile << result << ln
    
} // end countryList.each

println "finished..."
