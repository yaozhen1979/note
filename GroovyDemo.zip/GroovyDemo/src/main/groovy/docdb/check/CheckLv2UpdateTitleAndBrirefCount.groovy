// 102415
// db.PatentInfoDOCDB.find({country:"HK", isUpdateTitleAndBrief:true}).count()
// 246
// db.PatentInfoDOCDB.find({country:"HK", isUpdateTitleAndBrief:{$exists:false}}).count()

import org.apache.commons.io.input.ReversedLinesFileReader;


File file = new File("T:/log/log_for_update_lv2_title_and_abstract/AM_update.log");
int n_lines = 3;
int counter = 0;
ReversedLinesFileReader object = new ReversedLinesFileReader(file);
while(!object.readLine().isEmpty()  && counter < n_lines) {
    System.out.println(object.readLine());
    counter++
}

println "finished..."