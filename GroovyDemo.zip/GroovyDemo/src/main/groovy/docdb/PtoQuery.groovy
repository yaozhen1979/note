/**
 * 查詢 Other Country 中 docdbDoDate 最早和最晚的日期
 */
import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import org.common.utils.DateUtil

// If you are using Mongodb 3.x you need to use MongoCredential#createCredential instead
def credentials = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])

// "10.60.90.101", 27017
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [credentials])

def patentRawDOCDB = client.getDB("PatentRawDOCDB")

def originPto = ["CN", "US", "TW", "KR", "JP", "EP", "WO"]

def otherCountry = ["MX", "MY", "NI", "NL", "NO", "NZ", "OA", 
                    "PA", "PE", "PH", "PL", "PT", "SE", "SG",
                    "SI", "SK", "SM", "SU", "SV", "TH", "TJ",
                    "TN", "TR", "UA", "UY", "VN", "YU", "ZA",
                    "ZM", "ZW"]

def selectCountry = ["DK", "DO"]

println "to start..."

selectCountry.each { it ->
    
    // println "query country = ${it}"
    
    def showInfo = "${it}\t"
    
    patentRawDOCDB.PatentRawDOCDB.find(country:it, fileType:0, docdbDoDate:[$exists:true]).sort(docdbDoDate:1).limit(1).each { data ->
        showInfo += "${DateUtil.toISODateFormat(data.docdbDoDate)}"
    }
    
    showInfo += " - "
    
    patentRawDOCDB.PatentRawDOCDB.find(country:it, fileType:0, docdbDoDate:[$exists:true]).sort(docdbDoDate:-1).limit(1).each { data ->
        showInfo += "${DateUtil.toISODateFormat(data.docdbDoDate)}"
    }
    
    //
    def dataSize = patentRawDOCDB.PatentRawDOCDB.find(country:it, fileType:0).size()
    showInfo += "\t${dataSize}"
    
    println showInfo
}

println "finished"
