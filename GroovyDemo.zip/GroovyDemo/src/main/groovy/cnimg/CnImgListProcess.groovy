import groovy.time.*

def filePathList = ["", "", "", ""]

filePathList.each { filePath ->

    //
    File file = new File(filePath.toString())
    //
    def processCount = 0
    def timeStart = new Date()

    file.eachFile { it ->

        println "processing -> ${it.getPath()}"

        if (it.isDirectory()) {
            // println "path = ${it.getPath()}"
            File fullImageFile = new File("${it.getPath()}\\fullImage")

            // add [fullImage] folder
            if (!fullImageFile.exists()) {
                fullImageFile.mkdir()
            }

            it.eachFile { imgFile ->
                if (imgFile.isFile() && imgFile.name != 'Thumbs.db') {
                    if (imgFile.renameTo(new File(fullImageFile, imgFile.getName()))) {
                        println "${it.name} =  moving img ok..."
                    } else {
                        println "${imgFile.getPath()} moving img no good..."
                    }
                }
            }

            processCount++;

        }

    }

    def timeStop = new Date()
    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

    println "${filePath} duration -> ${duration}"
    println "${filePath} processCount = ${processCount}"

}

println "finished..."
