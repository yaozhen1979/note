import java.nio.file.Files

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

//
def ln = System.getProperty('line.separator')
def type = "WG"
def findDate = "20100804"

def totalCount = 0
def lostFileCount = 0
def noImageFileCount = 0

def destPath = "/mnt/nhdell/patent_cn/data/cn2s/2010/08/04"

File lostFile = new File("diff_log/cn_img/lost_file_${type}_${findDate}.txt")
File noImageFile = new File("diff_log/cn_img/no_image_${type}_${findDate}.txt")

File checkFile = new File("appNumber/${findDate}/sipo-${type}-${findDate.substring(0,4)}.${findDate.substring(4,6)}.${findDate.substring(6,8)}.txt")

// File checkFile = new File("appNumber/20100804/test.txt")

println "start parsing..."

checkFile.each { checkAppNumber ->
    
    println "======================================="
    
    totalCount++
    
    // TODO: WG\20100804\201030100805.6 => 字尾驗證碼如為X, 則可能有大小寫之分, 待處理.
    def appNumber = checkAppNumber.substring(12).trim()
    // println "appNumber = ${appNumber}"
    //
    File imgFile = new File("/home/tony/cnipr/img/data/cn2/2010/08/04/${appNumber}")
    //
    File dest = new File("${destPath}/${appNumber}/")

    if (imgFile.exists()) {
        // println "it exists..."
    } else {
        lostFileCount++
        println "${appNumber} no exists..."
        lostFile << checkAppNumber << ln
    }

    if (imgFile.isDirectory()) {
        // println "it's directory..."
        File fullImageFile = new File("${imgFile.getPath()}/fullImage")
        //
        if (fullImageFile.exists()) {
            //
            def fileCount = 0
            
            fullImageFile.eachFile { imageFile ->
                if (imageFile.exists()) {
                    fileCount++
                }
            }
            if (fileCount == 0) {
                println "[${appNumber}] no imgage file exists"
                noImageFileCount++
                noImageFile << checkAppNumber << ln
            }
            
            if (!dest.exists()) {
                dest.mkdir()
            }
            
            // println "fileCount = ${fileCount}"
            FileUtils.copyDirectory(imgFile, dest)
            println "[${appNumber}] folder copy ok..."
            
        }
    }

}

println "======================================="

println "totalCount = ${totalCount}"
println "lostFileCount = ${lostFileCount}"
println "noImageFileCount = ${noImageFileCount}"

println "finished..."
