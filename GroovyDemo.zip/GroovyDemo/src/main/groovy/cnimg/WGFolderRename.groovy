package cnimg

class WGFolderRename {
    
    static process(String folderPath) {
        
        //  // D:\share\cn_img\WG\3144
        new File(folderPath).eachFile { dir ->
            
            if (!dir.isDirectory()) {
                throw new Exception("${file.name} is not a directory")
            }
            
            if (!dir.name.contains(".")) {
                
                def originName = dir.name
                // println "originName = ${originName}"
                def newName = originName.substring(0, originName.length() - 1) + "." + originName[-1]
                // println "newName = ${newName}"
                
                
                File newDir = new File(dir.getParent() + "/" + newName);
                dir.renameTo(newDir);
                
            } else {
                println "${dir.name} dont need to rename."
            }
            
        }
        
    }
    
    static main(args) {
        
        def pathList = [
            // "/mnt/nhdell/patent_cn/data/cn2s/11/11"
            "D:/share/cn_img/WG/3146"    
        ]
        
        pathList.each { path -> 
            WGFolderRename.process(path)
            println "rename ${path} complete..."
        }
        
    }

}
