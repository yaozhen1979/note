import groovy.time.*

// \\10.60.95.12\patentimg\patent_cn\data\cn1a\2015\05\20

// test => T:\test_img
File file = new File("//10.60.95.12/patentimg/patent_cn/data/cn1a/2015/05/20")
// File file = new File("T://test_img/")

def ln = System.getProperty('line.separator')

def processCount = 0

def timeStart = new Date()

file.eachFile { it ->
    
    println "processing -> ${it.getPath()}"
    
    if (it.isDirectory()) {
        // println "path = ${it.getPath()}"
        File fullImageFile = new File("${it.getPath()}\\fullImage")
        
        // add [fullImage] folder
        if (!fullImageFile.exists()) {
            fullImageFile.mkdir()
        }
        
        it.eachFile { imgFile ->
            if (imgFile.isFile() && imgFile.name != 'Thumbs.db') {
                if (imgFile.renameTo(new File(fullImageFile, imgFile.getName()))) {
                    println "${it.name} =  moving img ok..."
                } else {
                    println "${imgFile.getPath()} moving img no good..."
                }
            }
        }
        
        processCount++;
        
    }
    
}

def timeStop = new Date()
TimeDuration duration = TimeCategory.minus(timeStop, timeStart)

println "duration -> ${duration}"

println "processCount = ${processCount}"

println "finished..."
