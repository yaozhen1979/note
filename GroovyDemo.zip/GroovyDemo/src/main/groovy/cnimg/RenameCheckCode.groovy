File renameList = new File("data/cn2/2010/08/04")

def ln = System.getProperty('line.separator')

renameList.eachFile { file ->
    
    //
    // println file.name.toUpperCase()
    // println file.parent
    // println file.getPath()
    
    // 
    println "rename path = " + file.parent + File.separator + file.name.toUpperCase()
    println "rename -> [${file.name}] to [${file.name.toUpperCase()}] = " + file.renameTo(new File(file.parent + File.separator + file.name.toUpperCase()))
    
}