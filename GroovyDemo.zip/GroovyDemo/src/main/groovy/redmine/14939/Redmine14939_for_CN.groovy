import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo
import com.gmongo.GMongoClient
import utils.MailUtil
import utils.RestTimeProcess

def ln = System.getProperty('line.separator')

def auth = MongoCredential.createMongoCRCredential("patentdata", "admin", "data.cloud.Abc12345" as char[])
def dbClient = new GMongoClient(new ServerAddress("10.60.90.121", 27017), [auth])

def db = dbClient.getDB("PatentInfoCNIPR")

def count = db.PatentInfoCNIPR.count()
RestTimeProcess restTimeProcess = new RestTimeProcess(count, this.class.name)

File fileLog = new File("log/Redmine14939.log")

// def queryMap = [history: [$exists: true]] 
db.PatentInfoCNIPR.find().limit(0).each { it -> 
    
    def history = it.history
    
    if (!!history) {
        fileLog << "history exists, _id = ${it._id}" << ln
        def docdbDoDate = history[-1].docdbDoDate
        db.PatentInfoCNIPR.update([_id: it._id], [$set: [docdbDoDate: docdbDoDate]])
    }
    
    restTimeProcess.process()
    
}

MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "redmine 14939 noticfication", "redmine 14939 - CN update complete")

println "finished..."


