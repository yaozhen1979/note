def strippedFirstNewline = '''\
line one
line two
line three
'''

println strippedFirstNewline

assert !strippedFirstNewline.startsWith('\n')


println "The Euro currency symbol: \u20AC"

println "\u5B9F\u7528\u65B0\u6848"

println "\u610F\u5320\u516C\u5831"