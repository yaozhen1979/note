@Grab(group='com.gmongo', module='gmongo', version='1.5')
@Grab(group='org.codehaus.groovy.modules.http-builder', module='http-builder', version='0.7.1')
@Grab(group='org.jodd', module='jodd-lagarto', version='3.6.6')

import groovyx.net.http.HTTPBuilder
import org.apache.http.auth.*

// System.properties << [ 'http.proxyHost':'10.60.94.22', 'http.proxyPort':'3128' ]
// System.properties << [ 'http.proxyHost':'10.60.94.21', 'http.proxyPort':'3128', 'http.proxyUser':'docker', 'proxyPassword':'Abc.2015' ]

def http = new HTTPBuilder('http://apod.nasa.gov/apod/astropix.html')
http.client.getCredentialsProvider().setCredentials(
    new AuthScope("10.60.94.21", 3128),
    new UsernamePasswordCredentials("docker", "Abc.2015")
)
http.setProxy('10.60.94.21', 3128, 'http')

// String html = 'http://apod.nasa.gov/apod/astropix.html'.toURL().text

http.request( GET, TEXT ){ req ->
    response.success = { resp, reader ->
        println "Response: ${reader.text}"
    }
}

println html
