import com.gmongo.GMongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.gmongo.GMongo

// If you are using Mongodb 3.x you need to use MongoCredential#createCredential instead
def credentials = MongoCredential.createCredential('patentdata', 'admin', 'data.cloud.Abc12345' as char[])

// "10.60.90.101", 27017
def client = new GMongoClient(new ServerAddress("10.60.90.101", 27017), [credentials])

def patentInfoDOCDB = client.getDB("PatentInfoDOCDB")

def originPto = ["CN", "US", "TW", "KR", "JP", "EP", "WO"]

// def collectionSize = patentInfoDOCDB.getCollection("PatentInfoDOCDB").find().size()

def collectionSize = patentInfoDOCDB.PatentInfoDOCDB.find(country:'EP').size()
println "count = " + collectionSize

patentInfoDOCDB.PatentInfoDOCDB.find(country:'CN').sort(doDate:1).limit(1).each { it -> 
   println "country = ${it.country}, doDate = ${it.doDate}"
}

// println "queryData = " + queryData._id

println "country size = " + patentInfoDOCDB.PatentInfoDOCDB.distinct("country").size()

patentInfoDOCDB.PatentInfoDOCDB.distinct("country").each { it -> 
    // println "country = ${it}"
}

println "finished"