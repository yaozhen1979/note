/*
* Copyright 2010 Srikanth Reddy Lingala  
* 
* Licensed under the Apache License, Version 2.0 (the "License"); 
* you may not use this file except in compliance with the License. 
* You may obtain a copy of the License at 
* 
* http://www.apache.org/licenses/LICENSE-2.0 
* 
* Unless required by applicable law or agreed to in writing, 
* software distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
* See the License for the specific language governing permissions and 
* limitations under the License. 
*/

package zip4j;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

import groovy.io.FileType
import net.lingala.zip4j.core.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.io.ZipInputStream;
import net.lingala.zip4j.model.FileHeader
import net.lingala.zip4j.unzip.UnzipUtil;

/**
 * Lists all the files in a zip file including the properties of the file
 * @author Srikanth Reddy Lingala
 *
 */
public class ListAllFilesInZipFile {
    
    static listZipFiles(String path) {
        
        try {
            
            ZipFile zipFile = new ZipFile(path);
            
            // Get the list of file headers from the zip file
            List fileHeaderList = zipFile.getFileHeaders();
            
            // Loop through the file headers
            for (int i = 0; i < fileHeaderList.size(); i++) {
                
                FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
                
                if (fileHeader.getFileName().contains("-CH-")) {
                    
                    println "path = ${path}, file name = ${fileHeader.getFileName()}"
                    //
                }
                
//                System.out.println("****File Details for: " + fileHeader.getFileName() + "*****");
//                System.out.println("Name: " + fileHeader.getFileName());
//                System.out.println("Compressed Size: " + fileHeader.getCompressedSize());
//                System.out.println("Uncompressed Size: " + fileHeader.getUncompressedSize());
//                System.out.println("CRC: " + fileHeader.getCrc32());
//                System.out.println("************************************************************");

            }
            
        } catch (ZipException e) {
            e.printStackTrace();
        }
        
    }
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
        // 
        // String path = "T:/docdb/data/Cr-Del/2015/01/docdb_xml_201501_CreateDelete_001.zip"
        
        def dir = new File("T:/docdb/data/Amend/2015/")
        dir.eachFileRecurse(FileType.FILES) { file ->
            if (file.name.toUpperCase().endsWith(".ZIP")) {
                listZipFiles(file.getAbsolutePath())
            }
        }
        
        // listZipFiles(path)
        
        println "finished..."
	}

}
