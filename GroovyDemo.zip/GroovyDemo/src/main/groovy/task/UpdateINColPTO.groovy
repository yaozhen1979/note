import utils.MongoUtil

import org.bson.types.ObjectId

import org.common.utils.DateUtil

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

import java.text.SimpleDateFormat;
import org.common.utils.DateUtil

println "to start..."

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def patentInfoIN = client.getDB("PatentInfoIN")

def totalCount = patentInfoIN.PatentInfoIN.count()
def current = 0

patentInfoIN.PatentInfoIN.find().limit(0).each { it ->
    
    patentInfoIN.PatentInfoIN.update([_id: it._id], [$set: [pto: 'IN']])
    
    println "process ${++current} / ${totalCount}"
    
}

println "finished..."
