def bySecond = timestamp("yyyy-MM-dd'T'HH-mm-ss")

appender("CONSOLE", ConsoleAppender) {
    encoder(PatternLayoutEncoder) { pattern = "%date [%thread] %-5level %logger{36} - %msg%n" }
}

appender("FILE", FileAppender) {
    file = "log_for_docdb_lv1/log-${bySecond}.txt"
    encoder(PatternLayoutEncoder) { pattern = "%date [%thread] %-5level %logger{36} - %msg%n" }
}

// root(DEBUG, ["FILE"])

root(INFO, ["CONSOLE", "FILE"])
