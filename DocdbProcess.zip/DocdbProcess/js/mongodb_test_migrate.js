/**
mongo --nodb mongodb_test_migrate.js --eval "q='19960301 19960331';user='cGF0ZW50ZGF0YQ==';password='ZGF0YS5jbG91ZC5BYmMxMjM0NQ==';mongo_src_ip='10.60.90.121';mongo_tar_ip='10.60.90.155';col_name='PatentInfoTIPO'"
eval 後面接帶入參數
user : 使用者
password : 密碼
q : 日期起迄
mongo_src_ip : 複製來源 DB ip
mongo_tar_ip : 複製目的地 DB ip
col_name : 複製的 collection 名稱
*/
;(function() {
	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/verifyPatentInfoFieldType.js");
	} catch(e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":", "[ERROR] Please run script in mongoutil directory");
		return;
	}

	var colsrc;
	var coltar;
	var dbsrc;
	var dbtar;
	var query;
	var mongodb;
	coltar = col_name;
	colsrc = col_name;
	dbtar = new Mongo(mongo_tar_ip).getDB("admin");
    dbsrc = new Mongo(mongo_src_ip).getDB("admin");
	
	dbtar.auth(BASE64.decode(user),BASE64.decode(password));
	dbsrc.auth(BASE64.decode(user),BASE64.decode(password));
	
	dbtar=dbtar.getSisterDB(coltar);
	dbsrc=dbsrc.getSisterDB(colsrc);
	
	query = parse_q_for_doDate(q);
	printlog("parsing", colsrc, "to", coltar, "in 5 seconds", tojsonObject(query));
	sleep(2000);

	initPatentCol({
		db: dbtar,
		col: coltar
	});

	printlog("counting total documents ...");
	initDebugProcess({
		maxCount: dbsrc[colsrc].find(query).count()
	});

	
			
	printlog("starting migrate from " + mongo_src_ip + " to " + mongo_tar_ip);
	
	dbsrc[colsrc].find(query).sort({doDate: 1}).forEach(function(doc) {
		try {			
			dbtar.getCollection(col_name).save(doc);
		}catch(e){
			printlog("Error : " + e);
		}
		
		debugProcess(doc);
	});
	
	printlog("migrate finish");
})();
