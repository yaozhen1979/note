/*
執行指令 mongo --nodb mongodb_test_merge.js ,因為101是Mongo3.0 所以必須執行3.0以上的mongo.exe
*/
;
(function() {
	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/docdbMergeUtil.js");
	} catch (e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":", "[ERROR] Please run script in mongoutil directory");
		return;
	}

	//argv
	var q = '2014 2015'; //2 : 日期起迄
	// var ac = 'patentdata'; //3 : 使用者
	// var pd = 'data.cloud.Abc12345'; //4 : 密碼
	var ac = 'cGF0ZW50ZGF0YQ=='; //3 : 使用者
	var pd = 'ZGF0YS5jbG91ZC5BYmMxMjM0NQ=='; //4 : 密碼
	var mongo_src_ip = '10.60.90.101'; //5 : 合併來源 DB ip
	var mongo_tar_ip = '10.60.90.121'; //6 : 合併目的地 DB ip
	var country = 'US';
	var jsFile = 'docdb_merge.js';
	var tag = 'v0.1.0';

	var argv = ["", "", q, ac, pd, mongo_src_ip, mongo_tar_ip, country, jsFile, tag];

	// TODO: 可改由讀取設定檔
	var setting = docdbMergeUtil.initSettingData(argv);

	printlog(tojsonObject(setting));

	var tardb = new Mongo(setting.tarIp).getDB("admin");
	var srcdb = new Mongo(setting.srcIp).getDB("admin");

	tardb.auth(BASE64.decode(setting.ac), BASE64.decode(setting.pd));
	srcdb.auth(BASE64.decode(setting.ac), BASE64.decode(setting.pd));

	tardb = tardb.getSisterDB(setting.colTarName);
	srcdb = srcdb.getSisterDB(setting.colSrcName);

	printlog("merge from ", setting.colSrcName, "to", setting.colTarName, "in 2 seconds", tojsonObject(setting.query));
	sleep(2000);

	printlog("counting total documents ...");
	initDebugProcess({
		maxCount: srcdb[setting.colSrcName].find(setting.query).count()
	});

	var errorCnt = 0;
	srcdb[setting.colSrcName]
	.find(setting.query)
	.sort({doDate:1})
	.limit(0)
	.addOption(DBQuery.Option.noTimeout)
	.forEach(function(srcResult) {

		var tarQuery = docdbMergeUtil.query(srcResult);

		// printlog("tarQuery: "+ tojsonObject(tarQuery));

		setting.pto = srcResult.pto;

		var tarCursor = tardb[setting.colTarName].find(tarQuery).addOption(DBQuery.Option.noTimeout);
		var updateInfo = docdbMergeUtil.updateInfoPTO(tarCursor, srcResult, setting, tarQuery);

		var errDoc = initErrDoc(updateInfo.errMsg);

		if (countJSONSize(errDoc.msg) !== 0) {
			errorCnt++;

			errDoc.doc = updateInfo.errDoc;
			//errorCollection add Jsfile and Tag
			saveTagAndJsfile(errDoc, setting.tag, setting.jsFile);
			printlog("errDoc: " + tojsonObject(errDoc));

			srcdb[setting.errCollection].update({
				"doc._id": errDoc.doc._id,
				"errHandle": false
			}, errDoc, {
				upsert: true
			});

		} else {
			//已經刷過,跳過
			if (updateInfo.hasMerged) {
				printlog("already merged: " + updateInfo.tarDoc._id);
			} else {
				var queryId = {
					"_id": updateInfo.tarDoc._id
				};
				// printlog("tarDoc: " + tojsonObject(updateInfo.tarDoc));

				tardb[setting.colTarName].update(queryId, updateInfo.tarDoc);
			}
		}


		debugProcess(srcResult);
	});

	printlog("merge finish! Total error count : " + errorCnt);

})();