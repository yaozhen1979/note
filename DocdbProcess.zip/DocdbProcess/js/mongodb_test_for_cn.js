;(function() {

    try {
        load("lib/base.js");
        load("lib/EncodeUtil.js");
        load("lib/verifyPatentInfoFieldType.js");
    } catch (e) {
        print(new Date().format("mm-dd HH:MM:ss"), ":",
                "[ERROR] Please run script in mongoutil directory");
        return;
    }
    
    var sourceIp = "10.60.90.155";
    var targetIp = "10.60.90.155";
    
    var userName = "cGF0ZW50ZGF0YQ==";
    var userPwd = "ZGF0YS5jbG91ZC5BYmMxMjM0NQ==";
    
    // MongoDB Source collection name
    var colsrc = "PatentRawDOCDB";
    // MongoDB Target collection name
    var coltar = "PatentInfoDOCDB";
    
    var dbsrc = new Mongo(sourceIp).getDB("admin");
    var dbtar = new Mongo(targetIp).getDB("admin");
    
    var query;

    /** 加密 */
    // dbtar.auth(BASE64.decode("cGF0ZW50ZGF0YQ=="),BASE64.decode("ZGF0YS5jbG91ZC5BYmMxMjM0NQ=="));
    // dbsrc.auth(BASE64.decode("cGF0ZW50ZGF0YQ=="),BASE64.decode("ZGF0YS5jbG91ZC5BYmMxMjM0NQ=="));
    /** 明文 */
    // dbtar.auth("patentdata","data.cloud.Abc12345");
    // dbsrc.auth("patentdata","data.cloud.Abc12345");
    dbtar.auth(BASE64.decode(userName), BASE64.decode(userPwd));
    dbsrc.auth(BASE64.decode(userName), BASE64.decode(userPwd));

    dbtar = dbtar.getSisterDB(coltar);
    dbsrc = dbsrc.getSisterDB(colsrc);

    // query =
    // {path:"1988/1988B/EPRTBJV1988000001001001/DOC/EPNWB1/EP82850254NWB1"};
    
    /** 
     * 查詢專利條件
     * "parameter option 'q', like: '2005' or '2005-01-01' or '2005-01-01 2008'
     * 
     */
    query = parse_q_for_docdbDoDate('2014', 'CN');
    
    // mongo --nodb MongoParseRawEPO.js --eval "q='19980101'"
    // query = {path:"XEPA2015010/DOC/EPNWA1/000/000/002/842/943"};
    printlog("parsing", colsrc, "to", coltar, "in 1 seconds",
            tojsonObject(query));
    
    // TODO: why sleep 5s ???
    sleep(1000);

    // 初始化
    initPatentCol({
        db : dbtar,
        col : coltar
    });

    printlog("counting total documents ...");

    /** TODO: 查詢資料數量 => how to use ??? */
    initDebugProcess({
        maxCount : dbsrc[colsrc].find(query).count()
    });
    
    printlog('maxCount = ' + dbsrc[colsrc].find(query).count())

    /** 生成欄位且存取相對應的值 ??? */
    function updateField(doc, field, value) {
        if (value === undefined) {
            delete doc[field];
        } else {
            doc[field] = value;
        }
    }

    /**
     * 對EPO 日期進行處理，處理后變成正規的日期格式 
     * 
     * TODO: 對docdb有需要 ???
     * 
     * @param {epoDate}
     */
    function formatDate(epoDate) {
        //
        var year = "";
        var month = "";
        var day = "";
        if (epoDate.match(/^\d{8}$/)) {
            year = epoDate.substring(0, 4);
            month = epoDate.substring(4, 6);
            day = epoDate.substring(6, 8);
        }
        
        return todate(year + "-" + month + "-" + day);
    }

    printlog("starting parse");
    
    // 檢索出來的結果, 按照docdbDoDate升序排列, 依次解析每篇專利
    // TOOD: 有必要排序 ???
    /*
    dbsrc[colsrc].find(query).sort({docdbDoDate : 1}).forEach(function(doc) {
        var xml = doc.data.xml;
        // printlog(xml);
    });
    */
    
    // regx pattern
    var invention_title_regex = /<exch:invention-title[\s\S]*>[\s\S]*<\/exch:invention-title>/;
    var family_id_regex = /family-id=\"[\w]+\"/;
    var kind_code_regex = /(?:kind=)("[^"]*"|^[^"]*$)/;
    var country_regex = /(?:country=)("[^"]*"|^[^"]*$)/;
    var abstract_regex = /<exch:abstract[\s\S]*?>[\s\S]*<\/exch:abstract>/;
    var appNo_regex = /<exch:application-reference data-format="original">[\s\S]*?<\/exch:application-reference>/;
    var do_date_regex = /(?:date-publ=)("[^"]*"|^[^"]*$)/;
    var language_regex = /<exch:language-of-publication>[\s\S]*?<\/exch:language-of-publication>/;
    
    // 取得<tag>XXX</tag>中的前後tag
    var tag_text_regex = /(<([^>]+)>)/g;
    // 取得包含雙引號和其中之值, 如"ABC"
    var double_quotes_regex = /(?:"[^"]*"|^[^"]*$)/;

    dbsrc[colsrc].find(query).forEach(function(doc) {
        
        printlog("doc.id = " + doc._id);
        
        var xml = doc.data.xml;
        // printlog(xml);
        
        // get title 
        var titleTag = String(xml.match(invention_title_regex));
        // printlog(typeof titleTag);
        var title = titleTag.replace(tag_text_regex, '');
        printlog('title = ' + title)
        
        // get familyId
        var familyIdTag = String(xml.match(family_id_regex));
        // printlog('familyIdTag = ' + familyIdTag.length);
        var familyId = familyIdTag.match(double_quotes_regex)[0].replace(/"/g, "");
        printlog("family_id = " + familyId);
        
        // get kind code
        var kindcode = xml.match(kind_code_regex)[0].match(double_quotes_regex)[0].replace(/"/g, "");
        printlog("kindcode = " + kindcode)
        
        // get country
        var country = xml.match(country_regex)[0].match(double_quotes_regex)[0].replace(/"/g, "");
        printlog("country = " + country);
        
        // get patent number => 為抓取docdb中的格式. => 查詢CN時, 則應以['CN' + patentNumber + kindcode]來查詢公布\公告號
        var patentNumber = xml
            .match(/<exch:publication-reference data-format="docdb">[\s\S]*?<\/exch:publication-reference>/)[0]
            .match(/<doc-number>[\s\S]*?<\/doc-number>/)[0]
            .replace(tag_text_regex, '');
        printlog("patentNumber = " + patentNumber);
        
        // get abstract
        var abstract;
        if (xml.match(abstract_regex) !== null) {
            abstract = xml
                .match(abstract_regex)[0]
                .replace(tag_text_regex, '').trim();
            printlog("abstract = " + abstract);
        } else {
            printlog("abstract miss");
        }
        
        /** 
         *  get app no => ex: [201320732798.X] 但資料如有[201320732798X]時也可查到資料.
         *  => 抓取<exch:application-reference data-format="original">中的<doc-number>
         */ 
        var appNo;
        if (xml.match(appNo_regex) !== null) {
            appNo = xml
                .match(appNo_regex)[0]
                .replace(tag_text_regex, '').trim();
            printlog("appNo = " + appNo);
        }
        
        // TODO: 由kind code來判斷[公開號/公告號], 目前僅先判斷 2001/01/02之後的資料
	    var stat = 0;
	    if (kindcode.charAt(0) === 'A') {
	    	// 表為公開
	    	stat = 1;
	    } else {
	    	// 表為公告
	    	stat = 2;
	    }
	    printlog("stat = " + stat);
        
        // get doDate
        var doDate;
        if (xml.match(do_date_regex) !== null) {
            doDate = xml
                .match(do_date_regex)[0]
                .match(double_quotes_regex)[0].replace(/"/g, "");
            printlog("doDate = " + doDate);
        }
        
        // 確認[PatentInfoDOCDB]是否存在 ???
        var doc2 = getPatentInfo(dbtar, {
            pto : "DOCDB",
            patentNumber : patentNumber,
            kindcode : kindcode
        }) || {
            pto : "DOCDB",
            patentNumber : patentNumber,
            kindcode : kindcode,
            mongoSyncFlag : {
                init : new Date(),
                basicInfo : new Date()
            }
        };
        // printlog(tojsonObject(doc2));
        
        //
        if (title != undefined && title.trim().length !== 0) {
            title = {
                "origin" : title
            }
            updateField(doc2, "title", title);
        } else {
            // throw "title miss";
            printlog("title miss");
        }
        
        // 
        if (familyId != undefined && familyId.trim().length !== 0) {
        	familyId = (familyId === 'null' ? 0 : familyId);
			updateField(doc2, "familyId", tolong(familyId));
        } else {
            // throw "family miss";
            printlog("family miss");
        }
        
        // country 在現有的 level2 db scheam 中並沒有.
        if (country != undefined && country.trim().length !== 0) {
            updateField(doc2, "country", country);
        } else {
            // throw "country miss";
            printlog("country miss");
        }
        
        // abstract
        if (abstract != undefined && abstract.trim().length !== 0) {
            abstract = {
                "origin" : abstract
            }
            updateField(doc2, "brief", abstract);
        } else {
            // throw "abstract miss";
            printlog("abstract miss");
        }
        
        // appNo 
        if (appNo != undefined && appNo.trim().length !== 0) {
            updateField(doc2, "appNumber", appNo);
        } else {
            // throw "appNo miss";
            printlog("appNo miss");
        }
        
        // stat
        if (stat === 1) {
            updateField(doc2, "openNumber",
                    patentNumber);
            updateField(doc2, "decisionNumber");
        } else if (stat === 2) {
            updateField(doc2, "openNumber");
            updateField(doc2, "decisionNumber",
                    patentNumber);
        } else {
            // throw "this data has problem."
            printlog("this data has problem.");
        }
        
        updateField(doc2, "stat", toint(stat));
        
        //
        if (doDate != undefined && doDate.trim().length !== 0) {
            updateField(doc2, "doDate", todate(doDate));
            // docdbDoDate
            updateField(doc2, "docdbDoDate", doc.docdbDoDate);
        } else {
            // throw "doDate miss";
            printlog("doDate miss");
        }
        
        // 
        printlog(tojsonObject(doc2));
        
        saveRelRawdatas(doc2, doc);
        
        doc2.mongoSyncFlag.last = new Date();
        
        dbtar[coltar].save(doc2);
        
    });
    
    
})();
