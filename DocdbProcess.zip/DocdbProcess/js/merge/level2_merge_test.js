;(function() {

	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/verifyPatentInfoFieldType.js");
	} catch(e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":", "[ERROR] Please run script in mongoutil directory");
		return;
	}

	var colsrc;
	var coltar;
	var dbsrc;
	var dbtar;
	var query;
	var mongodb;
	coltar = "PatentInfoUSPTO";//
	colsrc = "PatentInfoDOCDB";
	dbtar = new Mongo(mongo_tar_ip).getDB("admin");
    dbsrc = new Mongo(mongo_src_ip).getDB("admin");
	
	dbtar.auth(BASE64.decode(user),BASE64.decode(password));
	dbsrc.auth(BASE64.decode(user),BASE64.decode(password));
	
	dbtar=dbtar.getSisterDB(coltar);
	dbsrc=dbsrc.getSisterDB(colsrc);

	query = parse_q_for_doDate(/*queryDate*/);
	printlog("parsing", colsrc, "to", coltar, "in 5 seconds", tojsonObject(query));
	sleep(2000);

	initPatentCol({
		db: dbtar,
		col: coltar
	});

	printlog("counting total documents ...");
	initDebugProcess({
		maxCount: dbsrc[colsrc].find(query).count()
	});

	function updateField(doc, field, value) {
		if (value === undefined || value == null) {
			delete doc[field];
		} else {
			doc[field] = value;
		}
	}

	function normalizeIPC(doc, pc) {
		var mat = pc.trim().match(/^(\S{4})[\s\-]*(\S+)[\/:](\S+)([\s\.]\S+)?$/);
		if (mat) {
			if (mat[4]) {
				return mat[1] + " " + mat[2] + "/" + mat[3] + mat[4];
			} else {
				return mat[1] + " " + mat[2] + "/" + mat[3];
			}
		} else {
			logErrorDoc({
				db: dbsrc,
				col: "Error" + colsrc,
				msg: {
					msg:"invalid PC",
					pc: pc
				},
				doc: doc
			});
			return pc;
		}
	}
	
	//�N20000101���ɶ��榡�ഫ��2000-01-01
	
	function dateFormat(date){
		var r=date.substr(0,4)+"-"+date.substr(4,2)+"-"+date.substr(6,2);
		return r;
	}
	
	function normalizePriority(mat) {
 		if(mat) {
			var pto,patentNumber,kindcode;
			if(mat.match(/<country>([\s\S]*?)<\/country>/)) pto = mat.match(/<country>([\s\S]*?)<\/country>/)[1];
			if(mat.match(/<doc-number>([\s\S]*?)<\/doc-number>/))  patentNumber= mat.match(/<doc-number>([\s\S]*?)<\/doc-number>/)[1];
 			if(mat.match(/<kind>([\s\S]*?)<\/kind>/)) kindcode=  mat.match(/<kind>([\s\S]*?)<\/kind>/)[1];	
		//�Ϭd�u���v���
		    var doc = searchPatentInfo({
					pto : pto,
					patentNumber : patentNumber,
					kindcode : kindcode,
				});
		return doc;
		}
	}
	function searchPatentInfo(pat){
		switch(pat.pto){
			case "USPTO":
			case "US":
			case "TIPO":
			case "TW":
			case "JPO":
			case "JP":
				var dbsearch=mongodb.getDB("PatentInfo"+pat.pto);
				if(!pat.patentNumber){
					return pat;
				}else{
					return getPatentInfo(dbsearch,{
						pto: mapPtos[pat.pto],
						patentNumber: pat.patentNumber
					})||pat;
				}
			case "CNIPR":
			case "CN":
			case "KIPO":
			case "KR":
				var dbsearch=mongodb.getDB("PatentInfo"+pat.pto);
				if(!pat.patentNumber||!pat.stat){
					return pat;
				}else{
					return getPatentInfo(dbsearch,{
						pto:mapPtos[pat.pto],
						patentNumber:pat.patentNumber,
						
					})||pat;
				}
			case "EPO":
			case "EP":
			case "WIPO":
			case "WO":
			case "DPMA":
			case "DE":
			case "INPI":
			case "FR":
				var dbsearch = mongodb.getDB("PatentInfo"+pat.pto);
				if(!pat.patentNumber||!pat.kindcode){
					return pat;
				}else{
					return getpatentInfo(dbsearch,{
						pto:mapPtos[pat.pto],
						patentNumber:pat.patentNumber,
						kindcode:pat.kindcode
					})||pat;
				}
				default:
				return pat;
				break;
		}
	}
			var mapPtos={
				EP:"EPO",
				JP:"JPO",
				US:"USPTO",
				KR:"KIPO",
				CN:"CNIPR",
				DE:"DPMA",
				FR:"INPI",
				CH:"IGE",
				GB:"UGIPO",
				AU:"AU",
				TW:"TIPO",
				SG:"SG",
				OHIM:"OHIM",
				WO:"WIPO",
				KH:"KH"
			};
			
	printlog("starting merge from " + mongo_src_ip + " to " + mongo_tar_ip);

	function getPN(country, docPn) {
		var patentNumber;
		if (country == 'US') {
				if(docPn.match(/D0*[1-9]\d+/)){
					patentNumber = "US0" + docPn.match(/D(0*)[1-9]\d+/)[1]+"D" + docPn.match(/D0*([1-9]\d+)/)[1];
				}else if(docPn.match(/RE0*[1-9]\d+/)){
					patentNumber = "US0" + docPn.match(/RE(0*)[1-9]\d+/)[1]+"RE" + docPn.match(/RE0*([1-9]\d+)/)[1];
				}else if(docPn.match(/H0*[1-9]\d+/)){
					patentNumber = "US0" + docPn.match(/H(0*)[1-9]\d+/)[1]+"H" + docPn.match(/H0*([1-9]\d+)/)[1];
				}else if(docPn.match(/PP0*[1-9]\d+/)){
					patentNumber = "US0" + docPn.match(/PP(0*)[1-9]\d+/)[1]+"PP" + docPn.match(/PP0*([1-9]\d+)/)[1];
				}else if(docPn.match(/^\d{8}$/)){
					patentNumber = "US0" + docPn;
				}else if(docPn.match(/^\d{7}$/)){
					patentNumber = "US00" + docPn;
				}else if(docPn.match(/^\d{11}$/)){
					patentNumber = docPn;
				}else{
					throw "No PatentNumber or PatentNumber is not available";
				}
			}
			return patentNumber;
	}
	//dbsrc : DOCDB LV2 
	dbsrc[colsrc].find(query).sort({doDate: 1}).forEach(function(doc) {
		function log(msg) {
			logErrorDoc({
				db: dbsrc,
				col: "Error" + colsrc,
				msg: msg,
				doc: doc,
				console: true
			});
		}

		try {			
			var patentNumber = getPN(doc.country, doc.patentNumber);
			var cursor = dbtar[coltar].find(
							{'patentNumber': patentNumber},
							{'doDate' : doc.docDate},
							{'kindcode' : doc.kindcode},
							{"appNumber" : doc.appNumber});
							
			if (cursor.hasNext()) {
				var data = cursor.next();

				var title = undefined;
				title = {
					"en": doc.title
				}
				updateField(data, 'title', title);
				
				var brief = undefined;
				brief = {
					"en": doc.brief
				}
				updateField(data, 'brief', brief);
				
				updateField(data, 'family', doc.family);
				updateField(data, 'country', doc.country);
				updateField(data, 'docdbDoDate', doc.docdbDoDate);	
				
				dbtar[coltar].save(data);
			} else {
				printlog("query: patentNumber " + doc.patentNumber 
				+  "doDate" + doc.doDate
				+  "kindcode" + doc.kindcode
				+  "appNumber" + doc.appNumber
				+ " not found");
			}
			
			
			
		}catch(e){
			log(e);
		}
		
		debugProcess(doc);
	});
	
	printlog("merge finish");
})();
