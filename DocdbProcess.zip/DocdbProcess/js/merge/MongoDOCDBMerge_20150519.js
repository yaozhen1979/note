/**
mongo --nodb MongoDOCDBMerge.js --eval "q='20140514 20140515';user='cGF0ZW50ZGF0YQ==';password='ZGF0YS5jbG91ZC5BYmMxMjM0NQ==';mongo_src_ip='10.60.90.155';mongo_tar_ip='127.0.0.1';col_tar_name='PatentInfoCNIPR'"
eval 後面接帶入參數
user : 使用者
password : 密碼
q : 日期起迄
mongo_src_ip : 合併來源 DB ip
mongo_tar_ip : 合併目的地 DB ip
col_tar_name : 合併目的地 collection 名稱
*/
;(function() {
	try {
		load("lib/base.js");
		load("lib/EncodeUtil.js");
		load("lib/verifyPatentInfoFieldType.js");
	} catch(e) {
		print(new Date().format("mm-dd HH:MM:ss"), ":", "[ERROR] Please run script in mongoutil directory");
		return;
	}

	var colsrc;
	var coltar;
	var dbsrc;
	var dbtar;
	var query;
	var mongodb;
	coltar = col_tar_name;//
	colsrc = "PatentInfoDOCDB";
	dbtar = new Mongo(mongo_tar_ip).getDB("admin");
    dbsrc = new Mongo(mongo_src_ip).getDB("admin");
	
	dbtar.auth(BASE64.decode(user),BASE64.decode(password));
	dbsrc.auth(BASE64.decode(user),BASE64.decode(password));
	
	dbtar=dbtar.getSisterDB(coltar);
	dbsrc=dbsrc.getSisterDB(colsrc);

	query = parse_q_for_doDate(/*queryDate*/);
	printlog("parsing", colsrc, "to", coltar, "in 5 seconds", tojsonObject(query));
	sleep(2000);

	initPatentCol({
		db: dbtar,
		col: coltar
	});

	printlog("counting total documents ...");
	initDebugProcess({
		maxCount: dbsrc[colsrc].find(query).count()
	});

	function updateField(doc, field, value) {
		if (value === undefined) {
			delete doc[field];
		} else {
			doc[field] = value;
		}
	}

	/*
	function getPN(country, docPn) {
		var patentNumber;
		if (country == 'US') {
			if(docPn.match(/D0*[1-9]\d+/)){
				patentNumber = "US0" + docPn.match(/D(0*)[1-9]\d+/)[1]+"D" + docPn.match(/D0*([1-9]\d+)/)[1];
			}else if(docPn.match(/RE0*[1-9]\d+/)){
				patentNumber = "US0" + docPn.match(/RE(0*)[1-9]\d+/)[1]+"RE" + docPn.match(/RE0*([1-9]\d+)/)[1];
			}else if(docPn.match(/H0*[1-9]\d+/)){
				patentNumber = "US0" + docPn.match(/H(0*)[1-9]\d+/)[1]+"H" + docPn.match(/H0*([1-9]\d+)/)[1];
			}else if(docPn.match(/PP0*[1-9]\d+/)){
				patentNumber = "US0" + docPn.match(/PP(0*)[1-9]\d+/)[1]+"PP" + docPn.match(/PP0*([1-9]\d+)/)[1];
			}else if(docPn.match(/^\d{8}$/)){
				patentNumber = "US0" + docPn;
			}else if(docPn.match(/^\d{7}$/)){
				patentNumber = "US00" + docPn;
			}else if(docPn.match(/^\d{11}$/)){
				patentNumber = docPn;
			}else{
				throw "No PatentNumber or PatentNumber is not available";
			}
		}
		return patentNumber;
	}
	*/
	
	/**
	* 轉換appNumber
	*/
	function getAN(country, docAppNo) {
		
		var appNo = "";
		if (country == 'CN') {
			appNo = docAppNo.substring(0,docAppNo.length-1) + '.' + docAppNo.substring(docAppNo.length-1)
		} else {
			appNo = docAppNo;
		}
		return appNo;
	}
	
	//dbsrc : PatentInfoDOCDB 
	dbsrc[colsrc].find(query).limit(1).sort({doDate: 1}).forEach(function(doc) {
		function log(msg) {
			logErrorDoc({
				db: dbsrc,
				col: "Error" + colsrc,
				msg: msg,
				doc: doc,
				console: true
			});
		}

		try {			
			printlog("docAppNo: " + doc.appNumber  + ", after change :" + getAN(doc.country, doc.appNumber));
			var tarQ = {
				{"doDate" : doc.doDate},
				{"appNumber" : getAN(doc.country, doc.appNumber)},
				{"stat" : doc.stat},
				{"country" : doc.country}
			};
			printlog("query: "  + "\r\n"
				+  " doDate: " + doc.doDate + "\r\n"
				+  " appNumber: " + getAN(doc.country, doc.appNumber) + "\r\n"
				+  " stat: " + doc.stat + "\r\n"
				+  " country: " + doc.country + "\r\n");
				/*
			var mqdocs = [];
			dbsrc[colsrc].find(tarQ).sort({stat: 1,doDate: 1}).forEach(function(mqdoc) {
				if(!mqdoc.withdrawn){
					mqdocs.push(mqdoc);
				}
			});
			
			
			printlog("mqdocs:" + mqdocs);
			//read key
				for (var key in mqdocs) {
				  // ...
				  printlog("key: " + key + ", value "  + mqdocs[key]);
				}*/
				
			if (cursor.hasNext()) {
				var data = cursor.next();
				
				switch (doc.country) {
					case "TW" :
					case "JP" :
					case "CN" :
					case "KR" :
						printlog("language is not EN , need to write ");
						var title = undefined;
						title = {
							"en": doc.title
						}
						updateField(data, 'title', title);
						
						var brief = undefined;
						brief = {
							"en": doc.brief
						}
						updateField(data, 'brief', brief);
						break;
					case "US" :
					case "EPO" :
					case "WIPO" :
						printlog("language is EN , not need to write ");
						break;
					default:
						printlog("not exists PTO, write origin ");
						var title = undefined;
						title = {
							"origin": doc.title
						}
						updateField(data, 'title', title);
						
						var brief = undefined;
						brief = {
							"origin": doc.brief
						}
						updateField(data, 'brief', brief);
						break;				
				}
				
				updateField(data, 'family', doc.family);
				updateField(data, 'country', doc.country);
				updateField(data, 'docdbDoDate', doc.docdbDoDate);	
				
				dbtar[coltar].save(data);
				//dbtar.getCollection(coltar).save(data);
				
			} else {
				printlog("data not found");
			}
			
			
			
		}catch(e){
			log(e);
		}
		
		debugProcess(doc);
	});
	
	printlog("merge finish");
})();
