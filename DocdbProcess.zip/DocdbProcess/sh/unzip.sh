 ##解到unzipFilefolder之下並刪除zip
for file in *.zip; do
       dir=$(basename "$file" .zip) # remove the .zip from the filename
       mkdir "$dir"
       cd "$dir" && unzip ../"$file" && rm ../"$file" # unzip and remove file if successful
       cd ..
  done  
 
 ##解到unzipFilefolder之下
  for file in *.zip; do
       dir="unzipFiles" # remove the .zip from the filename
       mkdir "$dir"
       cd "$dir" && unzip ../"$file" # unzip and remove file if successful
       cd ..
  done
  
  ## 解到與黨名相同的folder之下
  ##  docdb_xml_bck_201511_001_A.zip
  for file in *.zip; do
       dir=$(basename "$file" .zip) # remove the .zip from the filename
       mkdir "$dir"
       echo "unzip file = $file"
       cd "$dir" && unzip ../"$file" # unzip and remove file if successful
       cd ..
  done
    