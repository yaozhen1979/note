package test;

import org.junit.Assert;
import org.junit.Test;
import org.tony.test.HelloWorld;


public class HelloWorldTester {
    
    @Test
    public void testSayHelloWorld() {
        
        HelloWorld hw = new HelloWorld();
        
        Assert.assertEquals("hello world", hw.sayHelloWorld());
    }

}
