package test.logback;

import org.junit.Assert;
import org.junit.Test;
import org.tony.test.TestBase;
import org.tony.test.logback.HelloLogback1;

public class HelloLogback1Tester extends TestBase {

    @Test
    public void testSayHello() {
        
        logger.info("into testSayHello...");
        
        Assert.assertEquals("hello", new HelloLogback1().sayHello());
        
    }

}
