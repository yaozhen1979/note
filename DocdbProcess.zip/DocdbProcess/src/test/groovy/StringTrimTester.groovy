import org.apache.commons.lang3.StringUtils

def test1 = "\"test test \"xxx\" test test\""

def test2 = "test test"

println StringUtils.removeEnd(test1, "\"")
println StringUtils.removeStart(test1, "\"")
println unwrap(test1, "\"")


println StringUtils.removeEnd(test2, "\"")
println StringUtils.removeStart(test2, "\"")
println unwrap(test2, "\"")

def unwrap(String str, String remove) {
    
    def removeStartStr = StringUtils.removeStart(str, remove)
    def removeEndStr = StringUtils.removeEnd(removeStartStr, remove)
    
    return removeEndStr
}