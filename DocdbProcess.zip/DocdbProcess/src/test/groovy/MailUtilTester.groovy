import org.utils.MailUtil

MailUtil.sendToPatentCloud("tonykuo@patentcloud.com", "import_raw_data_to_101 Error", "TEST MAIL...${new Date()}")

println "finished..."