import java.text.SimpleDateFormat

def date1 = new Date()

def date2 = new SimpleDateFormat("yyyyMMdd").parse("00000101")

def date3 = new SimpleDateFormat("yyyyMMdd").parse("99991231")

println "date1 = ${date1}"
println "date2 = ${date2}"
println "date3 = ${date3}"

println date1.compareTo(date2)
println date1.compareTo(date3)


def test = null ?: 'Viva Las Vegas!'
println "${!""}"