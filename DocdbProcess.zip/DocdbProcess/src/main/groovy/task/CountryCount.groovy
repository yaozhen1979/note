def oldList = [
    "AM", "AP", "AR", "AT", "AU", 
    "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR",
    "UA", "UY",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]

def sortOldList = oldList.toSet().sort()

println "old ccList = ${sortOldList.size()}"

def ccList = []

new File("doc/cc_list.txt").eachLine { line ->
    
    // "DE",7332186,
    def patternGroup = line =~ /".{2}"/
    
    def country = patternGroup[0][1] + patternGroup[0][2] 
    
    ccList << country
    
    println country
    
}

println ccList.toSet().sort().size()

def sorList = ccList.toSet().sort()

println sortOldList.removeAll(sorList)

println sortOldList

