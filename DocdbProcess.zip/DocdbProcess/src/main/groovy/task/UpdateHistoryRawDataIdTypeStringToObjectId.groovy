// CN, lv2._id = 557a985eb4411f24f16db434, 要改變其中的history中的rawDataId type 為 ObjectId, 而非String

/*
 * TODO:
 * process / 1239743
 * process / 1239744
 * lv2._id = 558652a2b4411f24f1d1d3c9
 */

/**
 * 查詢history最後一筆資料的rawDataId, 再來更新Lv2 data.
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

println "to start..."
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

// def queryMap = [_id: new ObjectId("557a985eb4411f24f16db434")]
// CN OK
// US OK
// JP OK
// TW OK
// WO OK
// EP OK
// KR OK
// OTHER COUNTRY

def ccList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO",
    "KE", "KG", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT",
    "UA", "UY", "UZ",
    "VN",
    "YU",
    "ZA", "ZM", "ZW"
]


println "ccList size = ${ccList.size()}"

// def ccList = ["WO", "KR"] 

ccList.each { cc -> 
    def queryMap = [country: cc]
    updateErrHistory(db, queryMap);
}

println "finished..."

def updateErrHistory(db, queryMap) {
    //
    
    // batch process
    BulkWriteOperation infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
    
    // 目前處理筆數
    def currentCount = 0
    // 目前bulk筆數
    def countOfBulk = 0
    // 每次bulk execute總筆數
    def sizeOfBulk = 500
    
    def errCount = 0
    
    db.PatentInfoDOCDB.find(queryMap).each { it ->
        
        // println "${it.history[2].rawDataId}"
        
        def historyList = [] 
        
        it.history.each{ history ->
            
            // println (history.rawDataId.class == org.bson.types.ObjectId)
            // println (history.rawDataId.class == String)
            //
            if (history.rawDataId.class == String) {
                
                def objectId = new ObjectId(history.rawDataId)
                // println objectId.class
                
                historyList << [rawDataId: objectId, docdbDoDate: history.docdbDoDate, status: history.status]
                
                errCount++
                println "lv2._id = ${it._id}"
                
            } else {
                // println "history = ${history}"
                historyList << history
            }
            
        }
        
        // println historyList[1].rawDataId.class
        
        def updateMap = [$set: [history: historyList]]
        infoDOCDBBulk.find(new BasicDBObject("_id", it._id)).updateOne(new BasicDBObject(updateMap))
        countOfBulk++;
        
        // countOfBulk == sizeOfBulk 時, 則執行bulk execute.
        if (countOfBulk.mod(sizeOfBulk) == 0) {
            //
            println "batch execute ...."
            //
            infoDOCDBBulk.execute()
            // init bulk again
            infoDOCDBBulk = db.PatentInfoDOCDB.initializeOrderedBulkOperation()
            countOfBulk = 0
        }
        
        println "process / ${++currentCount}"
        
    }   // end find query
    
    // execute rest bulk count
    if (countOfBulk > 0) {
        //
        println "rest batch execute ...."
        infoDOCDBBulk.execute()
    }
    
    println "errCount = ${errCount}"
    
}
