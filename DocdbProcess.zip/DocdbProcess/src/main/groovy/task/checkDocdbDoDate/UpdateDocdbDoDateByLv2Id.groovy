/**
 * 查詢history最後一筆資料的rawDataId, 再來更新Lv2 data.
 */
import org.utils.MongoUtil
import org.bson.types.ObjectId

import com.mongodb.BasicDBObject
import com.mongodb.BulkWriteOperation;

println "to start..."
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

//
def updateQuery = [_id: new ObjectId("557a9855b4411f24f16daecd")]
updateDocdbDoDate(updateQuery, client)

println "finished..."


def updateDocdbDoDate(updateQuery, client) {
    
    def lv1DB = client.getDB("PatentRawDOCDB")
    
    /*
     *  Test: TestInfoDOCDB
     *  Prod: PatentInfoDOCDB
     */
    def lv2DB = client.getDB("PatentInfoDOCDB")
    
    // def updateQuery = [country:"DE", 'redmine.bug':99999]
    
    def totalCount = lv2DB.PatentInfoDOCDB.count(updateQuery)
    
    // 目前處理筆數
    def currentCount = 0
    // 目前bulk筆數
    def countOfBulk = 0
    // 每次bulk execute總筆數
    def sizeOfBulk = 500
    
    // batch process
    BulkWriteOperation infoDOCDBBulk = lv2DB.PatentInfoDOCDB.initializeOrderedBulkOperation()
    
    lv2DB.PatentInfoDOCDB.find(updateQuery).each { lv2Data ->
        
        def lastHistoryRawDataId = lv2Data.history[-1].rawDataId
        println "lv2._id = ${lv2Data._id}"
        println "lv2.history = ${lv2Data.history}"
        
        // start
        def lv1Query = [_id: lastHistoryRawDataId]
        
        def lv1Data = lv1DB.PatentRawDOCDB.findOne(lv1Query)
        println "lv1Data = " + lv1Data
        // println "lv1._id = ${lv1Data._id}"
        // println "lv1.docdbDoDate = ${lv1Data.docdbDoDate}"
        
        //
        def updateMap = [$set: [docdbDoDate: lv1Data.docdbDoDate]]
        
        infoDOCDBBulk.find(new BasicDBObject("_id", lv2Data._id)).updateOne(new BasicDBObject(updateMap))
        countOfBulk++
        
        // countOfBulk == sizeOfBulk 時, 則執行bulk execute.
        if (countOfBulk.mod(sizeOfBulk) == 0) {
            //
            println "batch execute ...."
            //
            infoDOCDBBulk.execute()
            // init bulk again
            infoDOCDBBulk = lv2DB.PatentInfoDOCDB.initializeOrderedBulkOperation()
            countOfBulk = 0
        }
        // end
        
        println "process data ${++currentCount} / ${totalCount} ..."
        
    }   // end find query
    
    // execute rest bulk count
    if (countOfBulk > 0) {
        //
        println "rest batch execute ...."
        infoDOCDBBulk.execute()
    }
    
}   // end updateDocdbDoDate
