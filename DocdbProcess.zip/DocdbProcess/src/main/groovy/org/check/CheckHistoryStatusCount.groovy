/**
 * check history 每期修改的數量 (Cr-Del, Amend)
 */
import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def ln = System.getProperty('line.separator')

// 10.60.90.101 / 127.0.0.1
def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

// TonyDB / PatentInfoDOCDB
def lv2DB = client.getDB("PatentInfoDOCDB")

def amendCount = 0
def createCount = 0
def deleteCount = 0
def backfileCount = 0
def otherCount = 0

File filgLog = new File("log/check_status_20150402.log")

// 2015-03-12 createCount = 91851
//            deleteCount = 3
// 55a8090cb4411f24f119a639

def checkDate = "20150521"

def queryMap = ['history.docdbDoDate':DateUtil.parseDate(checkDate)]
// def queryMap = [_id: new ObjectId("55a8090cb4411f24f119a639")]

lv2DB.PatentInfoDOCDB.find(queryMap).eachWithIndex { it, index -> 
    
    println "process ${index + 1} ..."
    
    it.history.each { history -> 
        
        //
        def docdbDoDate = DateUtil.toISODate(history.docdbDoDate, "yyyyMMdd")
        
        
        if (history.status == 'C' && docdbDoDate == checkDate) {
            //
            createCount++
            
        } else if (history.status == 'A' && docdbDoDate == checkDate) {
            //
            amendCount++
            
        } else if (history.status == 'D' && docdbDoDate == checkDate) {
            
            deleteCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
            
        } else if (history.status == 'B' && docdbDoDate == checkDate) {
            
            backfileCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
            
        } else if(docdbDoDate == checkDate) {
            
            otherCount++
            filgLog << "id = ${it._id}, status = ${history.status}" << ln
        
        }
        
    }
    
}

println "amendCount = ${amendCount}"
println "createCount = ${createCount}"
println "deleteCount = ${deleteCount}"
println "backfileCount = ${backfileCount}"
println "otherCount = ${otherCount}"

println "finished..."
