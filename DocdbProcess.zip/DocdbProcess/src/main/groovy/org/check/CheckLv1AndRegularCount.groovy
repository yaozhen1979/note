import org.utils.MongoUtil
import org.utils.DateUtil
import org.bson.types.ObjectId

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def lv1Db = client.getDB("PatentRawDOCDB")

def regularDb = client.getDB("PatentRegularDOCDB")

def ccList = ["KR", "KZ", "LT", "LU", "LV", "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY"]

println "starting..."

ccList.each { cc -> 
    
    def rawCount = lv1Db.PatentRawDOCDB.count([country : "${cc}"])
    
    def regularCount = regularDb.getCollection("PatentRegularDOCDB${cc}").count()
    
    def msg = (rawCount == regularCount ? "MATCH !!!" : "NO MATCH !!!")
    
    println "${cc} count : ${msg}"
    
}

println "finished..."