// 102415
// db.PatentInfoDOCDB.find({country:"HK", isUpdateTitleAndBrief:true}).count()
// 246
// db.PatentInfoDOCDB.find({country:"HK", isUpdateTitleAndBrief:{$exists:false}}).count()
/**
 * 檢查docdb lv2 update title and brief count
 * 
 */
import org.apache.commons.io.input.ReversedLinesFileReader;
import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

def ln = System.getProperty('line.separator')

File checkLog = new File("log/checkUpdateTitleAndBrief.log")

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")

new File("T:/log/log_for_update_lv2_title_and_abstract").eachFile { file ->
// new File("T:/log/test").eachFile { file ->
    
    def fileName = file.name
    def country = file.name.substring(0,2)
    println "fileName = ${fileName}, country = ${country}"
    
    println "to start checking...${country}"
    
    // exclude CN, JP, US
    if (true) {
        //
        int n_lines = 1;
        int counter = 0;
        ReversedLinesFileReader object = new ReversedLinesFileReader(file);
        
        /*
         * updateCount = 1
         * noUpdateCount = 1
         */
        def lastLine = object.readLine()
        def last2Line 
        
        def noUpdateCount
        def updateCount
        
        while(counter < n_lines) {
            last2Line = object.readLine()
            counter++
        }
        
        println lastLine
        println last2Line
        
        if (lastLine.contains("noUpdateCount")) {
            //
            noUpdateCount = lastLine.split("=")[1].trim()
            updateCount = last2Line.split("=")[1].trim()
            //
            def query1 
            def query2
            def query3
            
            if (fileName == 'CN_Before_2011_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("2011-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("2011-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("2011-01-01") ]]
                
            } else if (fileName == 'CN_After_2011_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("2011-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("2011-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("2011-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
            
            } else if (fileName == 'JP_Before_1993_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("1993-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("1993-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("1900-01-01"), $lt:DateUtil.parseDate("1993-01-01") ]]
            
            } else if (fileName == 'JP_After_1993_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("1993-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("1993-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("1993-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
            
            } else if (fileName == 'US_Before_2000_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("1780-01-01"), $lt:DateUtil.parseDate("2000-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("1780-01-01"), $lt:DateUtil.parseDate("2000-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("1780-01-01"), $lt:DateUtil.parseDate("2000-01-01") ]]
            
            } else if (fileName == 'US_After_2000_update.log') {
                
                query1 = [country:country, doDate:[$gte:DateUtil.parseDate("2000-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false], doDate:[$gte:DateUtil.parseDate("2000-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
                query3 = [country:country, isUpdateTitleAndBrief:true, doDate:[$gte:DateUtil.parseDate("2000-01-01"), $lt:DateUtil.parseDate("2016-01-01") ]]
            
            } else {
                query1 = [country:country]
                query2 = [country:country, isUpdateTitleAndBrief:[$exists:false]]
                query3 = [country:country, isUpdateTitleAndBrief:true]
            }
            
            def totalCountry = db.PatentInfoDOCDB.count(query1)
            def checkDbNoUpdateCount = db.PatentInfoDOCDB.count(query2)
            def checkDbUpdateCount = db.PatentInfoDOCDB.count(query3)
            
            if (checkDbNoUpdateCount == Integer.valueOf(noUpdateCount)) {
                checkLog << "${country} = check [no update] count ok" << ln
            } else {
                checkLog << "${country} = check [no update] count no good" << ln
            }
            
            if (checkDbUpdateCount == Integer.valueOf(updateCount)) {
                checkLog << "${country} = check [update count] ok" << ln
            } else {
                checkLog << "${country} = check [update count] no good" << ln
            }
            
            if (totalCountry == (checkDbNoUpdateCount + checkDbUpdateCount)) {
                checkLog << "${country} = check [update count] + [no update count] = [total ${country} count]" << ln
            } else {
                checkLog << "${country} = check [update count] + [no update count] <> [total ${country} count]" << ln
            }
            
        } else {
            checkLog << "${country} must check again..." << ln
        }
        
    }
    
}

println "finished..."
