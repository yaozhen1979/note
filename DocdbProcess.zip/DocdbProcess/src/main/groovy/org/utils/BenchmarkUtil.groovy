import groovy.time.TimeCategory
import groovy.time.TimeDuration

def benchmark = { closure ->
    
    def timeStart = new Date()
    closure.call()
    def timeStop = new Date()
    
    TimeDuration duration = TimeCategory.minus(timeStop, timeStart)
    
    return duration
}

def duration = benchmark {
    (0..10000).inject(0) { sum, item ->
        sum + item
    }
}

println "execution took ${duration}"

//(0..5).inject(0) { sum, item ->
//    println "sum = ${sum}"
//    // println "item = ${item}"
//    sum + item
//}