package org.utils

import org.apache.commons.lang3.StringUtils

class StringUtil {
    
    /**
     * EX:
     * 
     * StringUtil.unwrap("\"test test \"xxx\" test test\"", "\"") = test test "xxx" test test
     * 
     * @param str
     * @param remove
     * @return
     */
    static unwrap(String str, String remove) {
        
        def removeStartStr = StringUtils.removeStart(str, remove)
        def removeEndStr = StringUtils.removeEnd(removeStartStr, remove)
        
        return removeEndStr
    }
    
    /**
     * Left pad a String with a specified character.
     * Pad to a size of size.
     * 
     * StringUtils.leftPad(null, *, *)     = null
     * StringUtils.leftPad("", 3, 'z')     = "zzz"
     * StringUtils.leftPad("bat", 3, 'z')  = "bat"
     * StringUtils.leftPad("bat", 5, 'z')  = "zzbat"
     * StringUtils.leftPad("bat", 1, 'z')  = "bat"
     * StringUtils.leftPad("bat", -1, 'z') = "bat"
     *
     * @param str - the String to pad out, may be null
     * @param size - the size to pad to
     * @param padChar - the character to pad with
     * @return - left padded String or original String if no padding is necessary, null if null String input
     */
    static leftPad(def str, int size, def padChar) {
        return StringUtils.leftPad(str, size, padChar)
    }
    
    /**
     * Right pad a String with a specified character.
     * 
     * The String is padded to the size of size.
     * 
     * StringUtils.rightPad(null, *, *)     = null
     * StringUtils.rightPad("", 3, 'z')     = "zzz"
     * StringUtils.rightPad("bat", 3, 'z')  = "bat"
     * StringUtils.rightPad("bat", 5, 'z')  = "batzz"
     * StringUtils.rightPad("bat", 1, 'z')  = "bat"
     * StringUtils.rightPad("bat", -1, 'z') = "bat"
     * 
     * @param str - the String to pad out, may be null
     * @param size - the size to pad to
     * @param padChar - the character to pad with
     * @return - right padded String or original String if no padding is necessary, null if null String input
     */
    static rightPad(def str, int size, def padChar) {
        return StringUtils.rightPad(str, size, padChar)
    }
    
}