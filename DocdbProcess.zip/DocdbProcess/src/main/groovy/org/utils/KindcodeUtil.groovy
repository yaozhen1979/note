package org.utils

class KindcodeUtil {
    
    /**
     * 2015-08-24:
     * 
     * 比對patentNumber or doDate, 來取得stat
     * 
     * stat = 1, 為公開
     * stat = 2, 為公告
     * stat = 3, 同時為公開, 公告
     * 
     * 並以ruleFlag為判斷依據
     * 
     * ruleFlag = 1, 直接以DB為準
     * ruleFlag = 2, 以doDate來比對startDate, endDate
     * ruleFlag = 3, 以patentNumber來比對number中的regex pattern
     * ruleFlag = 4, 則同時比對doDate && patentNumber
     * 
     * kindcode import 規則, 可參看KindCodeMapImporter.groovy
     * kindcode 資料, 則參看doc/kindcode_update.csv
     * 
     * @param lv1
     * @param dataMap
     * @param lv2DB
     * @return
     */
    static getKindcodeData(lv1, dataMap, lv2DB) {
        
        def kindcodeData = [:]
        
        // println "dataMap.doDate = ${dataMap.doDate}"
        
        lv2DB.KindCodeMap.find([country: lv1.country, kindcode: lv1.kindCode]).each { data -> 
            
            // println "data = ${data}"
            
            if (data.ruleFlag == 4) {
                
                def passFlag = false
                
                // println "${dataMap.doDate} compareTo(data.startDate) = ${dataMap.doDate.compareTo(data.startDate)}"
                // println "${dataMap.doDate} compareTo(data.endDate) = ${dataMap.doDate.compareTo(data.endDate)}"
                // println "${dataMap.patentNumber} ==~ ${data.number} = " + (dataMap.patentNumber ==~ "${data.number}")
                
                // compare: startDate, endDate, number
                if (dataMap.doDate.compareTo(data.startDate) >= 0 && 
                    dataMap.doDate.compareTo(data.endDate) <= 0 && 
                    dataMap.patentNumber ==~ "${data.number}") {
                    //
                    kindcodeData << [stat: data.stat]
                    kindcodeData << [type: data.patentType]
                    return;
                }
                
            } else if (data.ruleFlag == 1) {
                kindcodeData << [stat: data.stat]
                kindcodeData << [type: data.patentType]
                return;
            } else if (data.ruleFlag == 2) {
            
                // compare startDate, endDate
                try {
                    if (dataMap.doDate.compareTo(data.startDate) >= 0 &&
                        dataMap.doDate.compareTo(data.endDate) <= 0) {
                        //
                        kindcodeData << [stat: data.stat]
                        kindcodeData << [type: data.patentType]
                        return;
                    }
                } catch (e) {
                    e.printStackTrace()
                    throw new Exception(
                        "country = ${lv1.country}, kindcode = ${lv1.kindCode}, lv1Id = ${lv1._id}, ruleFlag = ${data.ruleFlag}, exception = ${e}"
                    )
                }
            
            } else if (data.ruleFlag == 3) {
            
                // throw new Exception("country = ${lv1.country}, kindcode = ${lv1.kindCode}, ruleFlag = ${data.ruleFlag}, todo...")
                
                // compare number
                // println "dataMap.patentNumber = ${dataMap.patentNumber}"
                // println "data.number = ${data.number}"
                if (dataMap.patentNumber ==~ "${data.number}") {
                    // println "${data.number} : match"
                    kindcodeData << [stat: data.stat]
                    kindcodeData << [type: data.patentType]
                    return;
                } else {
                
                    /*
                     * hard code : number compare
                     * country: BE, CA, ES
                     * 
                     * function 說明: setKindcodeBy[country] 
                     * => 會帶入 kindcodeData 是為了防止如[ES]這國家, 在ruleFlag = 3時, 
                     *    會產生重複判斷問題, 以致於最後更新的資料會洗掉前面的資料.
                     * 
                     */
                    if (lv1.country == 'BE') {
                        //
                        kindcodeData = setKindcodeByBE(dataMap, data, kindcodeData)
                    } else if (lv1.country == 'CA') {
                        //
                        kindcodeData = setKindcodeByCA(dataMap, data, kindcodeData)
                    } else if (lv1.country == 'ES') {
                        //
                        kindcodeData = setKindcodeByES(dataMap, data, kindcodeData)
                    }
                }
            
            }
            
        }  // end KindCodeMap find 
        
        // throw new Exception("for test, kindcodeData = ${kindcodeData}")
        
        if (!kindcodeData) {
            throw new Exception("country = ${lv1.country}, kindcode = ${lv1.kindCode}, lv1Id = ${lv1._id}, todo...")
        }
        
        return kindcodeData
        
    }  // end getKindcodeData function
    
    /**
     * 
     * for country BE
     * 
     * @param kindcodeData
     * @param data
     * @return
     */
    private static setKindcodeByBE(def dataMap, def data, def kindcodeData) {
        
        def kindcode = dataMap.kindcode
        def patentNumber = dataMap.patentNumber as Integer
        
        if (patentNumber >= 1000000) {

            if (kindcode == 'A1' || kindcode == 'A2' || kindcode == 'A3' ||
                kindcode == 'A4' || kindcode == 'A5') {
                //
                kindcodeData << [stat: data.stat]
                kindcodeData << [type: data.patentType]

            } else if (kindcode == 'A6' || kindcode == 'A7') {
                //
                kindcodeData << [stat: data.stat]
                kindcodeData << [type: data.patentType]
            }

        } else {

            if (kindcode == 'A1' || kindcode == 'A2' || kindcode == 'A3') {
                //
                kindcodeData << [stat: data.stat]
                kindcodeData << [type: data.patentType]

            } else if (kindcode == 'A4' || kindcode == 'A5' || kindcode == 'A6' ||
                kindcode == 'A7') {
                //
                kindcodeData << [stat: data.stat]
                kindcodeData << [type: data.patentType]
            }

        }
        
        return kindcodeData
    }
    
    /**
     * 
     * for country CA
     *
     * @param kindcodeData
     * @param data
     * @return
     */
    private static setKindcodeByCA(def dataMap, def data, def kindcodeData) {
        
        def kindcode = dataMap.kindcode
        def patentNumber = dataMap.patentNumber as Integer
        
        if (kindcode == 'A1' && patentNumber > 2000000) {
            kindcodeData << [stat: data.stat]
            kindcodeData << [type: data.patentType]
        } else if (kindcode == 'A1' && patentNumber <= 2000000) {
            kindcodeData << [stat: data.stat]
            kindcodeData << [type: data.patentType]
        }
        
        return kindcodeData
    }
    
    /**
     *
     * for country ES
     *
     * @param kindcodeData
     * @param data
     * @return
     */
    private static setKindcodeByES(def dataMap, def data, def kindcodeData) {
        
        def kindcode = dataMap.kindcode
        def patentNumber = dataMap.patentNumber as Integer
        
        if (kindcode == 'A6' && patentNumber >= 2000000 && patentNumber <= 2126538) {
            //
            kindcodeData << [stat: data.stat]
            kindcodeData << [type: data.patentType]

        } else if (kindcode == 'A6' && patentNumber >= 2126539) {
            //
            kindcodeData << [stat: data.stat]
            kindcodeData << [type: data.patentType]
        }
        
        return kindcodeData
    }
    
}


