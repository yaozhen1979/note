package org.enums;

public enum ErrCode {
    DataNotFound,
    ErrFormat,
    ErrKindcode,
    ErrNumber;
}
