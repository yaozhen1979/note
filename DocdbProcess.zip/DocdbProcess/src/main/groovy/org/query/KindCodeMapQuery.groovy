import org.utils.MongoUtil

import org.bson.types.ObjectId

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentInfoDOCDB")

def query = [_id: new ObjectId("557b962160b22fd0904ace5e")]

//db.getCollectionNames().each { it -> 
//    println it
//}
//
//println "db = ${db}"

db.KindCodeMap.find().each { it ->
    
    println it
    
}


def count = db.KindCodeMap.count()
println "count = ${count}"

println "finished..."
