/**
 * 依國家別來統計DOCDB中每一期的資料數量
 */
import org.utils.MongoUtil

import org.bson.types.ObjectId
import org.utils.DateUtil

def client = MongoUtil.connect3X('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')

def db = client.getDB("PatentRawDOCDB")

// 2015-03-19 V
// Cr-Del count = 65100
// Amend  count = 605585

// 2015-03-26 V
// Cr-Del count = 76565
// Amend  count = 387816

// 2015-04-02 V
// Cr-Del count = 66505
// Amend  count = 403283

// 2015-04-09 V
// Cr-Del count = 98425
// Amend  count = 418472

// 2015-04-16 V
// Cr-Del count = 65383
// Amend  count = 853132

// 2015-04-23 V
// Cr-Del count = 69260
// Amend  count = 1486977

// 2015-04-30 V
// Cr-Del count = 121171
// Amend  count = 434688

// 2015-05-07 V
// Cr-Del count = 180072
// Amend  count = 1335115

// 2015-05-14 V
// Cr-Del count = 34524
// Amend  count = 736109

// 2015-05-21
// Cr-Del count = 73689
// Amend  count = 778707

// 2015-05-28
// Cr-Del count = 206371
// Amend  count = 487693

// 2015-06-04
// Cr-Del count = 23397
// Amend  count = 275540

// 2015-06-11
// Cr-Del count = 150701
// Amend  count = 375081

// 2015-06-18
// Cr-Del count = 33164
// Amend  count = 340880

// 2015-06-25
// Cr-Del count = 177622
// Amend  count = 431451

// 2015-07-2
// Cr-Del count =
// Amend  count =

// 2015-MM-dd
// Cr-Del count =
// Amend  count =

def query = "2015-07-02"

def countryList = [
    "AM", "AP", "AR", "AT", "AU", "BA", "BE", "BG", "BR", "BY",
    "CA", "CH", "CL", "CN", "CO", "CR", "CS", "CU", "CY", "CZ",
    "DD", "DE", "DZ", "DK", "DO",
    "EA", "EC", "EE", "EG", "ES", "EP",
    "FI", "FR",
    "GB", "GC", "GE", "GR", "GT",
    "HK", "HN", "HR", "HU",
    "ID", "IE", "IL", "IN", "IS", "IT",
    "JO", "JP",
    "KE", "KG", "KR", "KZ",
    "LT", "LU", "LV",
    "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
    "NI", "NL", "NO", "NZ",
    "OA",
    "PA", "PE", "PH", "PL", "PT",
    "RO", "RS", "RU",
    "SE", "SG", "SI", "SK", "SM", "SU", "SV",
    "TH", "TJ", "TN", "TR", "TT", "TW",
    "UA", "US", "UY", "UZ",
    "VN",
    "WO",
    "YU",
    "ZA", "ZM", "ZW"
]

println "countryList = ${countryList.size()}"

def fileType1TotalCount = 0
def fileType2TotalCount = 0

countryList.each { cc -> 
    
    println "query country = ${cc}"
    
    def checkDocdbDate = DateUtil.parseDate(query)
    
    def fileType1Count = queryCountryCount(db, checkDocdbDate, 1, cc)
    fileType1TotalCount = fileType1TotalCount + fileType1Count
    println "${cc}, checkDate = ${query}, fileType 1 count = ${fileType1Count}"
    //
    
    def fileType2Count = queryCountryCount(db, checkDocdbDate, 2, cc)
    fileType2TotalCount = fileType2TotalCount + fileType2Count
    println "${cc}, checkDate = ${query}, fileType 2 count = ${fileType2Count}"
    
}

println "================================================"
println "fileType1TotalCount = ${fileType1TotalCount}"
println "fileType2TotalCount = ${fileType2TotalCount}"

/**
 * 
 * @param db
 * @param checkDocdbDate
 * @param type
 * @param cc
 * @return
 */
def queryCountryCount (db, checkDocdbDate, type, cc) {
    
    return db.PatentRawDOCDB.count([docdbDoDate: checkDocdbDate, fileType:type, country: cc])
}

// db.PatentRawDOCDB.find({docdbDoDate: ISODate("2015-03-26T00:00:00Z"), fileType:1, 'data.xml':{$regex: /status=\"C\"/}}).count();
// def createCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"C\"/]])
// println "createCount = ${createCount}"

// def deleteCount = db.PatentRawDOCDB.count([docdbDoDate:DateUtil.parseDate(query), fileType:1, 'data.xml':[$regex:/status=\"D\"/]])
// println "deleteCount = ${deleteCount}"

println "finished..."
