package org.beans

class DocdbInfoBean {
    
    // TODO:
    def patentNumber
    
    def familyId
    
    def kindcode
    
    def status
    
    def country
    
    def appNo
    
    def appDate
    
    def doDate
    
    def titleMap
    
    def briefMap
    
    def ipcs
    
    def cpcs
    
    def docdbAssignees
    
    def docdbAAssignees
    
    def docdbInventors
    
    def docdbAInventors
    
    def lang
    
    def priorityPatents
    
    def citedPatents
    
    def otherReferences
    
    @Override
    public String toString() {
        return "DocdbInfoBean [patentNumber=" + patentNumber + ", familyId=" + familyId + ", kindcode=" + kindcode + ", status=" + status + ", country=" + country + ", appNo=" + appNo + ", appDate=" + appDate + ", doDate=" + doDate + ", titleMap=" + titleMap + ", briefMap=" + briefMap + ", ipcs=" + ipcs + ", cpcs=" + cpcs + ", docdbAssignees=" + docdbAssignees + ", docdbAAssignees=" + docdbAAssignees + ", docdbInventors=" + docdbInventors + ", docdbAInventors=" + docdbAInventors + ", lang=" + lang + ", priorityPatents=" + priorityPatents + ", citedPatents=" + citedPatents + ", otherReferences=" + otherReferences + "]";
    }
}