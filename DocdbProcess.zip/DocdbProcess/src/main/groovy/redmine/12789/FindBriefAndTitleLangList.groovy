import org.utils.MongoUtil
import org.bson.types.ObjectId
import org.utils.DateUtil

def ln = System.getProperty('line.separator')

def countryList = [
     "AM", "AP", "AR",
     "AT", 
     "AU", "BA",
     "BE", 
     "BG", "BR", "BY",
     "CA", 
     "CH", "CL",
     "CO", 
     "CR", "CS", "CU", "CY", "CZ",
     "DD",
     "DE", 
     "DZ", "DK", "DO",
     "EA", "EC", "EE", "EG", "ES",
     "FI", "FR",
     "GB", 
     "GC", "GE",
     "GR", 
     "GT",
     "HK", "HN", "HR",
     "HU", 
     "ID",
     "IE", 
     "IL", "IN", "IS", "IT",
     "JO",
     "KE",
     "KG", 
     "KZ",
     "LT", "LU", "LV",
     "MA", "MC", "MD", "ME", "MN", "MT", "MW", "MX", "MY",
     "NI",
     "NL", 
     "NO", "NZ",
     "OA",
     "PA", "PE", "PH", "PL",
     "PT", 
     "RO", "RS", "RU",
     "SE", "SG", "SI", "SK", "SM", "SU", "SV",
     "TH", "TJ", "TN", "TR", "TT",
     "UA", "UY", "UZ",
     "VN",
     "YU",
     "ZA", "ZM", "ZW"
]

def test = ["EP"]

println "cc list count = ${countryList.size()}"

def client = MongoUtil.connect('patentdata', 'data.cloud.Abc12345', "10.60.90.101", 27017, 'admin')
def db = client.getDB("PatentInfoDOCDB")


File fileLog = new File("log/redmine/12789/exists/12789_for_EP.log")

println "to start..."

test.each { cc ->
    //
    
    println "${cc} parsing..."
    
    def titleList = []
    def titleSet
    
    def briefList = []
    def briefSet
    
    def currentCount = 0
    def totalCount = db.PatentInfoDOCDB.count([country:cc]);
    
    println "${cc} total count = ${totalCount}"
    
    db.PatentInfoDOCDB.find([country:cc]).each { data ->
        
        // check title
        if (!!data.title) {
            data.title.each { key, value ->
                // println "cc title key = ${key}"
                if (key == 'origin' || key == 'original') {
                    // println "lv2._id = ${data._id}"
                    fileLog << "lv2._id = ${data._id}" << ln 
                }
                titleList << key
                titleSet = titleList.toSet()
                // println "titleSet = ${titleSet}"
                titleList = titleSet.toList()
                // println "titleList = ${titleList}"
            }
        }
        
        // check brief
        if (!!data.brief) {
            data.brief.each { key, value ->
                // println "cc brief key = ${key}"
                if (key == 'origin' || key == 'original') {
                    // println "lv2._id = ${data._id}"
                    fileLog << "lv2._id = ${data._id}" << ln
                }
                briefList << key
                briefSet = briefList.toSet()
                briefList = briefSet.toList()
            }
        }
        
        println "processing ${++currentCount} / ${totalCount} ..."
        
    }
    
    fileLog << "${cc} - title data-format list = ${titleSet}" << ln
    fileLog << "${cc} - brief data-format list = ${briefSet}" << ln
    fileLog << "---------------------------------------" << ln
    
}

println "finished..."
