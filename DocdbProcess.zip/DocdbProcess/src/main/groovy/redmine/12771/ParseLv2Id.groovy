File file = new File("log/redmine/12789/12789_for_DD.log")

def lv2IdList = []

file.eachLine { line -> 
    
    if (line.toString().startsWith("lv2._id")) {
        
        def data = line.toString().split("=")
        
        lv2IdList << data[1].trim()
        
    }
    
}

println "${lv2IdList}"