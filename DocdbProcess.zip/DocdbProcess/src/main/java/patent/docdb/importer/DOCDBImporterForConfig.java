package patent.docdb.importer;

import itec.patent.common.DateUtils;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tsaikd.java.utils.ArgParser;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import patent.util.PropertyUtil;

import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * @author mikelin
 *
 */
public class DOCDBImporterForConfig {
    
    static Logger logger = LoggerFactory.getLogger(DOCDBImporter.class);
    
    private static final String DOCDB_PTO = "DOCDB";
    private static final String DATA_XPATH = "exch:exchange-documents/exch:exchange-document";
    private static final String MONGODB_IP = "mongodb.ip";
    private static final String MONGODB_IP_DEFAULT = "10.60.90.155";
    private static final String XML_FILE_DIR = "xml.dir";
    private static final String XML_FILE_DIR_DEFAULT = "\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\EP\\docdb\\download\\backfile\\docdb_xml_bck_201511_019_A\\Root\\DOC\\unzipFiles";
    private static final String ZIP_FILE_DIR = "zip.dir";
    private static final String ZIP_FILE_DIR_DEFAULT = "T:\\test\\docdb\\source\\";
    private static final String LOG_DIR = "log.dir";
    private static final String LOG_DIR_DEFAULT = "T:\\test\\docdb\\source\\logs\\parse";
    private static final String UNZIP_FILE_LIST_DIR = "unzip.list";
    private static final String UNZIP_FILE_LIST_DIR_DEFAULT = "T:\\test\\docdb\\source\\logs\\unzip";
    private static final String REMOVE_FLAG = "remove.flag";
    private static final String REMOVE_FLAG_DEFAULT = "false";  
    private static final String SYSTEM_ID = "docdb-entities.dtd";
    private static final String DATE_OF_EXCHANGE = "date-of-exchange";
    private static final String DOC_ID = "doc-id";
    //
    private static final String CONFIG_PATH = "config.path";
    
    private static Element root;
    
    public static ArgParser.Option[] opts = {
    
        new ArgParser.Option(null, CONFIG_PATH, true, "./config.properties", "config path :"),
            
    };
    
    public DOCDBImporterForConfig() {
        
    }
    
    // C:/Users/tonykuo/Desktop/20150612/AR/config/config.properties
    public static void main(String[] args) throws Exception {
        
        DOCDBImporterForConfig rdPaser = new DOCDBImporterForConfig();
//      rdPaser.parserFromZip(args);
        rdPaser.parseFromXml(args);
        
    }
    
    public void parseFromXml(String[] args) throws Exception {
        
        Date start = new Date();
        
        ArgParser argParser = new ArgParser().addOpt(DOCDBImporterForConfig.class).parse(args);
        
        //show args
        logger.debug("start, opt: " + argParser.getParsedMap());
        
        
        Properties properties = PropertyUtil.load(argParser.getOptString(CONFIG_PATH));
        
        String ac = properties.getProperty("ac");
        String pd = properties.getProperty("pd");
//      String ac = "cGF0ZW50ZGF0YQ==";
//      String pd = "ZGF0YS5jbG91ZC5BYmMxMjM0NQ==";
        logger.debug(ac +", " + pd);
        
        // xmlDir
        String xmlDir = properties.getProperty("xmlDir");
        File dataDir = new File(xmlDir);
        
        // boolean removeFlag = argParser.getOptBoolean(REMOVE_FLAG);
        boolean removeFlag = true;
        
        String host = properties.getProperty("host");
        logger.info("host = " + host);
        
        MongoCredential credential = MongoCredential.createCredential(ac, "admin", pd.toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress(host, 27017), Arrays.asList(credential));
        
        DBCollection collection = mongoClient.getDB("PatentRawDOCDB").getCollection("PatentRawDOCDB");
        DBCollection errCollection = mongoClient.getDB("PatentRawDOCDB").getCollection("ErrorPatentRawDOCDB");
        
        //BulkWriteOperation 批次處理
        BulkWriteOperation builder = collection.initializeOrderedBulkOperation();
        //errorCollection insert
        BulkWriteOperation errorBuilder = errCollection.initializeOrderedBulkOperation();
        
        SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();
        
        String logDir = properties.getProperty("logDir");
        String unzipFileListDir = properties.getProperty("unzipFileListDir");
        
        String parseLogPath = logDir + File.separator + sf2.format(today) + "_parse.log";
        String errorLogPath = logDir + File.separator + sf2.format(today) + "_error.log";
        String unzipListPath = unzipFileListDir + File.separator + "unzip_list.log";
        
        int totalCnt = 0;
        int errorCnt = 0;
        
//      int cutPoint = 0;
        if (dataDir.exists()) {
            //
            File[] fileList = dataDir.listFiles();
            if (fileList != null && fileList.length > 0) {
                for (File file : fileList) {
                    logger.debug("start parse file: " + file.getAbsolutePath());
                    errorCnt = 0;
                    
                    if(FilenameUtils.isExtension(file.getName(), "xml")) {
                        File unzipListFile = new File(unzipListPath);
                        
                        //建立unzip_list.log
                        if (!unzipListFile.exists()) {
                            logger.info(unzipListPath + " does not exists, build it");
                            writeLog(unzipListPath, "");
                        }
                        
                        //執行時需比對曾經parse的xml
                        boolean isParsed = false;
                        for (String unzipFile : FileUtils.readLines(unzipListFile)) {
                            if(StringUtils.equals(unzipFile, file.getName())) {
                                logger.debug("file " + file.getName() + " has already unzip!");
                                isParsed = true;
                            }
                        }
                        
                        if (isParsed) {
                            continue;
                        }
                        
                        //將xml檔名寫入unzipList
                        writeLog(unzipListFile.getAbsolutePath(), file.getName() + "\r\n");
                        
                        try {
                            
                            Date parseStart = new Date();
                            Document doc = loadXMLFile(file);
                            Date parseEnd = new Date();
                            long diff = parseEnd.getTime() - parseStart.getTime();
                            String parseMsg = sf1.format(new Date()) + " " + file.getName() + "==> parse spend time : " + diff / 1000 + " seconds";
                            logger.debug(parseMsg);
                            
                            writeLog(parseLogPath, parseMsg + "\r\n");
                            
                            // After execution, you cannot re-execute the Bulk() object without reinitializing
                            builder = collection.initializeOrderedBulkOperation();
                            errorBuilder = errCollection.initializeOrderedBulkOperation();
                            
                            // DocDbDoDate parse
                            Date docdbDoDate = getDocDbDodate();
                            
                            // load elements
                            List<Element> nodes = doc.selectNodes(DATA_XPATH);
                            
                            totalCnt = nodes.size();
                            
                            logger.info("totalCnt = " + totalCnt);
                            
                            if (nodes != null && nodes.size() > 0) {
                                
                                for (int i=0; i < nodes.size(); i++) {
                                    
                                    Element ele = nodes.get(i);
                                    
                                    //when doc-id is null, write into error collection
                                    if (ele.attributeValue(DOC_ID) == null) {
                                        errorCnt++;
                                        
                                        String errMsg = file.getName() + "'s "
                                                + (i + 1)
                                                + " data does not have doc-id, skip it and write into ErrorPatentRawDOCDB";
                                        
                                        logger.error("error: " + errMsg);
                                        writeLog(errorLogPath, file.getName()
                                                + " : " + errMsg + "\r\n");
                                        
                                        errorBuilder.insert(new BasicDBObject(getErrorMap(ele, file.getName())));
                                        
                                        continue;
                                    }
                                    
                                    //path = 檔名+/+docId ,設為LV1 PK
                                    String path =  file.getName() + "/" + ele.attributeValue(DOC_ID);
                                    
                                    // logger.info("insert path = " + path);
                                    
                                    //先刪除現有的資料，避免重複insert
//                                    if (removeFlag) {
//                                        logger.info("removeFlag = " + removeFlag);
//                                        collection.remove(new BasicDBObject("path", path));
//                                    }
                                    
                                    builder.insert(new BasicDBObject(getDataMap(ele, file.getName(), path, docdbDoDate)));
                                    
                                    if ((i+1) % 500 == 0) {
                                        logger.debug("save path " + path + " ==> " + (i+1) + "/" + totalCnt);
                                    } else if ((i+1) == nodes.size()){
                                        logger.debug("save path " + path + " ==> " + (i+1) + "/" + totalCnt);
                                    }
                                }
                            }
                            
                            logger.debug("bulk processing , please wait ...");
                            //if no operations ,will throws exception
                            if (errorCnt > 0) {
                                errorBuilder.execute();
                            }
                            builder.execute();
                            
                        } catch (DocumentException dex) {
                            logger.error("error: " + dex);
                            writeLog(errorLogPath, file.getName() + " : " + dex.getMessage() + "\r\n");
                        } catch (Exception ex) {
                            logger.error("error: " + ex);
                            writeLog(errorLogPath, file.getName() + " : " + ex.getMessage() + "\r\n");
                        } finally {
                            //FileUtils.deleteQuietly(file);
                        }
                        
                        Date end = new Date();
                        long diff = end.getTime() - start.getTime();
                        String msg = sf1.format(new Date()) + " " + file.getName() + "==> total spend time : " + diff / 1000 + " seconds , data counts: " + totalCnt;
                        logger.debug(msg);
                        
                        writeLog(parseLogPath, msg + "\r\n");
                        
                    } else {
                        String errorMsg = file.getName() +" is not xml file!";
                        logger.error(errorMsg);
                        writeLog(errorLogPath, errorMsg + "\r\n");
                        continue;
                    }
//                  cutPoint++;
//                  if (cutPoint > 27) {
//                      break;
//                  }
                }
//              logger.debug("parse xml finish ~!");
            } else {
                logger.debug(dataDir.getAbsolutePath() + " is empty");
            }
            
        } else {
            logger.debug(dataDir.getAbsolutePath() + " folder not exists~!");
        }
        logger.debug("parse xml finish ~!");
    }
    
    /**
     * 取得檔案來源
     * 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
     * @param fileName
     * @return
     */
    public int getFileType(String fileName){
        
        int fileType = 0;
        
        if (fileName.contains("CreateDelete")) {
            fileType = 1;
        }
        if (fileName.contains("Amend")) {
            fileType = 2;
        }
        if (fileName.contains("REPLACEMENT")) {
            fileType = 3;
        }
        return fileType;
    }
    
    
    /**
     * 從root取得docDodate
     * 
     * @return
     */
    public Date getDocDbDodate() {
        String docdbDodate = "";
        
        if (root.attribute(DATE_OF_EXCHANGE) == null) {
            docdbDodate = "00000000";
        } else {
            docdbDodate = root.attribute(DATE_OF_EXCHANGE).getText();
        }
        
        //IF DATE_OF_EXCHANGE 為00000000 回傳 西元1970年01月01日
        if (docdbDodate.equals("00000000")){
            return DateUtils.parseDate("19700101");
        } else {
            return DateUtils.parseDate(docdbDodate);
        }

    }
    
    /**
     * 寫入訊息
     * @param logFilePath
     * @param msg
     * @throws IOException
     */
    public void writeLog(String logFilePath, String msg) throws IOException {
        File logFile = new File(logFilePath);
        FileUtils.writeStringToFile(logFile, msg , logFile.exists());
    }
    
    /**
     *  
     * 從指定的檔案路徑 讀取XML檔案 
     * @throws DocumentException
     *  
     */
    public static Document loadXMLFile(File xmlFile) throws DocumentException {
        Document doc = null;
        SAXReader saxReader = new SAXReader();
        saxReader.setEntityResolver(new EntityResolver() {
            @Override
            public InputSource resolveEntity(String publicId, String systemId)
                    throws SAXException, IOException {
                if (systemId.contains(SYSTEM_ID)) {
                    return new InputSource(new StringReader(""));
                } else {
                    return null;
                }
            }
        });
        doc = saxReader.read(xmlFile);
        root = doc.getRootElement();
        return doc;
    }   
    
    /**
     * 組出存入PatentDOCDB collection 的資訊
     * @param ele
     * @param fileName
     * @param path
     * @param docdbDoDate
     * @return
     */
    private Map<String, Object> getDataMap(Element ele, String fileName, String path, Date docdbDoDate) {
        
        // logger.info("into getDataMap...");
        
        Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
        dataMap.put("pto", DOCDB_PTO);
        dataMap.put("path", path);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        dataMap.put("data", data);
        
        dataMap.put("type", "xml/xml");
        dataMap.put("provider", "EPO Purchase");
        dataMap.put("docdbDoDate", docdbDoDate);
        
        //目前寫死truncate : false,
        dataMap.put("truncate", false);
        
        //add country
        dataMap.put("country", ele.attributeValue("country"));
        
        //add fileType
        dataMap.put("fileType", getFileType(fileName));
        
        //add mongoSyncData
        BasicDBObject mongoSyncData = new BasicDBObject();
        mongoSyncData.put("init", new Date());
        dataMap.put("mongoSyncFlag", mongoSyncData);
        
        //add kindCode
        dataMap.put("kindCode", ele.attributeValue("kind"));
        
        // logger.info("dataMap = " + dataMap);
        
        return dataMap;
    }
    
    /**
     * 組出存入ErrorPatentDOCDB collection 的資訊
     * @param ele
     * @param fileName
     * @return
     */
    private Map<String, Object> getErrorMap(Element ele, String fileName) {
        
        Map<String, Object> errorMap = new LinkedHashMap<String, Object>();
        errorMap.put("doDate", new Date());
        errorMap.put("errHandle", false);
        
        BasicDBObject errDoc = new BasicDBObject();
        errDoc.put("country", ele.attributeValue("country"));
        errDoc.put("path", fileName);
        errorMap.put("doc", errDoc);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        errorMap.put("data", data);
        
        return errorMap;
    }
    
}
