/**
 * 依kindcode.csv來存入相關資料
 */
package patent.docdb.importer;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class KindCodeImporter {
	static Logger logger = LoggerFactory.getLogger(KindCodeImporter.class);
	
	public static void main(String[] args) throws IOException {
		MongoCredential credential = MongoCredential.createMongoCRCredential("patentdata","admin","data.cloud.Abc12345".toCharArray());
		MongoClient mongoClient = new MongoClient(new ServerAddress("10.60.90.155", 27017), Arrays.asList(credential));
		DBCollection collection = mongoClient.getDB("PatentInfoDOCDB").getCollection("KindCodeMap");
		
		BulkWriteOperation builder = collection.initializeOrderedBulkOperation();
		
		File kindCodeFile = new File("T:\\note\\DOCDB\\kindCodeMap.csv");
		List<String> list = new LinkedList<String>();
		
		if (kindCodeFile.exists()) {
			list = FileUtils.readLines(kindCodeFile);
		}
		
		Map<String, Object> dataMap = null;
		for (String data : list) {
			logger.debug("data: " + data);
			String[] kindCodeData = data.split(",");
			dataMap = new LinkedHashMap<String, Object>();
			
			dataMap.put("country", kindCodeData[0]);
			dataMap.put("kindcode", kindCodeData[1]);
			dataMap.put("startDate", parseDate(kindCodeData[2]));
			dataMap.put("endDate", parseDate(kindCodeData[3]));
			dataMap.put("number", kindCodeData[4]);
			dataMap.put("patentType", kindCodeData[5]);
			dataMap.put("state", getStat(kindCodeData[6]));
			dataMap.put("ruleFlag", Integer.valueOf(kindCodeData[7]));
			builder.insert(new BasicDBObject(dataMap));
			
			logger.info("insert data : "  + dataMap);
		}
		builder.execute();
	}
	
	
	/**
	 * 1 : Publication, 2: Issued
	 * @param stateStr
	 * @return
	 */
	private static int getStat(String stateStr) {
		
		return stateStr.equals("Publication") ? Integer.valueOf(1) : Integer.valueOf(2);
	}
	
	@SuppressWarnings("serial")
    private static final Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {{
        put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
        put("^\\d{8}$", "yyyyMMdd");
        put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
        put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
        put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
        put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
        put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
        put("^\\d{12}$", "yyyyMMddHHmm");
        put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
        put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "dd-MM-yyyy HH:mm");
        put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
        put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
        put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
        put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
        put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
        put("^\\d{4}-\\d{1,2}-\\d{1,2}t\\d{1,2}:\\d{2}:\\d{2}z$", "yyyy-MM-dd'T'HH:mm:ss'Z'");
        put("^\\d{14}$", "yyyyMMddHHmmss");
        put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
        put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd-MM-yyyy HH:mm:ss");
        put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
        put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
        put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");
        put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
        put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMMM yyyy HH:mm:ss");
    }};
    
	private static String determineDateFormat(String dateString) {
        if (dateString == null) {
            return null;
        }
        for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
            if (dateString.toLowerCase().matches(regexp)) {
                return DATE_FORMAT_REGEXPS.get(regexp);
            }
        }
        return null; // Unknown format.
    }
	
	public static Date parseDate(String date) {
        String fmt = determineDateFormat(date);
        if (fmt == null) {
            return null;
        }

        DateFormat fmtInput = new SimpleDateFormat(fmt);
        try {
            fmtInput.setTimeZone(TimeZone.getTimeZone("GMT"));
            return fmtInput.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
