package patent.docdb.importer;

import itec.patent.common.DateUtils;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * @author Tony
 * 
 * meno
 * 
 */
public class DOCDBImporterByTony {

    static Logger logger = LoggerFactory.getLogger(DOCDBImporterByTony.class);
    
    private static final String DOCDB_PTO = "DOCDB";
    private static final String DATA_XPATH = "exch:exchange-documents/exch:exchange-document";
    
    // 
    private static final String DATA_FILE_DIR = "T:\\docdb\\test\\data";
    private static final String ERROR_FILE_DIR = "T:\\docdb\\test\\error";
    
    private static Element root;
    
    public static void main(String[] args) throws IOException {
        
        // 
        long startTime = System.nanoTime();
        
        DOCDBImporterByTony rdPaser = new DOCDBImporterByTony();
        
        // 
        rdPaser.parser(new File(DATA_FILE_DIR));
        
        long estimatedTime = System.nanoTime() - startTime;
        
        logger.info("estimatedTime = "
                + TimeUnit.SECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS) + "s");
        
    }
    
    /**
     * 
     * @param dir
     * @throws IOException
     */
    public void parser(File dir) throws IOException {
        
        // TODO: mongodb connection util ???
        MongoCredential credential = MongoCredential.createMongoCRCredential(
                "patentdata", "admin", "data.cloud.Abc12345".toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress(
                "10.60.90.155", 27017), Arrays.asList(credential));
        
        DBCollection collection = mongoClient.getDB("PatentRawDOCDB")
                .getCollection("PatentRawDOCDB");
        
        if (dir.exists()) {
            
            File[] fileList = dir.listFiles();
            
            if (fileList != null && fileList.length > 0) {
                
                for (File file : fileList) {
                    
                    if(FilenameUtils.isExtension(file.getName(), "xml")) {
                        
                        logger.debug("start parse file: " + file.getAbsolutePath());
                        
                        try {
                            
                            Document doc = loadXMLFile(file);
                            Date docdbDoDate = getDocDbDodate();
                            
                            @SuppressWarnings("unchecked")
                            List<Element> dataList = doc.selectNodes(DATA_XPATH);
                            
                            if (dataList != null && dataList.size() > 0) {
                                for (int i=0; i < dataList.size(); i++) {
                                    Element ele = dataList.get(i);
                                    //path = 檔名+/+docId ,設為LV1 PK
                                    String path =  file.getName() + "/" + ele.attributeValue("doc-id");
                                    collection.remove(new BasicDBObject("path", path));
                                    Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
                                    dataMap.put("pto", DOCDB_PTO);
                                    dataMap.put("path", path);
                                    BasicDBObject data = new BasicDBObject();
                                    
                                    data.put("xml", ele.asXML());
                                    
                                    dataMap.put("data", data);
                                    dataMap.put("type", "xml/xml");
                                    dataMap.put("provider", "DOCDB");
                                    // TODO: docdbDoDate meaning ??? 
                                    dataMap.put("docdbDoDate", docdbDoDate);
                                    dataMap.put("truncate", false);
                                    
                                    // add country
                                    dataMap.put("country", ele.attributeValue("country"));
                                    
                                    collection.insert(new BasicDBObject(dataMap));
                                    
                                    logger.debug("save path " + path + " ==> " + (i+1) + "/" + dataList.size());
                                }
                            }
                            
                        } catch (DocumentException dex) {
                            
                            logger.error(dex.getMessage());
                            
                            writeErrorLog(file.getName(), dex.getMessage());
                            
                        } finally {
                            
                            // TODO: 存取完後是否要刪除資料 ??? 因為現在連在解析XML有錯誤時也會一併刪除處理資料 ???
                            FileUtils.deleteQuietly(file);
                            
                        }
                        
                    } else {
                        
                        String errorMsg = file.getName() +" 檔案非XML: ";
                        logger.error(errorMsg);
                        writeErrorLog(file.getName(), errorMsg);
                        continue;
                        
                    }
                }
                
                logger.debug("parse xml finish ~!");
                
            } else {
                logger.debug(dir.getAbsolutePath() + " is empty");
            }
            
        } else {
            logger.debug(dir.getAbsolutePath() + " folder not exists~!");
        }
        
    }
    
    /**
     * 從root取得docDodate
     * @return
     */
    public Date getDocDbDodate() {
        return DateUtils.parseDate(root.attribute("date-of-exchange").getText());
        
    }
    
    /**
     * 寫入錯誤訊息
     * @param errorDir
     * @param prefix
     * @param errorMsg
     * @throws IOException
     */
    public void writeErrorLog(String prefix, String errorMsg) throws IOException {
        File errorFile = new File(ERROR_FILE_DIR + File.separator + prefix + "_error.log");
        FileUtils.writeStringToFile(errorFile, errorMsg , errorFile.exists());
    }
    
    /** 
     * TODO: 在讀取大檔時, 會佔用大多時間 ???
     * 
     * 指定的檔案路徑 讀取XML檔案 
     * @throws DocumentException 
     * 
     */
    public static Document loadXMLFile(File xmlFile) throws DocumentException {
        Document doc = null;
        SAXReader saxReader = new SAXReader();
        saxReader.setEntityResolver(new EntityResolver() {
            @Override
            public InputSource resolveEntity(String publicId, String systemId)
                    throws SAXException, IOException {
                if (systemId.contains("docdb-entities.dtd")) {
                    return new InputSource(new StringReader(""));
                } else {
                    return null;
                }
            }
        });
        doc = saxReader.read(xmlFile);
        root = doc.getRootElement();
        return doc;
    }   
    
    
}
