package patent.docdb.importer;

import itec.patent.common.DateUtils;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tsaikd.java.utils.ArgParser;
import org.utils.DateUtil;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * @author mikelin
 * @author tonykuo
 *
 */
public class DOCDBImporter {
	
	static Logger logger = LoggerFactory.getLogger(DOCDBImporter.class);
	
	private static final Date v244EndDate = DateUtil.parseDate("2015-05-08");
    private static final Date v253EndDate = DateUtil.parseDate("2015-10-08");
	
	private static final String DOCDB_PTO = "DOCDB";
	private static final String DATA_XPATH = "exch:exchange-documents/exch:exchange-document";
	private static final String MONGODB_IP = "mongodb.ip";
	
	private static final String MONGODB_IP_DEFAULT = "127.0.0.1";
	
	private static final String XML_FILE_DIR = "xml.dir";
	// TODO: 每期資訊 Cr-Del or Amend
	private static final String XML_FILE_DIR_DEFAULT = "D:/share/docdb/Amend/201609/unzip";
	
	// private static final String ZIP_FILE_DIR = "zip.dir";
	// private static final String ZIP_FILE_DIR_DEFAULT = "T:\\test\\docdb\\source\\";
	
	private static final String LOG_DIR = "log.dir";
	private static final String LOG_DIR_DEFAULT = "D:/share/docdb/logs";
	
	private static final String UNZIP_FILE_LIST_DIR = "unzip.list";
	private static final String UNZIP_FILE_LIST_DIR_DEFAULT = "D:/share/docdb/logs/unzip";
	
	private static final String REMOVE_FLAG = "remove.flag";
	private static final String REMOVE_FLAG_DEFAULT = "true";	
	
	private static final String SYSTEM_ID = "docdb-entities.dtd";
	private static final String DATE_OF_EXCHANGE = "date-of-exchange";
	private static final String DOC_ID = "doc-id";
	
	private static Element root;
	
    public static ArgParser.Option[] opts = {
    	new ArgParser.Option(null, MONGODB_IP, true, MONGODB_IP_DEFAULT,"mongodb ip: "),
        new ArgParser.Option(null, XML_FILE_DIR, true, XML_FILE_DIR_DEFAULT,"xml locate: "),
        // new ArgParser.Option(null, ZIP_FILE_DIR, true, ZIP_FILE_DIR_DEFAULT,"zip locate: "),
        new ArgParser.Option(null, LOG_DIR, true, LOG_DIR_DEFAULT,"log locate :"),
        new ArgParser.Option(null, UNZIP_FILE_LIST_DIR, true, UNZIP_FILE_LIST_DIR_DEFAULT,"unzip list log locate :"),
        new ArgParser.Option(null, REMOVE_FLAG, true, REMOVE_FLAG_DEFAULT,"remove duplicate data :"),
            
    };
    
	public DOCDBImporter() {
		
	}
	
	public static void main(String[] args) throws Exception {
		DOCDBImporter rdPaser = new DOCDBImporter();
//		rdPaser.parserFromZip(args);
		rdPaser.parseFromXml(args);
	}
	
 	public void parseFromXml(String[] args) throws Exception {
 	    
 		Date start = new Date();
 		ArgParser argParser = new ArgParser().addOpt(DOCDBImporter.class).parse(args);
 		//show args
 		logger.debug("start, opt: " + argParser.getParsedMap());
 		
 		// TODO: mongo db setting / 101, datateamdocdb, whsfciaewms
 		String ac = "datateamdocdb";
 		String pd = "whsfciaewms";
 		String mongoIp = "10.60.90.101";
 		
 		logger.debug(ac +", " + pd);
 		File dataDir = new File(argParser.getOptString(XML_FILE_DIR));
 		
 		boolean removeFlag = argParser.getOptBoolean(REMOVE_FLAG);
 		
 		MongoCredential credential = MongoCredential.createCredential(ac, "admin", pd.toCharArray());
 		
		MongoClient mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
		
		SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
		Date today = new Date();
		
		String parseLogPath = argParser.getOptString(LOG_DIR) + File.separator + sf2.format(today) + "_parse.log";
		String errorLogPath = argParser.getOptString(LOG_DIR) + File.separator + sf2.format(today) + "_error.log";
		String unzipListPath = argParser.getOptString(UNZIP_FILE_LIST_DIR) + File.separator + "unzip_list.log";
		
		if (dataDir.exists()) {
			File[] fileList = dataDir.listFiles();
			
			if (fileList != null && fileList.length > 0) {
			    
				for (File file : fileList) {
				    
					logger.debug("start parse file: " + file.getAbsolutePath());
					
					int totalCnt = 0;
			        int errorCnt = 0;
			        int currentCnt = 0;
					
					// TDOO : by country ??? execute bulk
					String cc =  file.getName().split("-")[4];
                    if (cc.length() != 2) {
                        throw new Exception(cc + " = country code error");
                    }
                    System.out.println("country = " + cc);
			        DBCollection collection = mongoClient.getDB("DocdbRawData").getCollection("DocdbRawData" + cc);
			        DBCollection errCollection = mongoClient.getDB("DocdbRawData").getCollection("ErrorDocdbRawData");
			        
			        //BulkWriteOperation 批次處理
			        BulkWriteOperation builder = collection.initializeOrderedBulkOperation();
			        //errorCollection insert
			        BulkWriteOperation errorBuilder = errCollection.initializeOrderedBulkOperation();
					
					if(FilenameUtils.isExtension(file.getName(), "xml")) {
						File unzipListFile = new File(unzipListPath);
						
						//建立unzip_list.log
						if (!unzipListFile.exists()) {
							logger.info(unzipListPath + " does not exists, build it");
							writeLog(unzipListPath, "");
						}
						
						//執行時需比對曾經parse的xml
						boolean isParsed = false;
						for (String unzipFile : FileUtils.readLines(unzipListFile)) {
							if(StringUtils.equals(unzipFile, file.getName())) {
								logger.debug("file " + file.getName() + " has already unzip!");
								isParsed = true;
							}
						}
						
						if (isParsed) {
							continue;
						}
						
						//將xml檔名寫入unzipList
						writeLog(unzipListFile.getAbsolutePath(), file.getName() + "\r\n");
						
						try {
							Date parseStart = new Date();
							Document doc = loadXMLFile(file);
							Date parseEnd = new Date();
							long diff = parseEnd.getTime() - parseStart.getTime();
							String parseMsg = sf1.format(new Date()) + " " + file.getName() + "==> parse spend time : " + diff / 1000 + " seconds";
							logger.debug(parseMsg);
							
							writeLog(parseLogPath, parseMsg + "\r\n");
							
							// After execution, you cannot re-execute the Bulk() object without reinitializing
							builder = collection.initializeOrderedBulkOperation();
							errorBuilder = errCollection.initializeOrderedBulkOperation();
							
							//DocDbDoDate parse
					 		Date docdbDoDate = getDocDbDodate();
					 		
					 		@SuppressWarnings("unchecked")
                            List<Element> nodes = doc.selectNodes(DATA_XPATH);
					 		
					 		totalCnt = nodes.size();
					 		
					 		if (nodes != null && nodes.size() > 0) {
					 			for (int i=0; i < nodes.size(); i++) {
					 				
					 				Element ele = nodes.get(i);
					 				
					 				//path = 檔名+/+docId ,設為LV1 PK
                                    String path =  file.getName() + "/" + ele.attributeValue(DOC_ID) + "/" + ele.attributeValue("status");
					 				
					 				//when doc-id is null, write into error collection
									if (ele.attributeValue(DOC_ID) == null) {
									    
										errorCnt++;
										String errMsg = file.getName() + "'s "
												+ (i + 1)
												+ " data does not have doc-id, skip it and write into ErrorPatentRawDOCDB";
										logger.error("error: " + errMsg);
										writeLog(errorLogPath, file.getName()
												+ " : " + errMsg + "\r\n");
										
										//先刪除現有的資料，避免重複insert
	                                    if (removeFlag) {
	                                        errCollection.remove(new BasicDBObject("_id", path));
	                                    }
										
										errorBuilder.insert(new BasicDBObject(getErrorMap(ele, file.getName(), docdbDoDate)));
										
										continue;
									}
								    
								    //先刪除現有的資料，避免重複insert
								    if (removeFlag) {
								    	collection.remove(new BasicDBObject("_id", path));
								    }
								    
								    currentCnt++;
                                    builder.insert(new BasicDBObject(getDataMap(ele, file.getName(), path, docdbDoDate)));
                                    
                                    if ((i+1) % 500 == 0) {
                                    	logger.debug("save path " + path + " ==> " + (i+1) + "/" + totalCnt);
                                    } else if ((i+1) == nodes.size()){
                                    	logger.debug("save path " + path + " ==> " + (i+1) + "/" + totalCnt);
                                    }
					 			}
					 		}
					 		
					 		logger.debug("bulk processing , please wait ...");
					 		//if no operations ,will throws exception
					 		if (errorCnt > 0) {
					 			errorBuilder.execute();
					 		}
					 		
					 		if (currentCnt > 0) {
					 		   builder.execute();
					 		}
							
						} catch (DocumentException dex) {
							logger.error("error - : " + dex);
							writeLog(errorLogPath, file.getName() + " : " + dex + "\r\n");
						} catch (Exception ex) {
							logger.error("error + : " + ex);
							writeLog(errorLogPath, file.getName() + " : " + ex + "\r\n");
						} finally {
							//FileUtils.deleteQuietly(file);
						}
						
						Date end = new Date();
						long diff = end.getTime() - start.getTime();
						String msg = sf1.format(new Date()) + " " + file.getName() + "==> total spend time : " + diff / 1000 + " seconds , data counts: " + totalCnt;
						logger.debug(msg);
						
						writeLog(parseLogPath, msg + "\r\n");
						
					} else {
						String errorMsg = file.getName() +" is not xml file!";
						logger.error(errorMsg);
						writeLog(errorLogPath, errorMsg + "\r\n");
						continue;
					}  // end if(FilenameUtils.isExtension(file.getName(), "xml"))
					
				}
				
			} else {
				logger.debug(dataDir.getAbsolutePath() + " is empty");
			}
			
		} else {
			logger.debug(dataDir.getAbsolutePath() + " folder not exists~!");
		}
		logger.debug("parse xml finish ~!");
	}
 	
 	/**
 	 * 取得檔案來源
 	 * 0 : back, 1 : CreateDelete, 2 : Amend, 3: REPLACEMENT
 	 * @param fileName
 	 * @return
 	 */
 	public int getFileType(String fileName){
 		
 		int fileType = 0;
 		
 		if (fileName.contains("CreateDelete")) {
 			fileType = 1;
 		}
 		if (fileName.contains("Amend")) {
 			fileType = 2;
 		}
 		if (fileName.contains("REPLACEMENT")) {
 			fileType = 3;
 		}
 		return fileType;
 	}
 	
 	
	/**
	 * 從root取得docDodate
	 * 
	 * @return
	 */
	public Date getDocDbDodate() {
		String docdbDodate = "";
		
		if (root.attribute(DATE_OF_EXCHANGE) == null) {
			docdbDodate = "00000000";
		} else {
			docdbDodate = root.attribute(DATE_OF_EXCHANGE).getText();
		}
		
		//IF DATE_OF_EXCHANGE 為00000000 回傳 西元1970年01月01日
		if (docdbDodate.equals("00000000")){
			return DateUtils.parseDate("19700101");
		} else {
			return DateUtils.parseDate(docdbDodate);
		}

	}
 	
 	/**
 	 * 寫入訊息
 	 * @param logFilePath
 	 * @param msg
 	 * @throws IOException
 	 */
 	public void writeLog(String logFilePath, String msg) throws IOException {
 		File logFile = new File(logFilePath);
 		FileUtils.writeStringToFile(logFile, msg , logFile.exists());
 	}
 	
 	/** 從指定的檔案路徑 讀取XML檔案 
 	 * @throws DocumentException */
    public static Document loadXMLFile(File xmlFile) throws DocumentException {
    	Document doc = null;
        SAXReader saxReader = new SAXReader();
        saxReader.setEntityResolver(new EntityResolver() {
			@Override
			public InputSource resolveEntity(String publicId, String systemId)
					throws SAXException, IOException {
				if (systemId.contains(SYSTEM_ID)) {
	                return new InputSource(new StringReader(""));
	            } else {
	                return null;
	            }
			}
		});
        doc = saxReader.read(xmlFile);
        root = doc.getRootElement();
        return doc;
    }   
    
    /**
     * 組出存入PatentDOCDB collection 的資訊
     * @param ele
     * @param fileName
     * @param path
     * @param docdbDoDate
     * @return
     */
    private Map<String, Object> getDataMap(Element ele, String fileName, String path, Date docdbDoDate) {
        
        Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
        
        dataMap.put("_id", path);
        
        dataMap.put("pto", DOCDB_PTO);
        // dataMap.put("path", path);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        dataMap.put("data", data);
        
        dataMap.put("type", "xml/xml");
        dataMap.put("provider", "EPO Purchase");
        dataMap.put("docdbDoDate", docdbDoDate);
        
        // hard code: truncate : false,
        dataMap.put("truncate", false);
        dataMap.put("country", ele.attributeValue("country"));
        dataMap.put("fileType", getFileType(fileName));
        dataMap.put("status", ele.attributeValue("status"));
        
        BasicDBObject mongoSyncData = new BasicDBObject();
        mongoSyncData.put("init", new Date());
        mongoSyncData.put("last", new Date());
        dataMap.put("mongoSyncFlag", mongoSyncData);
        
        // add kindCode
        dataMap.put("kindcode", ele.attributeValue("kind"));
        
        // TODO: refactor
        BasicDBObject tag = new BasicDBObject();
        tag.put("file", "DocdbRawDataImport.groovy");
        tag.put("version", "v1.0.0");
        dataMap.put("tag", tag);
        
        if (docdbDoDate.compareTo(v244EndDate) <= 0) {
            dataMap.put("xsd", "v2.4.4");
        } else if (docdbDoDate.compareTo(v244EndDate) > 0 && docdbDoDate.compareTo(v253EndDate) <= 0) {
            // Cr-Del\Amend 201520 ~ 201541 v2.5.3 => 20150508 ~ 20151008
            dataMap.put("xsd", "v2.5.3");
        } else {
            // Cr-Del\Amend 201542 ~ 201551 v2.5.4 => 20151009 ~
            dataMap.put("xsd", "v2.5.4");
        }
        
    	return dataMap;
    }
    
    /**
     * 組出存入ErrorPatentDOCDB collection 的資訊
     * @param ele
     * @param fileName
     * @return
     */
    private Map<String, Object> getErrorMap(Element ele, String fileName, Date docdbDoDate) {
    	
        Map<String, Object> errorMap = new LinkedHashMap<String, Object>();
        
        String cc = ele.attributeValue("country");
        
        String docNumber = "";
        if (ele.attributeValue("doc-number") != null) {
            docNumber = ele.attributeValue("doc-number");
        }
        
        String kindcode = "";
        if (ele.attributeValue("kind") != null) {
            kindcode = ele.attributeValue("kind");
        }
        
        String path = fileName + "/" + cc + docNumber + kindcode;
        
        errorMap.put("_id", path);
        
        errorMap.put("doDate", new Date());
        errorMap.put("errHandle", false);
        //
        BasicDBObject errDoc = new BasicDBObject();
        errDoc.put("country", ele.attributeValue("country"));
        // errDoc.put("path", path);
        errDoc.put("docNumber", ele.attributeValue("doc-number"));
        errDoc.put("kindcode", ele.attributeValue("kind"));
        errorMap.put("doc", errDoc);
        //
        errorMap.put("country", cc);
        errorMap.put("docdbDoDate", docdbDoDate);
        
        BasicDBObject data = new BasicDBObject();
        data.put("xml", ele.asXML());
        errorMap.put("data", data);
        
        errorMap.put("fileType", getFileType(fileName));
        
        // TODO: refactor
        BasicDBObject tag = new BasicDBObject();
        tag.put("file", "DocdbRawDataImport.java");
        tag.put("version", "v1.0.0");
        errorMap.put("tag", tag);
        
        // TODO: refactor ???
        if (docdbDoDate.compareTo(v244EndDate) <= 0) {
            errorMap.put("xsd", "v2.4.4");
        } else if (docdbDoDate.compareTo(v244EndDate) > 0 && docdbDoDate.compareTo(v253EndDate) <= 0) {
            // Cr-Del\Amend 201520 ~ 201541 v2.5.3 => 20150508 ~ 20151008
            errorMap.put("xsd", "v2.5.3");
        } else {
            // Cr-Del\Amend 201542 ~ 201551 v2.5.4 => 20151009 ~
            errorMap.put("xsd", "v2.5.4");
        }
        
        BasicDBObject mongoSyncData = new BasicDBObject();
        mongoSyncData.put("init", new Date());
        mongoSyncData.put("last", new Date());
        errorMap.put("mongoSyncFlag", mongoSyncData);
		
		return errorMap;
    }
    
}
