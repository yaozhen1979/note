package patent.util;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

//import org.json.JSONException;
//import org.json.JSONObject;
//import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.util.JSON;

public class Xml2JsUtil {

	static Logger log = LoggerFactory.getLogger(Xml2JsUtil.class);

	public static int PRETTY_PRINT_INDENT_FACTOR = 4;

	public static void main(String[] args) throws Exception {

		MongoCredential credential = MongoCredential.createMongoCRCredential(
				"patentdata", "admin", "data.cloud.Abc12345".toCharArray());
		MongoClient mongoClient = new MongoClient(new ServerAddress(
				"127.0.0.1", 27017), Arrays.asList(credential));
		DBCollection testCollection = mongoClient.getDB("test").getCollection(
				"test");
		DBCollection collection = mongoClient.getDB("PatentRawDOCDB")
				.getCollection("PatentRawDOCDB");
		String path = "DOCDB-201511-012-JP-0001.xml/391984364";
		DBCursor curosr = collection.find(new BasicDBObject("path", path));
		DBObject dataSrc = curosr.next();
		DBObject dataXml = (DBObject) dataSrc.get("data");
		
		Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
		
//		try {
//			dataMap.put("exch", parseXml2DBObject(dataXml.get("xml").toString()));
//        } catch (JSONException je) {
//        	log.error("error happened when parse raw data xml: " + je.toString());
//        } catch (Exception ex) {
//        	log.error("error happened when parse raw data xml: " + ex.getMessage());
//        }
		
		testCollection.insert(new BasicDBObject(dataMap));

		log.info("finish");
	}

	/**
	 * parse xml to DBObject
	 * 
	 * @param xml
	 * @return
	 */
	public static DBObject parseXml2DBObject(String xml) throws Exception {

		// String jsonStr = parseXml2JsonStr(xml);

		return (DBObject) JSON.parse(null);
	}

	/**
	 * parse xml to json string
	 * 
	 * @param xml
	 * @return
	 */
	public static String parseXml2JsonStr(String xml) throws Exception {

//		JSONObject xmlJSONObj = XML.toJSONObject(xml);
//		String jsonPrettyPrintString = xmlJSONObj
//				.toString(PRETTY_PRINT_INDENT_FACTOR);

		return null;

	}
}
