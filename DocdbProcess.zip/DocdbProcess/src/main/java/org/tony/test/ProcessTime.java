package org.tony.test;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProcessTime {

    public static Logger logger = LoggerFactory.getLogger(ProcessTime.class);

    public static void main(String[] args) throws InterruptedException {

        long startTime = System.nanoTime();
        logger.info("startTime...");
        //
        Thread.sleep(new Long(3000));

        long estimatedTime = System.nanoTime() - startTime;

        logger.info("estimatedTime = "
                + TimeUnit.SECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS));

    }

}
