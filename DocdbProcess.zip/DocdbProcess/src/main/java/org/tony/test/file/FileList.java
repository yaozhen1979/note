package org.tony.test.file;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileList {
    
    public static Logger logger = LoggerFactory.getLogger(FileList.class);

    public static List<String> fileList(String directory) {
        List<String> fileNames = new ArrayList<>();
        try (DirectoryStream<Path> directoryStream = Files
                .newDirectoryStream(Paths.get(directory))) {
            for (Path path : directoryStream) {
                logger.info(path.getParent().getFileName() + "\\" + path.getFileName());
                fileNames.add(path.toString());
            }
        } catch (IOException ex) {
        }
        return fileNames;
    }
    
    public static List<String> fileCrDelList(String directory) {
        List<String> fileNames = new ArrayList<>();
        try (DirectoryStream<Path> directoryStream = Files
                .newDirectoryStream(Paths.get(directory))) {
            for (Path path : directoryStream) {
                
                if (path.toFile().isDirectory()) {
                    
                    fileList(path.toString());
                    
                } else {
                    
                    fileNames.add(path.toString());
                    
                }
                
            }
        } catch (IOException ex) {
        }
        return fileNames;
    }

    public static void main(String[] args) {
        
        // //10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/backfile
        // //10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/Amend/2015
        
        // //10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/Cr-Del/2015
        // fileCrDelList("//10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/Cr-Del/2015");
        
        // //10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/DOCDB REPLACEMENT_FAM
        // fileList("//10.62.41.110/rawdata/patentsource/originaldata/EP/docdb/download/DOCDB REPLACEMENT_FAM");
        
        for(String arg : args) {
            // System.out.println("arg = " + arg);
        }
        
        fileList("T:/cnlist/rawdata/FM/20150513");
        
        System.out.println("finished");
    }

}
