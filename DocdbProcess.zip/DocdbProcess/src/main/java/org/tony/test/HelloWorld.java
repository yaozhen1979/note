package org.tony.test;

public class HelloWorld {
    
    public String sayHelloWorld() {
        return "hello world";
    }
    
}
