package org.tony.test.logback;

import org.tony.test.TestBase;

public class HelloLogback1 extends TestBase {

    public String sayHello() {
        
        logger.info("something...");
        
        return "hello";
    }
    
}
