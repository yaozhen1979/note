# 在 solr vm 上裝 munin-node

```
ap-get install munin-node
```

# 將 plugins 拷貝到 munin plugins 目錄

```
rsync ./plugins/ /usr/share/munin/plugins/
``` 

# 用 ln 安裝 munin plugin

```
//安裝監控 gc count 的 plugin
ln -s /usr/share/munin/plugins/jstat__gccount /etc/munin/plugins/jstat_solr_gccount
//安裝監控 gc 時間的 plugin
ln -s /usr/share/munin/plugins/jstat__gctime /etc/munin/plugins/jstat_solr_gctime
//安裝監控 java heap 狀況的 plugin
ln -s /usr/share/munin/plugins/jstat__heap /etc/munin/plugins/jstat_solr_heap
//安裝監控 solr 記憶體狀況的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_memory
//安裝監控 solr 索引大小的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_indexsize
//安裝監控 solr qps (query per second) 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_qps
//安裝監控平均 request time 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_requesttimes_select
//安裝監控某個 core 的 doc num 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_numdocs_corename
//安裝監控某個 core 的 qps 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_qps_us_select
//安裝監控某個 core 的 document cache 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_documentcache_us
//安裝監控某個 core 的 field value cache 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_fieldvaluecache_us
//安裝監控某個 core 的 filter cache 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_filtercache_us
//安裝監控某個 core 的 queryresult cache 的 plugin
ln -s /usr/share/munin/plugins/solr4_ /etc/munin/plugins/solr_queryresultcache_us
```

# 拷貝 plugin 的設定檔

```
cp ./plugin-conf.d/munin-node /etc/munin/plugin-conf.d/munin-node
```

# 修改 munin-node 的設定檔，讓 munin server 可以存取

```
vi /etc/munin/munin-node.conf
```

加入

```
#10.62.41.134 為 munin-server ip
allow ^10\.62\.41\.134$
```

# 重啟 munin-node
```
/etc/init.d/munin-node restart
```
