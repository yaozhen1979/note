package com.patentcloud.vo.query;

import itec.patent.mongodb.Pto;

import java.util.Date;

import org.bson.types.ObjectId;
import org.tsaikd.java.mongodb.MongoObject;

public class ImagePatent extends MongoObject {
    
    public Pto pto;

    public ObjectId id;
    
    public String patentNumber;
    
    public Date doDate;
    
    public Integer filePageNumber;

    public Integer clipPageNumber;
    
    public Integer figurePageNumber;
    
    public boolean firstImagePageFlag = false;
}
