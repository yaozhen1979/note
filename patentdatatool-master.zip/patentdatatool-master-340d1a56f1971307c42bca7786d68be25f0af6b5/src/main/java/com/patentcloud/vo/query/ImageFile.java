package com.patentcloud.vo.query;

import java.util.ArrayList;

import org.tsaikd.java.mongodb.MongoObject;

public class ImageFile extends MongoObject {
    
    public String name;
    
    public ArrayList<ImageFile> childs = new ArrayList<>();
    
    public ImageFile(String name) {
        this.name = name;
    }
}
