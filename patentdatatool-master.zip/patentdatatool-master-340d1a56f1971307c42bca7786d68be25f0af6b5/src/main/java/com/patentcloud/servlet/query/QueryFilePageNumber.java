package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.servlet.JSonOutput;

import com.mongodb.DBCollection;
import com.mongodb.QueryOperators;
import com.patentcloud.utils.MongoUtils;

@WebServlet(urlPatterns = "/QueryFilePageNumber")
public class QueryFilePageNumber extends HttpServlet {
    
    static Log log = LogFactory.getLog(QueryFilePageNumber.class);
    private static final long serialVersionUID = 1L;  
    
    @SuppressWarnings("unused")
    private static class Output extends JSonOutput {
        public Pto pto;
        public String dateRange;
        public Integer patentCount;
        public Integer pageNumberCount;
        public Integer gap;
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output output = new Output();
        try {
            Pto pto = Pto.valueOf(req.getParameter("pto").toUpperCase());
            String startDate = req.getParameter("startDate");
            String endDate = req.getParameter("endDate");
            
            output.pto = pto;
            output.dateRange = startDate + "-" + endDate;
            
            DBCollection col = PatentInfo2.getCollection(pto);
            QueryHelp query = MongoUtils.getDateRange(output.dateRange);
            log.debug(query.toString());
            long patentCount = col.count(query);
            output.patentCount = (int) patentCount;
            
            query.filter("filePageNumber", new QueryHelp(QueryOperators.GT, 0));
            log.debug(query.toString());
            long pageNumberCount = col.count(query);
            output.pageNumberCount = (int) pageNumberCount;
            output.gap = output.pageNumberCount - output.patentCount;
            
            output.write(res);
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
}
