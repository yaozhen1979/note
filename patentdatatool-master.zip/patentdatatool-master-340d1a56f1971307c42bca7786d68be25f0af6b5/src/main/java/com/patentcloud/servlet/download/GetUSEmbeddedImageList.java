package com.patentcloud.servlet.download;

import itec.util.HttpUtil;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;
import org.tsaikd.java.utils.ConfigUtils;

import com.patentcloud.utils.FormatUtils;
import com.patentcloud.vo.download.USEmbeddedFile;

@WebServlet(urlPatterns = "/GetUSEmbeddedImageList")
public class GetUSEmbeddedImageList extends HttpServlet {
    
    static Log log = LogFactory.getLog(GetUSEmbeddedImageList.class);
    private static final long serialVersionUID = 1L;
    
    private static String pubUrl = "http://www.google.com/googlebooks/uspto-patents-applications-text-with-embedded-images.html";
    private static String grantUrl = "http://www.google.com/googlebooks/uspto-patents-redbook.html";
    
    private static class Output2 extends JSonOutput {
        public List<USEmbeddedFile> data = new ArrayList<>();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output2 output = new Output2();
        
        String type = req.getParameter("type");
        String year = req.getParameter("year");
        String content = "";
        try {
            switch (type) {
            case "Publication":
                content = HttpUtil.getResponseAsString(pubUrl);
                break;
            case "Grant":
                content = HttpUtil.getResponseAsString(grantUrl);
                break;
            default:
                throw new IllegalArgumentException("Invalid Patent Type");
            }
            
            Matcher mat = Pattern.compile("<h3.*?>" + year + "</h3>(.*?)(<h3|<div).*?", Pattern.DOTALL).matcher(content);
            if (mat.find()) {
                content = mat.group(1);
                mat = Pattern.compile("<a href=\"(.*?)\">(.*?)</a>", Pattern.DOTALL).matcher(content);
                while (mat.find()) {
                    USEmbeddedFile embFile = new USEmbeddedFile();
                    embFile.fileName = mat.group(2).trim();
                    embFile.url = mat.group(1);
                    
                    if (embFile.fileName.contains("SUPP")) {
                        continue;
                    }
                    
                    String filePath = ConfigUtils.get("us.embeddedImage.origin.path") 
                            + File.separator + type
                            + File.separator + year
                            + File.separator + embFile.fileName;
                    File file = new File(filePath);
                    if (file.exists()) {
                        embFile.isDownload = true;
                        embFile.fileSize = FormatUtils.readableFileSize(file.length());
                        embFile.fileDate = new Date(file.lastModified());
                    }
                    
                    output.data.add(embFile);
                }
            }
            output.write(res);
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
}
