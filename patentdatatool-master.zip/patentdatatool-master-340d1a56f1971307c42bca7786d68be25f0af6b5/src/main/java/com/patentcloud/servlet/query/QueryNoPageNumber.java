package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.Pto;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.mongodb.QueryHelp;
import org.tsaikd.java.servlet.JSonOutput;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.patentcloud.utils.MongoUtils;
import com.patentcloud.vo.query.ImagePatent;

@WebServlet(urlPatterns = "/QueryNoPageNumber")
public class QueryNoPageNumber extends HttpServlet {
    
    static Log log = LogFactory.getLog(QueryNoPageNumber.class);
    private static final long serialVersionUID = 1L;  
    
    private static class Output extends JSonOutput {
        ArrayList<ImagePatent> imagePatents = new ArrayList<>();
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Output output = new Output();
        try {
            Pto pto = Pto.valueOf(req.getParameter("pto").toUpperCase());
            String dateRange = req.getParameter("dateRange");
            DBCollection col = PatentInfo2.getCollection(pto);
            
            PatentInfo2 info = null;
            QueryHelp noExistsQuery = MongoUtils.getDateRange(dateRange);
            noExistsQuery.filter("filePageNumber", new QueryHelp("$exists", false));
            log.debug(noExistsQuery.toString());
            DBCursor cursor = col.find(noExistsQuery).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                output.imagePatents.add(toImagePatent(info));
            }
            
            QueryHelp eqZeroQuery = MongoUtils.getDateRange(dateRange); 
            eqZeroQuery.filter("filePageNumber", 0);
            log.debug(eqZeroQuery.toString());
            cursor = col.find(eqZeroQuery).sort(new BasicDBObject("doDate", 1));
            while (cursor.hasNext()) {
                DBObject dbobj = cursor.next();
                info = PatentInfo2.fromObject(pto, dbobj);
                output.imagePatents.add(toImagePatent(info));
            }
            
            output.write(res);
        } catch (Exception e) {
            log.debug(e, e);
            res.sendError(468, e.getMessage());
            return;
        }
    }
    
    public ImagePatent toImagePatent(PatentInfo2 info) {
        ImagePatent imagePatent = new ImagePatent();
        imagePatent.pto = info.pto;
        imagePatent.id = info.id;
        imagePatent.patentNumber = info.patentNumber;
        imagePatent.doDate = info.doDate;
        imagePatent.filePageNumber = info.filePageNumber;
        return imagePatent;
    }
}
