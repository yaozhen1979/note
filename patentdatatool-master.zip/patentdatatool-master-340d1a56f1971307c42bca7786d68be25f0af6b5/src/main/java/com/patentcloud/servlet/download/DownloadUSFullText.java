package com.patentcloud.servlet.download;

import itec.util.HttpUtil;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.utils.ConfigUtils;

@WebServlet(urlPatterns = "/DownloadUSFullText")
public class DownloadUSFullText extends HttpServlet {
    
    static Log log = LogFactory.getLog(DownloadUSFullText.class);
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try {
            String type = req.getParameter("type");
            String year = req.getParameter("year");
            String url = req.getParameter("url");
            
            String target = String.format("%s/%s/%s/%s"
                    , ConfigUtils.get("us.fullText.origin.path")
                    , year
                    , type + "s"
                    , new File(url).getName());
            
            log.debug("start download: " + url + " target: " + target);
            HttpUtil.downloadFile(url, new File(target));
        } catch (Exception e) {
            log.debug(e, e);
            return;
        }
    }
}
