package com.patentcloud.servlet.query;

import itec.patent.mongodb.PatentInfo2;
import itec.patent.mongodb.PatentInfo2.PtoPid;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tsaikd.java.servlet.JSonOutput;
import org.tsaikd.java.utils.ConfigUtils;

import com.patentcloud.utils.MongoUtils;
import com.patentcloud.utils.PtoPidUtils;

@WebServlet(urlPatterns = "/GetImagePath")
public class GetImagePath extends HttpServlet {

	static Log log = LogFactory.getLog(GetImagePath.class);
	private static final long serialVersionUID = 1L; 
	
	private static class Output extends JSonOutput {
		@SuppressWarnings("unused")
		public String path = null;
	}
	 
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Output output = new Output();
		try {
			String pidStr = req.getParameter("ptopid");
			PtoPid ptopid = PtoPidUtils.getPtoPid(pidStr);
			
			PatentInfo2 info = PatentInfo2.findOne(ptopid.pto, ptopid.id, "pto", "patentNumber", "kindcode", "stat", "doDate");
			output.path = String.format("%s/%s/%s/%s"
                    , ConfigUtils.get("image.path")
                    , "patent_" + MongoUtils.ptoMap.get(info.pto.toString()).toLowerCase()
                    , "data"
                    , MongoUtils.getRelPatentPath(info));
			 output.write(res);
		} catch (Exception e) {
			log.debug(e, e);
			res.sendError(468, e.getMessage());
			return;
		}
	}
}
