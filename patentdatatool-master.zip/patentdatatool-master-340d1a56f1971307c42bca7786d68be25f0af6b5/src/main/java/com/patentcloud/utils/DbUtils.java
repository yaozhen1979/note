package com.patentcloud.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.logicalcobwebs.proxool.configuration.JAXPConfigurator;
import org.xml.sax.InputSource;

public class DbUtils {

    static {
        try {
            InputStream is = DbUtils.class.getResourceAsStream("/proxool.xml");
            JAXPConfigurator.configure(new InputSource(is), false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private ArrayList<String> columns = new ArrayList<String>();
    private ArrayList<Map<String, String>> data = new ArrayList<Map<String, String>>();
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    
    public void fetchData(String sql, String datasource) throws Exception {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName("org.logicalcobwebs.proxool.ProxoolDriver");
            conn = DriverManager.getConnection("proxool." + datasource);
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            toData(rs);
        } finally {
            try { rs.close(); } catch(Exception e) {}
            try { stmt.close(); } catch(Exception e) {}
            try { conn.close(); } catch(Exception e) {}
        }
    }
    
    private void toData(ResultSet rs) throws Exception {
        
        ResultSetMetaData rsmd = rs.getMetaData();
        for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            columns.add(rsmd.getColumnName(i));
        }
        while (rs.next()) {
            data.add(toRow(rs));
        }
    }
    
    private Map<String, String> toRow(ResultSet rs) throws Exception {
        Map<String, String> row = new HashMap<String, String>();
        ResultSetMetaData rsmd = rs.getMetaData();
        for (int i = 1; i <= rsmd.getColumnCount(); i++) {
            switch(rsmd.getColumnType(i)) {
               case Types.DATE:
                   Date d = rs.getDate(i);
                   if (d != null) {
                       row.put(rsmd.getColumnName(i), sdf.format(d));
                   } else {
                       row.put(rsmd.getColumnName(i), "");
                   }
                   break;
               default:
                   row.put(rsmd.getColumnName(i), StringUtils.defaultString(rs.getString(i)));
            }
        }
        return row;
    }

    public ArrayList<String> getColumns() {
        return columns;
    }

    public void setColumns(ArrayList<String> columns) {
        this.columns = columns;
    }

    public ArrayList<Map<String, String>> getData() {
        return data;
    }

    public void setData(ArrayList<Map<String, String>> data) {
        this.data = data;
    }
    
}
