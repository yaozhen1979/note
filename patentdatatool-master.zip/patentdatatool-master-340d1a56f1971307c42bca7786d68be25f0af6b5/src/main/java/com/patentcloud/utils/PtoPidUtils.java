package com.patentcloud.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;

import itec.patent.mongodb.PatentInfo2.PtoPid;
import itec.patent.mongodb.Pto;

public class PtoPidUtils {
    
    static Log log = LogFactory.getLog(PtoPidUtils.class);
    
    public static PtoPid getPtoPid(String pidStr) {
        String[] tem = pidStr.split("\\.");
        PtoPid ptopid = new PtoPid();
        ptopid.pto = Pto.valueOf(tem[0]);
        ptopid.id = new ObjectId(tem[1]);
        return ptopid;
    }
}
