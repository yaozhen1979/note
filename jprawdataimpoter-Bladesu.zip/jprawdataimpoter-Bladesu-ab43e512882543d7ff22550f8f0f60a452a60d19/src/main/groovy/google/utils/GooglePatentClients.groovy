package google.utils

import java.text.SimpleDateFormat


/**
 * 
 * 日本官網抓資料會被擋
 * 新增其他管道抓資料
 *
 */

class GooglePatentClients {
    def static  sdfGooglePatentDateParse = new SimpleDateFormat("yyyy-MM-dd")
    static {
        sdfGooglePatentDateParse.setTimeZone(TimeZone.getTimeZone("GMT"))
        System.properties << [ 'https.proxyHost': '10.60.94.21', 
                               'https.proxyPort': '3128',
                               'https.proxyUser': 'docker',
                               'https.proxyPassword': 'Abc.2015' ]
    }

    def static googlePatentUrl = "https://patents.google.com/patent/"
    def static getJPGrantPatentDoDate(certificatedNumber, kindcode) {
       def doc = org.jsoup.Jsoup.connect(googlePatentUrl + "JP" + certificatedNumber + kindcode + "/en").userAgent("Mozilla").get()
       return sdfGooglePatentDateParse.parse(doc.select("dl[class=key-dates]").select("dt:contains(Publication date) ~ dd").text())
    }

    public static void main(String []args) {
        getJPGrantPatentDoDate("4823606", "B2")
    }
}
