package fixId

import java.text.SimpleDateFormat

import wips.patent.utils.ProgressUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


def cli = new CliBuilder(
    usage: 'Fix id format',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
    c(longOpt: 'mongo.collection', 'PatentRawJPO', args: 1, required: true)
    k(longOpt: 'kindcide', 'A', args: 1, required: true)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
def collection = opt.c
def kindcode = opt.k

MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def col = mongoClient.getDB(collection).getCollection(collection)
def sdf = new SimpleDateFormat("yyyyMMdd")
def sortQuery = new BasicDBObject("doDate", 1)
def startDate = sdf.parse("19000331")
def endDate = sdf.parse("20130101")

def query = new BasicDBObject();
def dateQuery = new BasicDBObject();
dateQuery.append('''$gte''', startDate)
dateQuery.append('''$lte''', endDate)
query.append("kindcode", kindcode)
query.append("doDate", dateQuery)


def cursor = col.find(query).sort(sortQuery)
def len = cursor.count()
println len
def count = 0
wips.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
wips.patent.utils.ProgressUtils.latestPrintTime = wips.patent.utils.ProgressUtils.startTime
cursor.each { doc ->
    count++
    def matcher = doc['_id'] =~ /^(?i)JP/
    if(!matcher) {
        col.remove(doc)
        def id = doc['_id']
        doc['_id'] = "JP" + id
        col.save(doc)
    }
    ProgressUtils.printlnProgress(count, len, doc.doDate)
}

if(col.count(query) != len) {
    throw new Exception("fix id error")
}
mongoClient.close()