package wips.patent.importer
import wips.patent.utils.XmlImportUtils

import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//parser args
def cli = new CliBuilder(
    usage: 'import jp raw data (1993~2011) to mongo ',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    p(longOpt: 'rawdata.path', '\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\JP\\wips\\disk\\Application\\p'
                , args: 1, required: true)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def rawdataPath = opt.p
def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));

XmlImportUtils.rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
XmlImportUtils.errCol = mongoClient.getDB("PatentRawJPO").getCollection("ErrorPatentRawJPO")
XmlImportUtils.sdfDoDateParse.setTimeZone(TimeZone.getTimeZone("GMT"))

//測試用路徑 (application)
//rawdataPath  = "src" + File.separator + "test" + File.separator + "resources" + File.separator+ "wips" + 
//                File.separator + "patent" + File.separator + "application"+ File.separator +"sampleXml"
//測試用路徑 (grant)
//rawdataPath  = "src" + File.separator + "test" + File.separator + "resources" + File.separator+ "wips" +
//                File.separator + "patent" + File.separator + "grant"+ File.separator +"sampleXml"

def filelist = wips.patent.utils.XmlImportUtils.extractRawXml(new File(rawdataPath))
//filelist = [new File(rawdataPath + File.separator + "u" + File.separator + "0002605481.xml")]
//filelist = [new File("C:\\gitlab_project\\jprawdataimpoter\\src\\main\\resources\\garbled\\wips\\disk\\application\\p\\1994\\m04\\1994102498\\1994102498.xml")]

def count = 0
def len = filelist.size()
wips.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
wips.patent.utils.ProgressUtils.latestPrintTime = wips.patent.utils.ProgressUtils.startTime

filelist.each { file ->
    count++
    wips.patent.utils.XmlImportUtils.importFileToMongo(file, len, count)
    //println file
}
println "finished"
mongoClient.close()

