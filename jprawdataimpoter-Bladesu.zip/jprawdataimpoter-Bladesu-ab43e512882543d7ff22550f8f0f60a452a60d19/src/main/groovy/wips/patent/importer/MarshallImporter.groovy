package wips.patent.importer

import java.text.SimpleDateFormat

import wips.patent.utils.MarshallImportUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
//parser args
def cli = new CliBuilder(
        usage: 'import jp raw data (1993~2011) to mongo ',
        header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
    d(longOpt: 'statr.date', '2001/01/01', args: 1, required: true)
    e(longOpt: 'end.date', '2001/11/01', args: 1, required: true)
    k(longOpt: 'kindcode', 'A', args: 1, required: true)
    t(longOpt: 'timestmp', '20160111', args: 1, required: true)
    s(longOpt: 'number to skip', '100', args: 1, required: false)
    limit(longOpt: 'number to limit', '100', args: 1, required: false)
    loadList(longOpt: 'given _id list which separated by comma', '100', args: 1, required: false)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def startDate = sdf.parse(opt.d)
def endDate = sdf.parse(opt.e)
def kindcode = opt.k
def timeStmp = opt.t

MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")

MarshallImportUtils.errCol = mongoClient.getDB("PatentMarshallJPO").getCollection("ErrorPatentMarshallJPO")
MarshallImportUtils.marshallCol = mongoClient.getDB("PatentMarshallJPO").getCollection("PatentMarshallJPO")

// number to skip over
def skipN = 0
if (!!opt.s) {
    skipN = opt.s.toInteger()
}

// number to be the limit()

def limitN = 0
if (!!opt.limit) {
    limitN = opt.limit.toInteger()
}



// application of  loadList
def idList = null
if (opt.loadList) {
    idList = opt.loadList.split(',')
}

def patentStatus
if(kindcode == "A" || kindcode == "U") {
    patentStatus = "application"
} else if(kindcode == "A(公表)"){
    patentStatus = "t"
} else if(kindcode == "A1"){
    patentStatus = "s"
} else {
    patentStatus = "grant"
}




MarshallImportUtils.initMarshallImportUtils(patentStatus)

// apply _id list or time interval
if (!!idList){
    // (1) Apply _id list
    idList.each { id ->
        println "Process "+ id
        def doc = rawCol.findOne(new BasicDBObject("_id",id))
        def len = rawCol.count(new BasicDBObject("_id",id))
        def count = 1
        MarshallImportUtils.importMarshallToMongo(doc, timeStmp, "MarshallImporter.groovy")
    }
} else {
    // (2) Time interval
    // doc to query
    def query = new BasicDBObject();
    def dateQuery = new BasicDBObject();
    dateQuery.append('''$gte''', startDate)
    dateQuery.append('''$lte''', endDate)
    query.append("kindcode", kindcode)
    query.append("doDate", dateQuery)
    
    def sortQuery = new BasicDBObject("doDate", 1)
    
    println "query: " + query.toString()
    def cursor = rawCol.find(query).sort(sortQuery).limit(0).skip(skipN).limit(limitN)
    def len = cursor.count()
    def count = skipN;
    
    ProgressUtils.startTime = Calendar.instance.time.time
    ProgressUtils.latestPrintTime = ProgressUtils.startTime
    
    cursor.each { doc ->
        count++
        MarshallImportUtils.importMarshallToMongo(doc, timeStmp, "MarshallImporter.groovy", len, count)
    }
    
    
}

println "finished"
