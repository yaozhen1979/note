package wips.patent.importer.error
import wips.patent.utils.ProgressUtils
import wips.patent.utils.XmlImportUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress

//parser args
def cli = new CliBuilder(
    usage: 'extract xml path from ErrorDb and reimport data (1993~2011) to mongo ',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    p(longOpt: 'rootRawDir', '\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\JP\\', args: 1, required: true)
    t(longOpt: 'errordb.title', 'There are some error while fix xml'
                , args: 1, required: false)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def rootRawPath = opt.p
def errorTitle = opt.t
def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));

XmlImportUtils.rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
XmlImportUtils.errCol = mongoClient.getDB("PatentRawJPO").getCollection("ErrorPatentRawJPO")
XmlImportUtils.sdfDoDateParse.setTimeZone(TimeZone.getTimeZone("GMT"))

def query = new BasicDBObject()
if(errorTitle) {
    query.append("title", errorTitle)
}
def cursor = XmlImportUtils.errCol.find(query)
def separator = File.separator
if(separator.equals("\\")) {
    separator = "\\\\"
}
def len = cursor.count()
def count = 0
wips.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
wips.patent.utils.ProgressUtils.latestPrintTime = wips.patent.utils.ProgressUtils.startTime

//針對亂碼處理
File gardledDir = new File(ClassLoader.getSystemClassLoader().getResource("./garbled/wips/disk").getPath())
def garbledList = wips.patent.utils.XmlImportUtils.extractRawXml(gardledDir)

//SB tag no match
File sbTagNoMatchDir = new File(ClassLoader.getSystemClassLoader().getResource("./sbunmatched/wips/disk").getPath())
def sbTagNoMatchList = wips.patent.utils.XmlImportUtils.extractRawXml(sbTagNoMatchDir)

cursor.each  { errorDoc ->
    count++
    def errXmlPath = errorDoc.path
    errXmlPath = errXmlPath.replaceAll("/", separator)

    //讀取亂碼 xml 清單
    def isGarbled = garbledList.any() { grabledXml ->
        if(grabledXml.toString().endsWith(errXmlPath.toLowerCase())) {
            errXmlPath = grabledXml.toString()
            return true
        }
    }

    //讀取 SB tag 沒有 match 的 xml 清單
    def isSBTagNoMatched = sbTagNoMatchList.any() { subNoMatchXml ->
        if(subNoMatchXml.toString().endsWith(errXmlPath.toLowerCase())) {
            errXmlPath = subNoMatchXml.toString()
            return true
        }
    }

    if(isGarbled) { //處理有亂碼的 xml
        def file = new File(errXmlPath)
        wips.patent.utils.XmlImportUtils.importFileToMongo(file, len, count)
        XmlImportUtils.errCol.remove(errorDoc)
    } else if (isSBTagNoMatched) {
        def file = new File(errXmlPath)
        wips.patent.utils.XmlImportUtils.importFileToMongo(file, len, count)
        XmlImportUtils.errCol.remove(errorDoc)
    } else {  //處理其他異常
        errXmlPath = rootRawPath + File.separator + errXmlPath
        def oriFile = new File(errXmlPath)
        def contents = oriFile.getText('UTF-8')
        wips.patent.utils.XmlImportUtils.importFileToMongo(oriFile, len, count)
        XmlImportUtils.errCol.remove(errorDoc)
    }
    ProgressUtils.printlnProgress(count, len, errorDoc.createDate)
}
println "finished"
mongoClient.close()
