package wips.patent.importer.error

import wips.patent.utils.MarshallImportUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress

//parser args
def cli = new CliBuilder(
        usage: 'extract xml path from ErrorDb and reimport data (1993~2011) to mongo ',
        header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    t(longOpt: 'errordb.title', 'There are some error while fix xml'
    , args: 1, required: false)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
    s(longOpt: 'timestmp', '20160111', args: 1, required: true)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def errorTitle = opt.t
def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
def timeStmp = opt.s

MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")

MarshallImportUtils.errCol = mongoClient.getDB("PatentMarshallJPO").getCollection("ErrorPatentMarshallJPO")
MarshallImportUtils.marshallCol = mongoClient.getDB("PatentMarshallJPO").getCollection("PatentMarshallJPO")

def query = new BasicDBObject()
if(errorTitle) {
    query.append("title", errorTitle)
}

def cursor = MarshallImportUtils.errCol.find(query)
def len = cursor.count()
def count = 0
wips.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
wips.patent.utils.ProgressUtils.latestPrintTime = wips.patent.utils.ProgressUtils.startTime

cursor.each  { errorDoc ->
    count++
    def id = errorDoc.rawId
    def rawDoc = rawCol.findOne(new BasicDBObject("_id", id))
    def kindcode = rawDoc.kindcode
    def patentStatus
    if(kindcode == "A" || kindcode == "U") {
        patentStatus = "application"
    } else if(kindcode == "A1"){
        patentStatus = "s"
    } else if(kindcode == "A(公表)"){
        patentStatus = "t"
    } else {
        patentStatus = "grant"
    }
    MarshallImportUtils.initMarshallImportUtils(patentStatus)
    MarshallImportUtils.importMarshallToMongo(rawDoc, timeStmp, "MarshallImporterFromErrDb.groovy", len, count)
    MarshallImportUtils.errCol.remove(errorDoc)
}