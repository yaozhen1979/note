package wips.patent.utils

import google.utils.GooglePatentClients
import groovy.io.FileType

import java.text.SimpleDateFormat

import org.dom4j.io.SAXReader

import com.mongodb.BasicDBObject
import com.mongodb.DBObject

class XmlImportUtils {
    def static filesizeLimit = 2^16
    //def static filesizeLimit = 1024 * 2
    def static provider = "WIPS"
    def static pto = "JPO"
    def static type ="xml/xml"
    def static pathS_word = "/(?i)"+File.separator+"TS"+File.separator+"Application"+File.separator+"t/"
    def static pathT_word = "/(?i)"+File.separator+"TS"+File.separator+"Application"+File.separator+"s/"
    def static extractRawXml(dir) {
        println "extract raw data file list..."
        def list = []
        dir.eachFileRecurse (FileType.FILES) { file ->
            if (file =~ /(?i).*\.xml$/ ) {
                list << file
            }
        }
        return list
    }
    
    def static errCol
    def static saveErrObj(relatePath, title, e) {
        println title + ": " + relatePath
        def errObj = new BasicDBObject()
        errObj.append("createDate", new Date())
        errObj.append("path", relatePath)
        errObj.append("title", title)
        errObj.append("errMsg", e.getMessage())
        errCol.save(errObj)
    }
    
    def static rawCol
    def static saveRawObj(id, fileContents, doDate, relatePath, truncate, kindcode) {
        def rawObj = new BasicDBObject()
        rawObj.append("_id", id)
        
        // 確認之前有寫入同樣id但不同資料來源的話，不存入PatentRawJPO，而存該筆資料和錯誤資訊到ErrorPatentRawJPO.
        DBObject  queryObj = rawCol.findOne(rawObj)
        
        if(queryObj){
            String previousInserted = queryObj.get("path").toString()
            if(relatePath != previousInserted){
                saveErrObj(relatePath, id+" existed before.",
                new Exception(" Err: The _id has been inserted by other source:"+previousInserted))
                return
            }
        }
        
        
        rawObj.append("path", relatePath)
        rawObj.append("data", new BasicDBObject("xml", fileContents.toString()))
        rawObj.append("doDate", doDate)
        rawObj.append("kindcode", kindcode)
        rawObj.append("provider", provider)
        rawObj.append("pto", pto)
        rawObj.append("truncate", truncate)
        rawObj.append("type", type)
        
        // 若無法存入DB，則改存錯誤記錄到Error DB
        try{
            rawCol.save(rawObj)
        } catch (Exception e){
            saveErrObj(relatePath, "Fail to save doc to DB.", e)
        }
    }
    
    
    def static private formatedPatentId(pubNumber, kindcode, doDate) {
        // 新制度的實用新案 kindcode 有 "(新制)" 要拿掉
        kindcode = kindcode.replace("(新制)", "")
        // 公表的kincode，原本加上(公表)，在此階段，把該字樣刪除，使之恢復原狀。
        kindcode = kindcode.replace("(公表)", "")
        if(pubNumber =~ /-/) {
            def yearAndnumber = pubNumber.split("-")
            def pubYear = yearAndnumber[0]
            def pubSerialNmber = String.format("%1\$7s", yearAndnumber[1]).replace(' ', '0')
            def id = pubYear + pubSerialNmber + kindcode
            return "JP" + id
        } else {
            def pubYear = doDate.format("yyyy")
            def pubSerialNmber = String.format("%1\$7s", pubNumber).replace(' ', '0')
            def id = pubYear + pubSerialNmber + kindcode
            return "JP" + id
        }
    }
    
    def static sdfDoDateParse = new SimpleDateFormat("yyyyMMdd")
    def static importFileToMongo(file, len, count) {
        def fileContents = file.getText('UTF-8')
        def absolutePath = file.toString()
        //擷取相對路徑的同時將目錄結構全都替換成斜線
        def relatePath = absolutePath.substring(absolutePath.indexOf("wips")).replaceAll("\\\\", "/")
        try {
            fileContents = wips.patent.XmlUtils.fixXml(fileContents)
        } catch (Exception e) {
            e.printStackTrace()
            saveErrObj(relatePath, "There are some error while fix xml", e)
            return
        }
        SAXReader saxReader = new SAXReader();
        org.dom4j.Document document
        try {
            document = saxReader.read(new ByteArrayInputStream(fileContents.getBytes("utf-8")))
        } catch (Exception e) {
            e.printStackTrace()
            saveErrObj(relatePath, "dom4j error", e)
            return
        }
        //xml 超過 mongodb doc 上限時需要特別處理
        def truncate = false
        if(file.length() > filesizeLimit) {
            fileContents = wips.patent.XmlUtils.cutDescription(document, file.length(), filesizeLimit,
            "wips-patent-document/description", "wips-patent-document/bibliographic-data/description")
            truncate = true
        }
        
        def pubRef
        // 在wips/TS中的公表以及再公表，他們的xml中標籤publication-reference開頭為小寫。但是其他wips的資料中為Publication-reference。
        if (document.selectSingleNode("wips-patent-document/bibliographic-data/Publication-reference[@data-format='wips']") ){
            pubRef = document.selectSingleNode("wips-patent-document/bibliographic-data/Publication-reference[@data-format='wips']")
        } else {
            pubRef = document.selectSingleNode("wips-patent-document/bibliographic-data/publication-reference[@data-format='wips']")
        }
        
        def pubInfo = pubRef.selectSingleNode("document-id")
        //dates-of-public-availability 公告專利領證(登陸)後，公開到公眾的時間
        //EPO world wide 官網查詢日本專利，在查詢結果頁面顯示的日期為此日期，故以此日期作為公告專利的 doDate
        def availableInfo = document.selectSingleNode("wips-patent-document/bibliographic-data/dates-of-public-availability[@data-format='wips']")
        def kindcode = pubInfo.selectSingleNode("kind").getText().toUpperCase()
        //實用新案的新制雖為公開，但又有實際領證日 (用 grant 的 xsd)，為方便 rawdata 統計數量，加上註記
        if(file =~ /(?i)registered_utility/) {
            kindcode += "(新制)"
        }
        // 將"公表"的kind code: "A" 加上"(公表)"，為了要跟"特許出願公開"區分。
        if(relatePath=~ /(?i)\/TS\/Application\/t/){
            kindcode += "(公表)"
        }
        def doDate = null
        //公告專利且號碼為七碼為新制，此時要取發布日 (dates-of-public-availability)
        //2011 年底的 grant p 專利有漏 dates-of-public-availability 欄位的
        if(file =~ /(?i)grant/ && pubInfo.selectSingleNode("doc-num").getText().length() == 7) {
            try {
                if(availableInfo) {
                    def doDateStr = availableInfo.selectSingleNode("printed-with-grant").selectSingleNode("document-id").selectSingleNode("date").getText()
                    doDate = sdfDoDateParse.parse(doDateStr)
                } else if (kindcode == "B2" ){
                    //若 xml 裡面沒有公告專利新制的 doDate，到官網抓(目前僅 B2 專利有此問題)
                    def cerfificatedNumber = pubInfo.selectSingleNode("doc-num").getText()
                    //doDate = JpoClientUtils.getGrantPatentDoDate(cerfificatedNumber, kindcode)
                    
                    //JPO 官網大量爬會檔 IP，增加一個去 google patent 爬日期的方案
                    doDate = GooglePatentClients.getJPGrantPatentDoDate(cerfificatedNumber, kindcode)
                }
            } catch (Exception e) {
                saveErrObj(relatePath, "no available date", e)
                return
            }
        } else {
            if (relatePath=~ /(?i)\/TS\/Application\/s/) {
                // 再公表的情況，doDate取以下標籤內的日期，該日期再j-platpat上的搜尋名稱為"再公表發行日"。
                // 該日期跟官網發布日期才相同，以方便跟官網發佈更新時核對數目。
                try {
                    def doDateStr = document.selectSingleNode("wips-patent-document/bibliographic-data/corrected-publication-date[@data-format='wips']").getText()
                    doDate = sdfDoDateParse.parse(doDateStr)
                } catch (Exception e) {
                    saveErrObj(relatePath, "no available tag: <corrected-publication-date>", e)
                }
            } else {
                doDate = sdfDoDateParse.parse(pubInfo.selectSingleNode("date").getText())
            }
        }
        def id = formatedPatentId(pubInfo.selectSingleNode("doc-num").getText(), kindcode, doDate)
        try {
            //對"再公表"的那些檔案來說，他們的doc-num會有前綴WO字樣。其他JP的文件。
            assert id ==~ /^(JP)(WO)??(?i)\d{11}\w\d?/
        } catch (AssertionError e) {
            saveErrObj(relatePath, "ID does not confirm to the format", e)
            return
        }
        
        saveRawObj(id, fileContents, doDate, relatePath, truncate, kindcode)
        ProgressUtils.printlnProgress(count, len, doDate)
    }
}
