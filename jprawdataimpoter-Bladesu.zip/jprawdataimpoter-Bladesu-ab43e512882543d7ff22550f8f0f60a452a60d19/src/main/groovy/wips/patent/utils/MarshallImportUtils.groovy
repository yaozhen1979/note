package wips.patent.utils

import groovy.json.JsonSlurper

import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBElement
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType
import org.w3c.dom.Document

import wips.patent.application.jaxb.WipsPatentDocument;

import com.mongodb.BasicDBList
import com.mongodb.BasicDBObject

class MarshallImportUtils {
    
    private static Unmarshaller unmarshaller;
    private static Marshaller marshaller;
    private static enum Status {
        application, grant, t, s
    }
    private static Status status
    def static initMarshallImportUtils(patentStatus) {
        if(patentStatus ==~ /application/) {
            status = Status.application
        } else if (patentStatus ==~ /grant/) {
            status = Status.grant
        } else if (patentStatus ==~ /t/) {
            status = Status.t
        } else if (patentStatus ==~ /s/) {
            status = Status.s
        }
        JAXBContext jc = JAXBContext.newInstance("wips.patent." + patentStatus + ".jaxb")
        unmarshaller = jc.createUnmarshaller()
        //validation xsd
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI)
        //InputStream xsdis = ConvertXML.class.getResourceAsStream("wips-jp-patent-application-v1-0.xsd")
        InputStream xsdis = ClassLoader.getSystemClassLoader().
                getResourceAsStream("wips/patent/" + patentStatus + "/wips-jp-patent-"+ patentStatus +"-v1-0.xsd")
        Schema schema = sf.newSchema(new StreamSource(xsdis))
        unmarshaller.setSchema(schema)
        List<InputStream> moxyBindings = new ArrayList<InputStream>()
        Map<String, Object> props = new HashMap<String, Object>()
        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings)
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false)
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON)
        JAXBContext jc1 = JAXBContext.newInstance("wips.patent."+ patentStatus +".jaxb", getJaxbClassLoader(), props)
        marshaller = jc1.createMarshaller()
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json")
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)
    }
    
    def static slurper = new JsonSlurper()
    def static xml2Json(xml) {
        //修正部分 xml 的 element 大小寫和 xsd 不對應的問題
        //例如這篇 src/test/resources/sampleXml/wips/patent/registered_utility/grant/u/0003002002.xml
        //xml 為 <publication-reference> 而 xsd 為 <Publication-reference>
        xml = xml.replaceAll(/(<[\/]?)p(ublication-reference)/, /$1P$2/)
        //這篇公告專利  src\test\resources\sampleXml\wips\patent\grant\p\0003653601.xml  這篇公告專利有 <doc_num></doc_num>
        //xml 為 <doc_num></doc_num> 而xsd 為 <doc-num></doc-num>
        xml = xml.replaceAll(/(<[\/]?doc)_(num)/, /$1-$2/)
        
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance()
        docBuilderFactory.setNamespaceAware(true)
        Document doc
        try {
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder()
            doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes("utf-8")))
        } catch (Exception e) {
            throw new Exception("Problem on recognizing invoice type of given xml, cause: ", e)
        }
        def unmarshallerElem = getUnmarshallerElem(doc)
        StringWriter sw = new StringWriter();
        marshaller.marshal(unmarshallerElem.getValue(), sw)
        return slurper.parseText(sw.toString())
    }
    
    def static getUnmarshallerElem (doc) {
        if (status == Status.application ) {
            return (JAXBElement<wips.patent.application.jaxb.WipsPatentDocument>)unmarshaller.unmarshal(doc, wips.patent.application.jaxb.WipsPatentDocument.class)
        } else if (status == Status.grant) {
            return (JAXBElement<wips.patent.grant.jaxb.WipsPatentDocument>)unmarshaller.unmarshal(doc, wips.patent.grant.jaxb.WipsPatentDocument.class)
        } else if (status == Status.t) {
            return (JAXBElement<wips.patent.t.jaxb.WipsPatentDocument>)unmarshaller.unmarshal(doc, wips.patent.t.jaxb.WipsPatentDocument.class)
        } else if (status == Status.s) {
            return (JAXBElement<wips.patent.s.jaxb.WipsPatentDocument>)unmarshaller.unmarshal(doc, wips.patent.s.jaxb.WipsPatentDocument.class)
        }
    }
    def static getJaxbClassLoader () {
        if (status == Status.application ) {
            return wips.patent.application.jaxb.WipsPatentDocument.class.getClassLoader()
        } else if (status == Status.grant) {
            return wips.patent.grant.jaxb.WipsPatentDocument.class.getClassLoader()
        } else if (status == Status.t) {
            return wips.patent.t.jaxb.WipsPatentDocument.class.getClassLoader()
        } else if (status == Status.s) {
            return wips.patent.s.jaxb.WipsPatentDocument.class.getClassLoader()
        }
    }
    
    def static saveOrCatchException(marshallCol,doc){
        try{
            marshallCol.save(doc)
        } catch (Exception e) {
            def title = "mongoDB saving error"
            println title + ": " + doc._id
            e.printStackTrace()
            def errObj = new BasicDBObject()
            errObj.append("createDate", new Date())
            errObj.append("rawId", doc._id)
            errObj.append("title", title)
            errObj.append("errMsg", e.getMessage())
            errCol.save(errObj)
        }
        
    }
    def static errCol
    def static marshallCol
    def static importMarshallToMongo (doc, timeStamp, filename) {
        try {
            doc.data = xml2Json(doc.data.xml)
        } catch (Exception e) {
            def title = "marshall error"
            println title + ": " + doc._id
            e.printStackTrace()
            def errObj = new BasicDBObject()
            errObj.append("createDate", new Date())
            errObj.append("rawId", doc._id)
            errObj.append("title", title)
            errObj.append("errMsg", e.getMessage())
            errCol.save(errObj)
            return true
        }
        def oldDoc = marshallCol.findOne(new BasicDBObject("_id", doc._id))
        if(oldDoc) {
            oldDoc.data = doc.data
            def buildTimeStampAndFile = oldDoc.buildTimeStampAndFile
            def isRepeat = buildTimeStampAndFile.any { timeStamAndFile ->
                if(timeStamAndFile.buildTimeStamp == timeStamp && timeStamAndFile.filename == filename) {
                    return true
                }
            }
            if(!isRepeat) {
                def curBuildTimeStampAndFile = new BasicDBObject()
                curBuildTimeStampAndFile.append("buildTimeStamp", timeStamp)
                curBuildTimeStampAndFile.append("filename", filename)
                buildTimeStampAndFile.add(curBuildTimeStampAndFile)
            }
            oldDoc.buildTimeStampAndFile = buildTimeStampAndFile
            oldDoc.mongoSyncFlag.last = new Date()
            saveOrCatchException(marshallCol,oldDoc)
        } else {
            def dbList = new BasicDBList()
            def curBuildTimeStampAndFile = new BasicDBObject()
            curBuildTimeStampAndFile.append("buildTimeStamp", timeStamp)
            curBuildTimeStampAndFile.append("filename", filename)
            dbList.add(curBuildTimeStampAndFile)
            doc.append("buildTimeStampAndFile", dbList)
            def mongoSyncFlag = new BasicDBObject()
            mongoSyncFlag.append("init", new Date())
            mongoSyncFlag.append("last", new Date())
            doc.append("mongoSyncFlag", mongoSyncFlag)
            saveOrCatchException(marshallCol,doc)
        }
        
    }
    def static importMarshallToMongo (doc, timeStamp, filename, len, count) {
        importMarshallToMongo (doc, timeStamp, filename)
        ProgressUtils.printlnProgress(count, len, doc.doDate)
    }
}
