package verify.raw

import jpo.utils.JpoClientUtils

/**
 * 給定一個起始流水號和結束流水號，用來找流水號有中斷目錄 (這些目錄可能為 wips 原始資料有缺的專利)
 * 並用這些缺漏的流水號去官網查詢看是否能找到
 * 如果有則代表這邊原始資料有缺
 */

def rootDirPath = /Z:\patentsource\originaldata\JP\wips\disk\2011_update\Grant\p\2011\m09/
def startNumber = 4764401
def endNumber = 4784100
def kindcode = "A"
for (i=startNumber; i<=endNumber; i++) {
    String number = String.format("%1\$10s", i).replace(' ', '0')
    patentDir = new File(rootDirPath + File.separator + number)
    if(!patentDir.isDirectory()) {
        if(number.startsWith("0")) {
            number = number.substring(3, number.length())
        } else {
            year = Integer.parseInt(number.substring(0, 4))
            year = "H" + String.format("%1\$2s", year - 1988).replace(' ', '0')
            number = number.substring(4, number.length())
            number = year + "-" + number
        }
        def isExist = JpoClientUtils.isPatentExist(kindcode, number)
        if(isExist) {
            println number
        }
    }
}


def static getCodes(type) {
    def searchItemCode
    def officalInfoListCode
    switch (type) {
        case "特許公開":
            searchItemCode = "31" //公開號
            officalInfoListCode = "01" //公開特許公報 (特開･特表(A)、再公表(A1))
            break
        case "公開実用新案":
            searchItemCode = "31" //公開號
            officalInfoListCode = "04"//公開実用新案公報 (実開･実表･登実(U)、再公表(A1))
            break
        case "公開実用新案(新制)":
            searchItemCode = "35" //登錄番號
            officalInfoListCode = "04"//公開実用新案公報 (実開･実表･登実(U)、再公表(A1))
            break
        default:
            searchItemCode = "32"
            officalInfoListCode = "01"
            break
    }
    return [searchItemCode, officalInfoListCode]
}

def static isPatentExist(type, number) {
    System.properties << [ 'https.proxyHost':'10.60.94.41', 'https.proxyPort':'3128' ]
    def url = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action"
    def (searchItemCode, officalInfoListCode) = getCodes(type)
    def doc
    def tryCount = 0
    while(true) {
        try {
            tryCount++
            doc = org.jsoup.Jsoup.connect(url)
                            .data("bTmFCOMDTO.officialInfoList[0]", officalInfoListCode)
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[0]", "01")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08")
                            .data("bTmFCOMDTO.searchItemList[0]", searchItemCode)
                            .data("bTmFCOMDTO.fukumuFukumanaiList[0]","01")
                            .data("bTmFCOMDTO.searchKeywordList[0]", number)
                            .data("bTmFCOMDTO.searchSystemList[0]", "01")
                            .data("bTmFCOMDTO.searchItemList[1]", "05")
                            .data("bTmFCOMDTO.fukumuFukumanaiList[1]", "01")
                            .data("bTmFCOMDTO.searchKeywordList[1]", "")
                            .data("bTmFCOMDTO.searchSystemList[1]", "01")
                            .data("bTmFCOMDTO.ronrishiki", "")
                            .data("bTmFCOMDTO.fillingRowCount", "2")
                            .userAgent("Mozilla")
                            .post()
            break
        } catch (Exception e) {
            def sleepSec = 5*tryCount
            println "connect to JPO error, wait " + sleepSec + " sec and try again"
            sleep(sleepSec*1000)
        }
    }
    //println doc
    def ele = doc.select("strong[class=searchbox-result-count]")
    def jpoCount = ele.text().replace("件", "")
    jpoCount = Integer.parseInt(jpoCount)
    if (jpoCount == 0) {
        return false
    }
    return true
}