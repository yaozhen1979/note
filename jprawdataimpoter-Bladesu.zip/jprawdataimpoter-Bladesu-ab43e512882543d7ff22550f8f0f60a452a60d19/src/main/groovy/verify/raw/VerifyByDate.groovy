package verify.raw

import java.text.SimpleDateFormat

import jpo.utils.JpoClientUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


def cli = new CliBuilder(
    usage: 'verify rawdata count',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)
if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def mongoIp = "10.60.90.101"
def mongoUser = opt.u
def mongoPwd = opt.w
def kindcode = "A(公表)"
def stat = 2
def year = "2011"
def month = 9
MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")

def endDate
if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12) {
    endDate = 31
} else if (month==2) {
    endDate = 28
} else {
    endDate = 30
}

for (i=1; i<=endDate; i++){
    date = sdf.parse(year + "/" + month+ "/" + Integer.toString(i))
    def dateRangeQuery = new BasicDBObject('''$gte''', date)
    dateRangeQuery.append('''$lte''', date)
    def countQuert = new BasicDBObject("kindcode", kindcode)
    countQuert.append("doDate", dateRangeQuery)
    
    def mongocount = rawCol.count(countQuert)
    def jpoCount = JpoClientUtils.getCount(kindcode, date, date)
    
    println year + "/" + month + "/" + i + "\t" +mongocount + "\t" + jpoCount + "\t" + (jpoCount-mongocount) 
}

mongoClient.close()