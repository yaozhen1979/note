package verify.raw

import java.text.SimpleDateFormat

import jpo.utils.JPOMarshallIdTransferer
import jpo.utils.JpoClientUtils

import com.mongodb.BasicDBObject
import com.mongodb.DBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
import com.mongodb.DBCursor

def cli = new CliBuilder(
        usage: 'verify rawdata count',
        header: '\nAvailable options (use -h for help):\n')

cli.with {
    h(longOpt: 'help', 'Usage Information', required: false)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)
if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def mongoIp = "10.60.90.101"
def mongoUser = opt.u
def mongoPwd = opt.w
def kindcode = "A(公表)"


MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")


// Which date you want to alternative check the existence of documents of JPO and Mongo.
def year = "2009";
def month = "06";
def beginDay= 25;
def endDay=beginDay;

for (i=beginDay; i<=endDay; i++){
    date = sdf.parse(year + "/" + month+ "/" + Integer.toString(i))
    
    ArrayList<String> docIdList = JpoClientUtils.getDocNumberList(kindcode, date, date)
    
    if(docIdList!=null){
        
        JPOMarshallIdTransferer JTr = new JPOMarshallIdTransferer(docIdList.first());
        
        // From JPO to search mongoDB.
        def lackNumberOfMongo =0
        Set<String> marshallIdSet_fromJPO = new HashSet<String>()
        for(String docID : docIdList){
            def marshallId = JTr.translateID(docID)
            marshallIdSet_fromJPO.add(marshallId);
            def IDQuery = new BasicDBObject('_id', marshallId)
            def mongocount = rawCol.count(IDQuery)
            if(mongocount==0){
                println sdf.format(date) +": no "+marshallId+"("+docID+")" +" in mongo."
                lackNumberOfMongo +=1 
            }
        }
        
        def lackNumberOfJPO = 0;
        // From mongoDB _id to search JPO
        def dateRangeQuery = new BasicDBObject('''$gte''', date)
        dateRangeQuery.append('''$lte''', date)
        def IDQuery = new BasicDBObject("kindcode", kindcode)
        IDQuery.append("doDate", dateRangeQuery)
        def field = new BasicDBObject("_id","1")
        
        DBCursor cursor = rawCol.find(IDQuery,field)
        while(cursor.hasNext()) {
            DBObject obj = cursor.next()
            String marshallId= obj.get("_id");
            if (!marshallIdSet_fromJPO.contains(marshallId)){
                println sdf.format(date) +": no " + marshallId+" in JPO."
                lackNumberOfJPO += 1
            }
        }
        println("Overall")
        println("JPO has "+ lackNumberOfMongo + " documents which mongoDB don't have.")
        println("MongoDB has "+ lackNumberOfJPO + " documents which JPO don't have.")
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        println("Current time = "+cal.getTime())

    } else{
        sleep(500)
    }
    
    
}


mongoClient.close()