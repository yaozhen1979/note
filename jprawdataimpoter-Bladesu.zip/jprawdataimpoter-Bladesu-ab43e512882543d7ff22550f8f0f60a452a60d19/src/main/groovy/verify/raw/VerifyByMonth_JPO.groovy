package verify.raw

import java.text.SimpleDateFormat

import jpo.utils.JpoClientUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


def cli = new CliBuilder(
        usage: 'verify rawdata count',
        header: '\nAvailable options (use -h for help):\n')

cli.with {
    h(longOpt: 'help', 'Usage Information', required: false)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)
if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def mongoIp = "10.60.90.101"
def mongoUser = opt.u
def mongoPwd = opt.w

//def kindcode = "A"
//def kind_of_jp = "A"

//def kindcode = "A(公表)"
//def kind_of_jp = "T"

//def kindcode = "A1"
//def kind_of_jp = "S"

def kindcode = "B2"
def kind_of_jp = "B9"

//def kindcode = "S"
//def kind_of_jp = "DG"

//def kindcode = "U"
//def kind_of_jp = "U9"


def stat = 2

MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
for(yearN=2016;yearN<2017;yearN++){
    def year = yearN.toString()
    for (i=05; i<=12; i++){
        
        def endDate
        if(i==1 || i==3 || i==5 || i==7 || i==8 || i==10 || i==12) {
            endDate = "31"
        } else if (i==2) {
            endDate = "29"
        } else {
            endDate = "30"
        }
        def month = Integer.toString(i)
        startDate = sdf.parse(year + "/" + month+ "/01")
        endDate = sdf.parse(year + "/" + month + "/" + endDate)
        def dateRangeQuery = new BasicDBObject('''$gte''', startDate)
        dateRangeQuery.append('''$lte''', endDate)
        def countQuert = new BasicDBObject("kind_of_jp", kind_of_jp)
        countQuert.append("dateOfPublicAvailability", dateRangeQuery)
        
        def mongocount = rawCol.count(countQuert)
        def jpoCount = JpoClientUtils.getCount(kindcode, startDate, endDate)
        println year + "/" + month + "\t" +mongocount + "\t" + jpoCount + "\t" + (jpoCount-mongocount)
    }
}
mongoClient.close()