package verify.raw

import java.text.SimpleDateFormat

import jpo.utils.JpoClientUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress

//parser args
def cli = new CliBuilder(
    usage: 'verify rawdata count',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
    k(longOpt: 'kindcode', 'A', args: 1, required: true)
    d(longOpt: 'statr.date', '2001/01/01', args: 1, required: true)
    e(longOpt: 'end.date', '2001/11/01', args: 1, required: true)
}

def opt = cli.parse(args)
if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w
def kindcode = opt.k
def startDate = sdf.parse(opt.d)
def endDate = sdf.parse(opt.e)

//測試用
startDate = sdf.parse("1997/02/25")
endDate = sdf.parse("1997/02/25")
kindcode = "A"

MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
def dateRangeQuery = new BasicDBObject('''$gte''', startDate)
dateRangeQuery.append('''$lte''', endDate)
def countQuert = new BasicDBObject("kindcode", kindcode)
countQuert.append("doDate", dateRangeQuery)

def mongocount = rawCol.count(countQuert)
def jpoCount = JpoClientUtils.getCount(kindcode, startDate, endDate)

println mongocount + " " + jpoCount

mongoClient.close()