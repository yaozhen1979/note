package verify.raw

import java.text.SimpleDateFormat

import jpo.utils.JpoClientUtils

import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


def cli = new CliBuilder(
    usage: 'verify rawdata count',
    header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
}
def opt = cli.parse(args)
if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def sdf = new SimpleDateFormat("yyyy/MM/dd")
sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
def mongoIp = "10.60.90.155"
def mongoUser = opt.u
def mongoPwd = opt.w
def kindcode = "A1"


MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")

for (i=1996; i<=1997;i++){
    def year = Integer.toString(i)
    startDate = sdf.parse(year + "/01/01")
    endDate = sdf.parse(year + "/12/31")
    def dateRangeQuery = new BasicDBObject('''$gte''', startDate)
    dateRangeQuery.append('''$lte''', endDate)
    def countQuert = new BasicDBObject("kindcode", kindcode)
    countQuert.append("doDate", dateRangeQuery)
    
    def mongocount = rawCol.count(countQuert)
    def jpoCount = JpoClientUtils.getCount(kindcode, startDate, endDate)
    
    println year + "\t" + mongocount + "\t" + jpoCount + "\t" + (jpoCount-mongocount) 
}

mongoClient.close()