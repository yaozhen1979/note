package verify.rawfile
import jpo.patent.utils.XmlImportUtils
import jpo.patent.utils.ProgressUtils
class CheckFolderAndDTD {
    /* 
     * This program is made to parse whether the folder name and content of XML or SGM provided by JPO style.
     * The result also contain the counting chart of patent type.
     * editor: Blade Su 20160420
     */
    
    
    // Counting chart to put the counting result of patent with all type parsed in the process
    // The key of the chart is the same as the assemble of "dtdTypesRegXML" and "dtdTypesRegSGM".
    //
    static def countingChart = [:]
    static {
        jpo.patent.utils.XmlImportUtils.dtdTypesRegXML.each{k,v ->
            countingChart.put(k,0)
        }
        jpo.patent.utils.XmlImportUtils.dtdTypesRegSGM.each{k,v ->
            countingChart.put(k,0)
        }
    }
    static def contentRegMapXML = jpo.patent.utils.XmlImportUtils.dtdTypesRegXML
    static def contentRegMapSGM = jpo.patent.utils.XmlImportUtils.dtdTypesRegSGM
    
    
    static main(args) {
        // initialize the arguments
        String targetPath = null
        String logFilePath = "log.temp.CheckFolderAndDTD"
        def skipN = null
        
        def cli = new CliBuilder(
                usage: 'Check JPO provided patent file',
                header: '\nAvailable options (use -h for help):\n')
        
        cli.with {
            h(longOpt: 'help', 'Usage Information', required: false)
            t(longOpt: 'target path', '\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\JP\\synergytek\\update\\JPG\\'
            , args: 1, required: true)
            l(longOpt: 'place to save log', '', args: 1, required: false)
            n(longOpt: 'assigned name for log file','',args: 1, required: false)
            s(longOpt: 'doc number to skip (default:0)', '', args: 1, required: false)
            c(longOpt: 'show counting of a patent type (example: B9, U9...)', '', args: 1, required: false)
            provider(longOpt: 'data source provider ,synergytek or jpo(default)', '', args: 1, required: false)
        }
        def opt = cli.parse(args)
        if (!opt) {
            cli.usage()
            assert opt : "some argument is required"
        }
        
        if (opt.h) cli.usage()
        
        // Setting of arguments: target of folder to recursively process
        targetPath = opt.t
        // Setting of arguments: the place to put log file (combined with two arguments)
        if (opt.l){
            if(opt.n){
                
                logFilePath = opt.l+ File.separator +opt.n
                
            } else {
                
                logFilePath = opt.l+ File.separator +logFilePath
                
            }
        }
        // Setting of arguments: number of file to skip
        if(opt.s) {
            skipN = opt.s
        } else {
            skipN = 0
        }
        // Setting of arguments: provider
        def folderNameRegXML = jpo.patent.utils.XmlImportUtils.importTypesRegXML
        def folderNameRegSGM = jpo.patent.utils.XmlImportUtils.importTypesRegSGM
        
        if(opt.provider) {
            switch (opt.provider){
                case "jpo":
                // do nothing
                    break
                case "synergytek":
                    folderNameRegXML = synergytek.patent.utils.XmlImportUtils.importTypesRegXML
                    folderNameRegSGM = synergytek.patent.utils.XmlImportUtils.importTypesRegSGM
                
                    break
                default:
                    throw new Exception("undefined provider, please check it")
                    break
                
            }
            
        }
        
        // file to append
        def log = new File(logFilePath)
        log.append("Starting parsing..."+ Calendar.instance.time+"\n")
        
        // statistic
        
        println "Starting parsing..."+ Calendar.instance.time+"\n"
        
        def filelist = jpo.patent.utils.XmlImportUtils.extractRawXml(new File(targetPath))
        def len = filelist.size()
        jpo.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
        jpo.patent.utils.ProgressUtils.latestPrintTime = jpo.patent.utils.ProgressUtils.startTime
        def count = 0
        def fileString = null
        
        
        filelist.each { file ->
            count++
            ProgressUtils.printlnProgress(count, len, Calendar.instance.time)
            if (count >= skipN){
                
                fileString = file.toString()
                def parsedFolderType = null
                def parsedFileType = null
                
                
                // check the fileString is a patent file.
                // separating the sampling way of SGM and xml
                if (fileString =~ /.SGM$/) {
                    
                    def fileContents = file.getText("EUC-JP")
                    // iteratively check the folder is defined
                    folderNameRegSGM.each{k,v ->
                        if (fileString =~ v){
                            parsedFolderType = k
                            
                        }
                    }
                    parseTypeAndResponse(parsedFileType, log, parsedFolderType,
                            fileString, fileContents, contentRegMapSGM,
                            jpo.patent.utils.XmlImportUtils.EscapedPatentType.sequenceListSGM)
                    
                } else if (fileString =~ /.xml$/) {
                    
                    BufferedReader br = new BufferedReader(new FileReader(file))
                    def fileContents = br.readLine()+br.readLine()+br.readLine();
                    br.close()
                    
                    // iteratively check the folder is defined
                    
                    folderNameRegXML.each{k,v ->
                        if (fileString =~ v){
                            parsedFolderType = k
                        }
                    }
                    
                    parseTypeAndResponse(parsedFileType, log, parsedFolderType,
                            fileString ,fileContents, contentRegMapXML,
                            jpo.patent.utils.XmlImportUtils.EscapedPatentType.sequenceListXML)
                    
                }
                
            }
        }
        log.append("finished\n")
        
        // print chart
        log.append("Totally counting chart\n")
        def totalCount = 0
        countingChart.each{ k,v ->
            log.append("Type $k : count $v\n")
            totalCount += v
        }
        log.append("Total Counts: $totalCount\n")
        println "finished\n"
        if (opt.c){
            try {
            println opt.c+" : couting "+countingChart.get(opt.c)
            } catch (ex) {
            println "No defined type :" + opt.c
            } 
        }
    }
    
    static void parseTypeAndResponse(parsedFileType, File log, parsedFolderType, String fileString, String fileContents, contentRegMap ,escapedType) {
        // If the folder is defined, check content
        if (parsedFolderType != null){
            
            // check content type
            contentRegMap.each{ k,v ->
                
                if (fileContents =~ v){
                    parsedFileType = k
                }
                
            }
            
            if (parsedFileType != null) {
                if (parsedFileType == escapedType.toString()) {
                    
                    countingChart.put(parsedFileType,countingChart.get(parsedFileType)+1)
                } else {
                    if (parsedFileType != parsedFolderType){
                        // The type was unmatched
                        log.append("<note>type unmatched</note> ")
                        log.append("<folder>$parsedFolderType</folder> ")
                        log.append("<file>$parsedFileType</file> ")
                        log.append("<path>$fileString</path>\n")
                        
                    } else {
                        // totally correct, add the number to chart
                        countingChart.put(parsedFolderType,countingChart.get(parsedFolderType)+1)
                    }
                }
            } else {
                
                // The undefined parsedFileType was discovered
                log.append("<note>undefined dtd type</note> ")
                log.append("<path>$fileString</path>\n")
            }
        } else {
            
            // The undefined folder was discovered
            log.append("<note>undefined folder</note> ")
            log.append("<path>$fileString</path>\n")
            
        }
        
    }
}
