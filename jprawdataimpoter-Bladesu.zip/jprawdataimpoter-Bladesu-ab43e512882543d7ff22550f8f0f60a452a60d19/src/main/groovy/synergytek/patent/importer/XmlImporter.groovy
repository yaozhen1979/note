package synergytek.patent.importer
import synergytek.patent.utils.XmlImportUtils

import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress


//parser args
def cli = new CliBuilder(
        usage: 'import jp raw data (2012~2014) to mongo ',
        header: '\nAvailable options (use -h for help):\n')

cli.with
{
    h(longOpt: 'help', 'Usage Information', required: false)
    p(longOpt: 'rawdata.path', '\\\\10.62.41.110\\rawdata\\patentsource\\originaldata\\JP\\synergytek\\update\\JPG\\'
    , args: 1, required: true)
    i(longOpt: 'mongo.ip', '', args: 1, required: true)
    u(longOpt: 'mongo.user', '', args: 1, required: true)
    w(longOpt: 'mongo.pwd', '', args: 1, required: true)
    s(longOpt: 'doc number to skip', '', args: 1, required: false)
    t(longOpt: 'patent type', '', args: 1, required: false)
}

def opt = cli.parse(args)

if (!opt) {
    cli.usage()
    assert opt : "some argument is required"
}
if (opt.h) cli.usage()

def rawdataPath = opt.p
def mongoIp = opt.i
def mongoUser = opt.u
def mongoPwd = opt.w

def skipN = 0
if (opt.s) {
    skipN = opt.s.toDouble()
    println "Beginning from "+skipN+"'th file.."
}
def importType = null
if (opt.t) {
    importType = opt.t
}
MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));

XmlImportUtils.rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
XmlImportUtils.errCol = mongoClient.getDB("PatentRawJPO").getCollection("ErrorPatentRawJPO")
XmlImportUtils.sdfDoDateParse.setTimeZone(TimeZone.getTimeZone("GMT"))

//測試用路徑 (application)
//rawdataPath  = "src" + File.separator + "test" + File.separator + "resources" + File.separator+ "wips" +
//                File.separator + "patent" + File.separator + "application"+ File.separator +"sampleXml"
//測試用路徑 (grant)
//rawdataPath  = "src" + File.separator + "test" + File.separator + "resources" + File.separator+ "wips" +
//                File.separator + "patent" + File.separator + "grant"+ File.separator +"sampleXml"
def filelist = null
println "Starting extract raw data list..."
if (importType) {
    filelist = synergytek.patent.utils.XmlImportUtils.extractRawXml(new File(rawdataPath),importType)
} else {
    filelist = synergytek.patent.utils.XmlImportUtils.extractRawXml(new File(rawdataPath))
}
println "End of extraction"


//filelist = [new File(rawdataPath + File.separator + "u" + File.separator + "0002605481.xml")]
//filelist = [new File("C:\\gitlab_project\\jprawdataimpoter\\src\\main\\resources\\garbled\\wips\\disk\\application\\p\\1994\\m04\\1994102498\\1994102498.xml")]

def count = 0
def len = filelist.size()
jpo.patent.utils.ProgressUtils.startTime = Calendar.instance.time.time
jpo.patent.utils.ProgressUtils.latestPrintTime = jpo.patent.utils.ProgressUtils.startTime

filelist.each { file ->
    count++
    if (count >= skipN){
        synergytek.patent.utils.XmlImportUtils.importFileToMongo(file, len, count)
    }
    //println file
}
println "finished"
mongoClient.close()

