package synergytek.patent.constant

class Path {
    def static regexPatternForXML = [
        A : /.*Patent(\/|\\).*_CONVERT.*(\/|\\)A(\/|\\).*.xml$/,   //公開特許公報
        // A5: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)A5(\/|\\).*.xml$/,
        // A6: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)A6(\/|\\).*.xml$/,
        // B6: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)B6(\/|\\).*.xml$/, // NeverFind
        B9: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)B9(\/|\\).*.xml$/,
        // BC: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)BC(\/|\\).*.xml$/,
        S: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)S(\/|\\).*.xml$/,
        //S5: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)S5(\/|\\).*.xml$/,
        //S6: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)S6(\/|\\).*.xml$/,
        T: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)T(\/|\\).*.xml$/,
        //T5: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)T5(\/|\\).*.xml$/,
        //T6: /.*Patent(\/|\\).*_CONVERT.*(\/|\\)T6(\/|\\).*.xml$/,
        //U7: /.*UtilityModel(\/|\\).*_CONVERT.*(\/|\\)U7(\/|\\).*.xml$/,
        U9: /.*UtilityModel(\/|\\).*_CONVERT.*(\/|\\)U9(\/|\\).*.xml$/
        //UB: /.*UtilityModel(\/|\\).*_CONVERT.*(\/|\\)UB(\/|\\).*.xml$/
        //UC: /.*UtilityModel(\/|\\).*_CONVERT.*(\/|\\)UC(\/|\\).*.xml$/,
    ]
    def static regexPatternForSGM = [
        DG: /.*DesignPatent(\/|\\).*(\/|\\)DG(\/|\\).*.SGM$/
        //DGC: /.*DesignPatent(\/|\\).*(\/|\\)DGC(\/|\\).*.SGM$/,
        //DD: /.*DesignPatent(\/|\\).*(\/|\\)DD(\/|\\).*.SGM$/,
    ]
}
