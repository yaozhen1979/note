package jpo.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*********************************************
 * Editor : Blade Su
 * Purpose: Transfer the doc_id gotten from JPO to the Marshall ID format
 *          for example: (1) "再表95\005362"  => "WO19950005362A1"
 *                       (2) "特表平08-500001" => "20000500001A"
 * Usage: (1) create instance of JPOMarshallIDTransferer.
 * 
 * Notation: 
 * (1) If you want to give new pattern, please check and modify all array behind:
 *      <a> capitalPatterns,splitPatterns,marshallIDPattern for whole id pattern
 *      <b> royalYearSymbol, royalYearACYearValue for loyal year pattern.
 * 
 **********************************************/
public class JPOMarshallIdTransferer {
    /* 
     * 以下三個array，都對應算出的docTypeSerialnumber
     * capitalPatterns為JPO官網上document id的regex樣式
     * 天皇年代號勿變成此處pattern，留待最後一個步驟處理年份再來處理
     * 注意!!!!!!!!!!!
     * 以下三個array，同一種專利的element必須對應相同位置!!!!!!
     */
    
    // capitalPatterns: 樣式為前綴日文字和中間分隔號
    private Pattern[] capitalPatterns={
            Pattern.compile("(再表)(\\d+)(\\/)(\\d+)"),
            Pattern.compile("(特表)\\S(\\d+)(-)(\\d+)")
    };
    // splitPattern: 樣式為欲使用split功能的跟隔物，想要達成的效果是
    // 分離出年份(包含天皇年字樣)以及結尾代碼流水號。
    private Pattern[] splitPatterns={
            Pattern.compile("(再表)|(\\/)"),
            Pattern.compile("(特表)|-")
    };
    // 輸出的marshall id的樣式
    private String[] marshallIDPattern={
            "JPWO%4d%07dA1",
            "JP%4d%07dA"
    };
    
    
    /* 
     * 以下兩個array是處理天皇年的樣式
     * royalYearSymbol為天皇年的前綴碼
     * royalYearACYearValue為上array element對應之西元年的int值。
     */
    private Pattern[] royalYearSymbol={
            Pattern.compile("平"),
   
    };
    private int[] royalYearACYearValue={
            1988,
    };
    
    
    private int docTypeSerialnumber = -1;
    private Matcher singleMatcher;
    private int repeat = 0;
    private String[] splitedResult;
    private Matcher yearMatcher;

    public JPOMarshallIdTransferer(String doc_id) throws Exception{
        copyDocIDType(doc_id);
    }
    
    
    // 處理輸入的一個doc_id，若是他的樣式在我們已知的pattern內。
    // 會得到一docTypeSerialnumber，此編號為我們樣式的編號。
    // 之後使用translateID
    private void copyDocIDType(String doc_id) throws Exception {
        for(int i =0;i < capitalPatterns.length; i++){
            singleMatcher = capitalPatterns[i].matcher(doc_id);
            if(singleMatcher.find()){
                this.docTypeSerialnumber = i;
                this.repeat += 1;
            }
            if(repeat>1){
                throw new Exception("Error: More than one pattern accepted");
            }
        }
        if(repeat==0){
            throw new Exception("Error: No pattern accepted");
        }
    }
    
    // 將輸入的doc_id專譯成marshall id之樣式。
    // 合理使用的情況下，使用前必須先用建構子輸入一想要處理的範例id。否則會報錯。
    public String translateID(String doc_id) throws Exception{
        if(docTypeSerialnumber >=0){
        this.splitedResult = splitPatterns[docTypeSerialnumber].split(doc_id);
        return String.format(marshallIDPattern[this.docTypeSerialnumber],
                transferRoyalYear(this.splitedResult[1]),
                 Integer.parseInt(this.splitedResult[2]));
        } else {
            throw new Exception("Please give the sample of document"
                              + " id by constructior or copyDocIDType method.");
        }

    }
    public int transferRoyalYear(String year) throws Exception{

        int pureYear = 0;
        repeat = 0;
        for(int i =0;i < royalYearSymbol.length; i++){
            this.yearMatcher = royalYearSymbol[i].matcher(year);
            if(yearMatcher.find()){
                repeat += 1;
                pureYear=Integer.parseInt(year.replace(royalYearSymbol[i].toString(), ""))+royalYearACYearValue[i];
                break;
            }
        }
        
        // 若都沒有找到已定義的天皇年樣式。就直接轉譯成年份。
        if(repeat==0){
            pureYear = Integer.parseInt(year);
        }
        
        // 若處理完有(或沒有)天皇的年份後，仍為兩碼年份，則是千禧喜年前的兩碼計法，直接加1900;
        if(pureYear<=03){
            pureYear = pureYear +2000;
        }else if(pureYear<=100){
            pureYear = pureYear +1900;
        }
        return pureYear;
        
    }


}
