package jpo.utils

import java.text.SimpleDateFormat
import org.jsoup.nodes.Element
import org.jsoup.select.Elements

class JpoClientUtils {
    def static searchurl = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action"
    def static resulturl = "https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_SearchResult.action"
    def static searchurlDesignPatent = "https://www.j-platpat.inpit.go.jp/web/ishou/iskt/ISKT_GM201_SearchCount.action"
    
    def static  sdfJPDateParse = new SimpleDateFormat("yyyy年MM月dd日")
    static {
        System.properties << [ 'https.proxyHost':'10.60.94.41', 'https.proxyPort':'3128' ]
        sdfJPDateParse.setTimeZone(TimeZone.getTimeZone("GMT"))
    }
    
    def static querySearchPage(officalInfoListCode, searchItemCode, query) {
        def doc
        def tryCount = 0
        while(true) {
            try {
                tryCount++
                //println "dateQuery:"+query+"/"+"officalInfoListCode:"+officalInfoListCode+"/"+"searchItemCode:"+searchItemCode
                doc = org.jsoup.Jsoup.connect(searchurl)
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[0]", "01")
                        .data("bTmFCOMDTO.officialInfoList[0]", officalInfoListCode)
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08")
                        .data("bTmFCOMDTO.searchItemList[0]", searchItemCode)
                        .data("bTmFCOMDTO.fukumuFukumanaiList[0]","01")
                        .data("bTmFCOMDTO.searchKeywordList[0]", query)
                        .data("bTmFCOMDTO.searchSystemList[0]", "01")
                        .data("bTmFCOMDTO.searchItemList[1]", "05")
                        .data("bTmFCOMDTO.fukumuFukumanaiList[1]", "01")
                        .data("bTmFCOMDTO.searchKeywordList[1]", "")
                        .data("bTmFCOMDTO.searchSystemList[1]", "01")
                        .data("bTmFCOMDTO.ronrishiki", "")
                        .data("bTmFCOMDTO.fillingRowCount", "2")
                        .userAgent("Mozilla")
                        .post()
                break
            } catch (Exception e) {
                def sleepSec = 5*tryCount
                println "connect to JPO error, wait " + sleepSec + " sec and try again"
                sleep(sleepSec*1000)
            }
        }
        return doc
    }
    
    // 意匠專用
    def static querySearchPageDesignPatent( searchItemCode, query) {
        def doc
        def tryCount = 0
        
        //Get session first
        def sessionDoc = org.jsoup.Jsoup.connect(searchurlDesignPatent).post()
        def jplatpatSession = sessionDoc.select("div[id=jplatpatSession]").text()
        
        while(true) {
            try {
                tryCount++
                //println "dateQuery:"+query+"/"+"officalInfoListCode:"+officalInfoListCode+"/"+"searchItemCode:"+searchItemCode
                doc = org.jsoup.Jsoup.connect(searchurlDesignPatent)
                        .data("bTmFCOMDTO.kokunaiDeleteFlag", "on")
                        .data("bTmFCOMDTO.hagueDeleteFlag", "on")
                        .data("bTmFCOMDTO.fillingOnlyPartialDesign", "off")
                        .data("bTmFCOMDTO.fillingSokyuuHukumu", "off")
                        .data("bTmFCOMDTO.fillingPageBango", "1")
                        .data("bTmFCOMDTO.fillingPublicationType", "SS")
                        .data("bTmFCOMDTO.fillingRelatedDesign", "0")
                        .data("bTmFCOMDTO.fillingSearchConditionList[0].searchItemValue", searchItemCode)
                        .data("bTmFCOMDTO.fillingSearchConditionList[0].searchKeywordValue", query)
                        .data("bTmFCOMDTO.fillingSearchConditionList[0].searchSystemValue:", "2")
                        .data("bTmFCOMDTO.fillingSearchConditionList[1].searchItemValue", "19")
                        .data("bTmFCOMDTO.fillingSearchConditionList[1].searchKeywordValue", "")
                        .data("bTmFCOMDTO.fillingSearchConditionList[1].searchSystemValue:", "3")
                        .data("bTmFCOMDTO.fillingShowListMode","1")
                        .data("bTmFCOMDTO.fillingConditionListCount","2")
                        .data("jplatpatSession",jplatpatSession)
                        .userAgent("Mozilla")
                        .post()
                break
            } catch (Exception e) {
                def sleepSec = 5*tryCount
                println "connect to JPO error, wait " + sleepSec + " sec and try again"
                sleep(sleepSec*1000)
            }
        }

        return doc
    }
    
    //這功能目前只用來抓公告專利(用登錄號)抓 doDate
    def static getGrantPatentDoDate(certificatedNumber, kindcode) {
        def officalInfoListCode = getTypeCode(kindcode)
        def searchItemCode = getNumberCode(kindcode)
        def doc
        def session = getSession(certificatedNumber, kindcode)
        def tryCount = 0
        while(true) {
            try {
                tryCount++
                doc = org.jsoup.Jsoup.connect(resulturl)
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[0]", officalInfoListCode)
                        .data("bTmFCOMDTO.officialInfoList[1]", "02")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07")
                        .data("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08")
                        .data("__checkbox_bTmFCOMDTO.jglobalsearchList[0]", "1")
                        .data("__checkbox_bTmFCOMDTO.jglobalsearchList[1]", "2")
                        .data("__checkbox_bTmFCOMDTO.jglobalsearchList[2]", "3")
                        .data("__checkbox_bTmFCOMDTO.jglobalsearchList[3]", "4")
                        .data("bTmFCOMDTO.searchItemList[0]", searchItemCode)
                        .data("bTmFCOMDTO.fukumuFukumanaiList[0]", "01")
                        .data("bTmFCOMDTO.searchKeywordList[0]", certificatedNumber)
                        .data("bTmFCOMDTO.searchSystemList[0]", "01")
                        .data("bTmFCOMDTO.searchItemList[1]", "05")
                        .data("bTmFCOMDTO.fukumuFukumanaiList[1]", "01")
                        .data("bTmFCOMDTO.searchKeywordList[1]", "")
                        .data("bTmFCOMDTO.searchSystemList[1]", "01")
                        .data("bTmFCOMDTO.ronrishiki", "")
                        .data("bTmFCOMDTO.fillingRowCount", "2")
                        .data("jplatpatSession", session)
                        .userAgent("Mozilla")
                        .post()
                break
            } catch (Exception e) {
                e.printStackTrace()
                def sleepSec = 5*tryCount
                println "connect to JPO error, wait " + sleepSec + " sec and try again"
                sleep(sleepSec*1000)
            }
        }
        def doDateStr = doc.select("table[class=table-result]").select("tbody td:eq(4)").text()
        return sdfJPDateParse.parse(doDateStr)
    }
    
    // 用來轉譯WIPS文件的WO檔案名稱，變成JPO官網可以查詢的樣式文件編號。
    def static transferWIPS_WONumber(number){
        if(number =~ /^WO/){
            String numberString = number.toString()
            def years = numberString.drop(2).take(4) as int
            def seriesN = numberString.drop(6) as int
            if(years <=2003){
                number = String.format("WO%s/%05d",Integer.toString(years).drop(2),seriesN)
            } else {
                number = String.format("WO%4d/%06d",years,seriesN)
            }
            return number
        } else {
            return number
        }
    }
    
    def static getSession(pn, kindcode) {
        def officalInfoListCode = getTypeCode(kindcode)
        def searchItemCode = getNumberCode(kindcode)
        def doc = querySearchPage(officalInfoListCode, searchItemCode, pn)
        def countEle = doc.select("strong[class=searchbox-result-count]")
        def jpoCount = countEle.text().replace("件", "")
        if(!jpoCount.equals("1")) {
            throw new Exception("count not equals to 1")
        }
        def ele = doc.select("div[id=jplatpatSession]")
        return ele.text()
    }
    
    
    def static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
    
    def static getCount(kindcode, startDate, endDate) {
        def dateQuery = sdf.format(startDate) + ":" + sdf.format(endDate)
        def officalInfoListCode = getTypeCode(kindcode)
        def searchItemCode = getDateCode(kindcode)
        def doc
        
        if (kindcode == "S"){
            doc = querySearchPageDesignPatent(searchItemCode, dateQuery)
        } else {
            doc = querySearchPage(officalInfoListCode, searchItemCode, dateQuery)
        }
        def ele = doc.select("strong[class=searchbox-result-count]")
        def jpoCount = ele.text().replace("件", "")
        return jpoCount.toInteger()
    }
    
    def static isPatentExist(kindcode, number) {
        def officalInfoListCode = getTypeCode(kindcode)
        def searchItemCode = getNumberCode(kindcode)
        
        def doc = querySearchPage(officalInfoListCode, searchItemCode, transferWIPS_WONumber(number))
        def ele = doc.select("strong[class=searchbox-result-count]")
        def jpoCount = ele.text().replace("件", "")
        jpoCount = Integer.parseInt(jpoCount)
        if (jpoCount == 0) {
            return false
        }
        return true
    }
    
    def static getTypeCode (kindcode) {
        switch (kindcode) {
            case "A":
                return "01" //公開特許公報 (特開･特表(A)、再公表(A1))
                break
            case "A(公表)":
                return "01" // 對"公表"來說此欄也是01
                break
            case "A1":
                return "01" // 對"再公表特許(A1)"來說，此欄也是01
                break
            case "B2":
                return "02"//特許公報 (特公･特許(B))
                break
            case "U":
                return "04"//公開実用新案公報 (実開･実表･登実(U)、再公表(A1))
                break
            case "U(新制)":
                return "04"//公開実用新案公報 (実開･実表･登実(U)、再公表(A1))
                break
            case "Y2":
                return "05"//実用新案公報 (実公・実登(Y))
                break
            default:
                return "01"
                break
        }
    }
    
    def static getDateCode (kindcode) {
        switch (kindcode) {
            case "A":
                return "32" //公開日
                break
            case "A(公表)":
                return "39" //39代表 "公表日"
                break
            case "A1":
                return  "40" // 40代表"再公表発行日(A1)"
                break
            case "U":
                return "41" //公開日
                break
            case "B2":
                return "41" //公報發行日
                break
            case "Y2":
                return "41"//公報發行日
                break
            case "U(新制)":
                return "37"//登錄公報發行日
                break
            case "S":
                return "16"
                break
            default:
                return "32"
                break
        }
    }
    
    //僅列出目前有需要用到的號碼查詢
    def static getNumberCode (kindcode) {
        switch (kindcode) {
            case "A1":
                return "45" // 公表番號
                break
            case "A(公表)":  // 國際公開番號
                return "38"
                break
            case "A":
                return "31" //公開號
                break
            case "B2":
                return "35" //登錄番號
                break
            case "U":
                return "31" //公開號
                break
            case "U(新制)":
                return "35" //登錄番號
                break
            
            default:
                return "31" //公開號
                break
        }
    }
    
    def static getDocNumberList (kindcode, startDate, endDate){
        def dateQuery = sdf.format(startDate) + ":" + sdf.format(endDate)
        def officalInfoListCode = getTypeCode(kindcode)
        def searchItemCode = getDateCode(kindcode)
        def doc = querySearchPage(officalInfoListCode, searchItemCode, dateQuery)
        def ele = doc.select("strong[class=searchbox-result-count]")
        def jpoCount = ele.text().replace("件", "") as int
        if(jpoCount<=1000 && jpoCount>0){
            def sessionString = doc.select("div[id=jplatpatSession]")
            def session = sessionString.text()
            def tryCount = 0
            while(true) {
                try {
                    tryCount++
                    
                    doc = org.jsoup.Jsoup.connect(resulturl)
                            .data("bTmFCOMDTO.officialInfoList[1]", "01")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[0]", officalInfoListCode)
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[1]", "02")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[2]", "03")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[3]", "04")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[4]", "05")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[5]", "06")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[6]", "07")
                            .data("__checkbox_bTmFCOMDTO.officialInfoList[7]", "08")
                            .data("__checkbox_bTmFCOMDTO.jglobalsearchList[0]", "1")
                            .data("__checkbox_bTmFCOMDTO.jglobalsearchList[1]", "2")
                            .data("__checkbox_bTmFCOMDTO.jglobalsearchList[2]", "3")
                            .data("__checkbox_bTmFCOMDTO.jglobalsearchList[3]", "4")
                            .data("bTmFCOMDTO.searchItemList[0]", searchItemCode)
                            .data("bTmFCOMDTO.fukumuFukumanaiList[0]", "01")
                            .data("bTmFCOMDTO.searchKeywordList[0]", dateQuery)
                            .data("bTmFCOMDTO.searchSystemList[0]", "01")
                            .data("bTmFCOMDTO.searchItemList[1]", "05")
                            .data("bTmFCOMDTO.fukumuFukumanaiList[1]", "01")
                            .data("bTmFCOMDTO.searchKeywordList[1]", "")
                            .data("bTmFCOMDTO.searchSystemList[1]", "01")
                            .data("bTmFCOMDTO.ronrishiki", "")
                            .data("bTmFCOMDTO.fillingRowCount", "2")
                            .data("jplatpatSession", session)
                            .referrer("https://www7.j-platpat.inpit.go.jp/tkk/tokujitsu/tkkt/TKKT_GM201_KeywordSearchCount.action")
                            .userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36")
                            .header("Acccpet,text/html","application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                            .header("Accept-Encoding","gzip, deflate")
                            .header("Accept-Language","en-US,en;q=0.8")
                            .header("Cache-Control","max-age=0")
                            .header("Connection","keep-alive")
                            .post()
                    break
                } catch (Exception e) {
                    e.printStackTrace()
                    def sleepSec = 5*tryCount
                    println "connect to JPO error, wait " + sleepSec + " sec and try again"
                    sleep(sleepSec*1000)
                }
            }
            
            Elements docs = doc.select("table[class=table-result]").select("tbody").select("a[class=detailedLink]")
            ArrayList<String> docIDList = new ArrayList<String>()
            for(Element element : docs){
                docIDList.add(element.text())
            }
            return  docIDList
            
        } else if (jpoCount> 1000) {
            throw new Exception("Too many doc on this day, try other ways.")
        }
        
        
        
    }
}
