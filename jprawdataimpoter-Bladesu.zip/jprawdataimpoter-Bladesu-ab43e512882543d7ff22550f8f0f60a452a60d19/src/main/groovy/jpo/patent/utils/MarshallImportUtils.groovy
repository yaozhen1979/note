package jpo.patent.utils

import groovy.json.JsonSlurper

import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBElement
import javax.xml.bind.Marshaller
import javax.xml.bind.Unmarshaller
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory

import org.eclipse.persistence.jaxb.JAXBContextProperties
import org.eclipse.persistence.jaxb.MarshallerProperties
import org.eclipse.persistence.oxm.MediaType
import org.w3c.dom.Document


import com.mongodb.BasicDBList
import com.mongodb.BasicDBObject
/** This MarshallImportUtils is modified for JPO official file format
 * @auther BladeSu
 */
class MarshallImportUtils {
    
    private static Unmarshaller categoryUnmarshaller,validateUnmarshaller;
    private static Marshaller marshaller;
    private static String xsdVersion = "v1" //default value
    public static enum Type {
        A,A5,A6,B6,B9,BC,DD,DG,DGC,S,S5,S6,T,T5,T6,U7,U9,UB,UC
    }
    public static enum PublicationType {
        A,S,T
    }
    public static enum IssueType {
        B9,U9
    }
    public static enum DesignType {
        DG
    }
    private static xsdMap = [
        A : 'jpo/patent/a/gat-a-%1$s.xsd',
        A5: 'jpo/patent/a/gat-a5-%1$s.xsd',
        A6: 'jpo/patent/a/gat-a6-%1$s.xsd',
        B6: 'jpo/patent/b/gat-b6-%1$s.xsd',
        B9: 'jpo/patent/b/gat-b9-%1$s.xsd',
        BC: 'jpo/patent/b/gat-vc-%1$s.xsd',
        DD: 'jpo/patent/design/DES-%1$s.xsd',
        DG: 'jpo/patent/design/DES-%1$s.xsd',
        DGC: 'jpo/patent/design/DESCOR-%1$s.xsd',
        S: 'jpo/patent/s/gat-s-%1$s.xsd',
        S5: 'jpo/patent/s/gat-s5-%1$s.xsd',
        S6: 'jpo/patent/s/gat-s6-%1$s.xsd',
        T: 'jpo/patent/t/gat-t-%1$s.xsd',
        T5: 'jpo/patent/t/gat-t5-%1$s.xsd',
        T6: 'jpo/patent/t/gat-t6-%1$s.xsd',
        U7: 'jpo/patent/u/gat-u7-%1$s.xsd',
        U9: 'jpo/patent/u/gat-u9-%1$s.xsd',
        UB: 'jpo/patent/u/gat-ub-%1$s.xsd',
        UC:  'jpo/patent/u/gat-uc-%1$s.xsd',
        PUBLICATION: 'jpo/patent/publication/gat-publication-%1$s.xsd',
        ISSUE: 'jpo/patent/issue/gat-issue-%1$s.xsd'
    ]
    private static jaxbMap = [
        A : 'jpo.patent.a.gat_a.%1$s.jaxb',
        A5: 'jpo.patent.a.gat_a5.%1$s.jaxb',
        A6: 'jpo.patent.a.gat_a6.%1$s.jaxb',
        B6: 'jpo.patent.b.gat_b6.%1$s.jaxb',
        B9: 'jpo.patent.b.gat_b9.%1$s.jaxb',
        BC: 'jpo.patent.b.gat_vc.%1$s.jaxb',
        DD: 'jpo.patent.design.des.%1$s.jaxb',
        DG: 'jpo.patent.design.des.%1$s.jaxb',
        DGC: 'jpo.patent.design.descor.%1$s.jaxb',
        S: 'jpo.patent.s.gat_s.%1$s.jaxb',
        S5: 'jpo.patent.s.gat_s5.%1$s.jaxb',
        S6: 'jpo.patent.s.gat_s6.%1$s.jaxb',
        T: 'jpo.patent.t.gat_t.%1$s.jaxb',
        T5: 'jpo.patent.t.gat_t5.%1$s.jaxb',
        T6: 'jpo.patent.t.gat_t6.%1$s.jaxb',
        U7: 'jpo.patent.u.gat_u7.%1$s.jaxb',
        U9: 'jpo.patent.u.gat_u9.%1$s.jaxb',
        UB: 'jpo.patent.u.gat_ub.%1$s.jaxb',
        UC: 'jpo.patent.u.gat_uc.%1$s.jaxb',
        PUBLICATION: 'jpo.patent.publication.gat_publication.%1$s.jaxb',
        ISSUE: 'jpo.patent.issue.gat_issue.%1$s.jaxb'
    ]
    private static jaxbRootMap = [
        A : 'jpo.patent.a.gat_a.%1$s.jaxb.JpOfficialGazette',
        A5: 'jpo.patent.a.gat_a5.%1$s.jaxb.JpOfficialGazette',
        A6: 'jpo.patent.a.gat_a6.%1$s.jaxb.JpOfficialGazette',
        B6: 'jpo.patent.b.gat_b6.%1$s.jaxb.JpOfficialGazette',
        B9: 'jpo.patent.b.gat_b9.%1$s.jaxb.JpOfficialGazette',
        BC: 'jpo.patent.b.gat_vc.%1$s.jaxb.JpOfficialGazette',
        DD: 'jpo.patent.design.des.%1$s.jaxb.DESGAZ',
        DG: 'jpo.patent.design.des.%1$s.jaxb.DESGAZ',
        DGC: 'jpo.patent.design.descor.%1$s.jaxb.CORDESGAZ',
        S: 'jpo.patent.s.gat_s.%1$s.jaxb.JpOfficialGazette',
        S5: 'jpo.patent.s.gat_s5.%1$s.jaxb.JpOfficialGazette',
        S6: 'jpo.patent.s.gat_s6.%1$s.jaxb.JpOfficialGazette',
        T: 'jpo.patent.t.gat_t.%1$s.jaxb.JpOfficialGazette',
        T5: 'jpo.patent.t.gat_t5.%1$s.jaxb.JpOfficialGazette',
        T6: 'jpo.patent.t.gat_t6.%1$s.jaxb.JpOfficialGazette',
        T7: 'jpo.patent.u.gat_u7.%1$s.jaxb.JpOfficialGazette',
        U9: 'jpo.patent.u.gat_u9.%1$s.jaxb.JpOfficialGazette',
        UB: 'jpo.patent.u.gat_ub.%1$s.jaxb.JpOfficialGazette',
        UC: 'jpo.patent.u.gat_uc.%1$s.jaxb.JpOfficialGazette',
        PUBLICATION: 'jpo.patent.publication.gat_publication.%1$s.jaxb.JpOfficialGazette',
        ISSUE: 'jpo.patent.issue.gat_issue.%1$s.jaxb.JpOfficialGazette'
    ]
    private static String categoryXsd
    private static String categoryJaxb
    private static Class categoryJaxbRootClass
    
    private static String validatorXsd
    private static String validatorJaxb
    private static Class validatorJaxbRootClass
    
    /** initialize Marshlling process to specifical xsd version
     * @param patentType the patent type
     * @param inputXsdVersion the xsd version for corresponding patent type
     */
    def static initMarshallImportUtils(patentType ,inputXsdVersion) {
        // if enter xsdVersion, set the version value.
        this.xsdVersion = inputXsdVersion;
        initMarshallImportUtils(patentType)
        this.xsdVersion = "v1" // set it back to defaults
    }
    /** initialize Marshlling process to without specifical xsd version (default value = v1)
     * @param patentType the patent type
     */
    def static initMarshallImportUtils(patentType) {
        // check the petentType and category is well defined
        
        def category = null
        for (String s : PublicationType.values()){
            if (s == patentType) {
                category = "PUBLICATION"
                break
            }
        }
        for (String s : IssueType.values()){
            if (s == patentType) {
                category = "ISSUE"
                break
            }
        }
        for (String s : DesignType.values()){
            if (s == patentType) {
                category = "DG"
                break
            }
        }
        if (!category) {
            throw new Exception("No defined patent type: "+patentType)
            return
        }
        
        // Given the xsd and jaxb class
        categoryXsd = sprintf(xsdMap.get(category),xsdVersion)
        categoryJaxb = sprintf(jaxbMap.get(category),xsdVersion)
        categoryJaxbRootClass = Class.forName(sprintf(jaxbRootMap.get(category),xsdVersion))
        JAXBContext jc = JAXBContext.newInstance(categoryJaxb)
        categoryUnmarshaller = jc.createUnmarshaller()
        // Given the xsd and jaxb class to validate.
        validatorXsd = sprintf(xsdMap.get(patentType),xsdVersion)
        validatorJaxb = sprintf(jaxbMap.get(patentType),xsdVersion)
        validatorJaxbRootClass = Class.forName(sprintf(jaxbRootMap.get(patentType),xsdVersion))
        JAXBContext jcV = JAXBContext.newInstance(validatorJaxb)
        validateUnmarshaller = jcV.createUnmarshaller()
        
        
        // print information of the patentType
        println "\nUnmarshall:"
        println "xsd application:"+ categoryXsd
        println "jaxb application:"+ categoryJaxb
        println "jaxbRootClass application:"+ categoryJaxbRootClass+"\n"
        
        println "Validate:"
        println "xsd application:"+ validatorXsd
        println "jaxb application:"+ validatorJaxb
        println "jaxbRootClass application:"+ validatorJaxbRootClass+"\n"
        
        // Set up unmarshaller
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI)
        InputStream xsdis = ClassLoader.getSystemClassLoader().getResourceAsStream(categoryXsd)
        Schema schema = sf.newSchema(new StreamSource(xsdis))
        categoryUnmarshaller.setSchema(schema)
        
        sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI)
        xsdis = ClassLoader.getSystemClassLoader().getResourceAsStream(validatorXsd)
        schema = sf.newSchema(new StreamSource(xsdis))
        validateUnmarshaller.setSchema(schema)
        
        // Set up marshaller
        List<InputStream> moxyBindings = new ArrayList<InputStream>()
        Map<String, Object> props = new HashMap<String, Object>()
        props.put(JAXBContextProperties.OXM_METADATA_SOURCE, moxyBindings)
        props.put(JAXBContextProperties.JSON_INCLUDE_ROOT, false)
        props.put(JAXBContextProperties.MEDIA_TYPE, MediaType.APPLICATION_JSON)
        JAXBContext jc1 = JAXBContext.newInstance( categoryJaxb, getCategoryJaxbClassLoader(), props)
        marshaller = jc1.createMarshaller()
        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json")
        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true)
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)
    }
    
    def static slurper = new JsonSlurper()
    def static xml2Json(xml) {
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance()
        docBuilderFactory.setNamespaceAware(true)
        Document doc
        
        // extract contents
        try {
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder()
            doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")))
        } catch (Exception e) {
            throw new Exception("Problem on recognizing invoice type of given xml, cause: ", e)
        }
        
        // Separately validate doc with their own xsd. If it passes, go to unmarshal it with catogory xsd.
        try {
            validateUnmarshaller.unmarshal(doc, validatorJaxbRootClass)
        } catch (Exception e) {
            throw new Exception("Fail to pass validate of "+validatorXsd.toString(),e)
            return
        }
        
        // unmarshall with category xsd
        try {
            def unmarshallerElem = getUnmarshallerElem(doc)
            StringWriter sw = new StringWriter();
            marshaller.marshal(unmarshallerElem.getValue(), sw)
            return slurper.parseText(sw.toString())
        }  catch (Exception e) {
            throw new Exception("Fail to pass validate of "+categoryXsd.toString())
            return
        }
    }
    
    def static getUnmarshallerElem (doc) {
        return categoryUnmarshaller.unmarshal(doc, categoryJaxbRootClass)
    }
    def static getCategoryJaxbClassLoader() {
        return categoryJaxbRootClass.getClassLoader()
    }
    def static getValidatorJaxbClassLoader() {
        return validatorJaxbRootClass.getClassLoader()
    }
    
    def static saveOrCatchException(marshallCol,doc){
        try{
            marshallCol.save(doc)
        } catch (Exception e) {
            def title = "mongoDB saving error"
            println title + ": " + doc._id
            e.printStackTrace()
            def errObj = new BasicDBObject()
            errObj.append("createDate", new Date())
            errObj.append("rawId", doc._id)
            errObj.append("title", title)
            errObj.append("errMsg", e.getMessage())
            errCol.save(errObj)
        }
    }
    def static errCol
    def static marshallCol
    def static importMarshallToMongo (doc, timeStamp, filename) {
        // remove createDate, which is the data of creating for raw data importation.
        if (!!doc.containsField("createDate")) {
            doc.removeField("createDate")
        }
        
        try {
            doc.data = xml2Json(doc.data.xml)
            
        } catch (Exception e) {
            
            def title = "marshall error"
            println title + ": " + doc._id
            e.printStackTrace()
            def errObj = new BasicDBObject()
            errObj.append("createDate", new Date())
            errObj.append("rawId", doc._id)
            errObj.append("title", title)
            errObj.append("errMsg", e.getMessage())
            // To store stack trace of XMLMarshal exception
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errObj.append("errStackTrace", sw.toString())
            
            errCol.save(errObj)
            return false
        }
        def oldDoc = marshallCol.findOne(new BasicDBObject("_id", doc._id))
        if(oldDoc) {
            
            // directly overwrite
            oldDoc.data = doc.data
            // remove createDate, which is the data of creating for raw data importation.
            if (!!oldDoc.containsField("createDate")) {
                oldDoc.removeField("createDate")
            }
            
            def buildTimeStampAndFile = oldDoc.buildTimeStampAndFile
            def isRepeat = buildTimeStampAndFile.any { timeStamAndFile ->
                if(timeStamAndFile.buildTimeStamp == timeStamp && timeStamAndFile.filename == filename) {
                    return true
                }
            }
            if(!isRepeat) {
                def curBuildTimeStampAndFile = new BasicDBObject()
                curBuildTimeStampAndFile.append("buildTimeStamp", timeStamp)
                curBuildTimeStampAndFile.append("filename", filename)
                buildTimeStampAndFile.add(curBuildTimeStampAndFile)
            }
            oldDoc.buildTimeStampAndFile = buildTimeStampAndFile
            oldDoc.mongoSyncFlag.last = new Date()
            saveOrCatchException(marshallCol,oldDoc)
        } else {
            def dbList = new BasicDBList()
            def curBuildTimeStampAndFile = new BasicDBObject()
            curBuildTimeStampAndFile.append("buildTimeStamp", timeStamp)
            curBuildTimeStampAndFile.append("filename", filename)
            dbList.add(curBuildTimeStampAndFile)
            doc.append("buildTimeStampAndFile", dbList)
            def mongoSyncFlag = new BasicDBObject()
            mongoSyncFlag.append("init", new Date())
            mongoSyncFlag.append("last", new Date())
            doc.append("mongoSyncFlag", mongoSyncFlag)
            saveOrCatchException(marshallCol,doc)
        }
        return true
    }
    def static importMarshallToMongo (doc, timeStamp, filename, len, count) {
        importMarshallToMongo (doc, timeStamp, filename)
       
        ProgressUtils.printlnProgress(count, len, doc.dateOfPublicAvailability)
        return true
    }
}
