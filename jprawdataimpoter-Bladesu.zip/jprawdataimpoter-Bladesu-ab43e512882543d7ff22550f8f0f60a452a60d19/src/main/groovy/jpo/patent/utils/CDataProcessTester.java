package jpo.patent.utils;

import patentdata.utils.CDataProcess;

public class CDataProcessTester {
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        CDataProcess process = new CDataProcess(true,
                "/p:child"
                ); 
        try {
            System.out.println( process.transfer("<p:child num=\"\">abc</p:child>")  );
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
}
