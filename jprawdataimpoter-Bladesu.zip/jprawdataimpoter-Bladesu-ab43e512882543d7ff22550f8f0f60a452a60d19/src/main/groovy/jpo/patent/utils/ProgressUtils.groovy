package jpo.patent.utils

import java.text.SimpleDateFormat

class ProgressUtils {
    def static startTime
    def static latestPrintTime
    def static sdfCurTime = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss")
    def static printlnProgress(count, len , doDate) {
        def curTime = Calendar.instance.time.time
        if(((curTime - latestPrintTime) > 10*1000) || (count == len)) {
            latestPrintTime = curTime
            def rest = (float)(curTime - startTime)*(float)(len - count)
            rest = rest/count
            def msec = ((int)rest%1000)
            rest = (int)rest/1000
            def sec = (int) (rest%60)
            rest = (int)rest/60
            def min = (int) (rest%60)
            rest = (int)rest/60
            def hr = (int) rest;
            def percent = (int)count*100/len
            def restStr
            if (hr > 0) {
                    restStr = sprintf('%02d:%02d:%02d', hr, min, sec)
                } else if (min > 0) {
                    restStr = sprintf('%02d:%02d', min, sec)
                } else {
                    restStr = sprintf('%02d.%02d', sec, msec)
            }
            println sprintf('%s - %d/%d(%d%%), rest time: %s, cur dateOfPublicAvailability %s',
                            sdfCurTime.format(new Date()), count, len, percent, restStr,
                            sdfCurTime.format(doDate))
        }
    }
}
