package jpo.patent.utils

import google.utils.GooglePatentClients
import groovy.io.FileType

import java.text.SimpleDateFormat

import org.dom4j.io.SAXReader

import com.mongodb.BasicDBObject
import com.mongodb.DBCursor
import com.mongodb.DBObject
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper
import jpo.patent.utils.ProgressUtils;

import java.util.regex.Matcher
import java.util.regex.Pattern


class XmlImportUtils {
    def static filesizeLimit = 1024 * 1024 * 14
    //def static filesizeLimit = 1024 * 2
    def static provider = "JPO"
    def static pto = "JPO"
    def static importType = null
    static enum EscapedPatentType{
        sequenceListXML,sequenceListSGM
    }
    
    // For each type of JPO patent, we should define the patentTypeName and importPathReg here.
    
    // (1) patent type name to be recognized by human.
    def static patentTypeName = jpo.patent.constant.Documents.patentTypeName
    
    // (2) path of the files which to be recognized by program.
    def static importPathRegXML = jpo.patent.constant.Path.regexPatternForXML
    def static importPathRegSGM = jpo.patent.constant.Path.regexPatternForSGM
    
    def static importPathReg = [:]
    static {
        importPathRegXML.each{k,v ->
            importPathReg.put(k,v)
            
        }
        importPathRegSGM.each{k,v ->
            importPathReg.put(k,v)
        }
    }
    
    // (3) type of the patent which will be imported.
    def static importTypeSet = []
    static {
        importPathRegXML.each{k,v ->
            importTypeSet.add(k)
            
        }
        importPathRegSGM.each{k,v ->
            importTypeSet.add(k)
        }
        importTypeSet = importTypeSet as Set
    }
    
    // (4) Regular expression of the specific content of each type.
    def static dtdTypesRegXML = jpo.patent.constant.Documents.docContentPatternForXML
    def static dtdTypesRegSGM = jpo.patent.constant.Documents.docContentPatternForSGM
    // mixed dtd type regex pattern map
    def static dtdTypesReg = [:]
    static {
        dtdTypesRegXML.each { k,v ->
            dtdTypesReg.put(k,v)
        }
        dtdTypesRegSGM.each { k,v ->
            dtdTypesReg.put(k,v)
        }
    }
    
    // (5) two other map to save time.
    def static JPWO_kindcode_regex_map = jpo.patent.constant.Documents.JPWO_kindcode_regex_map
    def static JPWO_kindcode_map = jpo.patent.constant.Documents.JPWO_kindcode_map
    
    /**
     * 全角转半角
     *
     * @param input
     *            String.
     * @return 半角字符串
     */
    public static String toHalfWidth(String input) {
        
        char[] c = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == '\u3000') {
                c[i] = ' ';
            } else if (c[i] > '\uFF00' && c[i] < '\uFF5F') {
                c[i] = (char) (c[i] - 65248);
                
            }
        }
        
        return new String(c);
    }
    def static extractRawXml(dir,importType) {
        //
        // In the beginning, to check the patent type was defined.
        // So the importType could be trusted in the following process "importFileToMongo"
        if (!importTypeSet.contains(importType)){
            
            throw new Exception("Undefined patent type to import!!!!!!")
        }
        println "The patent type here is:"+patentTypeName[importType]
        this.importType = importType
        //
        
        // Check the type is exist well for the two array.
        try {
            patentTypeName[importType]
            importPathReg[importType]
        } catch (e) {
            println "undefined patent type"
            e.printStackTrace()
            return null
        } // end of checking
        
        
        // Begin extracting file list according to the regex rule for file path.
        println "extract raw data file list..."
        println "Fitting this pattern: "+ importPathReg[importType]
        def list = []
        Pattern regex = Pattern.compile(importPathReg[importType], Pattern.CASE_INSENSITIVE)
        if (dir.isDirectory()){
            dir.eachFileRecurse (FileType.FILES) { file ->
                def fileStr = file.toString()
                def me = regex.matcher(fileStr)
                def check = me.matches()
                if (check) {
                    list << file
                }
            }
        } else if (dir.isFile()){
            def fileStr = dir.toString()
            def me = regex.matcher(fileStr)
            def check = me.matches()
            if (check) {
                list << dir
            }
        }
        return list
    }
    def static extractRawXml(dir) {
        def list = []
        if (dir.isDirectory()){
            dir.eachFileRecurse (FileType.FILES) { file ->
                // At least it should be .xml or .SGM
                if (file.toString() =~ /(i?)(.SGM|.xml)$/)
                    list << file
            }
        } else if (dir.isFile()){
            list << dir
        }
        return list
    }
    def static errCol
    def static saveErrObj(relatePath, title, e) {
        println title + ": " + relatePath
        def errObj = new BasicDBObject()
        errObj.append("createDate", new Date())
        errObj.append("path", relatePath)
        errObj.append("title", title)
        errObj.append("errMsg", e.getMessage())
        errCol.save(errObj)
    }
    
    def static rawCol
    def static saveRawObj(id, fileContents, doDate, relatePath, truncate, kindcode,kind_of_jp,type,dateOfPublicAvailability) {
        def rawObj = new BasicDBObject()
        rawObj.append("_id", id)
        
        // 確認之前有寫入同樣id但不同資料來源的話，不存入PatentRawJPO，而存該筆資料和錯誤資訊到ErrorPatentRawJPO.
        DBObject  queryObj = rawCol.findOne(rawObj)
        
        if(queryObj){
            String previousInserted = queryObj.get("path").toString()
            if(relatePath != previousInserted){
                saveErrObj(relatePath, id+" existed before.",
                        new Exception(" Err: The _id has been inserted by other source:"+previousInserted))
                return
            }
        }
        
        
        rawObj.append("path", relatePath)
        rawObj.append("data", new BasicDBObject("xml", fileContents.toString()))
        rawObj.append("doDate", doDate)
        rawObj.append("dateOfPublicAvailability", dateOfPublicAvailability)
        rawObj.append("kindcode", kindcode)
        rawObj.append("kind_of_jp",kind_of_jp)
        rawObj.append("provider", provider)
        rawObj.append("pto", pto)
        rawObj.append("truncate", truncate)
        rawObj.append("type", type)
        rawObj.append("createDate", new Date())
        
        // 若無法存入DB，則改存錯誤記錄到Error DB
        try{
            rawCol.save(rawObj)
        } catch (Exception e){
            saveErrObj(relatePath, "Fail to save doc to DB.", e)
        }
    }
    
    /**
     * formatedPatentId_xml: 
     * format for issue: (JP)(7#)(kindcode)(-)(kind-of-jp)(-)(dateOfPublicAvailability)
     * format for publication: (JP)(yyyy+7#)(kindcode)(-)(kind-of-jp)(-)(dateOfPublicAvailability)
     * @param docNumber, kindcode, dateOfPublicAvailability, importType, kind_of_jp
     * @return formatted id
     */
    def static private formatedPatentId_xml (docNumber, kindcode, dateOfPublicAvailability, kind_of_jp) {
        
        // Just in case the some value is null or empty.
        if ( (!docNumber) || (!kindcode) || (!dateOfPublicAvailability) || (!kind_of_jp) ){
            throw new Exception("null value founded when formatedPatentId_xml. "+
            "docNumber:"+docNumber+" "+
            "kindcode:"+kindcode+" "+
            "dateOfPublicAvailability:"+dateOfPublicAvailability+" "+
            "kind_of_jp:"+kind_of_jp
            )
        }
        
        switch (kind_of_jp) {
            case ~/A|T/:
                if (!(docNumber.length() == 10)) {
                    // In case the rule of digital changes.
                    throw new Exception("kind_of_jp("+kind_of_jp+") has wrong docNumber digital :"+docNumber.length())
                }
                def pubSerialNmber = String.format("%1\$4s%2\$7s", docNumber[0..3],docNumber[4..-1]).replace(' ', '0')
                return "JP" + pubSerialNmber + kindcode + "-" + kind_of_jp + "-" + dateOfPublicAvailability
                break
            case ~/S/:
                if (!(docNumber =~ /WO[0-9]{10}/)) {
                    // In case the rule of digital changes.
                    throw new Exception("kind_of_jp("+kind_of_jp+") has wrong docNumber pattern"+docNumber)
                }
                def pubSerialNmber = String.format("WO%1\$4s%2\$7s", docNumber[2..5],docNumber[6..-1]).replace(' ', '0')
                return "JP" + pubSerialNmber + kindcode + "-" + kind_of_jp + "-" + dateOfPublicAvailability
                break
            case ~/B9|U9/:
                if (!(docNumber.length() == 7)) {
                    // In case the rule of digital changes.
                    throw new Exception("kind_of_jp("+kind_of_jp+") has wrong docNumber pattern"+docNumber)
                }
                def pubSerialNmber = String.format("%1\$7s",docNumber).replace(' ', '0')
                return "JP" + pubSerialNmber + kindcode + "-" + kind_of_jp + "-" + dateOfPublicAvailability
                break
            default:
                throw new Exception("Undefined inputType, no id formatting rule to fit it: kind_of_jp("+kind_of_jp+")" )
                break
        }
    }
    /**
     * formatedPatentId_sgm:
     * format for 意匠: (JP)(7#)(_3#)(kindcode)(-)(kind-of-jp)(-)(dateOfPublicAvailability)
     * @param docNumber, kindcode, dateOfPublicAvailability, importType, kind_of_jp
     * @return formatted id
     */
    def static private formatedPatentId_sgm (docNumber, kindcode, dateOfPublicAvailability, kind_of_jp) {
        
        // Just in case the some value is null or empty.
        if ( (!docNumber) || (!kindcode) || (!dateOfPublicAvailability) || (!kind_of_jp) ){
            throw new Exception("null value founded when formatedPatentId_xml. "+
            "docNumber:"+docNumber+" "+
            "kindcode:"+kindcode+" "+
            "dateOfPublicAvailability:"+dateOfPublicAvailability+" "+
            "kind_of_jp:"+kind_of_jp
            )
        }
        
        // 處理連續意匠(意匠公報的一種，2000年初常出現)
        if (docNumber =~ /.*?\/.*?/) {
            def docNumberHead= docNumber[0..docNumber.indexOf("/")-1]
            def docNumberTail= docNumber[docNumber.indexOf("/")+1..-1]
            if (docNumberHead.length() > 7) {
                throw new Exception("DocNumber:"+docNumber)
            }
            docNumber =
                    String.format("%1\$7s",docNumberHead).replace(' ', '0') +"_"+
                    String.format("%1\$3s",docNumberTail).replace(' ', '0')
        } else {
            if (docNumber.length() > 7) {
                throw new Exception("DocNumber:"+docNumber)
            }
        }
        // 分不同意匠處理
        if (kind_of_jp == "DG") {
            def pubSerialNmber = String.format("%1\$7s",docNumber).replace(' ', '0')
            return "JP" + pubSerialNmber + kindcode + "-" + kind_of_jp + "-" + dateOfPublicAvailability
        }
    }
    
    def static sdfDoDateParse = new SimpleDateFormat("yyyyMMdd")
    
    def static importFileToMongo(file, len, count) {
        
        def fileContents = null
        try {
            fileContents = file.getText("EUC-JP")
        } catch (Exception e) {
            saveErrObj(file.toString(), "Can not getText(\"EUC-JP\")", e)
            return
        }
        def absolutePath = file.toString()
        // 擷取相對路徑的同時將目錄結構全都替換成斜線
        def relatePath = absolutePath.substring(absolutePath.indexOf("JP")+3).replaceAll("\\\\","/")
        
        // Parse the type of the folder type and content type
        def parsedFileExtension = null
        def parsedPatentType = null
        def parsedFolderType = null
        
        switch (relatePath) {
            case ~/.*.xml$/:
                parsedFileExtension = "xml/xml"
            
            /*
             *  Parse folder type
             */
                def acceptedPathN = 0
                importPathRegXML.each { k1,v1 ->
                    if (relatePath =~ v1) {
                        acceptedPathN = acceptedPathN+1
                        parsedFolderType = k1
                    }
                }
                if (acceptedPathN < 1) {
                    // No accepted path type
                    return
                } else if (acceptedPathN > 1) {
                    saveErrObj(relatePath,
                            "Multiple accepted path. Wrong folder structure",
                            new Exception()
                            )
                    return
                }
            
            // If assigned patent type and the type mismatches with folder type...
            // It is impossible due to the pre-selection when extracting file list.
                if (importType) {
                    if (parsedFolderType != importType) {
                        saveErrObj(relatePath,
                                "Parsed folder type is mismatched with pre-selected file list.",
                                new Exception()
                                )
                        return
                    }
                }
            
            // The cutted content to save calculation time, for jpo xml file
            // the dtd information only located at the first three lines.
                def examStr =fileContents.substring(0,
                        fileContents.indexOf("\n",
                        fileContents.indexOf("\n",
                        fileContents.indexOf("\n")+1)+1)+1)
            
            
            // Parsing header to check patent type
            // If the patent type is assigned, the program only check the assigned type.
            
                if (examStr =~ dtdTypesRegXML.getAt(parsedFolderType)) {
                    parsedPatentType = parsedFolderType
                } else {
                    if (examStr =~ dtdTypesRegXML.getAt(EscapedPatentType.sequenceListXML.toString())) {
                        // the EscapedPatentType should be avoided to advanced process
                        return
                    } else {
                        // the folder type disagree with parsed dtd type, so save err to err db and return
                        if (importType) {
                            saveErrObj(relatePath,
                                    "Mismatched type",
                                    new Exception("Dtd type is mismatched with assigned file type: "+ importType)
                                    )
                        } else {
                            saveErrObj(relatePath,
                                    "Mismatched type",
                                    new Exception("Dtd type is mismatched with assigned folder type: "+parsedFolderType)
                                    )
                        }
                        return
                    }
                }
            
                break
            case ~/.*.SGM$/:
            
                parsedFileExtension = "sgm/sgm"
            
            
            // Parse folder type
                def acceptedPathN = 0
                importPathRegSGM.each { k1,v1 ->
                    if (relatePath =~ v1) {
                        acceptedPathN = acceptedPathN+1
                        parsedFolderType = k1
                    }
                }
                if (acceptedPathN < 1) {
                    // No accepted path type
                    return
                } else if (acceptedPathN > 1) {
                    saveErrObj(relatePath,
                            "Multiple accepted path. Wrong folder structure",
                            new Exception()
                            )
                    return
                }
            
            // If assigned patent type and the type mismatches with folder type...
            // It is impossible due to the pre-selection when extracting file list.
                if (importType) {
                    if (parsedFolderType != importType) {
                        saveErrObj(relatePath,
                                "Parsed folder type is mismatched with pre-selected file list.",
                                new Exception()
                                )
                        return
                    }
                }
            
            /*
             *  Parsing header to check patent type
             */
            // If the patent type is assigned, the program only check the assigned type.
                if (fileContents =~ dtdTypesRegSGM.getAt(parsedFolderType)) {
                    parsedPatentType = parsedFolderType
                } else {
                    if (fileContents =~ dtdTypesRegSGM.getAt(EscapedPatentType.sequenceListSGM.toString())) {
                        
                        // the EscapedPatentType should be avoided to advanced process
                        return
                    } else {
                        
                        // the folder type disagree with parsed dtd type, so save err to err db and return
                        if (importType) {
                            saveErrObj(relatePath,
                                    "Mismatched type",
                                    new Exception("Dtd type is mismatched with assigned file type: "+ importType)
                                    )
                        } else {
                            saveErrObj(relatePath,
                                    "Mismatched type",
                                    new Exception("Dtd type is mismatched with assigned folder type: "+parsedFolderType)
                                    )
                        }
                        return
                    }
                }
            
                break
            default:
            // Other file, escape it,
                return null
                break
        }
        
        /*
         * Fix the xml or SGM content to proper style.
         */
        try {
            fileContents = jpo.patent.XmlUtils.fixXml(fileContents,parsedFileExtension)
        } catch (Exception e) {
            e.printStackTrace()
            saveErrObj(relatePath, "There are some error while fix xml", e)
            return
        }
        
        def rootNode = null
        try {
            rootNode = new XmlSlurper(false,false).parseText(fileContents)
        } catch (Exception e) {
            e.printStackTrace()
            saveErrObj(relatePath, "XmlSlurper import error", e)
            return
        }
        
        /*
         * xml 超過 mongodb doc 上限時需要特別處理
         */
        def truncate = false
        if (fileContents.length() > filesizeLimit) {
            String tempStr = rootNode."description".text()
            float sizeScalae = (float) (fileContents.length() / filesizeLimit) * 1.2f
            rootNode."description".replaceBody( tempStr.substring(0, (int) (tempStr.length() / sizeScalae)))
//            println "size"+fileContents.length()
            fileContents = groovy.xml.XmlUtil.serialize(rootNode)
//            println "size"+fileContents.length()
            truncate = true
        }
        
        // begin of parsing necessary data to contract ID, and other terms.
        def doDate = null
        def doDateStr = null
        def dateOfPublicAvailability = null
        def dateOfPublicAvailabilityStr = null
        def kindcode = null //standard 16
        def kind_of_jp = parsedPatentType
        def docNumber = null
        
        /*
         * Parsed doDate
         */
        switch (parsedPatentType) {
            case ~ /A|T|B9|U9/:
            // A: "公開特許公報(A)"     pdf上定義:公開日
            // T: "公表特許公報(A)"     pdf上定義:公表日
            // B9: "特許公報(B2)"      pdf上定義:登錄日
            // U9: "登録実用新案公報(U)" pdf上定義:登錄日
                try {
                    doDateStr =rootNode."bibliographic-data"."publication-reference"."document-id"."date".text()
                    doDate = sdfDoDateParse.parse(doDateStr)
                } catch (Exception e){
                    saveErrObj(relatePath, "Fail to parsing doDate", e)
                    return null
                }
                break
            
            case "S":
            // S:"再公表特許(A1)"，  pdf上之定義:發行日
                try {
                    doDateStr = rootNode."bibliographic-data"."jp:corrected-publication-date".text()
                    doDate = sdfDoDateParse.parse(doDateStr)
                } catch (Exception e){
                    saveErrObj(relatePath, "Fail to parse doDate (再公表)", e)
                    return null
                }
                break
            case "DG":
            // DG:"意匠公報（Ｓ）" pdf上之定義:登錄日
                try {
                    
                    def dateStr = toHalfWidth(rootNode."REGISTRATION-DATE".text())
                    def dateGroup = (dateStr =~ /.*\((.*?)\.(.*?)\.(.*?)\)/)
                    
                    if (!dateGroup.hasGroup()) {
                        throw new Exception()
                    }
                    
                    doDateStr = sprintf('%4s%2s%2s',
                            dateGroup[0][1],
                            dateGroup[0][2],
                            dateGroup[0][3]).replaceAll(" ","0")
                    doDate = sdfDoDateParse.parse(doDateStr)
                    ///////////////////////////////
                } catch (Exception e){
                    saveErrObj(relatePath, "Fail to parsing doDate", e)
                    return null
                }
                break
            default:
            // Some pattern type did not be ready to import
            
            // To Do: 等到每種專利文件都完成此switch-case，要解開這個封印。
            // println "Invalid parsedPatentType, please fix it!"
            // saveErrObj(relatePath, "Invalid parsedPatentType", new Exception())
                return null
                break
        } // end of doDateparsing
        
        /*
         parsed dateOfPublicAvailability (專門用以官網查詢)
         */
        if (parsedPatentType =~ /B9|U9/) {
            // B9: "特許公報(B2)"      pdf上定義:發行日
            // U9: "登録実用新案公報(U)" pdf上定義:發行日
            try {
                dateOfPublicAvailabilityStr = rootNode."bibliographic-data"."dates-of-public-availability"."printed-with-grant"."document-id"."date".text()
                dateOfPublicAvailability = sdfDoDateParse.parse(dateOfPublicAvailabilityStr)
                
            } catch (Exception e){
                saveErrObj(relatePath, "Fail to parsing dateOfPublicAvailability", e)
                return null
            }
        } else if (parsedPatentType =~ /DG/) {
            // DG:"意匠公報（Ｓ）"     pdf上定義:發行日
            try {
                def dateStr = toHalfWidth(rootNode."PUBLICATION-DATE".text())
                def dateGroup = (dateStr =~ /.*\((.*?)\.(.*?)\.(.*?)\)/)
                
                if (!dateGroup.hasGroup()) {
                    throw new Exception()
                }
                dateOfPublicAvailabilityStr = sprintf('%4s%2s%2s',
                        dateGroup[0][1],
                        dateGroup[0][2],
                        dateGroup[0][3]).replaceAll(" ","0")
                dateOfPublicAvailability = sdfDoDateParse.parse(dateOfPublicAvailabilityStr)
                
            } catch (Exception e){
                saveErrObj(relatePath, "Fail to parsing dateOfPublicAvailability", e)
                return null
            }
        } else {
            // 公開特許公報(A):    pdf上定義: 公開日
            // 公表特許公報(A):    pdf上定義: 公表日
            // 再公表特許(A1) :    pdf上定義:発行日
            
            dateOfPublicAvailabilityStr = doDateStr
            dateOfPublicAvailability = doDate
        }
        
        /*
         Parse kindcode
         */
        if (parsedFileExtension == "xml/xml") {
            // parse @kind-of-st16 as kindcode
            try {
                kindcode = rootNode."@kind-of-st16".text().toUpperCase()
            } catch (Exception e) {
                saveErrObj(relatePath, "no @kind-of-st16", e)
                return null
            }
            // Check whether the parsed kindcode is under restriction of
            // mapping between kindcode and kind-of-jp
            if (!(kindcode =~ JPWO_kindcode_regex_map.getAt(kind_of_jp))){
                // note: JPWO_kindcode_regex_map can have multiple domain of definition.
                //       If some exception happens, please consider add definition of JPWO_kindcode_regex_map.
                saveErrObj(relatePath,
                        "Undefined mapping relation of kindcode and kind_of_jp",
                        new Exception() )
            }
            
        } else {
            // For sgm/sgm, the only way to get kindcode is parsing content which is done before.
            kindcode = JPWO_kindcode_map.getAt(kind_of_jp)
        }
        
        /*
         Parse docNumber:
         */
        if (parsedFileExtension == "xml/xml") {
            
            try {
                docNumber = rootNode."bibliographic-data"."publication-reference"."document-id"."doc-number".text()
            } catch (Exception e){
                saveErrObj(relatePath, "Fail to parsing docNumber", e)
                return null
            }
        } else { // For "sgm/sgm"
            
            try {
                docNumber = toHalfWidth(rootNode."REGISTRATION-NUMBER".text())
                def docGroup = (docNumber =~ /.*?\(D(.*?)\)/)
                if (!docGroup.hasGroup()) {
                    throw new Exception("docNumber:"+docNumber)
                }
                docNumber = docGroup[0][1]
                
            } catch (Exception e){
                saveErrObj(relatePath, "Fail to parsing docNumber (sgm/smg)", e)
                return null
            }
        }
        // end of docNumber parsing
        // docNumber: 資料源舉例
        // 公表特許公報(A): docNumber=2012520659
        // 公開特許公報(A): docNumber=2012170328
        // 再公表特許(A1): docNumber=WO2010101056
        // 公開特許公報(A): docNumber=2012170328
        // 意匠公報（Ｓ）:docNumber=1081800 or 1071783/1 (連續意匠:2000~2003有很多)
        // 登録実用新案公報(U):docNumber=3172567
        //
        def id = null
        
        if (parsedFileExtension == "xml/xml") {
            try {
                id = formatedPatentId_xml(docNumber, kindcode, dateOfPublicAvailabilityStr,kind_of_jp)
                saveRawObj(id, fileContents, doDate, relatePath, truncate, kindcode , kind_of_jp ,parsedFileExtension,dateOfPublicAvailability)
            } catch (e) {
                saveErrObj(relatePath, "the id can not be formatted.", e)
            }
        } else {
            // parsedFileExtension == "sgm/sgm"
            try {
                id = formatedPatentId_sgm(docNumber, kindcode, dateOfPublicAvailabilityStr,kind_of_jp)
                saveRawObj(id, fileContents, doDate, relatePath, truncate, kindcode , kind_of_jp ,parsedFileExtension,dateOfPublicAvailability)
            } catch (e) {
                saveErrObj(relatePath, "the id can not be formatted.", e)
            }
        }
        
        //println "id:"+id +" doDate:"+doDateStr+" kindcode "
        ProgressUtils.printlnProgress(count, len, dateOfPublicAvailability)
    }
}
