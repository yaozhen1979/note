package jpo.patent.importer;
import java.text.SimpleDateFormat

import jpo.patent.utils.MarshallImportUtils
import jpo.patent.utils.ProgressUtils
import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import com.mongodb.MongoCredential
import com.mongodb.ServerAddress
class CDATAReviseAndMarshallImporter {
    public static void main (String[] args){
        //parser args
        def cli = new CliBuilder(
                usage: 'import jp raw data (2012~2014) to mongo, for jp design patent (2000~2014)',
                header: '\nAvailable options (use -h for help):\n')
        
        cli.with
        {
            h(longOpt: 'help', 'Usage Information', required: false)
            i(longOpt: 'mongo.ip', '', args: 1, required: true)
            u(longOpt: 'mongo.user', '', args: 1, required: true)
            w(longOpt: 'mongo.pwd', '', args: 1, required: true)
            d(longOpt: 'start.dateOfPublicAvailability', '2014/01/01', args: 1, required: true)
            e(longOpt: 'end.dateOfPublicAvailability', '2001/11/01', args: 1, required: true)
            t(longOpt: 'timestmp', '20160111', args: 1, required: true)
            kind_of_jp(longOpt: 'kind_of_jp', 'PUBLICATION|A|S|T;ISSUE|B9|U9;DG', args: 1, required: true)
            s(longOpt: 'number to skip', '100', args: 1, required: false)
            xsdv(longOpt: 'xsd version', 'v1, v2', args: 1, required: false)
            limit(longOpt: 'number to limit', '100', args: 1, required: false)
            loadList(longOpt: 'given _id list which separated by comma', '100', args: 1, required: false)
        }
        
        def opt = cli.parse(args)
        
        if (!opt) {
            cli.usage()
            assert opt : "some argument is required"
        }
        if (opt.h) cli.usage()
        
        def mongoIp = opt.i
        def mongoUser = opt.u
        def mongoPwd = opt.w
        
        
        // number to skip over
        def skipN = 0
        if (!!opt.s) {
            skipN = opt.s.toInteger()
        }
        
        // number to be the limit()
        
        def limitN = 0
        if (!!opt.limit) {
            limitN = opt.limit.toInteger()
        }
        
        // date format
        def sdf = new SimpleDateFormat("yyyy/MM/dd")
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"))
        def startDate = sdf.parse(opt.d)
        def endDate = sdf.parse(opt.e)
        
        // time stamp to recognize the date of processing
        def timeStmp = opt.t
        
        // xsd version
        def xsdV = null
        if (!!opt.xsdv) {
            xsdV = opt.xsdv
        }
        
        // The kind_of_jp to query.
        def kind_of_jp = null
        if (!!opt.kind_of_jp) {
            for (String kj : MarshallImportUtils.Type.values()){
                if (kj.equals(opt.kind_of_jp)){
                    kind_of_jp = opt.kind_of_jp.toString()
                }
            }
            if (!kind_of_jp){
                throw new Exception("The kind_of_jp is undefined.")
            }
        } else {
            throw new Exception("Must enter kind_of_jp.")
        }
        
        // Set up mongo client
        MongoCredential credential = MongoCredential.createCredential(mongoUser,"admin", mongoPwd.toCharArray());
        def mongoClient = new MongoClient(new ServerAddress(mongoIp, 27017), Arrays.asList(credential));
        def rawCol = mongoClient.getDB("PatentRawJPO").getCollection("PatentRawJPO")
        MarshallImportUtils.errCol = mongoClient.getDB("PatentMarshallJPO").getCollection("ErrorPatentMarshallJPO")
        MarshallImportUtils.marshallCol = mongoClient.getDB("PatentMarshallJPO").getCollection("PatentMarshallJPO")
        
        // parsedFileExtension
        def parsedFileExtension = null
        // initalize marshall, it should have corresponding proper xsd version.
        switch (kind_of_jp) {
            case "DG":
                if (!xsdV){
                    // default version is v2
                    MarshallImportUtils.initMarshallImportUtils("DG","v2")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("DG",xsdV)
                }
                parsedFileExtension="sgm/sgm"
                break
            
            case "A":
                if (!xsdV){
                    // default version is v1
                    MarshallImportUtils.initMarshallImportUtils("A","v1")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("A",xsdV)
                }
                parsedFileExtension="xml/xml"
                break
            
            case "T":
                if (!xsdV){
                    // default version is v1
                    MarshallImportUtils.initMarshallImportUtils("T","v1")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("T",xsdV)
                }
                
                parsedFileExtension="xml/xml"
                break
            
            case "S":
                if (!xsdV){
                    // default version is v1
                    MarshallImportUtils.initMarshallImportUtils("S","v1")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("S",xsdV)
                }
                
                parsedFileExtension="xml/xml"
                break
            
            case "B9":
                if (!xsdV){
                    // default version is v1
                    MarshallImportUtils.initMarshallImportUtils("B9","v1")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("B9",xsdV)
                }
                
                parsedFileExtension="xml/xml"
                break
            
            case "U9":
                if (!xsdV){
                    // default version is v1
                    MarshallImportUtils.initMarshallImportUtils("U9","v1")
                } else {
                    MarshallImportUtils.initMarshallImportUtils("U9",xsdV)
                }
                
                parsedFileExtension="xml/xml"
                break
            default:
                throw new Exception("Can not initial marshaller due to unknown kind_of_jp:" + kind_of_jp)
                break
        }
        // application of  loadList
        def idList = null
        if (opt.loadList) {
            idList = opt.loadList.split(',')
        }
        
        def query = new BasicDBObject();
        def dateQuery = new BasicDBObject();
        
        
        
        // apply _id list or time interval
        if (!!idList){
            // (1) Apply _id list
            idList.each { id ->
                println "Process "+ id
                def doc = rawCol.findOne(new BasicDBObject("_id",id))
                def len = 1
                def count = 1
                MarshallImportUtils.importMarshallToMongo(doc, timeStmp, "MarshallImporter.groovy")
            }
        } else {
            // (2) Time interval
            // doc to query
            
            dateQuery.append('''$gte''', startDate)
            dateQuery.append('''$lte''', endDate)
            query.append("kind_of_jp", kind_of_jp)
            query.append("dateOfPublicAvailability", dateQuery)
            
            def sortQuery = new BasicDBObject("dateOfPublicAvailability", 1)
            
            println "query: " + query.toString()
            def cursor = rawCol.find(query).sort(sortQuery).limit(0).skip(skipN).limit(limitN)
            def len = cursor.count()
            def count = skipN;
            
            ProgressUtils.startTime = Calendar.instance.time.time
            ProgressUtils.latestPrintTime = ProgressUtils.startTime
            
            cursor.each { doc ->
                count++
                try {
                    
                    doc.data.xml = jpo.patent.XmlUtils.fixXml(doc.data.xml.replaceAll(/<!\[CDATA\[([\s\S]*?)\]\]>/,/$1/),parsedFileExtension)
                    doc.createDate = new Date()
                    rawCol.save(doc)
                    
                } catch (e) {
                    throw new Exception("Error when fixXml")
                }
                
                MarshallImportUtils.importMarshallToMongo(doc, timeStmp, "MarshallImporter.groovy", len, count)
                
            }
        }
        println "finished"
    }
}
