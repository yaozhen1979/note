package jpo.patent.constant

class Path {
    def static regexPatternForXML = [
        A : /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)A(\/|\\).*.xml$/,   //公開特許公報
        //A5: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)A5(\/|\\).*.xml$/,
        //A6: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)A6(\/|\\).*.xml$/,
        //B6: /.*japanese_patent_and_registered_utility_model_specifications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)B6(\/|\\).*.xml$/, // NeverFind
        B9: /.*japanese_patent_and_registered_utility_model_specifications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)B9(\/|\\).*.xml$/,
        //BC: /.*japanese_patent_and_registered_utility_model_specifications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)BC(\/|\\).*.xml$/,
        S:  /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)S(\/|\\).*.xml$/,
        //S5: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)S5(\/|\\).*.xml$/,
        //S6: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)S6(\/|\\).*.xml$/,
        T:  /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)T(\/|\\).*.xml$/,
        //T5: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)T5(\/|\\).*.xml$/,
        //T6: /.*published_unexamined_patent_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)T6(\/|\\).*.xml$/,
        //U7: /.*published_registered_utility_model_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)U7(\/|\\).*.xml$/,
        U9: /.*published_registered_utility_model_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)U9(\/|\\).*.xml$/,
        //UB: /.*published_registered_utility_model_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)UB(\/|\\).*.xml$/,
        //UC: /.*published_registered_utility_model_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)UC(\/|\\).*.xml$/
    ]
    def static regexPatternForSGM = [
        DG:  /.*published_registered_design_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)DG(\/|\\).*.SGM$/,
        //DGC: /.*published_registered_design_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)DGC(\/|\\).*.SGM$/,
        //DD:  /.*published_registered_design_applications(\/|\\).*(\/|\\)DOCUMENT(\/|\\)DD(\/|\\).*.SGM$/
    ]
}
