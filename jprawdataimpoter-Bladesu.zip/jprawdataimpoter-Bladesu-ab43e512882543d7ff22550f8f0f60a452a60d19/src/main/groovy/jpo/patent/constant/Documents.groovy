package jpo.patent.constant

class Documents {
    def static patentTypeName =[
        // A
        // attribute of jp-official-gazette: kind-of-jp="A" kind-of-st16="A"
        // <jp-official-gazette><publication-reference><document-id><kind>公開特許公報(A)
        A : "公開特許公報(A)",   //公開特許公報
        
        // A5
        // attribute of jp-official-gazette: kind-of-jp="A5" kind-of-st16="A5"
        // <jp-official-gazette><publication-reference><document-id><kind>特許法第１７条の２の規定による補正の掲載
        A5: "特許法第１７条の２の規定による補正の掲載(note:公開特許公報)",
        
        // A6
        // attribute of jp-official-gazette: kind-of-jp="A6" kind-of-st16="A6"
        // <jp-official-gazette><jp:header><publication-reference><document-id><kind>公開特許公報の訂正
        A6: "公開特許公報の訂正",
        
        
        B6: "Not defined, please add",
        
        // b9
        // attribute of jp-official-gazette: kind-of-jp="B9" kind-of-st16="B2"
        // <jp-official-gazette><publication-reference><document-id><kind>特許公報(B2)
        B9: "特許公報(B2)",
        
        // BC
        // attribute of jp-official-gazette: kind-of-jp="BC" kind-of-st16="B6"
        // <jp-official-gazette><jp:header<publication-reference><document-id><kind>特許公報の訂正
        BC: "特許公報の訂正",
        
        
        DG: "意匠",
        DGC: "意匠公報の訂正",
        DD:"協議不成立意匠出願公報",
        
        // S1
        // attribute of jp-official-gazette:kind-of-jp="S" kind-of-st16="A1"
        // <jp-official-gazette><jp:kind-of-official-gazette>再公表特許(A1)
        S: "再公表特許(A1)",
        
        
        // S5
        // <jp-official-gazette><jp:kind-of-official-gazette>特許法第１７条の２の規定による補正の掲載
        //  attribute of jp-official-gazette: kind-of-jp="S5" kind-of-st16="A5"
        S5: "特許法第１７条の２の規定による補正の掲載 (note:再公表)",
        
        // S6
        // <jp-official-gazette><jp:header> <jp:kind-of-official-gazette>特許法第１７条の２の規定による補正の掲載の訂正
        
        S6: "特許法第１７条の２の規定による補正の掲載の訂正 (note:再公表)",
        
        // T
        // <jp-official-gazette><publication-reference><document-id><kind>:公表特許公報(A)
        //  attribute of jp-official-gazette:   kind-of-jp="T" kind-of-st16="A"
        T:  "公表特許公報(A)",
        
        
        // T5
        // <jp-official-gazette><publication-reference> <document-id><kind>特許法第１７条の２の規定による補正の掲載</kind>
        // kind-of-jp="T5" kind-of-st16="A5"
        T5: "特許法第１７条の２の規定による補正の掲載(note:公表)",
        
        
        // T6
        // attribute of jp-official-gazette: kind-of-jp="T6" kind-of-st16="A6"
        // <jp:header><publication-reference><document-id><kind>:公表特許公報の訂正
        T6: "公表特許公報の訂正",
        
        // U7
        // attribute of jp-official-gazette: kind-of-jp="U7" kind-of-st16="U7"
        // <jp-official-gazette><jp:header><publication-reference><document-id><kind>実用新案法第１４条の２の規定による訂正明細書等の掲載
        U7: "実用新案法第１４条の２の規定による訂正明細書等の掲載",
        
        // U9
        // attribute of jp-official-gazette: kind-of-jp="U9" kind-of-st16="U"
        // <jp-official-gazette><publication-reference><document-id><kind>登録実用新案公報(U)
        U9: "登錄実用新案公報(U)",
        
        
        // UB
        // attribute of jp-official-gazette: kind-of-jp="UB" kind-of-st16="U6"
        // <jp-official-gazette><jp:header><publication-reference><document-id><kind>実用新案法第１４条の２の規定による訂正明細書等の掲載の訂正<
        UB: "実用新案法第１４条の２の規定による訂正明細書等の掲載の訂正",
        
        // UC
        // attribute of jp-official-gazette: kind-of-jp="UC" kind-of-st16="U6"
        // <jp-official-gazette><jp:header><publication-reference><document-id><kind>登録実用新案公報の訂正
        UC: "登録実用新案公報の訂正"
    ]
    def static docContentPatternForXML = [
        A : /.*gat-a.dtd.*/,   //公開特許公報
        A5: /.*gat-a5.dtd.*/,
        A6: /.*gat-a6.dtd.*/,
        B6: /.*gat-b6.dtd.*/,
        B9: /.*gat-b9.dtd.*/,
        BC: /.*gat-bc.dtd.*/,
        S: /.*gat-s.dtd.*/,
        S5:/.*gat-s5.dtd.*/,
        S6:/.*gat-s6.dtd.*/,
        T: /.*gat-t.dtd.*/,
        T5:/.*gat-t5.dtd.*/,
        T6:/.*gat-t6.dtd.*/,
        U7:/.*gat-u7.dtd.*/,
        U9:/.*gat-u9.dtd.*/,
        UB:/.*gat-ub.dtd.*/,
        UC:/.*gat-uc.dtd.*/,
        sequenceListXML:/.*sequence-list.*/
        
    ]
    def static docContentPatternForSGM = [
        DD:/<KIND-OF-OFFICIAL-GAZETTE>協議不成立意匠出願公報<\/KIND-OF-OFFICIAL-GAZETTE/,
        DG:/<KIND-OF-OFFICIAL-GAZETTE>意匠公報（Ｓ）<\/KIND-OF-OFFICIAL-GAZETTE/,
        DGC:/<KIND-OF-OFFICIAL-GAZETTE>意匠公報の訂正<\/KIND-OF-OFFICIAL-GAZETTE/,
        sequenceListSGM:/<!SGML \"ISO 8879:1986\".*/
    ]
    
    
def static JPWO_kindcode_regex_map = [
        A : /A/,
        A5: /A5/,
        A6: /A6/,
        //B6: /B6/,
        B9: /B2|B1/,
        BC: /B6/,
        S: /A1/,
        S5: /A5/,
        S6: /A6/,
        T:  /A/,
        T5: /A5/,
        T6: /A6/,
        U7: /U7/,
        U9: /U/,
        UB: /U6/,
        UC: /U6/,
        DG: /S/
        //DGC: ,
        //DD:
        
    ]
def static JPWO_kindcode_map = [
    A : "A",
    A5: "A5",
    A6: "A6",
    //B6: /B6/,
    //B9: /B2|B1/,
    BC: "B6",
    S: "A1",
    S5: "A5",
    S6: "A6",
    T:  "A",
    T5: "A5",
    T6: "A6",
    U7: "U7",
    U9: "U",
    UB: "U6",
    UC: "U6",
    DG: "S"
    //DGC: ,
    //DD:
    
]
}
