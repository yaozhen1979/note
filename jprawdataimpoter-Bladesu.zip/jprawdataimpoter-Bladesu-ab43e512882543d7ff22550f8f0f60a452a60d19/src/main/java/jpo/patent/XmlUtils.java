package jpo.patent;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jpo.patent.utils.XmlImportUtils;
import org.dom4j.DocumentException;
import org.dom4j.Node;

import patentdata.utils.CDataProcess;

public class XmlUtils {
    static Pattern patternSGMHeader = Pattern
            .compile("\\S*?<!DOCTYPE[\\s\\S]*?DES-GAZ PUBLIC[\\s\\S]*?\\]>");
    
    static Pattern patternXMLHeader = Pattern.compile("<!DOCTYPE jp-official-gazette PUBLIC.*gat-.*.dtd\">");
    private static CDataProcess processXML;
    private static CDataProcess processSGM;
    static {
        try {
            processXML = new CDataProcess(true,
                    // title
                    "/jp-official-gazette/bibliographic-data/invention-title",
                    // description
                    "/jp-official-gazette/description",
                    // claims
                    "/jp-official-gazette/claims",
                    // amendment could have description/claims, therefore it should be CDATA
                    "/jp-official-gazette/jp:written-amendment-group/jp:written-amendment/jp:amendment-article/jp:amendment-group/jp:contents-of-amendment",
                    
                    // abstract
                    "/jp-official-gazette/abstract",
                    // other reference
                    "/jp-official-gazette/jp:reference-file-article/jp:reference-file-group/reference-file",
                    
                    // the article of gat-a has special column (a lot of <p> and refereed image tag)
                    "/jp-official-gazette/jp:foreign-language-body",
                    
                    
                    // special column <p> has <br> tag inside
                    "/jp-official-gazette/jp:overflow"
                    );
            
            processSGM = new CDataProcess(true,
                    // titles
                    "/DES-GAZ/NAME-OF-ARTICLE",
                    "/DES-GAZ/TRANSLATION-OF-NAME-OF-ARTICLE",
                    // the column equals to description
                    "/DES-GAZ/REFERENCE-DOCUMENT",
                    "/DES-GAZ/EXPLANATION-OF-THE-DESIGN-ART",
                    "/DES-GAZ/TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN-ART",
                    "/DES-GAZ/EXPLANATION-OF-THE-DESIGN",
                    "/DES-GAZ/TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN",
                    "/DES-GAZ/EXPLANATION-OF-ORIGINAL-DOCUMENT"
                    );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String fixXml(String xml, String parsedFileExtension)
            throws Exception {
        if (parsedFileExtension.equals("sgm/sgm")) {
            // For SGM files, eliminate the header "DOCTYPE" and line feed .
            Matcher m = patternSGMHeader.matcher(xml);
            if (m.find()) {
                
                xml = xml.replace(m.group(0), "");
                xml = xml.replaceAll("\r\n", "\n");
                xml = xml.replaceAll("\n>", ">\n");
                xml = xml.replaceAll("\n", "\r\n");
                xml = xml.replaceAll("<ATTORNEY-RIGHT([^>]*?)>",
                        "<ATTORNEY-RIGHT$1 \\/>");
                xml = xml.replaceAll("<IMAGE([^>]+?)>", "<IMAGE$1 \\/>");
                xml = xml.replaceAll("<PART-DESIGN([^>]*?)>","<PART-DESIGN$1 \\/>");
                xml = xml.replaceAll("<ACCELERATED-EXAM-OBJ-APP([^>]+?)>","<ACCELERATED-EXAM-OBJ-APP$1 \\/>");
                xml = xml.replaceAll("<RELATED-DESIGN-REGISTRATION-NUM([^>]+?)>","<RELATED-DESIGN-REGISTRATION-NUM$1 \\/>");
                xml = xml.replaceAll("><", ">\n<");
                xml = processSGM.transfer(xml);
            }
        } else if (parsedFileExtension.equals("xml/xml")) {
            Matcher m = patternXMLHeader.matcher(xml);
            if (m.find()) {
                xml = xml.replace(m.group(0), "");
            }
            xml = xml.replace("xmlns:jp=\"http://www.jpo.go.jp\"",
                    "xmlns=\"http://patentcloud.com/DMD/jpo\" xmlns:jp=\"http://patentcloud.com/DMD/jpo\"");
            xml = xml.replace("encoding=\"EUC-JP\"", "encoding=\"UTF-8\"");
            xml = processXML.transfer(xml);
        }
        
        return xml;
    }
    
    // 濾除掉部分 description 內容
    public static String cutDescription(org.dom4j.Document document,
            long filesize, long filesizelimit, String... xpaths)
                    throws DocumentException {
        for (String xpath : xpaths) {
            Node node = document.selectSingleNode(xpath);
            if (node != null) {
                String oriDesc = node.asXML();
                float sizeScalae = (float) (filesize / filesizelimit) * 1.2f; // 縮放比例再乘上
                                                                              // 1.2
                                                                              // 倍緩衝
                String newDesc = oriDesc.substring(0,
                        (int) (oriDesc.length() / sizeScalae))
                        + " ...]]></description>";
                node.setText(newDesc);
            }
        }
        return document.asXML();
    }
    
    public static void main(String[] args) throws Exception {
        String sampleXmlDir = "src" + File.separator + "test" + File.separator
                + "resources" + File.separator + "sampleXml" + File.separator
                + "synergytek" + File.separator + "patent" 
                + File.separator + "jpg" + File.separator + "s";
        String content = new String(
                Files.readAllBytes(Paths
                        .get(sampleXmlDir + File.separator + "2013171821.xml")),
                StandardCharsets.UTF_8);
        // content = (String)
        // wips.patent.importer.error.XmlImporterFromErrDb.fixErrorContents(content);
        
        content = fixXml(content,"xml/xml");
        System.out.println(content);
    }
}
