//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:48:41 PM CST 
//


package jpo.patent.a.gat_a.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}text"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}author"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}online-title"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}hosttitle"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}subname"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}edition"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}serial"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}book"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}imprint"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}pubdate"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}history"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}series"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}hostno"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}location"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}notes"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}avail"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}class"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}keyword"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}cpyrt"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}issn"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}isbn"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}datecit"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}srchterm"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}srchdate"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}refno"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "textOrAuthorOrOnlineTitle"
})
@XmlRootElement(name = "online")
public class Online {

    @XmlElementRefs({
        @XmlElementRef(name = "avail", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "book", namespace = "http://patentcloud.com/DMD/jpo", type = Book.class, required = false),
        @XmlElementRef(name = "cpyrt", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "text", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "issn", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "notes", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "imprint", namespace = "http://patentcloud.com/DMD/jpo", type = Imprint.class, required = false),
        @XmlElementRef(name = "online-title", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "series", namespace = "http://patentcloud.com/DMD/jpo", type = Series.class, required = false),
        @XmlElementRef(name = "keyword", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "class", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "history", namespace = "http://patentcloud.com/DMD/jpo", type = History.class, required = false),
        @XmlElementRef(name = "author", namespace = "http://patentcloud.com/DMD/jpo", type = Author.class, required = false),
        @XmlElementRef(name = "serial", namespace = "http://patentcloud.com/DMD/jpo", type = Serial.class, required = false),
        @XmlElementRef(name = "location", namespace = "http://patentcloud.com/DMD/jpo", type = Location.class, required = false),
        @XmlElementRef(name = "datecit", namespace = "http://patentcloud.com/DMD/jpo", type = Datecit.class, required = false),
        @XmlElementRef(name = "srchterm", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "subname", namespace = "http://patentcloud.com/DMD/jpo", type = Subname.class, required = false),
        @XmlElementRef(name = "isbn", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "srchdate", namespace = "http://patentcloud.com/DMD/jpo", type = Srchdate.class, required = false),
        @XmlElementRef(name = "refno", namespace = "http://patentcloud.com/DMD/jpo", type = Refno.class, required = false),
        @XmlElementRef(name = "pubdate", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "hostno", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "edition", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "hosttitle", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false)
    })
    protected List<Object> textOrAuthorOrOnlineTitle;

    /**
     * Gets the value of the textOrAuthorOrOnlineTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the textOrAuthorOrOnlineTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTextOrAuthorOrOnlineTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Book }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Imprint }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Series }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link History }
     * {@link Author }
     * {@link Serial }
     * {@link Location }
     * {@link Datecit }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Subname }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Srchdate }
     * {@link Refno }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getTextOrAuthorOrOnlineTitle() {
        if (textOrAuthorOrOnlineTitle == null) {
            textOrAuthorOrOnlineTitle = new ArrayList<Object>();
        }
        return this.textOrAuthorOrOnlineTitle;
    }

}
