//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:48:41 PM CST 
//


package jpo.patent.a.gat_a.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}addressbook"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}attorney"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}lawyer"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="sequence" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute ref="{http://patentcloud.com/DMD/jpo}kind use="required""/&gt;
 *       &lt;attribute ref="{http://patentcloud.com/DMD/jpo}number-of-other-applicants"/&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "addressbook",
    "attorneyOrLawyer"
})
@XmlRootElement(name = "agent")
public class Agent {

    @XmlElement(required = true)
    protected Addressbook addressbook;
    @XmlElements({
        @XmlElement(name = "attorney", type = Attorney.class),
        @XmlElement(name = "lawyer", type = Lawyer.class)
    })
    protected List<Object> attorneyOrLawyer;
    @XmlAttribute(name = "sequence", required = true)
    protected String sequence;
    @XmlAttribute(name = "kind", namespace = "http://patentcloud.com/DMD/jpo", required = true)
    protected String kind;
    @XmlAttribute(name = "number-of-other-applicants", namespace = "http://patentcloud.com/DMD/jpo")
    protected String numberOfOtherApplicants;

    /**
     * 取得 addressbook 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Addressbook }
     *     
     */
    public Addressbook getAddressbook() {
        return addressbook;
    }

    /**
     * 設定 addressbook 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Addressbook }
     *     
     */
    public void setAddressbook(Addressbook value) {
        this.addressbook = value;
    }

    /**
     * Gets the value of the attorneyOrLawyer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the attorneyOrLawyer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAttorneyOrLawyer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Attorney }
     * {@link Lawyer }
     * 
     * 
     */
    public List<Object> getAttorneyOrLawyer() {
        if (attorneyOrLawyer == null) {
            attorneyOrLawyer = new ArrayList<Object>();
        }
        return this.attorneyOrLawyer;
    }

    /**
     * 取得 sequence 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * 設定 sequence 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

    /**
     * 取得 kind 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * 設定 kind 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * 取得 numberOfOtherApplicants 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumberOfOtherApplicants() {
        return numberOfOtherApplicants;
    }

    /**
     * 設定 numberOfOtherApplicants 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumberOfOtherApplicants(String value) {
        this.numberOfOtherApplicants = value;
    }

}
