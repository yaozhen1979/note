//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:48:41 PM CST 
//


package jpo.patent.a.gat_a.v1.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the jpo.patent.a.gat_a.v1.jaxb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Absno_QNAME = new QName("http://patentcloud.com/DMD/jpo", "absno");
    private final static QName _Date_QNAME = new QName("http://patentcloud.com/DMD/jpo", "date");
    private final static QName _Address1_QNAME = new QName("http://patentcloud.com/DMD/jpo", "address-1");
    private final static QName _Address2_QNAME = new QName("http://patentcloud.com/DMD/jpo", "address-2");
    private final static QName _Address3_QNAME = new QName("http://patentcloud.com/DMD/jpo", "address-3");
    private final static QName _Mailcode_QNAME = new QName("http://patentcloud.com/DMD/jpo", "mailcode");
    private final static QName _Pobox_QNAME = new QName("http://patentcloud.com/DMD/jpo", "pobox");
    private final static QName _Room_QNAME = new QName("http://patentcloud.com/DMD/jpo", "room");
    private final static QName _AddressFloor_QNAME = new QName("http://patentcloud.com/DMD/jpo", "address-floor");
    private final static QName _Building_QNAME = new QName("http://patentcloud.com/DMD/jpo", "building");
    private final static QName _Street_QNAME = new QName("http://patentcloud.com/DMD/jpo", "street");
    private final static QName _City_QNAME = new QName("http://patentcloud.com/DMD/jpo", "city");
    private final static QName _County_QNAME = new QName("http://patentcloud.com/DMD/jpo", "county");
    private final static QName _State_QNAME = new QName("http://patentcloud.com/DMD/jpo", "state");
    private final static QName _Postcode_QNAME = new QName("http://patentcloud.com/DMD/jpo", "postcode");
    private final static QName _Country_QNAME = new QName("http://patentcloud.com/DMD/jpo", "country");
    private final static QName _Text_QNAME = new QName("http://patentcloud.com/DMD/jpo", "text");
    private final static QName _Prefix_QNAME = new QName("http://patentcloud.com/DMD/jpo", "prefix");
    private final static QName _LastName_QNAME = new QName("http://patentcloud.com/DMD/jpo", "last-name");
    private final static QName _FirstName_QNAME = new QName("http://patentcloud.com/DMD/jpo", "first-name");
    private final static QName _MiddleName_QNAME = new QName("http://patentcloud.com/DMD/jpo", "middle-name");
    private final static QName _Suffix_QNAME = new QName("http://patentcloud.com/DMD/jpo", "suffix");
    private final static QName _Iid_QNAME = new QName("http://patentcloud.com/DMD/jpo", "iid");
    private final static QName _Role_QNAME = new QName("http://patentcloud.com/DMD/jpo", "role");
    private final static QName _Orgname_QNAME = new QName("http://patentcloud.com/DMD/jpo", "orgname");
    private final static QName _Department_QNAME = new QName("http://patentcloud.com/DMD/jpo", "department");
    private final static QName _Synonym_QNAME = new QName("http://patentcloud.com/DMD/jpo", "synonym");
    private final static QName _RegisteredNumber_QNAME = new QName("http://patentcloud.com/DMD/jpo", "registered-number");
    private final static QName _Phone_QNAME = new QName("http://patentcloud.com/DMD/jpo", "phone");
    private final static QName _Fax_QNAME = new QName("http://patentcloud.com/DMD/jpo", "fax");
    private final static QName _Email_QNAME = new QName("http://patentcloud.com/DMD/jpo", "email");
    private final static QName _Url_QNAME = new QName("http://patentcloud.com/DMD/jpo", "url");
    private final static QName _Ead_QNAME = new QName("http://patentcloud.com/DMD/jpo", "ead");
    private final static QName _Dtext_QNAME = new QName("http://patentcloud.com/DMD/jpo", "dtext");
    private final static QName _OfficeInJapan_QNAME = new QName("http://patentcloud.com/DMD/jpo", "office-in-japan");
    private final static QName _Atl_QNAME = new QName("http://patentcloud.com/DMD/jpo", "atl");
    private final static QName _Pubdate_QNAME = new QName("http://patentcloud.com/DMD/jpo", "pubdate");
    private final static QName _Descrip_QNAME = new QName("http://patentcloud.com/DMD/jpo", "descrip");
    private final static QName _Notes_QNAME = new QName("http://patentcloud.com/DMD/jpo", "notes");
    private final static QName _Issn_QNAME = new QName("http://patentcloud.com/DMD/jpo", "issn");
    private final static QName _Isbn_QNAME = new QName("http://patentcloud.com/DMD/jpo", "isbn");
    private final static QName _Pubid_QNAME = new QName("http://patentcloud.com/DMD/jpo", "pubid");
    private final static QName _Vid_QNAME = new QName("http://patentcloud.com/DMD/jpo", "vid");
    private final static QName _Cpyrt_QNAME = new QName("http://patentcloud.com/DMD/jpo", "cpyrt");
    private final static QName _BookTitle_QNAME = new QName("http://patentcloud.com/DMD/jpo", "book-title");
    private final static QName _Conftitle_QNAME = new QName("http://patentcloud.com/DMD/jpo", "conftitle");
    private final static QName _Confno_QNAME = new QName("http://patentcloud.com/DMD/jpo", "confno");
    private final static QName _Confplace_QNAME = new QName("http://patentcloud.com/DMD/jpo", "confplace");
    private final static QName _Confsponsor_QNAME = new QName("http://patentcloud.com/DMD/jpo", "confsponsor");
    private final static QName _Subtitle_QNAME = new QName("http://patentcloud.com/DMD/jpo", "subtitle");
    private final static QName _Edition_QNAME = new QName("http://patentcloud.com/DMD/jpo", "edition");
    private final static QName _Mst_QNAME = new QName("http://patentcloud.com/DMD/jpo", "mst");
    private final static QName _Msn_QNAME = new QName("http://patentcloud.com/DMD/jpo", "msn");
    private final static QName _Serpart_QNAME = new QName("http://patentcloud.com/DMD/jpo", "serpart");
    private final static QName _Sersect_QNAME = new QName("http://patentcloud.com/DMD/jpo", "sersect");
    private final static QName _Chapter_QNAME = new QName("http://patentcloud.com/DMD/jpo", "chapter");
    private final static QName _Pp_QNAME = new QName("http://patentcloud.com/DMD/jpo", "pp");
    private final static QName _Column_QNAME = new QName("http://patentcloud.com/DMD/jpo", "column");
    private final static QName _Para_QNAME = new QName("http://patentcloud.com/DMD/jpo", "para");
    private final static QName _Line_QNAME = new QName("http://patentcloud.com/DMD/jpo", "line");
    private final static QName _Bookno_QNAME = new QName("http://patentcloud.com/DMD/jpo", "bookno");
    private final static QName _Class_QNAME = new QName("http://patentcloud.com/DMD/jpo", "class");
    private final static QName _Keyword_QNAME = new QName("http://patentcloud.com/DMD/jpo", "keyword");
    private final static QName _Artid_QNAME = new QName("http://patentcloud.com/DMD/jpo", "artid");
    private final static QName _Avail_QNAME = new QName("http://patentcloud.com/DMD/jpo", "avail");
    private final static QName _B_QNAME = new QName("http://patentcloud.com/DMD/jpo", "b");
    private final static QName _FilingForm_QNAME = new QName("http://patentcloud.com/DMD/jpo", "filing-form");
    private final static QName _TotalPages_QNAME = new QName("http://patentcloud.com/DMD/jpo", "total-pages");
    private final static QName _ContentOfPublicOrderAndMorality_QNAME = new QName("http://patentcloud.com/DMD/jpo", "content-of-public-order-and-morality");
    private final static QName _Trademark_QNAME = new QName("http://patentcloud.com/DMD/jpo", "trademark");
    private final static QName _ArticleOfIndustrialRevitalizingLaw_QNAME = new QName("http://patentcloud.com/DMD/jpo", "article-of-industrial-revitalizing-law");
    private final static QName _ExternalFile_QNAME = new QName("http://patentcloud.com/DMD/jpo", "external-file");
    private final static QName _ThemeCode_QNAME = new QName("http://patentcloud.com/DMD/jpo", "theme-code");
    private final static QName _FTerm_QNAME = new QName("http://patentcloud.com/DMD/jpo", "f-term");
    private final static QName _Category_QNAME = new QName("http://patentcloud.com/DMD/jpo", "category");
    private final static QName _ClaimText_QNAME = new QName("http://patentcloud.com/DMD/jpo", "claim-text");
    private final static QName _Colf_QNAME = new QName("http://patentcloud.com/DMD/jpo", "colf");
    private final static QName _Coll_QNAME = new QName("http://patentcloud.com/DMD/jpo", "coll");
    private final static QName _Dd_QNAME = new QName("http://patentcloud.com/DMD/jpo", "dd");
    private final static QName _Edate_QNAME = new QName("http://patentcloud.com/DMD/jpo", "edate");
    private final static QName _Misc_QNAME = new QName("http://patentcloud.com/DMD/jpo", "misc");
    private final static QName _Hostno_QNAME = new QName("http://patentcloud.com/DMD/jpo", "hostno");
    private final static QName _Hosttitle_QNAME = new QName("http://patentcloud.com/DMD/jpo", "hosttitle");
    private final static QName _I_QNAME = new QName("http://patentcloud.com/DMD/jpo", "i");
    private final static QName _DocumentCode_QNAME = new QName("http://patentcloud.com/DMD/jpo", "document-code");
    private final static QName _ItemOfAmendment_QNAME = new QName("http://patentcloud.com/DMD/jpo", "item-of-amendment");
    private final static QName _WayOfAmendment_QNAME = new QName("http://patentcloud.com/DMD/jpo", "way-of-amendment");
    private final static QName _Linef_QNAME = new QName("http://patentcloud.com/DMD/jpo", "linef");
    private final static QName _Linel_QNAME = new QName("http://patentcloud.com/DMD/jpo", "linel");
    private final static QName _OnlineTitle_QNAME = new QName("http://patentcloud.com/DMD/jpo", "online-title");
    private final static QName _Srchterm_QNAME = new QName("http://patentcloud.com/DMD/jpo", "srchterm");
    private final static QName _Othercit_QNAME = new QName("http://patentcloud.com/DMD/jpo", "othercit");
    private final static QName _Paraf_QNAME = new QName("http://patentcloud.com/DMD/jpo", "paraf");
    private final static QName _Paral_QNAME = new QName("http://patentcloud.com/DMD/jpo", "paral");
    private final static QName _Passage_QNAME = new QName("http://patentcloud.com/DMD/jpo", "passage");
    private final static QName _RelClaims_QNAME = new QName("http://patentcloud.com/DMD/jpo", "rel-claims");
    private final static QName _Ppf_QNAME = new QName("http://patentcloud.com/DMD/jpo", "ppf");
    private final static QName _Ppl_QNAME = new QName("http://patentcloud.com/DMD/jpo", "ppl");
    private final static QName _Sdate_QNAME = new QName("http://patentcloud.com/DMD/jpo", "sdate");
    private final static QName _Smallcaps_QNAME = new QName("http://patentcloud.com/DMD/jpo", "smallcaps");
    private final static QName _Sub_QNAME = new QName("http://patentcloud.com/DMD/jpo", "sub");
    private final static QName _Sup_QNAME = new QName("http://patentcloud.com/DMD/jpo", "sup");
    private final static QName _Time_QNAME = new QName("http://patentcloud.com/DMD/jpo", "time");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: jpo.patent.a.gat_a.v1.jaxb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ApplicantsAgents }
     * 
     */
    public ApplicantsAgents createApplicantsAgents() {
        return new ApplicantsAgents();
    }

    /**
     * Create an instance of {@link Tgroup }
     * 
     */
    public Tgroup createTgroup() {
        return new Tgroup();
    }

    /**
     * Create an instance of {@link AbstProblem }
     * 
     */
    public AbstProblem createAbstProblem() {
        return new AbstProblem();
    }

    /**
     * Create an instance of {@link P }
     * 
     */
    public P createP() {
        return new P();
    }

    /**
     * Create an instance of {@link Abstract }
     * 
     */
    public Abstract createAbstract() {
        return new Abstract();
    }

    /**
     * Create an instance of {@link Accepted }
     * 
     */
    public Accepted createAccepted() {
        return new Accepted();
    }

    /**
     * Create an instance of {@link AdditionalInfo }
     * 
     */
    public AdditionalInfo createAdditionalInfo() {
        return new AdditionalInfo();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link Addressbook }
     * 
     */
    public Addressbook createAddressbook() {
        return new Addressbook();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link AdvantageousEffects }
     * 
     */
    public AdvantageousEffects createAdvantageousEffects() {
        return new AdvantageousEffects();
    }

    /**
     * Create an instance of {@link Heading }
     * 
     */
    public Heading createHeading() {
        return new Heading();
    }

    /**
     * Create an instance of {@link jpo.patent.a.gat_a.v1.jaxb.Agent }
     * 
     */
    public jpo.patent.a.gat_a.v1.jaxb.Agent createAgent() {
        return new jpo.patent.a.gat_a.v1.jaxb.Agent();
    }

    /**
     * Create an instance of {@link Attorney }
     * 
     */
    public Attorney createAttorney() {
        return new Attorney();
    }

    /**
     * Create an instance of {@link Lawyer }
     * 
     */
    public Lawyer createLawyer() {
        return new Lawyer();
    }

    /**
     * Create an instance of {@link InApplicationBody_0020 }
     * 
     */
    public InApplicationBody_0020 createInApplicationBody_0020() {
        return new InApplicationBody_0020();
    }

    /**
     * Create an instance of {@link ApplicationBody }
     * 
     */
    public ApplicationBody createApplicationBody() {
        return new ApplicationBody();
    }

    /**
     * Create an instance of {@link DocPage }
     * 
     */
    public DocPage createDocPage() {
        return new DocPage();
    }

    /**
     * Create an instance of {@link Description }
     * 
     */
    public Description createDescription() {
        return new Description();
    }

    /**
     * Create an instance of {@link Claims }
     * 
     */
    public Claims createClaims() {
        return new Claims();
    }

    /**
     * Create an instance of {@link Drawings }
     * 
     */
    public Drawings createDrawings() {
        return new Drawings();
    }

    /**
     * Create an instance of {@link Figure }
     * 
     */
    public Figure createFigure() {
        return new Figure();
    }

    /**
     * Create an instance of {@link Img }
     * 
     */
    public Img createImg() {
        return new Img();
    }

    /**
     * Create an instance of {@link ApplicationReference }
     * 
     */
    public ApplicationReference createApplicationReference() {
        return new ApplicationReference();
    }

    /**
     * Create an instance of {@link DocumentId }
     * 
     */
    public DocumentId createDocumentId() {
        return new DocumentId();
    }

    /**
     * Create an instance of {@link Article }
     * 
     */
    public Article createArticle() {
        return new Article();
    }

    /**
     * Create an instance of {@link Author }
     * 
     */
    public Author createAuthor() {
        return new Author();
    }

    /**
     * Create an instance of {@link Subname }
     * 
     */
    public Subname createSubname() {
        return new Subname();
    }

    /**
     * Create an instance of {@link Serial }
     * 
     */
    public Serial createSerial() {
        return new Serial();
    }

    /**
     * Create an instance of {@link Imprint }
     * 
     */
    public Imprint createImprint() {
        return new Imprint();
    }

    /**
     * Create an instance of {@link Book }
     * 
     */
    public Book createBook() {
        return new Book();
    }

    /**
     * Create an instance of {@link Conference }
     * 
     */
    public Conference createConference() {
        return new Conference();
    }

    /**
     * Create an instance of {@link Series }
     * 
     */
    public Series createSeries() {
        return new Series();
    }

    /**
     * Create an instance of {@link Location }
     * 
     */
    public Location createLocation() {
        return new Location();
    }

    /**
     * Create an instance of {@link Refno }
     * 
     */
    public Refno createRefno() {
        return new Refno();
    }

    /**
     * Create an instance of {@link BackgroundArt }
     * 
     */
    public BackgroundArt createBackgroundArt() {
        return new BackgroundArt();
    }

    /**
     * Create an instance of {@link BestMode }
     * 
     */
    public BestMode createBestMode() {
        return new BestMode();
    }

    /**
     * Create an instance of {@link BibliographicData }
     * 
     */
    public BibliographicData createBibliographicData() {
        return new BibliographicData();
    }

    /**
     * Create an instance of {@link PublicationReference }
     * 
     */
    public PublicationReference createPublicationReference() {
        return new PublicationReference();
    }

    /**
     * Create an instance of {@link InventionTitle }
     * 
     */
    public InventionTitle createInventionTitle() {
        return new InventionTitle();
    }

    /**
     * Create an instance of {@link Parties }
     * 
     */
    public Parties createParties() {
        return new Parties();
    }

    /**
     * Create an instance of {@link ApplicantsAgentsArticle }
     * 
     */
    public ApplicantsAgentsArticle createApplicantsAgentsArticle() {
        return new ApplicantsAgentsArticle();
    }

    /**
     * Create an instance of {@link Applicant }
     * 
     */
    public Applicant createApplicant() {
        return new Applicant();
    }

    /**
     * Create an instance of {@link ApplicantsAgents.Agent }
     * 
     */
    public ApplicantsAgents.Agent createApplicantsAgentsAgent() {
        return new ApplicantsAgents.Agent();
    }

    /**
     * Create an instance of {@link Inventors }
     * 
     */
    public Inventors createInventors() {
        return new Inventors();
    }

    /**
     * Create an instance of {@link Inventor }
     * 
     */
    public Inventor createInventor() {
        return new Inventor();
    }

    /**
     * Create an instance of {@link PriorityClaims }
     * 
     */
    public PriorityClaims createPriorityClaims() {
        return new PriorityClaims();
    }

    /**
     * Create an instance of {@link PriorityClaim }
     * 
     */
    public PriorityClaim createPriorityClaim() {
        return new PriorityClaim();
    }

    /**
     * Create an instance of {@link DatesOfPublicAvailability }
     * 
     */
    public DatesOfPublicAvailability createDatesOfPublicAvailability() {
        return new DatesOfPublicAvailability();
    }

    /**
     * Create an instance of {@link PrintedWithGrant }
     * 
     */
    public PrintedWithGrant createPrintedWithGrant() {
        return new PrintedWithGrant();
    }

    /**
     * Create an instance of {@link ClassificationIpc }
     * 
     */
    public ClassificationIpc createClassificationIpc() {
        return new ClassificationIpc();
    }

    /**
     * Create an instance of {@link MainClsf }
     * 
     */
    public MainClsf createMainClsf() {
        return new MainClsf();
    }

    /**
     * Create an instance of {@link FurtherClsf }
     * 
     */
    public FurtherClsf createFurtherClsf() {
        return new FurtherClsf();
    }

    /**
     * Create an instance of {@link LinkedIndexingCodeGroup }
     * 
     */
    public LinkedIndexingCodeGroup createLinkedIndexingCodeGroup() {
        return new LinkedIndexingCodeGroup();
    }

    /**
     * Create an instance of {@link MainLinkedIndexingCode }
     * 
     */
    public MainLinkedIndexingCode createMainLinkedIndexingCode() {
        return new MainLinkedIndexingCode();
    }

    /**
     * Create an instance of {@link SubLinkedIndexingCode }
     * 
     */
    public SubLinkedIndexingCode createSubLinkedIndexingCode() {
        return new SubLinkedIndexingCode();
    }

    /**
     * Create an instance of {@link UnlinkedIndexingCode }
     * 
     */
    public UnlinkedIndexingCode createUnlinkedIndexingCode() {
        return new UnlinkedIndexingCode();
    }

    /**
     * Create an instance of {@link ClassificationNational }
     * 
     */
    public ClassificationNational createClassificationNational() {
        return new ClassificationNational();
    }

    /**
     * Create an instance of {@link NumberOfClaims }
     * 
     */
    public NumberOfClaims createNumberOfClaims() {
        return new NumberOfClaims();
    }

    /**
     * Create an instance of {@link FigureToPublish }
     * 
     */
    public FigureToPublish createFigureToPublish() {
        return new FigureToPublish();
    }

    /**
     * Create an instance of {@link RelatedDocuments }
     * 
     */
    public RelatedDocuments createRelatedDocuments() {
        return new RelatedDocuments();
    }

    /**
     * Create an instance of {@link Division }
     * 
     */
    public Division createDivision() {
        return new Division();
    }

    /**
     * Create an instance of {@link Relation }
     * 
     */
    public Relation createRelation() {
        return new Relation();
    }

    /**
     * Create an instance of {@link ParentDoc }
     * 
     */
    public ParentDoc createParentDoc() {
        return new ParentDoc();
    }

    /**
     * Create an instance of {@link ChangeOfApplication }
     * 
     */
    public ChangeOfApplication createChangeOfApplication() {
        return new ChangeOfApplication();
    }

    /**
     * Create an instance of {@link ChangeOfUtility }
     * 
     */
    public ChangeOfUtility createChangeOfUtility() {
        return new ChangeOfUtility();
    }

    /**
     * Create an instance of {@link RequestForExamination }
     * 
     */
    public RequestForExamination createRequestForExamination() {
        return new RequestForExamination();
    }

    /**
     * Create an instance of {@link ApplicationInForeignLanguage }
     * 
     */
    public ApplicationInForeignLanguage createApplicationInForeignLanguage() {
        return new ApplicationInForeignLanguage();
    }

    /**
     * Create an instance of {@link RequestOpenApplication }
     * 
     */
    public RequestOpenApplication createRequestOpenApplication() {
        return new RequestOpenApplication();
    }

    /**
     * Create an instance of {@link ArticleOfLackOfNovelty }
     * 
     */
    public ArticleOfLackOfNovelty createArticleOfLackOfNovelty() {
        return new ArticleOfLackOfNovelty();
    }

    /**
     * Create an instance of {@link LackOfNovelty }
     * 
     */
    public LackOfNovelty createLackOfNovelty() {
        return new LackOfNovelty();
    }

    /**
     * Create an instance of {@link ArticleOfPublicOrderAndMorality }
     * 
     */
    public ArticleOfPublicOrderAndMorality createArticleOfPublicOrderAndMorality() {
        return new ArticleOfPublicOrderAndMorality();
    }

    /**
     * Create an instance of {@link UnapprovedUseOfTrademark }
     * 
     */
    public UnapprovedUseOfTrademark createUnapprovedUseOfTrademark() {
        return new UnapprovedUseOfTrademark();
    }

    /**
     * Create an instance of {@link ExternalFileInfo }
     * 
     */
    public ExternalFileInfo createExternalFileInfo() {
        return new ExternalFileInfo();
    }

    /**
     * Create an instance of {@link ThemeCodeInfo }
     * 
     */
    public ThemeCodeInfo createThemeCodeInfo() {
        return new ThemeCodeInfo();
    }

    /**
     * Create an instance of {@link FTermInfo }
     * 
     */
    public FTermInfo createFTermInfo() {
        return new FTermInfo();
    }

    /**
     * Create an instance of {@link BioDeposit }
     * 
     */
    public BioDeposit createBioDeposit() {
        return new BioDeposit();
    }

    /**
     * Create an instance of {@link Br }
     * 
     */
    public Br createBr() {
        return new Br();
    }

    /**
     * Create an instance of {@link Chemistry }
     * 
     */
    public Chemistry createChemistry() {
        return new Chemistry();
    }

    /**
     * Create an instance of {@link CitationList }
     * 
     */
    public CitationList createCitationList() {
        return new CitationList();
    }

    /**
     * Create an instance of {@link PatentLiterature }
     * 
     */
    public PatentLiterature createPatentLiterature() {
        return new PatentLiterature();
    }

    /**
     * Create an instance of {@link NonPatentLiterature }
     * 
     */
    public NonPatentLiterature createNonPatentLiterature() {
        return new NonPatentLiterature();
    }

    /**
     * Create an instance of {@link Claim }
     * 
     */
    public Claim createClaim() {
        return new Claim();
    }

    /**
     * Create an instance of {@link ClaimRef }
     * 
     */
    public ClaimRef createClaimRef() {
        return new ClaimRef();
    }

    /**
     * Create an instance of {@link jpo.patent.a.gat_a.v1.jaxb.Colspec }
     * 
     */
    public jpo.patent.a.gat_a.v1.jaxb.Colspec createColspec() {
        return new jpo.patent.a.gat_a.v1.jaxb.Colspec();
    }

    /**
     * Create an instance of {@link Crossref }
     * 
     */
    public Crossref createCrossref() {
        return new Crossref();
    }

    /**
     * Create an instance of {@link Datecit }
     * 
     */
    public Datecit createDatecit() {
        return new Datecit();
    }

    /**
     * Create an instance of {@link DescriptionOfDrawings }
     * 
     */
    public DescriptionOfDrawings createDescriptionOfDrawings() {
        return new DescriptionOfDrawings();
    }

    /**
     * Create an instance of {@link DescriptionOfEmbodiments }
     * 
     */
    public DescriptionOfEmbodiments createDescriptionOfEmbodiments() {
        return new DescriptionOfEmbodiments();
    }

    /**
     * Create an instance of {@link EmbodimentsExample }
     * 
     */
    public EmbodimentsExample createEmbodimentsExample() {
        return new EmbodimentsExample();
    }

    /**
     * Create an instance of {@link Disclosure }
     * 
     */
    public Disclosure createDisclosure() {
        return new Disclosure();
    }

    /**
     * Create an instance of {@link TechProblem }
     * 
     */
    public TechProblem createTechProblem() {
        return new TechProblem();
    }

    /**
     * Create an instance of {@link TechSolution }
     * 
     */
    public TechSolution createTechSolution() {
        return new TechSolution();
    }

    /**
     * Create an instance of {@link Dl }
     * 
     */
    public Dl createDl() {
        return new Dl();
    }

    /**
     * Create an instance of {@link Dt }
     * 
     */
    public Dt createDt() {
        return new Dt();
    }

    /**
     * Create an instance of {@link Entry }
     * 
     */
    public Entry createEntry() {
        return new Entry();
    }

    /**
     * Create an instance of {@link Figref }
     * 
     */
    public Figref createFigref() {
        return new Figref();
    }

    /**
     * Create an instance of {@link History }
     * 
     */
    public History createHistory() {
        return new History();
    }

    /**
     * Create an instance of {@link Received }
     * 
     */
    public Received createReceived() {
        return new Received();
    }

    /**
     * Create an instance of {@link Revised }
     * 
     */
    public Revised createRevised() {
        return new Revised();
    }

    /**
     * Create an instance of {@link IndustrialApplicability }
     * 
     */
    public IndustrialApplicability createIndustrialApplicability() {
        return new IndustrialApplicability();
    }

    /**
     * Create an instance of {@link JpOfficialGazette }
     * 
     */
    public JpOfficialGazette createJpOfficialGazette() {
        return new JpOfficialGazette();
    }

    /**
     * Create an instance of {@link ImageOfBibliographicData }
     * 
     */
    public ImageOfBibliographicData createImageOfBibliographicData() {
        return new ImageOfBibliographicData();
    }

    /**
     * Create an instance of {@link ImageOfChosenDrawing }
     * 
     */
    public ImageOfChosenDrawing createImageOfChosenDrawing() {
        return new ImageOfChosenDrawing();
    }

    /**
     * Create an instance of {@link AbstractCorrection }
     * 
     */
    public AbstractCorrection createAbstractCorrection() {
        return new AbstractCorrection();
    }

    /**
     * Create an instance of {@link ReferenceFileArticle }
     * 
     */
    public ReferenceFileArticle createReferenceFileArticle() {
        return new ReferenceFileArticle();
    }

    /**
     * Create an instance of {@link ReferenceFileGroup }
     * 
     */
    public ReferenceFileGroup createReferenceFileGroup() {
        return new ReferenceFileGroup();
    }

    /**
     * Create an instance of {@link ReferenceFile }
     * 
     */
    public ReferenceFile createReferenceFile() {
        return new ReferenceFile();
    }

    /**
     * Create an instance of {@link WrittenAmendmentGroup }
     * 
     */
    public WrittenAmendmentGroup createWrittenAmendmentGroup() {
        return new WrittenAmendmentGroup();
    }

    /**
     * Create an instance of {@link WrittenAmendment }
     * 
     */
    public WrittenAmendment createWrittenAmendment() {
        return new WrittenAmendment();
    }

    /**
     * Create an instance of {@link AmendmentArticle }
     * 
     */
    public AmendmentArticle createAmendmentArticle() {
        return new AmendmentArticle();
    }

    /**
     * Create an instance of {@link AmendmentGroup }
     * 
     */
    public AmendmentGroup createAmendmentGroup() {
        return new AmendmentGroup();
    }

    /**
     * Create an instance of {@link ContentsOfAmendment }
     * 
     */
    public ContentsOfAmendment createContentsOfAmendment() {
        return new ContentsOfAmendment();
    }

    /**
     * Create an instance of {@link Overflow }
     * 
     */
    public Overflow createOverflow() {
        return new Overflow();
    }

    /**
     * Create an instance of {@link ForeignLanguageBody }
     * 
     */
    public ForeignLanguageBody createForeignLanguageBody() {
        return new ForeignLanguageBody();
    }

    /**
     * Create an instance of {@link ForeignLanguageAbstract }
     * 
     */
    public ForeignLanguageAbstract createForeignLanguageAbstract() {
        return new ForeignLanguageAbstract();
    }

    /**
     * Create an instance of {@link ForeignLanguageClaims }
     * 
     */
    public ForeignLanguageClaims createForeignLanguageClaims() {
        return new ForeignLanguageClaims();
    }

    /**
     * Create an instance of {@link ForeignLanguageDescription }
     * 
     */
    public ForeignLanguageDescription createForeignLanguageDescription() {
        return new ForeignLanguageDescription();
    }

    /**
     * Create an instance of {@link ForeignLanguageDrawings }
     * 
     */
    public ForeignLanguageDrawings createForeignLanguageDrawings() {
        return new ForeignLanguageDrawings();
    }

    /**
     * Create an instance of {@link Li }
     * 
     */
    public Li createLi() {
        return new Li();
    }

    /**
     * Create an instance of {@link Math }
     * 
     */
    public Math createMath() {
        return new Math();
    }

    /**
     * Create an instance of {@link Maths }
     * 
     */
    public Maths createMaths() {
        return new Maths();
    }

    /**
     * Create an instance of {@link ModeForInvention }
     * 
     */
    public ModeForInvention createModeForInvention() {
        return new ModeForInvention();
    }

    /**
     * Create an instance of {@link Nplcit }
     * 
     */
    public Nplcit createNplcit() {
        return new Nplcit();
    }

    /**
     * Create an instance of {@link Online }
     * 
     */
    public Online createOnline() {
        return new Online();
    }

    /**
     * Create an instance of {@link Srchdate }
     * 
     */
    public Srchdate createSrchdate() {
        return new Srchdate();
    }

    /**
     * Create an instance of {@link Ol }
     * 
     */
    public Ol createOl() {
        return new Ol();
    }

    /**
     * Create an instance of {@link Patcit }
     * 
     */
    public Patcit createPatcit() {
        return new Patcit();
    }

    /**
     * Create an instance of {@link RelPassage }
     * 
     */
    public RelPassage createRelPassage() {
        return new RelPassage();
    }

    /**
     * Create an instance of {@link ReferenceSignsList }
     * 
     */
    public ReferenceSignsList createReferenceSignsList() {
        return new ReferenceSignsList();
    }

    /**
     * Create an instance of {@link ReferenceToDepositedBiologicalMaterial }
     * 
     */
    public ReferenceToDepositedBiologicalMaterial createReferenceToDepositedBiologicalMaterial() {
        return new ReferenceToDepositedBiologicalMaterial();
    }

    /**
     * Create an instance of {@link Row }
     * 
     */
    public Row createRow() {
        return new Row();
    }

    /**
     * Create an instance of {@link SequenceListText }
     * 
     */
    public SequenceListText createSequenceListText() {
        return new SequenceListText();
    }

    /**
     * Create an instance of {@link SummaryOfInvention }
     * 
     */
    public SummaryOfInvention createSummaryOfInvention() {
        return new SummaryOfInvention();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link Tgroup.Colspec }
     * 
     */
    public Tgroup.Colspec createTgroupColspec() {
        return new Tgroup.Colspec();
    }

    /**
     * Create an instance of {@link Thead }
     * 
     */
    public Thead createThead() {
        return new Thead();
    }

    /**
     * Create an instance of {@link Tbody }
     * 
     */
    public Tbody createTbody() {
        return new Tbody();
    }

    /**
     * Create an instance of {@link Tables }
     * 
     */
    public Tables createTables() {
        return new Tables();
    }

    /**
     * Create an instance of {@link TechnicalField }
     * 
     */
    public TechnicalField createTechnicalField() {
        return new TechnicalField();
    }

    /**
     * Create an instance of {@link U }
     * 
     */
    public U createU() {
        return new U();
    }

    /**
     * Create an instance of {@link Ul }
     * 
     */
    public Ul createUl() {
        return new Ul();
    }

    /**
     * Create an instance of {@link AbstSolution }
     * 
     */
    public AbstSolution createAbstSolution() {
        return new AbstSolution();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "absno")
    public JAXBElement<String> createAbsno(String value) {
        return new JAXBElement<String>(_Absno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "date")
    public JAXBElement<String> createDate(String value) {
        return new JAXBElement<String>(_Date_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "address-1")
    public JAXBElement<String> createAddress1(String value) {
        return new JAXBElement<String>(_Address1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "address-2")
    public JAXBElement<String> createAddress2(String value) {
        return new JAXBElement<String>(_Address2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "address-3")
    public JAXBElement<String> createAddress3(String value) {
        return new JAXBElement<String>(_Address3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "mailcode")
    public JAXBElement<String> createMailcode(String value) {
        return new JAXBElement<String>(_Mailcode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "pobox")
    public JAXBElement<String> createPobox(String value) {
        return new JAXBElement<String>(_Pobox_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "room")
    public JAXBElement<String> createRoom(String value) {
        return new JAXBElement<String>(_Room_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "address-floor")
    public JAXBElement<String> createAddressFloor(String value) {
        return new JAXBElement<String>(_AddressFloor_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "building")
    public JAXBElement<String> createBuilding(String value) {
        return new JAXBElement<String>(_Building_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "street")
    public JAXBElement<String> createStreet(String value) {
        return new JAXBElement<String>(_Street_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "city")
    public JAXBElement<String> createCity(String value) {
        return new JAXBElement<String>(_City_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "county")
    public JAXBElement<String> createCounty(String value) {
        return new JAXBElement<String>(_County_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "state")
    public JAXBElement<String> createState(String value) {
        return new JAXBElement<String>(_State_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "postcode")
    public JAXBElement<String> createPostcode(String value) {
        return new JAXBElement<String>(_Postcode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "country")
    public JAXBElement<String> createCountry(String value) {
        return new JAXBElement<String>(_Country_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "text")
    public JAXBElement<String> createText(String value) {
        return new JAXBElement<String>(_Text_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "prefix")
    public JAXBElement<String> createPrefix(String value) {
        return new JAXBElement<String>(_Prefix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "last-name")
    public JAXBElement<String> createLastName(String value) {
        return new JAXBElement<String>(_LastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "first-name")
    public JAXBElement<String> createFirstName(String value) {
        return new JAXBElement<String>(_FirstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "middle-name")
    public JAXBElement<String> createMiddleName(String value) {
        return new JAXBElement<String>(_MiddleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "suffix")
    public JAXBElement<String> createSuffix(String value) {
        return new JAXBElement<String>(_Suffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "iid")
    public JAXBElement<String> createIid(String value) {
        return new JAXBElement<String>(_Iid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "role")
    public JAXBElement<String> createRole(String value) {
        return new JAXBElement<String>(_Role_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "orgname")
    public JAXBElement<String> createOrgname(String value) {
        return new JAXBElement<String>(_Orgname_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "department")
    public JAXBElement<String> createDepartment(String value) {
        return new JAXBElement<String>(_Department_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "synonym")
    public JAXBElement<String> createSynonym(String value) {
        return new JAXBElement<String>(_Synonym_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "registered-number")
    public JAXBElement<String> createRegisteredNumber(String value) {
        return new JAXBElement<String>(_RegisteredNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "phone")
    public JAXBElement<String> createPhone(String value) {
        return new JAXBElement<String>(_Phone_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "fax")
    public JAXBElement<String> createFax(String value) {
        return new JAXBElement<String>(_Fax_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "email")
    public JAXBElement<String> createEmail(String value) {
        return new JAXBElement<String>(_Email_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "url")
    public JAXBElement<String> createUrl(String value) {
        return new JAXBElement<String>(_Url_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "ead")
    public JAXBElement<String> createEad(String value) {
        return new JAXBElement<String>(_Ead_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "dtext")
    public JAXBElement<String> createDtext(String value) {
        return new JAXBElement<String>(_Dtext_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "office-in-japan")
    public JAXBElement<String> createOfficeInJapan(String value) {
        return new JAXBElement<String>(_OfficeInJapan_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "atl")
    public JAXBElement<String> createAtl(String value) {
        return new JAXBElement<String>(_Atl_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "pubdate")
    public JAXBElement<String> createPubdate(String value) {
        return new JAXBElement<String>(_Pubdate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "descrip")
    public JAXBElement<String> createDescrip(String value) {
        return new JAXBElement<String>(_Descrip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "notes")
    public JAXBElement<String> createNotes(String value) {
        return new JAXBElement<String>(_Notes_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "issn")
    public JAXBElement<String> createIssn(String value) {
        return new JAXBElement<String>(_Issn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "isbn")
    public JAXBElement<String> createIsbn(String value) {
        return new JAXBElement<String>(_Isbn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "pubid")
    public JAXBElement<String> createPubid(String value) {
        return new JAXBElement<String>(_Pubid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "vid")
    public JAXBElement<String> createVid(String value) {
        return new JAXBElement<String>(_Vid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "cpyrt")
    public JAXBElement<String> createCpyrt(String value) {
        return new JAXBElement<String>(_Cpyrt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "book-title")
    public JAXBElement<String> createBookTitle(String value) {
        return new JAXBElement<String>(_BookTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "conftitle")
    public JAXBElement<String> createConftitle(String value) {
        return new JAXBElement<String>(_Conftitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "confno")
    public JAXBElement<String> createConfno(String value) {
        return new JAXBElement<String>(_Confno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "confplace")
    public JAXBElement<String> createConfplace(String value) {
        return new JAXBElement<String>(_Confplace_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "confsponsor")
    public JAXBElement<String> createConfsponsor(String value) {
        return new JAXBElement<String>(_Confsponsor_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "subtitle")
    public JAXBElement<String> createSubtitle(String value) {
        return new JAXBElement<String>(_Subtitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "edition")
    public JAXBElement<String> createEdition(String value) {
        return new JAXBElement<String>(_Edition_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "mst")
    public JAXBElement<String> createMst(String value) {
        return new JAXBElement<String>(_Mst_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "msn")
    public JAXBElement<String> createMsn(String value) {
        return new JAXBElement<String>(_Msn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "serpart")
    public JAXBElement<String> createSerpart(String value) {
        return new JAXBElement<String>(_Serpart_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "sersect")
    public JAXBElement<String> createSersect(String value) {
        return new JAXBElement<String>(_Sersect_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "chapter")
    public JAXBElement<String> createChapter(String value) {
        return new JAXBElement<String>(_Chapter_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "pp")
    public JAXBElement<String> createPp(String value) {
        return new JAXBElement<String>(_Pp_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "column")
    public JAXBElement<String> createColumn(String value) {
        return new JAXBElement<String>(_Column_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "para")
    public JAXBElement<String> createPara(String value) {
        return new JAXBElement<String>(_Para_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "line")
    public JAXBElement<String> createLine(String value) {
        return new JAXBElement<String>(_Line_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "bookno")
    public JAXBElement<String> createBookno(String value) {
        return new JAXBElement<String>(_Bookno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "class")
    public JAXBElement<String> createClass(String value) {
        return new JAXBElement<String>(_Class_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "keyword")
    public JAXBElement<String> createKeyword(String value) {
        return new JAXBElement<String>(_Keyword_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "artid")
    public JAXBElement<String> createArtid(String value) {
        return new JAXBElement<String>(_Artid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "avail")
    public JAXBElement<String> createAvail(String value) {
        return new JAXBElement<String>(_Avail_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "b")
    public JAXBElement<String> createB(String value) {
        return new JAXBElement<String>(_B_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "filing-form")
    public JAXBElement<String> createFilingForm(String value) {
        return new JAXBElement<String>(_FilingForm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "total-pages")
    public JAXBElement<String> createTotalPages(String value) {
        return new JAXBElement<String>(_TotalPages_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "content-of-public-order-and-morality")
    public JAXBElement<String> createContentOfPublicOrderAndMorality(String value) {
        return new JAXBElement<String>(_ContentOfPublicOrderAndMorality_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "trademark")
    public JAXBElement<String> createTrademark(String value) {
        return new JAXBElement<String>(_Trademark_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "article-of-industrial-revitalizing-law")
    public JAXBElement<String> createArticleOfIndustrialRevitalizingLaw(String value) {
        return new JAXBElement<String>(_ArticleOfIndustrialRevitalizingLaw_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "external-file")
    public JAXBElement<String> createExternalFile(String value) {
        return new JAXBElement<String>(_ExternalFile_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "theme-code")
    public JAXBElement<String> createThemeCode(String value) {
        return new JAXBElement<String>(_ThemeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "f-term")
    public JAXBElement<String> createFTerm(String value) {
        return new JAXBElement<String>(_FTerm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "category")
    public JAXBElement<String> createCategory(String value) {
        return new JAXBElement<String>(_Category_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "claim-text")
    public JAXBElement<String> createClaimText(String value) {
        return new JAXBElement<String>(_ClaimText_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "colf")
    public JAXBElement<String> createColf(String value) {
        return new JAXBElement<String>(_Colf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "coll")
    public JAXBElement<String> createColl(String value) {
        return new JAXBElement<String>(_Coll_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "dd")
    public JAXBElement<String> createDd(String value) {
        return new JAXBElement<String>(_Dd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "edate")
    public JAXBElement<String> createEdate(String value) {
        return new JAXBElement<String>(_Edate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "misc")
    public JAXBElement<String> createMisc(String value) {
        return new JAXBElement<String>(_Misc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "hostno")
    public JAXBElement<String> createHostno(String value) {
        return new JAXBElement<String>(_Hostno_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "hosttitle")
    public JAXBElement<String> createHosttitle(String value) {
        return new JAXBElement<String>(_Hosttitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "i")
    public JAXBElement<String> createI(String value) {
        return new JAXBElement<String>(_I_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "document-code")
    public JAXBElement<String> createDocumentCode(String value) {
        return new JAXBElement<String>(_DocumentCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "item-of-amendment")
    public JAXBElement<String> createItemOfAmendment(String value) {
        return new JAXBElement<String>(_ItemOfAmendment_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "way-of-amendment")
    public JAXBElement<String> createWayOfAmendment(String value) {
        return new JAXBElement<String>(_WayOfAmendment_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "linef")
    public JAXBElement<String> createLinef(String value) {
        return new JAXBElement<String>(_Linef_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "linel")
    public JAXBElement<String> createLinel(String value) {
        return new JAXBElement<String>(_Linel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "online-title")
    public JAXBElement<String> createOnlineTitle(String value) {
        return new JAXBElement<String>(_OnlineTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "srchterm")
    public JAXBElement<String> createSrchterm(String value) {
        return new JAXBElement<String>(_Srchterm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "othercit")
    public JAXBElement<String> createOthercit(String value) {
        return new JAXBElement<String>(_Othercit_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "paraf")
    public JAXBElement<String> createParaf(String value) {
        return new JAXBElement<String>(_Paraf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "paral")
    public JAXBElement<String> createParal(String value) {
        return new JAXBElement<String>(_Paral_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "passage")
    public JAXBElement<String> createPassage(String value) {
        return new JAXBElement<String>(_Passage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "rel-claims")
    public JAXBElement<String> createRelClaims(String value) {
        return new JAXBElement<String>(_RelClaims_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "ppf")
    public JAXBElement<String> createPpf(String value) {
        return new JAXBElement<String>(_Ppf_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "ppl")
    public JAXBElement<String> createPpl(String value) {
        return new JAXBElement<String>(_Ppl_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "sdate")
    public JAXBElement<String> createSdate(String value) {
        return new JAXBElement<String>(_Sdate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "smallcaps")
    public JAXBElement<String> createSmallcaps(String value) {
        return new JAXBElement<String>(_Smallcaps_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "sub")
    public JAXBElement<String> createSub(String value) {
        return new JAXBElement<String>(_Sub_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "sup")
    public JAXBElement<String> createSup(String value) {
        return new JAXBElement<String>(_Sup_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://patentcloud.com/DMD/jpo", name = "time")
    public JAXBElement<String> createTime(String value) {
        return new JAXBElement<String>(_Time_QNAME, String.class, null, value);
    }

}
