//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:48:41 PM CST 
//


package jpo.patent.a.gat_a.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}tech-problem"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}tech-solution"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}advantageous-effects"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}heading"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}p"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "techProblemOrTechSolutionOrAdvantageousEffects"
})
@XmlRootElement(name = "disclosure")
public class Disclosure {

    @XmlElements({
        @XmlElement(name = "tech-problem", type = TechProblem.class),
        @XmlElement(name = "tech-solution", type = TechSolution.class),
        @XmlElement(name = "advantageous-effects", type = AdvantageousEffects.class),
        @XmlElement(name = "heading", type = Heading.class),
        @XmlElement(name = "p", type = P.class)
    })
    protected List<Object> techProblemOrTechSolutionOrAdvantageousEffects;
    @XmlAttribute(name = "id")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlID
    @XmlSchemaType(name = "ID")
    protected String id;

    /**
     * Gets the value of the techProblemOrTechSolutionOrAdvantageousEffects property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the techProblemOrTechSolutionOrAdvantageousEffects property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTechProblemOrTechSolutionOrAdvantageousEffects().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TechProblem }
     * {@link TechSolution }
     * {@link AdvantageousEffects }
     * {@link Heading }
     * {@link P }
     * 
     * 
     */
    public List<Object> getTechProblemOrTechSolutionOrAdvantageousEffects() {
        if (techProblemOrTechSolutionOrAdvantageousEffects == null) {
            techProblemOrTechSolutionOrAdvantageousEffects = new ArrayList<Object>();
        }
        return this.techProblemOrTechSolutionOrAdvantageousEffects;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

}
