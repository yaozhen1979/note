//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:48:41 PM CST 
//


package jpo.patent.a.gat_a.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}text"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}received"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}accepted"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}revised"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}misc"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "textOrReceivedOrAccepted"
})
@XmlRootElement(name = "history")
public class History {

    @XmlElementRefs({
        @XmlElementRef(name = "received", namespace = "http://patentcloud.com/DMD/jpo", type = Received.class, required = false),
        @XmlElementRef(name = "accepted", namespace = "http://patentcloud.com/DMD/jpo", type = Accepted.class, required = false),
        @XmlElementRef(name = "misc", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "text", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "revised", namespace = "http://patentcloud.com/DMD/jpo", type = Revised.class, required = false)
    })
    protected List<Object> textOrReceivedOrAccepted;

    /**
     * Gets the value of the textOrReceivedOrAccepted property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the textOrReceivedOrAccepted property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTextOrReceivedOrAccepted().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Received }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Accepted }
     * {@link Revised }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getTextOrReceivedOrAccepted() {
        if (textOrReceivedOrAccepted == null) {
            textOrReceivedOrAccepted = new ArrayList<Object>();
        }
        return this.textOrReceivedOrAccepted;
    }

}
