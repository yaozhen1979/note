//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.09 於 09:12:10 AM CST 
//


package jpo.patent.design.des.v2.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PUBLICATION-COUNTRY" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="PUBLICATION-DATE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="KIND-OF-OFFICIAL-GAZETTE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="REGISTRATION-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="REGISTRATION-DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NAME-OF-ARTICLE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TRANSLATION-OF-NAME-OF-ARTICLE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}PART-DESIGN" minOccurs="0"/&gt;
 *         &lt;element name="RELATED-DESIGN-REGISTRATION-NUM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PRINCIPAL-DESIGN-REG-NUM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CONSERNED-DESIGN-REG-NUM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DESIGN-CLASSIFICATION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LOCARNO-CLASS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="D-TERM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="APPLICATION-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FILING-DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="INTERNATIONAL-REGISTRATION-NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DESIGN-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DATE-OF-INTERNATIONAL-REGISTRATION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="INTERNATIONAL-PUBLICATION-DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}SPECIAL-APPLICATION-INDICATION" minOccurs="0"/&gt;
 *         &lt;element ref="{}PARIS-PRIORITY-CLAIM-ARTICLE" minOccurs="0"/&gt;
 *         &lt;element name="APPEAL-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="APPEAL-DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SPECIAL-WAY-OF-INDUSTRY-VITALITY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}CREATOR-GROUP" minOccurs="0"/&gt;
 *         &lt;element ref="{}RIGHT-HOLDER-GROUP" minOccurs="0"/&gt;
 *         &lt;element ref="{}DESIGN-LAW-SEC-4-2-APPLIED" minOccurs="0"/&gt;
 *         &lt;element name="LACK-OF-NOVELTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}ACCELERATED-EXAM-OBJ-APP" minOccurs="0"/&gt;
 *         &lt;element name="INDICATION-OF-READY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}EXAMINER-GROUP" minOccurs="0"/&gt;
 *         &lt;element ref="{}APPEAL-EXAMINER-GROUP" minOccurs="0"/&gt;
 *         &lt;element ref="{}CONSULTATION-GROUP" minOccurs="0"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}REFERENCE-DOCUMENT"/&gt;
 *           &lt;element ref="{}EXPLANATION-OF-THE-DESIGN-ART"/&gt;
 *           &lt;element ref="{}TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN-ART"/&gt;
 *           &lt;element ref="{}EXPLANATION-OF-THE-DESIGN"/&gt;
 *           &lt;element ref="{}TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN"/&gt;
 *           &lt;element ref="{}EXPLANATION-OF-ORIGINAL-DOCUMENT"/&gt;
 *           &lt;element ref="{}DRAWING-ARTICLE"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element ref="{}CHARACTERISTIC-OF-DESIGN" minOccurs="0"/&gt;
 *         &lt;element ref="{}EXPLANATORY-FIGURE-GROUP" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "publicationcountry",
    "publicationdate",
    "kindofofficialgazette",
    "registrationnumber",
    "registrationdate",
    "nameofarticle",
    "translationofnameofarticle",
    "partdesign",
    "relateddesignregistrationnum",
    "principaldesignregnum",
    "conserneddesignregnum",
    "designclassification",
    "locarnoclass",
    "dterm",
    "applicationnumber",
    "filingdate",
    "internationalregistrationno",
    "designnumber",
    "dateofinternationalregistration",
    "internationalpublicationdate",
    "specialapplicationindication",
    "parispriorityclaimarticle",
    "appealnumber",
    "appealdate",
    "specialwayofindustryvitality",
    "creatorgroup",
    "rightholdergroup",
    "designlawsec42APPLIED",
    "lackofnovelty",
    "acceleratedexamobjapp",
    "indicationofready",
    "examinergroup",
    "appealexaminergroup",
    "consultationgroup",
    "referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART",
    "characteristicofdesign",
    "explanatoryfiguregroup"
})
@XmlRootElement(name = "DES-GAZ")
public class DESGAZ {

    @XmlElement(name = "PUBLICATION-COUNTRY", required = true)
    protected String publicationcountry;
    @XmlElement(name = "PUBLICATION-DATE", required = true)
    protected String publicationdate;
    @XmlElement(name = "KIND-OF-OFFICIAL-GAZETTE", required = true)
    protected String kindofofficialgazette;
    @XmlElement(name = "REGISTRATION-NUMBER")
    protected String registrationnumber;
    @XmlElement(name = "REGISTRATION-DATE")
    protected String registrationdate;
    @XmlElement(name = "NAME-OF-ARTICLE")
    protected String nameofarticle;
    @XmlElement(name = "TRANSLATION-OF-NAME-OF-ARTICLE")
    protected String translationofnameofarticle;
    @XmlElement(name = "PART-DESIGN")
    protected PARTDESIGN partdesign;
    @XmlElement(name = "RELATED-DESIGN-REGISTRATION-NUM")
    protected String relateddesignregistrationnum;
    @XmlElement(name = "PRINCIPAL-DESIGN-REG-NUM")
    protected String principaldesignregnum;
    @XmlElement(name = "CONSERNED-DESIGN-REG-NUM")
    protected String conserneddesignregnum;
    @XmlElement(name = "DESIGN-CLASSIFICATION")
    protected String designclassification;
    @XmlElement(name = "LOCARNO-CLASS")
    protected String locarnoclass;
    @XmlElement(name = "D-TERM")
    protected String dterm;
    @XmlElement(name = "APPLICATION-NUMBER", required = true)
    protected String applicationnumber;
    @XmlElement(name = "FILING-DATE")
    protected String filingdate;
    @XmlElement(name = "INTERNATIONAL-REGISTRATION-NO")
    protected String internationalregistrationno;
    @XmlElement(name = "DESIGN-NUMBER")
    protected String designnumber;
    @XmlElement(name = "DATE-OF-INTERNATIONAL-REGISTRATION")
    protected String dateofinternationalregistration;
    @XmlElement(name = "INTERNATIONAL-PUBLICATION-DATE")
    protected String internationalpublicationdate;
    @XmlElement(name = "SPECIAL-APPLICATION-INDICATION")
    protected SPECIALAPPLICATIONINDICATION specialapplicationindication;
    @XmlElement(name = "PARIS-PRIORITY-CLAIM-ARTICLE")
    protected PARISPRIORITYCLAIMARTICLE parispriorityclaimarticle;
    @XmlElement(name = "APPEAL-NUMBER")
    protected String appealnumber;
    @XmlElement(name = "APPEAL-DATE")
    protected String appealdate;
    @XmlElement(name = "SPECIAL-WAY-OF-INDUSTRY-VITALITY")
    protected String specialwayofindustryvitality;
    @XmlElement(name = "CREATOR-GROUP")
    protected CREATORGROUP creatorgroup;
    @XmlElement(name = "RIGHT-HOLDER-GROUP")
    protected RIGHTHOLDERGROUP rightholdergroup;
    @XmlElement(name = "DESIGN-LAW-SEC-4-2-APPLIED")
    protected DESIGNLAWSEC42APPLIED designlawsec42APPLIED;
    @XmlElement(name = "LACK-OF-NOVELTY")
    protected String lackofnovelty;
    @XmlElement(name = "ACCELERATED-EXAM-OBJ-APP")
    protected ACCELERATEDEXAMOBJAPP acceleratedexamobjapp;
    @XmlElement(name = "INDICATION-OF-READY")
    protected String indicationofready;
    @XmlElement(name = "EXAMINER-GROUP")
    protected EXAMINERGROUP examinergroup;
    @XmlElement(name = "APPEAL-EXAMINER-GROUP")
    protected APPEALEXAMINERGROUP appealexaminergroup;
    @XmlElement(name = "CONSULTATION-GROUP")
    protected CONSULTATIONGROUP consultationgroup;
    @XmlElementRefs({
        @XmlElementRef(name = "EXPLANATION-OF-THE-DESIGN-ART", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN-ART", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DRAWING-ARTICLE", type = DRAWINGARTICLE.class, required = false),
        @XmlElementRef(name = "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "EXPLANATION-OF-ORIGINAL-DOCUMENT", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "REFERENCE-DOCUMENT", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "EXPLANATION-OF-THE-DESIGN", type = JAXBElement.class, required = false)
    })
    protected List<Object> referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART;
    @XmlElement(name = "CHARACTERISTIC-OF-DESIGN")
    protected CHARACTERISTICOFDESIGN characteristicofdesign;
    @XmlElement(name = "EXPLANATORY-FIGURE-GROUP")
    protected EXPLANATORYFIGUREGROUP explanatoryfiguregroup;

    /**
     * 取得 publicationcountry 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPUBLICATIONCOUNTRY() {
        return publicationcountry;
    }

    /**
     * 設定 publicationcountry 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPUBLICATIONCOUNTRY(String value) {
        this.publicationcountry = value;
    }

    /**
     * 取得 publicationdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPUBLICATIONDATE() {
        return publicationdate;
    }

    /**
     * 設定 publicationdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPUBLICATIONDATE(String value) {
        this.publicationdate = value;
    }

    /**
     * 取得 kindofofficialgazette 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKINDOFOFFICIALGAZETTE() {
        return kindofofficialgazette;
    }

    /**
     * 設定 kindofofficialgazette 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKINDOFOFFICIALGAZETTE(String value) {
        this.kindofofficialgazette = value;
    }

    /**
     * 取得 registrationnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGISTRATIONNUMBER() {
        return registrationnumber;
    }

    /**
     * 設定 registrationnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGISTRATIONNUMBER(String value) {
        this.registrationnumber = value;
    }

    /**
     * 取得 registrationdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGISTRATIONDATE() {
        return registrationdate;
    }

    /**
     * 設定 registrationdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGISTRATIONDATE(String value) {
        this.registrationdate = value;
    }

    /**
     * 取得 nameofarticle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAMEOFARTICLE() {
        return nameofarticle;
    }

    /**
     * 設定 nameofarticle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAMEOFARTICLE(String value) {
        this.nameofarticle = value;
    }

    /**
     * 取得 translationofnameofarticle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTRANSLATIONOFNAMEOFARTICLE() {
        return translationofnameofarticle;
    }

    /**
     * 設定 translationofnameofarticle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTRANSLATIONOFNAMEOFARTICLE(String value) {
        this.translationofnameofarticle = value;
    }

    /**
     * 取得 partdesign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PARTDESIGN }
     *     
     */
    public PARTDESIGN getPARTDESIGN() {
        return partdesign;
    }

    /**
     * 設定 partdesign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PARTDESIGN }
     *     
     */
    public void setPARTDESIGN(PARTDESIGN value) {
        this.partdesign = value;
    }

    /**
     * 取得 relateddesignregistrationnum 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELATEDDESIGNREGISTRATIONNUM() {
        return relateddesignregistrationnum;
    }

    /**
     * 設定 relateddesignregistrationnum 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELATEDDESIGNREGISTRATIONNUM(String value) {
        this.relateddesignregistrationnum = value;
    }

    /**
     * 取得 principaldesignregnum 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRINCIPALDESIGNREGNUM() {
        return principaldesignregnum;
    }

    /**
     * 設定 principaldesignregnum 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRINCIPALDESIGNREGNUM(String value) {
        this.principaldesignregnum = value;
    }

    /**
     * 取得 conserneddesignregnum 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCONSERNEDDESIGNREGNUM() {
        return conserneddesignregnum;
    }

    /**
     * 設定 conserneddesignregnum 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCONSERNEDDESIGNREGNUM(String value) {
        this.conserneddesignregnum = value;
    }

    /**
     * 取得 designclassification 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESIGNCLASSIFICATION() {
        return designclassification;
    }

    /**
     * 設定 designclassification 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESIGNCLASSIFICATION(String value) {
        this.designclassification = value;
    }

    /**
     * 取得 locarnoclass 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCARNOCLASS() {
        return locarnoclass;
    }

    /**
     * 設定 locarnoclass 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCARNOCLASS(String value) {
        this.locarnoclass = value;
    }

    /**
     * 取得 dterm 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDTERM() {
        return dterm;
    }

    /**
     * 設定 dterm 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDTERM(String value) {
        this.dterm = value;
    }

    /**
     * 取得 applicationnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPLICATIONNUMBER() {
        return applicationnumber;
    }

    /**
     * 設定 applicationnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPLICATIONNUMBER(String value) {
        this.applicationnumber = value;
    }

    /**
     * 取得 filingdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFILINGDATE() {
        return filingdate;
    }

    /**
     * 設定 filingdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFILINGDATE(String value) {
        this.filingdate = value;
    }

    /**
     * 取得 internationalregistrationno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERNATIONALREGISTRATIONNO() {
        return internationalregistrationno;
    }

    /**
     * 設定 internationalregistrationno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERNATIONALREGISTRATIONNO(String value) {
        this.internationalregistrationno = value;
    }

    /**
     * 取得 designnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESIGNNUMBER() {
        return designnumber;
    }

    /**
     * 設定 designnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESIGNNUMBER(String value) {
        this.designnumber = value;
    }

    /**
     * 取得 dateofinternationalregistration 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATEOFINTERNATIONALREGISTRATION() {
        return dateofinternationalregistration;
    }

    /**
     * 設定 dateofinternationalregistration 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATEOFINTERNATIONALREGISTRATION(String value) {
        this.dateofinternationalregistration = value;
    }

    /**
     * 取得 internationalpublicationdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERNATIONALPUBLICATIONDATE() {
        return internationalpublicationdate;
    }

    /**
     * 設定 internationalpublicationdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERNATIONALPUBLICATIONDATE(String value) {
        this.internationalpublicationdate = value;
    }

    /**
     * 取得 specialapplicationindication 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link SPECIALAPPLICATIONINDICATION }
     *     
     */
    public SPECIALAPPLICATIONINDICATION getSPECIALAPPLICATIONINDICATION() {
        return specialapplicationindication;
    }

    /**
     * 設定 specialapplicationindication 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link SPECIALAPPLICATIONINDICATION }
     *     
     */
    public void setSPECIALAPPLICATIONINDICATION(SPECIALAPPLICATIONINDICATION value) {
        this.specialapplicationindication = value;
    }

    /**
     * 取得 parispriorityclaimarticle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PARISPRIORITYCLAIMARTICLE }
     *     
     */
    public PARISPRIORITYCLAIMARTICLE getPARISPRIORITYCLAIMARTICLE() {
        return parispriorityclaimarticle;
    }

    /**
     * 設定 parispriorityclaimarticle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PARISPRIORITYCLAIMARTICLE }
     *     
     */
    public void setPARISPRIORITYCLAIMARTICLE(PARISPRIORITYCLAIMARTICLE value) {
        this.parispriorityclaimarticle = value;
    }

    /**
     * 取得 appealnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPEALNUMBER() {
        return appealnumber;
    }

    /**
     * 設定 appealnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPEALNUMBER(String value) {
        this.appealnumber = value;
    }

    /**
     * 取得 appealdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPEALDATE() {
        return appealdate;
    }

    /**
     * 設定 appealdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPEALDATE(String value) {
        this.appealdate = value;
    }

    /**
     * 取得 specialwayofindustryvitality 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSPECIALWAYOFINDUSTRYVITALITY() {
        return specialwayofindustryvitality;
    }

    /**
     * 設定 specialwayofindustryvitality 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSPECIALWAYOFINDUSTRYVITALITY(String value) {
        this.specialwayofindustryvitality = value;
    }

    /**
     * 取得 creatorgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CREATORGROUP }
     *     
     */
    public CREATORGROUP getCREATORGROUP() {
        return creatorgroup;
    }

    /**
     * 設定 creatorgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CREATORGROUP }
     *     
     */
    public void setCREATORGROUP(CREATORGROUP value) {
        this.creatorgroup = value;
    }

    /**
     * 取得 rightholdergroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link RIGHTHOLDERGROUP }
     *     
     */
    public RIGHTHOLDERGROUP getRIGHTHOLDERGROUP() {
        return rightholdergroup;
    }

    /**
     * 設定 rightholdergroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link RIGHTHOLDERGROUP }
     *     
     */
    public void setRIGHTHOLDERGROUP(RIGHTHOLDERGROUP value) {
        this.rightholdergroup = value;
    }

    /**
     * 取得 designlawsec42APPLIED 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DESIGNLAWSEC42APPLIED }
     *     
     */
    public DESIGNLAWSEC42APPLIED getDESIGNLAWSEC42APPLIED() {
        return designlawsec42APPLIED;
    }

    /**
     * 設定 designlawsec42APPLIED 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DESIGNLAWSEC42APPLIED }
     *     
     */
    public void setDESIGNLAWSEC42APPLIED(DESIGNLAWSEC42APPLIED value) {
        this.designlawsec42APPLIED = value;
    }

    /**
     * 取得 lackofnovelty 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLACKOFNOVELTY() {
        return lackofnovelty;
    }

    /**
     * 設定 lackofnovelty 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLACKOFNOVELTY(String value) {
        this.lackofnovelty = value;
    }

    /**
     * 取得 acceleratedexamobjapp 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ACCELERATEDEXAMOBJAPP }
     *     
     */
    public ACCELERATEDEXAMOBJAPP getACCELERATEDEXAMOBJAPP() {
        return acceleratedexamobjapp;
    }

    /**
     * 設定 acceleratedexamobjapp 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ACCELERATEDEXAMOBJAPP }
     *     
     */
    public void setACCELERATEDEXAMOBJAPP(ACCELERATEDEXAMOBJAPP value) {
        this.acceleratedexamobjapp = value;
    }

    /**
     * 取得 indicationofready 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINDICATIONOFREADY() {
        return indicationofready;
    }

    /**
     * 設定 indicationofready 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINDICATIONOFREADY(String value) {
        this.indicationofready = value;
    }

    /**
     * 取得 examinergroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EXAMINERGROUP }
     *     
     */
    public EXAMINERGROUP getEXAMINERGROUP() {
        return examinergroup;
    }

    /**
     * 設定 examinergroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EXAMINERGROUP }
     *     
     */
    public void setEXAMINERGROUP(EXAMINERGROUP value) {
        this.examinergroup = value;
    }

    /**
     * 取得 appealexaminergroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link APPEALEXAMINERGROUP }
     *     
     */
    public APPEALEXAMINERGROUP getAPPEALEXAMINERGROUP() {
        return appealexaminergroup;
    }

    /**
     * 設定 appealexaminergroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link APPEALEXAMINERGROUP }
     *     
     */
    public void setAPPEALEXAMINERGROUP(APPEALEXAMINERGROUP value) {
        this.appealexaminergroup = value;
    }

    /**
     * 取得 consultationgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CONSULTATIONGROUP }
     *     
     */
    public CONSULTATIONGROUP getCONSULTATIONGROUP() {
        return consultationgroup;
    }

    /**
     * 設定 consultationgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CONSULTATIONGROUP }
     *     
     */
    public void setCONSULTATIONGROUP(CONSULTATIONGROUP value) {
        this.consultationgroup = value;
    }

    /**
     * Gets the value of the referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getREFERENCEDOCUMENTOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link DRAWINGARTICLE }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getREFERENCEDOCUMENTOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART() {
        if (referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART == null) {
            referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART = new ArrayList<Object>();
        }
        return this.referencedocumentOrEXPLANATIONOFTHEDESIGNARTOrTRANSLATIONOFEXPLANATIONOFTHEDESIGNART;
    }

    /**
     * 取得 characteristicofdesign 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CHARACTERISTICOFDESIGN }
     *     
     */
    public CHARACTERISTICOFDESIGN getCHARACTERISTICOFDESIGN() {
        return characteristicofdesign;
    }

    /**
     * 設定 characteristicofdesign 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CHARACTERISTICOFDESIGN }
     *     
     */
    public void setCHARACTERISTICOFDESIGN(CHARACTERISTICOFDESIGN value) {
        this.characteristicofdesign = value;
    }

    /**
     * 取得 explanatoryfiguregroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link EXPLANATORYFIGUREGROUP }
     *     
     */
    public EXPLANATORYFIGUREGROUP getEXPLANATORYFIGUREGROUP() {
        return explanatoryfiguregroup;
    }

    /**
     * 設定 explanatoryfiguregroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link EXPLANATORYFIGUREGROUP }
     *     
     */
    public void setEXPLANATORYFIGUREGROUP(EXPLANATORYFIGUREGROUP value) {
        this.explanatoryfiguregroup = value;
    }

}
