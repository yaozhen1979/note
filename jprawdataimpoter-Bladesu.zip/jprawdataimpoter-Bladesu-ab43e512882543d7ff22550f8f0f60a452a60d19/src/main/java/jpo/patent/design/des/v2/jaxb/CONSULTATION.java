//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.09 於 09:12:10 AM CST 
//


package jpo.patent.design.des.v2.jaxb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="APPLICANT-PART" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}APPLICANT-GROUP" minOccurs="0"/&gt;
 *         &lt;element name="CREATOR-PART" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{}CREATOR-GROUP" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "applicantpart",
    "applicantgroup",
    "creatorpart",
    "creatorgroup"
})
@XmlRootElement(name = "CONSULTATION")
public class CONSULTATION {

    @XmlElement(name = "APPLICANT-PART")
    protected String applicantpart;
    @XmlElement(name = "APPLICANT-GROUP")
    protected APPLICANTGROUP applicantgroup;
    @XmlElement(name = "CREATOR-PART")
    protected String creatorpart;
    @XmlElement(name = "CREATOR-GROUP")
    protected CREATORGROUP creatorgroup;

    /**
     * 取得 applicantpart 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPLICANTPART() {
        return applicantpart;
    }

    /**
     * 設定 applicantpart 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPLICANTPART(String value) {
        this.applicantpart = value;
    }

    /**
     * 取得 applicantgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link APPLICANTGROUP }
     *     
     */
    public APPLICANTGROUP getAPPLICANTGROUP() {
        return applicantgroup;
    }

    /**
     * 設定 applicantgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link APPLICANTGROUP }
     *     
     */
    public void setAPPLICANTGROUP(APPLICANTGROUP value) {
        this.applicantgroup = value;
    }

    /**
     * 取得 creatorpart 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREATORPART() {
        return creatorpart;
    }

    /**
     * 設定 creatorpart 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREATORPART(String value) {
        this.creatorpart = value;
    }

    /**
     * 取得 creatorgroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link CREATORGROUP }
     *     
     */
    public CREATORGROUP getCREATORGROUP() {
        return creatorgroup;
    }

    /**
     * 設定 creatorgroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link CREATORGROUP }
     *     
     */
    public void setCREATORGROUP(CREATORGROUP value) {
        this.creatorgroup = value;
    }

}
