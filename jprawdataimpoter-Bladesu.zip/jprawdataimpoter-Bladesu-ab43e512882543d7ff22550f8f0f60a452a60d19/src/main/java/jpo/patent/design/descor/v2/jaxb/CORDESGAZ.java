//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.04.27 於 11:03:32 AM CST 
//


package jpo.patent.design.descor.v2.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="KIND-OF-OFFICIAL-GAZETTE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="PUBLICATION-DATE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DOCUMENT-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="REGISTRATION-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GAZETTE-PUBLICATION-DATE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ANNUAL-SERIAL-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DESIGN-CLASSIFICATION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="APPLICATION-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="INTERNATIONAL-REGISTRATION-NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DESIGN-NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="GIST-OF-CORRECTION" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{}POINT-OF-CORRECTION"/&gt;
 *           &lt;element ref="{}ERROR"/&gt;
 *           &lt;element ref="{}RIGHT"/&gt;
 *           &lt;element ref="{}DES-GAZ"/&gt;
 *           &lt;element ref="{}IMAGE"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "kindofofficialgazette",
    "publicationdate",
    "documentnumber",
    "registrationnumber",
    "gazettepublicationdate",
    "annualserialnumber",
    "designclassification",
    "applicationnumber",
    "internationalregistrationno",
    "designnumber",
    "gistofcorrection",
    "pointofcorrectionOrERROROrRIGHT"
})
@XmlRootElement(name = "COR-DES-GAZ")
public class CORDESGAZ {

    @XmlElement(name = "KIND-OF-OFFICIAL-GAZETTE", required = true)
    protected String kindofofficialgazette;
    @XmlElement(name = "PUBLICATION-DATE", required = true)
    protected String publicationdate;
    @XmlElement(name = "DOCUMENT-NUMBER")
    protected String documentnumber;
    @XmlElement(name = "REGISTRATION-NUMBER")
    protected String registrationnumber;
    @XmlElement(name = "GAZETTE-PUBLICATION-DATE", required = true)
    protected String gazettepublicationdate;
    @XmlElement(name = "ANNUAL-SERIAL-NUMBER", required = true)
    protected String annualserialnumber;
    @XmlElement(name = "DESIGN-CLASSIFICATION")
    protected String designclassification;
    @XmlElement(name = "APPLICATION-NUMBER", required = true)
    protected String applicationnumber;
    @XmlElement(name = "INTERNATIONAL-REGISTRATION-NO")
    protected String internationalregistrationno;
    @XmlElement(name = "DESIGN-NUMBER")
    protected String designnumber;
    @XmlElement(name = "GIST-OF-CORRECTION", required = true)
    protected String gistofcorrection;
    @XmlElementRefs({
        @XmlElementRef(name = "IMAGE", type = IMAGE.class, required = false),
        @XmlElementRef(name = "RIGHT", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "ERROR", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "POINT-OF-CORRECTION", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "DES-GAZ", type = DESGAZ.class, required = false)
    })
    protected List<Object> pointofcorrectionOrERROROrRIGHT;

    /**
     * 取得 kindofofficialgazette 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKINDOFOFFICIALGAZETTE() {
        return kindofofficialgazette;
    }

    /**
     * 設定 kindofofficialgazette 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKINDOFOFFICIALGAZETTE(String value) {
        this.kindofofficialgazette = value;
    }

    /**
     * 取得 publicationdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPUBLICATIONDATE() {
        return publicationdate;
    }

    /**
     * 設定 publicationdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPUBLICATIONDATE(String value) {
        this.publicationdate = value;
    }

    /**
     * 取得 documentnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOCUMENTNUMBER() {
        return documentnumber;
    }

    /**
     * 設定 documentnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOCUMENTNUMBER(String value) {
        this.documentnumber = value;
    }

    /**
     * 取得 registrationnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGISTRATIONNUMBER() {
        return registrationnumber;
    }

    /**
     * 設定 registrationnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGISTRATIONNUMBER(String value) {
        this.registrationnumber = value;
    }

    /**
     * 取得 gazettepublicationdate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGAZETTEPUBLICATIONDATE() {
        return gazettepublicationdate;
    }

    /**
     * 設定 gazettepublicationdate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGAZETTEPUBLICATIONDATE(String value) {
        this.gazettepublicationdate = value;
    }

    /**
     * 取得 annualserialnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getANNUALSERIALNUMBER() {
        return annualserialnumber;
    }

    /**
     * 設定 annualserialnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setANNUALSERIALNUMBER(String value) {
        this.annualserialnumber = value;
    }

    /**
     * 取得 designclassification 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESIGNCLASSIFICATION() {
        return designclassification;
    }

    /**
     * 設定 designclassification 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESIGNCLASSIFICATION(String value) {
        this.designclassification = value;
    }

    /**
     * 取得 applicationnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPLICATIONNUMBER() {
        return applicationnumber;
    }

    /**
     * 設定 applicationnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPLICATIONNUMBER(String value) {
        this.applicationnumber = value;
    }

    /**
     * 取得 internationalregistrationno 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERNATIONALREGISTRATIONNO() {
        return internationalregistrationno;
    }

    /**
     * 設定 internationalregistrationno 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERNATIONALREGISTRATIONNO(String value) {
        this.internationalregistrationno = value;
    }

    /**
     * 取得 designnumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESIGNNUMBER() {
        return designnumber;
    }

    /**
     * 設定 designnumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESIGNNUMBER(String value) {
        this.designnumber = value;
    }

    /**
     * 取得 gistofcorrection 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGISTOFCORRECTION() {
        return gistofcorrection;
    }

    /**
     * 設定 gistofcorrection 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGISTOFCORRECTION(String value) {
        this.gistofcorrection = value;
    }

    /**
     * Gets the value of the pointofcorrectionOrERROROrRIGHT property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pointofcorrectionOrERROROrRIGHT property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPOINTOFCORRECTIONOrERROROrRIGHT().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link IMAGE }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link DESGAZ }
     * 
     * 
     */
    public List<Object> getPOINTOFCORRECTIONOrERROROrRIGHT() {
        if (pointofcorrectionOrERROROrRIGHT == null) {
            pointofcorrectionOrERROROrRIGHT = new ArrayList<Object>();
        }
        return this.pointofcorrectionOrERROROrRIGHT;
    }

}
