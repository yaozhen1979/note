//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.09 於 09:12:10 AM CST 
//


package jpo.patent.design.des.v2.jaxb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the jpo.patent.design.des.v2.jaxb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _REFERENCEDOCUMENT_QNAME = new QName("", "REFERENCE-DOCUMENT");
    private final static QName _EXPLANATIONOFTHEDESIGNART_QNAME = new QName("", "EXPLANATION-OF-THE-DESIGN-ART");
    private final static QName _TRANSLATIONOFEXPLANATIONOFTHEDESIGNART_QNAME = new QName("", "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN-ART");
    private final static QName _EXPLANATIONOFTHEDESIGN_QNAME = new QName("", "EXPLANATION-OF-THE-DESIGN");
    private final static QName _TRANSLATIONOFEXPLANATIONOFTHEDESIGN_QNAME = new QName("", "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN");
    private final static QName _EXPLANATIONOFORIGINALDOCUMENT_QNAME = new QName("", "EXPLANATION-OF-ORIGINAL-DOCUMENT");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: jpo.patent.design.des.v2.jaxb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ACCELERATEDEXAMOBJAPP }
     * 
     */
    public ACCELERATEDEXAMOBJAPP createACCELERATEDEXAMOBJAPP() {
        return new ACCELERATEDEXAMOBJAPP();
    }

    /**
     * Create an instance of {@link APPEALEXAMINER }
     * 
     */
    public APPEALEXAMINER createAPPEALEXAMINER() {
        return new APPEALEXAMINER();
    }

    /**
     * Create an instance of {@link APPEALEXAMINERGROUP }
     * 
     */
    public APPEALEXAMINERGROUP createAPPEALEXAMINERGROUP() {
        return new APPEALEXAMINERGROUP();
    }

    /**
     * Create an instance of {@link APPEALEXAMINERINCHIEF }
     * 
     */
    public APPEALEXAMINERINCHIEF createAPPEALEXAMINERINCHIEF() {
        return new APPEALEXAMINERINCHIEF();
    }

    /**
     * Create an instance of {@link APPLICANT }
     * 
     */
    public APPLICANT createAPPLICANT() {
        return new APPLICANT();
    }

    /**
     * Create an instance of {@link APPLICANTGROUP }
     * 
     */
    public APPLICANTGROUP createAPPLICANTGROUP() {
        return new APPLICANTGROUP();
    }

    /**
     * Create an instance of {@link PROXY }
     * 
     */
    public PROXY createPROXY() {
        return new PROXY();
    }

    /**
     * Create an instance of {@link ATTORNEYRIGHT }
     * 
     */
    public ATTORNEYRIGHT createATTORNEYRIGHT() {
        return new ATTORNEYRIGHT();
    }

    /**
     * Create an instance of {@link BAIKAKU }
     * 
     */
    public BAIKAKU createBAIKAKU() {
        return new BAIKAKU();
    }

    /**
     * Create an instance of {@link CHARACTERISTICOFDESIGN }
     * 
     */
    public CHARACTERISTICOFDESIGN createCHARACTERISTICOFDESIGN() {
        return new CHARACTERISTICOFDESIGN();
    }

    /**
     * Create an instance of {@link PARAGRAPH }
     * 
     */
    public PARAGRAPH createPARAGRAPH() {
        return new PARAGRAPH();
    }

    /**
     * Create an instance of {@link CONSULTATION }
     * 
     */
    public CONSULTATION createCONSULTATION() {
        return new CONSULTATION();
    }

    /**
     * Create an instance of {@link CREATORGROUP }
     * 
     */
    public CREATORGROUP createCREATORGROUP() {
        return new CREATORGROUP();
    }

    /**
     * Create an instance of {@link CREATOR }
     * 
     */
    public CREATOR createCREATOR() {
        return new CREATOR();
    }

    /**
     * Create an instance of {@link CONSULTATIONGROUP }
     * 
     */
    public CONSULTATIONGROUP createCONSULTATIONGROUP() {
        return new CONSULTATIONGROUP();
    }

    /**
     * Create an instance of {@link DESGAZ }
     * 
     */
    public DESGAZ createDESGAZ() {
        return new DESGAZ();
    }

    /**
     * Create an instance of {@link PARTDESIGN }
     * 
     */
    public PARTDESIGN createPARTDESIGN() {
        return new PARTDESIGN();
    }

    /**
     * Create an instance of {@link SPECIALAPPLICATIONINDICATION }
     * 
     */
    public SPECIALAPPLICATIONINDICATION createSPECIALAPPLICATIONINDICATION() {
        return new SPECIALAPPLICATIONINDICATION();
    }

    /**
     * Create an instance of {@link PARISPRIORITYCLAIMARTICLE }
     * 
     */
    public PARISPRIORITYCLAIMARTICLE createPARISPRIORITYCLAIMARTICLE() {
        return new PARISPRIORITYCLAIMARTICLE();
    }

    /**
     * Create an instance of {@link PARISPRIORITYGROUP }
     * 
     */
    public PARISPRIORITYGROUP createPARISPRIORITYGROUP() {
        return new PARISPRIORITYGROUP();
    }

    /**
     * Create an instance of {@link RIGHTHOLDERGROUP }
     * 
     */
    public RIGHTHOLDERGROUP createRIGHTHOLDERGROUP() {
        return new RIGHTHOLDERGROUP();
    }

    /**
     * Create an instance of {@link RIGHTHOLDER }
     * 
     */
    public RIGHTHOLDER createRIGHTHOLDER() {
        return new RIGHTHOLDER();
    }

    /**
     * Create an instance of {@link DESIGNLAWSEC42APPLIED }
     * 
     */
    public DESIGNLAWSEC42APPLIED createDESIGNLAWSEC42APPLIED() {
        return new DESIGNLAWSEC42APPLIED();
    }

    /**
     * Create an instance of {@link EXAMINERGROUP }
     * 
     */
    public EXAMINERGROUP createEXAMINERGROUP() {
        return new EXAMINERGROUP();
    }

    /**
     * Create an instance of {@link EXAMINER }
     * 
     */
    public EXAMINER createEXAMINER() {
        return new EXAMINER();
    }

    /**
     * Create an instance of {@link DRAWINGARTICLE }
     * 
     */
    public DRAWINGARTICLE createDRAWINGARTICLE() {
        return new DRAWINGARTICLE();
    }

    /**
     * Create an instance of {@link FIGUREGROUP }
     * 
     */
    public FIGUREGROUP createFIGUREGROUP() {
        return new FIGUREGROUP();
    }

    /**
     * Create an instance of {@link IMAGE }
     * 
     */
    public IMAGE createIMAGE() {
        return new IMAGE();
    }

    /**
     * Create an instance of {@link EXPLANATORYFIGUREGROUP }
     * 
     */
    public EXPLANATORYFIGUREGROUP createEXPLANATORYFIGUREGROUP() {
        return new EXPLANATORYFIGUREGROUP();
    }

    /**
     * Create an instance of {@link PARACON }
     * 
     */
    public PARACON createPARACON() {
        return new PARACON();
    }

    /**
     * Create an instance of {@link SUBSCRIPT }
     * 
     */
    public SUBSCRIPT createSUBSCRIPT() {
        return new SUBSCRIPT();
    }

    /**
     * Create an instance of {@link SUPSCRIPT }
     * 
     */
    public SUPSCRIPT createSUPSCRIPT() {
        return new SUPSCRIPT();
    }

    /**
     * Create an instance of {@link UNDERLINE }
     * 
     */
    public UNDERLINE createUNDERLINE() {
        return new UNDERLINE();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "REFERENCE-DOCUMENT")
    public JAXBElement<String> createREFERENCEDOCUMENT(String value) {
        return new JAXBElement<String>(_REFERENCEDOCUMENT_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EXPLANATION-OF-THE-DESIGN-ART")
    public JAXBElement<String> createEXPLANATIONOFTHEDESIGNART(String value) {
        return new JAXBElement<String>(_EXPLANATIONOFTHEDESIGNART_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN-ART")
    public JAXBElement<String> createTRANSLATIONOFEXPLANATIONOFTHEDESIGNART(String value) {
        return new JAXBElement<String>(_TRANSLATIONOFEXPLANATIONOFTHEDESIGNART_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EXPLANATION-OF-THE-DESIGN")
    public JAXBElement<String> createEXPLANATIONOFTHEDESIGN(String value) {
        return new JAXBElement<String>(_EXPLANATIONOFTHEDESIGN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "TRANSLATION-OF-EXPLANATION-OF-THE-DESIGN")
    public JAXBElement<String> createTRANSLATIONOFEXPLANATIONOFTHEDESIGN(String value) {
        return new JAXBElement<String>(_TRANSLATIONOFEXPLANATIONOFTHEDESIGN_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EXPLANATION-OF-ORIGINAL-DOCUMENT")
    public JAXBElement<String> createEXPLANATIONOFORIGINALDOCUMENT(String value) {
        return new JAXBElement<String>(_EXPLANATIONOFORIGINALDOCUMENT_QNAME, String.class, null, value);
    }

}
