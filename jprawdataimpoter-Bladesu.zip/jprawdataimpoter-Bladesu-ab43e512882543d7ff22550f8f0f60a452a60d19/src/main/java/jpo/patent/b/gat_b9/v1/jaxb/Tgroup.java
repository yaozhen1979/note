//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:54:09 PM CST 
//


package jpo.patent.b.gat_b9.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="colspec" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                 &lt;/sequence&gt;
 *                 &lt;attribute name="colnum" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="colname" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="colwidth" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="colsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="rowsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="char" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="charoff" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}thead" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}tbody"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="cols" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="colsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="rowsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "colspec",
    "thead",
    "tbody"
})
@XmlRootElement(name = "tgroup")
public class Tgroup {

    @XmlElement(nillable = true)
    protected List<Tgroup.Colspec> colspec;
    protected Thead thead;
    @XmlElement(required = true)
    protected Tbody tbody;
    @XmlAttribute(name = "cols", required = true)
    protected String cols;
    @XmlAttribute(name = "colsep")
    protected String colsep;
    @XmlAttribute(name = "rowsep")
    protected String rowsep;
    @XmlAttribute(name = "align")
    protected String align;

    /**
     * Gets the value of the colspec property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the colspec property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getColspec().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Tgroup.Colspec }
     * 
     * 
     */
    public List<Tgroup.Colspec> getColspec() {
        if (colspec == null) {
            colspec = new ArrayList<Tgroup.Colspec>();
        }
        return this.colspec;
    }

    /**
     * 取得 thead 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Thead }
     *     
     */
    public Thead getThead() {
        return thead;
    }

    /**
     * 設定 thead 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Thead }
     *     
     */
    public void setThead(Thead value) {
        this.thead = value;
    }

    /**
     * 取得 tbody 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Tbody }
     *     
     */
    public Tbody getTbody() {
        return tbody;
    }

    /**
     * 設定 tbody 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Tbody }
     *     
     */
    public void setTbody(Tbody value) {
        this.tbody = value;
    }

    /**
     * 取得 cols 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCols() {
        return cols;
    }

    /**
     * 設定 cols 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCols(String value) {
        this.cols = value;
    }

    /**
     * 取得 colsep 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColsep() {
        return colsep;
    }

    /**
     * 設定 colsep 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColsep(String value) {
        this.colsep = value;
    }

    /**
     * 取得 rowsep 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowsep() {
        return rowsep;
    }

    /**
     * 設定 rowsep 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowsep(String value) {
        this.rowsep = value;
    }

    /**
     * 取得 align 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlign() {
        return align;
    }

    /**
     * 設定 align 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlign(String value) {
        this.align = value;
    }


    /**
     * <p>anonymous complex type 的 Java 類別.
     * 
     * <p>下列綱要片段會指定此類別中包含的預期內容.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *       &lt;/sequence&gt;
     *       &lt;attribute name="colnum" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="colname" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="colwidth" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="colsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="rowsep" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="align" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="char" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="charoff" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Colspec {

        @XmlAttribute(name = "colnum")
        protected String colnum;
        @XmlAttribute(name = "colname")
        protected String colname;
        @XmlAttribute(name = "colwidth")
        protected String colwidth;
        @XmlAttribute(name = "colsep")
        protected String colsep;
        @XmlAttribute(name = "rowsep")
        protected String rowsep;
        @XmlAttribute(name = "align")
        protected String align;
        @XmlAttribute(name = "char")
        protected String _char;
        @XmlAttribute(name = "charoff")
        protected String charoff;

        /**
         * 取得 colnum 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getColnum() {
            return colnum;
        }

        /**
         * 設定 colnum 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setColnum(String value) {
            this.colnum = value;
        }

        /**
         * 取得 colname 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getColname() {
            return colname;
        }

        /**
         * 設定 colname 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setColname(String value) {
            this.colname = value;
        }

        /**
         * 取得 colwidth 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getColwidth() {
            return colwidth;
        }

        /**
         * 設定 colwidth 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setColwidth(String value) {
            this.colwidth = value;
        }

        /**
         * 取得 colsep 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getColsep() {
            return colsep;
        }

        /**
         * 設定 colsep 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setColsep(String value) {
            this.colsep = value;
        }

        /**
         * 取得 rowsep 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRowsep() {
            return rowsep;
        }

        /**
         * 設定 rowsep 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRowsep(String value) {
            this.rowsep = value;
        }

        /**
         * 取得 align 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAlign() {
            return align;
        }

        /**
         * 設定 align 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAlign(String value) {
            this.align = value;
        }

        /**
         * 取得 char 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getChar() {
            return _char;
        }

        /**
         * 設定 char 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setChar(String value) {
            this._char = value;
        }

        /**
         * 取得 charoff 特性的值.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCharoff() {
            return charoff;
        }

        /**
         * 設定 charoff 特性的值.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCharoff(String value) {
            this.charoff = value;
        }

    }

}
