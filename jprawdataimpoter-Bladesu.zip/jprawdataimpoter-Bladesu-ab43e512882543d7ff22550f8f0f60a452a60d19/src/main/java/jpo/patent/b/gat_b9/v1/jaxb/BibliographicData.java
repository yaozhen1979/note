//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:54:09 PM CST 
//


package jpo.patent.b.gat_b9.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}publication-reference"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}application-reference"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}invention-title"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}parties"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}priority-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}dates-of-public-availability" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}classification-ipc"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}classification-national" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}field-of-search" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}references-cited" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}number-of-claims" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}related-documents" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}bio-deposit-article" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}pct-or-regional-filing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}pct-or-regional-publishing-data" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}previously-published-document" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}application-in-foreign-language" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}total-pages"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}request-day-for-examination"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}appeal-number" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}appeal-date" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}article-of-lack-of-novelty" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}assign-or-license" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}article-of-industrial-revitalizing-law" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}external-file-info" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}accelerated-exam-or-appeal" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}reconsideration-before-appeal" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}examiner-group" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}appeal-examiner-group" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}consultation-group" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="country" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "publicationReference",
    "applicationReference",
    "inventionTitle",
    "parties",
    "priorityClaims",
    "datesOfPublicAvailability",
    "classificationIpc",
    "classificationNational",
    "fieldOfSearch",
    "referencesCited",
    "numberOfClaims",
    "relatedDocuments",
    "bioDepositArticle",
    "pctOrRegionalFilingData",
    "pctOrRegionalPublishingData",
    "previouslyPublishedDocument",
    "applicationInForeignLanguage",
    "totalPages",
    "requestDayForExamination",
    "appealNumber",
    "appealDate",
    "articleOfLackOfNovelty",
    "assignOrLicense",
    "articleOfIndustrialRevitalizingLaw",
    "externalFileInfo",
    "acceleratedExamOrAppeal",
    "reconsiderationBeforeAppeal",
    "examinerGroup",
    "appealExaminerGroup",
    "consultationGroup"
})
@XmlRootElement(name = "bibliographic-data")
public class BibliographicData {

    @XmlElement(name = "publication-reference", required = true)
    protected PublicationReference publicationReference;
    @XmlElement(name = "application-reference", required = true)
    protected ApplicationReference applicationReference;
    @XmlElement(name = "invention-title", required = true)
    protected InventionTitle inventionTitle;
    @XmlElement(required = true)
    protected Parties parties;
    @XmlElement(name = "priority-claims")
    protected PriorityClaims priorityClaims;
    @XmlElement(name = "dates-of-public-availability")
    protected DatesOfPublicAvailability datesOfPublicAvailability;
    @XmlElement(name = "classification-ipc", required = true)
    protected ClassificationIpc classificationIpc;
    @XmlElement(name = "classification-national")
    protected ClassificationNational classificationNational;
    @XmlElement(name = "field-of-search")
    protected FieldOfSearch fieldOfSearch;
    @XmlElement(name = "references-cited")
    protected ReferencesCited referencesCited;
    @XmlElement(name = "number-of-claims")
    protected NumberOfClaims numberOfClaims;
    @XmlElement(name = "related-documents")
    protected RelatedDocuments relatedDocuments;
    @XmlElement(name = "bio-deposit-article")
    protected BioDepositArticle bioDepositArticle;
    @XmlElement(name = "pct-or-regional-filing-data")
    protected PctOrRegionalFilingData pctOrRegionalFilingData;
    @XmlElement(name = "pct-or-regional-publishing-data")
    protected PctOrRegionalPublishingData pctOrRegionalPublishingData;
    @XmlElement(name = "previously-published-document")
    protected PreviouslyPublishedDocument previouslyPublishedDocument;
    @XmlElement(name = "application-in-foreign-language")
    protected String applicationInForeignLanguage;
    @XmlElement(name = "total-pages", required = true)
    protected String totalPages;
    @XmlElement(name = "request-day-for-examination", required = true)
    protected String requestDayForExamination;
    @XmlElement(name = "appeal-number")
    protected AppealNumber appealNumber;
    @XmlElement(name = "appeal-date")
    protected String appealDate;
    @XmlElement(name = "article-of-lack-of-novelty")
    protected ArticleOfLackOfNovelty articleOfLackOfNovelty;
    @XmlElement(name = "assign-or-license")
    protected String assignOrLicense;
    @XmlElement(name = "article-of-industrial-revitalizing-law")
    protected String articleOfIndustrialRevitalizingLaw;
    @XmlElement(name = "external-file-info")
    protected ExternalFileInfo externalFileInfo;
    @XmlElement(name = "accelerated-exam-or-appeal")
    protected AcceleratedExamOrAppeal acceleratedExamOrAppeal;
    @XmlElement(name = "reconsideration-before-appeal")
    protected ReconsiderationBeforeAppeal reconsiderationBeforeAppeal;
    @XmlElement(name = "examiner-group")
    protected ExaminerGroup examinerGroup;
    @XmlElement(name = "appeal-examiner-group")
    protected AppealExaminerGroup appealExaminerGroup;
    @XmlElement(name = "consultation-group")
    protected List<ConsultationGroup> consultationGroup;
    @XmlAttribute(name = "id")
    protected String id;
    @XmlAttribute(name = "lang")
    protected String lang;
    @XmlAttribute(name = "status")
    protected String status;
    @XmlAttribute(name = "country")
    protected String country;

    /**
     * 取得 publicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PublicationReference }
     *     
     */
    public PublicationReference getPublicationReference() {
        return publicationReference;
    }

    /**
     * 設定 publicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PublicationReference }
     *     
     */
    public void setPublicationReference(PublicationReference value) {
        this.publicationReference = value;
    }

    /**
     * 取得 applicationReference 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationReference }
     *     
     */
    public ApplicationReference getApplicationReference() {
        return applicationReference;
    }

    /**
     * 設定 applicationReference 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationReference }
     *     
     */
    public void setApplicationReference(ApplicationReference value) {
        this.applicationReference = value;
    }

    /**
     * 取得 inventionTitle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link InventionTitle }
     *     
     */
    public InventionTitle getInventionTitle() {
        return inventionTitle;
    }

    /**
     * 設定 inventionTitle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link InventionTitle }
     *     
     */
    public void setInventionTitle(InventionTitle value) {
        this.inventionTitle = value;
    }

    /**
     * 取得 parties 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link Parties }
     *     
     */
    public Parties getParties() {
        return parties;
    }

    /**
     * 設定 parties 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link Parties }
     *     
     */
    public void setParties(Parties value) {
        this.parties = value;
    }

    /**
     * 取得 priorityClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PriorityClaims }
     *     
     */
    public PriorityClaims getPriorityClaims() {
        return priorityClaims;
    }

    /**
     * 設定 priorityClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PriorityClaims }
     *     
     */
    public void setPriorityClaims(PriorityClaims value) {
        this.priorityClaims = value;
    }

    /**
     * 取得 datesOfPublicAvailability 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public DatesOfPublicAvailability getDatesOfPublicAvailability() {
        return datesOfPublicAvailability;
    }

    /**
     * 設定 datesOfPublicAvailability 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link DatesOfPublicAvailability }
     *     
     */
    public void setDatesOfPublicAvailability(DatesOfPublicAvailability value) {
        this.datesOfPublicAvailability = value;
    }

    /**
     * 取得 classificationIpc 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationIpc }
     *     
     */
    public ClassificationIpc getClassificationIpc() {
        return classificationIpc;
    }

    /**
     * 設定 classificationIpc 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationIpc }
     *     
     */
    public void setClassificationIpc(ClassificationIpc value) {
        this.classificationIpc = value;
    }

    /**
     * 取得 classificationNational 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ClassificationNational }
     *     
     */
    public ClassificationNational getClassificationNational() {
        return classificationNational;
    }

    /**
     * 設定 classificationNational 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassificationNational }
     *     
     */
    public void setClassificationNational(ClassificationNational value) {
        this.classificationNational = value;
    }

    /**
     * 取得 fieldOfSearch 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link FieldOfSearch }
     *     
     */
    public FieldOfSearch getFieldOfSearch() {
        return fieldOfSearch;
    }

    /**
     * 設定 fieldOfSearch 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldOfSearch }
     *     
     */
    public void setFieldOfSearch(FieldOfSearch value) {
        this.fieldOfSearch = value;
    }

    /**
     * 取得 referencesCited 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ReferencesCited }
     *     
     */
    public ReferencesCited getReferencesCited() {
        return referencesCited;
    }

    /**
     * 設定 referencesCited 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ReferencesCited }
     *     
     */
    public void setReferencesCited(ReferencesCited value) {
        this.referencesCited = value;
    }

    /**
     * 取得 numberOfClaims 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link NumberOfClaims }
     *     
     */
    public NumberOfClaims getNumberOfClaims() {
        return numberOfClaims;
    }

    /**
     * 設定 numberOfClaims 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link NumberOfClaims }
     *     
     */
    public void setNumberOfClaims(NumberOfClaims value) {
        this.numberOfClaims = value;
    }

    /**
     * 取得 relatedDocuments 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link RelatedDocuments }
     *     
     */
    public RelatedDocuments getRelatedDocuments() {
        return relatedDocuments;
    }

    /**
     * 設定 relatedDocuments 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link RelatedDocuments }
     *     
     */
    public void setRelatedDocuments(RelatedDocuments value) {
        this.relatedDocuments = value;
    }

    /**
     * 取得 bioDepositArticle 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link BioDepositArticle }
     *     
     */
    public BioDepositArticle getBioDepositArticle() {
        return bioDepositArticle;
    }

    /**
     * 設定 bioDepositArticle 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link BioDepositArticle }
     *     
     */
    public void setBioDepositArticle(BioDepositArticle value) {
        this.bioDepositArticle = value;
    }

    /**
     * 取得 pctOrRegionalFilingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public PctOrRegionalFilingData getPctOrRegionalFilingData() {
        return pctOrRegionalFilingData;
    }

    /**
     * 設定 pctOrRegionalFilingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalFilingData }
     *     
     */
    public void setPctOrRegionalFilingData(PctOrRegionalFilingData value) {
        this.pctOrRegionalFilingData = value;
    }

    /**
     * 取得 pctOrRegionalPublishingData 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public PctOrRegionalPublishingData getPctOrRegionalPublishingData() {
        return pctOrRegionalPublishingData;
    }

    /**
     * 設定 pctOrRegionalPublishingData 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PctOrRegionalPublishingData }
     *     
     */
    public void setPctOrRegionalPublishingData(PctOrRegionalPublishingData value) {
        this.pctOrRegionalPublishingData = value;
    }

    /**
     * 取得 previouslyPublishedDocument 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link PreviouslyPublishedDocument }
     *     
     */
    public PreviouslyPublishedDocument getPreviouslyPublishedDocument() {
        return previouslyPublishedDocument;
    }

    /**
     * 設定 previouslyPublishedDocument 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link PreviouslyPublishedDocument }
     *     
     */
    public void setPreviouslyPublishedDocument(PreviouslyPublishedDocument value) {
        this.previouslyPublishedDocument = value;
    }

    /**
     * 取得 applicationInForeignLanguage 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationInForeignLanguage() {
        return applicationInForeignLanguage;
    }

    /**
     * 設定 applicationInForeignLanguage 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationInForeignLanguage(String value) {
        this.applicationInForeignLanguage = value;
    }

    /**
     * 取得 totalPages 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalPages() {
        return totalPages;
    }

    /**
     * 設定 totalPages 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalPages(String value) {
        this.totalPages = value;
    }

    /**
     * 取得 requestDayForExamination 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDayForExamination() {
        return requestDayForExamination;
    }

    /**
     * 設定 requestDayForExamination 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDayForExamination(String value) {
        this.requestDayForExamination = value;
    }

    /**
     * 取得 appealNumber 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AppealNumber }
     *     
     */
    public AppealNumber getAppealNumber() {
        return appealNumber;
    }

    /**
     * 設定 appealNumber 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AppealNumber }
     *     
     */
    public void setAppealNumber(AppealNumber value) {
        this.appealNumber = value;
    }

    /**
     * 取得 appealDate 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealDate() {
        return appealDate;
    }

    /**
     * 設定 appealDate 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealDate(String value) {
        this.appealDate = value;
    }

    /**
     * 取得 articleOfLackOfNovelty 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ArticleOfLackOfNovelty }
     *     
     */
    public ArticleOfLackOfNovelty getArticleOfLackOfNovelty() {
        return articleOfLackOfNovelty;
    }

    /**
     * 設定 articleOfLackOfNovelty 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ArticleOfLackOfNovelty }
     *     
     */
    public void setArticleOfLackOfNovelty(ArticleOfLackOfNovelty value) {
        this.articleOfLackOfNovelty = value;
    }

    /**
     * 取得 assignOrLicense 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignOrLicense() {
        return assignOrLicense;
    }

    /**
     * 設定 assignOrLicense 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignOrLicense(String value) {
        this.assignOrLicense = value;
    }

    /**
     * 取得 articleOfIndustrialRevitalizingLaw 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArticleOfIndustrialRevitalizingLaw() {
        return articleOfIndustrialRevitalizingLaw;
    }

    /**
     * 設定 articleOfIndustrialRevitalizingLaw 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArticleOfIndustrialRevitalizingLaw(String value) {
        this.articleOfIndustrialRevitalizingLaw = value;
    }

    /**
     * 取得 externalFileInfo 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExternalFileInfo }
     *     
     */
    public ExternalFileInfo getExternalFileInfo() {
        return externalFileInfo;
    }

    /**
     * 設定 externalFileInfo 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExternalFileInfo }
     *     
     */
    public void setExternalFileInfo(ExternalFileInfo value) {
        this.externalFileInfo = value;
    }

    /**
     * 取得 acceleratedExamOrAppeal 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AcceleratedExamOrAppeal }
     *     
     */
    public AcceleratedExamOrAppeal getAcceleratedExamOrAppeal() {
        return acceleratedExamOrAppeal;
    }

    /**
     * 設定 acceleratedExamOrAppeal 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AcceleratedExamOrAppeal }
     *     
     */
    public void setAcceleratedExamOrAppeal(AcceleratedExamOrAppeal value) {
        this.acceleratedExamOrAppeal = value;
    }

    /**
     * 取得 reconsiderationBeforeAppeal 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ReconsiderationBeforeAppeal }
     *     
     */
    public ReconsiderationBeforeAppeal getReconsiderationBeforeAppeal() {
        return reconsiderationBeforeAppeal;
    }

    /**
     * 設定 reconsiderationBeforeAppeal 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ReconsiderationBeforeAppeal }
     *     
     */
    public void setReconsiderationBeforeAppeal(ReconsiderationBeforeAppeal value) {
        this.reconsiderationBeforeAppeal = value;
    }

    /**
     * 取得 examinerGroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link ExaminerGroup }
     *     
     */
    public ExaminerGroup getExaminerGroup() {
        return examinerGroup;
    }

    /**
     * 設定 examinerGroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link ExaminerGroup }
     *     
     */
    public void setExaminerGroup(ExaminerGroup value) {
        this.examinerGroup = value;
    }

    /**
     * 取得 appealExaminerGroup 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link AppealExaminerGroup }
     *     
     */
    public AppealExaminerGroup getAppealExaminerGroup() {
        return appealExaminerGroup;
    }

    /**
     * 設定 appealExaminerGroup 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link AppealExaminerGroup }
     *     
     */
    public void setAppealExaminerGroup(AppealExaminerGroup value) {
        this.appealExaminerGroup = value;
    }

    /**
     * Gets the value of the consultationGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consultationGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsultationGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsultationGroup }
     * 
     * 
     */
    public List<ConsultationGroup> getConsultationGroup() {
        if (consultationGroup == null) {
            consultationGroup = new ArrayList<ConsultationGroup>();
        }
        return this.consultationGroup;
    }

    /**
     * 取得 id 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * 設定 id 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

}
