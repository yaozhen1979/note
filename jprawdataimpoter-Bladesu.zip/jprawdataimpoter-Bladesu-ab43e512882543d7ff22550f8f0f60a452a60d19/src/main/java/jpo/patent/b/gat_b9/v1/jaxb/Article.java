//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:54:09 PM CST 
//


package jpo.patent.b.gat_b9.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}text"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}author"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}atl"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}subname"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}serial"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}book"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}absno"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}location"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}class"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}keyword"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}cpyrt"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}artid"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}refno"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "textOrAuthorOrAtl"
})
@XmlRootElement(name = "article")
public class Article {

    @XmlElementRefs({
        @XmlElementRef(name = "atl", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "text", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "absno", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "cpyrt", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "keyword", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "book", namespace = "http://patentcloud.com/DMD/jpo", type = Book.class, required = false),
        @XmlElementRef(name = "refno", namespace = "http://patentcloud.com/DMD/jpo", type = Refno.class, required = false),
        @XmlElementRef(name = "location", namespace = "http://patentcloud.com/DMD/jpo", type = Location.class, required = false),
        @XmlElementRef(name = "serial", namespace = "http://patentcloud.com/DMD/jpo", type = Serial.class, required = false),
        @XmlElementRef(name = "class", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "subname", namespace = "http://patentcloud.com/DMD/jpo", type = Subname.class, required = false),
        @XmlElementRef(name = "author", namespace = "http://patentcloud.com/DMD/jpo", type = Author.class, required = false),
        @XmlElementRef(name = "artid", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false)
    })
    protected List<Object> textOrAuthorOrAtl;

    /**
     * Gets the value of the textOrAuthorOrAtl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the textOrAuthorOrAtl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTextOrAuthorOrAtl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Book }
     * {@link Refno }
     * {@link Location }
     * {@link Serial }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Subname }
     * {@link Author }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getTextOrAuthorOrAtl() {
        if (textOrAuthorOrAtl == null) {
            textOrAuthorOrAtl = new ArrayList<Object>();
        }
        return this.textOrAuthorOrAtl;
    }

}
