//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.04.12 於 10:01:54 AM CST 
//


package jpo.patent.b.gat_b9.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}content-of-public-order-and-morality" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}unapproved-use-of-trademark" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contentOfPublicOrderAndMorality",
    "unapprovedUseOfTrademark"
})
@XmlRootElement(name = "article-of-public-order-and-morality")
public class ArticleOfPublicOrderAndMorality {

    @XmlElement(name = "content-of-public-order-and-morality")
    protected List<String> contentOfPublicOrderAndMorality;
    @XmlElement(name = "unapproved-use-of-trademark")
    protected UnapprovedUseOfTrademark unapprovedUseOfTrademark;

    /**
     * Gets the value of the contentOfPublicOrderAndMorality property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contentOfPublicOrderAndMorality property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContentOfPublicOrderAndMorality().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getContentOfPublicOrderAndMorality() {
        if (contentOfPublicOrderAndMorality == null) {
            contentOfPublicOrderAndMorality = new ArrayList<String>();
        }
        return this.contentOfPublicOrderAndMorality;
    }

    /**
     * 取得 unapprovedUseOfTrademark 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link UnapprovedUseOfTrademark }
     *     
     */
    public UnapprovedUseOfTrademark getUnapprovedUseOfTrademark() {
        return unapprovedUseOfTrademark;
    }

    /**
     * 設定 unapprovedUseOfTrademark 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link UnapprovedUseOfTrademark }
     *     
     */
    public void setUnapprovedUseOfTrademark(UnapprovedUseOfTrademark value) {
        this.unapprovedUseOfTrademark = value;
    }

}
