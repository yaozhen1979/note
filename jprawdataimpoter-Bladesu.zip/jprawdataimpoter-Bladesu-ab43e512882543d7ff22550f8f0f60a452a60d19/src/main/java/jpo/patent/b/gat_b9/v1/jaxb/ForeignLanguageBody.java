//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.04.12 於 10:01:54 AM CST 
//


package jpo.patent.b.gat_b9.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}doc-page"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}foreign-language-description"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}foreign-language-claims"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}foreign-language-abstract"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}foreign-language-drawings"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}reference-file-article"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="lang" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="dtd-version" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="file" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "docPageOrForeignLanguageDescriptionOrForeignLanguageClaims"
})
@XmlRootElement(name = "foreign-language-body")
public class ForeignLanguageBody {

    @XmlElements({
        @XmlElement(name = "doc-page", type = DocPage.class),
        @XmlElement(name = "foreign-language-description", type = ForeignLanguageDescription.class),
        @XmlElement(name = "foreign-language-claims", type = ForeignLanguageClaims.class),
        @XmlElement(name = "foreign-language-abstract", type = ForeignLanguageAbstract.class),
        @XmlElement(name = "foreign-language-drawings", type = ForeignLanguageDrawings.class),
        @XmlElement(name = "reference-file-article", type = ReferenceFileArticle.class)
    })
    protected List<Object> docPageOrForeignLanguageDescriptionOrForeignLanguageClaims;
    @XmlAttribute(name = "lang", required = true)
    protected String lang;
    @XmlAttribute(name = "dtd-version")
    protected String dtdVersion;
    @XmlAttribute(name = "file")
    protected String file;
    @XmlAttribute(name = "status")
    protected String status;

    /**
     * Gets the value of the docPageOrForeignLanguageDescriptionOrForeignLanguageClaims property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docPageOrForeignLanguageDescriptionOrForeignLanguageClaims property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocPageOrForeignLanguageDescriptionOrForeignLanguageClaims().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocPage }
     * {@link ForeignLanguageDescription }
     * {@link ForeignLanguageClaims }
     * {@link ForeignLanguageAbstract }
     * {@link ForeignLanguageDrawings }
     * {@link ReferenceFileArticle }
     * 
     * 
     */
    public List<Object> getDocPageOrForeignLanguageDescriptionOrForeignLanguageClaims() {
        if (docPageOrForeignLanguageDescriptionOrForeignLanguageClaims == null) {
            docPageOrForeignLanguageDescriptionOrForeignLanguageClaims = new ArrayList<Object>();
        }
        return this.docPageOrForeignLanguageDescriptionOrForeignLanguageClaims;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    /**
     * 取得 dtdVersion 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtdVersion() {
        return dtdVersion;
    }

    /**
     * 設定 dtdVersion 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtdVersion(String value) {
        this.dtdVersion = value;
    }

    /**
     * 取得 file 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFile() {
        return file;
    }

    /**
     * 設定 file 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFile(String value) {
        this.file = value;
    }

    /**
     * 取得 status 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * 設定 status 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
