//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.13 於 04:54:09 PM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://patentcloud.com/DMD/jpo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package jpo.patent.b.gat_b9.v1.jaxb;
