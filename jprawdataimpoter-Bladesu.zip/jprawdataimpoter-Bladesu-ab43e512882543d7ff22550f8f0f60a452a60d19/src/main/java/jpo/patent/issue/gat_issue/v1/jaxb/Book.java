//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.07 於 06:41:57 PM CST 
//


package jpo.patent.issue.gat_issue.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}text"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}author"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}book-title"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}conference"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}subtitle"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}subname"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}edition"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}imprint"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}descrip"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}series"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}absno"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}location"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}isbn"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}pubid"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}vid"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}bookno"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}notes"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}class"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}keyword"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}cpyrt"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}refno"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "textOrAuthorOrBookTitle"
})
@XmlRootElement(name = "book")
public class Book {

    @XmlElementRefs({
        @XmlElementRef(name = "text", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "bookno", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "edition", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "vid", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "absno", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "subtitle", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "book-title", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "cpyrt", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "keyword", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "pubid", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "descrip", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "notes", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "isbn", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "conference", namespace = "http://patentcloud.com/DMD/jpo", type = Conference.class, required = false),
        @XmlElementRef(name = "refno", namespace = "http://patentcloud.com/DMD/jpo", type = Refno.class, required = false),
        @XmlElementRef(name = "imprint", namespace = "http://patentcloud.com/DMD/jpo", type = Imprint.class, required = false),
        @XmlElementRef(name = "location", namespace = "http://patentcloud.com/DMD/jpo", type = Location.class, required = false),
        @XmlElementRef(name = "series", namespace = "http://patentcloud.com/DMD/jpo", type = Series.class, required = false),
        @XmlElementRef(name = "class", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "subname", namespace = "http://patentcloud.com/DMD/jpo", type = Subname.class, required = false),
        @XmlElementRef(name = "author", namespace = "http://patentcloud.com/DMD/jpo", type = Author.class, required = false)
    })
    protected List<Object> textOrAuthorOrBookTitle;

    /**
     * Gets the value of the textOrAuthorOrBookTitle property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the textOrAuthorOrBookTitle property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTextOrAuthorOrBookTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Conference }
     * {@link Refno }
     * {@link Imprint }
     * {@link Location }
     * {@link Series }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Subname }
     * {@link Author }
     * 
     * 
     */
    public List<Object> getTextOrAuthorOrBookTitle() {
        if (textOrAuthorOrBookTitle == null) {
            textOrAuthorOrBookTitle = new ArrayList<Object>();
        }
        return this.textOrAuthorOrBookTitle;
    }

}
