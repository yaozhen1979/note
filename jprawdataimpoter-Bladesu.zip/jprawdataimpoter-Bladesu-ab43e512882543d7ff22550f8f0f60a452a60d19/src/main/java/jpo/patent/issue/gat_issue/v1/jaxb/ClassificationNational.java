//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.07 於 06:41:57 PM CST 
//


package jpo.patent.issue.gat_issue.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}country"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}edition" minOccurs="0"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}main-clsf"/&gt;
 *         &lt;element ref="{http://patentcloud.com/DMD/jpo}further-clsf" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}additional-info"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}linked-indexing-code-group"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}unlinked-indexing-code"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "country",
    "edition",
    "mainClsf",
    "furtherClsf",
    "additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode"
})
@XmlRootElement(name = "classification-national")
public class ClassificationNational {

    @XmlElement(required = true)
    protected String country;
    protected String edition;
    @XmlElement(name = "main-clsf", required = true)
    protected MainClsf mainClsf;
    @XmlElement(name = "further-clsf")
    protected List<FurtherClsf> furtherClsf;
    @XmlElements({
        @XmlElement(name = "additional-info", type = AdditionalInfo.class),
        @XmlElement(name = "linked-indexing-code-group", type = LinkedIndexingCodeGroup.class),
        @XmlElement(name = "unlinked-indexing-code", type = UnlinkedIndexingCode.class)
    })
    protected List<Object> additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;

    /**
     * 取得 country 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * 設定 country 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * 取得 edition 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEdition() {
        return edition;
    }

    /**
     * 設定 edition 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEdition(String value) {
        this.edition = value;
    }

    /**
     * 取得 mainClsf 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link MainClsf }
     *     
     */
    public MainClsf getMainClsf() {
        return mainClsf;
    }

    /**
     * 設定 mainClsf 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link MainClsf }
     *     
     */
    public void setMainClsf(MainClsf value) {
        this.mainClsf = value;
    }

    /**
     * Gets the value of the furtherClsf property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the furtherClsf property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFurtherClsf().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FurtherClsf }
     * 
     * 
     */
    public List<FurtherClsf> getFurtherClsf() {
        if (furtherClsf == null) {
            furtherClsf = new ArrayList<FurtherClsf>();
        }
        return this.furtherClsf;
    }

    /**
     * Gets the value of the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalInfo }
     * {@link LinkedIndexingCodeGroup }
     * {@link UnlinkedIndexingCode }
     * 
     * 
     */
    public List<Object> getAdditionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode() {
        if (additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode == null) {
            additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode = new ArrayList<Object>();
        }
        return this.additionalInfoOrLinkedIndexingCodeGroupOrUnlinkedIndexingCode;
    }

}
