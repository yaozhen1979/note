//
// 此檔案是由 JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.11 所產生 
// 請參閱 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2016.05.07 於 06:41:57 PM CST 
//


package jpo.patent.issue.gat_issue.v1.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type 的 Java 類別.
 * 
 * <p>下列綱要片段會指定此類別中包含的預期內容.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}name"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}prefix"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}last-name"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}first-name"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}middle-name"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}suffix"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}iid"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}role"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}orgname"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}department"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}synonym"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}registered-number"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}address"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}phone"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}fax"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}email"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}url"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}ead"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}dtext"/&gt;
 *           &lt;element ref="{http://patentcloud.com/DMD/jpo}text"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "nameOrPrefixOrLastName"
})
@XmlRootElement(name = "addressbook")
public class Addressbook {

    @XmlElementRefs({
        @XmlElementRef(name = "email", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "text", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "prefix", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "orgname", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "department", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "last-name", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "synonym", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "registered-number", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "name", namespace = "http://patentcloud.com/DMD/jpo", type = Name.class, required = false),
        @XmlElementRef(name = "ead", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "url", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "address", namespace = "http://patentcloud.com/DMD/jpo", type = Address.class, required = false),
        @XmlElementRef(name = "phone", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "first-name", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "iid", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "dtext", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "suffix", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "middle-name", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "fax", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "role", namespace = "http://patentcloud.com/DMD/jpo", type = JAXBElement.class, required = false)
    })
    protected List<Object> nameOrPrefixOrLastName;
    @XmlAttribute(name = "lang")
    protected String lang;

    /**
     * Gets the value of the nameOrPrefixOrLastName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nameOrPrefixOrLastName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNameOrPrefixOrLastName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Name }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link Address }
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<Object> getNameOrPrefixOrLastName() {
        if (nameOrPrefixOrLastName == null) {
            nameOrPrefixOrLastName = new ArrayList<Object>();
        }
        return this.nameOrPrefixOrLastName;
    }

    /**
     * 取得 lang 特性的值.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * 設定 lang 特性的值.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

}
