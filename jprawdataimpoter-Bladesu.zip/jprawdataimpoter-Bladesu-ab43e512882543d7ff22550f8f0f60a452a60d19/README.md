## 日本原始資料的一些備忘資訊
# 關於數學式的 tag
- 直接用 <sup> 等上下標的  
  src/test/resources/wips/patent/grant/sampleXML/p/0004673302.xml
- 直接用圖檔的
  src/test/resources/wips/patent/application/sampleXML/p/2004153493.xml

# 紀錄一些 XML tag 異常導致 CDATA 不過的專利
隨機抽樣幾篇來看，都是文字信息欄位(claims/abstract/description 等)中出現出現 tag match error  
 * <U> </U> 沒有 match: 目前先把所有 <U> </U> 濾掉
 * "<SP>"變成 "鼼SP>": 替換回 <SP>
 * 孤立的"</A>" tag: 目前先把所有 </A> 濾掉
 * <SB> </SB> 沒有 match: 目前先把所有 <SB> </SB> 濾掉


# src/main/resources/garbled 裡面存放 rawdata 為亂碼，人工校正過後的資料
# src/main/resources/sbnomatched 裡面存放 rawdata 的 SB tag 沒有對應，人工校正過後的資料
# wips 採購的資料目前有 21 篇 xml 是不完整的，且這 23 篇 doDate 可能和所在的目錄日期不符合，紀錄如下
```
#公開
wips\disk\2011_update\Application\p\2011\m09\2011172587\2011172587.xml  實際 doDate 2011/09/08
wips\disk\2011_update\Application\p\2011\m09\2011187480\2011187480.xml  實際 doDate 2011/09/22
wips\disk\2011_update\Application\p\2011\m09\2011191446\2011191446.xml  實際 doDate 2011/09/29
wips\disk\2011_update\Application\p\2011\m09\2011193428\2011193428.xml  實際 doDate 2011/09/29
wips\disk\2011_update\Application\p\2011\m10\2011202032\2011202032.xml  實際 doDate 2011/10/13
wips\disk\2011_update\20111111\Application\p\2011223356\2011223356.xml  實際 doDate 2011/11/04
wips\disk\2011_update\20111118\Application\p\2011229037\2011229037.xml  實際 doDate 2011/11/10
wips\disk\2011_update\20111125\Application\p\2011234123\2011234123.xml  實際 doDate 2011/11/17
wips\disk\2011_update\20111202\Application\p\2011235122\2011235122.xml  實際 doDate 2011/11/24
wips\disk\2011_update\20111223\Application\p\2011251203\2011251203.xml  實際 doDate 2011/12/15
wips\disk\2011_update\20111223\Application\p\2011251203\2011251203.xml  實際 doDate 2011/12/15
wips\disk\2011_update\20111230\Application\p\2011259515\2011259515.xml  實際 doDate 2011/12/22

#公告
wips\disk\2011_update\Grant\p\2011\m09\0004783783\0004783783.xml  實際 doDate 2011/07/15
wips\disk\2011_update\Grant\p\2011\m09\0004783787\0004783787.xml  實際 doDate 2011/07/15
wips\disk\2011_update\Grant\p\2011\m10\0004787737\0004787737.xml  實際 doDate 2011/07/22
wips\disk\2011_update\20111118\Grant\p\0004810897\0004810897.xml  實際 doDate 2011/09/02
wips\disk\2011_update\20111125\Grant\p\0004815554\0004815554.xml  實際 doDate 2011/09/09
wips\disk\2011_update\20111125\Grant\p\0004815558\0004815558.xml  實際 doDate 2011/09/09
wips\disk\2011_update\20111223\Grant\p\0004835879\0004835879.xml  實際 doDate 2011/10/07
wips\disk\2011_update\20111223\Grant\p\0004835879\0004835879.xml  實際 doDate 2011/10/07
wips\disk\2011_update\20111230\Grant\p\0004840888\0004840888.xml  實際 doDate 2011/10/14

#實用新案(新制)
wips\disk\registered_utility\Grant\u\1995\m12\0003022535\0003022535.xml 實際 doDate 1996/03/26
wips\disk\registered_utility\Grant\u\2008\m09\0003145721\0003145721.xml 實際 doDate 2008/10/16
```
# 關於公開專利沒有 title
這篇公開專利 wips/disk/Application/u/1994/m08/1994061219/1994061219.xml 沒有 title  
這篇公告專利 wips/disk/grant/p/2004/m02/0003500388
官網查詢和 PDF 也沒有  
因此修改 xsd 使 title 為非必要出現(之後需要想辦法驗證是不是所有沒 title 都是官網也沒有的...)

# 關於優先權(priority-claims)沒有號碼和國家
wips/disk/grant/p/1994/m04/1994025313 這篇專利的其中一個優先權只給日期沒給其他資訊

# wips 給的公告專利，2011/11/01 ~ 2011/12/31 有缺 doDate
新制公告發明要用登錄日當 doDate，這區間的專利有缺漏登錄日資訊  
從 JPO 採買的資料補